// content/select-adapter/adapters/layui.js — LayUI (.layui-form-select) 适配器
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   LayuiSelectAdapter (模块4737):   行 16772-17621
//   triggerLayuiSelect (混淆名 v/y): 行 17385-17436
//
// 算法 (对应源码 v() 函数, 行17388-17436):
//   1. container = closest(.layui-form-select)
//   2. trigger = container 内 input[type=text] 或 .layui-select-title (下拉标题条)
//   3. focus + 点击 trigger 展开面板
//   4. 面板优先在 container 内找 dl.layui-anim.layui-anim-upbit 且可见；找不到再全局搜索
//      (layui 面板一般紧跟在 container 后面，但也可能被上层定位样式挪出去)
//   5. 找到面板后调用通用 selectMatchingOption (layui 选项是 dl > dd)
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};
  var H = SA._helpers;
  var CFG = SA._config.layui;
  var PANEL_SELECTOR = "dl.layui-anim.layui-anim-upbit";

  async function selectOneLayuiValue(element, container, trigger, value) {
    trigger.focus && trigger.focus();
    await AF.DomUtils.safeClickElement(trigger);
    await AF.Utils.sleep(200);

    var panel = container.querySelector(PANEL_SELECTOR);
    if (!panel || !AF.DomUtils.isElementVisible(panel)) {
      panel = H.findVisibleDropdownNear(element, PANEL_SELECTOR, CFG.container);
    }
    if (!panel) {
      panel = await H.waitForVisibleDropdownNear(element, PANEL_SELECTOR, CFG.container, 1500);
    }
    if (!panel) return false;
    return await H.selectMatchingOption(panel, value, "dd");
  }

  async function triggerLayuiSelect(element, value) {
    try {
      if (!element || value === undefined || value === null || value === "") return false;
      var container = element.closest(CFG.container) || element;
      var trigger = container.querySelector('input[type="text"]') || container.querySelector(CFG.trigger) || container;

      var ok;
      if (Array.isArray(value)) {
        ok = false;
        for (var i = 0; i < value.length; i++) {
          var one = await selectOneLayuiValue(element, container, trigger, value[i]);
          if (one) ok = true;
          await AF.Utils.sleep(150);
        }
      } else {
        ok = await selectOneLayuiValue(element, container, trigger, value);
      }
      H.dispatchChangeEvents(element);
      return ok;
    } catch (e) {
      return false;
    }
  }

  SA._registry["layui"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        return await triggerLayuiSelect(element, value);
      },
    };
  };
})();
