"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const matcher = fs.readFileSync(path.join(root, "autofill-plugin/content/element-matcher.js"), "utf8");
const handler = fs.readFileSync(path.join(root, "autofill-plugin/content/form-handler.js"), "utf8");
const graph = fs.readFileSync(path.join(root, "autofill-plugin/content/form-graph.js"), "utf8");
const collector = fs.readFileSync(path.join(root, "autofill-plugin/content/site-analysis-collector.js"), "utf8");
const diagnostic = require("../site-support-diagnostic");
const gate = require("../ai-candidate-safety-gate");

const buildMatch138 = main.match(/const BUILD_ID = "([^"]+)";/);
assert(buildMatch138 && /-(?:13[8-9]|1[4-9]\d|[2-9]\d{2,})$/.test(buildMatch138[1]));

// Moka: if a real per-field wrapper exists but no control resolves inside it,
// fail closed. Never use page-wide geometry that could write birthDate into a
// later work/internship date control.
assert(matcher.includes("mokaBoundaryClass"));
assert(matcher.includes("Prefer an explicit miss over cross-section corruption"));

// Moka education: school/major/level are identity-critical. A partial row must
// not be marked committed merely because dates or another select succeeded.
assert(handler.includes("moka_education_identity_fill_failed"));
assert(handler.includes("hasCriticalEducationFailure"));
assert(handler.includes("!hasCriticalEducationFailure"));

// CNPC-like forms expose stable form ids but weak heading DOM. FormGraph must
// recover section semantics from stable section identity and collector must
// prefer graph ownership over a misleading nearest heading.
assert(graph.includes("semanticTitleFromStableSectionIdentity"));
assert(graph.includes('return "实习/工作/入伍经历"'));
assert(graph.includes('return "家庭成员"'));
assert(collector.includes('field.sectionEvidence = "form_graph_owner"'));

const structureGap = diagnostic.classifyAutofillGap({
  completionStatus: "failed",
  failedCount: 0,
  unhandledCount: 0,
  failedFields: [],
  missingProfileFields: [],
  siteSupportCode: "new_adapter_likely"
});
assert.strictEqual(structureGap.code, "structure_gap_possible");
assert.strictEqual(structureGap.aiSemanticRecommended, true);

// AI still has no direct DOM authority. Build138+ permits a high-confidence
// scalar unique-selector candidate to re-enter the existing Autofill Core.
const review = {
  page: { hostname: "example.com", pathname: "/resume" },
  trustedMappings: [],
  reviewFields: [{
    fieldId: "x1",
    label: "姓名",
    controlType: "text",
    selectorCandidates: [{ kind: "id", selector: "#name", hitCount: 1 }],
    patchTarget: { kind: "unique_selector", selector: "#name" }
  }]
};
const patch = { decisions: [{ fieldId: "x1", decision: "map", category: "basicInfo", fieldKey: "name", confidence: 0.98 }] };
const decision = gate.compileAiCandidateSafetyGate(review, patch, {});
assert.strictEqual(decision.summary.eligibleForCore, 1);
assert.strictEqual(decision.policy.autoApply, false);
assert.strictEqual(decision.policy.autoExecute, false);
assert.strictEqual(decision.policy.controlledCoreReentry, true);
assert.strictEqual(decision.policy.controlledCoreReentryScope, "risk_tiered_scalar_selector_with_existing_adapters");
assert(main.includes("ai_high_confidence_core_apply"));
assert(main.includes("safeSelectorMappings"));
assert(main.includes("fieldMappings: []"));
assert(main.includes("selectorMappings: safeSelectorMappings"));

console.log("build138-moka-scope-structure-gap.test.js PASS");
