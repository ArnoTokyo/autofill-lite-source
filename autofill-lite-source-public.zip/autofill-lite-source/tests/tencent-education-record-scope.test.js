"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const handler = fs.readFileSync(path.join(root, "autofill-plugin/content/form-handler.js"), "utf8");

assert(handler.includes("function detectEducationRecordCards(container, matcher)"));
assert(handler.includes("/^(?:join|careers)\\.qq\\.com$/i"), "Tencent education detection must be explicitly scoped to join/careers.qq.com");
assert(handler.includes('container.querySelectorAll(".info_list, .experience_box")'), "Tencent education rows must use their real record containers");
assert(handler.includes("educationSignals >= 2"), "Tencent record candidates must require multiple education-specific signals");
assert(handler.includes("candidate.contains(other)"), "nested Tencent wrappers must be de-duplicated before allocating education rows");
assert(handler.includes('var labelSelector = "label,.subtitle,'), "Tencent subtitle labels must remain available to the shared field executor");
assert(handler.includes("fillEducationSequentially"), "education must continue using the sequential single-owner executor");
console.log("tencent education record scope test: PASS");
