// content/select-adapter/adapters/aui.js — Huawei AUI (.aui-select) 适配器
//
// 华为招聘站点使用自研 AUI 组件: 外层 .aui-select，真实输入框仍是
// .aui-input__inner，下拉弹层通常 portal 到 body。它不属于 Ant/Element，
// 不能用普通 input.value 可靠触发 Vue 状态更新，因此单独走
// "点击触发器 -> 输入过滤词 -> 等候选弹层 -> 选择匹配项"。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};
  var H = SA._helpers;
  var CFG = SA._config.aui;

  function setInputValue(input, value) {
    var text = String(value == null ? "" : value);
    var descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    if (descriptor && descriptor.set) descriptor.set.call(input, text);
    else input.value = text;
    input.dispatchEvent(new InputEvent("input", {
      bubbles: true,
      cancelable: true,
      composed: true,
      data: text,
      inputType: "insertText",
    }));
    input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true, composed: true }));
  }

  // 学校名称沿用已验证稳定的输入方式。不要让专业控件的特殊兼容逻辑
  // 改变学校搜索框的焦点和节点生命周期。
  async function typeStableSearchValue(input, value) {
    var text = String(value == null ? "" : value);
    setInputValue(input, "");
    await AF.Utils.sleep(50);
    var current = "";
    for (var i = 0; i < text.length; i++) {
      current += text.charAt(i);
      var descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
      if (descriptor && descriptor.set) descriptor.set.call(input, current);
      else input.value = current;
      input.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        cancelable: true,
        composed: true,
        data: text.charAt(i),
        inputType: "insertText",
      }));
      await AF.Utils.sleep(25);
    }
    input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true, composed: true }));
    await AF.Utils.sleep(300);
    return true;
  }

  // 华为毕业院校的远程搜索不是只监听 input/change，还依赖键盘输入链来刷新
  // 候选。该策略只给“毕业院校/学校名称”使用，不改变其他 AUI 下拉。
  async function typeHuaweiSchoolSearchValue(input, value) {
    var text = String(value == null ? "" : value);
    setInputValue(input, "");
    await AF.Utils.sleep(80);
    var current = "";
    for (var i = 0; i < text.length; i++) {
      var character = text.charAt(i);
      current += character;
      input.focus && input.focus();
      input.dispatchEvent(new KeyboardEvent("keydown", {
        bubbles: true, cancelable: true, composed: true, key: character,
      }));
      input.dispatchEvent(new InputEvent("beforeinput", {
        bubbles: true, cancelable: true, composed: true,
        data: character, inputType: "insertText",
      }));
      var descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
      if (descriptor && descriptor.set) descriptor.set.call(input, current);
      else input.value = current;
      input.dispatchEvent(new InputEvent("input", {
        bubbles: true, cancelable: true, composed: true,
        data: character, inputType: "insertText",
      }));
      input.dispatchEvent(new KeyboardEvent("keyup", {
        bubbles: true, cancelable: true, composed: true, key: character,
      }));
      await AF.Utils.sleep(85);
    }
    input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true, composed: true }));
    await AF.Utils.sleep(500);
    return true;
  }

  async function typeLiveProfessionalSearchValue(container, input, value) {
    var text = String(value == null ? "" : value);
    setInputValue(input, "");
    await AF.Utils.sleep(50);
    var current = "";
    for (var i = 0; i < text.length; i++) {
      current += text.charAt(i);
      // 华为专业控件会在输入过程中重建 input。每个字符前都重新取得当前活节点，
      // 否则后续字符会继续写进 detached 节点，页面上只留下“密码”之类的半截值。
      var liveInput = container && container.querySelector("input.aui-input__inner, input[type='text'], input:not([type])");
      if (liveInput && liveInput.isConnected) input = liveInput;
      if (!input || input.disabled || input.readOnly) return false;
      input.focus && input.focus();
      var descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
      if (descriptor && descriptor.set) descriptor.set.call(input, current);
      else input.value = current;
      input.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        cancelable: true,
        composed: true,
        data: text.charAt(i),
        inputType: "insertText",
      }));
      input.dispatchEvent(new KeyboardEvent("keyup", {
        bubbles: true,
        cancelable: true,
        composed: true,
        key: text.charAt(i),
      }));
      await AF.Utils.sleep(45);
    }
    input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true, composed: true }));
    await AF.Utils.sleep(300);
    return true;
  }

  function normalizeKeyword(value) {
    if (value === undefined || value === null) return "";
    if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
      return String(value).trim();
    }
    if (Array.isArray(value)) {
      return value.map(normalizeKeyword).filter(Boolean);
    }
    if (typeof value === "object") {
      var keys = [
        "name", "label", "text", "value", "title", "schoolName", "majorName", "degree",
        "country", "province", "city", "district", "location", "address",
      ];
      for (var i = 0; i < keys.length; i++) {
        if (value[keys[i]] !== undefined && value[keys[i]] !== null && String(value[keys[i]]).trim()) {
          return String(value[keys[i]]).trim();
        }
      }
    }
    return "";
  }

  function getInputValue(input) {
    return input ? String(input.value || input.getAttribute("value") || "").trim() : "";
  }

  function provinceFromCity(city) {
    var clean = String(city || "").replace(/\s/g, "").replace(/[省市区县]$/g, "");
    var municipalities = ["北京", "上海", "天津", "重庆"];
    for (var i = 0; i < municipalities.length; i++) {
      if (clean.indexOf(municipalities[i]) === 0) return municipalities[i];
    }
    var map = {
      杭州: "浙江", 宁波: "浙江", 温州: "浙江", 嘉兴: "浙江", 绍兴: "浙江", 金华: "浙江",
      南京: "江苏", 苏州: "江苏", 无锡: "江苏", 常州: "江苏", 南通: "江苏",
      广州: "广东", 深圳: "广东", 佛山: "广东", 东莞: "广东", 珠海: "广东",
      成都: "四川", 绵阳: "四川", 武汉: "湖北", 长沙: "湖南", 西安: "陕西",
      济南: "山东", 青岛: "山东", 郑州: "河南", 合肥: "安徽", 厦门: "福建", 福州: "福建",
    };
    for (var key in map) {
      if (Object.prototype.hasOwnProperty.call(map, key) && clean.indexOf(key) === 0) return map[key];
    }
    return "";
  }

  function buildCascadeValues(rawValue) {
    var values = [];
    if (Array.isArray(rawValue)) {
      values = rawValue.map(normalizeKeyword).filter(Boolean);
    } else if (rawValue && typeof rawValue === "object") {
      values = [rawValue.country, rawValue.province, rawValue.city, rawValue.district].map(normalizeKeyword).filter(Boolean);
      if (!values.length) values = [rawValue.location, rawValue.address, rawValue.name, rawValue.label].map(normalizeKeyword).filter(Boolean);
    } else {
      values = String(rawValue || "").split(/[\/,，>\-—\s]+/).map(function (x) { return x.trim(); }).filter(Boolean);
    }

    if (values.length === 1) {
      var only = values[0];
      var province = provinceFromCity(only);
      if (province) {
        var city = String(only).replace(/\s/g, "").replace(/市$/g, "");
        values = ["中国", province, city];
      } else {
        var compactLocation = String(only).replace(/\s/g, "");
        var provinceCity = compactLocation.match(/^(.+?(?:省|自治区))(.+?市)(?:.*)?$/);
        if (provinceCity) {
          values = [
            "中国",
            provinceCity[1].replace(/(?:省|壮族自治区|回族自治区|维吾尔自治区|自治区)$/g, ""),
            provinceCity[2].replace(/市$/g, ""),
          ];
        }
      }
      if (values.length === 1 && /中国|China|CHINA/i.test(only)) {
        values = ["中国"];
      }
    }
    return values;
  }

  function hasCommittedValue(container) {
    var input = container && container.querySelector("input.aui-input__inner, input[type='text'], input:not([type])");
    return !!getInputValue(input);
  }

  function isAuiOpen(container, trigger) {
    return (
      container.classList.contains("is-focus") ||
      container.classList.contains("is-open") ||
      container.getAttribute("aria-expanded") === "true" ||
      (trigger && trigger.getAttribute && trigger.getAttribute("aria-expanded") === "true")
    );
  }

  function normalizeOptionText(value) {
    return String(value == null ? "" : value).replace(/[\s：:()（）]/g, "").toLowerCase();
  }

  function normalizeAuiComparable(value) {
    var text = normalizeOptionText(value);
    // 华为页面使用“中国大陆”，简历常保存为“中国”。二者在国家/地区
    // 下拉里是同一语义，不能因为字面不完全一致而跳过。
    if (/^(中国|中华人民共和国|中国大陆)$/.test(text)) return "中国大陆";
    if (/^(身份证|居民身份证|中华人民共和国居民身份证|中国居民身份证)$/.test(text)) return "中国居民身份证";
    var rank = text.match(/^(?:前|top)(\d+)%$/);
    if (rank) return "top" + rank[1] + "%";
    return text;
  }

  function getAuiOptionSignature(panel) {
    if (!panel) return "";
    return H.getOptionNodes(panel, CFG.dropdown).map(function (node) {
      return normalizeOptionText(node.textContent);
    }).filter(Boolean).join("|");
  }

  function getAuiFieldLabel(element) {
    try {
      var item = element && element.closest && element.closest(".aui-form-item");
      var label = item && item.querySelector(".aui-form-item__label, label");
      return String(label && label.textContent || "").replace(/\s+/g, "").trim();
    } catch (e) {
      return "";
    }
  }

  function buildAuiSearchCandidates(rawValue, fieldLabel) {
    var values = [];
    var append = function (value) {
      var text = normalizeKeyword(value);
      if (Array.isArray(text)) {
        text.forEach(append);
        return;
      }
      text = String(text || "").trim();
      if (text && values.indexOf(text) === -1) values.push(text);
    };
    append(rawValue);
    if (/专业/.test(fieldLabel) && rawValue && typeof rawValue === "object") {
      var dialogChoice = rawValue.dialogChoice || {};
      (dialogChoice.alternatives || []).forEach(append);
    }
    return values;
  }

  async function clickAndVerifyAuiOption(container, panel, optionNode, value, capability) {
    if (!optionNode) return false;
    var targets = [];
    var wrapper = optionNode.matches && optionNode.matches(".aui-select-dropdown__item-wrapper")
      ? optionNode
      : optionNode.querySelector && optionNode.querySelector(".aui-select-dropdown__item-wrapper");
    if (wrapper) targets.push(wrapper);
    if (optionNode && targets.indexOf(optionNode) === -1) targets.push(optionNode);

    for (var i = 0; i < targets.length; i++) {
      await H.clickOption(targets[i]);
      if (capability && capability.verifyAfterSelect === false) return true;
      await AF.Utils.sleep(350);
      var currentInput = container && container.querySelector("input.aui-input__inner, input[type='text'], input:not([type])");
      var current = getInputValue(currentInput);
      var expected = normalizeOptionText(value);
      var actual = normalizeOptionText(current);
      var panelStillVisible = panel && H.findVisibleDropdownNear(currentInput || container, CFG.panelSelectors, CFG.container) === panel;
      if ((actual && (actual === expected || actual.indexOf(expected) !== -1 || expected.indexOf(actual) !== -1)) || !panelStillVisible) {
        return true;
      }
    }
    return false;
  }

  async function selectStrictAuiOption(container, panel, value, allowFirstFilteredOption, fieldLabel, capability) {
    var nodes = H.getOptionNodes(panel, CFG.dropdown);
    if (!nodes.length) return false;
    var target = normalizeAuiComparable(value);
    if (!target) return false;
    var cleanFieldLabel = String(fieldLabel || "").replace(/\s+/g, "");
    var strictRemoteSearch = /^(毕业院校|学校名称|学校|院校名称|专业|专业名称)$/.test(cleanFieldLabel);
    var strictSensitiveEnum = /证件签发国家|国家\/地区|毕业院校所在国家|^证件$|证件类型|^学制$/.test(cleanFieldLabel);
    var matchMode = capability && String(capability.matchMode || "");

    var exact = nodes.find(function (node) {
      return normalizeAuiComparable(node.textContent) === target;
    });
    if (exact) return await clickAndVerifyAuiOption(container, panel, exact, value, capability);
    if (matchMode === "exact") {
      return allowFirstFilteredOption && nodes.length
        ? await clickAndVerifyAuiOption(container, panel, nodes[0], value, capability)
        : false;
    }

    // 学校、专业名称不能使用全局相似度算法。“上海交通大学”与
    // “北京交通大学”文字很像，但绝不是同一所学校。
    if (!strictRemoteSearch && !strictSensitiveEnum) {
      var semantic = nodes.find(function (node) {
        var text = String(node.textContent || "").trim();
        var code = node.getAttribute("data-value") || node.getAttribute("value") || node.getAttribute("code") || text;
        return H.isOptionMatch(text, code, value);
      });
      if (semantic) return await clickAndVerifyAuiOption(container, panel, semantic, value, capability);
    }

    var contained = nodes.find(function (node) {
      var text = normalizeAuiComparable(node.textContent);
      return text && (text.indexOf(target) !== -1 || target.indexOf(text) !== -1);
    });
    if (contained) return await clickAndVerifyAuiOption(container, panel, contained, value, capability);
    if (matchMode === "exactOrContains") {
      return allowFirstFilteredOption && nodes.length
        ? await clickAndVerifyAuiOption(container, panel, nodes[0], value, capability)
        : false;
    }

    // 学校是搜索候选控件，网站自身过滤后允许选择第一条近似结果。
    // 专业只接受名称或备用专业分类的明确命中，不能盲选第一条。
    // 民族、学历、学制等枚举控件没有精确/规则命中时必须留空，不能智能猜测。
    if (allowFirstFilteredOption && nodes.length) return await clickAndVerifyAuiOption(container, panel, nodes[0], value, capability);
    return false;
  }

  async function waitForAuiOptions(container, element, value, allowFirstFilteredOption, timeoutMs, initialOptionSignature, fieldLabel, capability) {
    var startedAt = Date.now();
    var timeoutAt = startedAt + (timeoutMs || 5000);
    while (Date.now() < timeoutAt) {
      // 输入后 Vue 可能替换 input 节点。每轮都从当前容器重新获取活节点，
      // 不能继续使用输入前保存的 detached element 来做几何邻近判断。
      var liveInput = container && container.querySelector("input.aui-input__inner, input[type='text'], input:not([type])");
      var reference = liveInput && liveInput.isConnected ? liveInput : element;
      var panel = H.findVisibleDropdownNear(reference, CFG.panelSelectors, CFG.container);
      if (panel) {
        var nodes = H.getOptionNodes(panel, CFG.dropdown);
        if (nodes.length) {
          // 搜索输入后弹层会短暂保留旧候选。一次没命中不能立即返回失败，
          // 必须继续等接口把“软件工程”等真实结果刷新出来。
          // 学校/专业的近似第一项兜底必须确认列表已经因搜索发生刷新，
          // 不能选择弹层刚打开时残留的默认第一项。
          var currentSignature = getAuiOptionSignature(panel);
          var requireChanged = !capability || capability.waitForOptionsChanged !== false;
          var listRefreshed = !requireChanged || !initialOptionSignature || currentSignature !== initialOptionSignature;
          var allowFirstNow = allowFirstFilteredOption && listRefreshed && Date.now() - startedAt >= 1200;
          var selected = await selectStrictAuiOption(container, panel, value, allowFirstNow, fieldLabel, capability);
          if (selected) return true;
        }
      }
      await AF.Utils.sleep(100);
    }
    return false;
  }

  async function selectOneAuiValue(element, container, trigger, value, allowFirstFilteredOption, searchTimeoutMs, useLiveProfessionalTyping, fieldLabel, useHuaweiSchoolTyping, capability) {
    value = normalizeKeyword(value);
    if (!value) return false;
    // 华为 AUI 弹层打开后不会设置 is-open / aria-expanded。必须先按真实可见
    // 弹层判断；若继续依赖状态 class，会误点第二次并把已经打开的弹层关掉。
    var panel = H.findVisibleDropdownNear(element, CFG.panelSelectors, CFG.container);
    if (!panel) {
      await AF.DomUtils.safeClickElement(trigger || container);
      panel = await H.waitForVisibleDropdownNear(element, CFG.panelSelectors, CFG.container, 1800);
    }
    if (!panel) return false;
    var initialOptionSignature = getAuiOptionSignature(panel);

    // 学校、专业以及华为其他 filterable 下拉初始 input 是 readonly；点击后
    // Vue 才把同一个输入框切换成可编辑状态。必须在点击后重新查询 input，
    // 再模拟真人输入，不能沿用点击前得到的 readonly 引用和判断结果。
    var liveInput = container.querySelector("input.aui-input__inner, input[type='text'], input:not([type])");
    if (liveInput && !liveInput.disabled && !liveInput.readOnly) {
      liveInput.focus && liveInput.focus();
      var typed = useLiveProfessionalTyping
        ? await typeLiveProfessionalSearchValue(container, liveInput, value)
        : useHuaweiSchoolTyping
          ? await typeHuaweiSchoolSearchValue(liveInput, value)
          : await typeStableSearchValue(liveInput, value);
      if (!typed) return false;
      return await waitForAuiOptions(container, liveInput, value, allowFirstFilteredOption, searchTimeoutMs || 5000, initialOptionSignature, fieldLabel, capability);
    }
    return await selectStrictAuiOption(container, panel, value, allowFirstFilteredOption, fieldLabel, capability);
  }

  async function commitTypedAuiValue(input, value) {
    if (!input || !value) return false;
    setInputValue(input, value);
    await AF.Utils.sleep(120);
    input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: "Enter", code: "Enter", keyCode: 13, which: 13 }));
    input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, key: "Enter", code: "Enter", keyCode: 13, which: 13 }));
    input.dispatchEvent(new Event("blur", { bubbles: true }));
    await AF.Utils.sleep(260);
    var current = getInputValue(input);
    return !!current && (current === value || current.indexOf(value) !== -1 || value.indexOf(current) !== -1);
  }

  async function fillAuiCascade(element, rawValue) {
    var root = element && element.closest && element.closest(".countryProvinceCity-select");
    if (!root) return false;
    var selects = Array.prototype.slice.call(root.querySelectorAll(".aui-select"));
    if (selects.length < 2) return false;

    var values = buildCascadeValues(rawValue);
    if (!values.length) return false;

    var ok = false;
    var cascadeFieldLabel = getAuiFieldLabel(element);
    for (var i = 0; i < selects.length && i < values.length; i++) {
      var existing = hasCommittedValue(selects[i]);
      if (existing && i > 0 && getInputValue(selects[i].querySelector("input.aui-input__inner, input[type='text'], input:not([type])")).indexOf(values[i]) !== -1) continue;
      var trigger = selects[i].querySelector(CFG.trigger) || selects[i];
      var input = selects[i].querySelector("input.aui-input__inner, input[type='text'], input:not([type])");
      var one = await selectOneAuiValue(selects[i], selects[i], trigger, values[i], false, 5000, false, cascadeFieldLabel, false);
      if (!one && input && !input.disabled && !input.readOnly) {
        one = await commitTypedAuiValue(input, values[i]);
      }
      if (one) ok = true;
      await AF.Utils.sleep(250);
    }
    return ok;
  }

  async function triggerAuiSelect(element, value, capability) {
    try {
      if (!element || value === undefined || value === null || value === "") return false;
      var cascadeOk = await fillAuiCascade(element, value);
      if (cascadeOk) return true;

      var container = (element.closest && element.closest(CFG.container)) || element;
      var trigger = container.querySelector(CFG.trigger) || container;
      var input = container.querySelector("input.aui-input__inner, input[type='text'], input:not([type])");
      var normalizedValue = normalizeKeyword(value);
      var fieldLabel = getAuiFieldLabel(element);
      if (/籍贯/.test(fieldLabel) && typeof normalizedValue === "string") {
        normalizedValue = normalizedValue.split(/\s*(?:\/|>|＞|\||,|，)\s*/)[0] || normalizedValue;
      }
      var firstValue = Array.isArray(normalizedValue) ? normalizedValue[0] : normalizedValue;
      // 院校名称只接受精确或包含关系，避免把上海交通大学选成北京交通大学；
      // 只有专业允许在搜索结果确实刷新后选择第一条近似值。
      var allowFirstFilteredOption = capability
        ? capability.fallback === "firstFilteredOption"
        : /专业/.test(fieldLabel);
      // 华为专业库的远程检索明显慢于普通枚举项。专业必须等待准确候选返回，
      // 不能因默认列表先出现便提前失败，更不能用第一项兜底造成“国际事务”等误填。
      var configuredTimeout = capability && Number(capability.waitForOptionsMs);
      var searchTimeoutMs = configuredTimeout > 0
        ? configuredTimeout
        : (/专业/.test(fieldLabel) ? 12000 : (/学校|院校/.test(fieldLabel) ? 8000 : 5000));
      var inputMode = capability && String(capability.inputMode || "");
      var useLiveProfessionalTyping = inputMode
        ? inputMode === "liveNodeKeyboard"
        : /专业/.test(fieldLabel);
      var useHuaweiSchoolTyping = inputMode
        ? inputMode === "keyboardEvents"
        : /^(毕业院校|学校名称|学校|院校名称)$/.test(fieldLabel);
      var searchCandidates = buildAuiSearchCandidates(value, fieldLabel);

      var ok;
      if (Array.isArray(normalizedValue)) {
        ok = false;
        for (var i = 0; i < normalizedValue.length; i++) {
          if (i > 0 && input && !input.disabled && !input.readOnly) {
            if (useLiveProfessionalTyping) await typeLiveProfessionalSearchValue(container, input, normalizedValue[i]);
            else await typeStableSearchValue(input, normalizedValue[i]);
          }
          var one = await selectOneAuiValue(element, container, trigger, normalizedValue[i], allowFirstFilteredOption, searchTimeoutMs, useLiveProfessionalTyping, fieldLabel, useHuaweiSchoolTyping, capability);
          if (one) ok = true;
          await AF.Utils.sleep(150);
        }
      } else {
        ok = false;
        for (var candidateIndex = 0; candidateIndex < searchCandidates.length; candidateIndex++) {
          ok = await selectOneAuiValue(
            element,
            container,
            trigger,
            searchCandidates[candidateIndex],
            allowFirstFilteredOption,
            searchTimeoutMs,
            useLiveProfessionalTyping,
            fieldLabel,
            useHuaweiSchoolTyping,
            capability
          );
          if (ok) break;
          await AF.Utils.sleep(120);
        }
        if (!ok && input && !input.disabled && !input.readOnly && typeof normalizedValue === "string") {
          ok = await commitTypedAuiValue(input, normalizedValue);
        }
      }

      H.dispatchChangeEvents(element);
      if (input) H.dispatchChangeEvents(input);
      return ok;
    } catch (e) {
      return false;
    }
  }

  SA._registry["aui"] = function (element, valueType, sectionEl, capability) {
    return {
      selectValue: async function (value) {
        return await triggerAuiSelect(element, value, capability || null);
      },
    };
  };
})();
