// Electron MAIN-world bridge for React-controlled plain text fields.
(function () {
  "use strict";

  var BRIDGE_VERSION = "2";
  var root = document.documentElement;
  if (!root) return;
  if (root.getAttribute("data-af-controlled-text-main-bridge") === BRIDGE_VERSION) return;
  root.setAttribute("data-af-controlled-text-main-bridge", BRIDGE_VERSION);

  function findTarget(token) {
    return Array.from(document.querySelectorAll("input[data-af-controlled-text-token], textarea[data-af-controlled-text-token]"))
      .find(function (node) {
        return node.getAttribute("data-af-controlled-text-token") === token;
      }) || null;
  }

  window.addEventListener("message", function (event) {
    var data = event && event.data;
    if (event.source !== window || !data || data.type !== "AF_CONTROLLED_TEXT_REQUEST_V2") return;
    var token = String(data.token || "");
    var element = token && findTarget(token);
    if (!element || !(element.closest && element.closest('[class*="phoenix" i]'))) return;

    var value = String(data.value == null ? "" : data.value);
    var previousValue = String(element.value || "");
    try {
      element.focus();
      if (typeof element.select === "function") element.select();
      var insertedByCommand = false;
      try {
        insertedByCommand = !!(document.execCommand && document.execCommand("insertText", false, value));
      } catch (commandError) {}

      var prototype = element.tagName === "TEXTAREA"
        ? window.HTMLTextAreaElement.prototype
        : window.HTMLInputElement.prototype;
      var descriptor = Object.getOwnPropertyDescriptor(prototype, "value");

      // Electron 隔离世界里的 execCommand 不能稳定触发页面框架；这里在页面
      // MAIN world 重放与 Chrome 插件相同的编辑命令。命令成功只说明 DOM 已变化，
      // 不代表 React state 已收到，因此下面始终恢复 tracker 并补发 input。
      if (!insertedByCommand || String(element.value || "") !== value) {
        element.dispatchEvent(new InputEvent("beforeinput", {
          bubbles: true,
          cancelable: true,
          composed: true,
          data: value,
          inputType: "insertText"
        }));
        if (descriptor && descriptor.set) descriptor.set.call(element, value);
        else element.value = value;
      }
      if (element._valueTracker && typeof element._valueTracker.setValue === "function") {
        element._valueTracker.setValue(previousValue);
      }
      element.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        cancelable: true,
        composed: true,
        data: value,
        inputType: "insertText"
      }));
      setTimeout(function () {
        element.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
        element.blur();
        window.postMessage({
          type: "AF_CONTROLLED_TEXT_RESPONSE_V2",
          token: token,
          success: String(element.value || "") === value
        }, "*");
      }, 180);
    } catch (error) {
      window.postMessage({
        type: "AF_CONTROLLED_TEXT_RESPONSE_V2",
        token: token,
        success: false,
        error: error && error.message || String(error)
      }, "*");
    }
  });
})();
