"use strict";

function norm(value) {
  return String(value == null ? "" : value)
    .replace(/[\s：:*?？（）()【】\[\]「」'"“”‘’.,，。;；、]/g, "")
    .toLowerCase();
}

function clampConfidence(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(1, n));
}

function classifyLocalFirstRoute(input) {
  const data = input || {};
  const reasons = [];
  if (data.matchedWorkflowId) reasons.push("special_workflow");
  if (data.localConfigFound) reasons.push("local_config");
  if (data.builtInConfigFound) reasons.push("built_in_config");
  const platformCapabilityAvailable = !!data.domPlatformDetected;
  return {
    strongLocalSupport: reasons.length > 0,
    platformCapabilityAvailable,
    route: reasons.length ? "local_first" : "ai_preflight_allowed",
    reasons
  };
}

function fieldById(review) {
  const map = new Map();
  for (const field of Array.isArray(review && review.reviewFields) ? review.reviewFields : []) {
    const id = String(field && field.fieldId || "");
    if (id) map.set(id, field);
  }
  return map;
}

const ARRAY_CATEGORIES = new Set([
  "education",
  "workExperience",
  "internshipExperience",
  "projectExperience",
  "trainingExperience",
  "awards",
  "languageSkills",
  "certificates",
  "campusLeadership",
  "campusActivities",
  "familyMembers",
  "publications",
  "patents"
]);

const COMPOSITE_ADDRESS_KEYS = new Set([
  "nativePlace",
  "birthOrigin",
  "hukouLocation",
  "archiveLocation",
  "currentAddress",
  "currentResidence",
  "currentAddressDetail",
  "familyLocation",
  "schoolLocation",
  "expectedLocation"
]);

function hasTransientSelector(selector) {
  return /(?:^|[.:[\s>+~])(is-checked|is-active|selected|current|focus|focused|hover|active)(?:$|[.:[\s>+~])|:checked\b|\[aria-selected=["']?true["']?\]/i.test(String(selector || ""));
}

function stableSelectorForField(field) {
  const controlType = String(field && field.controlType || "").toLowerCase();
  const candidates = Array.isArray(field && field.selectorCandidates) ? field.selectorCandidates : [];

  // Radio/checkbox groups should be addressed by stable name rather than by one
  // option's nth-of-type path. FormHandler can then resolve the whole group.
  if (/radio|checkbox/.test(controlType)) {
    const byName = candidates.find((item) => item && item.kind === "name" && item.selector && Number(item.hitCount || 0) >= 1 && !hasTransientSelector(item.selector));
    if (byName) return { selector: String(byName.selector), mode: "group", hitCount: Number(byName.hitCount || 0) };
  }

  const preferred = candidates.find((item) => item && ["id", "name", "placeholder"].includes(String(item.kind || "")) && item.selector && Number(item.hitCount || 0) === 1 && !hasTransientSelector(item.selector));
  if (preferred) return { selector: String(preferred.selector), mode: "unique", hitCount: 1 };

  const target = field && field.patchTarget && typeof field.patchTarget === "object" ? field.patchTarget : {};
  if (String(target.kind || "") === "unique_selector" && target.selector && Number(field.selectorHitCount || 0) === 1 && !hasTransientSelector(target.selector)) {
    // Avoid brittle ancestry-only selectors when no stable id/name/placeholder exists.
    if (!/:nth-(?:child|of-type)\(/i.test(String(target.selector))) {
      return { selector: String(target.selector), mode: "unique", hitCount: 1 };
    }
  }
  return null;
}


function compileRepeatRecordSelectorMetadata(review, gateResult, options) {
  const opts = Object.assign({ minConfidence: 0.65 }, options || {});
  const reviewMap = fieldById(review);
  const accepted = [];
  const skipped = [];
  const candidates = Array.isArray(gateResult && gateResult.reviewOnlyCandidates)
    ? gateResult.reviewOnlyCandidates : [];

  for (const candidate of candidates) {
    const fieldId = String(candidate && candidate.fieldId || "");
    const category = String(candidate && candidate.category || "").trim();
    const fieldKey = String(candidate && candidate.fieldKey || "").trim();
    const confidence = clampConfidence(candidate && candidate.confidence);
    const reasons = Array.isArray(candidate && candidate.reasons) ? candidate.reasons.map(String) : [];
    if (!fieldId || !category || !fieldKey || !ARRAY_CATEGORIES.has(category)) continue;
    if (!reasons.includes("repeat_record_requires_recordgraph_ownership")) {
      skipped.push({ fieldId, reason: "repeat_record_ownership_gate_missing" });
      continue;
    }
    if (confidence < Number(opts.minConfidence || 0.65)) {
      skipped.push({ fieldId, reason: "low_confidence", confidence });
      continue;
    }
    const field = reviewMap.get(fieldId);
    if (!field) {
      skipped.push({ fieldId, reason: "unknown_field_id" });
      continue;
    }
    const stable = stableSelectorForField(field);
    if (!stable) {
      skipped.push({ fieldId, reason: "repeat_record_selector_not_stable" });
      continue;
    }
    const controlType = String(field && field.controlType || "").toLowerCase();
    if (!/^(text|textarea|native-select|radio|checkbox|select|search|date)$/.test(controlType)) {
      skipped.push({ fieldId, reason: "repeat_record_control_unsupported", controlType });
      continue;
    }
    accepted.push({
      fieldId,
      category,
      fieldKey,
      selector: stable.selector,
      selectorMode: stable.mode,
      controlType,
      confidence,
      source: "local_structure_repeat_semantic"
    });
  }

  const selectorGroups = new Map();
  for (const item of accepted) {
    const key = String(item.selector || "");
    if (!selectorGroups.has(key)) selectorGroups.set(key, []);
    selectorGroups.get(key).push(item);
  }
  const recordSelectorMappings = [];
  for (const items of selectorGroups.values()) {
    const distinct = Array.from(new Set(items.map((item) => `${item.category}.${item.fieldKey}`)));
    if (distinct.length !== 1) {
      for (const item of items) skipped.push({ fieldId: item.fieldId, reason: "repeat_record_selector_conflict", selector: item.selector });
      continue;
    }
    recordSelectorMappings.push(items.slice().sort((a, b) => b.confidence - a.confidence)[0]);
  }

  return {
    recordSelectorMappings,
    skipped,
    summary: {
      acceptedRecordSelectorMappings: recordSelectorMappings.length,
      skippedRecordSelectorMappings: skipped.length
    },
    safety: {
      directExecutionAllowed: false,
      recordGraphOwnershipRequired: true,
      selectorsAuthoredByAi: false,
      profileValuesIncluded: false
    }
  };
}

function compileRuntimeSemanticOverlay(review, patch, options) {
  const opts = Object.assign({ minConfidence: 0.8 }, options || {});
  const reviewMap = fieldById(review);
  const acceptedRaw = [];
  const selectorMappings = [];
  const skipped = [];

  for (const decision of Array.isArray(patch && patch.decisions) ? patch.decisions : []) {
    const id = String(decision && decision.fieldId || "");
    const field = reviewMap.get(id);
    if (!field) {
      skipped.push({ fieldId: id, reason: "unknown_field_id" });
      continue;
    }
    if (String(decision.decision || "") !== "map") {
      skipped.push({ fieldId: id, reason: String(decision.decision || "leave_unmapped") });
      continue;
    }
    const confidence = clampConfidence(decision.confidence);
    if (confidence < Number(opts.minConfidence || 0.50)) {
      skipped.push({ fieldId: id, reason: "low_confidence", confidence });
      continue;
    }
    const target = field.patchTarget && typeof field.patchTarget === "object" ? field.patchTarget : {};
    const category = String(decision.category || "").trim();
    const fieldKey = String(decision.fieldKey || "").trim();
    if (!category || !fieldKey) {
      skipped.push({ fieldId: id, reason: "empty_mapping" });
      continue;
    }

    const label = String(target.label || field.label || "").trim();

    // AI intentionally does not receive profile values. Generic language-record
    // mappings such as “小语种” -> languageSkills.name can therefore select the
    // user's unrelated English record. Dedicated scalar language keys remain safe.
    if (
      category === "languageSkills" &&
      /小语种|方言/.test(label) &&
      ["name", "description", "level", "proficiency", "score"].includes(fieldKey)
    ) {
      skipped.push({ fieldId: id, reason: "record_subtype_not_proven", label, category, fieldKey });
      continue;
    }

    // Plain personal identifiers are normally text fields. A select-widget guess
    // must not be promoted into phone/email/id value mapping without an explicit label.
    if (
      /select|cascader/.test(String(field.controlType || "").toLowerCase()) &&
      ["phone", "email", "idNumber", "qq", "wechat", "homepage"].includes(fieldKey) &&
      !norm(label).includes(norm(fieldKey)) &&
      !/(手机|电话|邮箱|证件|qq|微信|主页|网址|链接)/i.test(label)
    ) {
      skipped.push({ fieldId: id, reason: "control_type_semantic_conflict", label, category, fieldKey });
      continue;
    }

    if (String(target.kind || "") === "semantic_label") {
      if (!label) {
        skipped.push({ fieldId: id, reason: "empty_label" });
        continue;
      }
      acceptedRaw.push({
        fieldId: id,
        category,
        fieldKey,
        label,
        confidence,
        source: "ai_semantic_patch"
      });
      continue;
    }

    // Selector-level execution is intentionally limited to scalar profile buckets.
    // Repeat records still require a record identity/scope transaction and therefore
    // remain on the existing repeat workflow path.
    if (String(target.kind || "") === "unique_selector") {
      if (ARRAY_CATEGORIES.has(category)) {
        skipped.push({ fieldId: id, reason: "selector_runtime_array_unsupported", category, fieldKey });
        continue;
      }
      const controlType = String(field.controlType || "").toLowerCase();
      if (!/^(text|textarea|native-select|radio|checkbox|select|search|date)$/.test(controlType)) {
        skipped.push({ fieldId: id, reason: "selector_runtime_control_unsupported", controlType });
        continue;
      }
      if (COMPOSITE_ADDRESS_KEYS.has(fieldKey) && /select|search|cascader/.test(controlType)) {
        skipped.push({ fieldId: id, reason: "composite_address_control_requires_adapter", category, fieldKey, controlType });
        continue;
      }
      const stable = stableSelectorForField(field);
      if (!stable) {
        skipped.push({ fieldId: id, reason: "unstable_selector_target", targetKind: String(target.kind || "") });
        continue;
      }
      selectorMappings.push({
        fieldId: id,
        category,
        fieldKey,
        selector: stable.selector,
        selectorMode: stable.mode,
        controlType,
        confidence,
        source: "ai_semantic_patch"
      });
      continue;
    }

    skipped.push({ fieldId: id, reason: "unsupported_patch_target", targetKind: String(target.kind || "") });
  }

  // Conflicting label mappings for the same category+label are unsafe. Keep neither.
  const grouped = new Map();
  for (const item of acceptedRaw) {
    const key = `${item.category}::${norm(item.label)}`;
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key).push(item);
  }
  const fieldMappings = [];
  for (const items of grouped.values()) {
    const distinctKeys = Array.from(new Set(items.map((item) => item.fieldKey)));
    if (distinctKeys.length !== 1) {
      for (const item of items) skipped.push({ fieldId: item.fieldId, reason: "conflicting_label_mapping", label: item.label, category: item.category });
      continue;
    }
    const best = items.slice().sort((a, b) => b.confidence - a.confidence)[0];
    fieldMappings.push(best);
    for (const duplicate of items.slice(1)) skipped.push({ fieldId: duplicate.fieldId, reason: "duplicate_same_mapping", label: duplicate.label, category: duplicate.category, fieldKey: duplicate.fieldKey });
  }

  // A selector may only drive one semantic field in one candidate overlay.
  const selectorGroups = new Map();
  for (const item of selectorMappings) {
    const key = String(item.selector || "");
    if (!selectorGroups.has(key)) selectorGroups.set(key, []);
    selectorGroups.get(key).push(item);
  }
  const safeSelectorMappings = [];
  for (const items of selectorGroups.values()) {
    const distinct = Array.from(new Set(items.map((item) => `${item.category}.${item.fieldKey}`)));
    if (distinct.length !== 1) {
      for (const item of items) skipped.push({ fieldId: item.fieldId, reason: "conflicting_selector_mapping", selector: item.selector });
      continue;
    }
    safeSelectorMappings.push(items.slice().sort((a, b) => b.confidence - a.confidence)[0]);
    for (const duplicate of items.slice(1)) skipped.push({ fieldId: duplicate.fieldId, reason: "duplicate_same_selector_mapping", selector: duplicate.selector });
  }

  const page = review && review.page || patch && patch.page || {};
  return {
    schemaType: "autofill-lite-runtime-semantic-overlay",
    schemaVersion: 2,
    page: {
      hostname: String(page.hostname || ""),
      pathname: String(page.pathname || "/") || "/"
    },
    minConfidence: Number(opts.minConfidence || 0.50),
    observedFieldCount: Array.isArray(review && review.reviewFields) ? review.reviewFields.length : 0,
    fieldMappings,
    selectorMappings: safeSelectorMappings,
    skipped,
    summary: {
      acceptedMappings: fieldMappings.length + safeSelectorMappings.length,
      acceptedLabelMappings: fieldMappings.length,
      acceptedSelectorMappings: safeSelectorMappings.length,
      skippedDecisions: skipped.length,
      sourceMappedDecisions: Array.isArray(patch && patch.decisions)
        ? patch.decisions.filter((d) => d && d.decision === "map").length
        : 0
    },
    safety: {
      labelMappingsOnly: safeSelectorMappings.length === 0,
      selectorMappingsPrepared: safeSelectorMappings.length > 0,
      profileValuesIncluded: false,
      pageActionsExecuted: false,
      repeatRecordSelectorsApplied: false
    }
  };
}

module.exports = {
  classifyLocalFirstRoute,
  compileRuntimeSemanticOverlay,
  compileRepeatRecordSelectorMetadata
};
