// content/date-picker/index.js — 日期选择器工厂
// 源码参考: webcrack-output/content/deobfuscated.js Kn.create/detectType 行45979-46193
// 这里恢复工厂入口 AF.DatePicker.create()，让 FormHandler.handleDate 能按检测类型分发。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  function classListSome(el, predicate) {
    try {
      return !!el.classList && Array.from(el.classList).some(predicate);
    } catch (e) {
      return false;
    }
  }

  function safeClosest(el, selector) {
    try {
      return el && el.closest && el.closest(selector);
    } catch (e) {
      return null;
    }
  }

  function safeQuery(el, selector) {
    try {
      return el && el.querySelector && el.querySelector(selector);
    } catch (e) {
      return null;
    }
  }

  function hasSplitYearMonthInputs(el) {
    try {
      var cur = el;
      for (var depth = 0; cur && depth < 8; depth++) {
        if (cur.querySelectorAll) {
          var inputs = Array.from(cur.querySelectorAll("input")).filter(function (input) {
            var hint = String([input.placeholder, input.name, input.id, input.getAttribute("aria-label")].filter(Boolean).join(" "));
            return (!AF.DomUtils || AF.DomUtils.isElementVisible(input)) && /(年|月|year|month)/i.test(hint);
          });
          if (inputs.length >= 2 && inputs.length <= 6) return true;
        }
        cur = cur.parentElement;
      }
    } catch (e) {}
    return false;
  }

  function getDatePickerType(el, depth) {
    depth = depth || 0;
    if (!el || depth > 2) return null;
    var prefixes = ["ant", "atsx", "kuma", "mtd", "sd", "el"];
    for (var i = 0; i < prefixes.length; i++) {
      var p = prefixes[i];
      if (
        classListSome(el, function (c) { return c.indexOf(p + "-date") === 0 || c.indexOf(p + "-picker") === 0 || c.indexOf(p + "-calendar") === 0; }) ||
        safeClosest(el, '[class*="' + p + '-date"], [class*="' + p + '-picker"], [class*="' + p + '-calendar"]') ||
        safeQuery(el, '[class*="' + p + '-date"], [class*="' + p + '-picker"], [class*="' + p + '-calendar"]')
      ) {
        return p === "el" ? "el" : p;
      }
    }
    return el.parentNode ? getDatePickerType(el.parentNode, depth + 1) : null;
  }

  // 源码深层前缀扫描用的 13 种框架类型 (deobfuscated.js 行46050 数组 u)
  var FRAMEWORK_TYPES = ["ant", "atsx", "kuma", "mtd", "sd", "el", "brick", "layui", "ud", "phoenix", "selSelect", "wdate", "ivu"];

  // 在一个 classList 里找出第一个"以某框架类型开头"的 class，返回该类型 (源码 u.find(startsWith))
  function matchFrame示例资料Prefix(classList) {
    if (!classList) return null;
    for (var i = 0; i < classList.length; i++) {
      var c = classList[i];
      for (var j = 0; j < FRAMEWORK_TYPES.length; j++) {
        if (c.indexOf(FRAMEWORK_TYPES[j]) === 0) return FRAMEWORK_TYPES[j];
      }
    }
    return null;
  }

  function detectType(element, depth) {
    depth = depth || 0;
    // 源码行46052: c>1 || e==null || !e.classList 时返回 null (即只处理 depth 0/1)
    if (!element || !element.classList || depth > 1) return null;
    var tag = element.tagName ? element.tagName.toLowerCase() : "";
    var cls = element.classList || { contains: function () { return false; } };

    if (
      safeClosest(element, ".throne-biz-date-range-picker-wrapper") ||
      safeQuery(element, ".throne-biz-date-range-picker-wrapper")
    ) {
      return "throneRange";
    }
    if (
      safeClosest(element, ".next-range-picker, .next-date-picker, .next-month-picker") ||
      safeQuery(element, ".next-range-picker, .next-date-picker, .next-month-picker")
    ) {
      return "native-date";
    }
    if (tag === "input" && (element.type === "date" || element.type === "month")) return "native-date";
    if (
      (element.getAttribute && element.getAttribute("data-tag") === "we-datepicker") ||
      safeClosest(element, '[data-tag="we-datepicker"], .picker[data-tag="we-datepicker"], .aui-date-picker, .aui-picker') ||
      safeQuery(element, '[data-tag="we-datepicker"], .picker[data-tag="we-datepicker"], .aui-date-picker, .aui-picker')
    ) {
      return "aui";
    }
    if (
      safeClosest(element, ".start-time-module, .end-time, .resume-module-left, .resume-module-right") &&
      (
        safeClosest(element, ".select-wrapper") ||
        safeQuery(element, ".required-year, .required-month, .small-select-ul, .splicing-select-ul")
      )
    ) {
      return "splitYearMonth";
    }
    if (hasSplitYearMonthInputs(element)) return "splitYearMonth";
    if (
      cls.contains("bitable-reminder-date-picker-input") ||
      safeClosest(element, ".bitable-date-time-editor, .bitable-reminder-date-picker") ||
      safeQuery(element, ".bitable-reminder-date-picker-input")
    ) {
      return "ud";
    }
    if (window.location.href.indexOf("51job.com") !== -1 && tag === "input") return "51job";

    var frame示例资料Type = getDatePickerType(element);
    if (frame示例资料Type) return frame示例资料Type;

    // selSelect (源码行46074): 自身含 sel_date_year/month，或最近的 <li> 内有这两个 class
    var selLi = safeClosest(element, "li");
    if (
      cls.contains("sel_date_year") ||
      cls.contains("sel_date_month") ||
      (selLi && selLi.querySelector(".sel_date_year")) ||
      (selLi && selLi.querySelector(".sel_date_month"))
    ) {
      return "selSelect";
    }
    // wdate (源码行46077): .Wdate class / onclick|onfocus 含 WdatePicker / 悬浮 iframe 面板
    if (
      cls.contains("Wdate") ||
      (element.getAttribute && /WdatePicker/.test(element.getAttribute("onclick") || "")) ||
      (element.getAttribute && /WdatePicker/.test(element.getAttribute("onfocus") || "")) ||
      document.querySelector('body > div[style*="position: absolute"][style*="z-index"] iframe')
    ) {
      return "wdate";
    }
    if (
      safeClosest(element, ".month-range-select.date_info, .monthRange-select.date_info, .month-range-select, .date_info") ||
      safeQuery(element, ".month-range-select.date_info, .monthRange-select.date_info, .month-range-select, .date_info")
    ) {
      return "sd";
    }
    if (
      cls.contains("ant-calendar-picker-input") ||
      cls.contains("ant-calendar-range-picker-input") ||
      safeClosest(element, ".ant-calendar-picker-input, .ant-calendar-range-picker-input, .ant-calendar-picker, .ant-picker-input, .ant-picker-range") ||
      safeQuery(element, ".ant-calendar-picker-input, .ant-calendar-range-picker-input, .ant-calendar-picker, .ant-picker-input, .ant-picker-range")
    ) {
      return "ant";
    }
    if (safeClosest(element, ".brick-date-picker, .brick-date-picker-trigger") || safeQuery(element, ".brick-date-picker, .brick-date-picker-trigger")) {
      return "brick";
    }
    // layui (源码行46083): .layui-input / 最近的 .layui-laydate / 后代有 .layui-laydate /
    //                       lay-key 属性 / 页面上有可见的 .layui-laydate 面板
    if (
      cls.contains("layui-input") ||
      safeClosest(element, ".layui-laydate") ||
      safeQuery(element, ".layui-laydate") ||
      (element.hasAttribute && element.hasAttribute("lay-key")) ||
      document.querySelector('.layui-laydate:not([style*="display: none"])')
    ) {
      return "layui";
    }
    if (safeClosest(element, ".el-date-editor, .el-range-editor") || safeQuery(element, ".el-date-editor, .el-range-editor")) {
      return "el";
    }
    if (
      cls.contains("ivu-date-picker") ||
      safeClosest(element, ".ivu-date-picker, .ivu-date-picker-rel") ||
      safeQuery(element, ".ivu-date-picker, .ivu-date-picker-rel")
    ) {
      return "ivu";
    }
    if (safeClosest(element, ".phoenix-date-picker") || safeQuery(element, ".phoenix-date-picker")) {
      return "phoenix";
    }

    // ==== 深层前缀扫描 (源码行46107-46180): 依次在 自身classList → 兄弟节点 → 所有后代
    //      的 classList 里，找第一个以 13 种框架类型之一开头的 class，命中即返回该类型 ====
    var ownMatch = matchFrame示例资料Prefix(element.classList);
    if (ownMatch) return ownMatch;

    if (element.parentNode) {
      var siblings = Array.prototype.filter.call(element.parentNode.children, function (c) {
        return c !== element;
      });
      for (var s = 0; s < siblings.length; s++) {
        var sibMatch = matchFrame示例资料Prefix(siblings[s].classList);
        if (sibMatch) return sibMatch;
      }
    }

    var descendants = element.querySelectorAll("*");
    for (var d = 0; d < descendants.length; d++) {
      var descMatch = matchFrame示例资料Prefix(descendants[d].classList);
      if (descMatch) return descMatch;
    }

    // 向上递归到父节点 (源码行46196: detectType(parent, depth+1)，顶部 depth>1 守卫兜底)
    if (element.parentNode) return detectType(element.parentNode, depth + 1);
    return null;
  }

  async function setFallbackValue(element, value) {
    try {
      var target = value;
      if (value && typeof value === "object") target = value.startTime || value.endTime;
      if (!target) return false;
      var input = (element.querySelector && element.querySelector("input")) || element;
      input.focus && input.focus();
      input.value = String(target);
      input.setAttribute && input.setAttribute("value", String(target));
      input.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
      input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      input.dispatchEvent(new Event("blur", { bubbles: true, cancelable: true }));
      return true;
    } catch (e) {
      return false;
    }
  }

  function create(element, valueType, capabilityContext) {
    var capability = capabilityContext && capabilityContext.capability
      ? capabilityContext.capability
      : capabilityContext || null;
    var detectedType = detectType(element);
    var requestedType = capability && String(capability.dateAdapter || capability.adapter || "").trim();
    var type = requestedType && AF.DatePicker._registry[requestedType] ? requestedType : detectedType;
    var factory = type && AF.DatePicker._registry[type];
    if (factory) {
      try {
        var picker = factory(element, valueType, capability);
        if (!capability || !picker || typeof picker.setValue !== "function") return picker;
        return {
          setValue: async function (value) {
            var previous = AF.DatePicker._currentCapability;
            AF.DatePicker._currentCapability = capability;
            var transformed = AF.CapabilityPatch && AF.CapabilityPatch.transformDateValue
              ? AF.CapabilityPatch.transformDateValue(value, capability)
              : value;
            try {
              return await picker.setValue(transformed);
            } catch (configuredError) {
              try {
                var legacyFactory = detectedType && AF.DatePicker._registry[detectedType];
                var legacyPicker = legacyFactory && legacyFactory(element, valueType);
                return legacyPicker && typeof legacyPicker.setValue === "function"
                  ? await legacyPicker.setValue(value)
                  : await setFallbackValue(element, value);
              } catch (legacyError) {
                return false;
              }
            } finally {
              AF.DatePicker._currentCapability = previous || null;
            }
          },
        };
      } catch (e) {}
    }
    return {
      setValue: function (value) {
        var transformed = capability && AF.CapabilityPatch && AF.CapabilityPatch.transformDateValue
          ? AF.CapabilityPatch.transformDateValue(value, capability)
          : value;
        return setFallbackValue(element, transformed);
      },
    };
  }

  AF.DatePicker.detectType = detectType;
  AF.DatePicker.getDatePickerType = getDatePickerType;
  AF.DatePicker.create = create;
})();
