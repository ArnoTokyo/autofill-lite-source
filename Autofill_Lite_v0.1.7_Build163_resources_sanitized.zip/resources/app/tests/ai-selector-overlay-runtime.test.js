"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const overlay = fs.readFileSync(path.join(root, "ai-semantic-overlay.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const fill = fs.readFileSync(path.join(root, "autofill-plugin/content/fill-engine.js"), "utf8");

assert(overlay.includes("selectorMappings"), "selector mappings missing from candidate compiler");
assert(overlay.includes("selector_runtime_array_unsupported"), "示例资料-record selector safety gate missing");
assert(overlay.includes("composite_address_control_requires_adapter"), "composite address safety gate missing");
assert(overlay.includes("stableSelectorForField"), "stable selector resolver missing");
assert(main.includes("selectorMappingCount"), "selector overlay installation accounting missing");
assert(fill.includes("executeRuntimeSelectorOverlayFill"), "runtime selector executor missing");
assert(fill.includes("runtime_selector_fill_failed"), "runtime selector failure trace missing");
assert(fill.includes("AI Selector Overlay"), "runtime selector result marker missing");
console.log("ai-selector-overlay-runtime.test.js PASS");
