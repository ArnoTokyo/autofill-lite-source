"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");

const workflowPath = path.join(__dirname, "..", "autofill-plugin", "content", "special-site-workflow.js");
const source = fs.readFileSync(workflowPath, "utf8");
assert(source.includes('"expanded_scope_cancel_close"'), "safe close resolver must support parent-scope expansion");
assert(source.includes("scopeDepth"), "safe close diagnostics must record scope depth");
assert(source.includes("preflightRecoveryAttempted"), "multi-section survey must recover an editor left open by a previous probe");
assert(source.includes("blocked_open_editor"), "survey must stop if preflight recovery is unsafe");
assert(source.includes("analyzedEditorActionTexts(actionScope)"), "action texts must be collected from the resolved action scope");

const probeStart = source.indexOf("async function runAnalyzedSectionAddEditorProbe");
const probeEnd = source.indexOf("async function runAnalyzedEducationAddEditorProbe", probeStart);
const probeSource = source.slice(probeStart, probeEnd);
assert(!probeSource.includes("fillFormElement"), "scope recovery must remain read-only");
assert(!probeSource.includes("findExplicitSectionSaveButton"), "scope recovery must not click save");

const main = fs.readFileSync(path.join(__dirname, "..", "main.js"), "utf8");
console.log("editor scope recovery test: PASS");
