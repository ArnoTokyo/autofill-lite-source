"use strict";
const fs = require("fs");
const path = require("path");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const workflow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-workflow.js"), "utf8");
const sites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");

// A. The site contract must describe the real custom-research submit action.
assert(sites.includes('fallbackCheckboxText: "若未找到，请填写研究方向"'), "A: fallback checkbox contract missing");
assert(sites.includes('fallbackSubmitButtonText: "提交"'), "A: custom research submit text missing");
assert(sites.includes('fallbackWritebackTimeoutMs'), "A: custom research writeback timeout missing");

// B. Research direction is required on Bankcomm higher-education cards; a failed custom transaction
// must be surfaced instead of silently treated as an optional field.
const researchTypeIndex = sites.indexOf('type: "bankcommResearchSearch"');
assert(researchTypeIndex !== -1, "B: Bankcomm research config missing");
const researchConfig = sites.slice(Math.max(0, researchTypeIndex - 500), researchTypeIndex + 1200);
assert(researchConfig.includes('label: "研究方向"'), "B: Bankcomm research label missing");
assert(researchConfig.includes('optional: false'), "B: Bankcomm research custom transaction should be required");

// C. Custom fallback must commit through the site's blue Submit button and wait for the main
// cascader field to reflect the custom text. Build119 incorrectly escaped the popup after typing.
const start = workflow.indexOf('async function fillBankcommResearchCustomValue');
const end = workflow.indexOf('\n  }\n\n', start);
assert(start !== -1 && end > start, "C: custom research filler missing");
const fn = workflow.slice(start, end + 5);
assert(fn.includes('fallbackSubmitButtonText'), "C: filler does not resolve submit button text");
assert(fn.includes('clickAntActionInPage(submitButton'), "C: filler must use MAIN-world click for React submit");
assert(fn.includes('typeBankcommResearchCustomInputInPage'), "C: filler must use controlled research input bridge");
assert(fn.includes('fallbackWritebackTimeoutMs'), "C: filler must wait for main field writeback");
assert(fn.includes('.ant-cascader-picker-label'), "C: main cascader writeback verification missing");
assert(!fn.includes('key: "Escape"'), "C: custom filler must not close the popup before Submit commits");

// D. Expose the helper for future DOM-level tests without changing production behavior.
assert(workflow.includes('fillBankcommResearchCustomValue: fillBankcommResearchCustomValue'), "D: test hook missing");
console.log("bankcomm-research-custom-submit.test.js passed (A-D)");
