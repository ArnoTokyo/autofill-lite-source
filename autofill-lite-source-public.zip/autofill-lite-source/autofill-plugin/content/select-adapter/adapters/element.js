// content/select-adapter/adapters/element.js — Element UI (.el-select) 适配器
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   ElementSelectAdapter (模块1140):  行 4492-5227
//   triggerElementSelect (混淆名 v/m): 行 5106-5161
//   选择器配置 (源码定位手册 6.5, 与 n.n.element 一致): container/.el-select,
//     trigger/.el-input__inner,.el-select__input, dropdown/.el-select-dropdown__item,
//     popper/.el-select__popper
//
// 算法 (对应源码 m() 函数, 行5109-5161):
//   1. container = closest(.el-select)；trigger = container 内 trigger 选择器命中的元素
//   2. focus trigger 并点击 (展开面板)
//   3. 若 trigger 本身是 <input> 或其内部有 <input>，输入 value 触发过滤
//   4. 面板是 el-select-dropdown / el-select__popper，通常被 portal 到 body 外，用
//      findVisibleDropdownNear 全局搜索并取离 container 最近的一个
//   5. 找到面板后调用通用 selectMatchingOption
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};
  var H = SA._helpers;
  var CFG = SA._config.element;
  var CASCADER_CFG = SA._config["element-cascader"];
  var DROPDOWN_PANEL_SELECTOR = [".el-select-dropdown", ".el-select__popper"];
  var AUTOCOMPLETE_PANEL_SELECTOR = [".el-autocomplete-suggestion", ".el-popper.my-autocomplete"];
  var AUTOCOMPLETE_OPTION_SELECTOR = ".el-autocomplete-suggestion__list li, .el-autocomplete-suggestion li, [role='option']";
  // 不把泛化的 .el-popper 放进 cascader 查找范围。Element Plus 的 date/select/cascader
  // 都会生成 .el-popper，在重复表单里按“最近距离”很容易拿错面板。
  // Element UI 2.x uses `.el-cascader-menus.el-popper`, while Element Plus
  // uses `.el-cascader__dropdown` / `.el-cascader-panel`.  The old container
  // is still common on bank recruitment sites (including Ping An).  Without
  // it the trigger opens correctly, but the adapter never sees the options.
  var CASCADER_PANEL_SELECTOR = [".el-cascader__dropdown", ".el-cascader-panel", ".el-cascader-menus"];

  function normalizeOptionText(value) {
    return String(value == null ? "" : value).replace(/\s+/g, "").trim();
  }

  function optionTextMatches(node, value) {
    var text = normalizeOptionText(node && node.textContent);
    var wanted = normalizeOptionText(value);
    return !!(text && wanted && (text === wanted || text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1));
  }

  function isVisiblePanel(panel) {
    return !!(panel && AF.DomUtils.isElementVisible(panel) && panel.getAttribute("aria-hidden") !== "true");
  }

  function panelHasOption(panel, optionSelector, value) {
    if (!panel) return false;
    if (!value) return true;
    var options = [];
    try { options = Array.from(panel.querySelectorAll(optionSelector)); } catch (e) {}
    return options.some(function (option) { return optionTextMatches(option, value); });
  }

  function findVisiblePanelInside(root, selectors, optionSelector, value) {
    if (!root) return null;
    var selectorText = Array.isArray(selectors) ? selectors.join(",") : selectors;
    var panels = [];
    try { panels = Array.from(root.querySelectorAll(selectorText)); } catch (e) {}
    panels = panels.filter(isVisiblePanel);
    if (value) {
      var matched = panels.find(function (panel) { return panelHasOption(panel, optionSelector, value); });
      if (matched) return matched;
    }
    return panels[0] || null;
  }

  function findAriaLinkedPanel(element, container, selectors, optionSelector, value) {
    var selectorText = Array.isArray(selectors) ? selectors.join(",") : selectors;
    var nodes = [element, container].filter(Boolean);
    try { nodes = nodes.concat(Array.from((container || element).querySelectorAll("[aria-controls], [aria-owns]"))); } catch (e) {}
    var ids = [];
    nodes.forEach(function (node) {
      ["aria-controls", "aria-owns"].forEach(function (attr) {
        var raw = node && node.getAttribute && node.getAttribute(attr);
        String(raw || "").split(/\s+/).filter(Boolean).forEach(function (id) { if (ids.indexOf(id) === -1) ids.push(id); });
      });
    });
    for (var i = 0; i < ids.length; i++) {
      var linked = document.getElementById(ids[i]);
      if (!linked) continue;
      var panel = linked;
      try {
        if (selectorText && !(linked.matches && linked.matches(selectorText))) {
          panel = linked.closest && linked.closest(selectorText) || linked.querySelector && linked.querySelector(selectorText) || linked;
        }
      } catch (ePanel) { panel = linked; }
      if (!isVisiblePanel(panel)) continue;
      if (!value || panelHasOption(panel, optionSelector, value)) return panel;
    }
    return null;
  }

  function findElementPanel(element, container, selectors, containerSelector, optionSelector, value) {
    // Element UI Autocomplete 的候选层在 popperAppendToBody=true 时不在
    // 当前表单容器内。aria-owns 是输入组件与 body 下候选层的一对一关联，
    // 必须优先使用，避免重复表单中误取其他 autocomplete 的浮层。
    var autocomplete = element && element.closest && element.closest(".el-autocomplete") ||
      container && container.matches && container.matches(".el-autocomplete") && container;
    var ownedId = autocomplete && autocomplete.getAttribute("aria-owns");
    var ownedPanel = ownedId && document.getElementById(ownedId);
    if (isVisiblePanel(ownedPanel) && (!value || panelHasOption(ownedPanel, optionSelector, value))) {
      return ownedPanel;
    }
    var ariaLinkedPanel = findAriaLinkedPanel(element, container, selectors, optionSelector, value);
    if (ariaLinkedPanel) return ariaLinkedPanel;
    // Element Plus 新版本经常把 popper 直接放在 .el-select/.el-cascader 或
    // 最近 .el-form-item 里，而不是 portal 到 body。重复记录场景下必须先局部找。
    var local = findVisiblePanelInside(container, selectors, optionSelector, value);
    if (local) return local;
    var formItem = element && element.closest && element.closest(".el-form-item");
    local = findVisiblePanelInside(formItem, selectors, optionSelector, value);
    if (local) return local;

    var panel = H.findVisibleDropdownNear(element, selectors, containerSelector);
    if (panel && (!value || panelHasOption(panel, optionSelector, value))) return panel;

    var selectorText = Array.isArray(selectors) ? selectors.join(",") : selectors;
    var candidates = [];
    try { candidates = Array.from(document.querySelectorAll(selectorText)).filter(isVisiblePanel); } catch (e) {}
    if (value) {
      var withValue = candidates.filter(function (candidate) { return panelHasOption(candidate, optionSelector, value); });
      if (withValue.length) candidates = withValue;
    }
    if (!candidates.length) return panel || null;
    var refRect = (container || element).getBoundingClientRect();
    candidates.sort(function (a, b) {
      var ar = a.getBoundingClientRect();
      var br = b.getBoundingClientRect();
      var ad = Math.abs(ar.left - refRect.left) + Math.abs(ar.top - refRect.bottom);
      var bd = Math.abs(br.left - refRect.left) + Math.abs(br.top - refRect.bottom);
      return ad - bd;
    });
    return candidates[0] || panel || null;
  }

  async function waitElementPanel(element, container, selectors, containerSelector, optionSelector, value, timeoutMs) {
    var start = Date.now();
    while (Date.now() - start < (timeoutMs || 1600)) {
      var panel = findElementPanel(element, container, selectors, containerSelector, optionSelector, value);
      if (panel) return panel;
      await AF.Utils.sleep(80);
    }
    return null;
  }

  function resolveClickableTrigger(container, trigger) {
    if (!container) return trigger;
    if (trigger && trigger.closest) {
      var wrapper = trigger.closest(".el-input__wrapper, .select-trigger, [role='button']");
      if (wrapper && container.contains(wrapper)) return wrapper;
    }
    return container.querySelector(".select-trigger, .el-input__wrapper, [role='button']") || trigger || container;
  }

  async function clickElementTrigger(container, trigger) {
    var node = resolveClickableTrigger(container, trigger);
    if (!node) return false;
    try { trigger && trigger.focus && trigger.focus(); } catch (e0) {}
    try { node.focus && node.focus(); } catch (e1) {}
    try {
      var rect = node.getBoundingClientRect && node.getBoundingClientRect();
      var init = {
        view: window,
        bubbles: true,
        cancelable: true,
        composed: true,
        clientX: rect ? rect.left + Math.max(4, Math.min(rect.width / 2, rect.width - 4)) : 0,
        clientY: rect ? rect.top + Math.max(4, Math.min(rect.height / 2, rect.height - 4)) : 0,
        button: 0,
        buttons: 1,
      };
      if (window.PointerEvent) node.dispatchEvent(new PointerEvent("pointerdown", init));
      node.dispatchEvent(new MouseEvent("mousedown", init));
      if (window.PointerEvent) node.dispatchEvent(new PointerEvent("pointerup", init));
      node.dispatchEvent(new MouseEvent("mouseup", init));
      node.dispatchEvent(new MouseEvent("click", init));
      if (trigger) trigger.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, composed: true, key: "ArrowDown" }));
    } catch (e2) {
      await AF.DomUtils.safeClickElement(node);
    }
    await AF.Utils.sleep(160);
    return true;
  }

  function setElementInputValue(input, value) {
    var descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    if (descriptor && descriptor.set) descriptor.set.call(input, value);
    else input.value = value;
  }

  function findEditableElementInput(container, fallback) {
    var inputs = [];
    try {
      inputs = Array.from(container.querySelectorAll(".el-select__input, input"));
    } catch (e) {}
    return inputs.find(function (input) {
      return input && !input.disabled && !input.readOnly && /^(text|search)?$/.test(input.type || "text");
    }) || fallback || null;
  }

  async function waitEditableElementInput(container, fallback, timeoutMs) {
    var start = Date.now();
    while (Date.now() - start < (timeoutMs || 1200)) {
      var input = findEditableElementInput(container, null);
      if (input && !input.disabled && !input.readOnly && /^(text|search)?$/.test(input.type || "text")) return input;
      await AF.Utils.sleep(60);
    }
    var fallbackInput = fallback && fallback.tagName === "INPUT" ? fallback : fallback && fallback.querySelector && fallback.querySelector("input");
    if (fallbackInput && !fallbackInput.disabled && !fallbackInput.readOnly && /^(text|search)?$/.test(fallbackInput.type || "text")) {
      return fallbackInput;
    }
    return null;
  }

  async function dispatchSearchEvents(input, value) {
    var events = [
      new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: value, inputType: "insertText" }),
      new Event("change", { bubbles: true, cancelable: true }),
      new KeyboardEvent("keydown", { bubbles: true, cancelable: true }),
      new KeyboardEvent("keyup", { bubbles: true, cancelable: true }),
      new Event("search", { bubbles: true, cancelable: true }),
    ];
    for (var i = 0; i < events.length; i++) {
      input.dispatchEvent(events[i]);
      await AF.Utils.sleep(5);
    }
  }

  async function typeAutocompleteInput(input, value, stableScope) {
    var text = String(value == null ? "" : value);
    var descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    input.focus && input.focus();
    try { input.select && input.select(); } catch (eSelect) {}

    try {
      if (document.execCommand) document.execCommand("delete", false, null);
    } catch (eDeleteCommand) {}
    if (input.value) {
      if (descriptor && descriptor.set) descriptor.set.call(input, "");
      else input.value = "";
    }
    input.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: "", inputType: "deleteContentBackward" }));
    input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
    await AF.Utils.sleep(220);
    // 某些站点（平安校园学校搜索）会在清空后重建 autocomplete/input。
    // 从稳定的 form-item 容器重新取得输入框，再执行逐字搜索输入。
    input = await waitAutocompleteInput(stableScope || input.parentElement, input, 1800) || input;
    input.focus && input.focus();
    var current = "";
    for (var i = 0; i < text.length; i++) {
      var ch = text[i];
      current += ch;
      input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: ch }));
      try { input.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, composed: true, data: ch, inputType: "insertText" })); } catch (eBeforeInput) {}
      var insertedChar = false;
      try {
        insertedChar = !!(document.execCommand && document.execCommand("insertText", false, ch));
      } catch (eCharCommand) {}
      if (!insertedChar || normalizeOptionText(input.value) !== normalizeOptionText(current)) {
        if (descriptor && descriptor.set) descriptor.set.call(input, current);
        else input.value = current;
      }
      input.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: ch, inputType: "insertText" }));
      input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, key: ch }));
      await AF.Utils.sleep(95);
    }
    try { input.dispatchEvent(new CompositionEvent("compositionend", { bubbles: true, cancelable: true, composed: true, data: text })); } catch (eComposition) {}
    input.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: text, inputType: "insertText" }));
    input.dispatchEvent(new Event("search", { bubbles: true, cancelable: true }));
    input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
    return input;
  }

  async function waitAutocompleteInput(container, fallback, timeoutMs) {
    var start = Date.now();
    while (Date.now() - start < (timeoutMs || 1800)) {
      var input = null;
      try {
        input = Array.from(container.querySelectorAll(
          "input[aria-autocomplete='list'], input[fetchsuggestions], input.el-input__inner"
        )).find(function (node) {
          return node && !node.disabled && !node.readOnly && AF.DomUtils.isElementVisible(node);
        }) || null;
      } catch (e) {}
      if (input) return input;
      await AF.Utils.sleep(60);
    }
    return fallback && !fallback.disabled && !fallback.readOnly ? fallback : null;
  }

  async function clickElementAutocompleteOption(option) {
    if (!option) return false;
    try { option.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "auto" }); } catch (e0) {}
    await AF.Utils.sleep(120);
    try {
      var rect = option.getBoundingClientRect();
      var init = {
        view: window,
        bubbles: true,
        cancelable: true,
        composed: true,
        clientX: rect.left + rect.width / 2,
        clientY: rect.top + rect.height / 2,
        button: 0,
        buttons: 1,
      };
      // Element UI autocomplete 先靠 mouseenter 更新 highlightedIndex，随后
      // click 才会调用 select。只派发 click 时页面会显示候选却不真正选中。
      option.dispatchEvent(new MouseEvent("mouseover", init));
      option.dispatchEvent(new MouseEvent("mouseenter", Object.assign({}, init, { bubbles: false })));
      option.dispatchEvent(new MouseEvent("mousemove", init));
      if (window.PointerEvent) option.dispatchEvent(new PointerEvent("pointerdown", init));
      option.dispatchEvent(new MouseEvent("mousedown", init));
      await AF.Utils.sleep(20);
      if (window.PointerEvent) option.dispatchEvent(new PointerEvent("pointerup", Object.assign({}, init, { buttons: 0 })));
      option.dispatchEvent(new MouseEvent("mouseup", Object.assign({}, init, { buttons: 0 })));
      option.dispatchEvent(new MouseEvent("click", Object.assign({}, init, { buttons: 0 })));
      return true;
    } catch (e1) {
      return await H.clickOption(option);
    }
  }

  async function selectPinganSchoolWithTrustedMouse(input, keyword) {
    if (!input || !window.chrome || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") return false;
    var marker = "af_element_pingan_school_" + Date.now() + "_" + Math.random().toString(16).slice(2);
    var host = input.closest && (input.closest(".el-form-item") || input.closest(".el-autocomplete")) || input.parentElement;
    try {
      input.setAttribute("data-af-trusted-autocomplete-id", marker);
      if (host) host.setAttribute("data-af-trusted-autocomplete-host", marker);
      var response = await new Promise(function (resolve) {
        chrome.runtime.sendMessage({
          action: "trustedElementAutocomplete",
          marker: marker,
          value: String(keyword || ""),
          panelSelector: ".el-autocomplete-suggestion.el-popper.my-autocomplete",
          optionSelector: "li[role='option']",
          preserveExistingInput: true,
          requireBlurAfterSelect: true,
          optionTimeoutMs: 4500,
          waitBeforeOptionClickMs: 80,
          waitAfterSelectMs: 500,
        }, function (result) {
          resolve(result || { success: false, error: chrome.runtime.lastError && chrome.runtime.lastError.message });
        });
      });
      return !!(response && response.success);
    } catch (e) {
      return false;
    } finally {
      try { input.removeAttribute("data-af-trusted-autocomplete-id"); } catch (e1) {}
      try { if (host) host.removeAttribute("data-af-trusted-autocomplete-host"); } catch (e2) {}
      try {
        var marked = document.querySelector('[data-af-trusted-autocomplete-id="' + marker + '"]');
        var markedHost = document.querySelector('[data-af-trusted-autocomplete-host="' + marker + '"]');
        if (marked) marked.removeAttribute("data-af-trusted-autocomplete-id");
        if (markedHost) markedHost.removeAttribute("data-af-trusted-autocomplete-host");
      } catch (e3) {}
    }
  }

  async function triggerElementAutocomplete(element, value) {
    var stableScope = element.closest && element.closest(".el-form-item") || element.closest && element.closest(".el-autocomplete") || element;
    var container = element.closest && element.closest(".el-autocomplete") || element;
    var input = await waitAutocompleteInput(stableScope, element.tagName === "INPUT" ? element : null, 2400);
    if (!input || value === null || value === undefined) return false;
    var keyword = typeof value === "object" ? value.name || value.label || value.text || value.value || "" : String(value);
    var selectFirstOption = !!(value && typeof value === "object" && value.selectFirstOption === true);
    var requireBlurAfterSelect = !!(value && typeof value === "object" && value.requireBlurAfterSelect === true);
    var isPinganCampusSchool = /(^|\.)campus\.pingan\.com$/i.test(String(location.hostname || "")) &&
      String(input.getAttribute("placeholder") || "").indexOf("仅校名全称") !== -1;
    if (!keyword) return false;
    function autocompleteAccepted() {
      var freshInput = null;
      try {
        freshInput = Array.from(stableScope.querySelectorAll(
          "input[aria-autocomplete='list'], input[fetchsuggestions], .el-autocomplete input.el-input__inner"
        )).find(function (node) { return node && AF.DomUtils.isElementVisible(node); }) || null;
      } catch (eFresh) {}
      input = freshInput || input;
      if (normalizeOptionText(input.value) !== normalizeOptionText(keyword)) return false;
      if (requireBlurAfterSelect && document.activeElement === input) return false;
      var formItem = input.closest && input.closest(".el-form-item");
      return !(formItem && /is-error/.test(String(formItem.className || "")));
    }
    input = await typeAutocompleteInput(input, keyword, stableScope);
    container = input.closest && input.closest(".el-autocomplete") || container;
    await AF.Utils.sleep(520);
    var panel = await waitElementPanel(
      input,
      container,
      AUTOCOMPLETE_PANEL_SELECTOR,
      ".el-autocomplete",
      AUTOCOMPLETE_OPTION_SELECTOR,
      keyword,
      3600
    );
    if (!panel) {
      try {
        input.focus && input.focus();
        input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: "ArrowDown", code: "ArrowDown" }));
        input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, key: "ArrowDown", code: "ArrowDown" }));
        await AF.Utils.sleep(160);
        input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: "Enter", code: "Enter" }));
        input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, key: "Enter", code: "Enter" }));
        input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
        await AF.Utils.sleep(240);
      } catch (eNoPanelKeyboard) {}
      return autocompleteAccepted();
    }
    // This exact Element UI autocomplete rejects isolated-world synthetic
    // clicks. Once the engine has visibly typed the school and found its
    // aria-owned option, hand that existing state directly to the real mouse
    // bridge. Do not close the popup with a synthetic click first.
    if (isPinganCampusSchool) {
      return await selectPinganSchoolWithTrustedMouse(input, keyword);
    }
    if (selectFirstOption) {
      try {
        var firstOption = Array.from(panel.querySelectorAll(AUTOCOMPLETE_OPTION_SELECTOR)).find(function (node) {
          return AF.DomUtils.isElementVisible(node) && !node.disabled && !node.classList.contains("disabled");
        }) || null;
        if (firstOption) await clickElementAutocompleteOption(firstOption);
        var firstCommitted = await (async function () {
          var started = Date.now();
          while (Date.now() - started < 1400) {
            var stillOpen = findElementPanel(input, container, AUTOCOMPLETE_PANEL_SELECTOR, ".el-autocomplete", AUTOCOMPLETE_OPTION_SELECTOR, keyword);
            var autocomplete = input.closest && input.closest(".el-autocomplete");
            // Element UI 2.x 收起 autocomplete 后会直接移除 aria-expanded，
            // 不一定保留 aria-expanded="false"。
            var collapsed = !autocomplete || autocomplete.getAttribute("aria-expanded") !== "true";
            if (!stillOpen && collapsed && autocompleteAccepted()) return true;
            await AF.Utils.sleep(80);
          }
          return false;
        })();
        if (firstCommitted) return true;
        // The caller will hand the already typed value and open suggestion to
        // a trusted mouse bridge. Do not spend several seconds on synthetic
        // keyboard fallbacks or clear/retype the field again.
        if (requireBlurAfterSelect) return false;
        // DOM 选择没有提交时，用组件自身的键盘行为再选第一项。
        input.focus && input.focus();
        input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, composed: true, key: "ArrowDown", code: "ArrowDown" }));
        input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, composed: true, key: "ArrowDown", code: "ArrowDown" }));
        await AF.Utils.sleep(120);
        input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, composed: true, key: "Enter", code: "Enter" }));
        input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, composed: true, key: "Enter", code: "Enter" }));
        input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
        await AF.Utils.sleep(320);
        var comboAfterKeyboard = input.closest && input.closest(".el-autocomplete");
        if ((!comboAfterKeyboard || comboAfterKeyboard.getAttribute("aria-expanded") !== "true") && autocompleteAccepted()) return true;
      } catch (eFirstOption) {}
    }
    var option = findElementSelectOption(panel, keyword) || await (async function () {
      var started = Date.now();
      while (Date.now() - started < 1600) {
        var found = findElementSelectOption(panel, keyword);
        if (found) return found;
        await AF.Utils.sleep(80);
      }
      return null;
    })();
    if (!option) return false;
    await clickElementAutocompleteOption(option);
    var clickCommitted = await (async function () {
      var started = Date.now();
      while (Date.now() - started < 1200) {
        var stillOpen = findElementPanel(input, container, AUTOCOMPLETE_PANEL_SELECTOR, ".el-autocomplete", AUTOCOMPLETE_OPTION_SELECTOR, keyword);
        if (!stillOpen && autocompleteAccepted()) return true;
        await AF.Utils.sleep(80);
      }
      return false;
    })();
    if (clickCommitted) return true;
    try {
      input.focus && input.focus();
      // mouseenter 已经把精确匹配项设为当前高亮，直接 Enter；再按 ArrowDown
      // 会跳到下一所学校。
      input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: "Enter", code: "Enter" }));
      input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, key: "Enter", code: "Enter" }));
      input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      await AF.Utils.sleep(320);
    } catch (eKeyboardSelect) {}
    return !findElementPanel(input, container, AUTOCOMPLETE_PANEL_SELECTOR, ".el-autocomplete", AUTOCOMPLETE_OPTION_SELECTOR, keyword) && autocompleteAccepted();
  }

  function getVisibleCascaderMenus(panel) {
    try {
      var root = panel || document;
      var menus = Array.from(root.querySelectorAll(".el-cascader-menu, .el-cascader-panel .el-scrollbar, .el-cascader__dropdown .el-scrollbar"));
      menus = menus.filter(function (menu) {
        return AF.DomUtils.isElementVisible(menu) && menu.querySelector(CASCADER_CFG.dropdown);
      });
      if (menus.length) return menus;
    } catch (e) {}
    return [panel || document];
  }

  async function selectCascaderPathLevel(panel, value, levelIndex) {
    var menus = getVisibleCascaderMenus(panel);
    var menu = menus[Math.min(levelIndex, menus.length - 1)] || panel;
    if (await H.selectMatchingOption(menu, value, CASCADER_CFG.dropdown)) return true;
    return await H.selectMatchingOption(panel, value, CASCADER_CFG.dropdown);
  }

  async function clickElementCascaderOption(option) {
    if (!option) return false;
    try {
      var checkbox = option.querySelector && option.querySelector(".el-checkbox__inner, .el-checkbox__input, input[type='checkbox']");
      if (checkbox && AF.DomUtils.isElementVisible(checkbox)) {
        await H.clickOption(checkbox);
        return true;
      }
    } catch (e) {}
    var ok = await H.clickOption(option);
    await AF.Utils.sleep(120);
    try {
      option.click && option.click();
    } catch (e2) {}
    await AF.Utils.sleep(120);
    return ok;
  }

  function findCascaderOption(scope, value) {
    var wanted = String(value == null ? "" : value).trim();
    if (!scope || !wanted) return null;
    var nodes = [];
    try { nodes = Array.from(scope.querySelectorAll(CASCADER_CFG.dropdown)); } catch (e) {}
    nodes = nodes.filter(function (node) { return AF.DomUtils.isElementVisible(node); });
    return nodes.find(function (node) {
      return String(node.textContent || "").replace(/\s+/g, "").trim() === wanted.replace(/\s+/g, "").trim();
    }) || nodes.find(function (node) {
      var text = String(node.textContent || "").replace(/\s+/g, "").trim();
      var target = wanted.replace(/\s+/g, "").trim();
      return text && (text.indexOf(target) !== -1 || target.indexOf(text) !== -1);
    }) || null;
  }

  function findFirstCascaderOption(scope) {
    if (!scope) return null;
    var nodes = [];
    try { nodes = Array.from(scope.querySelectorAll(CASCADER_CFG.dropdown)); } catch (e) {}
    nodes = nodes.filter(function (node) {
      return AF.DomUtils.isElementVisible(node) &&
        !(node.classList && (node.classList.contains("is-disabled") || node.classList.contains("is-loading"))) &&
        !/暂无数据|无匹配数据|加载中/i.test(String(node.textContent || ""));
    });
    return nodes[0] || null;
  }

  async function findCascaderOptionWithScroll(scope, value) {
    var option = findCascaderOption(scope, value);
    if (option) return option;
    var scrollers = [];
    try {
      scrollers = Array.from(scope.querySelectorAll(".el-scrollbar__wrap, .el-cascader-menu__wrap")).filter(function (node) {
        return AF.DomUtils.isElementVisible(node) && node.scrollHeight > node.clientHeight + 8;
      });
    } catch (e) {}
    if (!scrollers.length && scope && scope.scrollHeight > scope.clientHeight + 8) scrollers = [scope];
    for (var i = 0; i < scrollers.length; i++) {
      var scroller = scrollers[i];
      try { scroller.scrollTop = 0; } catch (e2) {}
      for (var attempt = 0; attempt < 14; attempt++) {
        option = findCascaderOption(scope, value);
        if (option) return option;
        try { scroller.scrollTop += Math.max(120, Math.floor((scroller.clientHeight || 180) * 0.8)); } catch (e3) {}
        await AF.Utils.sleep(80);
      }
    }
    return findCascaderOption(scope, value);
  }

  async function selectElementCascaderOption(panel, value, levelIndex) {
    var menus = getVisibleCascaderMenus(panel);
    var menu = menus[Math.min(levelIndex || 0, menus.length - 1)] || panel;
    var option = await findCascaderOptionWithScroll(menu, value) || await findCascaderOptionWithScroll(panel, value);
    return option ? await clickElementCascaderOption(option) : false;
  }

  async function selectFirstElementCascaderOption(panel, levelIndex) {
    var menus = getVisibleCascaderMenus(panel);
    var menu = menus[Math.min(levelIndex || 0, Math.max(0, menus.length - 1))] || menus[menus.length - 1] || panel;
    var option = findFirstCascaderOption(menu) || findFirstCascaderOption(panel);
    return option ? await clickElementCascaderOption(option) : false;
  }

  function findElementSelectOption(panel, value) {
    var wanted = normalizeOptionText(value);
    if (!panel || !wanted) return null;
    var options = [];
    try { options = Array.from(panel.querySelectorAll(CFG.dropdown)); } catch (e) {}
    options = options.filter(function (option) { return AF.DomUtils.isElementVisible(option); });
    return options.find(function (option) {
      return normalizeOptionText(option.textContent) === wanted;
    }) || options.find(function (option) {
      return optionTextMatches(option, value);
    }) || null;
  }

  function elementSelectValueMatches(container, value) {
    var wanted = normalizeOptionText(value);
    var input = container && container.querySelector && container.querySelector(".el-input__inner, input");
    var actual = normalizeOptionText(input && input.value);
    var tags = [];
    try {
      tags = Array.from(container.querySelectorAll(".el-select__tags .el-tag, .el-tag")).map(function (tag) {
        return normalizeOptionText(tag.textContent);
      }).filter(Boolean);
    } catch (e) {}
    return !!(wanted && (actual === wanted || tags.indexOf(wanted) !== -1));
  }

  function elementSelectHasAnyValue(container) {
    var input = container && container.querySelector && container.querySelector(".el-input__inner, input");
    var actual = normalizeOptionText(input && input.value);
    if (actual) return true;
    try {
      return Array.from(container.querySelectorAll(".el-select__tags .el-tag, .el-tag"))
        .some(function (tag) { return normalizeOptionText(tag.textContent); });
    } catch (e) {
      return false;
    }
  }

  async function clickElementSelectOption(option, container, value, allowAnyValue) {
    if (!option) return false;
    await H.clickOption(option);
    await AF.Utils.sleep(180);
    if (allowAnyValue && elementSelectHasAnyValue(container)) return true;
    if (elementSelectValueMatches(container, value)) return true;
    var inner = option.querySelector && option.querySelector("span, div");
    if (inner) {
      try {
        inner.click();
      } catch (e) {}
      await AF.Utils.sleep(180);
      if (allowAnyValue && elementSelectHasAnyValue(container)) return true;
      if (elementSelectValueMatches(container, value)) return true;
    }
    try {
      option.click();
    } catch (e2) {}
    await AF.Utils.sleep(180);
    if (allowAnyValue && elementSelectHasAnyValue(container)) return true;
    return elementSelectValueMatches(container, value);
  }

  async function selectOneElementValue(element, container, trigger, value) {
    var valueObject = value && typeof value === "object" && !Array.isArray(value) ? value : null;
    var keyword = valueObject
      ? String(valueObject.name || valueObject.label || valueObject.text || valueObject.value || "")
      : String(value == null ? "" : value);
    var selectFirstOption = !!(valueObject && (
      valueObject.selectFirstOption || valueObject.fallbackFirst ||
      valueObject.pickFirst || valueObject.allowFirstOption
    ));
    if (!keyword) return false;
    trigger.focus && trigger.focus();
    await clickElementTrigger(container, trigger);
    await AF.Utils.sleep(120);

    // 浙商“学校名称”等远程搜索型 Element Select，关闭状态下 input 是
    // readonly；点击后 Vue/Element 才会异步解锁可输入状态。之前这里只
    // 等 120ms 就判断，常常还没解锁就跳过搜索，导致只打开不选候选。
    var input = await waitEditableElementInput(container, trigger, 1400);
    if (input && !input.readOnly && !input.disabled && (input.type === "text" || input.type === "search")) {
      input.focus();
      setElementInputValue(input, keyword);
      await dispatchSearchEvents(input, keyword);
      await AF.Utils.sleep(450);
    }

    var panel = findElementPanel(element, container, DROPDOWN_PANEL_SELECTOR, CFG.container, CFG.dropdown, keyword);
    if (!panel) {
      panel = await waitElementPanel(element, container, DROPDOWN_PANEL_SELECTOR, CFG.container, CFG.dropdown, keyword, 3200);
    }
    if (!panel) return false;
    var option = findElementSelectOption(panel, keyword);
    if (option) return await clickElementSelectOption(option, container, keyword);
    if (selectFirstOption) {
      var firstOption = Array.from(panel.querySelectorAll(CFG.dropdown)).filter(function (node) {
        return AF.DomUtils.isElementVisible(node) &&
          !(node.classList && (node.classList.contains("is-disabled") || node.classList.contains("disabled") || node.classList.contains("is-loading"))) &&
          !/暂无数据|无匹配数据|加载中/i.test(String(node.textContent || ""));
      })[0] || null;
      if (firstOption) return await clickElementSelectOption(firstOption, container, keyword, true);
    }
    return await H.selectMatchingOption(panel, keyword, CFG.dropdown);
  }

  async function triggerElementSelect(element, value) {
    try {
      if (
        element &&
        element.closest &&
        (element.closest(".el-autocomplete") || element.matches && element.matches(".el-autocomplete"))
      ) {
        return await triggerElementAutocomplete(element, value);
      }
      var container = element.closest(CFG.container) || element;
      var trigger = container.querySelector(CFG.trigger) || container;

      var ok;
      if (Array.isArray(value)) {
        ok = false;
        for (var i = 0; i < value.length; i++) {
          var one = await selectOneElementValue(element, container, trigger, value[i]);
          if (one) ok = true;
          await AF.Utils.sleep(150);
        }
      } else {
        ok = await selectOneElementValue(element, container, trigger, value);
      }
      H.dispatchChangeEvents(element);
      return ok;
    } catch (e) {
      return false;
    }
  }

  async function triggerElementCascader(element, value) {
    try {
      var container = element.closest(CASCADER_CFG.container) || element;
      var trigger = container.querySelector(CASCADER_CFG.trigger) || container;
      var valueObject = value && typeof value === "object" && !Array.isArray(value) ? value : null;
      var path = Array.isArray(value)
        ? value.map(function (item) { return String(item || "").trim(); }).filter(Boolean)
        : valueObject && Array.isArray(valueObject.path)
          ? valueObject.path.map(function (item) { return String(item || "").trim(); }).filter(Boolean)
          : [];
      var keyword = valueObject ? valueObject.keyword || valueObject.name || valueObject.label || valueObject.text || "" : String(value || "");
      var fallbackFirst = !!(valueObject && (valueObject.fallbackFirst || valueObject.pickFirst || valueObject.allowFirstOption));
      var firstToken = valueObject && valueObject.firstToken ? String(valueObject.firstToken) : "__FIRST__";
      if (path.length) keyword = path[path.length - 1];
      if (!keyword) return false;

      trigger.focus && trigger.focus();
      await clickElementTrigger(container, trigger);
      await AF.Utils.sleep(120);

      var input = await waitEditableElementInput(container, trigger, 1400);
      if (!path.length && input && !input.disabled && !input.readOnly) {
        input.focus();
        setElementInputValue(input, keyword);
        await dispatchSearchEvents(input, keyword);
        await AF.Utils.sleep(450);
      }

      var firstWanted = path.length ? path[0] : keyword;
      var panel = findElementPanel(element, container, CASCADER_PANEL_SELECTOR, CASCADER_CFG.container, CASCADER_CFG.dropdown, firstWanted);
      if (!panel) {
        panel = await waitElementPanel(element, container, CASCADER_PANEL_SELECTOR, CASCADER_CFG.container, CASCADER_CFG.dropdown, firstWanted, 2200);
      }
      if (!panel) return false;

      if (path.length > 1) {
        for (var pathIndex = 0; pathIndex < path.length; pathIndex++) {
          var pathValue = path[pathIndex];
          var pathOk = pathValue === firstToken
            ? await selectFirstElementCascaderOption(panel, pathIndex)
            : await selectElementCascaderOption(panel, pathValue, pathIndex);
          if (!pathOk) return false;
          await AF.Utils.sleep(260);
          var nextWanted = path[pathIndex + 1] || pathValue;
          panel = findElementPanel(element, container, CASCADER_PANEL_SELECTOR, CASCADER_CFG.container, CASCADER_CFG.dropdown, nextWanted) || panel;
        }
        H.dispatchChangeEvents(element);
        return true;
      }

      var ok = await selectElementCascaderOption(panel, keyword, 0);
      if (!ok && fallbackFirst) ok = await selectFirstElementCascaderOption(panel);
      H.dispatchChangeEvents(element);
      return ok;
    } catch (e) {
      return false;
    }
  }

  SA._registry["element"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        return await triggerElementSelect(element, value);
      },
    };
  };

  SA._registry["element-cascader"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        return await triggerElementCascader(element, value);
      },
    };
  };
})();
