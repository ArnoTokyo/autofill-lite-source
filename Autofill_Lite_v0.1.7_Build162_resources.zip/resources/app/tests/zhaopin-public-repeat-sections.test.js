"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

const menuTitles = [
  "个人信息",
  "高中教育经历",
  "高等教育经历",
  "语言情况",
  "学生工作",
  "实习工作",
  "社会实践经历",
  "全职工作经历",
  "所获专业技术资格证书",
  "项目经验及研究成果",
  "奖励情况",
  "个人特长",
  "家庭信息",
  "是否服从调剂",
];

global.window = { AF: {} };
global.document = {
  body: { innerText: "", textContent: "", querySelectorAll() { return []; } },
  querySelector(selector) { return selector === "body" ? {} : null; },
  querySelectorAll(selector) {
    if (selector === ".resume-menu-item__title") {
      return menuTitles.map((textContent) => ({ textContent }));
    }
    return [];
  },
};

const registry = path.join(__dirname, "..", "autofill-plugin", "private", "private-special-sites.js");
new Function(fs.readFileSync(registry, "utf8"))();

const workflow = window.AF.PrivateSpecialSites.getWorkflowForUrl(
  "https://xiaoyuan.zhaopin.com/scrd/resume2?cid=10126836"
);
assert(workflow, "CDB should match public Zhaopin campus workflow");
assert.strictEqual(workflow.id, "zhaopin-campus-enterprise-resume-v1");

const internship = workflow.steps.find((step) => step.name === "实习工作");
assert(internship, "实习工作 should be recognized");
assert.strictEqual(internship.category, "internshipExperience", "internship section must not consume full-time rows");
assert.strictEqual(internship.zhaopinRepeatNavigationAdapter, true, "internship should use scoped repeat navigation adapter");
assert(internship.fieldSequence.some((item) => (Array.isArray(item.label) ? item.label : [item.label]).includes("公司名称")));
assert(internship.fieldSequence.some((item) => (Array.isArray(item.label) ? item.label : [item.label]).includes("职位名称")));
assert(internship.fieldSequence.some((item) => item.type === "zhaopinCampusDate" && (Array.isArray(item.label) ? item.label : [item.label]).includes("开始日期")), "internship must recognize the CDB 开始日期 label and use precision-aware date filling");
assert(internship.fieldSequence.some((item) => item.type === "zhaopinCampusDate" && (Array.isArray(item.label) ? item.label : [item.label]).includes("结束日期")), "internship must recognize the CDB 结束日期 label");
assert.strictEqual(internship.zhaopinRepairExistingRecords, true);
assert.strictEqual(internship.zhaopinRepairExistingByPosition, true);
assert.strictEqual(internship.zhaopinBlockOnExcessExistingRecords, true);
assert.strictEqual(internship.zhaopinRepairCorruptedExcessDuplicates, true, "obvious duplicate surplus cards may be repaired in-place, but never auto-deleted");
assert.strictEqual(internship.zhaopinContinueExistingRepairAfterRowError, true, "a failed repair of one existing internship row must cancel that unsaved editor and continue auditing later existing rows");
assert.strictEqual(internship.zhaopinRepeatRetrySaveWhenStillEditing, true, "public-repeat save should retry once only when the editor is still truly visible and no validation error is present");
internship.fieldSequence.filter((item) => ["company", "zhaopinCampusStartDate", "zhaopinCampusEndDate", "position"].includes(item.field)).forEach((item) => {
  assert.strictEqual(item.zhaopinRepeatLocalBinding, true, `${item.field} must bind within the current repeat editor field group`);
  assert.strictEqual(item.coreMatcherFirst, false, `${item.field} must not let a stale/global Core match override the current repeat editor`);
  assert.strictEqual(item.requireLabel, true, `${item.field} must stop instead of guessing when the current editor label is absent`);
});
assert.strictEqual(internship.waitForCloseSelector, "form.scrd-web--form-edit", "public-repeat save verification must watch the real editor form, not a persistent outer wrapper");
const transformedInternship = internship.rowTransform({ company: "fixture-company", startTime: "2026-04", endTime: "2026-06", startDate: "2026-04-30", endDate: "2026-06-30", position: "fixture-role" });
assert.strictEqual(transformedInternship.zhaopinCampusStartDate, "2026-04-30");
assert.strictEqual(transformedInternship.zhaopinCampusEndDate, "2026-06-30");

const fulltime = workflow.steps.find((step) => step.name === "全职工作经历");
assert(fulltime, "full-time section should be recognized");
assert.strictEqual(fulltime.category, "workExperience", "full-time section must not consume internship rows");
assert.strictEqual(fulltime.zhaopinRepeatNavigationAdapter, true);

const project = workflow.steps.find((step) => step.name === "项目经验及研究成果");
assert(project, "project section should be recognized");
assert.strictEqual(project.category, "projectExperience");
assert.strictEqual(project.zhaopinRepeatNavigationAdapter, true, "project should use scoped repeat navigation adapter");
const projectLabels = project.fieldSequence.flatMap((item) => Array.isArray(item.label) ? item.label : [item.label]);
["项目名称", "项目开始时间", "项目结束时间", "项目职责", "项目描述"].forEach((label) => {
  assert(projectLabels.includes(label), `project sequence should include ${label}`);
});
const transformedProject = project.rowTransform({ name: "fixture-project", details: "fixture-details", role: "fixture-role" });
assert(transformedProject.zhaopinProjectDescription.includes("fixture-details"), "normalized project details must reach the project-description field");
const transformedProjectDates = project.rowTransform({ name: "fixture-project", startTime: "2026-07", endTime: "2026-08", startDate: "2026-07-20", endDate: "2026-08-21" });
assert.strictEqual(transformedProjectDates.zhaopinCampusStartDate, "2026-07-20");
assert.strictEqual(transformedProjectDates.zhaopinCampusEndDate, "2026-08-21");
assert(projectLabels.includes("结束日期"), "project sequence must recognize the CDB 结束日期 label");
assert(project.fieldSequence.some((item) => item.type === "zhaopinCampusDate"), "project dates must use precision-aware CDB date handling");
project.fieldSequence.filter((item) => ["name", "zhaopinCampusStartDate", "zhaopinCampusEndDate"].includes(item.field)).forEach((item) => {
  assert.strictEqual(item.zhaopinRepeatLocalBinding, true, `project ${item.field} must bind inside the active project editor`);
  assert.strictEqual(item.coreMatcherFirst, false, `project ${item.field} must prefer the local editor over stale global controls`);
});


const certificate = workflow.steps.find((step) => step.name === "所获专业技术资格证书");
assert(certificate, "certificate section should still be recognized");
assert.strictEqual(certificate.category, "certificates");

const language = workflow.steps.find((step) => step.name === "语言情况");
assert(language, "语言情况 should be recognized from the CDB menu");
assert.strictEqual(language.category, "languageSkills");
assert.strictEqual(language.zhaopinRepeatNavigationAdapter, true, "language should tolerate either a visible editor or an Add-driven repeat editor");
const languageLabels = language.fieldSequence.flatMap((item) => Array.isArray(item.label) ? item.label : [item.label]);
["大学英语四级考试成绩", "大学英语六级考试成绩", "其他英语等级考试"].forEach((label) => {
  assert(languageLabels.includes(label), `CDB language summary should include ${label}`);
});
assert(!languageLabels.includes("外语种类"), "CDB fixed language-summary form must not use the generic language-name selector");
const transformedLanguage = language.rowTransform({
  name: "英语",
  certificateName: "雅思",
  score: "6.5",
  cet4Score: "616",
  cet6Score: "532",
  otherEnglishExam: "IELTS",
  otherEnglishScore: "6.5",
});
assert.strictEqual(transformedLanguage.zhaopinCampusCet4Score, "616");
assert.strictEqual(transformedLanguage.zhaopinCampusCet6Score, "532");
assert.strictEqual(transformedLanguage.zhaopinCampusOtherEnglishExam, "IELTS");
assert.strictEqual(transformedLanguage.zhaopinCampusOtherEnglishScore, "6.5");
const otherExamField = language.fieldSequence.find((item) => item.field === "zhaopinCampusOtherEnglishExam");
assert.strictEqual(otherExamField.verifyDisplayedSelection, true, "IELTS selection must accept a real selected-item readback even when Element clears input.value");
const otherScoreField = language.fieldSequence.find((item) => item.field === "zhaopinCampusOtherEnglishScore");
assert(otherScoreField && otherScoreField.optional !== true, "known IELTS score must not silently disappear after selecting IELTS");
assert.strictEqual(otherScoreField.type, "text");
assert.strictEqual(otherScoreField.coreMatcherFirst, false, "IELTS score is a plain input and must not be reclassified as the neighboring Element select");

const student = workflow.steps.find((step) => step.name === "学生工作");
assert(student, "学生工作 should be recognized");
assert.strictEqual(student.category, "campusLeadership");
assert.strictEqual(student.zhaopinRepeatNavigationAdapter, true);
const studentOrg = student.fieldSequence.find((item) => item.field === "projectName");
assert.strictEqual(studentOrg.optional, true, "CDB student-work section does not always expose organization name, so it must not block later rows");
const studentLabels = student.fieldSequence.flatMap((item) => Array.isArray(item.label) ? item.label : [item.label]);
assert(studentLabels.includes("职务描述"));
assert(studentLabels.includes("开始日期"));
assert(studentLabels.includes("结束日期"));
const transformedStudent = student.rowTransform({ projectName: "fixture-org", title: "干事", startTime: "2025-09", endTime: "2026-04", startDate: "2025-09-01", endDate: "2026-04-30" });
assert.strictEqual(transformedStudent.zhaopinCampusStartDate, "2025-09-01");
assert.strictEqual(transformedStudent.zhaopinCampusEndDate, "2026-04-30");
const studentDescription = student.fieldSequence.find((item) => item.field === "description");
assert(studentDescription && typeof studentDescription.valueTransform === "function", "CDB student-work description should apply the explicit 50-character site policy");
const oldLearningCommitteeDescription = "筹备学习经验交流活动，协调师兄师姐与班级同学；对接教务处，完成学校及学院任务，上报学生学习方面的合理诉求，并提供升学、学习和毕业信息指引。";
const approvedLearningCommitteeDescription = "对接教务处，完成学校及学院任务，上报学生学习方面的合理诉求，并提供升学、学习和毕业信息指引。";
assert.strictEqual(approvedLearningCommitteeDescription.length, 46);
assert.strictEqual(studentDescription.valueTransform(oldLearningCommitteeDescription, { title: "学习委员" }), approvedLearningCommitteeDescription, "only the user-approved Learning Committee Member wording should be shortened");
assert.strictEqual(studentDescription.valueTransform("参与日常采访，与采访对象交流，并完成转稿和信息整合工作。", { title: "干事" }), "参与日常采访，与采访对象交流，并完成转稿和信息整合工作。", "unrelated student-work descriptions must remain unchanged");
const overlongCombinedDescription = "负责粤西地区招生工作，对生源意向进行数据可视化处理，协调招生组师生并与总部沟通，开展舆情监控和招生咨询。；统筹信息处理与沟通协调，成功引导部分粤西地区高质量考生第一志愿报考中国人民大学。";
const existingRoleDescription = "统筹信息处理与沟通协调，成功引导部分粤西地区高质量考生第一志愿报考中国人民大学。";
assert(overlongCombinedDescription.length > 50 && existingRoleDescription.length <= 50);
assert.strictEqual(studentDescription.valueTransform(overlongCombinedDescription, { title: "干事", roleDescription: existingRoleDescription }), existingRoleDescription, "when CDB's 50-character limit is exceeded, an existing canonical 本人职责 may be used without inventing or truncating facts");
assert.strictEqual(studentDescription.valueTransform("这是一个超过五十字但没有可用本人职责的示例文本这是一个超过五十字但没有可用本人职责的示例文本这是一个超过五十字但没有可用本人职责的示例文本", { title: "干事" }).length > 50, true, "without an approved or existing <=50 alternative the adapter must not silently truncate");

const award = workflow.steps.find((step) => step.name === "奖励情况");
assert(award, "奖励情况 should be recognized");
assert.strictEqual(award.category, "awards");
assert.strictEqual(award.zhaopinRepeatNavigationAdapter, true);
const awardLabels = award.fieldSequence.flatMap((item) => Array.isArray(item.label) ? item.label : [item.label]);
assert(awardLabels.includes("获奖日期"));
assert(awardLabels.includes("颁发单位"));
const transformedAward = award.rowTransform({ awardName: "fixture-award", awardTime: "2024-12", awardDate: "2024-12-24" });
assert.strictEqual(transformedAward.zhaopinCampusAwardDate, "2024-12-24");

const family = workflow.steps.find((step) => step.name === "家庭信息");
assert(family, "家庭信息 should be recognized");
assert.strictEqual(family.category, "familyMembers");
assert.strictEqual(family.zhaopinRepeatNavigationAdapter, true);

const specialty = workflow.steps.find((step) => step.name === "个人特长");
assert(specialty, "个人特长 should be recognized");
assert.strictEqual(specialty.category, "basicInfo");
assert.strictEqual(specialty.fieldSequence.length, 1, "personal specialty must not rerun the whole basic-info sequence");
assert.strictEqual(specialty.fieldSequence[0].field, "hobbies");

const adjustment = workflow.steps.find((step) => step.name === "是否服从调剂");
assert(adjustment, "是否服从调剂 should use the explicit job-intention fact");
assert.strictEqual(adjustment.category, "jobIntention");
assert.strictEqual(adjustment.fieldSequence[0].field, "acceptAdjustment");

assert(!workflow.steps.some((step) => step.name === "社会实践经历"), "social practice remains unmapped until a non-duplicating canonical source is confirmed");
assert(!workflow.steps.some((step) => step.name === "高中教育经历"), "high school remains excluded from university rows");
console.log("zhaopin public repeat sections: PASS");
