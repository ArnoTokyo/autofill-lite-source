"use strict";
const fs = require("fs");
const path = require("path");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const 示例资料flow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-示例资料flow.js"), "utf8");

const start = 示例资料flow.indexOf("function findVisibleBankcommResearchDropdown");
const end = 示例资料flow.indexOf("\n  var lastBankcommResearchCustomError", start);
assert(start !== -1 && end > start, "A: Bankcomm research popup resolver missing");
const fn = 示例资料flow.slice(start, end);

// A. Bankcomm currently uses Ant 3/rc-cascader where the portal may it示例资料 be .ant-cascader-menus.
assert(fn.includes('".ant-cascader-menus, "'), "A: legacy Ant cascader menus root not supported");
assert(fn.includes('".ant-cascader-menu"'), "A: legacy direct cascader menu root not supported");

// B. Bind the popup to the active research trigger rather than selecting a global arbitrary portal.
assert(fn.includes('aria-controls'), "B: aria-controls popup association missing");
assert(fn.includes('aria-owns'), "B: aria-owns popup association missing");
assert(fn.includes('trigger.getBoundingClientRect'), "B: trigger-relative popup ranking missing");

// C. The custom footer can live above the .ant-cascader-menus node; reverse-resolve it from the unique checkbox.
assert(fn.includes('label.ant-checkbox-wrapper'), "C: checkbox reverse lookup missing");
assert(fn.includes('checkboxNode.parentElement'), "C: checkbox ancestor popup recovery missing");

// D. All live re-resolution calls in the custom transaction must carry the same trigger ownership.
const customStart = 示例资料flow.indexOf("async function fillBankcommResearchCustomValue");
const customEnd = 示例资料flow.indexOf("\n  // 兴业银行学校名称", customStart);
const customFn = 示例资料flow.slice(customStart, customEnd);
assert(customFn.includes('findVisibleBankcommResearchDropdown(checkboxText, trigger)'), "D: research custom transaction does not bind popup to trigger");
assert(!customFn.includes('findVisibleBankcommResearchDropdown(checkboxText) ||'), "D: legacy unowned popup re-resolution remains");

console.log("bankcomm-research-popup-binding.test.js passed (A-D)");
