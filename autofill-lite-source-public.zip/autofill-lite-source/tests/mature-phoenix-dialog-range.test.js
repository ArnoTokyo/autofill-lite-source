"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const APP = path.resolve(__dirname, "..");
const read = (p) => fs.readFileSync(path.join(APP, p), "utf8");

const templates = read("autofill-plugin/content/config/site-templates.js");
assert(templates.includes('dialogChoiceFallback: true, forceDialogProbe: true'), "Phoenix position must opt into mature dialog fallback");
assert(templates.includes('salaryMode: "monthlyRange"'), "Phoenix expected salary must declare monthly range semantics");

const handler = read("autofill-plugin/content/form-handler.js");
assert(handler.includes("AF.FormHandler.tryFillDialogChoice"), "mature dialog choice bridge must be exposed");
assert(handler.includes(".common-unmodeled-layer:not(.common-unmodeled-layer-hidden)"), "Phoenix overlay must be visible to mature dialog discovery");
assert(handler.includes("var forceProbe = choiceHints.forceProbe === true"), "dialog probing must stay capability-gated");
assert(handler.includes("[role='treeitem']"), "taxonomy tree items must be considered by mature dialog candidate search");

const phoenix = read("autofill-plugin/content/select-adapter/adapters/phoenix.js");
assert(phoenix.includes("normalizePhoenixMonthlySalaryValue"), "monthly salary normalizer missing");
assert(phoenix.includes("findPhoenixRangeListItem"), "mature salary range matcher bridge missing");
assert(phoenix.includes("mature_dialog_choice"), "mature dialog fallback result stage missing");
assert(phoenix.includes("parseableRangeCount"), "safe salary range evidence missing");
assert(phoenix.includes("dialogFallbackHandled"), "safe dialog fallback evidence missing");

const salaryFn = phoenix.match(/function phoenixSalaryUnitHint\(value\) \{[\s\S]*?\n  \}\n\n  function normalizePhoenixMonthlySalaryValue\(value, capability\) \{[\s\S]*?\n  \}/);
assert(salaryFn, "salary normalizer functions not extractable");
const ctx = { AF: { DomUtils: { extractComparableValue(value) {
  if (/24\s*万/.test(String(value))) return { value: 240000, type: "numeric" };
  return null;
} } }, isFinite, Math, String };
vm.createContext(ctx);
vm.runInContext(salaryFn[0] + "\nthis.norm = normalizePhoenixMonthlySalaryValue; this.hint = phoenixSalaryUnitHint;", ctx);
assert.strictEqual(ctx.hint("24万元/年"), "annual");
assert.strictEqual(ctx.norm("24万元/年", { salaryMode: "monthlyRange" }), "20000元/月");
assert.strictEqual(ctx.norm("15000元/月", { salaryMode: "monthlyRange" }), "15000元/月");
assert.strictEqual(ctx.norm("20-30", { salaryMode: "monthlyRange" }), "20-30", "unitless salary must not be guessed");

console.log("mature-phoenix-dialog-range: ok");
