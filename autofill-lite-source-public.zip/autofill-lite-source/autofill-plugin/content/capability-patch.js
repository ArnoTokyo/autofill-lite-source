// content/capability-patch.js — 字段级填写能力补丁解释器。
//
// 该层只解释站点配置中的 `_capabilityPatch.fields`。没有配置或没有精确命中时
// 返回 null，调用方继续执行原有填写逻辑，保证旧站点配置不受影响。
(function () {
  "use strict";

  var AF = (window.AF = window.AF || {});

  function normalizeText(value) {
    return String(value == null ? "" : value).replace(/[\s：:*]/g, "").toLowerCase();
  }

  function asArray(value) {
    if (Array.isArray(value)) return value;
    return value == null || value === "" ? [] : [value];
  }

  function clone(value) {
    if (Array.isArray(value)) return value.map(clone);
    if (!value || Object.prototype.toString.call(value) !== "[object Object]") return value;
    var output = {};
    Object.keys(value).forEach(function (key) {
      if (key === "__proto__" || key === "prototype" || key === "constructor") return;
      output[key] = clone(value[key]);
    });
    return output;
  }

  function matchesRule(rule, context) {
    if (!rule || rule.enabled === false) return false;
    if (rule.category && String(rule.category) !== String(context.category || "")) return false;
    if (rule.fieldKey && String(rule.fieldKey) !== String(context.fieldKey || "")) return false;

    var labels = asArray(rule.labels || rule.label).map(normalizeText).filter(Boolean);
    if (labels.length && labels.indexOf(normalizeText(context.labelText)) === -1) return false;

    var types = asArray(rule.types || rule.type).map(function (item) {
      return String(item || "").toLowerCase();
    }).filter(Boolean);
    if (types.length && types.indexOf(String(context.type || "").toLowerCase()) === -1) return false;
    return true;
  }

  function resolve(config, context) {
    var patch = config && config._capabilityPatch;
    var fields = patch && Array.isArray(patch.fields) ? patch.fields : [];
    if (!fields.length) return null;
    for (var i = fields.length - 1; i >= 0; i--) {
      if (matchesRule(fields[i], context || {})) return clone(fields[i]);
    }
    return null;
  }

  function aliasValue(value, aliases) {
    if (!aliases || value == null || typeof value === "object") return value;
    var text = String(value).trim();
    if (Array.isArray(aliases)) {
      for (var i = 0; i < aliases.length; i++) {
        var item = aliases[i] || {};
        if (normalizeText(item.from) === normalizeText(text)) return item.to;
      }
      return value;
    }
    if (Object.prototype.toString.call(aliases) === "[object Object]") {
      var keys = Object.keys(aliases);
      for (var j = 0; j < keys.length; j++) {
        if (normalizeText(keys[j]) === normalizeText(text)) return aliases[keys[j]];
      }
    }
    return value;
  }

  function transformValue(value, capability) {
    if (!capability) return value;
    var transformed = aliasValue(value, capability.valueAliases);
    var transforms = Array.isArray(capability.valueTransforms) ? capability.valueTransforms : [];
    if (typeof transformed !== "string" && typeof transformed !== "number") return transformed;
    var text = String(transformed);
    transforms.forEach(function (item) {
      if (!item || typeof item.pattern !== "string" || !item.pattern) return;
      try {
        text = text.replace(new RegExp(item.pattern, item.flags || ""), String(item.replacement == null ? "" : item.replacement));
      } catch (e) {}
    });
    return text;
  }

  function pad2(value) {
    return String(Number(value || 0)).padStart(2, "0");
  }

  function formatDateText(value, capability) {
    var text = String(value == null ? "" : value).trim();
    if (!text) return text;
    var currentAliases = asArray(capability && capability.currentValueAliases).concat(["至今", "现在", "当前", "present", "current"]);
    if (currentAliases.some(function (item) { return normalizeText(item) === normalizeText(text); })) return "至今";
    var match = text.match(/(\d{4})(?:\D+(\d{1,2}))?(?:\D+(\d{1,2}))?/);
    if (!match) return text;
    var year = match[1];
    var month = match[2] ? pad2(match[2]) : "";
    var day = match[3] ? pad2(match[3]) : "";
    var format = String(capability && (capability.dateFormat || capability.valueFormat) || "");
    var precision = String(capability && capability.datePrecision || "");
    if (!format) {
      if (precision === "year") format = "YYYY";
      else if (precision === "month") format = "YYYY-MM";
      else if (precision === "day") format = "YYYY-MM-DD";
    }
    if (!format) return text;
    if (!month) month = "01";
    if (!day) day = "01";
    return format
      .replace(/YYYY/g, year)
      .replace(/MM/g, month)
      .replace(/DD/g, day);
  }

  function transformDateValue(value, capability) {
    if (!capability) return value;
    if (value && typeof value === "object" && !Array.isArray(value)) {
      var range = clone(value);
      if (range.startTime != null) range.startTime = formatDateText(transformValue(range.startTime, capability), capability);
      if (range.endTime != null) range.endTime = formatDateText(transformValue(range.endTime, capability), capability);
      if (capability.rangeMode === "singleStart") return range.startTime || "";
      if (capability.rangeMode === "singleEnd") return range.endTime || "";
      return range;
    }
    return formatDateText(transformValue(value, capability), capability);
  }

  function createContext(config, context) {
    var base = context || {};
    var capability = resolve(config, base);
    if (!capability) return null;
    return {
      category: base.category || "",
      fieldKey: base.fieldKey || "",
      labelText: base.labelText || "",
      type: base.type || "",
      capability: capability,
    };
  }

  AF.CapabilityPatch = {
    createContext: createContext,
    normalizeText: normalizeText,
    resolve: resolve,
    transformDateValue: transformDateValue,
    transformValue: transformValue,
  };
})();
