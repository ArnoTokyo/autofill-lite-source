// content/record-graph.js
// Read-only repeat-record structure model for Autofill Lite.
// Mature-first: reuse SiteLoader/experience selectors before generic structural fallback.
// This module never clicks, fills, saves, submits, deletes, uploads, or captures field values.
(function (rootFactory) {
  "use strict";
  var api = rootFactory(typeof window !== "undefined" ? window : globalThis);
  if (typeof window !== "undefined") {
    window.AF = window.AF || {};
    window.AF.RecordGraph = api;
  }
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(function (global) {
  "use strict";

  var VERSION = "1.5.0";
  var SCHEMA_VERSION = 1;
  var CONTROL_SELECTOR = [
    "input:not([type='hidden']):not([type='button']):not([type='submit']):not([type='reset'])",
    "select", "textarea", "[contenteditable='true']", "[contenteditable='']",
    ".ant-select", ".ant-cascader-picker", ".ant-picker", ".el-select", ".el-cascader",
    ".el-date-editor", ".phoenix-select", ".phoenix-date-picker", ".phoenix-radio-group",
    "[role='combobox']", "[role='textbox']", "[role='radiogroup']"
  ].join(",");
  var REPEAT_TITLE_PATTERN = /教育|学习经历|工作经历|实习|项目|语言|外语|学生工作|校园|社会实践|获奖|奖励|荣誉|证书|资格|家庭|亲属|培训|论文|科研|专利|经历/;
  var UNSAFE_ACTION_PATTERN = /删除|移除|提交|投递|申请|下一步|保存|delete|remove|submit|apply|next|save/i;

  function normalizeText(value, max) {
    return String(value || "").replace(/[＊*]/g, "").replace(/[：:]/g, "").replace(/\s+/g, " ").trim().slice(0, Number(max || 100));
  }

  function safeAttr(value, max) {
    var text = normalizeText(value, max || 100);
    if (!text) return "";
    if (/\b(token|session|credential|authorization|cookie)\b/i.test(text)) return "";
    if (/https?:\/\//i.test(text)) {
      try {
        var u = new URL(text, global.location && global.location.href || "https://local.invalid/");
        return u.protocol + "//" + u.host + u.pathname;
      } catch (_) { return text.split(/[?#]/)[0]; }
    }
    return text;
  }

  function safePath(value) {
    try {
      var u = new URL(String(value || ""), global.location && global.location.href || "https://local.invalid/");
      return u.pathname || "/";
    } catch (_) { return String(value || "").split(/[?#]/)[0] || "/"; }
  }

  function hashText(value) {
    var text = String(value || "");
    var hash = 2166136261;
    for (var i = 0; i < text.length; i++) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }

  function stableId(prefix, parts) {
    return prefix + "_" + hashText((parts || []).map(function (part) { return normalizeText(part, 220); }).join("|"));
  }

  function isVisible(element) {
    if (!element || element.isConnected === false) return false;
    try {
      var style = global.getComputedStyle ? global.getComputedStyle(element) : { display: "", visibility: "", opacity: "1" };
      if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) < 0.01) return false;
      var rect = element.getBoundingClientRect ? element.getBoundingClientRect() : { width: 1, height: 1 };
      return Number(rect.width || 0) > 0 || Number(rect.height || 0) > 0;
    } catch (_) { return false; }
  }

  function rectOf(element) {
    try {
      var rect = element.getBoundingClientRect();
      return { x: Math.round(rect.left || rect.x || 0), y: Math.round(rect.top || rect.y || 0), width: Math.round(rect.width || 0), height: Math.round(rect.height || 0) };
    } catch (_) { return { x: 0, y: 0, width: 0, height: 0 }; }
  }

  function selectorText(slot) {
    if (!slot) return "";
    if (typeof slot === "string") return slot;
    return String(slot.class || slot.selector || slot.css || "");
  }

  function resolveMatureHints() {
    var hints = { source: "generic", configName: "", cardSelector: "", addSelector: "", editorGuardSelector: "", sectionSelector: "" };
    try {
      var AF = global.AF || {};
      var loader = AF.SiteLoader || {};
      var builtIn = typeof loader._getConfigForUrl === "function" ? loader._getConfigForUrl(global.location && global.location.href || "") : null;
      var platform = typeof loader._detectSiteType === "function" ? loader._detectSiteType() : null;
      var config = builtIn || platform || null;
      if (!config) return hints;
      hints.source = builtIn ? "built_in_config" : "dom_platform";
      hints.configName = String(config.name || "");
      var experience = config.experience || {};
      hints.cardSelector = String(experience.card && (experience.card.cardSelector || experience.card.selector) || "");
      hints.addSelector = String(experience.add && (experience.add.addButtonSelector || experience.add.selector) || "");
      hints.editorGuardSelector = String(experience.editor && (experience.editor.editModeGuardSelector || experience.editor.guardSelector) || "");
      hints.sectionSelector = String(experience.container && (experience.container.containerSelector || experience.container.selector) || selectorText(config.selectors && config.selectors.container) || "");
    } catch (_) {}
    return hints;
  }

  function categoryHint(title) {
    var text = normalizeText(title, 80);
    if (/教育|学习经历/.test(text)) return "education";
    if (/实习/.test(text)) return "internshipExperience";
    if (/工作经历|任职经历/.test(text)) return "workExperience";
    if (/项目|科研/.test(text)) return "projectExperience";
    if (/学生工作|校园任职|干部/.test(text)) return "campusLeadership";
    if (/校园|社会实践|活动/.test(text)) return "campusActivities";
    if (/语言|外语/.test(text)) return "languageSkills";
    if (/奖励|获奖|荣誉/.test(text)) return "awards";
    if (/证书|资格/.test(text)) return "certificates";
    if (/家庭|亲属/.test(text)) return "familyMembers";
    if (/培训/.test(text)) return "trainingExperience";
    if (/论文/.test(text)) return "publications";
    if (/专利/.test(text)) return "patents";
    return "";
  }

  function safeQueryAll(root, selector) {
    if (!root || !selector || !root.querySelectorAll) return [];
    try { return Array.from(root.querySelectorAll(selector)); } catch (_) { return []; }
  }

  function visibleControls(root) {
    return safeQueryAll(root, CONTROL_SELECTOR).filter(isVisible);
  }

  function findEditAction(root) {
    return safeQueryAll(root, "button,a,[role='button'],[onclick]").filter(isVisible).find(function (el) {
      var text = normalizeText([el.textContent, el.getAttribute && el.getAttribute("aria-label"), el.getAttribute && el.getAttribute("title")].filter(Boolean).join(" "), 80).replace(/\s+/g, "");
      if (!text || UNSAFE_ACTION_PATTERN.test(text)) return false;
      var icon = el.querySelector && el.querySelector('[data-icon*="edit" i],.anticon-edit,[class*="edit" i]');
      return Boolean(icon) || /^(编辑|修改|edit|modify)$/i.test(text);
    }) || null;
  }


  function dedupeNodesByRect(nodes) {
    var kept = [];
    (nodes || []).filter(isVisible).forEach(function (node) {
      var rect = rectOf(node);
      var duplicate = kept.some(function (item) {
        var other = rectOf(item);
        return Math.abs(rect.x - other.x) <= 3 && Math.abs(rect.y - other.y) <= 3 &&
          Math.abs(rect.width - other.width) <= 8 && Math.abs(rect.height - other.height) <= 8;
      });
      if (!duplicate) kept.push(node);
    });
    return kept;
  }

  function resolveOwnership(container, category) {
    if (!container || !container.querySelectorAll) return { source: "none", confidence: 0, cards: [], addActions: [] };
    var hints = resolveMatureHints();
    var cards = [];
    if (hints.cardSelector) cards = deepestUnique(safeQueryAll(container, hints.cardSelector));
    if ((!cards || !cards.length) && /education|workExperience|internshipExperience|projectExperience|languageSkills/.test(String(category || ""))) {
      try {
        var phoenixCards = deepestUnique(safeQueryAll(container, ".sc-khQegj, .ux-standard-form")).filter(function (node) {
          return node.querySelector && node.querySelector(".form-item, .form-item__text, input, textarea, .phoenix-select");
        });
        if (phoenixCards.length) cards = phoenixCards;
      } catch (_) {}
    }
    var addActions = hints.addSelector ? dedupeNodesByRect(safeQueryAll(container, hints.addSelector)) : [];
    return {
      source: cards.length || addActions.length ? "mature_record_graph" : "none",
      confidence: cards.length && hints.cardSelector ? 0.99 : (cards.length ? 0.9 : (addActions.length ? 0.85 : 0)),
      cards: cards || [],
      addActions: addActions || [],
      category: String(category || "")
    };
  }
  function normalizedIdentityText(value) {
    return String(value == null ? "" : value).toLowerCase()
      .replace(/至今|目前|现在|仍在职|在职|当前/g, "至今")
      .replace(/[\s：:，,。.;；、()（）\-_\/\\]/g, "");
  }


  // Build153: one repeat-record identity contract for RecordGraph + ExperienceHandler.
  // Keep this list data-only. It proves ownership/identity but never decides page actions.
  var RUNTIME_IDENTITY_RULES = {
    education: { primary: ["school"], secondary: ["level", "startTime"] },
    workExperience: { primary: ["company"], secondary: ["position", "startTime"] },
    internshipExperience: { primary: ["company"], secondary: ["position", "startTime"] },
    projectExperience: { primary: ["projectName", "name", "title"], secondary: ["role", "startTime"] },
    campusLeadership: { primary: ["projectName", "title"], secondary: ["startTime", "endTime"] },
    campusActivities: { primary: ["activityName", "name", "projectName"], secondary: ["role", "startTime"] },
    trainingExperience: { primary: ["name", "trainingName"], secondary: ["organization", "startTime"] },
    awards: { primary: ["awardName"], secondary: ["awardTime", "awardGrade"] },
    certificates: { primary: ["certificateName", "name"], secondary: ["certificateNo", "obtainedTime", "obtainTime"] },
    publications: { primary: ["paperTitle", "title", "name"], secondary: ["publishTime", "publishYear", "journal"] },
    patents: { primary: ["patentName", "name"], secondary: ["grantDate", "authorizationDate", "patentType"] },
    languageSkills: { primary: ["name", "language"], secondary: ["level", "score", "certificateName"] },
    familyMembers: { primary: ["name"], secondary: ["relationship"], requireSecondary: true }
  };
  var SUPPORTED_REPEAT_CATEGORIES = Object.freeze(Object.keys(RUNTIME_IDENTITY_RULES));

  function supportsRepeatCategory(category) {
    return SUPPORTED_REPEAT_CATEGORIES.indexOf(String(category || "")) !== -1;
  }

  function semanticSectionMatchesCategory(siteConfig, sectionTitle, category) {
    var direct = categoryHint(sectionTitle);
    if (direct) return direct === String(category || "");
    var mappings = siteConfig && siteConfig._aiSemanticPatch && siteConfig._aiSemanticPatch.sectionMappings || [];
    var wanted = normalizeText(sectionTitle, 100).replace(/\s+/g, "");
    return (Array.isArray(mappings) ? mappings : []).some(function (mapping) {
      if (!mapping || String(mapping.category || "") !== String(category || "")) return false;
      var label = normalizeText(mapping.label, 100).replace(/\s+/g, "");
      return !!(wanted && label && (wanted === label || wanted.indexOf(label) !== -1 || label.indexOf(wanted) !== -1));
    });
  }

  function cleanRuntimeControlValue(value) {
    var text = String(value == null ? "" : value).replace(/\s+/g, " ").trim();
    if (/^(请选择|请输入|选择|select|please select|暂无|无)$/i.test(text)) return "";
    return text;
  }

  function readRuntimeControlValue(node) {
    if (!node) return "";
    try {
      var AF = global.AF || {};
      if (AF.FillTrace && typeof AF.FillTrace.readElementValue === "function") {
        var traced = cleanRuntimeControlValue(AF.FillTrace.readElementValue(node));
        if (traced) return traced;
      }
    } catch (_) {}
    try {
      if (node.tagName === "SELECT") {
        var selected = Array.from(node.selectedOptions || []).map(function (option) { return option.textContent || option.value || ""; }).join(" ");
        return cleanRuntimeControlValue(selected);
      }
      if (node.matches && node.matches('input[type="radio"], input[type="checkbox"]')) {
        return node.checked ? cleanRuntimeControlValue(node.value || "true") : "";
      }
      if ("value" in node) return cleanRuntimeControlValue(node.value);
      var inner = node.querySelector && node.querySelector("input:not([type='hidden']), textarea, select");
      if (inner && "value" in inner) return cleanRuntimeControlValue(inner.value);
      return cleanRuntimeControlValue(node.textContent || "");
    } catch (_) { return ""; }
  }

  function nodesForOwnedSelector(container, selector) {
    if (!container || !selector) return [];
    var doc = (container && container.ownerDocument) || global.document;
    if (!doc || !doc.querySelectorAll) return [];
    var nodes = safeQueryAll(doc, selector).filter(function (node) {
      return isVisible(node) && (container === node || (container.contains && container.contains(node)));
    });
    return nodes;
  }

  function firstRecordField(row, keys) {
    for (var i = 0; i < (keys || []).length; i++) {
      var value = row && row[keys[i]];
      if (value != null && String(value).trim()) return { key: keys[i], value: String(value).trim() };
    }
    return null;
  }

  function mappingByKeys(resolvedMappings, keys) {
    for (var i = 0; i < (keys || []).length; i++) {
      var key = keys[i];
      var hit = resolvedMappings.find(function (item) { return item.fieldKey === key; });
      if (hit) return hit;
    }
    return null;
  }

  // Build144: RepeatRecord ownership compares semantic identity, not raw widget text.
  // Enterprise forms often render canonical profile values with site-specific wording
  // (e.g. profile `硕士` vs page `硕士研究生`) or with day precision added/removed.
  // Keep this field-aware and deliberately narrow: it is used only to prove owner
  // identity, never to choose a value to write.
  function canonicalRuntimeIdentityValue(category, fieldKey, value) {
    var text = cleanRuntimeControlValue(value);
    if (!text) return "";
    category = String(category || "");
    fieldKey = String(fieldKey || "");
    if (category === "education" && fieldKey === "level") {
      if (/博士/.test(text)) return "博士";
      if (/硕士|研究生/.test(text)) return "硕士";
      if (/本科|大学|学士/.test(text)) return "本科";
      if (/专科|大专/.test(text)) return "大专";
      if (/高中/.test(text)) return "高中";
      if (/中专|职高|技校/.test(text)) return "中专";
    }
    if (category === "education" && /^(startTime|endTime)$/.test(fieldKey)) {
      var dateMatch = text.match(/((?:19|20)\d{2})\D{0,3}(\d{1,2})/);
      if (dateMatch) return dateMatch[1] + String(Number(dateMatch[2])).padStart(2, "0");
    }
    return normalizedIdentityText(text);
  }

  function runtimeIdentityValuesEqual(category, fieldKey, left, right) {
    var a = canonicalRuntimeIdentityValue(category, fieldKey, left);
    var b = canonicalRuntimeIdentityValue(category, fieldKey, right);
    return !!(a && b && a === b);
  }

  // Build142: controlled ownership bridge for an already-open RepeatRecord editor.
  // Selectors are local FormGraph/review artifacts; AI contributes semantics only.
  // This function is read-only: it never fills, clicks Add/Save, submits, deletes or uploads.
  function resolveRuntimeEditorOwnership(container, category, options) {
    options = options || {};
    category = String(category || "");
    var mappings = (Array.isArray(options.mappings) ? options.mappings : []).filter(function (item) {
      return item && String(item.category || "") === category && item.selector && item.fieldKey;
    });
    var title = String(options.sectionTitle || "");
    if (!container || !isVisible(container)) return { status: "scope_not_visible", confidence: 0, category: category };
    if (!semanticSectionMatchesCategory(options.siteConfig || {}, title, category)) {
      return { status: "section_category_unproven", confidence: 0, category: category };
    }
    if (mappings.length < 2) return { status: "insufficient_semantic_selectors", confidence: 0, category: category };

    var resolved = [];
    var ambiguous = [];
    mappings.forEach(function (mapping) {
      var nodes = nodesForOwnedSelector(container, String(mapping.selector || ""));
      if (nodes.length === 1) resolved.push(Object.assign({}, mapping, { element: nodes[0] }));
      else if (nodes.length > 1) ambiguous.push(String(mapping.fieldKey || mapping.selector || ""));
    });
    if (ambiguous.length) {
      return { status: "selector_ownership_ambiguous", confidence: 0, category: category, ambiguousFields: ambiguous };
    }
    if (resolved.length < 2) {
      return { status: "insufficient_visible_owned_controls", confidence: 0, category: category, resolvedControlCount: resolved.length };
    }

    var identityRule = RUNTIME_IDENTITY_RULES[category] || null;
    if (!identityRule) return { status: "identity_rule_missing", confidence: 0, category: category };
    var primaryMapping = mappingByKeys(resolved, identityRule.primary || []);
    var secondaryMapping = mappingByKeys(resolved, identityRule.secondary || []);
    if (!primaryMapping || (identityRule.requireSecondary && !secondaryMapping)) {
      return { status: "identity_controls_missing", confidence: 0, category: category, resolvedControlCount: resolved.length };
    }

    var currentPrimary = cleanRuntimeControlValue(readRuntimeControlValue(primaryMapping.element));
    var currentSecondary = secondaryMapping ? cleanRuntimeControlValue(readRuntimeControlValue(secondaryMapping.element)) : "";
    // Build143: keep field ownership attached to each observed value. Education and
    // several enterprise forms pre-seed a newly opened editor with deterministic
    // defaults (for example school affiliation or education type). Treating any
    // non-empty default as "partially edited" blocked an otherwise blank editor.
    // We only accept such defaults when every observed value is consistent with
    // the next incomplete profile row; a conflict remains UNSAFE_STOP territory.
    var currentResolvedValues = resolved.map(function (item) {
      return { fieldKey: String(item.fieldKey || ""), value: cleanRuntimeControlValue(readRuntimeControlValue(item.element)) };
    }).filter(function (item) { return item.fieldKey && item.value; });
    var rows = Array.isArray(options.profileRecords) ? options.profileRecords : [];
    if (!rows.length) return { status: "profile_records_empty", confidence: 0, category: category };

    var selectedIndex = -1;
    var ownershipMode = "";
    if (currentPrimary) {
      var primaryKey = primaryMapping.fieldKey;
      var secondaryKey = secondaryMapping && secondaryMapping.fieldKey || "";
      var primaryMatches = [];
      var matches = [];
      rows.forEach(function (row, index) {
        if (!runtimeIdentityValuesEqual(category, primaryKey, row && row[primaryKey], currentPrimary)) return;
        primaryMatches.push(index);
        if (currentSecondary && secondaryKey && !runtimeIdentityValuesEqual(category, secondaryKey, row && row[secondaryKey], currentSecondary)) return;
        matches.push(index);
      });
      if (matches.length !== 1) {
        return {
          status: matches.length ? "record_identity_ambiguous" : "record_identity_not_found",
          confidence: 0,
          category: category,
          matchCount: matches.length,
          identityTrace: {
            primaryFieldKey: String(primaryKey || ""),
            secondaryFieldKey: String(secondaryKey || ""),
            primaryMatchCount: primaryMatches.length,
            secondaryObserved: !!currentSecondary,
            combinedMatchCount: matches.length
          }
        };
      }
      selectedIndex = matches[0];
      ownershipMode = "identity_match";
    } else {
      var remaining = [];
      for (var rowIndex = 0; rowIndex < rows.length; rowIndex++) {
        var completed = false;
        try { completed = typeof options.isRecordCompleted === "function" && options.isRecordCompleted(rowIndex, rows[rowIndex]) === true; } catch (_) {}
        if (!completed) remaining.push(rowIndex);
      }
      if (!remaining.length) return { status: "all_profile_records_completed", confidence: 0.95, category: category };
      selectedIndex = remaining[0];
      if (currentResolvedValues.length) {
        var targetRow = rows[selectedIndex] || {};
        var conflicts = currentResolvedValues.filter(function (item) {
          var expected = canonicalRuntimeIdentityValue(category, item.fieldKey, targetRow && targetRow[item.fieldKey]);
          var observed = canonicalRuntimeIdentityValue(category, item.fieldKey, item.value);
          return !expected || !observed || expected !== observed;
        });
        if (conflicts.length) {
          return {
            status: "partial_editor_identity_missing",
            confidence: 0,
            category: category,
            nextRecordIndex: selectedIndex,
            conflictingFields: conflicts.map(function (item) { return item.fieldKey; })
          };
        }
        ownershipMode = "blank_identity_next_record_defaults_consistent";
      } else {
        ownershipMode = "blank_editor_next_record";
      }
    }

    return {
      status: "owned",
      source: "graph_runtime_single_editor",
      confidence: ownershipMode === "identity_match" ? 0.99 : (ownershipMode === "blank_identity_next_record_defaults_consistent" ? 0.94 : 0.93),
      category: category,
      recordIndex: selectedIndex,
      ownershipMode: ownershipMode,
      editorScope: container,
      mappings: resolved,
      resolvedControlCount: resolved.length,
      identityFieldKeys: {
        primary: primaryMapping && primaryMapping.fieldKey || "",
        secondary: secondaryMapping && secondaryMapping.fieldKey || "",
        requireSecondary: !!identityRule.requireSecondary
      },
      safety: { executeActions: false, saveAllowed: false, addAllowed: false, submitAllowed: false }
    };
  }

  function recordRuntimeText(node) {
    if (!node) return "";
    var text = String(node.innerText || node.textContent || "");
    var values = safeQueryAll(node, "input,textarea,select").filter(isVisible).map(function (control) {
      if (control.tagName === "SELECT") return Array.from(control.selectedOptions || []).map(function (option) { return option.textContent || option.value || ""; }).join(" ");
      return control.value || "";
    }).join(" ");
    return normalizedIdentityText(text + " " + values);
  }

  function resolveIdentityCard(cards, primaryValue, secondaryValue) {
    cards = (cards || []).filter(Boolean);
    var primary = normalizedIdentityText(primaryValue);
    var secondary = normalizedIdentityText(secondaryValue);
    if (!primary || primary.length < 2) return { status: "no_identity", card: null, primaryMatches: 0, secondaryMatches: 0 };
    var primaryMatches = cards.filter(function (card) { return recordRuntimeText(card).indexOf(primary) !== -1; });
    if (primaryMatches.length === 1) return { status: "primary_unique", card: primaryMatches[0], primaryMatches: 1, secondaryMatches: secondary ? (recordRuntimeText(primaryMatches[0]).indexOf(secondary) !== -1 ? 1 : 0) : 0 };
    if (primaryMatches.length > 1 && secondary) {
      var secondaryMatches = primaryMatches.filter(function (card) { return recordRuntimeText(card).indexOf(secondary) !== -1; });
      if (secondaryMatches.length === 1) return { status: "primary_secondary_unique", card: secondaryMatches[0], primaryMatches: primaryMatches.length, secondaryMatches: 1 };
      return { status: "ambiguous", card: null, primaryMatches: primaryMatches.length, secondaryMatches: secondaryMatches.length };
    }
    if (primaryMatches.length > 1) return { status: "ambiguous", card: null, primaryMatches: primaryMatches.length, secondaryMatches: 0 };
    return { status: "not_found", card: null, primaryMatches: 0, secondaryMatches: 0 };
  }

  function deepestUnique(nodes) {
    var unique = [];
    nodes.forEach(function (node) { if (node && unique.indexOf(node) < 0 && isVisible(node)) unique.push(node); });
    return unique.filter(function (candidate) {
      return !unique.some(function (other) { return other !== candidate && candidate.contains && candidate.contains(other); });
    });
  }

  function resolveSectionElement(section, root, doc) {
    if (!section) return null;
    var selector = String(section.selectorHint || "");
    if (selector && doc && doc.querySelectorAll) {
      try {
        var hits = Array.from(doc.querySelectorAll(selector)).filter(function (node) { return !root || root === node || (root.contains && root.contains(node)); });
        if (hits.length === 1) return hits[0];
        if (hits.length > 1 && section.rect) {
          hits.sort(function (a, b) {
            var ar = rectOf(a), br = rectOf(b);
            return Math.abs(ar.y - Number(section.rect.y || 0)) - Math.abs(br.y - Number(section.rect.y || 0));
          });
          return hits[0];
        }
      } catch (_) {}
    }
    return root || (doc && doc.body) || null;
  }

  function rowsWithinCard(formSection, cardEl) {
    if (!formSection || !Array.isArray(formSection.rows) || !cardEl) return [];
    var cardRect = rectOf(cardEl);
    return formSection.rows.filter(function (row) {
      var rect = row && row.rect || {};
      var cx = Number(rect.x || 0) + Number(rect.width || 0) / 2;
      var cy = Number(rect.y || 0) + Number(rect.height || 0) / 2;
      return cx >= cardRect.x - 3 && cx <= cardRect.x + cardRect.width + 3 && cy >= cardRect.y - 3 && cy <= cardRect.y + cardRect.height + 3;
    });
  }

  function splitRowsByRepeatedAnchor(rows) {
    rows = Array.isArray(rows) ? rows : [];
    if (rows.length < 4) return [];
    var positions = {};
    rows.forEach(function (row, index) {
      var label = normalizeText(row && row.label, 80);
      if (!label) return;
      if (!positions[label]) positions[label] = [];
      positions[label].push(index);
    });
    var anchors = Object.keys(positions).filter(function (label) { return positions[label].length >= 2; }).sort(function (a, b) {
      return positions[a][0] - positions[b][0] || positions[b].length - positions[a].length;
    });
    if (!anchors.length) return [];
    var starts = positions[anchors[0]].slice();
    if (starts[0] !== 0) return [];
    var groups = [];
    for (var i = 0; i < starts.length; i++) {
      var end = i + 1 < starts.length ? starts[i + 1] : rows.length;
      var part = rows.slice(starts[i], end);
      if (part.length < 2) return [];
      groups.push(part);
    }
    return groups.length >= 2 ? groups : [];
  }

  function recordModel(sectionId, index, role, rows, cardEl, source) {
    rows = Array.isArray(rows) ? rows : [];
    var labels = [];
    rows.forEach(function (row) {
      var label = normalizeText(row && row.label, 80);
      if (label && labels.indexOf(label) < 0) labels.push(label);
    });
    var controls = cardEl ? visibleControls(cardEl) : [];
    var editAction = cardEl ? findEditAction(cardEl) : null;
    return {
      recordId: stableId("rec", [sectionId, role, index, rows.map(function (r) { return r && r.rowId || ""; }).join(",")]),
      role: role,
      source: source,
      index: index,
      controlCount: cardEl ? controls.length : rows.reduce(function (sum, row) { return sum + Number(row && row.controlCount || 0); }, 0),
      rowCount: rows.length,
      rowLabels: labels.slice(0, 24),
      hasEditAction: !!editAction,
      rect: cardEl ? rectOf(cardEl) : null
    };
  }

  function scan(root, options) {
    options = options || {};
    var doc = options.document || (root && root.ownerDocument) || global.document;
    root = root || (doc && doc.body);
    var formGraph = options.formGraph || (global.AF && global.AF.FormGraph && typeof global.AF.FormGraph.scan === "function" ? global.AF.FormGraph.scan(root, { document: doc }) : null);
    var hints = resolveMatureHints();
    var groups = [];
    var totals = { groups: 0, records: 0, savedRecords: 0, editorRecords: 0, addActions: 0 };
    var sections = formGraph && Array.isArray(formGraph.sections) ? formGraph.sections : [];

    sections.forEach(function (section) {
      var title = normalizeText(section && section.title, 80);
      var category = categoryHint(title);
      if (!category && !REPEAT_TITLE_PATTERN.test(title)) return;
      var sectionEl = resolveSectionElement(section, root, doc);
      if (!sectionEl) return;
      var cards = [];
      if (hints.cardSelector) {
        cards = deepestUnique(safeQueryAll(sectionEl, hints.cardSelector));
        try { if (sectionEl.matches && sectionEl.matches(hints.cardSelector)) cards = deepestUnique([sectionEl].concat(cards)); } catch (_) {}
      }

      var records = [];
      if (cards.length) {
        cards.forEach(function (card, index) {
          var rows = rowsWithinCard(section, card);
          var controls = visibleControls(card);
          var role = controls.length ? "editor_record" : "saved_record";
          records.push(recordModel(section.sectionId, index, role, rows, card, "mature_card_selector"));
        });
      } else {
        var rowGroups = splitRowsByRepeatedAnchor(section.rows || []);
        if (rowGroups.length) {
          rowGroups.forEach(function (rows, index) {
            records.push(recordModel(section.sectionId, index, "editor_record", rows, null, "repeated_row_signature"));
          });
        } else if (Number(section.controlCount || 0) > 0) {
          records.push(recordModel(section.sectionId, 0, "editor_record", section.rows || [], sectionEl, "repeat_section_surface"));
        }
      }

      var addNodes = hints.addSelector ? dedupeNodesByRect(safeQueryAll(sectionEl, hints.addSelector)) : [];
      var addActions = addNodes.filter(function (node) {
        var text = normalizeText(node.textContent, 60);
        return !UNSAFE_ACTION_PATTERN.test(text) || /添加|新增|增加|add/i.test(text);
      }).slice(0, 8).map(function (node, index) {
        return { actionId: stableId("act", [section.sectionId, "add", index]), role: "add_action", source: "mature_add_selector", rect: rectOf(node) };
      });

      if (!records.length && !addActions.length) return;
      records.forEach(function (record) {
        totals.records += 1;
        if (record.role === "saved_record") totals.savedRecords += 1;
        if (record.role === "editor_record") totals.editorRecords += 1;
      });
      totals.addActions += addActions.length;
      groups.push({
        groupId: stableId("grp", [section.sectionId, title, category]),
        sectionId: section.sectionId,
        sectionTitle: title,
        categoryHint: category,
        source: cards.length ? "mature_experience_config" : "form_graph_structure",
        recordCount: records.length,
        savedRecordCount: records.filter(function (record) { return record.role === "saved_record"; }).length,
        editorRecordCount: records.filter(function (record) { return record.role === "editor_record"; }).length,
        addActionCount: addActions.length,
        records: records,
        actions: addActions
      });
    });

    totals.groups = groups.length;
    return {
      schemaType: "autofill-lite-record-graph",
      schemaVersion: SCHEMA_VERSION,
      graphVersion: VERSION,
      page: { hostname: safeAttr(global.location && global.location.hostname, 120), pathname: safePath(global.location && global.location.href || "/") },
      totals: totals,
      groups: groups,
      structureHints: {
        source: hints.source,
        configName: safeAttr(hints.configName, 80),
        matureCardSelectorAvailable: !!hints.cardSelector,
        matureAddSelectorAvailable: !!hints.addSelector,
        matureEditorGuardAvailable: !!hints.editorGuardSelector
      },
      safety: {
        currentValuesIncluded: false,
        arbitraryRecordTextIncluded: false,
        profileValuesIncluded: false,
        pageActionsExecuted: false,
        addSaveSubmitDeleteUploadExecuted: false
      }
    };
  }

  return {
    version: VERSION,
    schemaVersion: SCHEMA_VERSION,
    scan: scan,
    resolveOwnership: resolveOwnership,
    resolveIdentityCard: resolveIdentityCard,
    resolveRuntimeEditorOwnership: resolveRuntimeEditorOwnership,
    // Execution bridge contract: RepeatRecord may consume ownership hints,
    // but RecordGraph itself remains read-only and never executes actions.
    buildExecutionBridge: function (graph) {
      var groups = (graph && graph.groups) || [];
      return groups.map(function (group) {
        return {
          groupId: group.groupId,
          categoryHint: group.categoryHint || "",
          ownershipKey: String(group.categoryHint || "repeat-record"),
          // Build114: repeat-record ownership cache contract.
          // Keep the graph read-only; execution layer owns actions.
          ownershipSupported: supportsRepeatCategory(group.categoryHint),
          recordCount: Number(group.recordCount || 0),
          savedRecordCount: Number(group.savedRecordCount || 0),
          editorRecordCount: Number(group.editorRecordCount || 0),
          addActionCount: Number(group.addActionCount || 0),
          ownershipConfidence: group.source === "mature_experience_config" ? 0.95 : 0.80,
          safety: {
            executeActions: false,
            saveAllowed: false,
            submitAllowed: false
          }
        };
      });
    },
    categoryHint: categoryHint,
    identityRules: RUNTIME_IDENTITY_RULES,
    supportedCategories: SUPPORTED_REPEAT_CATEGORIES,
    supportsCategory: supportsRepeatCategory,
    __test: {
      normalizeText: normalizeText,
      stableId: stableId,
      categoryHint: categoryHint,
      splitRowsByRepeatedAnchor: splitRowsByRepeatedAnchor,
      dedupeNodesByRect: dedupeNodesByRect
    }
  };
});
