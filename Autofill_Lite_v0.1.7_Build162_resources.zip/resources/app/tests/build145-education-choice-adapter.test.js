"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
assert(/const BUILD_ID = "202609\d{2}-.*-(?:14[5-9]|1[5-9]\d|[2-9]\d{2,})";/.test(main), "Build145+ compatible build ID missing");
assert(main.includes('20260918-education-degree-variants-145'), "existing portable profiles need the Build145 degree migration");

const formSource = fs.readFileSync(path.join(root, "autofill-plugin", "content", "form-handler.js"), "utf8");
assert(formSource.includes('capability.matchMode = "exact"'), "education choices must use exact option matching");
assert(formSource.includes('capability.adapter = "custom"'), "unknown visual dropdowns must fall back to the mature custom adapter");
assert(formSource.includes('rowData && rowData.degreeDetailed'), "detailed degree must be preferred");
assert(formSource.includes('rowData && rowData.degreeSimple'), "simple degree fallback must be retained");

const customSource = fs.readFileSync(path.join(root, "autofill-plugin", "content", "select-adapter", "adapters", "custom.js"), "utf8");
assert(customSource.includes("findPlainPopupWithExactOption"), "plain popup exact-option fallback missing");

const { loadProfile } = require(path.join(root, "profile-adapter.js"));
const profile = loadProfile(path.join(root, "defaults", "candidate-profile-merged.json"));
assert.strictEqual(profile.education[0].degreeDetailed, "经济学硕士");
assert.strictEqual(profile.education[0].degreeSimple, "硕士");
assert.strictEqual(profile.education[1].degreeDetailed, "经济学学士");
assert.strictEqual(profile.education[1].degreeSimple, "学士");

global.location = {
  href: "https://zhaopin.cnpc.com.cn/web/createResume.html",
  hostname: "zhaopin.cnpc.com.cn",
  pathname: "/web/createResume.html"
};
global.getComputedStyle = () => ({ display: "block", visibility: "visible", opacity: "1" });
global.document = { body: { click() {} } };
global.window = {
  location: global.location,
  AF: {
    CheckpointCore: {
      recordFingerprint(row) { return [row && row.school, row && row.level, row && row.startTime].join("|"); }
    },
    DomUtils: {
      isElementVisible() { return true; },
      isDateValue() { return false; },
      isDatePicker() { return false; },
      isSearchSelect() { return false; },
      isNormalSelect() { return false; }
    },
    Utils: { async sleep() {} },
    FillTrace: {
      setFieldContext() {},
      event() {},
      readElementValue(element) { return String(element && element.value || ""); }
    },
    SelectAdapter: {
      _registry: { custom: true },
      detectType() { return null; }
    }
  }
};

const RecordGraph = require(path.join(root, "autofill-plugin", "content", "record-graph.js"));
window.AF.RecordGraph = RecordGraph;
require(path.join(root, "autofill-plugin", "content", "form-handler.js"));
const AF = window.AF;

function fieldNode(value) {
  return {
    tagName: "INPUT",
    value: value || "",
    isConnected: true,
    getBoundingClientRect() { return { width: 180, height: 30, left: 100, top: 100, bottom: 130 }; },
    matches() { return false; },
    querySelector() { return null; }
  };
}
function actionNode(text) {
  return {
    textContent: text,
    innerText: text,
    value: "",
    disabled: false,
    isConnected: true,
    getBoundingClientRect() { return { width: 120, height: 30, left: 0, top: 0 }; },
    getAttribute() { return ""; }
  };
}

const rows = [{
  school: "中国人民大学",
  level: "硕士",
  degree: "硕士",
  degreeDetailed: "经济学硕士",
  degreeSimple: "硕士",
  startTime: "2025-09-01"
}];
const config = {
  _aiSemanticPatch: {
    fieldMappings: [
      { fieldId: "e-school", label: "毕业院校" },
      { fieldId: "e-level", label: "学历" },
      { fieldId: "e-degree", label: "学位" }
    ]
  }
};
const dataMatcher = {
  resumeData: { education: rows },
  getCategoryByTitle() { return { category: "education", type: "array", data: rows }; }
};

(async () => {
  AF.RuntimeSemanticPatch = {
    hostname: location.hostname,
    pathname: location.pathname,
    recordSelectorMappings: [
      // Deliberately say text: Build145 must still route these two choice fields
      // through SelectAdapter instead of treating the visible input as free text.
      { fieldId: "e-school", category: "education", fieldKey: "school", selector: "#school", controlType: "text" },
      { fieldId: "e-level", category: "education", fieldKey: "level", selector: "#level", controlType: "native-select" },
      { fieldId: "e-degree", category: "education", fieldKey: "degree", selector: "#degree", controlType: "text" }
    ]
  };

  const school = fieldNode("中国人民大学");
  const level = fieldNode("硕士研究生");
  const degree = fieldNode("哲学硕士");
  const save = actionNode("保存教育背景");
  const selectorMap = { "#school": [school], "#level": [level], "#degree": [degree] };
  const doc = { querySelectorAll(selector) { return selectorMap[selector] || []; } };
  const container = {
    ownerDocument: doc,
    isConnected: true,
    getBoundingClientRect() { return { width: 700, height: 500, left: 0, top: 0 }; },
    contains(candidate) { return [school, level, degree, save].includes(candidate); },
    querySelectorAll(selector) { return selector.includes("button") ? [save] : []; }
  };
  [school, level, degree, save].forEach((node) => { node.ownerDocument = doc; });

  const handler = new AF.FormHandler({ config, findContainerByTitle() { return container; } }, dataMatcher);
  handler.recordCheckpointRuntime = {
    shouldSkip() { return false; },
    async pause() { return {}; }
  };
  handler.fieldCheckpointRuntime = { async pause() { throw new Error("unexpected FIELD pause"); } };

  const calls = [];
  AF.FormHandler.fillFormElement = async function (element, value, type, context) {
    calls.push({ element, value: String(value), type, context });
    element.value = String(value);
    return true;
  };

  const result = await handler.fillExperience({}, "教育背景", {});
  assert.strictEqual(result, false, "manual Save checkpoint should keep the run partial");
  assert.strictEqual(handler.lastExperienceResult.ownerStatus, "owned");
  assert.strictEqual(handler.lastExperienceResult.manualSavePending, true);

  const schoolCall = calls.find((item) => item.element === school);
  const degreeCall = calls.find((item) => item.element === degree);
  assert(schoolCall, "school should be filled");
  assert(degreeCall, "degree should be filled");
  assert.strictEqual(schoolCall.type, "select", "school must be routed as a choice control");
  assert.strictEqual(schoolCall.value, "中国人民大学");
  assert.strictEqual(degreeCall.type, "select", "degree must be routed as a choice control");
  assert.strictEqual(degreeCall.value, "经济学硕士", "detailed degree must be attempted before the simple degree");
  assert.strictEqual(degreeCall.context.capability.matchMode, "exact");
  assert.strictEqual(degreeCall.context.capability.fallback, "leaveEmpty");
  assert.strictEqual(degreeCall.context.capability.forceAdapter, true);
  assert.strictEqual(degreeCall.context.capability.adapter, "custom");
  assert.strictEqual(degree.value, "经济学硕士");

  console.log("build145-education-choice-adapter.test.js PASS");
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
