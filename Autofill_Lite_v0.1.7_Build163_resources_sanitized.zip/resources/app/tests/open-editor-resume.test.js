"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const 示例资料flow = fs.readFileSync(path.join(root, "autofill-plugin", "content", "special-site-示例资料flow.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");

assert(示例资料flow.includes("function analyzedBatchSaveFindOpenEditor"), "save batch must be able to adopt a visible pre-opened editor");
assert(示例资料flow.includes('acquisition: "adopted_existing_editor"'), "adopted-editor acquisition trace missing");
assert(示例资料flow.includes('trace.editorAcquisition = opened.acquisition'), "save trace must expose editor acquisition path");
assert(示例资料flow.includes("existingEditorFieldMatchCount"), "save trace must expose matched visible editor fields");
assert(示例资料flow.includes("analyzedBatchPreviewAwardNameAliases(row.awardName)"), "award identity should accept the normalized fixed-list category as an alias");
console.log("open editor resume test: PASS");
