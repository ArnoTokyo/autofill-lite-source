// Autofill Lite core extraction from Bankcomm experiments
// Build94: reusable primitives only. Site-specific selectors/示例资料flow are not included.
(function(global){
  const BankcommLessons = {
    manualCheckpoint: {
      resolvedBy: ['record_identity','saved_state_probe'],
      rule: 'manual prerequisite records must not be counted as profile-managed 示例资料 records'
    },
    示例资料Identity(record, profileRecord){
      if (!record || !profileRecord) return false;
      const keys=['school','degree','major','startDate','endDate'];
      let score=0;
      for (const k of keys) if (record[k] && profileRecord[k] && String(record[k]).includes(String(profileRecord[k]))) score++;
      return score>=2;
    },
    normalizeChoice(v){
      return String(v||'').trim().replace('其它','其他');
    },
    shouldAdoptExistingEditor(editor){
      if(!editor) return false;
      return !editor.savedRecord && !!editor.editableControls;
    }
  };
  if(typeof module!=='undefined') module.exports=BankcommLessons;
  global.AutofillBankcommLessons=BankcommLessons;
})(typeof window!=='undefined'?window:globalThis);
