"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");

global.window = { AF: {} };
const source = fs.readFileSync(path.join(__dirname, "..", "autofill-plugin", "content", "field-dictionary.js"), "utf8");
new Function(source)();

const d = window.AF.FieldDictionary;
assert(d && d.basicInfo && d.education && d.languageSkills && d.campusLeadership);

assert(d.basicInfo.fields.idType.includes("证件号码类型"));
assert(d.basicInfo.fields.currentAddress.includes("当前所处地"));
assert(d.basicInfo.fields.qq.includes("QQ号"));
assert(d.basicInfo.fields.writtenExamCity.includes("请选择参加笔试的城市"));

assert(d.education.fields.schoolAffiliation.includes("办学属地"));
assert(d.education.fields.integratedTraining.includes("是否贯通式培养"));
assert(d.education.fields.majorCategory.includes("学科属性"));
assert(d.education.fields.gpa.includes("个人绩点"));
assert(d.education.fields.gpaTotal.includes("满绩绩点"));
assert(d.education.fields.classRank.includes("年级排名"));
assert(d.education.fields.schoolLocation.includes("目前就读地"));

assert(d.languageSkills.fields.cet4Score.includes("大学英语四级考试成绩"));
assert(d.languageSkills.fields.cet6Score.includes("大学英语六级考试成绩"));
assert(d.languageSkills.fields.otherEnglishExam.includes("其他英语等级考试"));
assert(d.languageSkills.fields.otherEnglishScore.includes("其他英语等级考试成绩"));
assert(d.languageSkills.fields.speakingListening.includes("英语口语水平"));

assert(d.campusLeadership.fields.startTime.includes("开始日期"));
assert(d.campusLeadership.fields.endTime.includes("结束日期"));
assert(d.campusLeadership.fields.description.includes("职务描述"));

assert(d.internshipExperience.fields.company.includes("实习公司"));
assert(d.internshipExperience.fields.detailedContent.includes("描述内容"));
assert(d.projectExperience.fields.name.includes("项目名称（含校园实践）"));
assert(d.projectExperience.fields.details.includes("描述内容"));

console.log("AI review contract aliases regression: PASS");
