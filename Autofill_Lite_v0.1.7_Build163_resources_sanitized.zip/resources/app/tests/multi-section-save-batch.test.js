"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const 示例资料flow = fs.readFileSync(path.join(root, "autofill-plugin", "content", "special-site-示例资料flow.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const preload = fs.readFileSync(path.join(root, "ui-preload.js"), "utf8");
const renderer = fs.readFileSync(path.join(root, "renderer.js"), "utf8");
const index = fs.readFileSync(path.join(root, "index.html"), "utf8");

assert(示例资料flow.includes("async function runAnalyzedResumeSectionSaveBatch"), "batch save runtime missing");
assert(示例资料flow.includes("async function analyzedBatchSaveOneRecord"), "per-record save transaction missing");
assert(示例资料flow.includes("analyzedBatchSaveIdentityPresent"), "batch save must dedupe by record identity");
assert(示例资料flow.includes("findAnalyzedNavigationSaveSuccessFeedback"), "batch save must verify save feedback");
assert(示例资料flow.includes("closeAnalyzedNavigationSaveSuccessModal"), "batch save must close verified success modal");
assert(示例资料flow.includes("runAnalyzedResumeSectionSaveBatch: runAnalyzedResumeSectionSaveBatch"), "batch save runtime must be exported");
assert(示例资料flow.includes("radio_option_ambiguous"), "radio safety guard must remain present");
assert(示例资料flow.includes("wantedBool !== null"), "boolean radio values should resolve 1/0 or yes/no safely");

const saveStart = 示例资料flow.indexOf("async function runAnalyzedResumeSectionSaveBatch");
const saveEnd = 示例资料flow.indexOf("async function runAnalyzedEducationRecordPreviewFill", saveStart);
const saveSource = 示例资料flow.slice(saveStart, saveEnd > saveStart ? saveEnd : undefined);
assert(saveSource.includes('trace.result = "complete"'), "batch save needs explicit completion state");
assert(saveSource.includes('trace.result = "stopped"'), "batch save must stop on unsafe/failed record transaction");
assert(saveSource.includes('finalSubmitExecuted: false'), "batch save must never final-submit resume");

assert(main.includes('ipcMain.handle("lite:save-resume-sections"'), "main batch save handler missing");
assert(main.includes('kind: "resume_section_save_batch"'), "batch save diagnostic kind missing");
assert(preload.includes("saveResumeSections"), "preload batch save API missing");
assert(renderer.includes("saveResumeSections"), "renderer batch save action missing");
assert(!index.includes('id="multiSectionSave"'), "Build160 removes the manual batch-save toolbar entry");
assert(!index.includes('id="experimentMenu"'), "Build160 removes the development experiment submenu");
console.log("multi-section save batch test: PASS");
