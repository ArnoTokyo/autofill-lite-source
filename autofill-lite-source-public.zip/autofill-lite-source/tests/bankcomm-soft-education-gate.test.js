"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const workflow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-workflow.js"), "utf8");
const privateSites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");

assert(privateSites.includes('id: "bankcomm-recruitment"'), "Bankcomm workflow missing");
assert(privateSites.includes('rowsValidator: validateBankcommEducationRows'), "Bankcomm education validator missing");
assert(privateSites.includes('rowsValidationFailureMode: "manual_checkpoint"'), "Bankcomm education validator must be section-scoped");
assert(workflow.includes('step.rowsValidationFailureMode === "skip_step" || step.rowsValidationFailureMode === "manual_checkpoint"'), "generic resumable rows validation path missing");
assert(workflow.includes('__afRowsValidationError'), "soft rows validation metadata missing");
assert(workflow.includes('validationBlocked: true'), "soft validation decision should be surfaced as blocked/review state");
assert(privateSites.includes('交通银行要求从高中填写，但当前简历没有高中/中专教育经历'), "Bankcomm high-school requirement should remain explicit");
console.log("bankcomm-soft-education-gate.test.js PASS");
