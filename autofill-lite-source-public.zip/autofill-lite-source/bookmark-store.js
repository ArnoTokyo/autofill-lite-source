"use strict";

const { randomUUID } = require("crypto");

const LIBRARY_VERSION = 2;
const ROOT_ID = "root";

function nowIso() {
  return new Date().toISOString();
}

function cleanName(value, fallback = "未命名") {
  const text = String(value == null ? "" : value).replace(/\s+/g, " ").trim();
  return (text || fallback).slice(0, 200);
}

function cleanFolderName(value) {
  return cleanName(value, "新建文件夹").slice(0, 80);
}

function cleanStatus(value) {
  return String(value == null ? "" : value).replace(/\s+/g, " ").trim().slice(0, 120);
}

function cleanUrl(value) {
  const raw = String(value == null ? "" : value).trim();
  if (!raw) throw new Error("网址不能为空");
  let parsed;
  try { parsed = new URL(raw); } catch (_) { throw new Error("网址格式无效"); }
  if (!/^https?:$/.test(parsed.protocol)) throw new Error("仅支持 http/https 网址");
  return parsed.toString().slice(0, 4096);
}

function createEmptyLibrary() {
  return {
    version: LIBRARY_VERSION,
    updatedAt: nowIso(),
    root: { id: ROOT_ID, type: "folder", name: "岗位库", children: [] }
  };
}

function normalizeNode(node, depth = 0) {
  if (!node || typeof node !== "object") return null;
  const type = node.type === "bookmark" ? "bookmark" : "folder";
  if (type === "bookmark") {
    try {
      return {
        id: String(node.id || randomUUID()),
        type: "bookmark",
        name: cleanName(node.name, "未命名岗位"),
        url: cleanUrl(node.url),
        status: cleanStatus(node.status),
        createdAt: String(node.createdAt || nowIso()),
        updatedAt: String(node.updatedAt || node.createdAt || nowIso())
      };
    } catch (_) {
      return null;
    }
  }
  if (depth > 20) return null;
  const children = Array.isArray(node.children)
    ? node.children.map((child) => normalizeNode(child, depth + 1)).filter(Boolean)
    : [];
  return {
    id: String(node.id || randomUUID()),
    type: "folder",
    name: cleanFolderName(node.name),
    children
  };
}

function normalizeLibrary(input) {
  const base = input && typeof input === "object" ? input : {};
  const root = normalizeNode(base.root || createEmptyLibrary().root, 0);
  const safeRoot = root && root.type === "folder" ? root : createEmptyLibrary().root;
  safeRoot.id = ROOT_ID;
  safeRoot.name = "岗位库";
  return {
    version: LIBRARY_VERSION,
    updatedAt: String(base.updatedAt || nowIso()),
    root: safeRoot
  };
}

function cloneLibrary(library) {
  return normalizeLibrary(JSON.parse(JSON.stringify(normalizeLibrary(library))));
}

function findInDoc(doc, id) {
  const target = String(id || "");
  if (!target) return { node: null, parent: null };
  if (target === ROOT_ID) return { node: doc.root, parent: null };
  let found = null;
  const walk = (folder) => {
    if (found || !folder || folder.type !== "folder") return;
    for (const child of folder.children || []) {
      if (child.id === target) {
        found = { node: child, parent: folder };
        return;
      }
      if (child.type === "folder") walk(child);
    }
  };
  walk(doc.root);
  return found || { node: null, parent: null };
}

function findNodeWithParent(library, id) {
  const doc = normalizeLibrary(library);
  const found = findInDoc(doc, id);
  return { doc, node: found.node, parent: found.parent };
}

function findFolderInDoc(doc, id) {
  const found = findInDoc(doc, id || ROOT_ID);
  if (!found.node || found.node.type !== "folder") throw new Error("目标文件夹不存在");
  return found.node;
}

function addFolder(library, parentId, name, idFactory = randomUUID) {
  const doc = cloneLibrary(library);
  const parent = findFolderInDoc(doc, parentId || ROOT_ID);
  const folder = {
    id: String(idFactory()),
    type: "folder",
    name: cleanFolderName(name),
    children: []
  };
  parent.children.push(folder);
  doc.updatedAt = nowIso();
  return { library: doc, node: folder };
}

function addBookmark(library, parentId, payload, idFactory = randomUUID) {
  const doc = cloneLibrary(library);
  const parent = findFolderInDoc(doc, parentId || ROOT_ID);
  const stamp = nowIso();
  const bookmark = {
    id: String(idFactory()),
    type: "bookmark",
    name: cleanName(payload && payload.name, "未命名岗位"),
    url: cleanUrl(payload && payload.url),
    status: cleanStatus(payload && payload.status),
    createdAt: stamp,
    updatedAt: stamp
  };
  parent.children.push(bookmark);
  doc.updatedAt = stamp;
  return { library: doc, node: bookmark };
}

function updateNode(library, id, payload) {
  const doc = cloneLibrary(library);
  const found = findInDoc(doc, id);
  const node = found.node;
  if (!node) throw new Error("目标记录不存在");
  if (node.id === ROOT_ID) throw new Error("根目录不能重命名");
  if (Object.prototype.hasOwnProperty.call(payload || {}, "name")) {
    node.name = node.type === "folder" ? cleanFolderName(payload.name) : cleanName(payload.name, "未命名岗位");
  }
  if (node.type === "bookmark" && Object.prototype.hasOwnProperty.call(payload || {}, "url")) {
    node.url = cleanUrl(payload.url);
  }
  if (node.type === "bookmark" && Object.prototype.hasOwnProperty.call(payload || {}, "status")) {
    node.status = cleanStatus(payload.status);
  }
  if (node.type === "bookmark" && (
    Object.prototype.hasOwnProperty.call(payload || {}, "name") ||
    Object.prototype.hasOwnProperty.call(payload || {}, "url") ||
    Object.prototype.hasOwnProperty.call(payload || {}, "status")
  )) {
    node.updatedAt = nowIso();
  }
  doc.updatedAt = nowIso();
  return { library: doc, node };
}

function collectDescendantFolderIds(folder, out = new Set()) {
  if (!folder || folder.type !== "folder") return out;
  for (const child of folder.children || []) {
    if (child.type === "folder") {
      out.add(child.id);
      collectDescendantFolderIds(child, out);
    }
  }
  return out;
}

function moveNode(library, id, targetFolderId) {
  const doc = cloneLibrary(library);
  const found = findInDoc(doc, id);
  const node = found.node;
  const parent = found.parent;
  if (!node || !parent) throw new Error("目标记录不存在或不能移动");
  const target = findFolderInDoc(doc, targetFolderId || ROOT_ID);
  if (node.id === target.id) throw new Error("不能移动到自身");
  if (node.type === "folder") {
    const descendants = collectDescendantFolderIds(node);
    if (descendants.has(target.id)) throw new Error("不能移动到自己的子文件夹");
  }
  parent.children = parent.children.filter((child) => child.id !== node.id);
  target.children.push(node);
  doc.updatedAt = nowIso();
  return { library: doc, node };
}

function deleteNode(library, id) {
  const doc = cloneLibrary(library);
  const found = findInDoc(doc, id);
  if (!found.node || !found.parent) throw new Error("目标记录不存在或不能删除");
  found.parent.children = found.parent.children.filter((child) => child.id !== found.node.id);
  doc.updatedAt = nowIso();
  return { library: doc, node: found.node };
}

function folderOptions(library) {
  const doc = normalizeLibrary(library);
  const rows = [];
  const walk = (folder, depth, pathParts) => {
    const parts = pathParts.concat(folder.id === ROOT_ID ? [] : [folder.name]);
    rows.push({
      id: folder.id,
      name: folder.name,
      depth,
      path: parts.length ? `岗位库 / ${parts.join(" / ")}` : "岗位库"
    });
    (folder.children || []).filter((child) => child.type === "folder").forEach((child) => walk(child, depth + 1, parts));
  };
  walk(doc.root, 0, []);
  return rows;
}

function searchBookmarks(library, query) {
  const doc = normalizeLibrary(library);
  const q = String(query || "").trim().toLowerCase();
  if (!q) return [];
  const out = [];
  const walk = (folder, parts) => {
    const nextParts = folder.id === ROOT_ID ? parts : parts.concat(folder.name);
    for (const child of folder.children || []) {
      if (child.type === "folder") {
        walk(child, nextParts);
      } else {
        const hay = `${child.name} ${child.status || ""} ${child.url}`.toLowerCase();
        if (hay.includes(q)) out.push({ ...child, folderPath: nextParts.length ? `岗位库 / ${nextParts.join(" / ")}` : "岗位库" });
      }
    }
  };
  walk(doc.root, []);
  return out;
}

module.exports = {
  LIBRARY_VERSION,
  ROOT_ID,
  createEmptyLibrary,
  normalizeLibrary,
  cleanUrl,
  cleanStatus,
  addFolder,
  addBookmark,
  updateNode,
  moveNode,
  deleteNode,
  folderOptions,
  searchBookmarks,
  findNodeWithParent
};
