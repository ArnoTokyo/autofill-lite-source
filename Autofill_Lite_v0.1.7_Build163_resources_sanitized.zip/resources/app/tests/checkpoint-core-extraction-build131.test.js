"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const root = path.join(__dirname, "..");
const manifest = JSON.parse(fs.readFileSync(path.join(root, "autofill-plugin/manifest.json"), "utf8"));
const 示例资料flow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-示例资料flow.js"), "utf8");
const coreSource = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-core.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");

const scripts = manifest.content_scripts[0].js;
assert(scripts.includes("content/checkpoint-core.js"), "A: checkpoint core must be loaded as a content script");
assert(scripts.indexOf("content/checkpoint-core.js") < scripts.indexOf("content/special-site-示例资料flow.js"), "A: checkpoint core must load before special 示例资料flow");
assert(示例资料flow.includes("var CheckpointCore = AF.CheckpointCore || null"), "B: special 示例资料flow must consume shared CheckpointCore");
assert(示例资料flow.includes("checkpointCore().loadRecoveryCheckpoint"), "B: recovery storage must be delegated to core");
assert(示例资料flow.includes("checkpointCore().buildFailureContext"), "B: FailureContext must be delegated to core");
assert(示例资料flow.includes('id === "bankcomm-recruitment" || id === "zhaopin-campus-enterprise-resume-v1"'), "C: Build131 must not expand checkpoint 示例资料flow eligibility");
assert(示例资料flow.includes("var executionLedger = await checkpointCore().loadExecutionLedger"), "D: observe-only ExecutionLedger must be initialized");
assert(示例资料flow.includes("checkpointCore().markStepCompleted(executionLedger, step)"), "D: completed steps must be recorded in ledger");
assert(示例资料flow.includes("summary.executionLedger = checkpointCore().snapshotExecutionLedger"), "D: safe ledger summary must be exposed");
assert(main.includes("executionLedger:"), "D: run log must include ledger summary");
assert(coreSource.includes("observeOnly: true"), "E: Build131 ledger must be explicitly observe-only");
assert(coreSource.includes('EXECUTION_LEDGER_STORAGE_KEY = "offerAutofillExecutionLedgerV1"'), "E: ledger storage key missing");
assert(!coreSource.includes("resumeValuesIncluded"), "E: checkpoint core must not embed resume payloads");

const store = {};
const sandbox = {
  window: { AF: {}, location: { hostname: "example.test", pathname: "/resume", hash: "" } },
  chrome: {
    storage: { local: {
      get(keys, cb) { const out = {}; keys.forEach(k => { if (Object.prototype.hasOwnProperty.call(store, k)) out[k] = store[k]; }); cb(out); },
      set(payload, cb) { Object.assign(store, payload); cb && cb(); },
      remove(keys, cb) { keys.forEach(k => delete store[k]); cb && cb(); }
    } },
    runtime: { lastError: null }
  },
  console,
  Date,
  Math,
  Promise,
  setTimeout,
  clearTimeout
};
vm.createContext(sandbox);
vm.runInContext(coreSource, sandbox, { filename: "checkpoint-core.js" });
const core = sandbox.window.AF.CheckpointCore;
assert(core && core.version === 1, "F: CheckpointCore API missing");
assert.strictEqual(core.classifyRecoverableFailure(null, "内容长度超过限制（51/50）", {}).recoverability, "RECOVERABLE_MANUAL", "F: explicit validation classification changed");
assert.strictEqual(core.classifyRecoverableFailure(null, "record ownership 无法安全确认", {}).recoverability, "UNSAFE_STOP", "F: unsafe ownership classification changed");
const fp1 = core.recordFingerprint({ school: "示例资料", degree: "本科", startTime: "示例资料" });
const fp2 = core.recordFingerprint({ school: "示例资料", degree: "硕士", startTime: "示例资料" });
assert(fp1 && fp2 && fp1 !== fp2, "F: record fingerprint semantics changed");
const ledger = { version: 1, observeOnly: true, 示例资料flowId: "wf", hostname: "example.test", routeKey: "/resume", completedStepKeys: [], completedRecords: {}, updatedAt: Date.now() };
core.markStepCompleted(ledger, { cardTitle: "教育信息", category: "示例资料", 示例资料Index: 0, dataOverride: [{ school: "示例资料", degree: "本科" }] });
const snap = core.snapshotExecutionLedger(ledger);
assert.strictEqual(snap.observeOnly, true, "G: ledger must remain observe-only");
assert.strictEqual(snap.completedStepCount, 1, "G: ledger step count incorrect");
assert.strictEqual(snap.completedRecordCount, 1, "G: ledger record count incorrect");
console.log("checkpoint-core-extraction-build131.test.js passed (A-G)");
