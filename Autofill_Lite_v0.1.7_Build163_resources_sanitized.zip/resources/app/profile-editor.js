"use strict";

const $ = (id) => document.getElementById(id);
let profile = null;
let currentSectionKey = null;
let currentRecordIndex = 0;
let currentMode = "sections";

function deepClone(value) { return JSON.parse(JSON.stringify(value)); }
function nonEmpty(value) { return value !== undefined && value !== null && String(value).trim() !== ""; }

function setStatus(text, kind) {
  const el = $("status");
  el.textContent = text;
  el.style.background = kind === "error" ? "#fff0f0" : (kind === "ok" ? "#eefbf3" : "#eef6ff");
  el.style.color = kind === "error" ? "#9f2f2f" : (kind === "ok" ? "#21643b" : "#35546d");
}

function sections() {
  return profile && profile.profileV2 && profile.profileV2.sections || {};
}

function ensureQuestionBank() {
  if (!profile.profileV2.questionBank || !Array.isArray(profile.profileV2.questionBank)) profile.profileV2.questionBank = [];
  return profile.profileV2.questionBank;
}

function renderSectionList() {
  const list = $("sectionList");
  list.innerHTML = "";
  Object.entries(sections()).forEach(([key, section]) => {
    const btn = document.createElement("button");
    btn.textContent = section.title || key;
    btn.dataset.key = key;
    btn.className = key === currentSectionKey && currentMode === "sections" ? "active" : "";
    btn.addEventListener("click", () => {
      currentMode = "sections";
      currentSectionKey = key;
      currentRecordIndex = 0;
      syncMode();
      renderSection();
    });
    list.appendChild(btn);
  });
}

function makeRow(key, value, onChange, onDelete) {
  const node = $("fieldRowTemplate").content.firstElementChild.cloneNode(true);
  const keyInput = node.querySelector(".field-key");
  const valueInput = node.querySelector(".field-value");
  keyInput.value = key || "";
  valueInput.value = value == null ? "" : String(value);
  let oldKey = key || "";
  keyInput.addEventListener("change", () => {
    const nextKey = keyInput.value.trim();
    if (!nextKey) { keyInput.value = oldKey; return; }
    onChange(oldKey, nextKey, valueInput.value);
    oldKey = nextKey;
  });
  valueInput.addEventListener("input", () => onChange(oldKey, oldKey, valueInput.value));
  node.querySelector(".delete").addEventListener("click", () => { onDelete(oldKey); renderSection(); });
  return node;
}

function renderValuesObject(values) {
  const host = $("fields");
  host.innerHTML = "";
  const entries = Object.entries(values || {});
  if (!entries.length) host.innerHTML = '<div class="empty">当前没有字段。可点击右上角“新增字段”。</div>';
  entries.forEach(([key, value]) => {
    host.appendChild(makeRow(key, value, (oldKey, nextKey, nextValue) => {
      if (oldKey !== nextKey) {
        delete values[oldKey];
        values[nextKey] = nextValue;
      } else values[oldKey] = nextValue;
    }, (deleteKey) => delete values[deleteKey]));
  });
}

function currentSection() { return sections()[currentSectionKey]; }
function currentValues() {
  const section = currentSection();
  if (!section) return null;
  if (section.kind === "示例资料") {
    section.items = Array.isArray(section.items) ? section.items : [];
    const item = section.items[currentRecordIndex];
    if (!item) return null;
    item.values = item.values && typeof item.values === "object" ? item.values : {};
    return item.values;
  }
  section.values = section.values && typeof section.values === "object" ? section.values : {};
  return section.values;
}

function renderSection() {
  if (!currentSectionKey || !currentSection()) {
    currentSectionKey = Object.keys(sections())[0] || null;
  }
  const section = currentSection();
  if (!section) return;
  $("sectionTitle").textContent = section.title || currentSectionKey;
  const recordBar = $("recordBar");
  if (section.kind === "示例资料") {
    section.items = Array.isArray(section.items) ? section.items : [];
    recordBar.classList.remove("hidden");
    const sel = $("recordSelect");
    sel.innerHTML = "";
    section.items.forEach((item, idx) => {
      const opt = document.createElement("option");
      opt.value = String(idx);
      opt.textContent = item.title || `记录 ${idx + 1}`;
      sel.appendChild(opt);
    });
    if (!section.items.length) {
      currentRecordIndex = -1;
      $("fields").innerHTML = '<div class="empty">当前没有记录。可点击“新增记录”。</div>';
      return;
    }
    currentRecordIndex = Math.min(Math.max(currentRecordIndex, 0), section.items.length - 1);
    sel.value = String(currentRecordIndex);
  } else {
    recordBar.classList.add("hidden");
  }
  const values = currentValues();
  if (values) renderValuesObject(values);
}

function renderQa() {
  const rows = $("qaRows");
  const bank = ensureQuestionBank();
  rows.innerHTML = "";
  if (!bank.length) rows.innerHTML = '<div class="empty">还没有自定义问答。遇到资料库里不存在的问题时，可以在这里保存“问题 + 回答”。</div>';
  bank.forEach((entry, index) => {
    const node = $("fieldRowTemplate").content.firstElementChild.cloneNode(true);
    node.querySelector(".field-key").value = entry.question || "";
    node.querySelector(".field-value").value = entry.answer == null ? "" : String(entry.answer);
    node.querySelector(".field-key").addEventListener("input", (e) => entry.question = e.target.value);
    node.querySelector(".field-value").addEventListener("input", (e) => entry.answer = e.target.value);
    node.querySelector(".delete").addEventListener("click", () => { bank.splice(index, 1); renderQa(); });
    rows.appendChild(node);
  });
}

function syncMode() {
  document.querySelectorAll(".nav").forEach(btn => btn.classList.toggle("active", btn.dataset.mode === currentMode));
  $("sectionsPanel").classList.toggle("hidden", currentMode !== "sections");
  $("qaPanel").classList.toggle("hidden", currentMode !== "qa");
  renderSectionList();
  if (currentMode === "qa") renderQa();
}

async function load() {
  setStatus("正在读取资料…");
  try {
    profile = deepClone(await window.lite.getProfileRaw());
    if (!profile || !profile.profileV2 || !profile.profileV2.sections) throw new Error("资料结构无效");
    if (!currentSectionKey) currentSectionKey = Object.keys(sections())[0] || null;
    renderSectionList();
    renderSection();
    renderQa();
    setStatus("已读取本地资料。修改后点击右上角“保存修改”。");
  } catch (error) {
    setStatus(`读取失败：${error.message || error}`, "error");
  }
}

$("recordSelect").addEventListener("change", (e) => { currentRecordIndex = Number(e.target.value || 0); renderSection(); });
$("addRecord").addEventListener("click", () => {
  const section = currentSection();
  if (!section || section.kind !== "示例资料") return;
  section.items = Array.isArray(section.items) ? section.items : [];
  section.items.push({ title: `${section.title || "记录"} ${section.items.length + 1}`, values: {}, custom: [] });
  currentRecordIndex = section.items.length - 1;
  renderSection();
});
$("addField").addEventListener("click", () => {
  const values = currentValues();
  if (!values) return;
  let base = "新字段";
  let key = base, n = 2;
  while (Object.prototype.hasOwnProperty.call(values, key)) key = `${base}${n++}`;
  values[key] = "";
  renderSection();
});
$("addQa").addEventListener("click", () => {
  ensureQuestionBank().push({ question: "", answer: "" });
  renderQa();
});

document.querySelectorAll(".nav").forEach(btn => btn.addEventListener("click", () => {
  currentMode = btn.dataset.mode;
  syncMode();
  if (currentMode === "sections") renderSection();
}));

$("reload").addEventListener("click", load);
$("save").addEventListener("click", async () => {
  try {
    const result = await window.lite.saveProfileRaw(profile);
    // Re-read the exact runtime profile after saving. This prevents the editor
    // from continuing to show an in-memory state that differs from Autofill Core.
    profile = deepClone(await window.lite.getProfileRaw());
    renderSectionList();
    if (currentMode === "sections") renderSection();
    else renderQa();
    const where = result && result.profileFile ? `；运行时资料：${result.profileFile}` : "";
    const hash = result && result.profileHash ? `；校验 ${result.profileHash}` : "";
    setStatus(`已保存并读回校验通过。备份：${result.backupName || ""}${where}${hash}`, "ok");
  } catch (error) {
    setStatus(`保存失败：${error.message || error}`, "error");
  }
});

load();
