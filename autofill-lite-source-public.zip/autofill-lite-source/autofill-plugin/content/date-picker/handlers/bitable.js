// content/date-picker/handlers/bitable.js — 飞书多维表格 UD 日期选择器 (.ud__picker / .bitable-*)
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   工厂分支 Kn.create() case "ud": 行46030 -> lo (类定义行47124)
//   ud 面板导航 (enhancedClick 打开 .ud__picker-date-panel -> 调通用导航器 w() -> 点确定): 行 40355-40395
//   w() 调用选择器: 行 40389 (已核实, 逐参数照搬; refine=null, monthRetries=10)
//
// 注: 之前版本是"直接 setTextLike 往 input/contenteditable 写文本"的占位实现, 对 UD 这种自定义
//     日历组件不会打开面板、也不生效 -> 填不上。现按源码恢复真实的 UD 面板导航。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  // 源码行40355: focus + enhancedClick 打开 UD 面板 -> w() 选日期 -> 有确定按钮就点
  async function udSingleNavigate(triggerEl, dateStr) {
    if (!triggerEl || !dateStr) throw new Error("参数错误：触发元素或日期不能为空");
    var input = (triggerEl.querySelector && triggerEl.querySelector("input")) || triggerEl;
    triggerEl.focus && triggerEl.focus();
    await AF.DomUtils.enhancedClick(input);
    await AF.Utils.sleep(300);
    var panel = document.querySelector(
      '.ud__picker-date-panel:not([style*="display: none"]), .ud-datepicker:not([style*="display: none"])'
    );
    if (!panel) throw new Error("无法打开UD日期选择器");
    // 源码行40389 (逐参数照搬)
    var ok = await AF.DatePicker._navigatePanel({
      container: panel,
      dateString: dateStr,
      headerClickSelector: ".ud__picker-panel-header-btn",
      yearCellSelector: ".ud__picker-year-panel-cell",
      disabledClassList: false,
      yearBoundarySelector: null,
      nextYearSelector: ".ud__picker-panel-header .ud__space__item:last-child .ud__picker-panel-header-icon",
      prevYearSelector: ".ud__picker-panel-header .ud__space__item:first-child .ud__picker-panel-header-icon",
      monthPanelSelector: ".ud__picker-panel-header-content__left .ud__picker-panel-header-btn:last-of-type",
      monthCellSelector: ".ud__picker-month-panel-cell",
      dayCellSelector: ".ud__picker-date-panel-cell",
      maxRetries: 20,
      monthRetries: 10,
    });
    // 源码行40389之后: 有确定按钮就点一下收尾
    var okBtn = panel.querySelector(".ud-datepicker-footer-btn-ok, .ud-calendar-footer-btn-ok");
    if (okBtn) {
      await AF.DomUtils.safeClickElement(okBtn);
    }
    if (!ok) throw new Error("UD calendar navigation failed");
    return true;
  }

  function isCurrentEndValue(value) {
    return typeof value === "string" && /^(至今|目前|现在|仍在职|在职|仍在进行|当前)$/.test(value.trim());
  }

  // Throne 的“至今”不是一个日期格，而是结束日期面板/字段附近的语义开关。
  // 只在当前范围组件和已打开的日期面板附近查找，避免点到其他经历模块的同名控件。
  async function selectCurrentRangeEnd(wrapper, endInput) {
    await AF.DomUtils.enhancedClick(endInput);
    await AF.Utils.sleep(250);
    var panelSelectors = [
      ".ud__picker-date-panel",
      ".ud-datepicker",
      "[class*='date'][class*='panel']",
      "[class*='picker'][class*='panel']",
    ].join(",");
    var scopes = Array.from(document.querySelectorAll(panelSelectors)).filter(function (node) {
      return AF.DomUtils.isElementVisible(node);
    });
    var local = wrapper;
    for (var depth = 0; local && depth < 4; depth++, local = local.parentElement) scopes.push(local);
    var seen = new Set();
    var matches = [];
    scopes.forEach(function (scope) {
      Array.from(scope.querySelectorAll(
        "label, button, [role='checkbox'], [role='switch'], input[type='checkbox'], input[type='radio'], span, div"
      )).forEach(function (node) {
        if (seen.has(node) || !AF.DomUtils.isElementVisible(node)) return;
        seen.add(node);
        var text = String(node.textContent || node.getAttribute("aria-label") || node.getAttribute("title") || "")
          .replace(/[\s:：*]/g, "");
        if (!/^(至今|目前|现在|仍在职|在职|仍在进行|当前)$/.test(text)) return;
        var target = node.closest && node.closest("label, button, [role='checkbox'], [role='switch']") || node;
        var rect = target.getBoundingClientRect();
        var origin = endInput.getBoundingClientRect();
        var dx = rect.left - origin.left;
        var dy = rect.top - origin.top;
        matches.push({ element: target, distance: Math.sqrt(dx * dx + dy * dy) });
      });
    });
    matches.sort(function (a, b) { return a.distance - b.distance; });
    if (!matches.length || matches[0].distance > 700) return false;
    var target = matches[0].element;
    var input = target.matches && target.matches("input[type='checkbox'], input[type='radio']")
      ? target
      : target.querySelector && target.querySelector("input[type='checkbox'], input[type='radio']");
    if (input && input.checked) return true;
    await AF.DomUtils.safeClickElement(target);
    await AF.Utils.sleep(200);
    return input ? Boolean(input.checked) : true;
  }

  AF.DatePicker._registry["ud"] = function (element, valueType) {
    return {
      setValue: async function (value) {
        try {
          if (!value) throw new Error("日期为空");
          if (typeof value === "string" || valueType === "string") {
            return await udSingleNavigate(element, value);
          }
          if (typeof value !== "object" || !("startTime" in value) || !("endTime" in value)) {
            throw new Error("当option为对象时，dateValue必须包含startTime和endTime属性");
          }
          var candidates = AF.DomUtils.findSimilarElements(element, 4, { sameTag: true, sameClass: true, sameParent: false });
          await udSingleNavigate(element, value.startTime);
          await AF.Utils.sleep(500);
          if (candidates.length > 0) {
            var best = AF.DatePicker._pickEndDateCandidate(element, candidates);
            await udSingleNavigate(best, value.endTime);
          } else {
            var surrounding = AF.DomUtils.findSurroundingInputs(element);
            if (surrounding.length > 0) await udSingleNavigate(surrounding[0], value.endTime);
          }
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };

  // 飞书招聘 / Throne 的年月范围组件：同一个字段内固定包含开始、结束两个 input。
  // 逐端打开日历选择，避免“相似元素”跨到相邻经历卡片。
  AF.DatePicker._registry["throneRange"] = function (element, valueType) {
    return {
      setValue: async function (value) {
        try {
          if (!value || typeof value !== "object" || !value.startTime || !value.endTime) return false;
          var wrapper = element.closest && element.closest(".throne-biz-date-range-picker-wrapper") ||
            element.querySelector && element.querySelector(".throne-biz-date-range-picker-wrapper") ||
            element;
          var inputs = Array.from(wrapper.querySelectorAll(".throne-biz-date-range-picker-input input, input"))
            .filter(function (input, index, all) {
              return all.indexOf(input) === index && AF.DomUtils.isElementVisible(input);
            });
          if (inputs.length < 2) return false;
          await udSingleNavigate(inputs[0], value.startTime);
          await AF.Utils.sleep(300);
          if (value.current === true || isCurrentEndValue(value.endTime)) {
            return await selectCurrentRangeEnd(wrapper, inputs[1]);
          }
          await udSingleNavigate(inputs[1], value.endTime);
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
