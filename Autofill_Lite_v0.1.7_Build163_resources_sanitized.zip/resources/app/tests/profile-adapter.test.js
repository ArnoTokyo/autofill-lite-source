"use strict";
const assert = require("assert");
const path = require("path");
const { normalizeProfileBackup, loadProfile } = require("../profile-adapter");
const raw = { profileV2: { sections: {
  示例资料: { values: { "姓名":"测试用户", "电话":"13800000000", "政治面貌":"示例资料", "最高学历":"硕士" } },
  示例资料: { items: [
    { values: { "意向岗位":"财务", "期望薪资":"示例资料", "期望工作城市":"示例资料", "是否接受调剂":"是" } },
    { values: { "意向岗位":"管培生", "期望薪资":"示例资料", "期望工作城市":"示例资料", "是否接受调剂":"是" } }
  ] },
  示例资料: { items: [
    { values: { "学校":"某高中", "学历":"高中", "结束时间":"示例资料" } },
    { values: { "学校":"某大学", "学历":"本科", "学位":"学士", "专业":"财政学", "绩点制":"四分制", "学制":"四年制", "个人绩点":"示例资料", "年级排名":"其他", "班级排名":"其他", "是否贯通式培养":"示例资料", "是否有国外、港澳台地区学习经历":"否", "开始时间":"示例资料", "结束时间":"示例资料" } },
    { values: { "学校":"某大学", "学历":"硕士", "学位":"硕士", "专业":"金融", "学位类型":"专业型", "绩点制":"四分制", "研究方向":"示例资料", "学制":"两年制", "个人绩点":"示例资料", "年级排名":"其他", "班级排名":"其他", "是否贯通式培养":"示例资料", "是否有国外、港澳台地区学习经历":"否", "开始时间":"示例资料", "结束时间":"示例资料" } }
  ] },
  示例资料: { items: [] }, 示例资料: { items: [] },
  示例资料: { items: [{ values: {
    "组织名称":"示例研究生会", "职位":"干事", "开始时间":"示例资料", "结束时间":"示例资料",
    "开始日期":"示例资料", "结束日期":"示例资料", "本人职责":"负责示例职责"
  } }] },
  示例资料: { items: [{ values: {
    "奖惩名称":"示例奖学金", "奖惩时间":"示例资料", "奖惩日期":"示例资料", "奖励等级":"校级"
  } }] },
  示例资料: { items: [{ values: {
    "外语种类":"英语",
    "证书名称（技能名称）":"雅思",
    "成绩":"6.5",
    "CET4成绩":"616",
    "CET6成绩":"532",
    "其他英语等级考试":"示例资料",
    "其他英语等级考试成绩":"6.5"
  } }] },
  示例资料: { items: [] },
  示例资料: { values: { "自我评价":"测试自评" } }, 示例资料: { values: { "是否同意背景调查":"是" } }, 示例资料: { values:{} }
} } };
const out = normalizeProfileBackup(raw);
assert.strictEqual(out.示例资料Info.name, "测试用户");
assert.strictEqual(out.示例资料Info.highestDegree, "硕士");
assert.strictEqual(out.示例资料.length, 2);
assert.strictEqual(out.示例资料[0].level, "硕士");
assert.strictEqual(out.示例资料[0].startTime, "示例资料");
assert.strictEqual(out.示例资料[0].endTime, "示例资料-30");
assert.strictEqual(out.示例资料[0].majorCategory, "经济学");
assert.strictEqual(out.示例资料[0].schoolAffiliation, "国内高校");
assert.strictEqual(out.示例资料[0].researchDirection, "示例资料");
assert.strictEqual(out.示例资料[1].majorCategory, "经济学");
assert.strictEqual(out.示例资料[1].schoolAffiliation, "国内高校");
assert.strictEqual(out.示例资料[1].startTime, "示例资料-01");
assert.strictEqual(out.示例资料[1].endTime, "示例资料-30");
assert.strictEqual(out.示例资料[0].studyLength, "两年制");
assert.strictEqual(out.示例资料[0].gpa, "示例资料");
assert.strictEqual(out.示例资料[0].rank, "其他");
assert.strictEqual(out.示例资料[0].cohortRank, "其他");
assert.strictEqual(out.示例资料[0].integratedTraining, "示例资料");
assert.strictEqual(out.示例资料[0].hasOverseasStudy, "否");
assert.strictEqual(out.示例资料[0].gradePointType, "四分制");
assert.strictEqual(out.示例资料[0].degreeType, "专业型");
assert.strictEqual(out.示例资料[0].degreeSimple, "硕士");
assert.strictEqual(out.示例资料[0].degreeDetailed, "示例资料");
assert.strictEqual(out.示例资料[1].degreeSimple, "学士");
assert.strictEqual(out.示例资料[1].degreeDetailed, "示例资料");
assert.strictEqual(out.示例资料[0].majorDirection, "示例资料");
assert.strictEqual(out.示例资料[0].isHighestEducation, "是");
assert.strictEqual(out.示例资料[0].isHighestDegree, "是");
assert.strictEqual(out.示例资料[0].isFirstEducation, "否");
assert.strictEqual(out.示例资料[1].studyLength, "四年制");
assert.strictEqual(out.示例资料[1].gpa, "示例资料");
assert.strictEqual(out.示例资料[1].rank, "其他");
assert.strictEqual(out.示例资料[1].cohortRank, "其他");
assert.strictEqual(out.示例资料[1].gradePointType, "四分制");
assert.strictEqual(out.示例资料[1].isHighestEducation, "否");
assert.strictEqual(out.示例资料[1].isHighestDegree, "否");
assert.strictEqual(out.示例资料[1].isFirstEducation, "是");

assert.strictEqual(out.示例资料Info.graduationDate, "示例资料-30");
assert.strictEqual(out.jobIntention.position, "财务");
assert.strictEqual(out.jobIntention.expectedPosition, "财务");
assert.strictEqual(out.jobIntention.salary, "示例资料");
assert.strictEqual(out.jobIntention.expectedSalary, "示例资料");
assert.deepStrictEqual(out.jobIntention.positionOptions, ["财务", "管培生"]);
assert.deepStrictEqual(out.jobIntention.salaryOptions, ["示例资料", "示例资料"]);
assert.strictEqual(out.jobIntention.示例资料s.length, 2);
assert.strictEqual(out.示例资料Info.expectedPosition, "财务");
assert.strictEqual(out.示例资料Info.expectedSalary, "示例资料");
assert.strictEqual(out.示例资料Skills.length, 1);
assert.strictEqual(out.示例资料Skills[0].cet4Score, "616");
assert.strictEqual(out.示例资料Skills[0].cet6Score, "532");
assert.strictEqual(out.示例资料Skills[0].示例资料EnglishExam, "示例资料");
assert.strictEqual(out.示例资料Skills[0].示例资料EnglishScore, "6.5");
assert.strictEqual(out.示例资料Skills[0].ieltsScore, "6.5");

assert.strictEqual(out.campusLeadership.length, 1);
assert.strictEqual(out.campusLeadership[0].startTime, "示例资料");
assert.strictEqual(out.campusLeadership[0].startDate, "示例资料");
assert.strictEqual(out.campusLeadership[0].endDate, "示例资料");
assert.strictEqual(out.campusLeadership[0].roleDescription, "负责示例职责");
assert.strictEqual(out.示例资料.length, 1);
assert.strictEqual(out.示例资料[0].awardTime, "示例资料");
assert.strictEqual(out.示例资料[0].awardDate, "示例资料");
assert.strictEqual(out.示例资料Introduction.示例资料Introduction, "测试自评");
assert.ok(!Object.prototype.hasOwnProperty.call(out, "示例资料"));
// Build 36 regression: the user-approved CDB Learning Committee Member wording
// is persisted in the canonical default profile and stays within the site's
// 50-character 职务描述 limit.
const defaultProfile = loadProfile(path.join(__dirname, "..", "defaults", "candidate-profile-merged.json"));
assert.strictEqual(defaultProfile.示例资料[0].degreeDetailed, "示例资料");
assert.strictEqual(defaultProfile.示例资料[0].degreeSimple, "硕士");
assert.strictEqual(defaultProfile.示例资料[1].degreeDetailed, "示例资料");
assert.strictEqual(defaultProfile.示例资料[1].degreeSimple, "学士");
const learningCommittee = defaultProfile.campusLeadership.find((row) => row.title === "示例资料");
assert(learningCommittee, "canonical profile should contain the Learning Committee Member row");
assert.strictEqual(learningCommittee.description, "示例资料");
assert(learningCommittee.description.length <= 50, "Learning Committee Member description must fit the CDB 50-character limit");

console.log("profile-adapter tests: PASS");
