"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
assert(/const BUILD_ID = "202609\d{2}-.+-1(?:4[4-9]|[5-9]\d|\d{3,})";/.test(main), 'current build must preserve Build144+ education identity invariants');

global.location = {
  href: "https://zhaopin.cnpc.com.cn/web/createResume.html",
  hostname: "zhaopin.cnpc.com.cn",
  pathname: "/web/createResume.html"
};
global.getComputedStyle = () => ({ display: "block", visibility: "visible", opacity: "1" });
global.document = {};
global.window = { location: global.location, AF: {} };

const RecordGraph = require(path.join(root, "autofill-plugin", "content", "record-graph.js"));

function input(value) {
  return {
    tagName: "INPUT",
    value: value || "",
    isConnected: true,
    getBoundingClientRect() { return { width: 120, height: 26, left: 0, top: 0 }; },
    matches() { return false; },
    querySelector() { return null; }
  };
}

function select(displayText, rawValue) {
  const option = { textContent: displayText, value: rawValue || displayText };
  return {
    tagName: "SELECT",
    value: rawValue || displayText,
    selectedOptions: [option],
    isConnected: true,
    getBoundingClientRect() { return { width: 120, height: 26, left: 0, top: 0 }; },
    matches(selector) { return String(selector || "").toLowerCase() === "select"; },
    querySelector() { return null; }
  };
}

function makeContainer(selectorMap) {
  const nodes = Object.values(selectorMap).flat();
  const doc = { querySelectorAll(selector) { return selectorMap[selector] || []; } };
  nodes.forEach((node) => { node.ownerDocument = doc; });
  return {
    ownerDocument: doc,
    isConnected: true,
    getBoundingClientRect() { return { width: 800, height: 600, left: 0, top: 0 }; },
    contains(node) { return nodes.includes(node); }
  };
}

const config = { _aiSemanticPatch: { sectionMappings: [{ label: "教育背景", category: "education" }] } };
const mappings = [
  { category: "education", fieldKey: "school", selector: "#school" },
  { category: "education", fieldKey: "level", selector: "#level" },
  { category: "education", fieldKey: "startTime", selector: "#start" }
];

// Real CNPC case: bachelor and master are from the same school. Canonical profile
// stores level as `硕士`, while the page renders `硕士研究生`. Raw equality used by
// Build143 returned record_identity_not_found; field-aware identity must bind master.
const rows = [
  { school: "甲大学", level: "硕士", startTime: "2024-09-01" },
  { school: "甲大学", level: "本科", startTime: "2021-09-01" }
];
const container = makeContainer({
  "#school": [input("甲大学")],
  "#level": [select("硕士研究生", "03")],
  "#start": [input("2024-09-01")]
});
let owner = RecordGraph.resolveRuntimeEditorOwnership(container, "education", {
  sectionTitle: "教育背景",
  siteConfig: config,
  mappings,
  profileRecords: rows,
  isRecordCompleted() { return false; }
});
assert.strictEqual(owner.status, "owned");
assert.strictEqual(owner.recordIndex, 0);
assert.strictEqual(owner.ownershipMode, "identity_match");

// Date precision is also an identity formatting detail, not a different record.
const dateOnlyMappings = [
  { category: "education", fieldKey: "school", selector: "#school" },
  { category: "education", fieldKey: "startTime", selector: "#start" }
];
const dateContainer = makeContainer({
  "#school": [input("甲大学")],
  "#start": [input("2024-09")]
});
owner = RecordGraph.resolveRuntimeEditorOwnership(dateContainer, "education", {
  sectionTitle: "教育背景",
  siteConfig: config,
  mappings: dateOnlyMappings,
  profileRecords: rows,
  isRecordCompleted() { return false; }
});
assert.strictEqual(owner.status, "owned");
assert.strictEqual(owner.recordIndex, 0);

// A real conflict must remain a hard ownership failure. Same school + bachelor page
// must never be rebound to the master's profile row.
const bachelorOnlyRows = [{ school: "甲大学", level: "硕士", startTime: "2024-09-01" }];
const conflictContainer = makeContainer({
  "#school": [input("甲大学")],
  "#level": [select("本科", "02")],
  "#start": [input("2021-09-01")]
});
owner = RecordGraph.resolveRuntimeEditorOwnership(conflictContainer, "education", {
  sectionTitle: "教育背景",
  siteConfig: config,
  mappings,
  profileRecords: bachelorOnlyRows,
  isRecordCompleted() { return false; }
});
assert.strictEqual(owner.status, "record_identity_not_found");
assert(owner.identityTrace);
assert.strictEqual(owner.identityTrace.primaryMatchCount, 1);
assert.strictEqual(owner.identityTrace.combinedMatchCount, 0);

console.log("build144-education-identity-canonicalization.test.js PASS");
