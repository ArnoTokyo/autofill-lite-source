// content/select-adapter/adapters/chakra.js — Chakra UI ([data-chakra] / class*="chakra") 适配器
// 源码参考 (webcrack-output/content/deobfuscated.js, 模块3620):
//   ChakraSelectAdapter (混淆名 S):     行 14715-14743
//   triggerChakraSelect (混淆名 x/k):   行 14626-14685
//
// 算法 (对应源码 k() 函数, 行14629-14684，同时兼容 v1 结构用 role=combobox、
// v2 结构用 class*=chakra-select 两种变体):
//   1. container = closest([role=combobox], [class*=chakra], .chakra-select) 或 element
//   2. 若容器内有可用 input[type=search/text]，输入 value 触发过滤
//   3. 点击容器内 [role=button]/button/[aria-haspopup=listbox]，找不到就点 element 本身
//   4. 找面板: 优先 chakra 专属 dropdown 类名 (ul.atsx-select-dropdown-menu /
//      [role=listbox] / [class*=chakra-menu] / [class*=chakra-select__menu])，
//      全局搜索 + 就近选择；找不到再退化到通用 findDropdown
//   5. 面板仍找不到 -> 退化为通用 GenericSelect 流程 (triggerGenericSelect)
//   6. 找到面板后调用通用 selectMatchingOption
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};
  var H = SA._helpers;
  var CONTAINER_SELECTOR = '[role="combobox"], [class*="chakra"], .chakra-select';
  var PANEL_SELECTOR = ['ul.atsx-select-dropdown-menu', '[role="listbox"]', '[role="menu"]', '[class*="chakra-menu"]', '[class*="chakra-select__menu"]'];

  async function selectOneChakraValue(element, value) {
    var container = element.closest(CONTAINER_SELECTOR) || element;

    var input = container.querySelector('input[type="search"], input[type="text"]');
    if (input && !input.disabled && !input.readOnly && typeof value === "string") {
      input.focus();
      input.value = value;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      await AF.Utils.sleep(200);
    }

    var openTarget = container.querySelector('[role="button"], button, [aria-haspopup="listbox"]') || element;
    await AF.DomUtils.safeClickElement(openTarget);
    await AF.Utils.sleep(200);

    var panel = H.findVisibleDropdownNear(element, PANEL_SELECTOR, CONTAINER_SELECTOR) || H.findDropdown(element);
    if (!panel) {
      // 找不到 chakra 专属面板，退化为通用流程 (源码里 fallback 到 triggerGenericSelect)
      return await genericFallback(element, value);
    }
    return await H.selectMatchingOption(panel, value);
  }

  async function genericFallback(element, value) {
    await AF.DomUtils.safeClickElement(element);
    await AF.Utils.sleep(200);
    var panel = H.findDropdown(element) || (await H.waitForVisibleDropdownNear(element, H.GENERIC_DROPDOWN_SELECTOR, null, 1000));
    if (!panel) return false;
    return await H.selectMatchingOption(panel, value);
  }

  async function triggerChakraSelect(element, value) {
    try {
      var ok;
      if (Array.isArray(value)) {
        ok = false;
        for (var i = 0; i < value.length; i++) {
          var one = await selectOneChakraValue(element, value[i]);
          if (one) ok = true;
          await AF.Utils.sleep(150);
        }
      } else {
        ok = await selectOneChakraValue(element, value);
      }
      H.dispatchChangeEvents(element);
      return ok;
    } catch (e) {
      return false;
    }
  }

  SA._registry["chakra"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        return await triggerChakraSelect(element, value);
      },
    };
  };
})();
