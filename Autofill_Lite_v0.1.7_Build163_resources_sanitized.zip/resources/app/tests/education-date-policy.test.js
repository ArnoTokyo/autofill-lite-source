"use strict";
const assert = require("assert");
const { normalizeProfileBackup } = require("../profile-adapter");

const raw = { profileV2: { sections: {
  示例资料: { values: { "姓名": "测试用户" } },
  示例资料: { items: [] },
  示例资料: { items: [
    { values: { "学校": "A大学", "学历": "本科", "开始时间": "示例资料", "结束时间": "示例资料" } },
    { values: { "学校": "B大学", "学历": "硕士", "开始日期": "示例资料-18", "结束日期": "示例资料-15" } }
  ] },
  示例资料: { items: [{ values: { "公司": "X", "开始时间": "2026-05", "结束时间": "示例资料" } }] },
  示例资料: { items: [] }, 示例资料: { items: [] }, 示例资料: { items: [] }, 示例资料: { items: [] }, 示例资料: { items: [] },
  示例资料: { values: {} }, 示例资料: { values: {} }
} } };

const out = normalizeProfileBackup(raw);
assert.strictEqual(out.示例资料[0].school, "B大学");
assert.strictEqual(out.示例资料[0].startTime, "示例资料");
assert.strictEqual(out.示例资料[0].endTime, "示例资料-30");
assert.strictEqual(out.示例资料[1].startTime, "示例资料-01");
assert.strictEqual(out.示例资料[1].endTime, "示例资料-30");
assert.strictEqual(out.示例资料Info.graduationDate, "示例资料-30");
assert.strictEqual(out.示例资料Experience[0].startTime, "2026-05");
assert.strictEqual(out.示例资料Experience[0].endTime, "示例资料");
console.log("示例资料-date-policy tests: PASS");
