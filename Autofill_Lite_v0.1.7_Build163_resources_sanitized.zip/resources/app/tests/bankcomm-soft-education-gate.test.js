"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const 示例资料flow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-示例资料flow.js"), "utf8");
const privateSites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");

assert(privateSites.includes('id: "bankcomm-recruitment"'), "Bankcomm 示例资料flow missing");
assert(privateSites.includes('rowsValidator: validateBankcommEducationRows'), "Bankcomm 示例资料 validator missing");
assert(privateSites.includes('rowsValidationFailureMode: "manual_checkpoint"'), "Bankcomm 示例资料 validator must be section-scoped");
assert(示例资料flow.includes('step.rowsValidationFailureMode === "skip_step" || step.rowsValidationFailureMode === "manual_checkpoint"'), "generic resumable rows validation path missing");
assert(示例资料flow.includes('__afRowsValidationError'), "soft rows validation metadata missing");
assert(示例资料flow.includes('validationBlocked: true'), "soft validation decision should be surfaced as blocked/review state");
assert(privateSites.includes('交通银行要求从高中填写，但当前简历没有高中/中专示例资料'), "Bankcomm high-school requirement should remain explicit");
console.log("bankcomm-soft-示例资料-gate.test.js PASS");
