"use strict";
const assert = require("assert");
global.window = { AF: {} };
global.document = {
  addEventListener() {},
  querySelectorAll() { return []; },
  querySelector() { return null; },
};
global.Element = function Element() {};
require("../autofill-plugin/content/utils.js");
const { DomUtils } = window.AF;
["四年制", "四年", "4年制", "4年", "4", "48个月"].forEach((value) => {
  assert.strictEqual(DomUtils.parseStudyYears(value), 4, `${value} should normalize to 4 years`);
  assert.strictEqual(DomUtils.isOptionMatch(value, "", "四年制"), true, `${value} should match canonical 四年制`);
});
["两年制", "两年", "2年制", "2年", "2", "24个月"].forEach((value) => {
  assert.strictEqual(DomUtils.parseStudyYears(value), 2, `${value} should normalize to 2 years`);
  assert.strictEqual(DomUtils.isOptionMatch(value, "", "两年制"), true, `${value} should match canonical 两年制`);
});
console.log("study-length normalization tests: PASS");
