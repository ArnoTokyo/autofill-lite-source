"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const handlerSource = fs.readFileSync(path.join(root, "autofill-plugin", "content", "form-handler.js"), "utf8");
const fillSource = fs.readFileSync(path.join(root, "autofill-plugin", "content", "fill-engine.js"), "utf8");
const checkpointSource = fs.readFileSync(path.join(root, "autofill-plugin", "content", "checkpoint-core.js"), "utf8");
const overlay = require(path.join(root, "ai-semantic-overlay.js"));
const gateModule = require(path.join(root, "ai-candidate-safety-gate.js"));

assert(/const BUILD_ID = "202609\d{2}-.+-1(?:4[2-9]|[5-9]\d|\d{3,})";/.test(main), 'current build must preserve Build142+ repeat-record invariants');
assert(main.includes("compileRepeatRecordSelectorMetadata"));
assert(main.includes("recordSelectorMappings"));
assert(main.includes("repeatRecordExecution"));
assert(fillSource.includes("runtime_selector_not_visible"), "hidden scalar DOM matches must never count as current-section success");
assert(!fillSource.includes("}) || nodes[0]"), "Build141 hidden-node fallback must stay removed");
assert(fillSource.includes("unsafeRepeatFailure"), "RepeatRecord ownership/persistence failures must block section completion");
assert(handlerSource.includes("fillGraphBackedRepeatRecord"));
assert(handlerSource.includes('raw === "native-select" || raw === "select"'), "RepeatRecord native selects must use SelectAdapter rather than text fallback");
assert(handlerSource.includes("manualSavePending"));
assert(handlerSource.includes("manualEditorOpenPending"));
assert(handlerSource.includes("manual_repeat_editor_open_required"));
assert(handlerSource.includes("record_save_state_unknown"));
assert(checkpointSource.includes("repeat_record_(?:not_committed|index_unresolved|no_fields_committed|identity_not_committed)"));

// AI contributes semantics only.  The selector comes from local review/FormGraph evidence.
const review = {
  reviewFields: [
    {
      fieldId: "f-name", label: "姓名", graphRowLabel: "姓名", controlType: "text",
      selectorCandidates: [{ kind: "id", selector: "#name", hitCount: 1 }],
      patchTarget: { kind: "unique_selector", selector: "#name" }, selectorHitCount: 1
    },
    {
      fieldId: "f-relation", label: "与本人关系", graphRowLabel: "与本人关系", controlType: "select",
      selectorCandidates: [{ kind: "id", selector: "#relation", hitCount: 1 }],
      patchTarget: { kind: "unique_selector", selector: "#relation" }, selectorHitCount: 1
    },
    {
      fieldId: "f-phone", label: "电话", graphRowLabel: "电话", controlType: "text",
      selectorCandidates: [{ kind: "id", selector: "#relativesPhoneNumber", hitCount: 1 }],
      patchTarget: { kind: "unique_selector", selector: "#relativesPhoneNumber" }, selectorHitCount: 1
    }
  ],
  trustedMappings: []
};
const patch = {
  decisions: [
    { fieldId: "f-name", decision: "map", category: "familyMembers", fieldKey: "name", confidence: 0.98, reason: "family member name" },
    { fieldId: "f-relation", decision: "map", category: "familyMembers", fieldKey: "relationship", confidence: 0.97, reason: "family relationship" },
    { fieldId: "f-phone", decision: "map", category: "familyMembers", fieldKey: "phone", confidence: 0.96, reason: "family member phone" }
  ]
};
const gate = gateModule.compileAiCandidateSafetyGate(review, patch, {});
assert.strictEqual(gate.executableCandidates.length, 0, "RepeatRecord must never enter direct scalar execution");
assert.strictEqual(gate.reviewOnlyCandidates.length, 3);
const repeatMeta = overlay.compileRepeatRecordSelectorMetadata(review, gate, { minConfidence: 0.8 });
assert.strictEqual(repeatMeta.recordSelectorMappings.length, 3);
assert.deepStrictEqual(repeatMeta.recordSelectorMappings.map((x) => x.selector).sort(), ["#name", "#relation", "#relativesPhoneNumber"].sort());
assert.strictEqual(repeatMeta.safety.directExecutionAllowed, false);
assert.strictEqual(repeatMeta.safety.recordGraphOwnershipRequired, true);
assert.strictEqual(repeatMeta.safety.selectorsAuthoredByAi, false);

// RecordGraph resolves only an already-open, visible editor inside the proven section.
global.location = { href: "https://zhaopin.cnpc.com.cn/web/createResume.html", hostname: "zhaopin.cnpc.com.cn", pathname: "/web/createResume.html" };
global.getComputedStyle = () => ({ display: "block", visibility: "visible", opacity: "1" });
const RecordGraph = require(path.join(root, "autofill-plugin", "content", "record-graph.js"));

function node(value) {
  return {
    tagName: "INPUT",
    value: value || "",
    isConnected: true,
    getBoundingClientRect() { return { width: 100, height: 24, left: 0, top: 0 }; },
    matches() { return false; },
    querySelector() { return null; }
  };
}
const nameNode = node("");
const relationNode = node("");
const phoneNode = node("");
const selectorMap = {
  "#name": [nameNode],
  "#relation": [relationNode],
  "#relativesPhoneNumber": [phoneNode]
};
const doc = { querySelectorAll(selector) { return selectorMap[selector] || []; } };
const container = {
  ownerDocument: doc,
  isConnected: true,
  getBoundingClientRect() { return { width: 800, height: 500, left: 0, top: 0 }; },
  contains(candidate) { return Object.values(selectorMap).some((items) => items.includes(candidate)); }
};
[nameNode, relationNode, phoneNode].forEach((n) => { n.ownerDocument = doc; });

const profileRows = [
  { name: "父亲甲", relationship: "父亲", phone: "13800000001" },
  { name: "母亲乙", relationship: "母亲", phone: "13800000002" }
];
const mappings = repeatMeta.recordSelectorMappings;
let owner = RecordGraph.resolveRuntimeEditorOwnership(container, "familyMembers", {
  sectionTitle: "家庭成员", mappings, profileRecords: profileRows, isRecordCompleted: () => false
});
assert.strictEqual(owner.status, "owned");
assert.strictEqual(owner.ownershipMode, "blank_editor_next_record");
assert.strictEqual(owner.recordIndex, 0);
assert(owner.confidence >= 0.9);

owner = RecordGraph.resolveRuntimeEditorOwnership(container, "familyMembers", {
  sectionTitle: "家庭成员", mappings, profileRecords: profileRows, isRecordCompleted: (index) => index === 0
});
assert.strictEqual(owner.status, "owned");
assert.strictEqual(owner.recordIndex, 1, "completed record token must advance ownership to the next profile row");

nameNode.value = "母亲乙";
relationNode.value = "母亲";
owner = RecordGraph.resolveRuntimeEditorOwnership(container, "familyMembers", {
  sectionTitle: "家庭成员", mappings, profileRecords: profileRows, isRecordCompleted: () => false
});
assert.strictEqual(owner.status, "owned");
assert.strictEqual(owner.ownershipMode, "identity_match");
assert.strictEqual(owner.recordIndex, 1, "visible identity must uniquely bind the editor to the matching family record");

// Ambiguous selector ownership is a hard stop, never a guessed record.
selectorMap["#name"] = [nameNode, node("父亲甲")];
owner = RecordGraph.resolveRuntimeEditorOwnership(container, "familyMembers", {
  sectionTitle: "家庭成员", mappings, profileRecords: profileRows, isRecordCompleted: () => false
});
assert.strictEqual(owner.status, "selector_ownership_ambiguous");
assert.strictEqual(owner.confidence, 0);

const bridge = RecordGraph.buildExecutionBridge({ groups: [{ groupId: "family", categoryHint: "familyMembers", recordCount: 1, editorRecordCount: 1 }] });
assert.strictEqual(bridge[0].ownershipSupported, true, "familyMembers must be a first-class RecordGraph ownership category");
assert.strictEqual(bridge[0].safety.executeActions, false, "RecordGraph stays read-only");
assert.strictEqual(bridge[0].safety.saveAllowed, false);

console.log("build142-graph-repeat-record-bridge.test.js PASS");
