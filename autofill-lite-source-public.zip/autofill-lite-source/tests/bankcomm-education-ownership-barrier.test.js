"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const sites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
const workflow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-workflow.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");

const documentStub = { body: null, querySelector: () => null, documentElement: { setAttribute() {} } };
const windowStub = {
  AF: {},
  location: { href: "https://job.bankcomm.com/", hostname: "job.bankcomm.com", pathname: "/" },
  getComputedStyle: () => ({ display: "block", visibility: "visible" })
};
const context = { window: windowStub, document: documentStub, URL, console, setTimeout, clearTimeout };
vm.createContext(context);
vm.runInContext(sites, context);
const api = windowStub.AF.PrivateSpecialSites._test;
assert(api && typeof api.bankcommEducationCardTextMatchesRow === "function", "A: education identity hook missing");

const bachelor = {
  school: "示例大学",
  level: "本科",
  startTime: "2021-09-01",
  endTime: "2025-06-30"
};
const master = {
  school: "示例大学",
  level: "硕士",
  startTime: "2024-09-01",
  endTime: "2026-06-30"
};
const bachelorCard = "示例大学 2021-09-01~2025-06-30 本科 财政学";
const masterCard = "示例大学 2024-09-01~2026-06-30 硕士研究生 金融学";

assert(api.bankcommEducationCardTextMatchesRow(bachelor, bachelorCard) === true,
  "A: bachelor must match its own saved card");
assert(api.bankcommEducationCardTextMatchesRow(master, masterCard) === true,
  "B: master must match its own saved card");
assert(api.bankcommEducationCardTextMatchesRow(master, bachelorCard) === false,
  "C: same-school master must never match bachelor card");
assert(api.bankcommEducationCardTextMatchesRow(bachelor, masterCard) === false,
  "D: same-school bachelor must never match master card");

assert(sites.includes("waitForRepeatEditorCloseInRoot: true"),
  "E: Bankcomm education must require root-level editor close barrier");
assert(sites.includes("reuseDirtyRepeatEditor: false"),
  "E: Bankcomm education must refuse reusing an unsaved previous editor");
assert(workflow.includes("step.waitForRepeatEditorCloseInRoot === true"),
  "F: runtime save barrier implementation missing");
assert(workflow.includes("liveRepeatRoot"),
  "F: save barrier must re-query the live repeat root after React redraw");

const buildMatch = main.match(/const BUILD_ID = "([^"]+)"/);
assert(buildMatch && /-\d+$/.test(buildMatch[1]), "G: current Build ID missing");
console.log("bankcomm-education-ownership-barrier.test.js passed (A-G)");
