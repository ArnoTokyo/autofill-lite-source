"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const source = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-workflow.js"), "utf8");

assert(/const BUILD_ID = "202609\d{2}-.+-(?:15[5-9]|1[6-9]\d|[2-9]\d{2,})";/.test(main), "Build155+ compatible build ID missing");
assert(source.includes("blocked_recovery_visible_editor_identity_unresolved"), "visible-editor recovery block action missing");
assert(source.includes("needs_review:repeat_recovery_visible_editor_identity_unresolved"), "visible-editor recovery reason missing");
assert(source.includes("reuse_visible_editor_verified"), "verified visible-editor reuse path missing");

// The guard must run inside the visible-editor branch before ordinary reuse.
const editorBranch = source.indexOf("if (editor.root) {");
const lockBranch = source.indexOf("if (recoveryRecordLockActive)", editorBranch);
const ordinaryReuse = source.indexOf('result.action = "reuse_visible_editor"', editorBranch);
assert(editorBranch >= 0 && lockBranch > editorBranch && ordinaryReuse > lockBranch, "recovery identity guard must precede ordinary visible-editor reuse");

global.HTMLElement = function(){};
global.Element = function(){};
global.document = {
  body: {},
  documentElement: { getAttribute() { return null; }, setAttribute() {}, removeAttribute() {}, hasAttribute() { return false; } },
  querySelectorAll() { return []; }, querySelector() { return null; }
};
global.window = {
  AF: {}, top: null,
  location: { hostname: "test", pathname: "/", href: "https://test/" },
  getComputedStyle() { return { display: "block", visibility: "visible", cursor: "default", zIndex: "0" }; },
  sessionStorage: { getItem() { return null; }, removeItem() {}, setItem() {} },
  postMessage() {}
};
window.top = window;
const realSetTimeout = global.setTimeout;
global.setTimeout = () => 0;
new Function(source)();
global.setTimeout = realSetTimeout;
const api = window.AF.SpecialSiteWorkflow._test;

function control(value) {
  return {
    value,
    disabled: false,
    readOnly: false,
    isConnected: true,
    tagName: "INPUT",
    type: "text",
    parentElement: null,
    getBoundingClientRect() { return { width: 120, height: 24 }; },
    getAttribute() { return null; },
    matches() { return false; }
  };
}
function editor(values) {
  const controls = values.map(control);
  return { querySelectorAll() { return controls; } };
}

const target = api.zhaopinRepeatRowIdentity(
  { category: "projectExperience" },
  { projectName: "千村百巷 强国大调研项目", role: "队长", startTime: "2024-12-31", endTime: "2025-01-31" }
);
const previousEditor = editor(["知行合一实践项目", "队长", "2024-12-31", "2025-01-31"]);
const targetEditor = editor(["千村百巷 强国大调研项目", "队长", "2024-12-31", "2025-01-31"]);

const mismatch = api.zhaopinRepeatEditorMatchState(previousEditor, target);
assert.strictEqual(mismatch.primary, false, "previous-record editor must not match next project identity");
assert.strictEqual(mismatch.strong, false, "previous-record editor must never be reusable during recovery");

const match = api.zhaopinRepeatEditorMatchState(targetEditor, target);
assert.strictEqual(match.primary, true, "target project primary identity should match");
assert.strictEqual(match.strong, true, "target editor with supporting identity should be reusable");
assert(match.supporting >= 1, "target editor should carry supporting identity evidence");

console.log("build155-visible-editor-ownership-guard.test.js PASS");
