"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const { classifySiteSupport, classifyAutofillGap } = require(path.join(root, "site-support-diagnostic"));

assert.strictEqual(classifySiteSupport({ matchedWorkflowId: "x" }).code, "special_workflow");
assert.strictEqual(classifySiteSupport({ localConfigFound: true }).code, "local_config");
assert.strictEqual(classifySiteSupport({ builtInConfigFound: true }).code, "built_in_config");
assert.strictEqual(classifySiteSupport({ domPlatformDetected: true }).code, "dom_platform_detected");
assert.strictEqual(classifySiteSupport({ totalFieldsFound: 5, filledCount: 2 }).code, "generic_scan_working");
assert.strictEqual(classifySiteSupport({ totalFieldsFound: 5, filledCount: 0 }).code, "generic_scan_semantic_gap");
assert.strictEqual(classifySiteSupport({ visibleEditableControlCount: 8, visibleLabelLikeCount: 4 }).code, "generic_scan_entry_gap");
assert.strictEqual(classifySiteSupport({ visibleEditableControlCount: 8, visibleLabelLikeCount: 0 }).code, "new_adapter_likely");
assert.strictEqual(classifySiteSupport({}).code, "no_form_detected");

assert.strictEqual(classifyAutofillGap({ completionStatus: "complete" }).code, "none");
assert.strictEqual(classifyAutofillGap({ completionStatus: "partial", missingProfileFields: [{ label: "导师" }] }).code, "profile_data_gap");
assert.strictEqual(classifyAutofillGap({ completionStatus: "partial", failedCount: 1, failedFields: [{ reason: "fill failed" }] }).code, "control_or_workflow_gap");
assert.strictEqual(classifyAutofillGap({ completionStatus: "partial", unhandledCount: 2 }).code, "semantic_gap_possible");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const renderer = fs.readFileSync(path.join(root, "renderer.js"), "utf8");
assert(main.includes("collectSiteSupportProbe") && main.includes("siteSupportDiagnostic"), "site support probe must be written into diagnostics");
assert(main.includes("visibleEditableControlCount") && main.includes("visibleLabelLikeCount"), "probe must use counts rather than field values");
assert(renderer.includes("站点诊断："), "site support diagnosis must be visible in the shell report");
console.log("site support diagnostic regression: PASS");
