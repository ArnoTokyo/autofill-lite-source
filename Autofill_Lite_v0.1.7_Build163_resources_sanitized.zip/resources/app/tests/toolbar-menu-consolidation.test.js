"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const index = fs.readFileSync(path.join(root, "index.html"), "utf8");
const renderer = fs.readFileSync(path.join(root, "renderer.js"), "utf8");

assert(index.includes('id="toolsMenu"') && index.includes('class="toolbar-menu"'), "tools menu missing");
const toolsStart = index.indexOf('id="toolsMenu"');
const toolsBlock = index.slice(toolsStart, index.indexOf('</div>\n      </details>', toolsStart));
for (const id of ["aiSettings", "devtools", "data"]) {
  assert(toolsBlock.includes(`id="${id}"`), `${id} must remain inside tools menu`);
}
for (const id of ["analyze", "aiMap", "experimentMenu", "sectionTxn", "示例资料Probe", "示例资料PreviewFill", "示例资料ContinuePreview", "multiSectionSurvey", "multiSectionPreview", "multiSectionSave", "verifySiteCandidate"]) {
  assert(!toolsBlock.includes(`id="${id}"`), `${id} must not remain in the Build160 product toolbar`);
}
const actionStart = index.indexOf('<div class="actionrow">');
const actionEnd = index.indexOf('</div>\n  </header>', actionStart);
const action = index.slice(actionStart, actionEnd);
for (const id of ["fill", "stop", "profile", "bookmarks", "toolsMenu"]) assert(action.includes(`id="${id}"`), `${id} top-level action missing`);
assert(index.includes(".toolbar-menu-panel") && index.includes("z-index: 10020"), "dropdown panel styling missing");
assert(renderer.includes("function initToolbarMenus()") && renderer.includes('querySelectorAll(".toolbar-menu")'), "menu behavior initializer missing");
assert(renderer.includes("示例资料.open = false") && renderer.includes("menu.open = false"), "menu auto-close behavior missing");
console.log("toolbar menu consolidation regression: PASS");
