// content/date-picker/handlers/atsx.js — ATSX/Byte 日期选择器
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   工厂分支 Kn.create() case "atsx" (行45995-45999):
//     - element.closest(".atsx-date-picker-period-month") -> Xn (月份区间控件, 起止年月两个 label)
//     - 否则 -> Jn (普通单选日历, 只接受严格 "Y-M-D" 三段字符串)
//   Jn.setValue: 行 46301-46339 (typeof !== "string" 直接抛错) -> M() 行 29767-29810
//     M() 流程: element.click() -> B() 轮询5次×50ms 等 .atsx-date-picker-dropdown 面板 ->
//       q() 严格切 [年,月,日] (split("-") 长度必须为3, 否则抛"日期格式不正确") ->
//       D() 年导航 (行29856-29910): 点年份选择器(Y(): 排除 next/prev 后剩一个 operator, 或
//         [data-cy="year"]) 打开年列表 -> 循环10次: 在 it() 收集的格子里找 ct(cell)===目标年
//         (提取4位数字) 命中即点; 未命中则 W() 按 K() 解析表头当前年决定点 next/prev 翻页 ->
//       J() 月+日 (行30018-30060): 循环2次 Q() 在 at() 格子里找 ut(cell)===目标月 (文本里第一个
//         1-12数字), 找不到且格子恰好12个时按 index=月-1 兜底; 命中点击后 et() 在
//         .atsx-date-picker-panel-body-date-cell-inner-content 里找日数字并点击
//     每步操作前 nt() = sleep(10)×3
//   Xn.setValue: 行 46341-46373 -> yt() 行 30858-31146
//     yt() 流程: wt() findClosestAncestorWithClass(element,"atsx-date-picker-period-month") ->
//       xt() 容器内 querySelectorAll(".atsx-date-picker-period-month-label") (起止各一个 label) ->
//       vt(): bt(labels[0], startTime) 再 bt(labels[1], endTime) ->
//       bt(): MouseEvent click label + standardSleep -> St() 立即取
//         .atsx-date-picker-dropdown:not(-hidden) 面板(无轮询, 没有就抛) -> Ot() 切 [年,月]
//         (NaN 抛 "Invalid date format") -> _t(): 面板内两个
//         .atsx-date-picker-period-month-panel-list, [0]=年列表 [1]=月列表 ->
//         Tt() 年列表里 textContent.trim()===年字符串 精确匹配, It() 点击+standardSleep ->
//         Pt() 月列表里用 findMonthName(月) 文案数组 includes 匹配 (去空格), It() 点击
//     注意: 月份区间控件没有"日"这一级, 也没有翻页 (年列表是完整下拉列表)
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  // 源码 nt(): sleep(10) × 3
  async function microWait() {
    for (var i = 0; i < 3; i++) await AF.Utils.sleep(10);
  }

  // 源码 standardSleep()
  function standardSleep() {
    return AF.Utils.sleep(AF.DatePicker._STANDARD_DELAY || 30);
  }

  function getVisibleDropdown() {
    return document.querySelector(".atsx-date-picker-dropdown:not(.atsx-date-picker-dropdown-hidden)");
  }

  // ============================================================
  // Jn — 普通单选日历 (M() 行 29767-30060)
  // ============================================================

  // 源码 B(): 轮询5次, 每次间隔50ms
  async function waitDropdown() {
    for (var i = 0; i < 5; i++) {
      var panel = getVisibleDropdown();
      if (panel) return panel;
      await AF.Utils.sleep(50);
    }
    throw new Error("日期选择器下拉框加载超时");
  }

  // 源码 q(): 严格三段
  function parseYMD(dateStr) {
    var parts = String(dateStr).split("-").map(Number);
    if (parts.length !== 3) throw new Error("日期格式不正确");
    return parts;
  }

  // 源码 it()/at(): 普通日历格子 + 区间月列表项 合并去重
  function collectCells(panel) {
    var a = panel.querySelectorAll(".atsx-date-picker-panel-body-cell-content");
    var b = panel.querySelectorAll(".atsx-date-picker-period-month-panel-list-item");
    return Array.from(new Set([].concat(Array.from(a), Array.from(b))));
  }

  // 源码 ct(): 格子文本里提取4位数字年份
  function cellYear(cell) {
    if (!cell) return null;
    var m = String(cell.textContent || "").match(/(\d{4})/);
    if (m) {
      var n = parseInt(m[1], 10);
      if (!Number.isNaN(n)) return n;
    }
    return null;
  }

  // 源码 ut(): 格子文本里第一个 1-12 的独立数字
  function cellMonth(cell) {
    if (!cell) return null;
    var text = String(cell.textContent || "");
    var re = /(\D|^)(1[0-2]|[1-9])(\D|$)/g;
    var m;
    while ((m = re.exec(text)) !== null) {
      var n = parseInt(m[2], 10);
      if (n >= 1 && n <= 12) return n;
    }
    return null;
  }

  // 源码 Y(): 年份选择器按钮
  async function findYearOperator(panel) {
    await microWait();
    var ops = panel.querySelectorAll('.atsx-date-picker-panel-header-operator:not([data-cy="next"]):not([data-cy="prev"])');
    return ops.length === 1 ? ops[0] : panel.querySelector('.atsx-date-picker-panel-header-operator[data-cy="year"]');
  }

  // 源码 K(): 表头标题里最后一个数字 = 当前年
  async function currentHeaderYear(panel) {
    await microWait();
    var text = panel.querySelector(".atsx-date-picker-panel-header-title").textContent;
    return parseInt(text.match(/\d+/g).pop(), 10);
  }

  // 源码 D(): 年导航
  async function navigateYear(panel, year) {
    var yearBtn = await findYearOperator(panel);
    if (yearBtn) await yearBtn.click();
    for (var retries = 10; retries > 0; retries--) {
      await microWait();
      var cell = collectCells(panel).find(function (c) { return cellYear(c) === year; });
      if (cell) {
        await cell.click();
        return;
      }
      var cur = await currentHeaderYear(panel);
      var dir = year > cur ? "next" : "prev";
      var pageBtn = panel.querySelector('.atsx-date-picker-panel-header-operator[data-cy="' + dir + '"]');
      if (!pageBtn) throw new Error("年份导航按钮未找到");
      await pageBtn.click();
    }
    throw new Error("超过最大尝试次数，未找到指定的年份");
  }

  // 源码 et(): 日格子
  async function clickDay(panel, day) {
    await microWait();
    var cells = panel.querySelectorAll(".atsx-date-picker-panel-body-date-cell-inner-content");
    if (cells.length === 0) throw new Error("日期面板未加载");
    var cell = Array.from(cells).find(function (c) {
      return parseInt(c.textContent.trim(), 10) === day;
    });
    if (!cell) throw new Error("指定日期未找到");
    await cell.click();
    return true;
  }

  // 源码 J(): 月 -> 日
  async function navigateMonthAndDay(panel, month, day) {
    for (var retries = 2; retries > 0; retries--) {
      await microWait();
      var cells = collectCells(panel);
      var cell = cells.find(function (c) { return cellMonth(c) === month; });
      // 源码 Q() 兜底: 恰好12个格子时按 index 取
      if (!cell && cells.length === 12) cell = cells[month - 1] || null;
      if (cell) {
        await cell.click();
        return clickDay(panel, day);
      }
      await AF.Utils.sleep(10);
    }
    throw new Error("指定的月份未找到");
  }

  // 源码 M(): 单选主流程
  async function fillSingle(element, dateStr) {
    element.click();
    var panel = await waitDropdown();
    var ymd = parseYMD(dateStr);
    await navigateYear(panel, ymd[0]);
    return navigateMonthAndDay(panel, ymd[1], ymd[2]);
  }

  // ============================================================
  // Xn — 月份区间控件 (yt() 行 30858-31146)
  // ============================================================

  // 源码 Ot(): 切 [年,月]
  function parseYM(dateStr) {
    var parts = String(dateStr).split("-").map(Number);
    if (isNaN(parts[0]) || isNaN(parts[1])) throw new Error("Invalid date format");
    return [parts[0], parts[1]];
  }

  // 源码 It(): 点击列表项 + standardSleep
  async function clickListItem(item) {
    item.click();
    await standardSleep();
  }

  // 源码 Nt(): 在面板列表里按文本/断言函数找项
  function findListItem(list, matcher) {
    var items = list.querySelectorAll(".atsx-date-picker-period-month-panel-list-item");
    if (typeof matcher === "function") return Array.from(items).find(matcher);
    return Array.from(items).find(function (t) { return t.textContent.trim() === matcher; });
  }

  // 源码 bt(): 单个 label 的 年+月 选择
  async function fillPeriodMonthLabel(labelEl, dateStr) {
    // kt(): MouseEvent click + standardSleep
    labelEl.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    await standardSleep();
    // St(): 无轮询, 立即取面板
    var panel = getVisibleDropdown();
    if (!panel) throw new Error("Dropdown panel not found");
    var ym = parseYM(dateStr);
    var year = ym[0];
    var month = ym[1];
    // _t(): [0]=年列表 [1]=月列表
    var lists = panel.querySelectorAll(".atsx-date-picker-period-month-panel-list");
    var yearList = lists[0];
    var monthList = lists[1];
    // Tt(): 年精确匹配
    var yearItem = findListItem(yearList, year.toString());
    if (!yearItem) throw new Error("Year " + year + " not found");
    await clickListItem(yearItem);
    // Pt(): 月用 findMonthName 文案数组匹配
    var names = AF.DatePicker._findMonthName(month);
    var monthItem = findListItem(monthList, function (t) {
      return names.includes(t.textContent.trim().replace(/\s+/g, ""));
    });
    if (!monthItem) throw new Error("Month " + month + " not found");
    await clickListItem(monthItem);
  }

  // 源码 yt(): 区间主流程
  async function fillPeriodMonth(element, value) {
    var container = AF.DomUtils.findClosestAncestorWithClass(element, "atsx-date-picker-period-month");
    if (!container) throw new Error("Invalid period month container");
    var labels = container.querySelectorAll(".atsx-date-picker-period-month-label");
    if (labels.length === 0) throw new Error("No date items found");
    await fillPeriodMonthLabel(labels[0], value.startTime);
    await fillPeriodMonthLabel(labels[1], value.endTime);
    return true;
  }

  // ============================================================
  // 工厂注册: 按 closest(".atsx-date-picker-period-month") 分派 (源码行45995-45999)
  // ============================================================
  AF.DatePicker._registry["atsx"] = function (element) {
    if (element.closest && element.closest(".atsx-date-picker-period-month")) {
      // Xn: 月份区间
      return {
        setValue: async function (value) {
          try {
            await fillPeriodMonth(element, value);
            return true;
          } catch (e) {
            return false;
          }
        },
      };
    }
    // Jn: 普通单选, 只接受字符串 (源码对非字符串直接抛错 -> 返回 false)
    return {
      setValue: async function (value) {
        try {
          if (typeof value !== "string") throw new Error("dateValue必须是字符串类型");
          await fillSingle(element, value);
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
