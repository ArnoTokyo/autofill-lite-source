"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

class FakeElement {
  constructor(tag, className, text) {
    this.tagName = String(tag || "div").toUpperCase();
    this.className = className || "";
    this.textContent = text || "";
    this.parentElement = null;
    this.children = [];
    this.isConnected = true;
    this.value = "";
    this.attrs = {};
    this.rect = { left: 0, top: 0, right: 120, bottom: 24, width: 120, height: 24, x: 0, y: 0 };
    this.styleState = { display: "block", visibility: "visible" };
  }
  append(child) { child.parentElement = this; this.children.push(child); return child; }
  getBoundingClientRect() { return this.rect; }
  getClientRects() { return [this.rect]; }
  getAttribute(name) { return Object.prototype.hasOwnProperty.call(this.attrs, name) ? this.attrs[name] : null; }
  setAttribute(name, value) { this.attrs[name] = String(value); }
  scrollIntoView() {}
  dispatchEvent() { return true; }
  click() {}
  closest(selector) {
    for (let node = this; node; node = node.parentElement) {
      if (/\bli\b/.test(selector) && node.tagName === "LI") return node;
      if (/button/.test(selector) && node.tagName === "BUTTON") return node;
      if (/(^|,\s*)a\b/.test(selector) && node.tagName === "A") return node;
    }
    return null;
  }
  querySelectorAll() { return []; }
  querySelector() { return null; }
}

const root = new FakeElement("html");
root.hasAttribute = () => false;
root._attrs = {};
root.getAttribute = (name) => root._attrs[name] || null;
root.setAttribute = (name, value) => { root._attrs[name] = String(value); };

const fromLi = new FakeElement("li", "on", "");
const fromAnchor = fromLi.append(new FakeElement("a", "", "基本信息"));
const targetLi = new FakeElement("li", "", "");
const targetAnchor = targetLi.append(new FakeElement("a", "", "教育背景"));
const saveButton = new FakeElement("button", "save-basic", "保存基本信息");
const successModal = new FakeElement("div", "legacy-message-shell", "信息提示 保存成功 × 关闭");
const successText = successModal.append(new FakeElement("h4", "legacy-message-body", "保存成功"));
// Real Build63 diagnostics showed document text contained 保存成功 while every
// element candidate was filtered out. Reproduce both likely causes: a stale
// aria-hidden=true modal shell and a zero-layout-box text carrier. Build65 must
// still verify the actually rendered text via Range geometry.
successModal.setAttribute("aria-hidden", "true");
successText.rect = { left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0, x: 0, y: 0 };
const headerClose = successModal.append(new FakeElement("button", "legacy-x", "×"));
const modalClose = successModal.append(new FakeElement("button", "legacy-confirm", "✖ 关闭"));
successModal.isConnected = false;
successText.isConnected = false;
headerClose.isConnected = false;
modalClose.isConnected = false;
successModal.querySelectorAll = (selector) => {
  if (selector.includes("button") || selector.includes("[role='button']") || selector.includes("[class*='close' i]")) return [headerClose, modalClose];
  return [];
};
let saveClicks = 0;
let closeClicks = 0;
let headerCloseClicks = 0;
let targetClicks = 0;
let successTextProbeCount = 0;

saveButton.click = () => {
  saveClicks += 1;
  successModal.isConnected = true;
  successText.isConnected = true;
  headerClose.isConnected = true;
  modalClose.isConnected = true;
};
headerClose.click = () => { headerCloseClicks += 1; successModal.isConnected = false; };
modalClose.click = () => {
  closeClicks += 1;
  successModal.isConnected = false;
  successText.isConnected = false;
  headerClose.isConnected = false;
  modalClose.isConnected = false;
};
targetAnchor.click = () => {
  targetClicks += 1;
  fromLi.className = "";
  targetLi.className = "on";
};

let documentStub = null;
const successTextNode = {
  nodeValue: "保存成功",
  textContent: "保存成功",
  parentElement: successText,
  parentNode: successText,
  ownerDocument: null
};

documentStub = {
  nodeType: 9,
  documentElement: root,
  body: new FakeElement("body"),
  createTreeWalker() {
    let yielded = false;
    return {
      nextNode() {
        if (!yielded && successModal.isConnected) { yielded = true; return successTextNode; }
        return null;
      }
    };
  },
  createRange() {
    return {
      selectNodeContents() {},
      getClientRects() { return successModal.isConnected ? [{ width: 68, height: 18 }] : []; },
      getBoundingClientRect() { return successModal.isConnected ? { width: 68, height: 18 } : { width: 0, height: 0 }; }
    };
  },
  querySelectorAll(selector) {
    if (selector === "#fromNav") return [fromAnchor];
    if (selector === "#targetNav") return [targetAnchor];
    if (selector.includes("input[type='button']") && selector.includes("[role='button']")) return [saveButton, fromAnchor, targetAnchor];
    if (selector.includes("field-validation-error") || selector.includes("[class*='error' i]")) return [];
    if (selector.includes("[role='alert']") || selector.includes("[class*='success' i]")) return [];
    if (selector.includes("[role='dialog']") || selector.includes("[aria-modal='true']") || selector.includes("[class*='modal' i]")) return [];
    if (selector === "*") {
      successTextProbeCount += 1;
      return successModal.isConnected && successTextProbeCount >= 2 ? [successText] : [];
    }
    return [];
  },
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; },
  createEvent() { return { initMouseEvent() {} }; },
  dispatchEvent() { return true; }
};
successTextNode.ownerDocument = documentStub;
successText.ownerDocument = documentStub;
successModal.ownerDocument = documentStub;
headerClose.ownerDocument = documentStub;
modalClose.ownerDocument = documentStub;

global.HTMLElement = FakeElement;
global.Element = FakeElement;
global.document = documentStub;
global.window = {
  AF: { Utils: { sleep: async () => {} } },
  top: null,
  location: { hostname: "zhaopin.cnpc.com.cn", pathname: "/web/createResume.html", href: "https://zhaopin.cnpc.com.cn/web/createResume.html" },
  innerWidth: 1400,
  innerHeight: 900,
  getComputedStyle: (el) => el.styleState || { display: "block", visibility: "visible" },
  sessionStorage: { getItem() { return null; }, removeItem() {} },
  postMessage() {}
};
window.top = window;

const realSetTimeout = global.setTimeout;
global.setTimeout = () => 0;
const source = fs.readFileSync(path.join(__dirname, "..", "autofill-plugin", "content", "special-site-workflow.js"), "utf8");
new Function(source)();
global.setTimeout = realSetTimeout;

(async () => {
  const api = window.AF.SpecialSiteWorkflow._test;
  assert.strictEqual(typeof api.runAnalyzedSectionNavigationTransaction, "function");
  const result = await api.runAnalyzedSectionNavigationTransaction({
    from: { text: "基本信息", selectorHint: "#fromNav" },
    target: { text: "教育背景", selectorHint: "#targetNav" },
    requireFromActive: true,
    requireSaveFeedback: true,
    saveFeedbackTimeoutMs: 50,
    saveModalCloseTimeoutMs: 20,
    navigationTimeoutMs: 20
  });
  assert.strictEqual(result.fromActiveBefore, true, "current analyzed navigation item must be active before transaction");
  assert.strictEqual(result.saveButtonFound, true, "transaction must resolve the explicit current-section save button");
  assert.strictEqual(result.saveButtonText, "保存基本信息");
  assert.strictEqual(result.saveClickDispatched, true);
  assert.strictEqual(result.saveFeedbackVerified, true, "visible 保存成功 modal should be read back");
  assert.strictEqual(result.saveFeedbackKind, "modal");
  assert.strictEqual(result.saveFeedbackDetectionStrategy, "rendered_text_node_ancestor");
  assert.strictEqual(result.saveModalDetected, true);
  assert.strictEqual(result.saveModalCloseFound, true);
  assert.strictEqual(result.saveModalCloseClickDispatched, true);
  assert.strictEqual(result.saveModalClosed, true, "verified save modal must be gone before navigation click");
  assert.strictEqual(result.targetNavClickDispatched, true);
  assert.strictEqual(result.targetActiveAfter, true, "target navigation state must be read back as active");
  assert.strictEqual(result.result, "success_verified_save");
  assert.strictEqual(saveClicks, 1);
  assert.strictEqual(closeClicks, 1, "explicit footer 关闭 control should win over header ×");
  assert.strictEqual(headerCloseClicks, 0, "decorative header × should not win when explicit 关闭 exists");
  assert.strictEqual(targetClicks, 1);

  const mainSource = fs.readFileSync(path.join(__dirname, "..", "main.js"), "utf8");
  assert(mainSource.includes('Build65 仅允许测试“基本信息 → 教育背景”'), "main-process gate must refuse later sections in Build65");
  assert(mainSource.includes("requireSaveFeedback: true"), "Build65 must not navigate before explicit save feedback");
  assert(mainSource.includes("saveFeedbackTimeoutMs: 5000"), "Build65 must allow realistic server latency for save feedback");
  assert(source.includes("querySelectorAll(\"*\")"), "Build65 must scan all element tags for explicit success text");
  assert(source.includes("createTreeWalker") && source.includes("createRange"), "Build65 must fall back to rendered Text-node geometry when element boxes are unavailable");
  assert(source.includes("aria-hidden is an accessibility-tree hint"), "Build65 must not treat stale aria-hidden as visual hiding for save feedback");
  assert(source.includes("collectAnalyzedNavigationSaveFeedbackDiagnostics"), "Build65 must log safe failure diagnostics when feedback is not detected");
  assert(mainSource.includes("selectorHitCount || 0) !== 1"), "transaction plan must require analyzer-verified unique navigation selectors");
  assert(mainSource.includes("stableAnalyzedNavigationSelector"), "transaction plan must reject transient navigation selectors");
  assert(!/final submit|最终提交/.test(source), "section transaction runtime must not contain final-application submit behavior");
  console.log("section navigation transaction probe fixture: PASS");
})().catch((error) => { console.error(error); process.exitCode = 1; });
