"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const collector = fs.readFileSync(path.join(root, "autofill-plugin", "content", "site-analysis-collector.js"), "utf8");
const start = collector.indexOf("function navigationItemScore");
const end = collector.indexOf("function collectNavigationSnapshot", start);
assert(start >= 0 && end > start, "navigation canonicalization helpers not found");
const helperSource = collector.slice(start, end);
const resumeTexts = new Set(["示例资料", "教育背景", "外语水平"]);
const canonicalize = new Function(
  "isResumeSectionNavigationText",
  `${helperSource}; return canonicalizeNavigationItems;`
)((text) => resumeTexts.has(text));

const rect = (x, y, width, height) => ({ x, y, width, height });
const items = [
  { text: "个人中心", hrefPath: "/web/centerRecruitInfoList.html", source: "nav_selector", clickable: true, selectorHitCount: 1, tagName: "a", clusterSize: 0, active: false, rect: rect(1000, -1000, 60, 20) },
  { text: "我的简历", hrefPath: "/web/showResume.html", source: "nav_selector", clickable: true, selectorHitCount: 1, tagName: "a", clusterSize: 0, active: false, rect: rect(500, -900, 60, 20) },
  // Form-body heading: same semantic text, but no coherent resume-rail cluster.
  { text: "外语水平", hrefPath: "", source: "semantic_text_fallback", clickable: true, selectorHitCount: 1, tagName: "span", clusterSize: 0, active: false, selectorHint: "#z3 > span", rect: rect(178, 518, 220, 30) },
  // Sidebar duplicates: parent/span + canonical anchor for each section.
  { text: "示例资料", hrefPath: "", source: "semantic_text_fallback", clickable: true, selectorHitCount: 1, tagName: "span", clusterSize: 9, active: true, selectorHint: "li:nth-of-type(1) > span", rect: rect(1037, 75, 90, 54) },
  { text: "示例资料", hrefPath: ";", source: "semantic_text_fallback", clickable: true, selectorHitCount: 1, tagName: "a", clusterSize: 9, active: true, selectorHint: "li:nth-of-type(1) > span > a", rect: rect(1067, 92, 60, 20) },
  { text: "教育背景", hrefPath: "", source: "semantic_text_fallback", clickable: true, selectorHitCount: 1, tagName: "span", clusterSize: 9, active: false, selectorHint: "li:nth-of-type(2) > span", rect: rect(1037, 129, 90, 54) },
  { text: "教育背景", hrefPath: ";", source: "semantic_text_fallback", clickable: true, selectorHitCount: 1, tagName: "a", clusterSize: 9, active: false, selectorHint: "li:nth-of-type(2) > span > a", rect: rect(1067, 146, 60, 20) },
  { text: "外语水平", hrefPath: ";", source: "semantic_text_fallback", clickable: true, selectorHitCount: 1, tagName: "a", clusterSize: 9, active: false, selectorHint: "li:nth-of-type(3) > span > a", rect: rect(1067, 200, 60, 20) }
];

const result = canonicalize(items);
assert.deepStrictEqual(result.map((item) => item.text), ["示例资料", "教育背景", "外语水平"], "resume rail should suppress global nav and body headings");
assert.strictEqual(result.length, 3, "resume rail items should be deduplicated by section text");
assert.strictEqual(result[0].tagName, "a", "canonical section target should prefer the anchor/button");
assert.strictEqual(result[0].selectorHint, "li:nth-of-type(1) > span > a", "canonical section selector should use stable clickable descendant");
assert.strictEqual(result[0].active, true, "active section state must be preserved");
console.log("navigation rail canonicalization fixture: PASS");
