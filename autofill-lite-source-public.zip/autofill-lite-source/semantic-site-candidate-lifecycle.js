"use strict";

function normalizePathname(value) {
  let pathname = String(value || "/").trim() || "/";
  try {
    if (/^https?:\/\//i.test(pathname)) pathname = new URL(pathname).pathname || "/";
  } catch (_) {}
  pathname = pathname.split("?")[0].split("#")[0] || "/";
  if (!pathname.startsWith("/")) pathname = "/" + pathname;
  return pathname;
}

function routeForUrl(rawUrl) {
  try {
    const u = new URL(String(rawUrl || ""));
    return { hostname: u.hostname.toLowerCase(), pathname: normalizePathname(u.pathname || "/") };
  } catch (_) {
    return null;
  }
}

function candidateMatchesUrl(candidate, rawUrl) {
  const route = routeForUrl(rawUrl);
  if (!route || !candidate || typeof candidate !== "object") return false;
  const page = candidate.page || {};
  return String(page.hostname || "").toLowerCase() === route.hostname &&
    normalizePathname(page.pathname || "/") === route.pathname;
}

function buildVerifiedSiteCandidate(candidate, diagnostic, options) {
  options = options || {};
  if (!candidate || typeof candidate !== "object" || !candidate.configTemplate) {
    throw new Error("site candidate missing configTemplate");
  }
  const diag = diagnostic && typeof diagnostic === "object" ? diagnostic : {};
  const aiAssist = diag.aiAssist && typeof diag.aiAssist === "object" ? diag.aiAssist : {};
  if (!aiAssist.siteCandidateInstalled) throw new Error("latest run did not install semantic site candidate");
  if (Number(diag.filledCount || 0) <= 0) throw new Error("latest candidate run did not fill any field");
  if (String(diag.completionStatus || "") === "failed") throw new Error("latest candidate run failed");
  if (diag.manualActionRequired) throw new Error("latest candidate run is paused at a manual checkpoint");

  const cloned = JSON.parse(JSON.stringify(candidate));
  const verifiedAt = options.verifiedAt || new Date().toISOString();
  cloned.schemaType = "autofill-lite-site-config-verified";
  cloned.schemaVersion = Math.max(1, Number(cloned.schemaVersion || 1));
  cloned.configTemplate._serverStatus = "verified";
  cloned.configTemplate._manualCandidate = false;
  cloned.configTemplate._verifiedAt = verifiedAt;
  cloned.configTemplate._verificationSource = "local_human_confirmed";
  cloned.configTemplate._autoConfigStrategy = Object.assign({}, cloned.configTemplate._autoConfigStrategy || {}, {
    mode: "local_verified_semantic_candidate_v1"
  });
  const failedLabels = Array.isArray(diag.failedFields)
    ? diag.failedFields.map((item) => String(item && (item.label || item.fieldKey) || "").trim()).filter(Boolean).slice(0, 30)
    : [];
  cloned.verification = {
    mode: "local_human_confirmed",
    verifiedAt,
    diagnosticAt: String(diag.at || ""),
    buildId: String(diag.buildId || ""),
    filledCount: Number(diag.filledCount || 0),
    failedCount: Number(diag.failedCount || 0),
    unhandledCount: Number(diag.unhandledCount || 0),
    completionStatus: String(diag.completionStatus || ""),
    knownExecutionGapLabels: failedLabels,
    profileValuesIncluded: false,
    selectorsAuthoredByAi: false
  };
  return cloned;
}

module.exports = {
  normalizePathname,
  routeForUrl,
  candidateMatchesUrl,
  buildVerifiedSiteCandidate
};
