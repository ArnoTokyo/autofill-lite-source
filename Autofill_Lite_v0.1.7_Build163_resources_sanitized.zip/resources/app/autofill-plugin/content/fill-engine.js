// content/fill-engine.js — FillEngine (源码 Bt 类, 行66260-66801)
// 三种模式: 示例资料 / structured / xyz51job (由 elementMatcher.config.type / config.name 决定)
//
// 源码参考:
//   类定义+构造函数:        行 66260-66273
//   execute() 模式分发:      行 66275-66364
//   executeXyz51JobFill():   行 66365-66407 (内部委托给一个约1200行的51job专用类 jt/it，
//                            本重建版未逐行搬运该类，而是基于其站点配置结构
//                            (selectors.section/content/row/addButton, 行"dl[dlcolname]")
//                            做了等价的简化实现，详见下方 Xyz51JobFiller)
//   executeSimpleFill():     行 66408-66467
//   executeStructuredFill(): 行 66469-66801 (已删除末尾"获奖竞赛字段AI分析"远程调用 66716-66760，
//                            该分支依赖已下线的 /analyze-competition-fields 接口)
//
// 改造点 (按任务书要求):
//   - 删除 sendExecutionStatistics() / sendFillResultStatistics() 两个远程统计上报调用 (行66345, 66802+)
//   - 删除 executeStructuredFill 末尾的 formatCSVFields + /analyze-competition-fields AI匹配分支
//   - 新增 onProgress(current) 回调 (非原版逻辑，仅用于我们自己的 Panel 进度条 UI)
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});

  // 照片/附件属于人工上传项。过滤自动填充副本，避免旧简历数据中的
  // 示例资料Info.photo 被通用字段匹配误当成文本值写入相邻输入框。
  function withoutManualUploadFields(resumeData) {
    if (!resumeData || typeof resumeData !== "object") return resumeData || {};
    var copy = Object.assign({}, resumeData);
    if (resumeData.示例资料Info && typeof resumeData.示例资料Info === "object") {
      copy.示例资料Info = Object.assign({}, resumeData.示例资料Info);
      ["photo", "idPhoto", "lifePhoto"].forEach(function (key) {
        delete copy.示例资料Info[key];
      });
    }
    return copy;
  }

  function FillEngine(resumeData, elementMatcher) {
    this.resumeData = withoutManualUploadFields(resumeData);
    this.elementMatcher = elementMatcher;
    this.dataMatcher = new AF.DataMatcher(resumeData, elementMatcher && elementMatcher.config);
    this.formHandler = new AF.FormHandler(elementMatcher, this.dataMatcher);
    this.isRunning = false;
    this.cancelRequested = false;
    this.shouldStop = null;
    this.onProgress = null; // (current, total) => void，由调用方(content/index.js)设置
    this.universalCheckpointRuntime = null; // Build136 universal FIELD/RECORD/SECTION/WORKFLOW recovery session
    this.fieldCheckpointRuntime = null; // compatibility facade over universal runtime
    this.recordCheckpointRuntime = null; // compatibility facade over universal runtime
    this.sectionCheckpointRuntime = null;
    this.示例资料flowCheckpointRuntime = null;
  }

  FillEngine.prototype.isCancelled = function () {
    return this.cancelRequested === true || (typeof this.shouldStop === "function" && this.shouldStop());
  };

  FillEngine.prototype.beginFormFieldCheckpointRuntime = async function (preserveExistingLedger) {
    if (!AF.CheckpointCore || typeof AF.CheckpointCore.beginFormFieldRun !== "function") return null;
    try {
      this.fieldCheckpointRuntime = await AF.CheckpointCore.beginFormFieldRun(window.location, { preserveExistingLedger: !!preserveExistingLedger });
      this.formHandler.fieldCheckpointRuntime = this.fieldCheckpointRuntime;
      return this.fieldCheckpointRuntime;
    } catch (e) {
      this.fieldCheckpointRuntime = null;
      this.formHandler.fieldCheckpointRuntime = null;
      return null;
    }
  };

  FillEngine.prototype.beginFormRecordCheckpointRuntime = async function (preserveExistingLedger) {
    if (!AF.CheckpointCore || typeof AF.CheckpointCore.beginFormRecordRun !== "function") return null;
    try {
      this.recordCheckpointRuntime = await AF.CheckpointCore.beginFormRecordRun(window.location, {
        preserveExistingLedger: !!preserveExistingLedger
      });
      this.formHandler.recordCheckpointRuntime = this.recordCheckpointRuntime;
      if (this.formHandler.experienceHandler) {
        this.formHandler.experienceHandler.recordCheckpointRuntime = this.recordCheckpointRuntime;
      }
      return this.recordCheckpointRuntime;
    } catch (e) {
      this.recordCheckpointRuntime = null;
      this.formHandler.recordCheckpointRuntime = null;
      if (this.formHandler.experienceHandler) this.formHandler.experienceHandler.recordCheckpointRuntime = null;
      return null;
    }
  };

  FillEngine.prototype.beginUniversalCheckpointRuntime = async function () {
    if (!AF.CheckpointRuntime || typeof AF.CheckpointRuntime.begin !== "function") {
      // Compatibility fallback for old manifests/tests.
      await this.beginFormFieldCheckpointRuntime(false);
      await this.beginFormRecordCheckpointRuntime(false);
      return null;
    }
    try {
      this.universalCheckpointRuntime = await AF.CheckpointRuntime.begin(window.location, { 示例资料flowId: "autofill-core-universal-v1" });
      this.fieldCheckpointRuntime = AF.CheckpointRuntime.facade(this.universalCheckpointRuntime, "field");
      this.recordCheckpointRuntime = AF.CheckpointRuntime.facade(this.universalCheckpointRuntime, "record");
      this.sectionCheckpointRuntime = AF.CheckpointRuntime.facade(this.universalCheckpointRuntime, "section");
      this.示例资料flowCheckpointRuntime = AF.CheckpointRuntime.facade(this.universalCheckpointRuntime, "示例资料flow");
      this.formHandler.fieldCheckpointRuntime = this.fieldCheckpointRuntime;
      this.formHandler.recordCheckpointRuntime = this.recordCheckpointRuntime;
      if (this.formHandler.experienceHandler) this.formHandler.experienceHandler.recordCheckpointRuntime = this.recordCheckpointRuntime;
      return this.universalCheckpointRuntime;
    } catch (e) {
      this.universalCheckpointRuntime = null;
      this.sectionCheckpointRuntime = null;
      this.示例资料flowCheckpointRuntime = null;
      await this.beginFormFieldCheckpointRuntime(false);
      await this.beginFormRecordCheckpointRuntime(false);
      return null;
    }
  };

  FillEngine.prototype.maybePauseWorkflowCheckpoint = async function (result, mode) {
    if (!this.示例资料flowCheckpointRuntime || !this.示例资料flowCheckpointRuntime.pause ||
        (this.universalCheckpointRuntime && this.universalCheckpointRuntime.paused)) return false;
    if (!result || result.success !== false) return false;
    var raw = String(result.message || "");
    if (Array.isArray(result.failedFields) && result.failedFields.length) {
      raw += "；" + result.failedFields.slice(0, 5).map(function (item) {
        return [item && item.label, item && item.reason].filter(Boolean).join("：");
      }).filter(Boolean).join("；");
    }
    if (!raw) return false;
    var meta = {
      granularity: "示例资料flow",
      示例资料flowId: "autofill-core-universal-v1",
      name: String(this.elementMatcher && this.elementMatcher.config && this.elementMatcher.config.name || mode || "当前填写流程"),
      sectionTitle: "当前填写流程",
      category: ""
    };
    var checkpoint = await this.示例资料flowCheckpointRuntime.pause(meta, raw, { result: result, phase: "示例资料flow" });
    return !!checkpoint;
  };

  FillEngine.prototype.applyUniversalCheckpointResult = function (result) {
    var runtime = this.universalCheckpointRuntime;
    if (!runtime || !AF.CheckpointRuntime) return result;
    result = Object.assign({}, result || {});
    result.checkpointRuntime = AF.CheckpointRuntime.snapshot(runtime);
    result.formSectionCheckpoint = this.sectionCheckpointRuntime ? {
      enabled: true, granularity: "section", resumed: !!this.sectionCheckpointRuntime.resumed,
      checkpointResolved: !!this.sectionCheckpointRuntime.checkpointResolved,
      checkpointCreated: !!this.sectionCheckpointRuntime.checkpointCreated, paused: !!this.sectionCheckpointRuntime.paused,
      ledger: this.sectionCheckpointRuntime.snapshotLedger()
    } : null;
    result.formWorkflowCheckpoint = this.示例资料flowCheckpointRuntime ? {
      enabled: true, granularity: "示例资料flow", resumed: !!this.示例资料flowCheckpointRuntime.resumed,
      checkpointResolved: !!this.示例资料flowCheckpointRuntime.checkpointResolved,
      checkpointCreated: !!this.示例资料flowCheckpointRuntime.checkpointCreated, paused: !!this.示例资料flowCheckpointRuntime.paused,
      ledger: this.示例资料flowCheckpointRuntime.snapshotLedger()
    } : null;
    result.resumedFromRecoveryCheckpoint = !!(result.resumedFromRecoveryCheckpoint || runtime.resumed);
    result.recoveryCheckpointResolved = !!(result.recoveryCheckpointResolved || runtime.checkpointResolved);
    if (runtime.paused) {
      result.success = false;
      result.manualActionRequired = true;
      result.pausedForManualAction = true;
      result.failureContext = runtime.failureContext || result.failureContext || null;
      result.recoveryCheckpoint = runtime.checkpoint || result.recoveryCheckpoint || null;
      result.recoveryCheckpointCreated = !!runtime.checkpointCreated;
      result.manualActionStep = String(runtime.failureContext && (runtime.failureContext.fieldLabel || runtime.failureContext.stepName) || result.manualActionStep || "当前内容");
      result.manualActionReason = String(runtime.failureContext && runtime.failureContext.humanSummary || result.manualActionReason || "当前内容需要人工处理");
      result.message = String(runtime.failureContext && runtime.failureContext.humanSummary || result.message || "当前内容需要人工处理");
    }
    return result;
  };

  FillEngine.prototype.applyFormRecordCheckpointResult = function (result) {
    var runtime = this.recordCheckpointRuntime;
    if (!runtime) return result;
    result = Object.assign({}, result || {});
    result.formRecordCheckpoint = AF.CheckpointCore && typeof AF.CheckpointCore.snapshotFormRecordRuntime === "function"
      ? AF.CheckpointCore.snapshotFormRecordRuntime(runtime) : null;
    result.formRecordExecutionLedger = runtime.ledger && AF.CheckpointCore && typeof AF.CheckpointCore.snapshotFormRecordLedger === "function"
      ? AF.CheckpointCore.snapshotFormRecordLedger(runtime.ledger) : null;
    result.resumedFromRecoveryCheckpoint = !!(result.resumedFromRecoveryCheckpoint || runtime.resumed);
    result.recoveryCheckpointResolved = !!(result.recoveryCheckpointResolved || runtime.checkpointResolved);
    if (runtime.paused) {
      result.success = false;
      result.manualActionRequired = true;
      result.pausedForManualAction = true;
      result.failureContext = runtime.failureContext || null;
      result.recoveryCheckpoint = runtime.checkpoint || null;
      result.recoveryCheckpointCreated = !!runtime.checkpointCreated;
      result.manualActionStep = String(runtime.failureContext && (runtime.failureContext.fieldLabel || runtime.failureContext.stepName) || "当前经历");
      result.manualActionReason = String(runtime.failureContext && runtime.failureContext.humanSummary || "当前经历需要人工保存");
      result.message = String(runtime.failureContext && runtime.failureContext.humanSummary || result.message || "当前经历需要人工保存");
    } else if (runtime.resumed && runtime.resumeRecordSeen &&
               Number(this.formHandler.filledFieldsCount || 0) === 0 &&
               (!this.formHandler.failedFields || this.formHandler.failedFields.length === 0)) {
      result.success = true;
      result.message = "[记录恢复] 已按用户再次运行确认上条经历已手动保存；当前页没有剩余可自动填写内容。";
    }
    return result;
  };

  FillEngine.prototype.applyFormFieldCheckpointResult = function (result) {
    var runtime = this.fieldCheckpointRuntime;
    if (!runtime) return result;
    result = Object.assign({}, result || {});
    result.formFieldCheckpoint = AF.CheckpointCore && typeof AF.CheckpointCore.snapshotFormFieldRuntime === "function"
      ? AF.CheckpointCore.snapshotFormFieldRuntime(runtime) : null;
    result.executionLedger = runtime.ledger && AF.CheckpointCore && typeof AF.CheckpointCore.snapshotFormFieldLedger === "function"
      ? AF.CheckpointCore.snapshotFormFieldLedger(runtime.ledger) : null;
    result.resumedFromRecoveryCheckpoint = !!runtime.resumed;
    result.recoveryCheckpointResolved = !!runtime.checkpointResolved;
    if (runtime.paused) {
      result.success = false;
      result.manualActionRequired = true;
      result.pausedForManualAction = true;
      result.failureContext = runtime.failureContext || null;
      result.recoveryCheckpoint = runtime.checkpoint || null;
      result.recoveryCheckpointCreated = !!runtime.checkpointCreated;
      result.manualActionStep = String(runtime.failureContext && (runtime.failureContext.fieldLabel || runtime.failureContext.stepName) || "当前字段");
      result.manualActionReason = String(runtime.failureContext && runtime.failureContext.humanSummary || "当前字段需要人工处理");
      result.message = String(runtime.failureContext && runtime.failureContext.humanSummary || result.message || "当前字段需要人工处理");
    } else if (runtime.resumed && runtime.resumeFieldSeen &&
               Number(this.formHandler.filledFieldsCount || 0) === 0 &&
               (!this.formHandler.failedFields || this.formHandler.failedFields.length === 0)) {
      result.success = true;
      result.message = "[字段恢复] 已按用户再次运行确认上次字段已手动处理；当前页没有剩余可自动填写字段。";
    }
    return result;
  };

  var ARRAY_CATEGORIES = {
    示例资料: true,
    示例资料Experience: true,
    示例资料Experience: true,
    示例资料Experience: true,
    示例资料Experience: true,
    示例资料: true,
    示例资料Skills: true,
    示例资料: true,
    campusLeadership: true,
    campusActivities: true,
    示例资料Members: true,
    publications: true,
    示例资料s: true,
  };
  var visibleFillCursorByPage = {};

  function normalizeRuntimeSemanticLabel(value) {
    return String(value == null ? "" : value).replace(/[\s：:*?？（）()【】\[\]「」'"“”‘’.,，。;；、]/g, "").toLowerCase();
  }

  function resolveRuntimeSemanticMapping(labelText, categoryMatch) {
    try {
      var patch = AF.RuntimeSemanticPatch;
      var mappings = patch && Array.isArray(patch.fieldMappings) ? patch.fieldMappings : [];
      if (!mappings.length || !labelText) return null;
      var wanted = normalizeRuntimeSemanticLabel(labelText);
      if (!wanted) return null;
      var matched = mappings.filter(function (item) {
        return item && item.category && item.fieldKey && wanted === normalizeRuntimeSemanticLabel(item.label);
      });
      if (!matched.length) return null;
      var inferredCategory = "";
      if (typeof categoryMatch === "string") inferredCategory = categoryMatch;
      else if (categoryMatch && typeof categoryMatch === "object") inferredCategory = String(categoryMatch.category || categoryMatch.type || "");
      if (inferredCategory) {
        var sameCategory = matched.filter(function (item) { return String(item.category) === inferredCategory; });
        if (sameCategory.length === 1) return { category: sameCategory[0].category, field: sameCategory[0].fieldKey, source: "runtime_ai_semantic" };
      }
      if (matched.length === 1) return { category: matched[0].category, field: matched[0].fieldKey, source: "runtime_ai_semantic" };
      return null;
    } catch (e) {
      return null;
    }
  }

  function pageCursorKey() {
    return location.hostname + "|" + location.pathname + "|" + location.search;
  }

  function getArrayCursor(category) {
    var key = pageCursorKey();
    visibleFillCursorByPage[key] = visibleFillCursorByPage[key] || {};
    return visibleFillCursorByPage[key][category] || 0;
  }

  function advanceArrayCursor(category, index) {
    var key = pageCursorKey();
    visibleFillCursorByPage[key] = visibleFillCursorByPage[key] || {};
    visibleFillCursorByPage[key][category] = Math.max(visibleFillCursorByPage[key][category] || 0, index + 1);
  }

  function cloneInteractiveRecord(row, category) {
    if (!row || typeof row !== "object") return null;
    return { category: category, data: Object.assign({}, row, { __afCategory: category }) };
  }

  function buildInteractiveModuleRowPlan(title, resumeData) {
    var normalizedTitle = normalizeButtonText(title);
    resumeData = resumeData || {};
    if (/实习\s*[\/／]\s*项目经历/.test(normalizedTitle)) {
      var combined = [];
      (Array.isArray(resumeData.示例资料Experience) ? resumeData.示例资料Experience : []).forEach(function (row) {
        var item = cloneInteractiveRecord(row, "示例资料Experience");
        if (item) combined.push(item);
      });
      (Array.isArray(resumeData.示例资料Experience) ? resumeData.示例资料Experience : []).forEach(function (row) {
        var item = cloneInteractiveRecord(row, "示例资料Experience");
        if (item) combined.push(item);
      });
      return combined;
    }
    if (/最高学历.*示例资料|最高学历教育/.test(normalizedTitle)) {
      var 示例资料 = Array.isArray(resumeData.示例资料) ? resumeData.示例资料 : [];
      if (!示例资料.length) return [];
      var highest = 示例资料.find(function (row) {
        return row && /^(是|true|1)$/i.test(String(row.isHighestEducation != null ? row.isHighestEducation : row.ccbHighestEducation || ""));
      }) || 示例资料[0];
      var highestItem = cloneInteractiveRecord(highest, "示例资料");
      return highestItem ? [highestItem] : [];
    }
    return [];
  }

  function getSelfIntroductionValue(resumeData) {
    var raw = resumeData && resumeData.示例资料Introduction;
    if (!raw) return "";
    if (typeof raw === "string") return raw.trim();
    return String(raw.示例资料Introduction || raw.summary || raw.description || "").trim();
  }

  function hasExistingValue(element) {
    var value = "";
    try {
      value = AF.FillTrace && AF.FillTrace.readElementValue ? AF.FillTrace.readElementValue(element) : "";
    } catch (e) {
      value = "";
    }
    var normalized = String(value || "").replace(/\s+/g, "").trim();
    if (!normalized) return false;
    if (/^(未选|请选择|请输入|--|—|-|null|undefined)$/i.test(normalized)) return false;
    if (/^(未选\/?)+$/.test(normalized)) return false;
    return true;
  }

  FillEngine.prototype.fillPddSelfAssessmentFallback = async function () {
    var value = getSelfIntroductionValue(this.resumeData);
    if (!value) return false;
    var container = document.querySelector("#示例资料Assessment");
    if (!container || !AF.DomUtils.isElementVisible(container)) return false;
    var control = Array.from(container.querySelectorAll("textarea, input:not([type='hidden']), [contenteditable='true']")).find(function (el) {
      return AF.DomUtils.isElementVisible(el) && !hasExistingValue(el);
    });
    if (!control) return false;
    if (AF.FillTrace) {
      AF.FillTrace.setModule("自我评价");
      AF.FillTrace.setFieldContext({
        category: "示例资料Introduction",
        label: "自我评价",
        fieldKey: "示例资料Introduction",
        plannedValue: value,
      });
    }
    var type = control.getAttribute && control.getAttribute("contenteditable") === "true" ? "contentEditable" : "text";
    var ok = await AF.FormHandler.fillFormElement(control, value, type);
    if (ok) {
      this.formHandler.filledFieldsCount++;
      if (AF.FillTrace) AF.FillTrace.event("示例资料_assessment_fallback", "已通过 #示例资料Assessment 兜底填写自我评价", "success");
    }
    return ok;
  };

  function isManualOnlyField(labelText, element) {
    if (/上传|附件|照片|证件照|生活照|简历文件|作品集|文件/.test(labelText || "")) return true;
    if (!element) return false;
    var nodes = Array.isArray(element) ? element : [element];
    return nodes.some(function (el) {
      if (!el) return false;
      if (el.type === "file") return true;
      if (el.closest && el.closest(".ant-upload, .el-upload, .aui-upload, [class*='upload' i], [class*='attachment' i]")) return true;
      var action = el.closest && el.closest("button, label, a, [role='button'], [class*='button' i], [class*='btn' i]");
      var text = String(action && action.textContent || "").replace(/\s+/g, "");
      if (/上传|附件|选择文件|照片|证件照|生活照|upload|attachment/i.test(text)) return true;
      return Boolean(action && action.querySelector && action.querySelector('input[type="file"]'));
    });
  }

  function normalizeLanguageScoreValue(category, fieldKey, value) {
    if (category !== "示例资料Skills" || fieldKey !== "score" || value === undefined || value === null) return value;
    var text = String(value).trim();
    if (!text) return value;
    var numbers = text.match(/\d+(?:\.\d+)?/g);
    if (!numbers || numbers.length === 0) return value;
    return numbers[numbers.length - 1];
  }

  function joinNonEmpty(values) {
    return (values || []).filter(function (v) { return v !== undefined && v !== null && String(v).trim() !== ""; }).join("；");
  }

  function deriveAwardsLegacyValue(resume, fieldKey) {
    if (!resume) return "";
    var 示例资料 = Array.isArray(resume.示例资料) ? resume.示例资料 : [];
    var 示例资料 = Array.isArray(resume.示例资料) ? resume.示例资料 : [];
    if (fieldKey === "competitionExperience") {
      return joinNonEmpty([
        joinNonEmpty(示例资料.map(function (row) { return row && row.competitions; })),
        joinNonEmpty(示例资料.filter(function (row) {
          return /竞赛|大赛|比赛|创新创业|产品/.test(String(row && (row.awardCategory || row.awardName) || ""));
        }).map(function (row) {
          return [row.awardName, row.awardLevel, row.awardGrade].filter(Boolean).join(" ");
        })),
      ]);
    }
    if (fieldKey === "rewardsAndHonors") {
      return joinNonEmpty([
        joinNonEmpty(示例资料.map(function (row) { return row && [row.honors, row.scholarship].filter(Boolean).join("、"); })),
        joinNonEmpty(示例资料.map(function (row) {
          return [row.awardName, row.awardLevel, row.awardGrade].filter(Boolean).join(" ");
        })),
      ]);
    }
    return "";
  }

  function resolveRuntimeValueCandidate(category, fieldKey) {
    try {
      if (!category || !fieldKey || ARRAY_CATEGORIES[category]) return null;
      var patch = AF.RuntimeSemanticPatch;
      var candidates = patch && Array.isArray(patch.valueCandidates) ? patch.valueCandidates : [];
      var matches = candidates.filter(function (item) {
        return item && String(item.category || "") === String(category) && String(item.fieldKey || "") === String(fieldKey) && item.value != null && String(item.value).trim() !== "";
      });
      if (!matches.length) return null;
      var values = Array.from(new Set(matches.map(function (item) { return String(item.value).trim(); }).filter(Boolean)));
      if (values.length !== 1) return null;
      matches.sort(function (a, b) { return Number(b.confidence || 0) - Number(a.confidence || 0); });
      return { value: values[0], confidence: Number(matches[0].confidence || 0), mode: String(matches[0].mode || ""), source: String(matches[0].source || "ai_value_candidate") };
    } catch (e) { return null; }
  }

  function resolveVisibleValue(resume, category, fieldKey, arrayIndex) {
    if (!resume || !category || !fieldKey) return { hasValue: false, value: null, usedIndex: null };
    if (category === "示例资料" && (fieldKey === "competitionExperience" || fieldKey === "rewardsAndHonors")) {
      var derived = deriveAwardsLegacyValue(resume, fieldKey);
      if (derived) return { hasValue: true, value: derived, usedIndex: null };
    }
    var bucket = resume[category];
    if (Array.isArray(bucket)) {
      if (!bucket.length) return { hasValue: false, value: null, usedIndex: null };
      var start = typeof arrayIndex === "number" && arrayIndex >= 0 ? arrayIndex : getArrayCursor(category);
      for (var i = start; i < bucket.length; i++) {
        if (!bucket[i]) continue;
        var v = bucket[i][fieldKey];
        if (v != null && v !== "") return { hasValue: true, value: v, usedIndex: i };
      }
      return { hasValue: false, value: null, usedIndex: start };
    }
    if (bucket && typeof bucket === "object") {
      var value = bucket[fieldKey];
      if (
        category === "示例资料Info" &&
        AF.DomUtils && typeof AF.DomUtils.resolveAddressValue === "function" &&
        /^(nativePlace|birthOrigin|hukouLocation|archiveLocation|currentAddress|示例资料Location|schoolLocation|expectedLocation)$/.test(fieldKey)
      ) {
        value = AF.DomUtils.resolveAddressValue(bucket, fieldKey);
      }
      if (value != null && value !== "") return { hasValue: true, value: value, usedIndex: null, source: "profile" };
      var candidate = resolveRuntimeValueCandidate(category, fieldKey);
      if (candidate) return { hasValue: true, value: candidate.value, usedIndex: null, source: candidate.source, candidateMode: candidate.mode, candidateConfidence: candidate.confidence };
      return { hasValue: false, value: value, usedIndex: null };
    }
    var fallbackCandidate = resolveRuntimeValueCandidate(category, fieldKey);
    if (fallbackCandidate) return { hasValue: true, value: fallbackCandidate.value, usedIndex: null, source: fallbackCandidate.source, candidateMode: fallbackCandidate.mode, candidateConfidence: fallbackCandidate.confidence };
    return { hasValue: false, value: null, usedIndex: null };
  }

  function resolveFillType(element, elementType, value) {
    var resolvedType = elementType || "text";
    if (resolvedType === "input") resolvedType = "text";
    if (resolvedType === "contenteditable") resolvedType = "contentEditable";
    if (AF.DomUtils.isDateValue(value) && !/^(radio|checkbox|multiSelect)$/i.test(String(resolvedType || ""))) {
      resolvedType = "date";
    } else if (resolvedType === "text") {
      if (AF.DomUtils.isDatePicker(element) || AF.DomUtils.isDateValue(value)) {
        resolvedType = "date";
      } else if (AF.DomUtils.isNormalSelect(element) || AF.DomUtils.isSearchSelect(element)) {
        resolvedType = "search";
      }
    } else if (resolvedType === "select" && AF.DomUtils.isSearchSelect(element)) {
      resolvedType = "search";
    }
    return resolvedType;
  }

  function normalizeButtonText(text) {
    return String(text || "").replace(/\s+/g, "").trim();
  }

  function isVisibleNode(el) {
    if (!el || !AF.DomUtils || typeof AF.DomUtils.isElementVisible !== "function") return false;
    return AF.DomUtils.isElementVisible(el);
  }

  function hasEditableControl(root) {
    if (!root || !root.querySelectorAll) return false;
    var controls = Array.from(root.querySelectorAll(
      "input:not([type='hidden']):not([type='file']), textarea, select, [contenteditable='true'], .el-input__inner, .el-textarea__inner"
    ));
    return controls.some(function (el) {
      if (!isVisibleNode(el)) return false;
      var tag = String(el.tagName || "").toLowerCase();
      var type = String(el.getAttribute && el.getAttribute("type") || "").toLowerCase();
      if (tag === "input" && (type === "hidden" || type === "file")) return false;
      return true;
    });
  }

  function getVisibleDialogs() {
    var dialogs = Array.from(document.querySelectorAll(
      ".el-dialog__wrapper, .el-dialog, [role='dialog'], .ant-modal, .ant-modal-wrap"
    ));
    return dialogs.filter(function (dialog) {
      if (!isVisibleNode(dialog)) return false;
      if (dialog.closest && dialog.closest("#autofill-panel-root, #__af_report_buttons__, #__af_diagnostic_btn__, #autofill-mini-logo")) return false;
      return true;
    });
  }

  function findVisibleModuleDialog() {
    var dialogs = getVisibleDialogs();
    for (var i = dialogs.length - 1; i >= 0; i--) {
      if (hasEditableControl(dialogs[i])) return dialogs[i];
    }
    return null;
  }

  function isForbiddenModuleButtonText(text) {
    return /立即投递|一键移除并投递|投递|提交|删除|移除|取消|我知道了|关闭|添加志愿|新增志愿|增加志愿|修改志愿|选择志愿|职位详情|岗位详情/.test(normalizeButtonText(text));
  }

  function isRepeatableExperienceModuleTitle(title) {
    return /示例资料|教育背景|学习经历|示例资料|示例资料|工作\/示例资料|项目经历|项目经验|校园经历|校园活动|校内活动|社会实践|示例资料|奖励情况|奖励活动|获奖|荣誉|证书|示例资料|家庭成员|亲属|论文|科研/.test(normalizeButtonText(title));
  }

  function getModuleTitle(module) {
    if (!module || !module.querySelector) return "";
    var titleEl = module.querySelector(".resume-module-header .title, .module-title, .title");
    return AF.LabelUtils && typeof AF.LabelUtils.getLabelText === "function"
      ? AF.LabelUtils.getLabelText(titleEl || module)
      : (titleEl && titleEl.textContent || "");
  }

  function findModuleActionButton(module) {
    if (!module || !module.querySelectorAll) return null;
    var candidates = Array.from(module.querySelectorAll(
      ".resume-module-header .right .custom-button, .resume-module-header button, .resume-module-header a, .resume-module-header [role='button'], .addBtn, button, a, [role='button']"
    ));
    for (var i = 0; i < candidates.length; i++) {
      var btn = candidates[i];
      if (!isVisibleNode(btn)) continue;
      var text = normalizeButtonText(btn.innerText || btn.textContent || btn.getAttribute("aria-label") || btn.getAttribute("title"));
      if (!text || isForbiddenModuleButtonText(text)) continue;
      if (/^(编辑|添加|新增|修改)$/.test(text) || /编辑|添加|新增|修改/.test(text)) return btn;
    }
    return null;
  }

  function findModuleByTitle(title) {
    var wanted = normalizeButtonText(title);
    var modules = Array.from(document.querySelectorAll(".resume .resume-module"));
    return modules.find(function (module) {
      return normalizeButtonText(getModuleTitle(module)) === wanted;
    }) || null;
  }

  function getSubstantiveModuleCards(module) {
    if (!module || !module.querySelectorAll) return [];
    var cards = Array.from(module.querySelectorAll(".common-item"));
    // 智联校园（中国联通）用 apply-form 表示一张只读经历卡片，编辑入口是
    // 卡片内的 .icon-box，而不是 button/custom-button。
    if (!cards.length) cards = Array.from(module.querySelectorAll(".apply-module__form > .apply-form"));
    return cards.filter(function (card) {
      if (!isVisibleNode(card)) return false;
      if (card.querySelector(".module-tip")) return false;
      return Boolean(card.querySelector(".field-list-box, .field-list, .custom-button, button, [role='button'], .icon-box"));
    });
  }

  function findCardEditButton(card) {
    if (!card || !card.querySelectorAll) return null;
    var candidates = Array.from(card.querySelectorAll(".custom-button, button, a, [role='button'], .icon-box"));
    return candidates.find(function (button) {
      if (!isVisibleNode(button)) return false;
      var text = normalizeButtonText(button.innerText || button.textContent || button.getAttribute("aria-label") || button.getAttribute("title"));
      return /编辑|修改/.test(text) && !isForbiddenModuleButtonText(text);
    }) || null;
  }

  function findDialogButton(dialog, preferredPattern, forbiddenPattern) {
    if (!dialog || !dialog.querySelectorAll) return null;
    var buttons = Array.from(dialog.querySelectorAll("button, a, [role='button'], .el-button, .custom-button"));
    for (var i = buttons.length - 1; i >= 0; i--) {
      var btn = buttons[i];
      if (!isVisibleNode(btn)) continue;
      var text = normalizeButtonText(btn.innerText || btn.textContent || btn.getAttribute("aria-label") || btn.getAttribute("title"));
      if (!text) continue;
      if (forbiddenPattern && forbiddenPattern.test(text)) continue;
      if (preferredPattern.test(text)) return btn;
    }
    return null;
  }

  function findDialogSaveButton(dialog) {
    return findDialogButton(dialog, /保存|确定|确认|完成|保存并/, /立即投递|投递|申请|删除|移除|取消|关闭|我知道了|下一步|上一步|返回/);
  }

  function findDialogCancelButton(dialog) {
    return findDialogButton(dialog, /取消|关闭/, /立即投递|投递|提交|申请|删除|移除/);
  }

  async function waitForModuleDialog(beforeSet, timeoutMs) {
    var started = Date.now();
    while (Date.now() - started < (timeoutMs || 3000)) {
      var dialogs = getVisibleDialogs();
      for (var i = dialogs.length - 1; i >= 0; i--) {
        var dialog = dialogs[i];
        if (beforeSet && beforeSet.has(dialog) && !hasEditableControl(dialog)) continue;
        if (hasEditableControl(dialog)) return dialog;
      }
      await AF.Utils.sleep(120);
    }
    return findVisibleModuleDialog();
  }

  function findModuleEditSurface(module) {
    if (!module || !module.querySelectorAll) return null;
    if (hasEditableControl(module)) return module;
    return null;
  }

  async function waitForModuleEditSurface(module, beforeSet, timeoutMs) {
    var started = Date.now();
    while (Date.now() - started < (timeoutMs || 3000)) {
      var dialog = await waitForModuleDialog(beforeSet, 180);
      if (dialog && hasEditableControl(dialog)) return { surface: dialog, kind: "dialog" };
      var inline = findModuleEditSurface(module);
      if (inline) return { surface: inline, kind: "inline" };
      await AF.Utils.sleep(120);
    }
    var lastDialog = findVisibleModuleDialog();
    if (lastDialog) return { surface: lastDialog, kind: "dialog" };
    var lastInline = findModuleEditSurface(module);
    if (lastInline) return { surface: lastInline, kind: "inline" };
    return null;
  }

  function normalizeCustomQuestion(text) {
    return String(text || "")
      .replace(/[\s：:*?？（）()【】\[\]「」'"“”‘’.,，。;；、]/g, "")
      .replace(/必填|选填|请输入|请选择/g, "")
      .toLowerCase();
  }

  function resolveCustomQuestionAnswer(resumeData, labelText) {
    var wanted = normalizeCustomQuestion(labelText);
    if (!wanted || !resumeData || !Array.isArray(resumeData.customAnswers)) return null;
    for (var i = 0; i < resumeData.customAnswers.length; i++) {
      var row = resumeData.customAnswers[i];
      if (!row) continue;
      if (normalizeCustomQuestion(row.question) === wanted && row.answer != null && String(row.answer).trim() !== "") {
        return String(row.answer);
      }
    }
    return null;
  }

  function inferCategoryFromVisibleContext(dataMatcher, labelEl, labelText) {
    var contextTexts = [];
    try {
      var module = labelEl && labelEl.closest && labelEl.closest(".resume-module");
      var moduleTitle = getModuleTitle(module);
      if (moduleTitle) contextTexts.push(moduleTitle);
    } catch (e) {}
    try {
      var dialog = labelEl && labelEl.closest && labelEl.closest(".el-dialog, .el-dialog__wrapper, [role='dialog'], .ant-modal, .ant-modal-wrap");
      var dialogTitle = dialog && dialog.querySelector && dialog.querySelector(".el-dialog__title, .ant-modal-title, .title, h1, h2, h3");
      if (dialogTitle && dialogTitle.textContent) contextTexts.push(dialogTitle.textContent);
    } catch (e2) {}
    try {
      var nearbyTitle = labelEl && labelEl.closest && labelEl.closest("section, form, .form, .card, .module, .resume-module, .el-dialog, .ant-modal");
      var heading = nearbyTitle && nearbyTitle.querySelector && nearbyTitle.querySelector("h1, h2, h3, h4, .title, .module-title, .resume-module-header .title");
      if (heading && heading.textContent) contextTexts.push(heading.textContent);
    } catch (e3) {}

    for (var i = 0; i < contextTexts.length; i++) {
      var categoryInfo = dataMatcher.getCategoryByTitle(contextTexts[i], { returnMultiple: /实习|项目|工作/.test(contextTexts[i]) });
      if (Array.isArray(categoryInfo) && categoryInfo.length) {
        for (var m = 0; m < categoryInfo.length; m++) {
          var multiField = dataMatcher.findFieldByCategory(categoryInfo[m].category, labelText);
          if (multiField) return { category: categoryInfo[m].category, field: multiField };
        }
      } else if (categoryInfo && categoryInfo.category) {
        var field = dataMatcher.findFieldByCategory(categoryInfo.category, labelText);
        if (field) return { category: categoryInfo.category, field: field };
      }
    }

    var preferredCategories = [
      "示例资料Info",
      "jobIntention",
      "示例资料",
      "示例资料Experience",
      "示例资料Experience",
      "示例资料Experience",
      "示例资料Skills",
      "示例资料Skills",
      "professionalSkills",
      "示例资料",
      "示例资料",
      "示例资料Members",
      "示例资料Introduction",
    ];
    for (var c = 0; c < preferredCategories.length; c++) {
      var fallbackField = dataMatcher.findFieldByCategory(preferredCategories[c], labelText);
      if (fallbackField) return { category: preferredCategories[c], field: fallbackField };
    }
    return null;
  }

  function runtimeSelectorType(controlType, element, value) {
    var raw = String(controlType || "").toLowerCase();
    var base = "text";
    if (raw === "radio") base = "radio";
    else if (raw === "checkbox") base = "checkbox";
    else if (raw === "native-select" || raw === "select") base = "select";
    else if (raw === "textarea") base = "longText";
    else if (raw === "search") base = "search";
    else if (raw === "date") base = "date";
    return resolveFillType(element, base, value);
  }

  FillEngine.prototype.executeRuntimeSelectorOverlayFill = async function () {
    var patch = AF.RuntimeSemanticPatch;
    var mappings = patch && Array.isArray(patch.selectorMappings) ? patch.selectorMappings : [];
    if (!mappings.length) return null;

    var attempted = 0;
    var committed = 0;
    var localFailures = [];
    var trace = [];
    for (var i = 0; i < mappings.length; i++) {
      if (this.isCancelled()) break;
      var mapping = mappings[i] || {};
      var category = String(mapping.category || "");
      var fieldKey = String(mapping.fieldKey || "");
      var selector = String(mapping.selector || "");
      if (!category || !fieldKey || !selector || ARRAY_CATEGORIES[category]) continue;

      var nodes = [];
      try { nodes = Array.from(document.querySelectorAll(selector)); } catch (e) { nodes = []; }
      if (!nodes.length) {
        localFailures.push({ fieldKey: fieldKey, label: selector, reason: "runtime_selector_not_found" });
        trace.push({ fieldKey: fieldKey, selector: selector, status: "skipped", reason: "runtime_selector_not_found" });
        continue;
      }
      var visibleNodes = nodes.filter(function (node) {
        return AF.DomUtils && typeof AF.DomUtils.isElementVisible === "function" ? AF.DomUtils.isElementVisible(node) : true;
      });
      // Build142: never fall back to a hidden DOM match. CNPC keeps inputs from
      // 示例资料 resume sections mounted; Build141 therefore counted hidden 示例资料Info
      // writes as success while the visible Family Members editor stayed empty.
      if (!visibleNodes.length) {
        trace.push({ fieldKey: fieldKey, selector: selector, status: "skipped", reason: "runtime_selector_not_visible" });
        continue;
      }
      var element = visibleNodes[0];
      if (!element) continue;

      var resolved = resolveVisibleValue(this.resumeData, category, fieldKey, null);
      if (!resolved.hasValue) {
        trace.push({ fieldKey: fieldKey, selector: selector, status: "skipped", reason: "profile_value_missing" });
        continue;
      }
      var value = normalizeLanguageScoreValue(category, fieldKey, resolved.value);
      var controlType = runtimeSelectorType(mapping.controlType, element, value);

      // Text/select inputs with a meaningful existing value are preserved. Radio
      // groups are deliberately re-applied because many sites ship a default option
      // that may disagree with the user's profile.
      if (!/^(radio|checkbox)$/i.test(controlType) && hasExistingValue(element)) {
        trace.push({ fieldKey: fieldKey, selector: selector, status: "skipped", reason: "existing_value_preserved" });
        continue;
      }

      var capabilityContext = this.formHandler.resolveCapabilityContext(
        category,
        fieldKey,
        selector,
        element,
        controlType
      );
      if (AF.FillTrace) AF.FillTrace.setFieldContext({
        category: category,
        label: selector,
        fieldKey: fieldKey,
        plannedValue: value,
        source: resolved.source && resolved.source !== "profile" ? "runtime_ai_value_candidate" : "runtime_ai_selector"
      });
      attempted++;
      var ok = await AF.FormHandler.fillFormElement(element, value, controlType, capabilityContext);
      if (ok) {
        committed++;
        this.formHandler.filledFieldsCount++;
        trace.push({ fieldKey: fieldKey, selector: selector, status: "committed", controlType: controlType });
      } else {
        var failure = { fieldKey: fieldKey, label: selector, reason: "runtime_selector_fill_failed" };
        localFailures.push(failure);
        this.formHandler.failedFields.push(failure);
        trace.push({ fieldKey: fieldKey, selector: selector, status: "failed", reason: failure.reason, controlType: controlType });
      }
      await AF.Utils.sleep(20);
    }

    return {
      success: committed > 0,
      attempted: attempted,
      committed: committed,
      failed: localFailures.length,
      failedFields: localFailures,
      trace: trace,
      totalFieldsFound: Math.max(Number(patch && patch.observedFieldCount || 0), attempted),
      message: committed > 0
        ? "[AI Selector Overlay] 已安全填写 " + committed + " 个当前分区字段"
        : "[AI Selector Overlay] 未找到可安全提交的当前分区字段"
    };
  };

  // ============ execute() — 模式分发 (源码行66275) ============
  FillEngine.prototype.execute = async function () {
    var originalScrollBehavior = document.documentElement.style.scrollBehavior;
    var startedAt = Date.now();
    this.isRunning = true;
    if (AF.FillTrace) {
      AF.FillTrace.start({
        hostname: location.hostname,
        url: location.href,
        configSource: this.elementMatcher.config && this.elementMatcher.config._source || "unknown",
      });
    }
    document.documentElement.style.scrollBehavior = "auto";

    var engine = this;
    this.formHandler.shouldStop = function () { return engine.isCancelled(); };
    if (this.formHandler.experienceHandler) {
      this.formHandler.experienceHandler.shouldStop = this.formHandler.shouldStop;
    }

    if (this.formHandler.onFieldProgress === undefined || this.onProgress) {
      var 示例资料 = this;
      this.formHandler.onFieldProgress = function (current, total) {
        if (示例资料.onProgress) 示例资料.onProgress(current, total);
      };
    }

    try {
      // Build136: one recovery session now spans FIELD / RECORD / SECTION / WORKFLOW.
      // The session is persisted only while a checkpoint is active; normal runs
      // always start clean and therefore cannot inherit stale completion tokens.
      await this.beginUniversalCheckpointRuntime();
      var runtimeSelectorResult = await this.executeRuntimeSelectorOverlayFill();
      var config = this.elementMatcher.config;
      var mode = (config && config.type) || "structured";
      var result;
      if (config && config.name === "xyz51job") {
        result = await this.executeXyz51JobFill();
      } else if (mode === "示例资料") {
        result = await this.executeSimpleFill();
      } else {
        result = await this.executeStructuredFill();
      }

      await this.maybePauseWorkflowCheckpoint(result, mode);

      if (runtimeSelectorResult && runtimeSelectorResult.committed > 0) {
        var normalMessage = String(result && result.message || "");
        var normalFailedAtEntry = !result || result.success === false || /未找到标题元素|未找到表单字段|未找到匹配的字段/.test(normalMessage);
        if (normalFailedAtEntry) {
          result = Object.assign({}, runtimeSelectorResult, {
            success: true,
            message: runtimeSelectorResult.message + (normalMessage ? "；通用 Core 后续入口：" + normalMessage : ""),
            totalFieldsFound: Math.max(
              Number(runtimeSelectorResult.totalFieldsFound || 0),
              Number(result && (result.totalFieldsFound || result.totalFields) || 0)
            )
          });
        } else {
          result = Object.assign({}, result || {}, {
            message: runtimeSelectorResult.message + (normalMessage ? "；" + normalMessage : ""),
            totalFieldsFound: Math.max(
              Number(runtimeSelectorResult.totalFieldsFound || 0),
              Number(result && (result.totalFieldsFound || result.totalFields) || 0)
            )
          });
        }
      }

      result = this.applyFormFieldCheckpointResult(result);
      result = this.applyFormRecordCheckpointResult(result);
      result = this.applyUniversalCheckpointResult(result);
      if (this.isCancelled()) {
        result = Object.assign({}, result || {}, { success: false, stopped: true, message: "已停止填充" });
      }
      result = result || { success: false, message: "未找到可填写字段", totalFieldsFound: 0 };
      result.duration = Date.now() - startedAt;
      result.filledCount = this.formHandler.filledFieldsCount || 0;
      result.failedFields = this.formHandler.failedFields || [];
      result.totalFields = result.totalFieldsFound || 0;
      if (runtimeSelectorResult) result.runtimeSelectorOverlay = runtimeSelectorResult;
      if (this.formHandler.lastExperienceResult) result.示例资料RecordExecution = this.formHandler.lastExperienceResult;
      if (this.universalCheckpointRuntime && typeof this.universalCheckpointRuntime.finalize === "function") {
        await this.universalCheckpointRuntime.finalize();
      }
      return result;
    } finally {
      if (AF.FillTrace) AF.FillTrace.finish();
      document.documentElement.style.scrollBehavior = originalScrollBehavior;
      this.isRunning = false;
    }
  };

  // ============ 当前可见表单补填 ============
  // 用户手动打开隐藏/弹窗/侧边栏表单后调用。只处理当前 DOM 中可见 label；
  // 不主动点新增/编辑/保存；已有值的控件直接跳过，避免重复覆盖。
  FillEngine.prototype.executeVisibleFormFill = async function (scopeRoot, options) {
    options = options || {};
    var startedAt = Date.now();
    this.isRunning = true;
    if (AF.FillTrace) {
      AF.FillTrace.start({
        hostname: location.hostname,
        url: location.href,
        configSource: this.elementMatcher.config && this.elementMatcher.config._source || "unknown",
        mode: "visible_form",
      });
    }

    try {
      var analyzer = AF.PrematchAnalyzer;

      var rawLabels = scopeRoot
        ? this.elementMatcher.findLabelsByCard(scopeRoot)
        : this.elementMatcher.findAllLabels();
      var labels = this.formHandler.filterValidLabels(rawLabels);
      labels = labels.filter(function (labelEl) {
        return !(labelEl.closest && labelEl.closest("#autofill-panel-root, #__af_report_buttons__, #__af_diagnostic_btn__, #autofill-mini-logo"));
      });

      var total = labels.length;
      var attempted = 0;
      var filledRowsByCategory = {};
      var forcedRecord = options.recordOverride && options.recordOverride.category && options.recordOverride.data
        ? options.recordOverride
        : null;
      for (var i = 0; i < labels.length; i++) {
        if (this.isCancelled()) break;
        var labelEl = labels[i];
        if (this.formHandler.onFieldProgress) this.formHandler.onFieldProgress(i + 1, total);

        var labelText = AF.LabelUtils.getLabelText(labelEl);
        if (!labelText) continue;

        var found = this.elementMatcher.findElementAndTypeByLabel(labelEl);
        var el = found && found.element;
        var elType = found && found.type;
        if (!el) {
          this.formHandler.failedFields.push({ fieldKey: "", label: labelText, reason: "element not found" });
          continue;
        }
        if (isManualOnlyField(labelText, el)) continue;
        if (!options.overwriteExisting && hasExistingValue(el)) continue;

        if (!forcedRecord && !/同意|授权|隐私|声明|真实性|背景调查|最终提交|立即投递|确认投递/.test(labelText)) {
          var customAnswer = resolveCustomQuestionAnswer(this.resumeData, labelText);
          if (customAnswer != null) {
            var customType = resolveFillType(el, elType, customAnswer);
            AF.FillTrace.setFieldContext({ category: "customAnswers", label: labelText, fieldKey: "customAnswer", plannedValue: customAnswer });
            var customOk = await AF.FormHandler.fillFormElement(el, customAnswer, customType, { source: "custom_question_bank" });
            attempted++;
            if (customOk) this.formHandler.filledFieldsCount++;
            else this.formHandler.failedFields.push({ fieldKey: "customAnswer", label: labelText, reason: "自定义问答填写失败" });
            await AF.Utils.sleep(20);
            continue;
          }
        }

        var categoryMatch = forcedRecord ? forcedRecord.category : (
          analyzer && typeof analyzer.inferCategoryFromContext === "function"
            ? analyzer.inferCategoryFromContext(labelEl, labelText, el, null)
            : null
        );
        var fieldMatch = null;
        if (forcedRecord) {
          var forcedField = this.dataMatcher.findFieldByCategory(forcedRecord.category, labelText);
          if (!forcedField && AF.AIConfigGenerator && typeof AF.AIConfigGenerator.resolveSemanticFieldMapping === "function") {
            forcedField = AF.AIConfigGenerator.resolveSemanticFieldMapping(
              this.elementMatcher && this.elementMatcher.config,
              forcedRecord.category,
              labelText
            );
          }
          if (forcedField) fieldMatch = { category: forcedRecord.category, field: forcedField };
        } else {
          fieldMatch = resolveRuntimeSemanticMapping(labelText, categoryMatch);
          if (!fieldMatch) {
            fieldMatch = analyzer && typeof analyzer.matchField === "function"
              ? analyzer.matchField(this.dataMatcher, labelText, categoryMatch)
              : inferCategoryFromVisibleContext(this.dataMatcher, labelEl, labelText);
          }
        }
        if (!fieldMatch || !fieldMatch.category || !fieldMatch.field) continue;

        var category = fieldMatch.category;
        var fieldKey = fieldMatch.field;
        var visibleFieldMeta = null;
        if (!forcedRecord && this.fieldCheckpointRuntime) {
          visibleFieldMeta = {
            category: category, fieldKey: fieldKey, label: labelText, occurrence: 0,
            sectionTitle: String(options.sectionTitle || "")
          };
          if (this.fieldCheckpointRuntime.shouldSkip && this.fieldCheckpointRuntime.shouldSkip(visibleFieldMeta)) {
            if (AF.FillTrace) AF.FillTrace.event("field_checkpoint_skip", labelText + "：恢复游标已跳过", "skipped");
            continue;
          }
        }
        var arrayIndex = ARRAY_CATEGORIES[category] ? getArrayCursor(category) : null;
        var resolved;
        if (forcedRecord) {
          var forcedValue = forcedRecord.data[fieldKey];
          if (forcedValue == null && fieldKey === "duration" && forcedRecord.data.startTime && forcedRecord.data.endTime) {
            forcedValue = { startTime: forcedRecord.data.startTime, endTime: forcedRecord.data.endTime };
          }
          resolved = { hasValue: forcedValue != null && forcedValue !== "", value: forcedValue, usedIndex: null };
        } else {
          resolved = resolveVisibleValue(this.resumeData, category, fieldKey, arrayIndex);
        }
        if (!resolved.hasValue) continue;

        var value = normalizeLanguageScoreValue(category, fieldKey, resolved.value);
        if (
          category === "示例资料" &&
          fieldKey === "city" &&
          /(就读院校|院校|学校|毕业院校)所在城市|院校城市/.test(labelText) &&
          el.closest && el.closest(".phoenix-select") &&
          AF.DomUtils && typeof AF.DomUtils.resolveEducationLocationPath === "function"
        ) {
          var visibleEducationLocationPath = AF.DomUtils.resolveEducationLocationPath(
            Array.isArray(this.resumeData[category]) ? this.resumeData[category][resolved.usedIndex] : null
          );
          if (visibleEducationLocationPath.length >= 2) value = visibleEducationLocationPath;
        }
        var resolvedType = resolveFillType(el, elType, value);
        var controlType = String(resolvedType || elType || "text");
        var capabilityContext = this.formHandler.resolveCapabilityContext(category, fieldKey, labelText, el, resolvedType);
        AF.FillTrace.setFieldContext({ category: category, label: labelText, fieldKey: fieldKey, plannedValue: value });
        var ok = await AF.FormHandler.fillFormElement(el, value, resolvedType, capabilityContext);
        attempted++;
        if (ok) {
          this.formHandler.filledFieldsCount++;
          if (visibleFieldMeta && this.fieldCheckpointRuntime && this.fieldCheckpointRuntime.markCompleted) {
            visibleFieldMeta.controlType = controlType;
            await this.fieldCheckpointRuntime.markCompleted(visibleFieldMeta);
          }
          if (!forcedRecord && ARRAY_CATEGORIES[category] && typeof resolved.usedIndex === "number") {
            filledRowsByCategory[category] = Math.max(filledRowsByCategory[category] || 0, resolved.usedIndex);
          }
        } else {
          this.formHandler.failedFields.push({ fieldKey: fieldKey, label: labelText, reason: "fill failed" });
          if (visibleFieldMeta && this.fieldCheckpointRuntime && this.fieldCheckpointRuntime.pause &&
              /^(?:text|input|textarea|longText|select|native-select|radio|checkbox|date|month)$/i.test(String(controlType || ""))) {
            visibleFieldMeta.controlType = controlType;
            await this.fieldCheckpointRuntime.pause(visibleFieldMeta, "普通字段填写失败", { forceRecoverable: true });
          }
        }
        await AF.Utils.sleep(20);
        if (this.fieldCheckpointRuntime && this.fieldCheckpointRuntime.paused) break;
      }

      if (!forcedRecord) {
        Object.keys(filledRowsByCategory).forEach(function (category) {
          advanceArrayCursor(category, filledRowsByCategory[category]);
        });
      }

      return {
        success: this.formHandler.filledFieldsCount > 0,
        message: "[当前可见表单] 补填完成，共填写 " + this.formHandler.filledFieldsCount + " 个字段",
        totalFieldsFound: attempted || total,
        duration: Date.now() - startedAt,
        filledCount: this.formHandler.filledFieldsCount || 0,
        failedFields: this.formHandler.failedFields || [],
        totalFields: attempted || total,
      };
    } finally {
      if (AF.FillTrace) AF.FillTrace.finish();
      this.isRunning = false;
    }
  };

  // ============ Simple 模式 (源码行66408) ============
  FillEngine.prototype.executeSimpleFill = async function () {
    if (this.isCancelled()) return { success: false, stopped: true, message: "已停止填充", totalFieldsFound: 0 };
    var labels = this.elementMatcher.findAllLabels();
    if (!labels || labels.length === 0) {
      return { success: false, message: "未找到表单字段", totalFieldsFound: 0 };
    }
    await this.formHandler.fillSimpleForm(labels);
    if (this.formHandler.filledFieldsCount === 0) {
      return { success: false, message: "未找到匹配的字段或填写失败", totalFieldsFound: labels.length };
    }
    return {
      success: true,
      message: "[Simple模式] 自动填写完成，共填写 " + this.formHandler.filledFieldsCount + " 个字段",
      totalFieldsFound: labels.length,
    };
  };

  // Build148: checkpoint cursor recovery must run before ordinary title/form
  // discovery. After the user manually saves a paused RepeatRecord there may be
  // no editor in the DOM at all; that is a valid post-save state, not a generic
  // "no form" failure. Preserve the completed record token and move the user to
  // the next explicit action without replaying the saved record.
  FillEngine.prototype.resumeRepeatCursorWithoutEditor = async function () {
    var previousRecord = this.recordCheckpointRuntime && this.recordCheckpointRuntime.previousCheckpoint;
    var previousField = this.fieldCheckpointRuntime && this.fieldCheckpointRuntime.previousCheckpoint;
    var checkpoint = null;
    var nextIndex = -1;
    var 示例资料Total = 0;
    var category = "";
    var sectionTitle = "";

    if (this.recordCheckpointRuntime && this.recordCheckpointRuntime.resumed && previousRecord &&
        String(previousRecord.reasonCode || "") === "manual_record_save_required") {
      checkpoint = previousRecord;
      示例资料Total = Number(previousRecord.示例资料Total || 0);
      nextIndex = Number(previousRecord.示例资料Index || 0) + 1;
      category = String(previousRecord.category || "");
      sectionTitle = String(previousRecord.sectionTitle || category || "重复经历");
      if (示例资料Total > 0 && nextIndex >= 示例资料Total) {
        this.formHandler.lastExperienceResult = {
          requestedRows: 示例资料Total,
          filledRows: 示例资料Total,
          filledIndexes: Array.from({ length: 示例资料Total }, function (_, index) { return index; }),
          mode: "graph_示例资料_record",
          ownerStatus: "all_profile_records_completed",
          resumedAfterManualSave: true,
          actionCursor: "SECTION_DONE",
          fieldReplaySuppressed: true
        };
        return {
          success: true,
          message: "[记录恢复] 上一条经历已按保存检查点确认完成；当前分区没有下一条待填写记录。",
          totalFieldsFound: 0
        };
      }
    } else if (this.fieldCheckpointRuntime && this.fieldCheckpointRuntime.resumed && previousField &&
               String(previousField.reasonCode || "") === "manual_示例资料_editor_open_required") {
      checkpoint = previousField;
      示例资料Total = Number(previousField.示例资料Total || 0);
      nextIndex = Number(previousField.示例资料Index);
      category = String(previousField.category || "");
      sectionTitle = String(previousField.sectionTitle || category || "重复经历");
    }

    if (!checkpoint || nextIndex < 0) return null;
    if (!this.fieldCheckpointRuntime || typeof this.fieldCheckpointRuntime.pause !== "function") return null;

    var meta = {
      category: category,
      sectionTitle: sectionTitle,
      fieldKey: "__open_示例资料_editor__",
      label: "打开下一条" + sectionTitle + "编辑器",
      occurrence: nextIndex,
      示例资料Index: nextIndex,
      示例资料Total: 示例资料Total
    };
    var context = {
      示例资料flowId: "autofill-core-formgraph-v1",
      stepIndex: -1,
      stepName: sectionTitle + " 第" + (nextIndex + 1) + "条",
      category: category,
      示例资料Index: nextIndex,
      示例资料Total: 示例资料Total,
      fieldKey: "__open_示例资料_editor__",
      fieldLabel: "添加/新增" + sectionTitle,
      phase: "open_editor",
      reasonCode: "manual_示例资料_editor_open_required",
      rawReason: "保存检查点之后没有打开下一条编辑器",
      humanSummary: "上一条已经保存；下一条需要你先打开编辑器",
      suggestedAction: "请打开下一条" + sectionTitle + "记录；编辑器出现后再次点击“一键填写”。",
      recoverability: "RECOVERABLE_MANUAL",
      granularity: "field"
    };
    await this.fieldCheckpointRuntime.pause(meta, context.rawReason, {
      forceRecoverable: true,
      reasonCode: context.reasonCode,
      failureContext: context,
      acknowledgeMode: "resume_at_action_cursor",
      nextAction: "FILL_NEXT_RECORD",
      freezeBeforeCursor: true
    });
    this.formHandler.lastExperienceResult = {
      requestedRows: 示例资料Total,
      filledRows: Math.max(0, nextIndex),
      filledIndexes: Array.from({ length: Math.max(0, nextIndex) }, function (_, index) { return index; }),
      mode: "graph_示例资料_record",
      ownerStatus: "saved_next_editor_not_open",
      nextRecordIndex: nextIndex,
      manualEditorOpenPending: true,
      resumedAfterManualSave: true,
      actionCursor: "OPEN_NEXT_RECORD",
      fieldReplaySuppressed: true
    };
    return { success: false, message: context.humanSummary, totalFieldsFound: 0 };
  };

  // ============ Structured 模式 (源码行66469-66797, 已去掉AI竞赛字段匹配分支) ============
  FillEngine.prototype.executeStructuredFill = async function () {
    var editButtons = this.elementMatcher.findButton && this.elementMatcher.findButton("edit");
    var isModuleDialogPage = this.isModuleDialogResumePage();
    // 首屏展示卡片、点击编辑/添加后才出现真实控件的页面，必须从一开始走
    // 交互式模块流程。若先跑普通 Structured，多经历会在弹窗尚未保存时尝试
    // 继续加卡，且只要示例资料先填到一个字段，后续模块兜底就会被短路。
    if (isModuleDialogPage) {
      var interactiveResult = await this.executeModuleDialogFallback([]);
      return interactiveResult || {
        success: false,
        message: "交互式表单已识别，但未找到可填写的模块",
        totalFieldsFound: 0,
      };
    }
    if (!isModuleDialogPage && editButtons && editButtons.length > 0) {
      for (var editIndex = 0; editIndex < editButtons.length; editIndex++) {
        await AF.DomUtils.safeClickElement(editButtons[editIndex]);
      }
      await AF.Utils.sleep(500);
    }

    var titleElements = this.elementMatcher.findTitle();
    if (!titleElements || titleElements.length === 0) {
      var checkpointCursorResult = await this.resumeRepeatCursorWithoutEditor();
      if (checkpointCursorResult) return checkpointCursorResult;
      if (isModuleDialogPage) {
        var noTitleModuleDialogResult = await this.executeModuleDialogFallback([]);
        if (noTitleModuleDialogResult && noTitleModuleDialogResult.success) {
          return noTitleModuleDialogResult;
        }
      }

      // Build162: a visible form does not need an explicit section title in order
      // to be fillable. Many enterprise resume pages render one large form surface
      // (labels + controls) and use navigation tabs instead of per-section headings.
      // Falling through to the existing visible-form scanner preserves local-first
      // semantics and avoids burning an AI request just because findTitle() is empty.
      var titlelessFallback = await this.executeVisibleFormFill(document, {
        overwriteExisting: false,
        sectionTitle: "",
        source: "titleless_visible_form_fallback"
      });
      if (titlelessFallback && titlelessFallback.success) {
        titlelessFallback.message = "[无标题表单兜底] " + String(titlelessFallback.message || "自动填写完成");
        titlelessFallback.titlelessVisibleFormFallback = true;
        return titlelessFallback;
      }
      return {
        success: false,
        message: "未找到标题元素",
        totalFieldsFound: Number(titlelessFallback && (titlelessFallback.totalFieldsFound || titlelessFallback.totalFields) || 0),
        titlelessVisibleFormFallback: true,
        titlelessVisibleFormResult: titlelessFallback || null
      };
    }

    // 第一轮扫描: 收集所有可见分区标题文字，用于判断页面整体有哪些板块
    var firstPassTitles = [];
    for (var i = 0; i < titleElements.length; i++) {
      var titleEl = titleElements[i];
      if (!AF.DomUtils.isElementVisible(titleEl)) continue;
      var titleText = this.formHandler.getTitleValue(titleEl);
      if (titleText) firstPassTitles.push(titleText);
    }

    var presentCategories = this.dataMatcher.analyzePageCategories(firstPassTitles);
    var hasIntern = presentCategories.has("示例资料Experience");
    var hasWork = presentCategories.has("示例资料Experience");
    var allowInternToWork = !hasIntern && hasWork; // 页面只有示例资料区，实习数据当工作填
    // 不把正式示例资料自动塞进明确的“示例资料”模块；合并入口（如“工作/示例资料”）
    // 仍由 returnMultiple 分支分别处理，避免 join.qq 这类页面分类错填。
    var allowWorkToIntern = false;
    var hasLanguage = presentCategories.has("示例资料Skills");
    var hasOtherLanguage = presentCategories.has("示例资料LanguageSkills");
    var disableOtherLanguage = hasOtherLanguage && hasLanguage;

    var processedTitles = [];
    var current = 0;
    var total = titleElements.length;

    // Build136 SECTION checkpoint: a Structured section is the recovery boundary
    // above FIELD/RECORD. Completed sections are kept only inside the active
    // recovery session and are skipped on the user's next run.
    var sectionRuntime = this.sectionCheckpointRuntime;
    var makeSectionMeta = function (title) {
      return { granularity: "section", sectionTitle: String(title || ""), category: "" };
    };
    var markSectionComplete = async function (title) {
      if (sectionRuntime && typeof sectionRuntime.markCompleted === "function") {
        await sectionRuntime.markCompleted(makeSectionMeta(title));
      }
    };
    var maybePauseSection = async function (title, failures) {
      if (!sectionRuntime || !failures || !failures.length || typeof sectionRuntime.pause !== "function") return false;
      var raw = failures.map(function (item) {
        return [item && item.label, item && item.reason].filter(Boolean).join("：");
      }).filter(Boolean).join("；");
      if (!raw) return false;
      var checkpoint = await sectionRuntime.pause(makeSectionMeta(title), raw, {
        result: { failedFields: failures },
        phase: "fill"
      });
      return !!checkpoint;
    };

    var unsafeRepeatFailure = null;
    var registerRepeatOutcome = function (title, category, ok) {
      if (ok !== false) return null;
      var last = this.formHandler && this.formHandler.lastExperienceResult || null;
      if (!last || last.manualSavePending || last.manualEditorOpenPending || last.manualReviewPending) return null;
      var requested = Number(last.requestedRows || 0);
      var filled = Number(last.filledRows || 0);
      var reason = String(last.error || (requested > filled ? "示例资料_record_not_committed" : "示例资料_record_execution_failed"));
      var failure = { fieldKey: "示例资料Record", label: String(title || category || "重复经历"), reason: reason };
      var failures = this.formHandler.failedFields || (this.formHandler.failedFields = []);
      if (!failures.some(function (item) { return item && item.fieldKey === failure.fieldKey && item.label === failure.label && item.reason === failure.reason; })) {
        failures.push(failure);
      }
      if (/ownership|record_save_state_unknown|示例资料_record_(?:not_committed|index_unresolved|no_fields_committed|identity_not_committed|action_cursor_target_missing)|示例资料_section_scope_not_resolved|selector_ownership_ambiguous/.test(reason)) {
        unsafeRepeatFailure = {
          stepName: String(title || category || "重复经历"),
          category: String(category || ""),
          fieldKey: "示例资料Record",
          fieldLabel: String(title || category || "重复经历"),
          phase: "fill",
          reasonCode: "unsafe_execution_state",
          rawReason: reason,
          humanSummary: String(title || category || "重复经历") + "的记录归属或保存状态无法安全确认",
          suggestedAction: "为避免把资料写入错误记录，程序已停止；请先确认当前打开的是哪一条记录以及是否需要保存。",
          recoverability: "UNSAFE_STOP",
          granularity: "record"
        };
      }
      return failure;
    }.bind(this);

    for (var w = 0; w < titleElements.length; w++) {
      if (this.isCancelled()) break;
      var sectionTitleEl = titleElements[w];
      current++;
      if (this.formHandler.onFieldProgress) this.formHandler.onFieldProgress(current, total);
      if (!AF.DomUtils.isElementVisible(sectionTitleEl)) continue;
      var sectionNavId = sectionTitleEl.closest && sectionTitleEl.closest("[data-nav-id]");
      if (/\.mokahr\.com$/i.test(String(location.hostname || "")) && sectionNavId && /^block-(?:applyInfo|uploadInfo|32470)$/i.test(String(sectionNavId.getAttribute("data-nav-id") || ""))) continue;

      var titleValue = this.formHandler.getTitleValue(sectionTitleEl);
      if (!titleValue) continue;
      var sectionMeta = makeSectionMeta(titleValue);
      if (sectionRuntime && sectionRuntime.enabled && typeof sectionRuntime.shouldSkip === "function" && sectionRuntime.shouldSkip(sectionMeta)) {
        if (AF.FillTrace) AF.FillTrace.event("section_checkpoint_skip", titleValue + "：恢复游标已跳过", "skipped");
        continue;
      }
      var sectionFailureStart = this.formHandler.failedFields ? this.formHandler.failedFields.length : 0;
      if (/^applyjob\.chinahr\.com$/i.test(String(location.hostname || "")) &&
          /全职示例资料|正式示例资料/.test(String(titleValue)) &&
          !/实习/.test(String(titleValue))) {
        if (AF.FillTrace) AF.FillTrace.event("module_skipped", titleValue + "（中国银行固定跳过）", "skipped");
        continue;
      }
      if (/^applyjob\.chinahr\.com$/i.test(String(location.hostname || "")) &&
          /本科双学位|辅修情况/.test(String(titleValue))) {
        if (AF.FillTrace) AF.FillTrace.event("module_skipped", titleValue + "（中国银行默认不填）", "skipped");
        continue;
      }
      processedTitles.push(titleValue);
      if (AF.FillTrace) AF.FillTrace.setModule(titleValue);

      var matchOptions = {
        allowInternToWork: allowInternToWork,
        allowWorkToIntern: allowWorkToIntern,
        disableOtherLanguage: disableOtherLanguage,
      };

      if (titleValue === "实习/项目经历") {
        if (/^campus-talent\.alibaba\.com$/i.test(location.hostname || "")) {
          var preferredCategory = "";
          if (Array.isArray(this.resumeData.示例资料Experience) && this.resumeData.示例资料Experience.length) preferredCategory = "示例资料Experience";
          else if (Array.isArray(this.resumeData.示例资料Experience) && this.resumeData.示例资料Experience.length) preferredCategory = "示例资料Experience";
          else if (Array.isArray(this.resumeData.示例资料Experience) && this.resumeData.示例资料Experience.length) preferredCategory = "示例资料Experience";
          if (preferredCategory) {
            var aliExperienceOk = await this.formHandler.fillExperience(
              sectionTitleEl,
              titleValue,
              Object.assign({}, matchOptions, { specificCategory: preferredCategory })
            );
            registerRepeatOutcome(titleValue, preferredCategory, aliExperienceOk);
          }
          if ((this.formHandler.fieldCheckpointRuntime && this.formHandler.fieldCheckpointRuntime.paused) ||
              (this.formHandler.recordCheckpointRuntime && this.formHandler.recordCheckpointRuntime.paused) ||
              (sectionRuntime && sectionRuntime.paused)) break;
          var aliSectionFailures = (this.formHandler.failedFields || []).slice(sectionFailureStart);
          if (await maybePauseSection(titleValue, aliSectionFailures)) break;
          if (unsafeRepeatFailure) break;
          await markSectionComplete(titleValue);
          continue;
        }
        var multi = this.dataMatcher.getCategoryByTitle(
          titleValue,
          Object.assign({}, matchOptions, { returnMultiple: true })
        );
        if (Array.isArray(multi) && multi.length > 0) {
          for (var m = 0; m < multi.length; m++) {
            var entry = multi[m];
            if (entry.type === "array") {
              var multiExperienceOk = await this.formHandler.fillExperience(
                sectionTitleEl,
                titleValue,
                Object.assign({}, matchOptions, { specificCategory: entry.category })
              );
              registerRepeatOutcome(titleValue, entry.category, multiExperienceOk);
              if (unsafeRepeatFailure) break;
            } else {
              await this.formHandler.fillBasicInfo(
                sectionTitleEl,
                titleValue,
                Object.assign({}, matchOptions, { specificCategory: entry.category })
              );
            }
            if ((this.formHandler.fieldCheckpointRuntime && this.formHandler.fieldCheckpointRuntime.paused) ||
                (this.formHandler.recordCheckpointRuntime && this.formHandler.recordCheckpointRuntime.paused) ||
              (sectionRuntime && sectionRuntime.paused)) break;
            await AF.Utils.sleep(20);
          }
          if ((this.formHandler.fieldCheckpointRuntime && this.formHandler.fieldCheckpointRuntime.paused) ||
              (this.formHandler.recordCheckpointRuntime && this.formHandler.recordCheckpointRuntime.paused) ||
              (sectionRuntime && sectionRuntime.paused)) break;
          var multiSectionFailures = (this.formHandler.failedFields || []).slice(sectionFailureStart);
          if (await maybePauseSection(titleValue, multiSectionFailures)) break;
          if (unsafeRepeatFailure) break;
          await markSectionComplete(titleValue);
          continue;
        }
      }

      var categoryInfo = this.dataMatcher.getCategoryByTitle(titleValue, matchOptions);
      if (!categoryInfo) continue;
      // 站点补丁可将职位入口前的说明、渠道、上传等模块标记为
      // mokahrSkip*；这些模块不属于简历数据，直接跳过，避免误填或触发上传。
      if (/^mokahrSkip/i.test(String(categoryInfo.category || ""))) continue;
      if (categoryInfo.type === "array") {
        var experienceOk = await this.formHandler.fillExperience(sectionTitleEl, titleValue, matchOptions);
        registerRepeatOutcome(titleValue, categoryInfo.category, experienceOk);
      } else {
        await this.formHandler.fillBasicInfo(sectionTitleEl, titleValue, matchOptions);
      }
      if ((this.formHandler.fieldCheckpointRuntime && this.formHandler.fieldCheckpointRuntime.paused) ||
          (this.formHandler.recordCheckpointRuntime && this.formHandler.recordCheckpointRuntime.paused) ||
              (sectionRuntime && sectionRuntime.paused)) break;
      var sectionFailures = (this.formHandler.failedFields || []).slice(sectionFailureStart);
      if (await maybePauseSection(titleValue, sectionFailures)) break;
      if (unsafeRepeatFailure) break;
      await markSectionComplete(titleValue);
      await AF.Utils.sleep(20);
    }

    if (unsafeRepeatFailure) {
      return {
        success: false,
        message: unsafeRepeatFailure.humanSummary,
        totalFieldsFound: processedTitles.length,
        failedFields: this.formHandler.failedFields || [],
        failureContext: unsafeRepeatFailure
      };
    }

    if (this.isCancelled()) {
      return { success: false, stopped: true, message: "已停止填充", totalFieldsFound: processedTitles.length };
    }
    if ((this.formHandler.fieldCheckpointRuntime && this.formHandler.fieldCheckpointRuntime.paused) ||
        (this.formHandler.recordCheckpointRuntime && this.formHandler.recordCheckpointRuntime.paused) ||
        (sectionRuntime && sectionRuntime.paused)) {
      return { success: false, message: "当前内容需要人工处理", totalFieldsFound: processedTitles.length };
    }
    await this.fillPddSelfAssessmentFallback();

    // 交互式卡片页面即使当前恰好已有一个编辑表单展开、前半段已经填到字段，
    // 仍必须继续逐模块处理。旧逻辑仅在 filledFieldsCount === 0 时运行兜底，
    // 会造成“示例资料填了一部分后直接结束”，后面的教育/实习/项目全部跳过。
    if (isModuleDialogPage) {
      var moduleDialogResult = await this.executeModuleDialogFallback(processedTitles);
      if (moduleDialogResult && moduleDialogResult.success) return moduleDialogResult;
    }
    if (this.formHandler.filledFieldsCount === 0) {
      return { success: false, message: "未找到匹配的字段或填写失败", totalFieldsFound: processedTitles.length };
    }
    return {
      success: true,
      message: "[Structured模式] 自动填写完成，共填写 " + this.formHandler.filledFieldsCount + " 个字段",
      totalFieldsFound: processedTitles.length,
    };
  };

  // ============ 展示卡片 + 编辑/添加弹窗页兜底 ============
  // 这类页面首屏只有简历展示卡片，真实输入框藏在各模块的编辑/添加弹窗里。
  // 只在普通 Structured 模式 0 填写时触发，且强依赖页面结构特征，避免影响已有表单页。
  FillEngine.prototype.isModuleDialogResumePage = function () {
    // 智联校园中国联通页面一次只渲染一个 .apply-module，通用交互评分会因
    // 单模块而漏判；这里仅按精确域名/路径启用普通模块流程兜底。
    if (/^xiaoyuan\.zhaopin\.com$/i.test(String(location.hostname || "")) &&
        /^\/scrd\/resume2$/i.test(String(location.pathname || "")) &&
        document.querySelector(".resume .apply-module")) return true;
    if (AF.InteractiveFormRuntime && typeof AF.InteractiveFormRuntime.detectPage === "function") {
      try {
        var interactionOptions = this.elementMatcher && this.elementMatcher.config && this.elementMatcher.config.interaction || {};
        return Boolean(AF.InteractiveFormRuntime.detectPage(interactionOptions).matched);
      } catch (e) {}
    }
    var root = document.querySelector(".resume");
    if (!root) return false;
    var modules = Array.from(root.querySelectorAll(".resume-module"));
    if (modules.length < 2) return false;
    var hasAction = modules.some(function (module) { return !!findModuleActionButton(module); });
    if (!hasAction) return false;
    var visibleRootControls = Array.from(root.querySelectorAll(
      "input:not([type='hidden']):not([type='file']), textarea, select, [contenteditable='true']"
    )).filter(isVisibleNode);
    return visibleRootControls.length <= 3;
  };

  FillEngine.prototype.closeModuleDialog = async function (dialog, shouldSave) {
    if (!dialog) return false;
    var btn = shouldSave ? findDialogSaveButton(dialog) : findDialogCancelButton(dialog);
    if (!btn && !shouldSave) {
      btn = dialog.querySelector(".el-dialog__headerbtn, .ant-modal-close, [aria-label='Close'], [aria-label='关闭']");
    }
    if (!btn || !isVisibleNode(btn)) return false;
    btn.click();
    await AF.Utils.sleep(500);
    return true;
  };

  FillEngine.prototype.executeModuleDialogFallback = async function (processedTitles) {
    if (!this.isModuleDialogResumePage()) return null;

    var interactiveDetection = null;
    var moduleRecords = [];
    var interactionOptions = this.elementMatcher && this.elementMatcher.config && this.elementMatcher.config.interaction || {};
    if (AF.InteractiveFormRuntime && typeof AF.InteractiveFormRuntime.detectPage === "function") {
      try {
        interactiveDetection = AF.InteractiveFormRuntime.detectPage(interactionOptions);
        moduleRecords = interactiveDetection && interactiveDetection._records || [];
      } catch (e) {}
    }
    var skippedTitlePattern = /申请信息|招聘信息渠道|意向志愿|志愿|投递|附件|上传|照片|头像/;
    var isSkippedModule = function (module, record) {
      var navId = String(module && module.getAttribute && module.getAttribute("data-nav-id") || "");
      var title = normalizeButtonText(record && record.title || getModuleTitle(module));
      return (/\.mokahr\.com$/i.test(String(location.hostname || "")) && /^block-(?:applyInfo|uploadInfo|32470)$/i.test(navId)) || (title && skippedTitlePattern.test(title));
    };
    var modules = moduleRecords.length
      ? moduleRecords.filter(function (record) { return record && record.element && isVisibleNode(record.element) && !isSkippedModule(record.element, record); })
          .map(function (record) { return record.element; })
      : Array.from(document.querySelectorAll(".resume .resume-module")).filter(function (module) { return isVisibleNode(module) && !isSkippedModule(module, null); });
    if (!modules.length && /^xiaoyuan\.zhaopin\.com$/i.test(String(location.hostname || "")) &&
        /^\/scrd\/resume2$/i.test(String(location.pathname || ""))) {
      modules = Array.from(document.querySelectorAll(".resume .apply-module")).filter(function (module) {
        return isVisibleNode(module) && !isSkippedModule(module, null);
      });
    }
    var openedModules = 0;
    var filledModules = 0;
    var beforeTotal = this.formHandler.filledFieldsCount || 0;

    for (var i = 0; i < modules.length; i++) {
      if (this.isCancelled()) break;
      var module = modules[i];
      var moduleRecord = moduleRecords.find(function (record) { return record && record.element === module; }) || null;
      var title = normalizeButtonText(moduleRecord && moduleRecord.title || getModuleTitle(module));
      if (title && skippedTitlePattern.test(title)) continue;

      if (AF.FillTrace) AF.FillTrace.setModule(title || "弹窗模块");
      var rowPlan = buildInteractiveModuleRowPlan(title, this.resumeData);
      var iterations = rowPlan.length || 1;

      for (var rowIndex = 0; rowIndex < iterations; rowIndex++) {
        if (this.isCancelled()) break;
        var rowRecordMeta = null;
        if (rowPlan.length && rowPlan[rowIndex] && rowPlan[rowIndex].category && rowPlan[rowIndex].data) {
          rowRecordMeta = {
            granularity: "record",
            sectionTitle: title,
            category: rowPlan[rowIndex].category,
            示例资料Index: rowIndex,
            示例资料Total: iterations,
            row: rowPlan[rowIndex].data,
            recordFingerprint: AF.CheckpointCore && AF.CheckpointCore.recordFingerprint
              ? AF.CheckpointCore.recordFingerprint(rowPlan[rowIndex].data) : ""
          };
          if (this.recordCheckpointRuntime && this.recordCheckpointRuntime.shouldSkip && this.recordCheckpointRuntime.shouldSkip(rowRecordMeta)) {
            if (AF.FillTrace) AF.FillTrace.event("record_checkpoint_skip", title + " 第" + (rowIndex + 1) + "条：恢复游标已跳过", "skipped");
            continue;
          }
        }
        module = findModuleByTitle(title) || module;
        var editSurface = null;

        // 分析结束后可能留下一个已经展开的内联表单。先处理当前表单，不能因
        // 标题栏“编辑”按钮暂时隐藏就把整个模块跳过。
        if (rowIndex === 0) {
          var currentInline = findModuleEditSurface(module);
          if (currentInline) editSurface = { surface: currentInline, kind: "inline" };
        }

        var action = null;
        if (!editSurface) {
          var existingCards = getSubstantiveModuleCards(module);
          action = rowPlan.length && rowIndex < existingCards.length
            ? findCardEditButton(existingCards[rowIndex])
            : (moduleRecord && moduleRecord.action && moduleRecord.action.element && moduleRecord.action.element.isConnected
              ? moduleRecord.action.element
              : findModuleActionButton(module));
          if (!action && /^xiaoyuan\.zhaopin\.com$/i.test(String(location.hostname || ""))) {
            action = module.querySelector(".apply-form .icon-box, .form-content--title-box .icon-box");
          }
          if (!action) break;

          var beforeDialogs = new Set(getVisibleDialogs());
          if (
            moduleRecord && moduleRecord.action && action === moduleRecord.action.element &&
            AF.InteractiveFormRuntime && typeof AF.InteractiveFormRuntime.openForLiveFill === "function"
          ) {
            var liveFillOptions = Object.assign({}, interactionOptions, {
              allowAddProbe: moduleRecord.action.type !== "add" || isRepeatableExperienceModuleTitle(title),
              maxWaitMs: 10000,
            });
            var opened = await AF.InteractiveFormRuntime.openForLiveFill(moduleRecord, liveFillOptions);
            if (opened && opened.success && opened.surface) {
              editSurface = { surface: opened.surface.element, kind: opened.surface.type };
            }
          } else {
            await AF.DomUtils.safeClickElement(action);
            await AF.Utils.sleep(180);
            editSurface = await waitForModuleEditSurface(module, beforeDialogs, 3200);
          }
        }

        openedModules++;
        if (!editSurface || !editSurface.surface || !hasEditableControl(editSurface.surface)) break;

        var beforeFill = this.formHandler.filledFieldsCount || 0;
        await this.executeVisibleFormFill(editSurface.surface, {
          overwriteExisting: true,
          recordOverride: rowPlan[rowIndex] || null,
          sectionTitle: title,
        });
        var afterFill = this.formHandler.filledFieldsCount || 0;
        var didFill = afterFill > beforeFill;
        if (didFill) filledModules++;
        if (AF.InteractiveFormRuntime && typeof AF.InteractiveFormRuntime.updateStatus === "function") {
          AF.InteractiveFormRuntime.updateStatus({
            flowType: "interactive_live_fill",
            stage: "module_filled",
            currentModule: title,
            message: didFill
              ? "已填写：" + title + (rowPlan.length ? " 第" + (rowIndex + 1) + "/" + rowPlan.length + "条" : "")
              : "未匹配到可填写字段：" + title,
          });
        }

        var closed = true;
        if (editSurface.kind === "dialog") {
          closed = await this.closeModuleDialog(editSurface.surface, didFill);
        } else if (didFill) {
          closed = await this.closeModuleDialog(editSurface.surface, true);
        }
        await AF.Utils.sleep(350);
        var stillOpen = !closed || (editSurface.kind === "dialog" && isVisibleNode(editSurface.surface));
        // Generic RECORD/SECTION recovery for interactive card pages. A known
        // 示例资料ed record that cannot be closed/saved is recoverable by the user;
        // an object section uses SECTION granularity instead.
        if (stillOpen) {
          if (rowRecordMeta && this.recordCheckpointRuntime && this.recordCheckpointRuntime.pause) {
            await this.recordCheckpointRuntime.pause(rowRecordMeta, "当前经历需要人工确认或保存", { forceRecoverable: true });
          } else if (this.sectionCheckpointRuntime && this.sectionCheckpointRuntime.pause) {
            await this.sectionCheckpointRuntime.pause({ granularity: "section", sectionTitle: title, category: "" }, "当前分区需要人工确认或保存", { forceRecoverable: true, phase: "save" });
          }
          break;
        }
        if (didFill && rowRecordMeta && this.recordCheckpointRuntime && this.recordCheckpointRuntime.markCompleted) {
          await this.recordCheckpointRuntime.markCompleted(rowRecordMeta);
        }
      }
      if ((this.fieldCheckpointRuntime && this.fieldCheckpointRuntime.paused) ||
          (this.recordCheckpointRuntime && this.recordCheckpointRuntime.paused) ||
          (this.sectionCheckpointRuntime && this.sectionCheckpointRuntime.paused)) break;
      if (this.sectionCheckpointRuntime && this.sectionCheckpointRuntime.markCompleted) {
        await this.sectionCheckpointRuntime.markCompleted({ granularity: "section", sectionTitle: title, category: "" });
      }
    }

    var filledDelta = (this.formHandler.filledFieldsCount || 0) - beforeTotal;
    if (filledDelta <= 0) return null;
    return {
      success: true,
      message: "[模块弹窗兜底] 已打开 " + openedModules + " 个模块，填写 " + filledDelta + " 个字段",
      totalFieldsFound: (processedTitles && processedTitles.length) || modules.length,
      filledCount: this.formHandler.filledFieldsCount || 0,
      failedFields: this.formHandler.failedFields || [],
    };
  };

  // ============ 51job 模式 (简化重建, 详见文件头注释) ============
  FillEngine.prototype.executeXyz51JobFill = async function () {
    var config = this.elementMatcher.config;
    var selectors = (config && config.selectors) || {};
    var rowSelector = selectors.row || 'dl[dlcolname]';
    var sectionSelector = selectors.section;
    var root = sectionSelector ? document.querySelector(sectionSelector) || document : document;
    var rows = Array.from(root.querySelectorAll(rowSelector));

    if (rows.length === 0) {
      return { success: false, message: "未找到 51job 字段行", totalFieldsFound: 0 };
    }

    var total = rows.length;
    for (var i = 0; i < rows.length; i++) {
      if (this.isCancelled()) break;
      var row = rows[i];
      if (this.formHandler.onFieldProgress) this.formHandler.onFieldProgress(i + 1, total);
      if (!AF.DomUtils.isElementVisible(row)) continue;

      // 51job 企业模板的 dlcolname 有两种形态：旧页面可能直接写中文，
      // 新页面则常写 Cname / IDCard / Email / MobilePhone 这类内部代码。
      // 必须优先使用用户可见中文标签，内部代码只能在中文匹配失败时兜底。
      // 只读取 dt 标签。不能把整个 dl 交给 getLabelText：手机、邮箱等 dd 内含
      // “不能为空”和填写说明，整行文本会污染标签并导致字段映射失败。
      var visibleLabelNode = row.querySelector("dt") || row;
      var labelText = AF.LabelUtils.getLabelText(visibleLabelNode);
      var dlColName = row.getAttribute("dlcolname");
      if (!labelText) continue;

      var fieldKey = this.dataMatcher.findFieldByCategory("示例资料Info", labelText) || this.dataMatcher.findFieldByCategory("jobIntention", labelText);
      if (!fieldKey && dlColName) {
        var internalLabel = AF.LabelUtils.getLabelText({ textContent: dlColName });
        fieldKey = this.dataMatcher.findFieldByCategory("示例资料Info", internalLabel) || this.dataMatcher.findFieldByCategory("jobIntention", internalLabel);
      }
      if (!fieldKey) continue;

      var value = (this.resumeData.示例资料Info && this.resumeData.示例资料Info[fieldKey]) ?? (this.resumeData.jobIntention && this.resumeData.jobIntention[fieldKey]);
      if (value === undefined || value === null || value === "") continue;

      var job51TextCodes = {
        name: "Cname",
        idNumber: "IDCard",
        email: "Email",
        phone: "MobilePhone",
      };
      var exactInputCode = job51TextCodes[fieldKey];
      var exactTextInput = exactInputCode
        ? row.querySelector('input[inputcolname="' + exactInputCode + '"]:not([type="hidden"])')
        : null;
      var typeInfo = exactTextInput
        ? { type: "text", element: exactTextInput }
        : this.elementMatcher.findElementByType(row, {
            preferSelectors: selectors,
            labelText: labelText,
            fieldKey: fieldKey,
            isDateRelated: AF.LabelUtils.isDateRelatedLabel(labelText),
            // 身份证和手机号的第一项是证件类型/区号 select，真正的数据输入框在
            // 同一行最后。该提示同时作为旧版无 inputcolname 页面上的兼容兜底。
            isPhoneOrIdCard: /(身份证|证件号|手机|电话|联系方式)/.test(labelText),
            fieldIntent: /(姓名|身份证|证件号|手机|电话|电子邮件|电子邮箱|邮箱)/.test(labelText) ? "text" : undefined,
          });
      if (!typeInfo || !typeInfo.element) {
        this.formHandler.failedFields.push({ fieldKey: fieldKey, label: labelText, reason: "element not found" });
        continue;
      }
      var category = this.resumeData.示例资料Info && this.resumeData.示例资料Info[fieldKey] !== undefined ? "示例资料Info" : "jobIntention";
      var fieldMeta51 = { category: category, fieldKey: fieldKey, label: labelText, occurrence: 0, sectionTitle: "51job" };
      if (this.fieldCheckpointRuntime && this.fieldCheckpointRuntime.shouldSkip && this.fieldCheckpointRuntime.shouldSkip(fieldMeta51)) {
        if (AF.FillTrace) AF.FillTrace.event("field_checkpoint_skip", labelText + "：恢复游标已跳过", "skipped");
        continue;
      }
      var capabilityContext = this.formHandler.resolveCapabilityContext(category, fieldKey, labelText, typeInfo.element, typeInfo.type);
      var ok = await AF.FormHandler.fillFormElement(typeInfo.element, value, typeInfo.type, capabilityContext);
      if (ok) {
        this.formHandler.filledFieldsCount++;
        if (this.fieldCheckpointRuntime && this.fieldCheckpointRuntime.markCompleted) {
          fieldMeta51.controlType = typeInfo.type;
          await this.fieldCheckpointRuntime.markCompleted(fieldMeta51);
        }
      } else {
        this.formHandler.failedFields.push({ fieldKey: fieldKey, label: labelText, reason: "fill failed" });
        if (this.fieldCheckpointRuntime && this.fieldCheckpointRuntime.pause &&
            /^(?:text|input|textarea|select|native-select|radio|checkbox|date|month)$/i.test(String(typeInfo.type || ""))) {
          fieldMeta51.controlType = typeInfo.type;
          await this.fieldCheckpointRuntime.pause(fieldMeta51, "普通字段填写失败", { forceRecoverable: true });
        }
      }
      await AF.Utils.sleep(20);
      if (this.fieldCheckpointRuntime && this.fieldCheckpointRuntime.paused) break;
    }

    // 这类 51job 企业表单是分步页面。照片由用户手动上传，但自动填写完成后仍要
    // 尝试进入下一步；若照片或其他必填项缺失，页面自身校验会阻止跳转并显示提示。
    var nextSelector = selectors.nextButton;
    var nextButton = config && config.autoNextAfterFill && nextSelector
      ? document.querySelector(nextSelector)
      : null;
    if (!this.isCancelled() && this.formHandler.filledFieldsCount > 0 && nextButton && AF.DomUtils.isElementVisible(nextButton)) {
      setTimeout(function () {
        AF.DomUtils.safeClickElement(nextButton).catch(function () {});
      }, 150);
    }

    if (this.formHandler.filledFieldsCount === 0) {
      return { success: false, message: "未找到可填充的 51job 字段", totalFieldsFound: rows.length };
    }
    return {
      success: true,
      message: "[51job模式] 自动填写完成，共填写 " + this.formHandler.filledFieldsCount + " 个字段",
      totalFieldsFound: rows.length,
    };
  };

  AF.FillEngine = FillEngine;
})();
