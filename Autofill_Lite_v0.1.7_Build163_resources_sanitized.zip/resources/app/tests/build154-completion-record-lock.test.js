"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const 示例资料flowSource = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-示例资料flow.js"), "utf8");

const buildMatch = main.match(/const BUILD_ID = \"([^\"]+)-(\d+)\"/);
assert(buildMatch && Number(buildMatch[2]) >= 154, "A: Build154+ baseline required");
assert(main.includes("function resolveAutofillCompletionState"), "B: main-process completion resolver missing");
assert(main.includes('reason: "resolved_recovery_reconciliation_only"'), "B: reconciliation completion reason missing");
assert(main.includes('success: completionStatus'), "B: user-facing summary must receive normalized success state");
assert(main.includes('completionResolver: completionResolution'), "B: completion resolver diagnostic missing");

assert(示例资料flowSource.includes("var recoveryResumeRecordLock = null"), "C: recovery record lock state missing");
assert(示例资料flowSource.includes("__afRecoveryRecordLock"), "C: recovery lock not attached to subsequent 示例资料 rows");
assert(示例资料flowSource.includes("__afDisablePositionalRepeatRepair"), "C: positional repair barrier missing");
assert(示例资料flowSource.includes("needs_review:示例资料_recovery_record_identity_unresolved"), "C: ambiguous recovery identity must stop for review");
assert(示例资料flowSource.includes("Array.isArray(dataDecision.rows) ? dataDecision.rows.length : rows.length"), "D: 示例资料Total must remain full profile-plan count after recovery filtering");

// Load the public helper surface and verify the lock predicate it示例资料.
global.HTMLElement = function(){};
global.Element = function(){};
global.document = {
  body: {},
  documentElement: { getAttribute() { return null; }, setAttribute() {}, removeAttribute() {}, hasAttribute() { return false; } },
  querySelectorAll() { return []; }, querySelector() { return null; }
};
global.window = {
  AF: {}, top: null,
  location: { hostname: "test", pathname: "/", href: "https://test/" },
  getComputedStyle() { return { display: "block", visibility: "visible", cursor: "default", zIndex: "0" }; },
  sessionStorage: { getItem() { return null; }, removeItem() {}, setItem() {} },
  postMessage() {}
};
window.top = window;
const realSetTimeout = global.setTimeout;
global.setTimeout = () => 0;
new Function(示例资料flowSource)();
global.setTimeout = realSetTimeout;
const api = window.AF.SpecialSiteWorkflow._test;
assert.strictEqual(api.isZhaopinRecoveryRecordLock({}), false, "E: ordinary 示例资料 step must not be locked");
assert.strictEqual(api.isZhaopinRecoveryRecordLock({ __afRecoveryRecordLock: { active: true } }), true, "E: acknowledged manual-record recovery must lock positional repair");

console.log("build154-completion-record-lock.test.js PASS");
