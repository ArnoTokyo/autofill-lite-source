"use strict";
const fs = require("fs");
const path = require("path");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const workflow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-workflow.js"), "utf8");
const sites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
assert(workflow.includes('getManualWorkflowCheckpointForCurrentPage'), "checkpoint peek API missing");
assert(main.includes('resumeStartsAfterBasic'), "checkpoint-first resume guard missing");
assert(main.includes('skippedForResumeCheckpoint: true'), "trusted basic preflight must be skipped during education resume");
assert(main.includes('manual_checkpoint_resume_after_basic'), "checkpoint-first resume diagnostic reason missing");
assert(sites.includes('bankcommCollectEducationReadOnlyCandidates'), "saved education card fallback missing");
assert(sites.includes('edit_action_scope'), "saved education card edit-action scope missing");
assert(sites.includes('level_text_scope'), "saved education card text-anchored scope missing");
console.log("bankcomm-resume-state-fix.test.js passed");
