"use strict";
const fs = require("fs");
const path = require("path");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const 示例资料flow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-示例资料flow.js"), "utf8");

const start = 示例资料flow.indexOf("async function fillBankcommResearchCustomValue");
const end = 示例资料flow.indexOf("\n  // 兴业银行学校名称", start);
assert(start !== -1 && end > start, "A: custom research filler missing");
const fn = 示例资料flow.slice(start, end);

// A. The legacy search box must never be treated as the custom-input row.
assert(fn.includes('inputNode.id === "researchSearch"'), "A: legacy research search id guard missing");
assert(fn.includes('/搜索研究方向|试试搜索/'), "A: legacy research search placeholder guard missing");

// B. The true custom input is resolved only after checking the fallback box, from the row
// that also owns the blue Submit action.
const checkboxIndex = fn.indexOf('checkboxInput');
const submitTextIndex = fn.indexOf('fallbackSubmitButtonText');
const customRowIndex = fn.indexOf('var customRow = await waitUntil');
assert(checkboxIndex !== -1 && customRowIndex > checkboxIndex, "B: custom row must be resolved after checkbox activation");
assert(submitTextIndex !== -1 && customRowIndex > submitTextIndex, "B: custom row must be bound to the Submit action");
assert(fn.includes('submit.parentElement'), "B: custom input must be resolved relative to Submit row");
assert(fn.includes('inputsBeforeCustom.indexOf(inputNode) === -1'), "B: newly appeared input guard missing");

// C. The new stage has its own diagnostic so future failures are not confused with popup-open bugs.
assert(fn.includes('research_custom_new_input_not_found'), "C: custom-input stage diagnostic missing");

console.log("bankcomm-research-custom-input.test.js passed (A-C)");
