"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const manifest = JSON.parse(fs.readFileSync(path.join(root, "autofill-plugin", "manifest.json"), "utf8"));
const sourcePath = path.join(root, "autofill-plugin", "content", "record-graph.js");
const source = fs.readFileSync(sourcePath, "utf8");
const graph = require(sourcePath);
const scripts = manifest.content_scripts[0].js;

assert(scripts.includes("content/record-graph.js"), "RecordGraph must be injected");
assert(scripts.indexOf("content/form-graph.js") < scripts.indexOf("content/record-graph.js"), "RecordGraph must load after FormGraph");
assert(scripts.indexOf("content/record-graph.js") < scripts.indexOf("content/site-analysis-collector.js"), "RecordGraph must load before analyzer");
assert(/^1\.\d+\.\d+$/.test(graph.version), "RecordGraph version must remain a 1.x semantic version");
assert.strictEqual(graph.schemaVersion, 1);
assert.strictEqual(typeof graph.scan, "function");
assert(source.includes("Mature-first"), "mature-first contract missing");
assert(source.includes('role: "add_action"'), "add-action structural role missing");
assert(source.includes('currentValuesIncluded: false'), "RecordGraph must not serialize control values");
assert(source.includes('arbitraryRecordTextIncluded: false'), "RecordGraph must not serialize arbitrary record text");
assert(source.includes('profileValuesIncluded: false'), "RecordGraph must not serialize profile values");
assert(!/\.click\s*\(/.test(source), "RecordGraph must not click");
assert(!/\.dispatchEvent\s*\(/.test(source), "RecordGraph must not mutate controls");
assert(!/\.value\s*=/.test(source), "RecordGraph must not assign field values");

const rows = [
  { rowId: "a1", label: "学校名称", controlCount: 1 },
  { rowId: "a2", label: "开始时间", controlCount: 1 },
  { rowId: "a3", label: "学历", controlCount: 1 },
  { rowId: "b1", label: "学校名称", controlCount: 1 },
  { rowId: "b2", label: "开始时间", controlCount: 1 },
  { rowId: "b3", label: "学历", controlCount: 1 }
];
const groups = graph.__test.splitRowsByRepeatedAnchor(rows);
assert.strictEqual(groups.length, 2, "repeated row signature should form two records");
assert.strictEqual(groups[0].length, 3);
assert.strictEqual(groups[1].length, 3);
assert.strictEqual(graph.__test.categoryHint("教育经历"), "education");
assert.strictEqual(graph.__test.categoryHint("实习工作"), "internshipExperience");
assert.strictEqual(graph.__test.categoryHint("个人信息"), "");
assert.strictEqual(graph.__test.stableId("rec", ["x", "y"]), graph.__test.stableId("rec", ["x", "y"]));

const collector = fs.readFileSync(path.join(root, "autofill-plugin", "content", "site-analysis-collector.js"), "utf8");
assert(collector.includes("collectRecordGraph"), "Analyzer must collect RecordGraph");
assert(collector.includes("recordGraphDiagnostics"), "Analyzer must expose RecordGraph diagnostics");
assert(collector.includes("schemaVersion: 7"), "Analyzer schema must advance for RecordGraph");

console.log("record graph core contract: PASS");
