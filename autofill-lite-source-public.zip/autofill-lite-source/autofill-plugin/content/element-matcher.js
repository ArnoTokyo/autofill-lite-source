// content/element-matcher.js — ElementMatcher: DOM 扫描 + 元素类型检测引擎
//
// 源码参考 (/Users/dayu/Desktop/网页端/原始代码和索引/content.readable.js):
//   ElementMatcher 主类 (混淆名 ee), 完整类体:               行 67749-68593
//     构造函数 (只存 this.config):                          行 67749-67757
//     findElementById:                                      行 67759-67770
//     findContainerByTitle / findContainingContainer /
//       findNextContainerByTitle / searchContainerInDepth /
//       isValidContainer / findSiblingContainer:             行 67772-67940
//     findLabelsByCard:                                      行 67942-67974
//     findElementAndTypeByLabel:                             行 67976-68035
//     findElementByType (12级优先级检测):                     行 68037-68145
//     findElementInSibling:                                  行 68147-68181
//     findElementByClass / findFormElement:                  行 68183-68220
//     findButton:                                            行 68193-68211
//     findTitle:                                             行 68222-68253
//     findAllLabels (三级回退):                               行 68255-68291
//     findClickableElementsNearTitle:                        行 68293-68324
//     findButtonsByContainerText (打分排序):                  行 68326-68419
//     findAddButton (原为 regenerator 生成器):                行 68421-68473
//     findAddButtonByAlternativeMethods (原为生成器):          行 68475-68557
//     getTitleValue:                                         行 68558-68568
//     静态 hasClassSubstring:                                 行 68570-68577
//   getVisibleInputElements (源码里挂在 DomUtils/p 类, 不在 ee 类内,
//     但只被 ee.findElementByType 使用):                      行 715-767
//   zt 类型检测辅助类 (findDateElement/findBitableSelectElement/
//     findBitableMultiSelectElement/findSearchElement/
//     findSelectElement/findRadioElements):                  行 66989-67067
//   Rt.T.isRadioLabel (label 文字含"性别/是否/有无"等判定):    行 4470-4475
//   Shadow DOM 遍历辅助 (独立的 fe 类, findElement/findAllElements/
//     findClosestElement, 与 ee 类无继承关系, 但服务于同一个
//     "在页面(含 Shadow DOM)里找元素"的职责，本文件按任务书要求
//     并入 ElementMatcher 统一对外暴露):                       行 69245-69333
//     其中 fe.isElementVisible (行69325) 是不查祖先链的简化版重复实现，
//     本文件不搬运它，直接委托 AF.DomUtils.isElementVisible。
//
// 改造点:
//   - 12级类型检测优先级、三级标签回退、Shadow DOM 遍历、按分数排序找按钮等算法
//     逻辑全部原样保留（含源码本身的冗余判断，见下方各方法内注释标注），仅将单字母
//     变量改为语义命名。
//   - findElementByType 原版接收 3 个布尔位置参数 (isDateRelated, isPhoneOrIdCard,
//     isRadioLabel)。本重建版按本项目既定契约 (见 content/fill-engine.js 里
//     `elementMatcher.findElementByType(row, { preferSelectors })` 的实际调用方式)
//     改成 (container, hints) 的形式，hints = { isDateRelated, isPhoneOrIdCard,
//     isRadioLabel, preferSelectors }。preferSelectors 是本项目新增的扩展位，
//     不存在于原版，允许调用方为这一次查询临时指定一份 selectors 配置
//     (而不是用 this.config 里长期绑定的那份)，源码没有这个能力。
//   - 找到"纯文本输入框"(textarea / 普通 input / 有值的 input) 时，原版统一标记
//     type: "input"；本重建版按既定契约统一改叫 type: "text"（因为
//     content/form-handler.js 的 fillLabels 类型二次修正步骤是按 "text" 字符串
//     判断的，AF.FormHandler.fillFormElement 的 switch 也没有 "input" 分支，
//     未命中的字符串一律走 default→handleText，用哪个名字对分发结果本身不影响，
//     但用 "text" 才能让 fillLabels 里 isDatePicker/isSearchSelect 的二次纠正逻辑触发)。
//   - contenteditable 分支原版返回小写 "contenteditable"；本重建版改成
//     "contentEditable" (驼峰)，因为 content/form-handler.js 的
//     fillFormElement switch 语句用的 case 是 "contentEditable"，大小写不一致
//     会导致这个类型静默走错 default 分支。
//   - 原版 findElementByType 12 级优先级里本来就没有单独检测 checkbox 的分支
//     (checkbox 类型的 <input> 最终会落到"普通 input"兜底分支)，这是源码本身的
//     行为，不是本次改写引入的疏漏，原样保留。
//   - getVisibleInputElements / zt 系列类型检测函数在源码里分散在 DomUtils(p)类
//     和独立的 zt 类中，这里合并成本文件内的私有辅助 (getVisibleInputElements +
//     TypeDetect.*)，避免污染已交付的 AF.DomUtils；能直接复用
//     AF.DomUtils.isNormalSelect/matchesAnySelector/hasClassSubstring 的地方
//     直接调用，不重复内联判断。
//   - findAddButton / findAddButtonByAlternativeMethods 原为 regenerator 生成器
//     实现，改写为原生 async/await，算法逻辑保持一致。
//   - isElementVisible 只保留一份，委托给 AF.DomUtils.isElementVisible。
//   - 未发现会员/登录/配额相关逻辑，无需删除。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  var LONG_TEXT_FIELDS = new Set([
    "detailedContent", "details", "description", "selfIntroduction",
    "workContent", "projectContent", "responsibility", "achievement"
  ]);

  function isLongTextField(fieldKey) {
    return LONG_TEXT_FIELDS.has(String(fieldKey || ""));
  }

  function isLongTextControl(el) {
    if (!(el instanceof HTMLElement) || !DomUtils.isElementVisible(el)) return false;
    var tag = String(el.tagName || "").toLowerCase();
    return tag === "textarea" || el.isContentEditable ||
      (el.matches && (el.matches('[contenteditable="true"]') || el.matches('[role="textbox"]')));
  }

  function longTextResult(element, source) {
    if (!element) return { type: null, element: null, source: source || "" };
    return {
      // Keep textarea distinct in the structured plan; FormHandler routes it
      // through the long-text writer rather than generic handleText.
      type: String(element.tagName || "").toLowerCase() === "textarea" ? "textarea" : "contentEditable",
      element: element,
      source: source || ""
    };
  }
  var DomUtils = AF.DomUtils;
  var LabelUtils = AF.LabelUtils;
  var SELECTORS = AF.SELECTORS;
  var EXTENSION_UI_SELECTOR = "#autofill-panel-root, #autofill-mini-logo, #__af_report_buttons__, #__af_diagnostic_btn__";

  function recruitmentNodes(nodeList) {
    return Array.from(nodeList || []).filter(function (node) {
      return !(node && node.closest && node.closest(EXTENSION_UI_SELECTOR));
    });
  }

  // ============================================================
  // 私有辅助 1: label 文字是否属于"单选类"标签 (源码 Rt.T.isRadioLabel, 行4470-4475)
  // AF.LabelUtils (utils.js) 没有导出这个方法，这里按源码原样补一份私有实现。
  // ============================================================
  function scopeToActiveDialogIfAvailable(nodeList) {
    return recruitmentNodes(nodeList);
  }

  function isRadioLabel(text) {
    if (!text) return false;
    // "是否统招"/"是否全日制"这类学历字段虽然含"是否"，但走的是下拉/文本而不是单选，排除掉
    if (/是否.*(全日制|统招)/.test(text)) return false;
    return ["性别", "是否", "有无", "有否", "可否", "是否已婚", "婚姻状况", "婚否"].some(function (kw) {
      return text.includes(kw);
    });
  }

  function normalizeLabelIntentText(text) {
    return String(text || "").replace(/\s+/g, "").replace(/[：:*＊]/g, "");
  }

  function getFieldIntent(labelText) {
    var text = normalizeLabelIntentText(labelText);
    if (!text) return null;
    if (LabelUtils.isDateRelatedLabel(text)) return "date";

    if (/(学校|院校|专业|公司|单位|部门|岗位|职位|职务|项目名|项目名称|姓名|名称|邮箱|电子邮件|邮件|电话|手机|手机号|移动电话|微信|微信号|证件号码|身份证|年龄|地址|住址|代码|编号|账号|学号|工号|成绩|分数|绩点|薪资|年薪|特长|爱好)/.test(text) && !/(类别|分类|类型|方向|等级|层次)/.test(text)) {
      return "text";
    }

    if (/(证件类别|证件类型|电话所在区域|手机所在区域|区号|国籍|国家|地区|籍贯|民族|政治面貌|学历|学位|学校类别|院校类别|专业类别|专业分类|专业方向|城市|省份|户口|所在地|工作地点|意向地点|性别|婚姻|语种|语言|等级|渠道|类别|类型|是否|有无|服从|排名|应届生届别)/.test(text)) {
      return "choice";
    }

    if (/(奖项|奖励|专利名|专利名称)/.test(text)) {
      return "text";
    }

    return null;
  }

  function isFieldItemLike(el) {
    if (!(el instanceof HTMLElement)) return false;
    if (el.matches && el.matches(".ud-formily-item, .ant-form-item, .el-form-item, .next-form-item, .table-field-tiled-item, .ivu-form-item, .arco-form-item, .semi-form-field, .form-item, .form-group, .field-item, .floor_view_editor_item, .pt-l, .pt-r, .apply-field-Q2iJ7AtQGX, .field-qLq39ezkYe, .form_container li, .aply-field-li, [role='group']")) {
      return true;
    }
    var cls = Array.from(el.classList || []).join(" ").toLowerCase();
    return /(^|\s|[-_])(form|field|input|apply-field)[-_]?(item|row|group|wrap|wrapper)?(\s|$|[-_])/.test(cls);
  }

  function findNearestFieldItem(labelEl) {
    if (!(labelEl instanceof HTMLElement)) return null;
    // 飞书招聘使用 UD Formily。`.ud-formily-item-label` 和实际控件都包在
    // `.ud-formily-item` 内；若不把它当作字段边界，后续向上遍历会进入整张经历卡，
    // 从而把“起止时间/项目链接/描述”错误地指向前一个输入框。
    var closest = labelEl.closest && labelEl.closest(".ud-formily-item, .ant-form-item, .el-form-item, .next-form-item, .table-field-tiled-item, .ivu-form-item, .arco-form-item, .semi-form-field, .form-item, .form-group, .field-item, .floor_view_editor_item, .pt-l, .pt-r, .apply-field-Q2iJ7AtQGX, .field-qLq39ezkYe, .form_container li, .aply-field-li, [role='group']");
    if (closest && !closest.closest(EXTENSION_UI_SELECTOR)) return closest;

    var cur = labelEl.parentElement;
    var depth = 0;
    while (cur && depth < 8) {
      if (cur.closest && cur.closest(EXTENSION_UI_SELECTOR)) return null;
      if (isFieldItemLike(cur)) return cur;
      cur = cur.parentElement;
      depth++;
    }
    return null;
  }

  function isPlainTextCandidate(el, config) {
    if (!(el instanceof HTMLElement)) return false;
    if (!DomUtils.isElementVisible(el)) return false;
    if (el.disabled || el.readOnly) return false;
    if (el.closest && el.closest(".ant-select, .el-select, .ant-cascader-picker, .el-cascader, .ivu-select, .arco-select, .semi-select, .bitable-single-selector-editor, .bitable-multi-selector-editor, [class^='sd-Dropdown-container'], [class*=' sd-Dropdown-container'], [class^='sd-Select-container'], [class*=' sd-Select-container']")) return false;
    if (DomUtils.isDatePicker(el, config) || DomUtils.isNormalSelect(el, config) || DomUtils.isSearchSelect(el, config)) return false;
    var tag = el.tagName.toLowerCase();
    if (tag === "textarea") return true;
    if (el.isContentEditable || (el.matches && el.matches('[contenteditable="true"]'))) return true;
    if (tag !== "input") return false;
    var type = String(el.getAttribute("type") || "text").toLowerCase();
    return ["", "text", "email", "tel", "number", "url", "password"].indexOf(type) !== -1;
  }

  function findPlainTextElement(elements, config, labelEl) {
    var list = elements.filter(function (el) {
      return isPlainTextCandidate(el, config);
    });
    if (!list.length) return null;
    if (labelEl && labelEl.getBoundingClientRect) {
      var labelRect = labelEl.getBoundingClientRect();
      list.sort(function (a, b) {
        function distance(el) {
          var rect = el.getBoundingClientRect();
          var dx = rect.left - labelRect.left;
          var dy = rect.top - labelRect.top;
          return Math.sqrt(dx * dx + dy * dy);
        }
        return distance(a) - distance(b);
      });
    }
    return list[0];
  }

  function shouldPreferPlainTextBeforeSelect(labelEl, hints) {
    var text = normalizeLabelIntentText((labelEl && labelEl.textContent) || (hints && hints.labelText) || "");
    return /(证件号码|身份证号|身份证号码|护照号|护照号码|手机号|手机号码|联系电话|电话|邮箱|电子邮箱|姓名|微信号|学号|工号)/.test(text);
  }

  function findLabelMatchedPlainTextElement(elements, config, labelEl, hints) {
    var labelText = normalizeLabelIntentText((labelEl && labelEl.textContent) || (hints && hints.labelText) || "");
    if (!labelText) return null;
    var list = elements.filter(function (el) {
      if (!isPlainTextCandidate(el, config)) return false;
      var hint = normalizeLabelIntentText([
        el.placeholder,
        el.name,
        el.id,
        el.getAttribute && el.getAttribute("aria-label"),
        el.getAttribute && el.getAttribute("title"),
      ].filter(Boolean).join(" "));
      return hint && (hint.indexOf(labelText) !== -1 || labelText.indexOf(hint) !== -1);
    });
    if (!list.length) return null;
    return findPlainTextElement(list, config, labelEl);
  }

  function findEmailInputElement(elements, labelEl, hints) {
    var labelText = normalizeLabelIntentText((labelEl && labelEl.textContent) || (hints && hints.labelText) || "");
    if (!/(邮箱|电子邮件|邮件)/.test(labelText)) return null;
    var candidates = elements.filter(function (el) {
      if (!isPlainTextCandidate(el, null) || String(el.tagName || "").toLowerCase() !== "input") return false;
      var type = String(el.getAttribute("type") || "text").toLowerCase();
      var hint = normalizeLabelIntentText([
        el.placeholder, el.name, el.id,
        el.getAttribute && el.getAttribute("aria-label"),
        el.getAttribute && el.getAttribute("title")
      ].filter(Boolean).join(" "));
      // 原生 email 类型或带邮箱语义的 name/id 优先；明确 QQ 控件不能作为邮箱。
      if (/(qq|扣扣)/.test(hint) && !/(邮箱|email|mail)/.test(hint)) return false;
      return type === "email" || /(邮箱|email|mail)/.test(hint);
    });
    return candidates.length ? findPlainTextElement(candidates, null, labelEl) : null;
  }

  // 有些招聘站把学校/专业/行业等选择器伪装成普通 input：点击后才打开
  // “搜索 + 候选项 + 确认按钮”的独立弹窗。它不在任何常见 Select 容器里，
  // 若仅按 input 判断会走普通文本填写，导致弹窗虽打开却没有完成选择。
  function findDialogChoiceInputCandidate(elements, config, hints) {
    if (!hints || hints.isDateRelated) return null;
    var labelText = normalizeLabelIntentText(hints.labelText || (hints.labelElement && hints.labelElement.textContent) || "");
    if (!/(学校|院校|专业|岗位|职位|行业|类别)/.test(labelText)) return null;
    var candidates = elements.filter(function (el) {
      if (!isPlainTextCandidate(el, config) || String(el.tagName || "").toLowerCase() !== "input") return false;
      var placeholder = String(el.getAttribute("placeholder") || "").replace(/\s+/g, "").trim();
      return /^请选择/.test(placeholder);
    });
    return candidates[0] || null;
  }

  function findVisibleFrameworkSelectInField(fieldItem, labelEl) {
    if (!fieldItem || !fieldItem.querySelectorAll) return null;
    var list = Array.from(fieldItem.querySelectorAll(
      ".ant-select, .el-select, .el-autocomplete, .el-cascader, .ant-cascader-picker, .rocket-select, .select_box, .multi_select_box, [class^='sd-Dropdown-container'], [class*=' sd-Dropdown-container'], [class^='sd-Select-container'], [class*=' sd-Select-container'], select"
    )).filter(function (el) {
      return DomUtils.isElementVisible(el);
    });
    if (!list.length) return null;
    if (labelEl && labelEl.getBoundingClientRect) {
      var labelRect = labelEl.getBoundingClientRect();
      list.sort(function (a, b) {
        function score(el) {
          var rect = el.getBoundingClientRect();
          var dx = rect.left - labelRect.left;
          var dy = rect.top - labelRect.top;
          var value = -Math.sqrt(dx * dx + dy * dy);
          if (el.matches && el.matches(".ant-select, .el-select, .el-autocomplete, .rocket-select, .select_box, .multi_select_box, [class^='sd-Dropdown-container'], [class*=' sd-Dropdown-container'], [class^='sd-Select-container'], [class*=' sd-Select-container']")) value += 1000;
          if (el.querySelector && el.querySelector("input, input[type='search']")) value += 100;
          return value;
        }
        return score(b) - score(a);
      });
    }
    return list[0];
  }

  function frameworkSelectElementType(element, labelEl) {
    if (!element) return "select";
    var hasInput = !!(element.querySelector && element.querySelector("input, input[type='search']"));
    if (!hasInput) return "select";
    if (element.matches && element.matches(".ant-select")) {
      var labelText = normalizeLabelIntentText(labelEl && labelEl.textContent || "");
      var explicitlySearchable = element.matches(
        ".ant-select-show-search, .ant-select-auto-complete, .ant-select-combobox"
      );
      // Ant v3 的普通单选也内置一个 display:none 的 input，不能仅凭“存在 input”
      // 判成搜索下拉。学校/专业等远程字典字段保留原搜索路由。
      return explicitlySearchable || /(学校|院校|专业)/.test(labelText) ? "search" : "select";
    }
    return "search";
  }

  function findCustomSelectNearLabel(labelEl) {
    try {
      if (!(labelEl instanceof HTMLElement)) return null;
      var scopes = [];
      var directParent = labelEl.parentElement;
      if (directParent) scopes.push(directParent);
      var fieldItem = findNearestFieldItem(labelEl);
      if (fieldItem && scopes.indexOf(fieldItem) === -1) scopes.push(fieldItem);
      if (directParent && directParent.parentElement) {
        var parent = directParent.parentElement;
        var labelSelector = ".text, label, .form-label, .field-label, .form-item-label, .resume-module-label";
        var labelCount = 0;
        try {
          labelCount = parent.querySelectorAll(labelSelector).length;
        } catch (e) {}
        if (labelCount <= 1 && scopes.indexOf(parent) === -1) scopes.push(parent);
      }
      var labelRect = labelEl.getBoundingClientRect();
      var candidates = [];
      scopes.forEach(function (scope) {
        Array.from(scope.querySelectorAll(".select-wrapper, .education-select, .country-select, .province-select, .city-select, .area-select, .region-select, .custom-select, [class*='select-box']")).forEach(function (wrapper) {
          if (!DomUtils.isElementVisible(wrapper)) return;
          if (wrapper.querySelector(".required-year, .required-month") || wrapper.closest(".start-time-module, .end-time")) return;
          var trigger = wrapper.querySelector(".select-left, .select-right, .select, [class*='select'][class*='value'], [class*='select'][class*='trigger']") || wrapper;
          var rect = wrapper.getBoundingClientRect();
          var dx = rect.left - labelRect.left;
          var dy = rect.top - labelRect.top;
          if (dx < -40 || Math.abs(dy) > 120) return;
          var score = Math.sqrt(dx * dx + dy * dy);
          if (dx >= -20) score -= 80;
          if (Math.abs(dy) < 120) score -= 40;
          if (trigger !== wrapper) score -= 20;
          candidates.push({ wrapper: wrapper, score: score });
        });
      });
      candidates.sort(function (a, b) { return a.score - b.score; });
      return candidates.length ? candidates[0].wrapper : null;
    } catch (e) {
      return null;
    }
  }

  // ============================================================
  // 私有辅助 2: 类型检测函数集合 (源码 zt 类, 行66989-67067)
  // ============================================================
  var TypeDetect = {
    findDateElement: function (elements, hints) {
      var rawDateElements = elements.filter(function (el) {
        return (
          DomUtils.matchesAnySelector(el, SELECTORS.date) ||
          el.type === "date" ||
          el.classList.contains("mdf-cal") ||
          !!(el.closest && el.closest(".date-ipt")) ||
          !!(el.closest && el.closest(".next-range-picker, .next-date-picker, .next-month-picker")) ||
          !!(el.closest && el.closest(".throne-biz-date-range-picker-wrapper")) ||
          !!(el.querySelector && el.querySelector(".required-year, .required-month")) ||
          !!(el.closest && el.closest(".el-date-editor, .el-range-editor, .el-date-picker")) ||
          !!(el.closest && el.closest(".ant-calendar-picker"))
        );
      });
      var dateElements = Array.from(new Set(rawDateElements.map(function (el) {
        if (el.tagName && el.tagName.toLowerCase() === "input") return el;
        return el.querySelector && el.querySelector("input") || el;
      })));
      if (!dateElements.length) return null;

      var labelText = String(hints && hints.labelText || "").toLowerCase();
      var isEndLabel = /(结束|截止|截至|终止|毕业|离职|end|finish|to)/.test(labelText);
      var labelElement = hints && hints.labelElement;
      if (labelElement && dateElements.length > 1) {
        var labelItem = labelElement.closest && labelElement.closest(".ud-formily-item, .ant-form-item, .el-form-item, [role='group']");
        var labelRect = labelElement.getBoundingClientRect();
        dateElements.sort(function (a, b) {
          function score(el) {
            var value = 0;
            var item = el.closest && el.closest(".ud-formily-item, .ant-form-item, .el-form-item, [role='group']");
            if (labelItem && item === labelItem) value += 100000;
            var text = [el.name, el.id, el.getAttribute("placeholder"), el.getAttribute("aria-label")]
              .filter(Boolean).join(" ").toLowerCase();
            if (isEndLabel && /(end|结束|截止|截至)/.test(text)) value += 10000;
            if (!isEndLabel && /(start|开始|起始)/.test(text)) value += 10000;
            if (isEndLabel && /(start|开始|起始)/.test(text)) value -= 10000;
            if (!isEndLabel && /(end|结束|截止|截至)/.test(text)) value -= 10000;
            var rect = el.getBoundingClientRect();
            var dx = rect.left - labelRect.left;
            var dy = rect.top - labelRect.top;
            value -= Math.sqrt(dx * dx + dy * dy);
            return value;
          }
          return score(b) - score(a);
        });
        return dateElements[0];
      }
      if (isEndLabel && dateElements.length > 1) return dateElements[dateElements.length - 1];
      return dateElements[0];
    },
    findBitableSelectElement: function (elements) {
      return elements.find(function (el) {
        return (
          (el.matches && el.matches(".bitable-single-selector-editor, .bitable-3356de__select, .b-select-dropdown-menu")) ||
          (el.closest && el.closest(".bitable-single-selector-editor"))
        );
      });
    },
    findBitableMultiSelectElement: function (elements) {
      return elements.find(function (el) {
        return (
          (el.matches && el.matches(".bitable-multi-selector-editor")) ||
          (el.closest && el.closest(".bitable-multi-selector-editor"))
        );
      });
    },
    findSearchElement: function (elements) {
      return elements.find(function (el) {
        return (
          (!el.closest || !el.closest(".bitable-single-selector-editor, .bitable-multi-selector-editor")) &&
          (DomUtils.matchesAnySelector(el, SELECTORS.select) ||
            el.tagName.toLowerCase() === "select" ||
            !!el.closest(".el-select") ||
            !!el.closest(".el-autocomplete") ||
            !!el.closest(".el-cascader") ||
            !!el.closest(".ant-select") ||
            !!el.closest(".ant-cascader-picker") ||
            !!el.closest(".rocket-select") ||
            !!el.closest(".next-select")) &&
          (el.querySelector("input") !== null ||
            el.querySelector('input[type="search"]') !== null ||
            DomUtils.hasClassSubstring(el, "search") ||
            DomUtils.hasClassSubstring(el, "cascader") ||
            DomUtils.hasClassSubstring(el, "rocket-select") ||
            DomUtils.hasClassSubstring(el.parentElement, "select-filter-input") ||
            DomUtils.hasClassSubstring(el.parentElement, "sd-Select-container") ||
            DomUtils.hasClassSubstring(el, "el-select"))
        );
      });
    },
    findSelectElement: function (elements) {
      return elements.find(function (el) {
        return (
          DomUtils.matchesAnySelector(el, SELECTORS.select) ||
          el.tagName.toLowerCase() === "select" ||
          !!el.closest(".el-select") ||
          !!el.closest(".el-autocomplete") ||
          !!el.closest(".el-cascader") ||
          !!el.closest(".ant-select") ||
          !!el.closest(".ant-cascader-picker") ||
          !!el.closest(".rocket-select") ||
          !!el.closest(".next-select")
        );
      });
    },
    findRadioElements: function (elements, config) {
      function normalizeRadioCandidate(el) {
        if (!el || !(el instanceof Element)) return null;
        if (el.matches && el.matches(".ant-radio-wrapper, .el-radio, .phoenix-radio, input[type='radio'], [role='radio']")) return el;
        return el.closest && el.closest(".ant-radio-wrapper, .el-radio, .phoenix-radio, input[type='radio'], [role='radio']");
      }
      if (config && config.selectors && config.selectors.radio && config.selectors.radio.class) {
        var sel = config.selectors.radio.class;
        var filtered = elements.filter(function (el) {
          if (el.closest && el.closest(".bitable-single-selector-editor, .bitable-multi-selector-editor")) {
            return false;
          }
          try {
            return el.matches(sel);
          } catch (e) {
            var cls = sel.charAt(0) === "." ? sel.slice(1) : sel;
            return el.classList.contains(cls);
          }
        });
        if (filtered.length > 0) return Array.from(new Set(filtered.map(normalizeRadioCandidate).filter(Boolean)));
      }
      return Array.from(new Set(elements.map(function (el) {
        if (
          DomUtils.matchesAnySelector(el, SELECTORS.radio) ||
          el.type === "radio" ||
          (el.closest && el.closest(".ant-radio-wrapper, .el-radio, .phoenix-radio, [role='radio']"))
        ) {
          return normalizeRadioCandidate(el);
        }
        return null;
      }).filter(Boolean)));
    },
    findCheckboxElements: function (elements, config) {
      if (config && config.selectors && config.selectors.checkbox && config.selectors.checkbox.class) {
        var sel = config.selectors.checkbox.class;
        var configured = elements.filter(function (el) {
          try {
            return el.matches(sel) || (el.closest && el.closest(sel));
          } catch (e) {
            return false;
          }
        });
        if (configured.length > 0) return configured;
      }
      return elements.filter(function (el) {
        return (
          el.type === "checkbox" ||
          el.getAttribute("role") === "checkbox" ||
          DomUtils.hasClassSubstring(el, "checkbox") ||
          !!(el.closest && el.closest(".el-checkbox, .ant-checkbox-wrapper, [class*='checkbox']"))
        );
      });
    },
  };

  // ============================================================
  // 私有辅助 3: 获取容器内所有"候选可见交互元素" (源码 getVisibleInputElements, 行715-767)
  // 只被 findElementByType 使用。源码按优先级依次收集 日期→radio/按钮类→
  // 带内嵌搜索框的下拉→普通下拉(排除已归入前者的)→contenteditable→input→textarea，
  // 最后去重。这个收集顺序本身不影响 findElementByType 的判定优先级(那是由
  // findElementByType 里各自独立的 .find()/.filter() 调用顺序决定的)，这里只是
  // 原样保留源码的收集顺序，不做改动。
  // ============================================================
  function getVisibleInputElements(container, config) {
    if (!container) return [];
    if (container.closest && container.closest(EXTENSION_UI_SELECTOR)) return [];
    try {
      var all = Array.from(container.querySelectorAll("*")).filter(function (el) {
        return !(el.closest && el.closest(EXTENSION_UI_SELECTOR)) && DomUtils.isElementVisible(el);
      });
      if (DomUtils.isElementVisible(container) && !(container.closest && container.closest(EXTENSION_UI_SELECTOR))) all.push(container);

      var result = [];
      var append = function (list) {
        result.push.apply(result, list);
      };

      // 1. 日期候选
      append(
        all.filter(function (el) {
          return (
            DomUtils.matchesAnySelector(el, SELECTORS.date) ||
            el.type === "date" ||
            el.classList.contains("mdf-cal") ||
            !!el.closest(".date-ipt") ||
            !!el.closest(".next-range-picker, .next-date-picker, .next-month-picker") ||
            !!el.closest(".throne-biz-date-range-picker-wrapper") ||
            !!(el.querySelector && el.querySelector(".required-year, .required-month")) ||
            !!el.closest(".el-date-editor, .el-range-editor, .el-date-picker") ||
            !!el.closest(".ant-calendar-picker")
          );
        })
      );

      // 2. radio / 按钮类候选 (含站点配置 selectors.radio.class 覆盖)
      append(
        all.filter(function (el) {
          if (config && config.selectors && config.selectors.radio && config.selectors.radio.class) {
            var sel = config.selectors.radio.class;
            if (el.matches(sel) || el.closest(sel)) return true;
          }
          return (
            DomUtils.matchesAnySelector(el, SELECTORS.radio) ||
            !!el.closest(".phoenix-radio-group") ||
            el.tagName.toLowerCase() === "button" ||
            el.getAttribute("role") === "button" ||
            el.classList.contains("button") ||
            el.getAttribute("type") === "button" ||
            el.classList.contains("radio")
          );
        })
      );

      // 3. 带内嵌搜索框/级联的下拉容器 (search-select)
      var searchSelects = all.filter(function (el) {
        return (
          (DomUtils.matchesAnySelector(el, SELECTORS.select) ||
            el.tagName.toLowerCase() === "select" ||
            !!el.closest(".el-select") ||
            !!el.closest(".el-autocomplete") ||
            !!el.closest(".el-cascader") ||
            !!el.closest(".ant-select") ||
            !!el.closest(".ant-cascader-picker") ||
            !!el.closest(".rocket-select") ||
            !!el.closest(".next-select")) &&
          (el.querySelector("input") !== null ||
            el.querySelector('input[type="search"]') !== null ||
            DomUtils.hasClassSubstring(el, "search") ||
            DomUtils.hasClassSubstring(el, "cascader") ||
            DomUtils.hasClassSubstring(el, "rocket-select") ||
            DomUtils.hasClassSubstring(el.parentElement, "select-filter-input") ||
            DomUtils.hasClassSubstring(el.parentElement, "sd-Select-container"))
        );
      });
      append(searchSelects);

      // 4. 普通下拉候选 (排除已经归入 search-select 的)
      append(
        all.filter(function (el) {
          return (
            (DomUtils.matchesAnySelector(el, SELECTORS.select) ||
              el.tagName.toLowerCase() === "select" ||
              !!el.closest(".el-select") ||
              !!el.closest(".el-autocomplete") ||
              !!el.closest(".el-cascader") ||
              !!el.closest(".ant-select") ||
              !!el.closest(".ant-cascader-picker") ||
              !!el.closest(".rocket-select") ||
              !!el.closest(".next-select")) &&
            searchSelects.indexOf(el) === -1
          );
        })
      );

      // 5. contenteditable
      append(
        all.filter(function (el) {
          return el.isContentEditable || (el.matches && el.matches('[contenteditable="true"]'));
        })
      );

      // 6. input
      append(
        all.filter(function (el) {
          return el.tagName.toLowerCase() === "input";
        })
      );

      // 7. textarea
      append(
        all.filter(function (el) {
          return el.tagName.toLowerCase() === "textarea";
        })
      );

      return Array.from(new Set(result));
    } catch (e) {
      return [];
    }
  }

  function findElementInNearestFieldItem(matcher, labelEl, hints) {
    var fieldItem = findNearestFieldItem(labelEl);
    if (!fieldItem) return { type: null, element: null };

    var effectiveConfig = hints.preferSelectors ? { selectors: hints.preferSelectors } : matcher.config;
    var candidates = getVisibleInputElements(fieldItem, effectiveConfig);
    if (!candidates.length) return { type: null, element: null };

    // 北森/智业旧版 Portal 的地址字段是 readonly 输入框，点击后由
    // `.bas_select_wrap` 弹层完成省市区选择。它既不是普通文本，也不是框架 Select；
    // 必须在字段边界内直接路由给专用选择适配器，避免几何回退串到相邻输入框。
    var legacyZhiyeAddress = fieldItem.querySelector && fieldItem.querySelector("input.ConstDictSingleSelect[readonly]");
    if (legacyZhiyeAddress && DomUtils.isElementVisible(legacyZhiyeAddress)) {
      return { type: "select", element: legacyZhiyeAddress };
    }

    var dialogChoiceInput = findDialogChoiceInputCandidate(candidates, effectiveConfig, hints);
    if (dialogChoiceInput) return { type: "search", element: dialogChoiceInput };

    if (hints.fieldIntent === "text" && shouldPreferPlainTextBeforeSelect(labelEl, hints)) {
      var emailEl = findEmailInputElement(candidates, labelEl, hints);
      if (emailEl) return { type: "text", element: emailEl };
      var exactTextEl = findLabelMatchedPlainTextElement(candidates, effectiveConfig, labelEl, hints);
      if (exactTextEl) return { type: "text", element: exactTextEl };
      var preferredTextEl = findPlainTextElement(candidates, effectiveConfig, labelEl);
      if (preferredTextEl) return { type: "text", element: preferredTextEl };
    }

    // Hotjob/Honor/Moka 模板中“学校/毕业院校/专业”视觉上是 Select，
    // 但旁边常伴随一个隐藏 input；仅按 label 文义会被归为 text，导致
    // 先找纯文本输入而错过真正的框架下拉。字段项里存在可见框架下拉时，
    // 应优先交给 select/search 适配器。
    var frameworkSelect = findVisibleFrameworkSelectInField(fieldItem, labelEl);
    if (frameworkSelect) {
      return {
        type: frameworkSelectElementType(frameworkSelect, labelEl),
        element: frameworkSelect,
      };
    }

    if (hints.fieldIntent === "text") {
      var textEl = findPlainTextElement(candidates, effectiveConfig, labelEl);
      if (textEl) return { type: "text", element: textEl };
    }

    var found = matcher.findElementByType(fieldItem, hints);
    if (found && found.element) {
      if (hints.fieldIntent === "choice" && found.type === "text") {
        return { type: null, element: null };
      }
      return found;
    }

    return { type: null, element: null };
  }

  function isNearLabelCandidate(el) {
    if (!(el instanceof HTMLElement)) return false;
    if (el.closest && el.closest(EXTENSION_UI_SELECTOR)) return false;
    if (!DomUtils.isElementVisible(el)) return false;
    if (el.disabled || el.readOnly) return false;
    return true;
  }

  function candidateRect(el) {
    try {
      var rect = el.getBoundingClientRect();
      if (rect && rect.width > 0 && rect.height > 0) return rect;
      var inner = el.querySelector && el.querySelector("input, textarea, select, [contenteditable], [role='textbox']");
      return inner && inner.getBoundingClientRect ? inner.getBoundingClientRect() : rect;
    } catch (e) {
      return null;
    }
  }

  function getVisibleNearFieldCandidates(scope, config) {
    var nodes = getVisibleInputElements(scope, config);
    try {
      var extra = Array.from(scope.querySelectorAll(
        ".ant-select, .ant-radio-wrapper, .ant-checkbox-wrapper, .el-select, .el-radio, .el-checkbox, .rocket-select, [role='radio'], [role='checkbox'], [role='textbox'], [contenteditable]"
      ));
      nodes.push.apply(nodes, extra);
    } catch (e) {}
    return Array.from(new Set(nodes)).filter(isNearLabelCandidate);
  }

  function findElementNearLabelByGeometry(matcher, labelEl, hints) {
    if (!(labelEl instanceof HTMLElement) || !labelEl.getBoundingClientRect) {
      return { type: null, element: null };
    }
    try {
      var effectiveConfig = hints.preferSelectors ? { selectors: hints.preferSelectors } : matcher.config;
      var labelRect = labelEl.getBoundingClientRect();
      if (!labelRect || labelRect.width <= 0 || labelRect.height <= 0) return { type: null, element: null };
      var labelCenterY = labelRect.top + labelRect.height / 2;
      var scope =
        labelEl.closest && labelEl.closest(".apply-form-yCQO5hUc23, .ant-form, form, main, [class*='resume' i], [class*='apply' i]") ||
        document.body;
      var candidates = getVisibleNearFieldCandidates(scope, effectiveConfig);
      var labelsClass = matcher.config && matcher.config.selectors && matcher.config.selectors.labels && matcher.config.selectors.labels.class;
      var scored = [];

      candidates.forEach(function (candidate) {
        var rect = candidateRect(candidate);
        if (!rect || rect.width <= 0 || rect.height <= 0) return;
        if (candidate.contains && candidate.contains(labelEl)) return;

        var candidateCenterY = rect.top + rect.height / 2;
        var dy = Math.abs(candidateCenterY - labelCenterY);
        var dx = rect.left - labelRect.right;
        var belowGap = rect.top - labelRect.bottom;
        var sameLine = dy <= Math.max(36, Math.min(80, labelRect.height * 3));
        var justBelow = belowGap >= -8 && belowGap <= 120 && Math.abs(rect.left - labelRect.left) <= 420;
        if (!sameLine && !justBelow) return;
        if (dx < -80 && !justBelow) return;
        if (dx > 900) return;

        var owner = candidate.closest && candidate.closest(".ant-form-item, .el-form-item, .ud-formily-item, .form-item, .form-group, [role='group']");
        if (owner && labelsClass) {
          try {
            var labelsInOwner = Array.from(owner.querySelectorAll(labelsClass));
            if (labelsInOwner.length > 1 && labelsInOwner.indexOf(labelEl) === -1) return;
          } catch (e) {}
        }

        var score = 0;
        score += dy * 4;
        score += Math.abs(Math.max(dx, 0));
        if (dx >= -20) score -= 120;
        if (sameLine) score -= 80;
        if (justBelow) score -= 40;
        if (candidate.matches && candidate.matches(".ant-select, .el-select, .rocket-select")) score -= 40;
        if (candidate.tagName && /^(INPUT|TEXTAREA|SELECT)$/.test(candidate.tagName)) score -= 20;
        scored.push({ candidate: candidate, score: score });
      });

      scored.sort(function (a, b) { return a.score - b.score; });
      for (var i = 0; i < scored.length && i < 8; i++) {
        var result = matcher.findElementByType(scored[i].candidate, hints);
        if (result && result.element) return result;
      }
      return { type: null, element: null };
    } catch (e) {
      return { type: null, element: null };
    }
  }

  // ============================================================
  // ElementMatcher 主类 (源码 ee 类, 行67749-68593)
  // ============================================================
  function ElementMatcher(config) {
    this.config = config; // 行67749-67757: 只存一个 config 对象
  }

  // ---------- findElementById (行67759-67770) ----------
  ElementMatcher.prototype.findElementById = function (type, id) {
    try {
      var typeConfig = this.config && this.config.selectors && this.config.selectors[type];
      if (!typeConfig) return null;
      if (typeConfig.ids && !typeConfig.ids.includes(id)) return null;
      var el = document.getElementById(id);
      if (el && el.closest && el.closest(EXTENSION_UI_SELECTOR)) el = null;
      return el || this.findElementByClass(type);
    } catch (e) {
      return null;
    }
  };

  // ---------- findElementByClass (行68183-68191) ----------
  ElementMatcher.prototype.findElementByClass = function (type) {
    try {
      var typeConfig = this.config && this.config.selectors && this.config.selectors[type];
      if (typeConfig && typeConfig.class) {
        // 源码原样是 `.${e.class}`：如果 typeConfig.class 本身已经是一份完整选择器
        // (站点配置里常见 ".foo,.bar" 写法)，这里会拼成 "..foo,.bar"。这是源码本身
        // 的写法(未见其被显式处理/修复)，此处原样保留，不做"修正"，靠 try/catch 兜底。
        return recruitmentNodes(document.querySelectorAll("." + typeConfig.class));
      }
      return null;
    } catch (e) {
      return null;
    }
  };

  // ---------- findFormElement (行68213-68220) ----------
  ElementMatcher.prototype.findFormElement = function (type, id) {
    if (id) return this.findElementById(type, id);
    return this.findElementByClass(type);
  };

  // ---------- findContainerByTitle (行67772-67792) ----------
  ElementMatcher.prototype.findContainerByTitle = function (titleEl) {
    try {
      if (titleEl && titleEl.getAttribute && titleEl.getAttribute("data-af-graph-section-title")) {
        return titleEl;
      }
      var containerSearch = this.config && this.config.domStrategy && this.config.domStrategy.containerSearch;
      if (containerSearch && containerSearch.useSiblingContainer) {
        var sibling = this.findSiblingContainer(titleEl, containerSearch.parentLevels || 1);
        if (sibling) return sibling;
      }
      var containing = this.findContainingContainer(titleEl);
      if (containing) return containing;
      var next = this.findNextContainerByTitle(titleEl);
      return next || null;
    } catch (e) {
      return null;
    }
  };

  // ---------- findContainingContainer (行67794-67825) ----------
  ElementMatcher.prototype.findContainingContainer = function (el) {
    try {
      var containerClass = this.config && this.config.selectors && this.config.selectors.container && this.config.selectors.container.class;
      if (containerClass) {
        var closest = el.closest(containerClass);
        if (closest) return closest;
      }
      if (SELECTORS.containers && SELECTORS.containers.length > 0) {
        for (var i = 0; i < SELECTORS.containers.length; i++) {
          var found = el.closest(SELECTORS.containers[i]);
          if (found) return found;
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  };

  // ---------- findNextContainerByTitle (行67827-67847) ----------
  ElementMatcher.prototype.findNextContainerByTitle = function (el) {
    try {
      if (!el) return null;
      for (var cur = el.parentElement; cur; cur = cur.parentElement) {
        var sibling = cur.nextElementSibling;
        if (sibling) {
          var found = this.searchContainerInDepth(sibling, 5);
          if (found) return found;
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  };

  // ---------- searchContainerInDepth (行67849-67876) ----------
  ElementMatcher.prototype.searchContainerInDepth = function (el, depth) {
    try {
      if (this.isValidContainer(el)) return el;
      if (depth > 0) {
        for (var i = 0; i < el.children.length; i++) {
          var found = this.searchContainerInDepth(el.children[i], depth - 1);
          if (found) return found;
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  };

  // ---------- isValidContainer (行67878-67910) ----------
  ElementMatcher.prototype.isValidContainer = function (el) {
    try {
      if (!el) return false;
      var containerClass = this.config && this.config.selectors && this.config.selectors.container && this.config.selectors.container.class;
      if (containerClass && el.matches(containerClass)) return true;
      if (SELECTORS.containers && SELECTORS.containers.length > 0) {
        for (var i = 0; i < SELECTORS.containers.length; i++) {
          if (el.matches(SELECTORS.containers[i])) return true;
        }
      }
      return false;
    } catch (e) {
      return false;
    }
  };

  // ---------- findSiblingContainer (行67912-67940) ----------
  ElementMatcher.prototype.findSiblingContainer = function (el, levels) {
    levels = levels === undefined ? 1 : levels;
    try {
      var cur = el;
      for (var i = 0; i < levels; i++) {
        if (!(cur = cur.parentElement)) return null;
      }
      var sibling = cur.nextElementSibling;
      if (!sibling) return null;
      if (this.isValidContainer(sibling)) return sibling;
      var containerClass = this.config && this.config.selectors && this.config.selectors.container && this.config.selectors.container.class;
      if (containerClass) {
        var nested = sibling.querySelector(containerClass);
        if (nested) return nested;
      }
      return null;
    } catch (e) {
      return null;
    }
  };

  // ---------- findLabelsByCard (行67942-67974) ----------
  ElementMatcher.prototype.findLabelsByCard = function (container) {
    try {
      var graphStructure = this.config && this.config._graphStructure;
      if (graphStructure && Array.isArray(graphStructure.sections) && graphStructure.sections.length && container) {
        var graphSection = graphStructure.sections.find(function (section) {
          try { return section && section.selector && container.matches && container.matches(section.selector); } catch (_) { return false; }
        });
        if (graphSection) {
          var graphRows = [];
          (graphSection.rows || []).forEach(function (row) {
            try {
              var node = row && row.selector ? document.querySelector(row.selector) : null;
              if (!node || !(container === node || container.contains(node))) return;
              node.setAttribute("data-af-graph-row-label", String(row.label || ""));
              node.setAttribute("data-af-graph-row-id", String(row.rowId || ""));
              if (row.controlSelector) node.setAttribute("data-af-graph-control-selector", String(row.controlSelector));
              graphRows.push(node);
            } catch (_) {}
          });
          if (graphRows.length) return recruitmentNodes(graphRows);
        }
      }
      if (this.config && this.config.selectors && this.config.selectors.labels !== undefined) {
        var configClass = this.config.selectors.labels.class;
        if (configClass) {
          var byConfig = recruitmentNodes(container.querySelectorAll(configClass));
          // 展示卡片页打开编辑态后，服务器配置里的标签选择器可能仍指向
          // 展示态字段（例如 `.field-item-label`），而真实表单已经切换为
          // `label.el-form-item__label`。空 NodeList 不能终止回退链路。
          if (byConfig.length > 0 && !this.config.selectors.labels.mergeFallback) return byConfig;
          if (byConfig.length > 0 && this.config.selectors.labels.mergeFallback) {
            var merged = byConfig.slice();
            var seen = new Set(merged);
            var fallbackSelectors = (SELECTORS.labels || []).concat(["label"]);
            fallbackSelectors.forEach(function (selector) {
              recruitmentNodes(container.querySelectorAll(selector)).forEach(function (node) {
                if (!seen.has(node)) { seen.add(node); merged.push(node); }
              });
            });
            return merged;
          }
        }
      }
      if (SELECTORS.labels && SELECTORS.labels.length > 0) {
        for (var i = 0; i < SELECTORS.labels.length; i++) {
          var bySelector = recruitmentNodes(container.querySelectorAll(SELECTORS.labels[i]));
          if (bySelector.length > 0) return bySelector;
        }
      }
      return recruitmentNodes(container.querySelectorAll("label"));
    } catch (e) {
      return null;
    }
  };

  // Known long-text fields must never be resolved by generic geometric control
  // matching: an adjacent "至今" checkbox is not a valid description editor.
  ElementMatcher.prototype.findLongTextElement = function (labelEl, fieldKey, recordScope) {
    if (!isLongTextField(fieldKey)) return { type: null, element: null, source: "not_long_text" };
    try {
      var scopes = [];
      if (recordScope) scopes.push({ node: recordScope, source: "record_scope_textarea" });
      var fieldItem = findNearestFieldItem(labelEl);
      if (fieldItem && (!recordScope || fieldItem !== recordScope)) scopes.push({ node: fieldItem, source: "field_item_longtext" });
      if (labelEl && labelEl.parentElement && (!fieldItem || labelEl.parentElement !== fieldItem)) {
        scopes.push({ node: labelEl.parentElement, source: "label_parent_longtext" });
      }
      for (var i = 0; i < scopes.length; i++) {
        var controls = Array.from(scopes[i].node.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]'))
          .filter(isLongTextControl);
        if (!controls.length) continue;
        var hinted = controls.filter(function (el) {
          var hint = [el.getAttribute("placeholder"), el.getAttribute("aria-label"), el.getAttribute("name"), el.id]
            .filter(Boolean).join(" ");
          return /描述|描述内容|工作内容|项目内容/.test(hint);
        });
        // A record-local single editor is unambiguous even if Tencent changes
        // its placeholder copy.
        return longTextResult(hinted[0] || (controls.length === 1 ? controls[0] : null), scopes[i].source);
      }
      return { type: null, element: null, source: "longtext_control_not_found" };
    } catch (e) {
      return { type: null, element: null, source: "longtext_lookup_error" };
    }
  };

  // ---------- findElementAndTypeByLabel (行67976-68035) ----------
  ElementMatcher.prototype.findElementAndTypeByLabel = function (labelEl) {
    try {
      if (!(labelEl instanceof HTMLElement)) {
        return { type: null, element: null };
      }
      var labelText = LabelUtils.getLabelText(labelEl);
      var hints = {
        labelText: labelText,
        labelElement: labelEl,
        isDateRelated: LabelUtils.isDateRelatedLabel(labelText),
        isPhoneOrIdCard: LabelUtils.isPhoneOrIdCardLabel(labelText),
        isRadioLabel: isRadioLabel(labelText),
        fieldIntent: getFieldIntent(labelText),
      };

      var graphControlSelector = labelEl.getAttribute && labelEl.getAttribute("data-af-graph-control-selector");
      if (graphControlSelector) {
        try {
          var graphControl = document.querySelector(graphControlSelector);
          if (graphControl && (labelEl === graphControl || labelEl.contains(graphControl))) {
            var graphResult = this.findElementByType(graphControl, hints);
            if (graphResult && graphResult.element) return graphResult;
          }
        } catch (_) {}
      }

      if (labelEl.htmlFor) {
        var byId = document.getElementById(labelEl.htmlFor);
        if (byId) {
          var resultById = this.findElementByType(byId, hints);
          if (resultById.element) return resultById;
        }
      }

      // Formily/低代码表单通常把稳定字段名同时写在字段容器和真实控件上。
      // 优先按 data-form-field-id/name 绑定，避免依赖会变动的哈希 class 或几何距离。
      var semanticScope = labelEl.closest && labelEl.closest(".ud-formily-item, [id^='formily-item-']");
      if (semanticScope) {
        var semanticIds = [
          semanticScope.getAttribute("data-form-field-id"),
          semanticScope.getAttribute("data-form-field-name"),
        ].filter(Boolean);
        var semanticCandidates = Array.from(semanticScope.querySelectorAll(
          "[data-form-field-id], [data-form-field-name]"
        )).filter(function (candidate) {
          if (candidate === semanticScope || candidate.closest(".ud-formily-item") !== semanticScope) return false;
          var candidateId = candidate.getAttribute("data-form-field-id");
          var candidateName = candidate.getAttribute("data-form-field-name");
          return semanticIds.indexOf(candidateId) !== -1 || semanticIds.indexOf(candidateName) !== -1;
        });
        for (var semanticIndex = 0; semanticIndex < semanticCandidates.length; semanticIndex++) {
          var semanticResult = this.findElementByType(semanticCandidates[semanticIndex], hints);
          if (semanticResult && semanticResult.element) return semanticResult;
        }
      }

      var fieldBoundary = findNearestFieldItem(labelEl);
      var nearestFieldResult = findElementInNearestFieldItem(this, labelEl, hints);
      if (nearestFieldResult.element) return nearestFieldResult;

      // Moka fields live inside React-controlled per-field wrappers. If a label has
      // a concrete field boundary but no control can be resolved inside it, never
      // fall back to page-wide geometry. That fallback can jump into the next
      // section and, for example, write a basic-info birth date into a blank work
      // experience date range. Prefer an explicit miss over cross-section corruption.
      var mokaBoundaryClass = String(fieldBoundary && fieldBoundary.className || "");
      if (/(^|\.)mokahr\.com$/i.test(String(location.hostname || "")) &&
          fieldBoundary && /(?:apply-field|field[-_])/i.test(mokaBoundaryClass)) {
        return { type: null, element: null };
      }

      if (hints.fieldIntent === "choice") {
        var customSelect = findCustomSelectNearLabel(labelEl);
        if (customSelect) return { type: "select", element: customSelect };
      }

      var siblingCfg = this.config && this.config.domStrategy && this.config.domStrategy.labelInputSearch;
      if (siblingCfg && siblingCfg.useSiblingSearch) {
        var resultSibling = this.findElementInSibling(labelEl, siblingCfg.parentLevels || 1, hints);
        if (resultSibling.element) return resultSibling;
      }

      var nearbyResult = findElementNearLabelByGeometry(this, labelEl, hints);
      if (nearbyResult.element) return nearbyResult;

      for (var cur = labelEl.control || labelEl.parentElement; cur; ) {
        var found = this.findElementByType(cur, hints);
        if (found.element) return found;
        // 已识别出单字段容器时绝不能继续爬到经历卡/整个模块；宁可明确返回未定位，
        // 也不能把相邻字段的输入框当作当前字段并产生“验证成功”的假象。
        if (fieldBoundary && cur === fieldBoundary) break;
        if (!(cur = cur.parentElement)) break;

        var containerClass = this.config && this.config.selectors && this.config.selectors.container && this.config.selectors.container.class;
        if (containerClass && cur.matches(containerClass)) break;

        var labelsClass = this.config && this.config.selectors && this.config.selectors.labels && this.config.selectors.labels.class;
        if (labelsClass) {
          if (cur.querySelectorAll(labelsClass).length > 1) break;
        } else {
          var nativeLabels = cur.querySelectorAll("label");
          if (nativeLabels.length > 1 && LabelUtils.hasMultipleSimilarLabels(Array.from(nativeLabels), labelEl)) break;
        }
      }
      if (hints.fieldIntent === "choice") {
        var fallbackCustomSelect = findCustomSelectNearLabel(labelEl);
        if (fallbackCustomSelect) return { type: "select", element: fallbackCustomSelect };
      }
      return { type: null, element: null };
    } catch (e) {
      return { type: null, element: null };
    }
  };

  // ---------- findElementByType (行68037-68145) ----------
  // 原版签名 (container, isDateRelated, isPhoneOrIdCard, isRadioLabel)，
  // 本重建版按既定契约改成 (container, hints)，见文件头注释。
  ElementMatcher.prototype.findElementByType = function (container, hints) {
    hints = hints || {};
    try {
      // preferSelectors 是本项目的扩展位，允许调用方为这一次查询临时指定 selectors，
      // 不存在于原版 (源码里 getVisibleInputElements/isNormalSelect 等只认 this.config)。
      var effectiveConfig = hints.preferSelectors ? { selectors: hints.preferSelectors } : this.config;
      var candidates = getVisibleInputElements(container, effectiveConfig);

      // 优先级1: 日期
      if (hints.isDateRelated) {
        var dateEl = TypeDetect.findDateElement(candidates, hints);
        if (dateEl) return { type: "date", element: dateEl };
      }

      // 优先级2: Bitable 多选组件
      var multiEl = TypeDetect.findBitableMultiSelectElement(candidates);
      if (multiEl) return { type: "multiSelect", element: multiEl };

      // 优先级3: Bitable 单选组件
      var bitableSelectEl = TypeDetect.findBitableSelectElement(candidates);
      if (bitableSelectEl) return { type: "select", element: bitableSelectEl };

      // 优先级4: 身份证/电话号码常见的"有值的最后一个 input" (排除其实是普通下拉的情况)
      if (hints.isPhoneOrIdCard) {
        var inputCandidates = candidates.filter(function (el) {
          return el.tagName.toLowerCase() === "input";
        });
        if (inputCandidates.length > 0) {
          var lastInput = inputCandidates[inputCandidates.length - 1];
          if (DomUtils.isNormalSelect(lastInput, effectiveConfig)) {
            return { type: null, element: null };
          }
          return { type: "text", element: lastInput };
        }
      }

      // 优先级5: 有"单选类"标签提示时的 radio 检测
      if (hints.isRadioLabel) {
        var radiosHinted = TypeDetect.findRadioElements(candidates, effectiveConfig);
        if (radiosHinted.length > 0) return { type: "radio", element: radiosHinted };
      }

      // 优先级6: 无论 hints.isRadioLabel 是否为真，都无条件再检测一次 radio
      // (源码行68091-68097 本身就有这段冗余判断，原样保留)
      var radios = TypeDetect.findRadioElements(candidates, effectiveConfig);
      if (radios.length > 0) return { type: "radio", element: radios };

      // 优先级7: checkbox 复选框
      var checkboxes = TypeDetect.findCheckboxElements(candidates, effectiveConfig);
      if (checkboxes.length > 0) {
        return { type: "checkbox", element: checkboxes.length === 1 ? checkboxes[0] : checkboxes };
      }

      // 优先级7.5: 明确文本字段先找普通输入框，避免大容器内的下拉搜索框抢先命中。
      var dialogChoiceInput = findDialogChoiceInputCandidate(candidates, effectiveConfig, hints);
      if (dialogChoiceInput) return { type: "search", element: dialogChoiceInput };

      if (hints.fieldIntent === "text") {
        var hintedTextEl = findPlainTextElement(candidates, effectiveConfig, hints.labelElement);
        if (hintedTextEl) return { type: "text", element: hintedTextEl };
      }

      // 优先级8: 搜索式下拉
      var searchEl = TypeDetect.findSearchElement(candidates);
      if (searchEl) return { type: "search", element: searchEl };

      // 优先级9: 普通下拉
      var selectEl = TypeDetect.findSelectElement(candidates);
      if (selectEl) return { type: "select", element: selectEl };

      // 优先级10: textarea
      var textareaEl = candidates.find(function (el) {
        return el.tagName.toLowerCase() === "textarea";
      });
      if (textareaEl) return { type: "text", element: textareaEl };

      // 优先级11: contenteditable
      var editableEl = candidates.find(function (el) {
        return el.isContentEditable || (el.matches && el.matches('[contenteditable="true"]'));
      });
      if (editableEl) return { type: "contentEditable", element: editableEl };

      // 优先级12: 普通 input (排除已经是日期/radio/checkbox的)
      var plainInput = candidates.find(function (el) {
        return (
          el.tagName.toLowerCase() === "input" &&
          !TypeDetect.findDateElement([el]) &&
          !TypeDetect.findRadioElements([el], effectiveConfig).length &&
          !TypeDetect.findCheckboxElements([el], effectiveConfig).length
        );
      });
      if (plainInput) return { type: "text", element: plainInput };

      // 优先级13: 都不匹配
      return { type: null, element: null };
    } catch (e) {
      return { type: null, element: null };
    }
  };

  // ---------- findElementInSibling (行68147-68181) ----------
  ElementMatcher.prototype.findElementInSibling = function (labelEl, levels, hints) {
    try {
      var cur = labelEl;
      for (var i = 0; i < levels; i++) {
        if (!(cur = cur.parentElement)) return { type: null, element: null };
      }
      var sibling = cur.nextElementSibling;
      if (!sibling) return { type: null, element: null };
      var result = this.findElementByType(sibling, hints);
      return result.element ? result : { type: null, element: null };
    } catch (e) {
      return { type: null, element: null };
    }
  };

  // ---------- findButton (行68193-68211) ----------
  ElementMatcher.prototype.findButton = function (name, container) {
    container = container || document;
    try {
      var buttonsConfig = this.config && this.config.selectors && this.config.selectors.buttons;
      var entry = buttonsConfig && buttonsConfig[name];
      if (!entry) {
        // 源码只对 "add" 这一个 name 提供全局选择器兜底 (qt.D.addButton)，
        // "edit"/"save" 等没有配置就没有兜底，直接返回 null。这是源码本身的行为，
        // 保留它 —— 不额外发明一套 编辑/保存 关键词兜底。
        if (name === "add" && SELECTORS.addButton && SELECTORS.addButton.length > 0) {
          var joined = SELECTORS.addButton.join(", ");
          if (joined) return recruitmentNodes(container.querySelectorAll(joined));
        }
        return null;
      }
      if (entry.class) return recruitmentNodes(container.querySelectorAll(entry.class));
      return null;
    } catch (e) {
      return null;
    }
  };

  // ---------- findTitle (行68222-68253) ----------
  // 动态交互执行期间，结果会被限制在首次扫描确定的表单 surface 内。
  ElementMatcher.prototype.findTitle = function () {
    try {
      var graphStructure = this.config && this.config._graphStructure;
      if (graphStructure && Array.isArray(graphStructure.sections) && graphStructure.sections.length) {
        var graphTitles = [];
        graphStructure.sections.forEach(function (section) {
          try {
            var node = section && section.selector ? document.querySelector(section.selector) : null;
            if (!node || !AF.DomUtils.isElementVisible(node)) return;
            node.setAttribute("data-af-graph-section-title", String(section.title || ""));
            node.setAttribute("data-af-graph-section-id", String(section.sectionId || ""));
            graphTitles.push(node);
          } catch (_) {}
        });
        if (graphTitles.length) return scopeToActiveDialogIfAvailable(graphTitles);
      }
      var configTitleClass = this.config && this.config.selectors && this.config.selectors.title && this.config.selectors.title.class;
      if (configTitleClass) {
        var byConfig = document.querySelectorAll(configTitleClass);
        // `labels.mergeFallback` belongs exclusively to field-label discovery.
        // Tencent intentionally needs `.subtitle` plus generic label fallbacks
        // inside a section, but treating those fallback labels as *section
        // titles* makes Structured mode run the page twice: first by `.send_title`
        // modules, then again from field labels near the top of the page.  The
        // second pass can revisit experience gates after their real cards were
        // already filled and flip `无实习经历` / `无项目经历`.
        //
        // A configured title selector is authoritative whenever it resolves.
        // Only if it resolves nothing do we continue to the generic title
        // fallback chain below.
        if (byConfig && byConfig.length > 0) return scopeToActiveDialogIfAvailable(byConfig);
      }
      if (SELECTORS.titles && SELECTORS.titles.length > 0) {
        for (var i = 0; i < SELECTORS.titles.length; i++) {
          var bySelector = document.querySelectorAll(SELECTORS.titles[i]);
          if (bySelector && bySelector.length > 0) return scopeToActiveDialogIfAvailable(bySelector);
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  };

  // ---------- findAllLabels (三级回退, 行68255-68291) ----------
  // 同 findTitle，动态交互执行期间只返回当前 surface 内的标签。
  ElementMatcher.prototype.findAllLabels = function () {
    try {
      var configLabelsClass = this.config && this.config.selectors && this.config.selectors.labels && this.config.selectors.labels.class;
      if (configLabelsClass) {
        var byConfig = document.querySelectorAll(configLabelsClass);
        if (byConfig && byConfig.length > 0) return scopeToActiveDialogIfAvailable(byConfig);
      }
      if (SELECTORS.labels && SELECTORS.labels.length > 0) {
        for (var i = 0; i < SELECTORS.labels.length; i++) {
          var bySelector = document.querySelectorAll(SELECTORS.labels[i]);
          if (bySelector && bySelector.length > 0) return scopeToActiveDialogIfAvailable(bySelector);
        }
      }
      var native = document.querySelectorAll("label");
      return native && native.length > 0 ? scopeToActiveDialogIfAvailable(native) : null;
    } catch (e) {
      return null;
    }
  };

  // ---------- findClickableElementsNearTitle (行68293-68324) ----------
  ElementMatcher.prototype.findClickableElementsNearTitle = function (container, pattern) {
    try {
      var regex = new RegExp(pattern, "i");
      var titleLikeNodes = Array.from(container.querySelectorAll("*")).filter(function (el) {
        return regex.test(el.textContent);
      });
      if (titleLikeNodes.length === 0) return [];

      var results = [];
      titleLikeNodes.forEach(function (node) {
        Array.from(node.parentElement.children).forEach(function (sibling) {
          if (sibling !== node && DomUtils.isClickable(sibling)) results.push(sibling);
        });
        var next = node.nextElementSibling;
        var count = 1;
        while (next && count <= 5) {
          if (DomUtils.isClickable(next)) results.push(next);
          var nestedButtons = Array.from(next.querySelectorAll('button, [role="button"], .button, [type="button"]'));
          results.push.apply(results, nestedButtons);
          next = next.nextElementSibling;
          count++;
        }
      });
      return Array.from(new Set(results));
    } catch (e) {
      return [];
    }
  };

  // ---------- findButtonsByContainerText (打分排序, 行68326-68419) ----------
  ElementMatcher.prototype.findButtonsByContainerText = function (container, similarText) {
    try {
      if (!container) return [];
      var addKeywords = ["新增", "添加", "新建", "增加", "add", "new", "create", "+"];
      var removeKeywords = ["删除", "移除", "清除", "delete", "remove", "clear", "×", "关闭", "close", "-"];

      var scored = Array.from(
        container.querySelectorAll(
          'button, [role="button"], [class*="btn"], [class*="button"], [class*="add"], a, [onclick], [tabindex], [type="button"]'
        )
      )
        .filter(function (el) {
          var style = window.getComputedStyle(el);
          return style.display !== "none" && style.visibility !== "hidden" && el.offsetWidth > 0 && el.offsetHeight > 0 &&
            DomUtils.isSafeExperienceAddAction(el, container);
        })
        .map(function (el) {
          var score = 0;
          var text = el.textContent.trim();
          var html = el.outerHTML;

          if (text) {
            if (addKeywords.some(function (k) { return text.toLowerCase().includes(k.toLowerCase()); })) score += 15;
            if (similarText && DomUtils.isSimilarText(text, similarText)) score += 5;
            if (removeKeywords.some(function (k) { return text.toLowerCase().includes(k.toLowerCase()); })) score -= 20;
          }

          if (
            html.includes("+") ||
            html.includes("add") ||
            html.includes("plus") ||
            html.includes("AddOutlined") ||
            el.querySelector('i.fa-plus, i.icon-plus, svg[data-icon*="add"], svg[data-icon*="Add"], svg[data-icon*="plus"], svg[data-icon*="Plus"]')
          ) {
            score += 15;
          }

          var svgPaths = Array.from(el.querySelectorAll("svg path"));
          for (var i = 0; i < svgPaths.length; i++) {
            var d = svgPaths[i].getAttribute("d");
            if (d && (d.includes("M12 2a1 1 0 0 0-1 1v8H3a1") || (d.includes("M12") && d.includes("V3a1 1 0 0 0-1-1")))) {
              score += 20;
              break;
            }
          }

          if (
            html.includes("×") ||
            html.includes("✖") ||
            html.includes("&times;") ||
            html.includes("trash") ||
            html.includes("delete") ||
            html.includes("remove") ||
            el.querySelector(
              'i.fa-times, i.fa-trash, i.icon-trash, svg[data-icon*="delete"], svg[data-icon*="Delete"], svg[data-icon*="trash"], svg[data-icon*="Trash"], svg[data-icon*="close"], svg[data-icon*="Close"]'
            )
          ) {
            score -= 15;
          }

          if (el.tagName === "BUTTON") {
            score += 10;
          } else if (el.getAttribute("role") === "button") {
            score += 5;
          }
          if (el.getAttribute("type") === "button") score += 3;
          if (window.getComputedStyle(el).cursor === "pointer") score += 3;

          var classText = Array.from(el.classList).join(" ").toLowerCase();
          if (classText.includes("delete") || classText.includes("remove") || classText.includes("trash") || classText.includes("danger") || classText.includes("close")) {
            score -= 10;
          }
          if (classText.includes("right") || window.getComputedStyle(el).float === "right") score += 3;

          return { element: el, score: score, text: text || "[无文本]", html: html.substring(0, 100) };
        })
        .filter(function (c) {
          return c.score > 0;
        })
        .sort(function (a, b) {
          return b.score - a.score;
        });

      if (scored.length > 0) {
        var topScore = scored[0].score;
        return scored
          .filter(function (c) {
            return c.score >= topScore - 2;
          })
          .map(function (c) {
            return c.element;
          });
      }
      return [];
    } catch (e) {
      return [];
    }
  };

  // ---------- findAddButton (精确匹配, 原为生成器, 行68421-68473) ----------
  ElementMatcher.prototype.findAddButton = async function (container, titleEl, fallbackPattern) {
    try {
      var buttons = this.findButton("add", container);
      buttons = Array.from(buttons || []).filter(function (btn) {
        return DomUtils.isSafeExperienceAddAction(btn, container);
      });
      if (!buttons || buttons.length === 0) {
        return this.findButtonsByContainerText(container, fallbackPattern);
      }

      var titleText = this.getTitleValue(titleEl).trim();
      var byTitle = Array.from(buttons).filter(function (btn) {
        var text = btn.textContent.trim();
        return text && DomUtils.isSimilarText(text, titleText);
      });
      if (byTitle.length > 0) return byTitle;

      var keywords = ["新增", "添加", "新建", "增加", "add", "new", "create"];
      var byKeyword = Array.from(buttons).filter(function (btn) {
        var text = btn.textContent.trim();
        return keywords.some(function (k) {
          return text.includes(k);
        });
      });
      if (byKeyword.length > 0) return byKeyword;

      return buttons;
    } catch (e) {
      return null;
    }
  };

  // ---------- findAddButtonByAlternativeMethods (备用方案, 原为生成器, 行68475-68557) ----------
  ElementMatcher.prototype.findAddButtonByAlternativeMethods = async function (container, fallbackPattern) {
    try {
      var iconSelectors = [
        'svg[data-icon="plus-circle"]', 'svg[data-icon="plus"]', "svg.add-icon", "i.fa-plus",
        "i.fa-plus-circle", "i.el-icon-plus", "i.icon-plus", ".anticon-plus", ".anticon-plus-circle",
      ];
      for (var i = 0; i < iconSelectors.length; i++) {
        var found = container.querySelectorAll(iconSelectors[i]);
        if (found.length > 0) {
          var iconButtons = Array.from(found).map(function (iconEl) {
            var cur = iconEl;
            for (var depth = 0; depth < 4 && cur; depth++) {
              if (
                cur.tagName.toLowerCase() === "button" ||
                cur.getAttribute("role") === "button" ||
                cur.classList.contains("button") ||
                cur.getAttribute("type") === "button"
              ) {
                return cur;
              }
              cur = cur.parentElement;
            }
            return cur || iconEl;
          }).filter(function (candidate) {
            return DomUtils.isSafeExperienceAddAction(candidate, container);
          });
          if (iconButtons.length) return iconButtons;
        }
      }

      var classSelectors = [
        ".add-button", ".add-btn", ".add-icon", ".add-new", ".btn-add", ".btn-new", ".create-button",
        ".create-btn", ".ant-btn-primary", ".el-button--primary", ".el-button", ".ant-btn", ".ui-button",
        ".add", ".new",
      ];
      for (var j = 0; j < classSelectors.length; j++) {
        var byClass = container.querySelectorAll(classSelectors[j]);
        if (byClass.length > 0) {
          var safeByClass = Array.from(byClass).filter(function (candidate) {
            return DomUtils.isSafeExperienceAddAction(candidate, container);
          });
          if (safeByClass.length) return safeByClass;
        }
      }

      var nearTitle = this.findClickableElementsNearTitle(container, fallbackPattern);
      nearTitle = Array.from(nearTitle || []).filter(function (candidate) {
        return DomUtils.isSafeExperienceAddAction(candidate, container);
      });
      if (nearTitle.length > 0) return nearTitle;

      return null;
    } catch (e) {
      return null;
    }
  };

  // ---------- getTitleValue (行68558-68568) ----------
  ElementMatcher.prototype.getTitleValue = function (el) {
    var tag = el && el.tagName ? el.tagName.toLowerCase() : "";
    if (tag === "input" || tag === "textarea") return el.value;
    return el ? el.textContent : "";
  };

  // ---------- 静态 hasClassSubstring (行68570-68577) ----------
  // 与 AF.DomUtils.hasClassSubstring 完全相同的实现，直接委托，不重复维护。
  ElementMatcher.hasClassSubstring = DomUtils.hasClassSubstring;

  // ============================================================
  // Shadow DOM 遍历辅助 (源码独立的 fe 类, 行69245-69333)
  // 按任务书要求并入 ElementMatcher 统一暴露。
  // ============================================================

  // ---------- findElement: 单个元素查找, 递归穿透 shadowRoot (行69255-69274) ----------
  ElementMatcher.prototype.findElement = function (selector, root) {
    root = root || document;
    try {
      var direct = root.querySelector(selector);
      if (direct && !(direct.closest && direct.closest(EXTENSION_UI_SELECTOR))) return direct;
      var walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, null, false);
      var node;
      while ((node = walker.nextNode())) {
        if (node.shadowRoot) {
          var inShadow = node.shadowRoot.querySelector(selector);
          if (inShadow) return inShadow;
          var deep = this.findElement(selector, node.shadowRoot);
          if (deep) return deep;
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  };

  // ---------- findAllElements: 全部元素查找, 递归穿透 shadowRoot (行69276-69296) ----------
  ElementMatcher.prototype.findAllElements = function (selector, root) {
    root = root || document;
    try {
      var results = [];
      var direct = recruitmentNodes(root.querySelectorAll(selector));
      if (direct.length > 0) results.push.apply(results, direct);

      var walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, null, false);
      var node;
      while ((node = walker.nextNode())) {
        if (node.shadowRoot) {
          var inShadow = node.shadowRoot.querySelectorAll(selector);
          if (inShadow.length > 0) results.push.apply(results, Array.from(inShadow));
          var deep = this.findAllElements(selector, node.shadowRoot);
          if (deep.length > 0) results.push.apply(results, deep);
        }
      }
      return results;
    } catch (e) {
      return [];
    }
  };

  // ---------- findClosestElement: 从候选集合里找离参照元素最近的一个 (行69298-69323) ----------
  ElementMatcher.prototype.findClosestElement = function (candidates, referenceEl) {
    try {
      var best = null;
      var bestDistance = Infinity;
      Array.from(candidates).forEach(function (candidate) {
        if (referenceEl.contains(candidate) || candidate.contains(referenceEl)) {
          var r1 = referenceEl.getBoundingClientRect();
          var r2 = candidate.getBoundingClientRect();
          var distance = Math.abs(r1.top - r2.top) + Math.abs(r1.left - r2.left);
          if (distance < bestDistance) {
            bestDistance = distance;
            best = candidate;
          }
        }
      });
      return best;
    } catch (e) {
      return null;
    }
  };

  // ---------- isElementVisible: 委托 AF.DomUtils, 不重复实现 (行69325-69332 的简化版重复实现在此去除) ----------
  ElementMatcher.prototype.isElementVisible = function (el) {
    return DomUtils.isElementVisible(el);
  };

  AF.ElementMatcher = ElementMatcher;
})();
