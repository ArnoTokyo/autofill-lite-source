"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const workflow = fs.readFileSync(path.join(root, "autofill-plugin", "content", "special-site-workflow.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const preload = fs.readFileSync(path.join(root, "ui-preload.js"), "utf8");
const renderer = fs.readFileSync(path.join(root, "renderer.js"), "utf8");
const index = fs.readFileSync(path.join(root, "index.html"), "utf8");
const adapter = fs.readFileSync(path.join(root, "profile-adapter.js"), "utf8");

assert(workflow.includes("function analyzedEditorProbeSectionAliases"), "section add probe needs semantic text aliases");
assert(workflow.includes('base.replace(/其他/g, "其它")'), "其他资格 must accept 其它资格 add text");
assert(workflow.includes("async function runAnalyzedResumeSectionPreviewBatch"), "batch preview runtime missing");
assert(workflow.includes("analyzedBatchPreviewRestoreControls"), "batch preview must restore controls before leaving editor");
assert(workflow.includes("runAnalyzedSectionAddEditorProbe({ section: other"), "other qualification should be probed in same batch");
assert(workflow.includes("runAnalyzedResumeSectionPreviewBatch: runAnalyzedResumeSectionPreviewBatch"), "batch preview runtime must be exported");

const batchStart = workflow.indexOf("async function runAnalyzedResumeSectionPreviewBatch");
const batchEnd = workflow.indexOf("function analyzedEducationPreviewNormalizeProvince", batchStart);
const batchSource = workflow.slice(batchStart, batchEnd);
assert(!batchSource.includes("findExplicitSectionSaveButton"), "batch preview must not resolve save controls");
assert(!batchSource.includes("saveClickDispatched"), "batch preview must not save records");
assert(batchSource.includes("safety: { valuesCaptured: false"), "batch preview diagnostics must not capture values");

assert(main.includes('ipcMain.handle("lite:preview-resume-sections"'), "main preview handler missing");
assert(main.includes('kind: "resume_section_preview_batch"'), "batch preview diagnostic kind missing");
assert(preload.includes("previewResumeSections"), "preload API missing");
assert(renderer.includes("previewResumeSections"), "renderer action missing");
assert(!index.includes('id="multiSectionPreview"'), "Build160 removes the manual batch-preview toolbar entry");
assert(!index.includes('id="experimentMenu"'), "Build160 removes the development experiment submenu");
assert(adapter.includes('communicationAddress: "通讯地址"'), "canonical profile should expose communication address");
assert(adapter.includes('mailingAddress: "通讯地址"'), "canonical profile should expose mailing address alias");
console.log("multi-section preview batch test: PASS");
