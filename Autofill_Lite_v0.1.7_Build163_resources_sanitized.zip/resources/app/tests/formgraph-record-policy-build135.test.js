"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const coreSource = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-core.js"), "utf8");

const buildMatch = main.match(/const BUILD_ID = "([^"]+)";/);
assert(buildMatch && Number((buildMatch[1].match(/-(\d+)$/) || [])[1] || 0) >= 135, "A: current numeric Build must be >=135");
assert(coreSource.includes('FORM_RECORD_POLICY_VERSION = 2'), "B: record recovery policy version missing");
assert(coreSource.includes('clearFormRecordLedger'), "B: record ledger clear API missing");
assert(coreSource.includes('Build135 migration barrier'), "B: legacy record-state migration barrier missing");

const store = {};
const sandbox = {
  window: { AF: {}, location: { hostname: "app.mokahr.com", pathname: "/campus-recruitment/muyuan/70116", hash: "#/candidateHome/resume" } },
  chrome: {
    storage: { local: {
      get(keys, cb) { const out = {}; keys.forEach(k => { if (Object.prototype.hasOwnProperty.call(store, k)) out[k] = store[k]; }); cb(out); },
      set(payload, cb) { Object.assign(store, payload); cb && cb(); },
      remove(keys, cb) { keys.forEach(k => delete store[k]); cb && cb(); }
    } },
    runtime: { lastError: null }
  },
  console, Date, Math, Promise, Set, setTimeout, clearTimeout
};
vm.createContext(sandbox);
vm.runInContext(coreSource, sandbox, { filename: "checkpoint-core.js" });
const core = sandbox.window.AF.CheckpointCore;

(async () => {
  const loc = sandbox.window.location;
  const row1 = { company: "公司A", position: "实习生", startTime: "示例资料", endTime: "2025-02" };
  const meta1 = { category: "示例资料Experience", sectionTitle: "示例资料", 示例资料Index: 0, 示例资料Total: 3, row: row1, recordFingerprint: core.recordFingerprint(row1) };
  const token1 = core.formRecordToken(meta1);

  // Simulate Build133/134 storage that caused fresh Moka pages to skip 示例资料/示例资料.
  store[core.FORM_RECORD_CHECKPOINT_STORAGE_KEY] = {
    version: 1,
    acknowledgeOnRerun: true,
    granularity: "record",
    示例资料flowId: "autofill-core-formgraph-v1",
    hostname: loc.hostname,
    routeKey: core.routeKey(loc),
    recordToken: token1,
    completedRecordTokens: [token1],
    status: "waiting_recovery",
    updatedAt: Date.now()
  };
  store[core.FORM_RECORD_LEDGER_STORAGE_KEY] = {
    version: 1,
    granularity: "record",
    observeOnly: false,
    示例资料flowId: "autofill-core-formgraph-v1",
    hostname: loc.hostname,
    routeKey: core.routeKey(loc),
    completedRecordTokens: [token1, "stale-token"],
    updatedAt: Date.now()
  };

  const legacy = await core.loadFormRecordCheckpoint(loc);
  assert.strictEqual(legacy, null, "C: legacy Build133/134 record checkpoint must be invalidated");
  assert.strictEqual(store[core.FORM_RECORD_CHECKPOINT_STORAGE_KEY], undefined, "C: legacy checkpoint storage must be cleared");
  assert.strictEqual(store[core.FORM_RECORD_LEDGER_STORAGE_KEY], undefined, "C: legacy record ledger must be cleared atomically");

  const fresh = await core.beginFormRecordRun(loc);
  assert.strictEqual(fresh.resumed, false, "D: post-migration run must start fresh");
  assert.strictEqual(fresh.shouldSkip(meta1), false, "D: stale completed token must not skip a fresh Moka record");
  assert.strictEqual(core.snapshotFormRecordRuntime(fresh).ledger.completedRecordCount, 0, "D: fresh record ledger must start empty");

  // New policy checkpoints must still preserve the intended user-ack recovery chain.
  await fresh.pause(meta1, "真实人工处理点");
  const marker = await core.loadFormRecordCheckpoint(loc);
  assert(marker && marker.version === 2 && marker.policyVersion === 2, "E: new record checkpoint must use policy v2");
  const resumed = await core.beginFormRecordRun(loc, { preserveExistingLedger: true });
  assert.strictEqual(resumed.resumed, true, "E: v2 record checkpoint should resume");
  assert.strictEqual(resumed.shouldSkip(meta1), true, "E: user-acknowledged v2 record should skip inside the same recovery chain");
  console.log("formgraph-record-policy-build135.test.js passed (A-E)");
})().catch(err => { console.error(err); process.exit(1); });
