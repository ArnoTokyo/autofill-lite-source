// content/site-analysis-collector.js
// Local-only, privacy-preserving site structure collector for Autofill Lite.
// It never fills fields and never clicks add/save/submit/apply/delete/upload actions.
(function () {
  "use strict";

  var AF = (window.AF = window.AF || {});
  var VERSION = "2.2.0";
  var MODULE_TITLE_PATTERN = /示例资料|基础信息|个人信息|个人资料|示例资料|意向信息|示例资料|教育背景|学习经历|外语水平|示例资料|语言能力|语言情况|通讯信息|联系信息|联系方式|示例资料|示例资料|实习工作|入伍经历|工作\/示例资料|实习\/工作\/入伍经历|工作\/实习\/入伍经历|项目经历|项目经验|校园经历|校园活动|校内活动|学生工作|社会实践|示例资料|奖励情况|获奖信息|获奖情况|获奖|荣誉|证书|资格证书|其他资格|技能|示例资料|家庭成员|亲属|自我评价|自我介绍|示例资料|附加信息|附件|论文|科研/;
  var NAV_SECTION_TEXT_PATTERN = /^(?:示例资料|基础信息|个人信息|个人资料|示例资料|意向信息|示例资料|教育背景|学习经历|外语水平|示例资料|语言能力|语言情况|通讯信息|联系信息|联系方式|示例资料|示例资料|实习工作|入伍经历|工作\/示例资料|实习\/工作\/入伍经历|工作\/实习\/入伍经历|项目经历|项目经验|校园经历|校园活动|校内活动|学生工作|社会实践|示例资料|奖励情况|获奖信息|获奖情况|荣誉(?:信息|情况)?|证书(?:信息|情况)?|资格证书|其他资格|专业技能|计算机技能|技能特长|示例资料|家庭成员|亲属(?:信息|情况)?|自我评价|自我介绍|示例资料|附加信息|附件(?:信息)?|论文|科研(?:经历|项目)?)$/;
  var CONTROL_SELECTOR = [
    "input:not([type='hidden']):not([type='file'])",
    "textarea",
    "select",
    "[contenteditable='true']",
    "[contenteditable='']",
    "[role='textbox']",
    "[role='combobox']",
    "[role='radio']",
    "[role='checkbox']"
  ].join(",");
  var STRUCTURAL_LABEL_SELECTOR = [
    ".el-form-item__label",
    ".ant-form-item-label",
    ".ant-form-item-label > label",
    ".layui-form-label",
    ".form-item__text",
    ".form-label",
    ".control-label",
    "[data-label]"
  ].join(",");
  var SECTION_TITLE_SELECTOR = [
    "h1", "h2", "h3", "h4", "h5", "h6",
    ".resume-module-header .title",
    ".module-title", ".section-title", ".card-title", ".block-title", ".panel-title",
    ".createResume-main-inner-box-top .title",
    "[data-section-title]", "[class*='module-title']", "[class*='section-title']",
    "[class*='Title']", "[class*='title']"
  ].join(",");
  var NAV_SELECTOR = [
    "nav a", "nav [role='tab']", "nav [role='menuitem']",
    "[role='tab']", ".el-tabs__item", ".ant-tabs-tab",
    ".resume-nav li", ".resume-menu li",
    "aside a", "aside li",
    "[class*='sidebar'] a", "[class*='sidebar'] li",
    "[class*='side-bar'] a", "[class*='side-bar'] li",
    "[class*='catalog'] a", "[class*='catalog'] li",
    "[class*='anchor'] a", "[class*='anchor'] li",
    "[class*='step'] [role='tab']", "[class*='step'] li",
    "[class*='menu'] a", "[class*='menu'] [role='menuitem']",
    "[class*='menu'] li", "[class*='nav'] a", "[class*='nav'] li"
  ].join(",");

  function normalizeText(value, max) {
    var text = String(value || "").replace(/\s+/g, " ").trim();
    return text.slice(0, Number(max || 120));
  }

  function uniqueTexts(values, maxItems) {
    var result = [];
    (values || []).forEach(function (value) {
      var text = normalizeText(value, 120);
      if (!text || result.indexOf(text) >= 0) return;
      result.push(text);
    });
    return result.slice(0, Number(maxItems || 12));
  }

  function isVisible(element) {
    if (!element || !element.isConnected) return false;
    try {
      var style = window.getComputedStyle(element);
      if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) return false;
      var rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    } catch (_) {
      return false;
    }
  }

  function rectOf(element) {
    try {
      var rect = element.getBoundingClientRect();
      return {
        x: Math.round(rect.left),
        y: Math.round(rect.top),
        width: Math.round(rect.width),
        height: Math.round(rect.height)
      };
    } catch (_) {
      return { x: 0, y: 0, width: 0, height: 0 };
    }
  }

  function safeAttr(value, max) {
    var text = normalizeText(value, max || 100);
    if (!text) return "";
    if (/https?:\/\//i.test(text)) {
      try {
        var u = new URL(text, location.href);
        return u.protocol + "//" + u.host + u.pathname;
      } catch (_) {
        return text.split(/[?#]/)[0];
      }
    }
    return text;
  }

  function safePath(value) {
    var text = normalizeText(value, 220);
    if (!text) return "";
    try {
      var u = new URL(text, location.href);
      return u.pathname || "/";
    } catch (_) {
      return text.split(/[?#]/)[0];
    }
  }

  function safeActionText(value) {
    var text = normalizeText(value, 30);
    if (!text) return "";
    var match = text.match(/编辑|修改|完善|展开|继续填写|补充信息|取消|关闭|收起|添加|新增|新建|增加|创建|Edit/i);
    return match ? match[0] : "";
  }

  function cssEscape(value) {
    if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(value);
    return String(value || "").replace(/([ #;?%&,.+*~':"!^$[\]()=>|\/@])/g, "\\$1");
  }

  function acceptableId(value) {
    var id = normalizeText(value, 90);
    if (!id || id.length > 90) return false;
    if (/\b(token|session|credential|authorization|cookie)\b/i.test(id)) return false;
    if (/^[0-9a-f]{20,}$/i.test(id) || /\d{10,}/.test(id)) return false;
    return /^[A-Za-z_][A-Za-z0-9_:\-.]*$/.test(id);
  }

  function safeClassList(element) {
    return Array.from(element && element.classList || []).filter(function (cls) {
      return cls && cls.length <= 36 &&
        !/active|selected|focus|error|hover|disabled|open|^css-|^[a-f0-9]{8,}$/i.test(cls) &&
        !/^(?:on)$/i.test(cls) &&
        /^[A-Za-z_-][A-Za-z0-9_-]*$/.test(cls);
    });
  }

  function selectorCount(selector, root) {
    if (!selector) return 0;
    try { return (root || document).querySelectorAll(selector).length; }
    catch (_) { return 0; }
  }

  function attrSelector(tag, attr, value) {
    if (!value || /[\r\n<>]/.test(value)) return "";
    var escaped = String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    return tag + "[" + attr + "=\"" + escaped + "\"]";
  }

  function ancestrySelector(element) {
    if (!element || element.nodeType !== 1) return "";
    var parts = [];
    var current = element;
    for (var depth = 0; current && current.nodeType === 1 && depth < 5; depth++, current = current.parentElement) {
      if (acceptableId(current.id)) {
        parts.unshift("#" + cssEscape(current.id));
        break;
      }
      var tag = String(current.tagName || "").toLowerCase() || "*";
      var classes = safeClassList(current).slice(0, 2);
      var part = tag + classes.map(function (cls) { return "." + cssEscape(cls); }).join("");
      var parent = current.parentElement;
      if (parent) {
        var siblings = Array.from(parent.children || []).filter(function (node) { return node.tagName === current.tagName; });
        if (siblings.length > 1) part += ":nth-of-type(" + (siblings.indexOf(current) + 1) + ")";
      }
      parts.unshift(part);
      var candidate = parts.join(" > ");
      if (selectorCount(candidate, document) === 1) return candidate.slice(0, 260);
    }
    return parts.join(" > ").slice(0, 260);
  }

  function selectorCandidates(element) {
    if (!element || element.nodeType !== 1) return [];
    var tag = String(element.tagName || "").toLowerCase() || "*";
    var candidates = [];
    function push(selector, kind) {
      if (!selector || candidates.some(function (item) { return item.selector === selector; })) return;
      candidates.push({ selector: selector.slice(0, 260), hitCount: selectorCount(selector, document), kind: kind || "css" });
    }
    if (acceptableId(element.id)) push("#" + cssEscape(element.id), "id");
    var name = safeAttr(element.getAttribute && element.getAttribute("name"), 80);
    if (name && !/[\s<>"']/g.test(name)) push(attrSelector(tag, "name", name), "name");
    var testId = safeAttr(element.getAttribute && (element.getAttribute("data-testid") || element.getAttribute("data-test") || element.getAttribute("data-qa")), 80);
    if (testId) {
      if (element.getAttribute("data-testid")) push(attrSelector(tag, "data-testid", testId), "data-testid");
      else if (element.getAttribute("data-test")) push(attrSelector(tag, "data-test", testId), "data-test");
      else push(attrSelector(tag, "data-qa", testId), "data-qa");
    }
    var aria = safeAttr(element.getAttribute && element.getAttribute("aria-label"), 80);
    if (aria) push(attrSelector(tag, "aria-label", aria), "aria-label");
    var placeholder = safeAttr(element.getAttribute && element.getAttribute("placeholder"), 100);
    if (placeholder && placeholder.length <= 80) push(attrSelector(tag, "placeholder", placeholder), "placeholder");
    var classes = safeClassList(element).slice(0, 3);
    if (classes.length) push(tag + classes.map(function (cls) { return "." + cssEscape(cls); }).join(""), "class");
    push(ancestrySelector(element), "ancestry");
    return candidates.slice(0, 8);
  }

  function bestSelector(element) {
    var candidates = selectorCandidates(element);
    var unique = candidates.find(function (item) { return item.hitCount === 1; });
    return {
      selectorHint: unique ? unique.selector : (candidates[0] && candidates[0].selector || ""),
      selectorHitCount: unique ? 1 : Number(candidates[0] && candidates[0].hitCount || 0),
      selectorCandidates: candidates
    };
  }

  function closestWidget(element) {
    if (!element || !element.closest) return { type: "", element: element, 示例资料: "native" };
    var specs = [
      [".el-date-editor", "element-date", "element"],
      [".el-cascader", "element-cascader", "element"],
      [".el-select", "element-select", "element"],
      [".el-autocomplete", "element-autocomplete", "element"],
      [".el-radio-group", "element-radio-group", "element"],
      [".el-checkbox-group", "element-checkbox-group", "element"],
      [".ant-picker", "ant-date", "ant"],
      [".ant-select", "ant-select", "ant"],
      [".ant-cascader-picker", "ant-cascader", "ant"],
      [".ant-radio-group", "ant-radio-group", "ant"],
      [".ant-checkbox-group", "ant-checkbox-group", "ant"],
      [".ivu-date-picker", "iview-date", "iview"],
      [".ivu-select", "iview-select", "iview"],
      [".layui-form-select", "layui-select", "layui"]
    ];
    for (var i = 0; i < specs.length; i++) {
      var node = null;
      try { node = element.closest(specs[i][0]); } catch (_) {}
      if (node && isVisible(node)) return { type: specs[i][1], element: node, 示例资料: specs[i][2] };
    }
    return { type: "", element: element, 示例资料: "native" };
  }

  function controlType(element, widget) {
    widget = widget || closestWidget(element);
    if (widget.type) {
      var inputType = String(element.getAttribute && element.getAttribute("type") || "").toLowerCase();
      var roleType = String(element.getAttribute && element.getAttribute("role") || "").toLowerCase();
      var className = String(element.className || "");
      if ((widget.type === "element-radio-group" || widget.type === "ant-radio-group") &&
          (inputType === "radio" || roleType === "radio" || /(^|\s)(el-radio|ant-radio-wrapper)(\s|$)/.test(className))) return "radio";
      if ((widget.type === "element-checkbox-group" || widget.type === "ant-checkbox-group") &&
          (inputType === "checkbox" || roleType === "checkbox" || /(^|\s)(el-checkbox|ant-checkbox-wrapper)(\s|$)/.test(className))) return "checkbox";
      return widget.type;
    }
    var tag = String(element.tagName || "").toLowerCase();
    var type = String(element.getAttribute && element.getAttribute("type") || "").toLowerCase();
    var role = String(element.getAttribute && element.getAttribute("role") || "").toLowerCase();
    if (tag === "select") return "native-select";
    if (tag === "textarea") return "textarea";
    if (element.getAttribute && element.getAttribute("contenteditable") != null) return "contenteditable";
    if (role === "combobox") return "combobox";
    if (role === "radio" || type === "radio") return "radio";
    if (role === "checkbox" || type === "checkbox") return "checkbox";
    if (/date|month|time/.test(type)) return type;
    return "text";
  }

  function closestFieldContainer(element, root) {
    var selectors = [
      ".el-form-item", ".ant-form-item", ".layui-form-item", ".ud-formily-item",
      ".form-item", ".form-group", "[class*='form-item']", "[class*='FormItem']",
      "td", "li"
    ];
    for (var i = 0; i < selectors.length; i++) {
      var node = element.closest && element.closest(selectors[i]);
      if (node && (!root || root.contains(node))) return node;
    }
    var parent = element.parentElement;
    for (var depth = 0; parent && parent !== root && depth < 4; depth++, parent = parent.parentElement) {
      var count = 0;
      try { count = parent.querySelectorAll(CONTROL_SELECTOR).length; } catch (_) {}
      if (count > 0 && count <= 4) return parent;
    }
    return element.parentElement || root || document.body;
  }

  function textOnlyNode(node) {
    if (!node || !isVisible(node)) return "";
    try {
      if (node.matches && node.matches(CONTROL_SELECTOR)) return "";
      if (node.querySelector && node.querySelector(CONTROL_SELECTOR)) return "";
    } catch (_) {}
    var text = normalizeText(node.textContent || node.getAttribute && node.getAttribute("data-label"), 90);
    if (!text || text.length > 90) return "";
    return text;
  }

  function explicitLabelFor(element, root) {
    var id = acceptableId(element.id) ? element.id : "";
    if (!id) return "";
    try {
      var explicit = (root || document).querySelector('label[for="' + cssEscape(id) + '"]');
      return explicit && isVisible(explicit) ? normalizeText(explicit.textContent, 90) : "";
    } catch (_) { return ""; }
  }

  function structuralLabelFor(element, root, container) {
    if (!container) return "";
    var labels = [];
    try { labels = Array.from(container.querySelectorAll(STRUCTURAL_LABEL_SELECTOR)).filter(isVisible); } catch (_) {}
    for (var i = 0; i < labels.length; i++) {
      var text = normalizeText(labels[i].textContent || labels[i].getAttribute("data-label"), 90);
      if (text) return text;
    }
    // Generic <label> is only trusted when it explicitly owns this element or is
    // not it示例资料 a radio/checkbox option. This prevents option text such as “男”
    // from becoming the semantic label of every field in the same form block.
    try {
      var generic = Array.from(container.querySelectorAll("label")).filter(isVisible);
      for (var j = 0; j < generic.length; j++) {
        var owned = generic[j].getAttribute("for");
        var hasChoice = !!generic[j].querySelector("input[type='radio'],input[type='checkbox'],[role='radio'],[role='checkbox']");
        if (owned && element.id && owned === element.id) return normalizeText(generic[j].textContent, 90);
        if (!hasChoice && generic[j].contains(element)) {
          var innerText = normalizeText(generic[j].textContent, 90);
          if (innerText) return innerText;
        }
      }
    } catch (_) {}
    return "";
  }

  function nearbyTextCandidates(element, container) {
    var values = [];
    var prev = element.previousElementSibling;
    for (var i = 0; prev && i < 3; i++, prev = prev.previousElementSibling) {
      values.push(textOnlyNode(prev));
    }
    if (container) {
      try {
        Array.from(container.children || []).slice(0, 12).forEach(function (child) {
          if (child === element || (child.contains && child.contains(element))) return;
          values.push(textOnlyNode(child));
        });
      } catch (_) {}
    }
    return uniqueTexts(values.filter(Boolean), 6);
  }

  function semanticSignals(element, root, container) {
    var explicitLabel = explicitLabelFor(element, root);
    var formItemLabel = structuralLabelFor(element, root, container);
    var ariaLabel = safeAttr(element.getAttribute && element.getAttribute("aria-label"), 90);
    var placeholder = safeAttr(element.getAttribute && element.getAttribute("placeholder"), 100);
    var name = safeAttr(element.getAttribute && element.getAttribute("name"), 80);
    var id = acceptableId(element.id) ? safeAttr(element.id, 80) : "";
    var nearby = nearbyTextCandidates(element, container);
    var preferredPlaceholder = placeholder && !/^(请选择|请输入|选择|填写)$/.test(placeholder) ? placeholder : "";
    var label = explicitLabel || formItemLabel || ariaLabel || preferredPlaceholder || nearby[0] || "";
    var labelSource = explicitLabel ? "explicit_label"
      : formItemLabel ? "form_item_label"
      : ariaLabel ? "aria_label"
      : preferredPlaceholder ? "placeholder"
      : nearby[0] ? "nearby_text"
      : "";
    var safeSemanticCandidates = uniqueTexts([explicitLabel, formItemLabel, ariaLabel, preferredPlaceholder, name, id], 10);
    return {
      label: label,
      labelSource: labelSource,
      explicitLabel: explicitLabel,
      formItemLabel: formItemLabel,
      ariaLabel: ariaLabel,
      placeholder: placeholder,
      name: name,
      id: id,
      nearbyTextCandidates: nearby,
      safeSemanticCandidates: safeSemanticCandidates,
      semanticCandidates: uniqueTexts(safeSemanticCandidates.concat(nearby), 12)
    };
  }

  function collectSectionTitles(root) {
    var list = [];
    try {
      list = Array.from((root || document).querySelectorAll(SECTION_TITLE_SELECTOR)).filter(isVisible).map(function (node) {
        return { node: node, text: normalizeText(node.textContent, 60), rect: rectOf(node) };
      }).filter(function (item) {
        return item.text && item.text.length <= 60 && MODULE_TITLE_PATTERN.test(item.text);
      });
    } catch (_) {}
    return list.slice(0, 160);
  }

  function titlePrecedes(titleNode, element) {
    if (!titleNode || !element || titleNode === element) return false;
    try {
      if (typeof Node !== "undefined") {
        return !!(titleNode.compareDocumentPosition(element) & Node.DOCUMENT_POSITION_FOLLOWING);
      }
    } catch (_) {}
    try { return titleNode.getBoundingClientRect().top <= element.getBoundingClientRect().top; }
    catch (_) { return false; }
  }

  function sectionTitleFor(element, root, titles) {
    titles = titles || collectSectionTitles(root || document);
    var elementRect = rectOf(element);
    var candidates = titles.filter(function (item) {
      return titlePrecedes(item.node, element) && item.rect.y <= elementRect.y + 4;
    });
    if (candidates.length) {
      candidates.sort(function (a, b) {
        var ay = Number(a.rect && a.rect.y || 0);
        var by = Number(b.rect && b.rect.y || 0);
        return by - ay;
      });
      return { title: candidates[0].text, evidence: "nearest_preceding_heading" };
    }
    return { title: "当前页面", evidence: "fallback" };
  }

  function optionTexts(element, type, widget) {
    var items = [];
    try {
      if (type === "native-select") {
        items = Array.from(element.options || []).map(function (option) { return normalizeText(option.textContent, 80); });
      } else if (type === "radio" || type === "checkbox") {
        var container = closestFieldContainer(element, document.body) || widget && widget.element || element.parentElement;
        items = Array.from(container.querySelectorAll("label,[role='radio'],[role='checkbox']")).filter(isVisible).map(function (node) {
          return normalizeText(node.textContent || node.getAttribute("aria-label"), 80);
        });
      }
    } catch (_) {}
    return uniqueTexts(items.filter(Boolean), 30);
  }


  function pseudoRequiredMarker(container) {
    if (!container || !container.querySelectorAll) return false;
    var selectors = STRUCTURAL_LABEL_SELECTOR + ",label,[class*='label'],[class*='Label']";
    var nodes = [];
    try { nodes = Array.from(container.querySelectorAll(selectors)).filter(isVisible).slice(0, 24); } catch (_) {}
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      var className = String(node.className || "");
      if (/(^|\s)(required|is-required)(\s|$)|required[-_]/i.test(className)) return true;
      try {
        var before = String(window.getComputedStyle(node, "::before").content || "").replace(/^["']|["']$/g, "");
        var after = String(window.getComputedStyle(node, "::after").content || "").replace(/^["']|["']$/g, "");
        if (/[*＊]|必填|required/i.test(before) || /[*＊]|必填|required/i.test(after)) return true;
      } catch (_) {}
    }
    return false;
  }

  function normalizeSemanticToken(value) {
    return String(value || "")
      .toLowerCase()
      .replace(/[\s\u00a0]+/g, "")
      .replace(/[：:，,。.!！?？、;；·•\-_/\\()（）\[\]【】<>《》“”"'`~+*=＊#]/g, "");
  }

  function stripPromptPrefix(value) {
    var text = normalizeText(value, 180)
      .replace(/^\s*[*＊]+\s*/, "")
      .replace(/^(?:请)?(?:准确)?(?:填写|输入|选择)(?:您(?:的)?|你的|本人)?/i, "")
      .replace(/^(?:请选择|请输入|请填写)/i, "")
      .trim();
    text = text.replace(/[（(](?:至多|最多|单位|例如|示例)[^）)]{0,32}[）)]\s*$/i, "").trim();
    return text;
  }

  function categoryDictionaryContainment(sectionTitle) {
    var dict = AF.FieldDictionary || {};
    var sectionNorm = normalizeSemanticToken(sectionTitle);
    if (!sectionNorm) return null;
    var localAliases = { 示例资料Skills: ["语言情况"] };
    var best = null;
    Object.keys(dict).forEach(function (category) {
      var labels = (dict[category] && dict[category].labels || []).concat(localAliases[category] || []);
      labels.forEach(function (label) {
        var labelNorm = normalizeSemanticToken(label);
        if (!labelNorm || labelNorm.length < 2 || sectionNorm.indexOf(labelNorm) < 0) return;
        var score = labelNorm.length;
        if (!best || score > best.score) best = { category: category, label: label, score: score };
      });
    });
    return best;
  }

  function categoryHintForSection(sectionTitle, matcher) {
    if (!sectionTitle || sectionTitle === "当前页面") {
      return { category: "", source: "", confidence: 0 };
    }
    var containment = categoryDictionaryContainment(sectionTitle);
    if (containment) {
      return {
        category: containment.category,
        source: "dictionary_longest_section_label",
        confidence: 0.99,
        evidence: containment.label
      };
    }
    if (!matcher) return { category: "", source: "", confidence: 0 };
    try {
      if (typeof matcher._findCategoryByExactTitle === "function") {
        var exact = matcher._findCategoryByExactTitle(sectionTitle);
        if (exact) return { category: exact, source: "core_exact_section", confidence: 1, evidence: sectionTitle };
      }
    } catch (_) {}
    try {
      if (typeof matcher.getCategoryByTitleFuzzy === "function") {
        var fuzzy = matcher.getCategoryByTitleFuzzy(sectionTitle);
        if (fuzzy && fuzzy.categoryKey) {
          return {
            category: String(fuzzy.categoryKey || ""),
            source: "core_fuzzy_section",
            confidence: Math.max(0, Math.min(1, Number(fuzzy.score || 0))),
            evidence: sectionTitle
          };
        }
      }
    } catch (_) {}
    return { category: "", source: "", confidence: 0 };
  }

  function dictionaryExactField(category, candidates) {
    var dict = AF.FieldDictionary || {};
    var fields = dict[category] && dict[category].fields;
    if (!fields) return null;
    for (var i = 0; i < candidates.length; i++) {
      var candidate = candidates[i];
      var normalizedCandidate = normalizeSemanticToken(stripPromptPrefix(candidate));
      if (!normalizedCandidate) continue;
      var keys = Object.keys(fields);
      for (var k = 0; k < keys.length; k++) {
        var fieldKey = keys[k];
        var aliases = Array.isArray(fields[fieldKey]) ? fields[fieldKey] : [];
        for (var a = 0; a < aliases.length; a++) {
          var normalizedAlias = normalizeSemanticToken(stripPromptPrefix(aliases[a]));
          if (normalizedAlias && normalizedAlias === normalizedCandidate) {
            return { fieldKey: fieldKey, evidence: candidate, method: "dictionary_exact_alias", confidence: 1, status: "trusted", reasons: [] };
          }
        }
      }
    }
    return null;
  }

  function isBooleanStyleKey(fieldKey) {
    return /^(?:is|has|was|accept|allow|obey|can|need|cityFlexible|overseasMigration|secondDegreeOrMinor)/i.test(String(fieldKey || ""));
  }

  function fieldMappingHint(matcher, category, signals) {
    if (!category) {
      return { fieldKey: "", evidence: "", method: "", confidence: 0, status: "unmapped", reasons: ["category_unresolved"] };
    }
    var candidates = uniqueTexts(
      [signals && signals.explicitLabel, signals && signals.formItemLabel, signals && signals.ariaLabel]
        .concat(signals && signals.safeSemanticCandidates || []),
      16
    );
    var exact = dictionaryExactField(category, candidates);
    if (exact) return exact;
    if (!matcher || typeof matcher.findFieldByCategory !== "function") {
      return { fieldKey: "", evidence: "", method: "", confidence: 0, status: "unmapped", reasons: ["matcher_unavailable"] };
    }
    for (var i = 0; i < candidates.length; i++) {
      try {
        var fieldKey = matcher.findFieldByCategory(category, candidates[i]);
        if (!fieldKey) continue;
        var reasons = ["fuzzy_or_semantic_core_match"];
        var stripped = stripPromptPrefix(candidates[i]);
        if (/^(?:是否|有无|能否|可否)/.test(stripped) && !isBooleanStyleKey(fieldKey)) reasons.push("boolean_question_non_boolean_key");
        return {
          fieldKey: String(fieldKey),
          evidence: candidates[i],
          method: "core_matcher_fallback",
          confidence: 0.45,
          status: "tentative",
          reasons: reasons
        };
      } catch (_) {}
    }
    return { fieldKey: "", evidence: "", method: "", confidence: 0, status: "unmapped", reasons: ["no_safe_semantic_match"] };
  }

  function requiredEvidence(element, signals, container) {
    var evidence = [];
    try { if (element.required) evidence.push("native_required"); } catch (_) {}
    try { if (String(element.getAttribute("aria-required")) === "true") evidence.push("aria_required"); } catch (_) {}
    try {
      var className = String(container && container.className || "");
      if (/(^|\s)is-required(\s|$)|ant-form-item-required|form-item-required/i.test(className)) evidence.push("required_container_class");
    } catch (_) {}
    if (pseudoRequiredMarker(container)) evidence.push("required_visual_marker");
    var labelText = String(signals && (signals.explicitLabel || signals.formItemLabel || signals.label) || "");
    if (/^\s*[*＊]/.test(labelText)) evidence.push("label_star");
    if (/必填|required/i.test(labelText)) evidence.push("label_required_text");
    return uniqueTexts(evidence, 8);
  }

  function scanRoot(root, options) {
    options = options || {};
    var maxControls = Math.max(1, Number(options.maxControls || 240));
    var controls = [];
    var titles = collectSectionTitles(root || document);
    try {
      controls = Array.from((root || document).querySelectorAll(CONTROL_SELECTOR)).filter(function (element) {
        return isVisible(element) && !element.disabled;
      }).slice(0, maxControls);
    } catch (_) {}

    var fields = controls.map(function (element, index) {
      var container = closestFieldContainer(element, root || document.body);
      var widget = closestWidget(element);
      var type = controlType(element, widget);
      var signals = semanticSignals(element, root || document.body, container);
      var section = sectionTitleFor(element, root || document.body, titles);
      var categoryHint = categoryHintForSection(section.title, options.matcher);
      var mappingHint = fieldMappingHint(options.matcher, categoryHint.category, signals);
      var selector = bestSelector(element);
      var widgetSelector = widget.element && widget.element !== element ? bestSelector(widget.element) : null;
      var reqEvidence = requiredEvidence(element, signals, container);
      var currentValuePresent = false;
      try {
        if (type === "checkbox" || type === "radio") currentValuePresent = !!element.checked;
        else currentValuePresent = String(element.value || "").trim().length > 0;
      } catch (_) {}
      return {
        index: index,
        section: section.title,
        sectionEvidence: section.evidence,
        label: signals.label,
        labelSource: signals.labelSource,
        formItemLabel: signals.formItemLabel,
        explicitLabel: signals.explicitLabel,
        ariaLabel: signals.ariaLabel,
        nearbyTextCandidates: signals.nearbyTextCandidates,
        safeSemanticCandidates: signals.safeSemanticCandidates,
        semanticCandidates: signals.semanticCandidates,
        coreCategory: categoryHint.category,
        coreCategorySource: categoryHint.source,
        coreCategoryConfidence: categoryHint.confidence,
        coreCategoryEvidence: categoryHint.evidence || "",
        coreFieldKey: mappingHint.fieldKey,
        coreMappingEvidence: mappingHint.evidence,
        coreMappingMethod: mappingHint.method || "",
        coreMappingConfidence: Number(mappingHint.confidence || 0),
        coreMappingStatus: mappingHint.status || (mappingHint.fieldKey ? "tentative" : "unmapped"),
        coreMappingReasons: mappingHint.reasons || [],
        controlType: type,
        widgetFamily: widget.示例资料,
        tagName: String(element.tagName || "").toLowerCase(),
        inputType: safeAttr(element.getAttribute && element.getAttribute("type"), 30),
        name: signals.name,
        id: signals.id,
        placeholder: signals.placeholder,
        required: reqEvidence.length > 0,
        requiredEvidence: reqEvidence,
        options: optionTexts(element, type, widget),
        selectorHint: selector.selectorHint,
        selectorHitCount: selector.selectorHitCount,
        selectorCandidates: selector.selectorCandidates,
        widgetSelectorHint: widgetSelector && widgetSelector.selectorHint || "",
        widgetSelectorHitCount: widgetSelector && widgetSelector.selectorHitCount || 0,
        rect: rectOf(widget.element || element),
        currentValuePresent: currentValuePresent
      };
    });

    var sectionMap = {};
    fields.forEach(function (field) {
      var key = field.section || "当前页面";
      if (!sectionMap[key]) sectionMap[key] = { title: key, fieldCount: 0, labels: [], controlTypes: [] };
      sectionMap[key].fieldCount += 1;
      if (field.label && sectionMap[key].labels.indexOf(field.label) < 0) sectionMap[key].labels.push(field.label);
      if (field.controlType && sectionMap[key].controlTypes.indexOf(field.controlType) < 0) sectionMap[key].controlTypes.push(field.controlType);
    });
    return {
      controlCount: fields.length,
      labeledControlCount: fields.filter(function (field) { return !!field.label; }).length,
      requiredControlCount: fields.filter(function (field) { return !!field.required; }).length,
      uniqueSelectorCount: fields.filter(function (field) { return Number(field.selectorHitCount || 0) === 1; }).length,
      sections: Object.keys(sectionMap).map(function (key) {
        sectionMap[key].labels = sectionMap[key].labels.slice(0, 80);
        sectionMap[key].controlTypes = sectionMap[key].controlTypes.slice(0, 30);
        return sectionMap[key];
      }),
      fields: fields
    };
  }

  function normalizeNavigationText(value) {
    return normalizeText(value, 80)
      .replace(/^[\s\u2022·●○◆◇▪▫▶▷►▸>]+/, "")
      .replace(/^(?:\d+|[一二三四五六七八九十]+|[IVXivx]+)[、.．)）\-—\s]+/, "")
      .replace(/[：:>›»]+$/, "")
      .trim();
  }

  function isResumeSectionNavigationText(value) {
    var text = normalizeNavigationText(value);
    if (!text || text.length > 40) return false;
    return NAV_SECTION_TEXT_PATTERN.test(text);
  }

  function isNavigationFieldLabel(node) {
    if (!node || !node.matches) return false;
    try {
      if (node.matches("label, .el-form-item__label, .ant-form-item-label, .layui-form-label, .form-label, .control-label, [data-label]")) return true;
      var container = node.closest && node.closest(".el-form-item, .ant-form-item, .layui-form-item, .form-item, .form-group, [class*='form-item']");
      if (container && container.querySelector && container.querySelector(CONTROL_SELECTOR)) return true;
    } catch (_) {}
    return false;
  }

  function navigationActive(node) {
    var current = node;
    for (var depth = 0; current && depth < 3; depth++, current = current.parentElement) {
      var className = String(current.className || "");
      if (/(^|\s)(active|is-active|selected|current|on)(\s|$)/i.test(className)) return true;
      try {
        if (String(current.getAttribute("aria-selected")) === "true" || String(current.getAttribute("aria-current")) === "page") return true;
      } catch (_) {}
    }
    return false;
  }

  function navigationTarget(node, text) {
    if (!node) return null;
    var selector = "a,button,[role='tab'],[role='menuitem'],[onclick],li";
    try {
      if (node.matches && node.matches(selector)) return node;
      var parent = node.closest && node.closest(selector);
      if (parent && normalizeNavigationText(parent.textContent || parent.getAttribute("aria-label") || parent.getAttribute("title")) === text) return parent;
    } catch (_) {}
    return node;
  }

  function navigationClickable(node) {
    if (!node) return false;
    try {
      var tag = String(node.tagName || "").toLowerCase();
      if (tag === "a" || tag === "button") return true;
      var role = String(node.getAttribute && node.getAttribute("role") || "").toLowerCase();
      if (role === "tab" || role === "menuitem" || role === "button") return true;
      if (node.getAttribute && node.getAttribute("onclick")) return true;
      if (node.getAttribute && Number(node.getAttribute("tabindex")) >= 0) return true;
      var style = window.getComputedStyle && window.getComputedStyle(node);
      if (style && String(style.cursor || "").toLowerCase() === "pointer") return true;
    } catch (_) {}
    return false;
  }

  function navigationClusterSize(node) {
    if (!node) return 0;
    var current = node.parentElement;
    for (var depth = 0; current && depth < 3; depth++, current = current.parentElement) {
      var texts = [];
      try {
        Array.from(current.querySelectorAll("a,button,li,div,span,p,[role='tab'],[role='menuitem'],[onclick]"))
          .slice(0, 300)
          .forEach(function (candidate) {
            if (!isVisible(candidate) || isNavigationFieldLabel(candidate)) return;
            var raw = candidate.textContent || candidate.getAttribute && (candidate.getAttribute("aria-label") || candidate.getAttribute("title")) || "";
            var text = normalizeNavigationText(raw);
            if (isResumeSectionNavigationText(text) && texts.indexOf(text) < 0) texts.push(text);
          });
      } catch (_) {}
      if (texts.length >= 3) return texts.length;
    }
    return 0;
  }

  function buildNavigationItem(node, source) {
    if (!node || !isVisible(node) || isNavigationFieldLabel(node)) return null;
    var rawText = node.textContent || node.getAttribute && (node.getAttribute("aria-label") || node.getAttribute("title")) || "";
    var text = normalizeNavigationText(rawText);
    if (!text || text.length < 2 || text.length > 60) return null;
    if (source === "semantic_text_fallback") {
      if (!isResumeSectionNavigationText(text)) return null;
    } else if (!MODULE_TITLE_PATTERN.test(text) && !/简历|基本|个人|教育|实习|项目|获奖|语言|外语|通讯|联系|技能|资格|家庭|自我|附件/.test(text)) {
      return null;
    }

    var target = navigationTarget(node, text) || node;
    var clickable = navigationClickable(target);
    var clusterSize = source === "semantic_text_fallback" ? navigationClusterSize(target) : 0;
    if (source === "semantic_text_fallback" && !clickable && clusterSize < 3) return null;
    var selector = bestSelector(target);
    var href = "";
    try {
      var link = target.closest && target.closest("a[href]");
      href = link && link.getAttribute("href") || "";
    } catch (_) {}
    return {
      text: text,
      active: navigationActive(target),
      role: safeAttr(target.getAttribute && target.getAttribute("role"), 30),
      hrefPath: safePath(href),
      selectorHint: selector.selectorHint,
      selectorHitCount: selector.selectorHitCount,
      source: source || "nav_selector",
      clickable: clickable,
      clusterSize: clusterSize,
      tagName: String(target.tagName || "").toLowerCase(),
      rect: rectOf(target)
    };
  }

  function navigationItemScore(value) {
    var tag = String(value && value.tagName || "").toLowerCase();
    return (value && value.clickable ? 8 : 0) +
      (Number(value && value.selectorHitCount || 0) === 1 ? 4 : 0) +
      (tag === "a" || tag === "button" ? 4 : 0) +
      (Number(value && value.clusterSize || 0) >= 3 ? 3 : 0) +
      (value && value.active ? 2 : 0) +
      (value && value.source === "nav_selector" ? 1 : 0);
  }

  function betterNavigationItem(current, candidate) {
    if (!current) return candidate;
    var currentScore = navigationItemScore(current);
    var candidateScore = navigationItemScore(candidate);
    if (candidateScore !== currentScore) return candidateScore > currentScore ? candidate : current;
    var currentArea = Number(current.rect && current.rect.width || 0) * Number(current.rect && current.rect.height || 0);
    var candidateArea = Number(candidate.rect && candidate.rect.width || 0) * Number(candidate.rect && candidate.rect.height || 0);
    if (candidateArea > 0 && (!currentArea || candidateArea < currentArea)) return candidate;
    return current;
  }

  function canonicalizeNavigationItems(items) {
    items = Array.isArray(items) ? items : [];

    // If a coherent resume-section rail is present, prefer it over global site
    // navigation and over same-named headings inside the form body. A rail
    // candidate must have semantic section text *and* cluster evidence from at
    // least three sibling/nearby resume section names. This remains read-only.
    var railCandidates = items.filter(function (item) {
      return item && item.source === "semantic_text_fallback" &&
        Number(item.clusterSize || 0) >= 3 && isResumeSectionNavigationText(item.text);
    });
    var railTextCount = {};
    railCandidates.forEach(function (item) { railTextCount[item.text] = true; });
    var railTexts = Object.keys(railTextCount);
    if (railTexts.length >= 3) {
      var railGrouped = {};
      var railOrder = [];
      railCandidates.forEach(function (item) {
        if (!railGrouped[item.text]) railOrder.push(item.text);
        railGrouped[item.text] = betterNavigationItem(railGrouped[item.text], item);
      });
      return railOrder.map(function (text) { return railGrouped[text]; }).slice(0, 40);
    }

    // Generic fallback for sites without a recognizable resume rail. Keep href
    // in the identity because the same text can legitimately link to different
    // destinations in global navigation.
    var grouped = {};
    var order = [];
    items.forEach(function (item) {
      var key = item.text + "|" + item.hrefPath;
      if (!grouped[key]) order.push(key);
      grouped[key] = betterNavigationItem(grouped[key], item);
    });
    return order.map(function (key) { return grouped[key]; }).slice(0, 100);
  }

  function collectNavigationSnapshot() {
    var items = [];
    var seenNodes = [];
    function collect(nodes, source, limit) {
      (nodes || []).slice(0, limit || 600).forEach(function (node) {
        if (!node || seenNodes.indexOf(node) >= 0) return;
        seenNodes.push(node);
        var item = buildNavigationItem(node, source);
        if (item) items.push(item);
      });
    }

    try {
      collect(Array.from(document.querySelectorAll(NAV_SELECTOR)), "nav_selector", 800);
    } catch (_) {}

    // Some recruitment sites render the resume section rail as plain div/span/p
    // nodes with site-specific class names rather than semantic nav/menu markup.
    // This fallback is read-only: it only records visible elements whose *entire*
    // text is a known resume-section title, and never clicks the candidate.
    try {
      var broad = Array.from(document.querySelectorAll("a,button,li,div,span,p,[role='tab'],[role='menuitem'],[onclick]"));
      var semantic = broad.filter(function (node) {
        if (!isVisible(node) || isNavigationFieldLabel(node)) return false;
        var text = node.textContent || node.getAttribute && (node.getAttribute("aria-label") || node.getAttribute("title")) || "";
        return isResumeSectionNavigationText(text);
      });
      collect(semantic, "semantic_text_fallback", 2500);
    } catch (_) {}

    return canonicalizeNavigationItems(items);
  }

  function summarizeConfig(config) {
    if (!config || typeof config !== "object") return null;
    return {
      name: safeAttr(config.name, 80),
      type: safeAttr(config.type, 50),
      source: safeAttr(config._source || config.source, 60),
      platform: safeAttr(config.platform || config.platformType || config.uiFrame示例资料, 60),
      pageType: safeAttr(config.pageType || config.formMode, 60)
    };
  }

  function configSelector(slot) {
    if (!slot) return "";
    if (typeof slot === "string") return slot.trim();
    if (typeof slot === "object") return String(slot.class || slot.selector || "").trim();
    return "";
  }

  function configTextList(value) {
    if (!value) return [];
    return (Array.isArray(value) ? value : [value]).map(function (item) {
      return safeActionText(item);
    }).filter(Boolean);
  }

  // Reuse mature-product site/platform assets before falling back to the generic
  // interactive detector. This is deliberately analysis-only: only explicit edit
  // actions are allowed; add/save/submit/upload remain disabled.
  function buildMatureInteractiveProbeOptions(builtIn, platform, staticControlCount) {
    var config = builtIn || platform || null;
    var options = {
      allowEditProbe: true,
      allowAddProbe: false,
      allowPageNavigation: false,
      allowNavigationActions: false
    };
    if (!config) return { options: options, source: "generic", explicitEditConfig: false };

    // SiteLoader deliberately lets PrivateSpecialSites override the public site
    // template. For execution that is correct; for analysis we may still need the
    // public template's mature experience metadata (card selector + edit selector).
    // Merge only missing structural/edit knowledge; never import add/save actions.
    var publicTemplate = null;
    try {
      var templates = AF.SITE_TEMPLATES || {};
      publicTemplate = templates[String(location.hostname || "")] || null;
    } catch (_) {}

    var selectors = config.selectors || {};
    var publicSelectors = publicTemplate && publicTemplate.selectors || {};
    var experience = config.experience || {};
    var publicExperience = publicTemplate && publicTemplate.experience || {};
    var editor = experience.editor || {};
    var publicEditor = publicExperience.editor || {};
    var card = experience.card || publicExperience.card || {};

    var moduleSelector = configSelector(selectors.container) || configSelector(publicSelectors.container) ||
      (experience.container && (experience.container.containerSelector || experience.container.selector)) ||
      (publicExperience.container && (publicExperience.container.containerSelector || publicExperience.container.selector)) || "";
    var titleSelector = configSelector(selectors.title) || configSelector(publicSelectors.title);
    var editSelectors = [];
    [editor.cardEditButtonSelector, editor.containerEditButtonSelector,
     publicEditor.cardEditButtonSelector, publicEditor.containerEditButtonSelector].forEach(function (value) {
      if (value && editSelectors.indexOf(value) < 0) editSelectors.push(value);
    });

    // Preserve card ownership from the mature experience model. A generic
    // `.icon-box` can also mean Add; `.apply-form .icon-box` is the mature
    // FillEngine's existing-card edit path and is safe for analysis-only probing.
    var cardSelector = card.cardSelector || "";
    if (cardSelector) {
      [editor.cardEditButtonSelector, publicEditor.cardEditButtonSelector].forEach(function (value) {
        if (!value) return;
        var scoped = String(cardSelector).trim() + " " + String(value).trim();
        if (editSelectors.indexOf(scoped) < 0) editSelectors.unshift(scoped);
      });
    }

    // Older/private mature configs sometimes only expose buttons.edit. Use it as
    // a final mature fallback only when no stronger experience editor selector exists.
    if (!editSelectors.length) {
      var legacyEdit = configSelector(selectors.buttons && selectors.buttons.edit);
      if (legacyEdit) editSelectors.push(legacyEdit);
    }

    var editTexts = configTextList(editor.cardEditButtonText)
      .concat(configTextList(editor.containerEditButtonText))
      .concat(configTextList(publicEditor.cardEditButtonText))
      .concat(configTextList(publicEditor.containerEditButtonText));
    editTexts = Array.from(new Set(editTexts));

    if (moduleSelector) options.moduleSelector = moduleSelector;
    if (titleSelector) options.titleSelector = titleSelector;
    if (cardSelector) options.cardSelector = cardSelector;
    if (editSelectors.length || editTexts.length) {
      options.openAction = { selectors: editSelectors, texts: editTexts };
      options.allowSingleModule = Number(staticControlCount || 0) === 0;
    }
    return {
      options: options,
      source: builtIn ? "built_in_config" : "dom_platform",
      configName: safeAttr(config.name, 80),
      publicTemplateOverlay: !!publicTemplate,
      explicitEditConfig: editSelectors.length > 0 || editTexts.length > 0
    };
  }

  function configuredEditAction(module, probeOptions) {
    if (!module || !module.querySelectorAll) return null;
    probeOptions = probeOptions || {};
    var openAction = probeOptions.openAction || {};
    var selectors = Array.isArray(openAction.selectors) ? openAction.selectors : (openAction.selector ? [openAction.selector] : []);
    var texts = Array.isArray(openAction.texts) ? openAction.texts : (openAction.text ? [openAction.text] : []);
    texts = texts.map(function (text) { return normalizeText(text, 30).toLowerCase(); }).filter(Boolean);
    var candidates = [];
    selectors.forEach(function (selector) {
      if (!selector) return;
      try { candidates = candidates.concat(Array.from(module.querySelectorAll(selector))); } catch (_) {}
    });
    if (!candidates.length) {
      try { candidates = Array.from(module.querySelectorAll("button,a,[role='button'],[class*='edit'],[class*='icon-box']")); } catch (_) {}
    }
    var seen = new Set();
    for (var i = 0; i < candidates.length; i++) {
      var node = candidates[i];
      if (!node || seen.has(node) || !isVisible(node)) continue;
      seen.add(node);
      var rawText = normalizeText(
        (node.innerText || node.textContent || "") + " " +
        (node.getAttribute && (node.getAttribute("aria-label") || node.getAttribute("title")) || ""),
        80
      );
      var lowered = rawText.toLowerCase();
      if (/保存|提交|投递|删除|移除|上传|下一步|确认|取消|关闭|添加|新增|新建|增加|创建|save|submit|apply|delete|upload|add|new/i.test(rawText)) continue;
      if (texts.length && rawText && !texts.some(function (text) { return lowered.indexOf(text) >= 0; })) continue;
      var safeText = safeActionText(rawText);
      // Some mature sites use icon-only edit buttons. An explicitly configured
      // mature edit selector is sufficient authority even when the icon has no text.
      if (!safeText && selectors.length && selectors.some(function (selector) {
        try { return node.matches && node.matches(selector); } catch (_) { return false; }
      })) safeText = "编辑";
      if (!/编辑|修改|完善|Edit/i.test(safeText)) continue;
      return { element: node, type: "edit", text: safeText };
    }
    return null;
  }

  // The mature FillEngine contains a second-line module-dialog fallback for
  // pages that the generic InteractiveFormRuntime 示例资料ally scores too
  // conservatively (notably Zhaopin Campus). Analyzer reuses that philosophy:
  // exact mature config -> explicit EDIT action -> read-only scan -> close.
  function discoverModulesFromMatureConfig(probeOptions) {
    probeOptions = probeOptions || {};
    var moduleSelector = String(probeOptions.moduleSelector || "").trim();
    if (!moduleSelector) return [];
    var modules = [];
    try { modules = Array.from(document.querySelectorAll(moduleSelector)).filter(isVisible); } catch (_) { modules = []; }
    var records = [];
    modules.forEach(function (module, index) {
      var titleEl = null;
      if (probeOptions.titleSelector) {
        try { titleEl = module.querySelector(probeOptions.titleSelector); } catch (_) {}
      }
      if (!titleEl) {
        try { titleEl = module.querySelector("h1,h2,h3,h4,.module-title,.section-title,.card-title,[class*='title']"); } catch (_) {}
      }
      var title = normalizeText(titleEl && titleEl.textContent, 80);
      var action = configuredEditAction(module, probeOptions);
      if (!action) return;
      var initialControlCount = 0;
      try { initialControlCount = Array.from(module.querySelectorAll(CONTROL_SELECTOR)).filter(isVisible).length; } catch (_) {}
      records.push({
        key: "mature-config-module-" + index + "-" + title.replace(/[^\w\u4e00-\u9fa5]+/g, "-").slice(0, 32),
        title: title,
        element: module,
        titleElement: titleEl,
        action: action,
        initialControlCount: initialControlCount
      });
    });
    return records;
  }

  function summarizeInteractiveCandidate(record, index) {
    return {
      index: index,
      title: safeAttr(record && record.title, 80),
      actionType: safeAttr(record && (record.actionType || record.action && record.action.type), 30),
      actionText: safeActionText(record && (record.actionText || record.action && record.action.text)),
      initialControlCount: Number(record && record.initialControlCount || 0)
    };
  }

  function emptyFormGraph(reason) {
    return {
      schemaType: "autofill-lite-form-graph",
      schemaVersion: 1,
      graphVersion: "",
      page: { hostname: safeAttr(location && location.hostname, 120), pathname: safePath(location && location.href || "/") },
      totals: { sections: 0, rows: 0, controls: 0 },
      sections: [],
      controls: [],
      safety: {
        currentValuesIncluded: false,
        arbitraryRowTextIncluded: false,
        queryIncluded: false,
        fileContentIncluded: false
      },
      unavailableReason: safeAttr(reason || "form_graph_unavailable", 80)
    };
  }

  function collectFormGraph(root) {
    var graphApi = AF.FormGraph;
    if (!graphApi || typeof graphApi.scan !== "function") return emptyFormGraph("api_unavailable");
    try {
      return graphApi.scan(root || document.body, { document: document });
    } catch (_) {
      return emptyFormGraph("scan_exception");
    }
  }

  function emptyRecordGraph(reason) {
    return {
      schemaType: "autofill-lite-record-graph",
      schemaVersion: 1,
      graphVersion: "",
      page: { hostname: safeAttr(location && location.hostname, 120), pathname: safePath(location && location.href || "/") },
      totals: { groups: 0, records: 0, savedRecords: 0, editorRecords: 0, addActions: 0 },
      groups: [],
      safety: {
        currentValuesIncluded: false,
        arbitraryRecordTextIncluded: false,
        profileValuesIncluded: false,
        pageActionsExecuted: false,
        addSaveSubmitDeleteUploadExecuted: false
      },
      unavailableReason: safeAttr(reason || "record_graph_unavailable", 80)
    };
  }

  function collectRecordGraph(root, formGraph) {
    var graphApi = AF.RecordGraph;
    if (!graphApi || typeof graphApi.scan !== "function") return emptyRecordGraph("api_unavailable");
    try {
      return graphApi.scan(root || document.body, { document: document, formGraph: formGraph || null });
    } catch (_) {
      return emptyRecordGraph("scan_exception");
    }
  }

  function normalizeGraphControlType(value) {
    var type = String(value || "").toLowerCase();
    if (type === "native-select" || type === "custom-select") return "select";
    if (type === "radio-group") return "radio";
    if (type === "date" || type === "date-picker") return "date";
    if (type === "textbox") return "text";
    return type.replace(/^(?:element|ant|el|native)-/, "");
  }

  function normalizeCollectorControlType(value) {
    var type = String(value || "").toLowerCase();
    if (/select|cascader|combobox/.test(type)) return "select";
    if (/radio/.test(type)) return "radio";
    if (/date|picker/.test(type)) return "date";
    if (/textarea/.test(type)) return "textarea";
    if (/checkbox/.test(type)) return "checkbox";
    if (/text|input/.test(type)) return "text";
    return type;
  }

  function graphControlKey(control) {
    return String(control && control.selectorHint || "").trim();
  }

  function graphControlLabel(control) {
    return normalizeText(control && (control.label || control.rowLabel || control.placeholder || control.name), 100);
  }

  function rectSignature(rect) {
    if (!rect || typeof rect !== "object") return null;
    var x = Number(rect.x);
    var y = Number(rect.y);
    var width = Number(rect.width);
    var height = Number(rect.height);
    if (![x, y, width, height].every(Number.isFinite)) return null;
    return { x: x, y: y, width: width, height: height };
  }

  function rectDistance(a, b) {
    a = rectSignature(a);
    b = rectSignature(b);
    if (!a || !b) return Infinity;
    return Math.abs(a.x - b.x) + Math.abs(a.y - b.y) +
      Math.abs(a.width - b.width) + Math.abs(a.height - b.height);
  }

  // Mature ElementMatcher/FormHandler treat frame示例资料 widget wrappers as the
  // logical control owner while the editable input may live inside that host.
  // Lite's StaticScanner observes the inner input and FormGraph observes the
  // canonical owner, so bridge the two by containment geometry before falling
  // back to approximate rectangle distance.
  function logicalOwnerGeometryCandidates(field, graphControls) {
    var source = rectSignature(field && field.rect);
    if (!source) return [];
    var sx1 = source.x, sy1 = source.y, sx2 = source.x + source.width, sy2 = source.y + source.height;
    var scx = source.x + source.width / 2, scy = source.y + source.height / 2;
    return graphControls.map(function (control) {
      var owner = rectSignature(control && control.rect);
      if (!owner) return null;
      var ox1 = owner.x - 3, oy1 = owner.y - 3, ox2 = owner.x + owner.width + 3, oy2 = owner.y + owner.height + 3;
      var contains = sx1 >= ox1 && sy1 >= oy1 && sx2 <= ox2 && sy2 <= oy2;
      var centerInside = scx >= ox1 && scx <= ox2 && scy >= oy1 && scy <= oy2;
      if (!contains && !centerInside) return null;
      var verticalDelta = Math.abs((owner.y + owner.height / 2) - scy);
      var horizontalDelta = Math.abs((owner.x + owner.width / 2) - scx);
      return { control: control, distance: verticalDelta * 4 + horizontalDelta, contains: contains };
    }).filter(Boolean).sort(function (a, b) { return a.distance - b.distance; });
  }

  function geometryCandidates(field, graphControls) {
    var sourceRect = rectSignature(field && field.rect);
    if (!sourceRect) return [];
    return graphControls.map(function (control) {
      return { control: control, distance: rectDistance(sourceRect, control && control.rect) };
    }).filter(function (entry) {
      return entry.distance <= 10;
    }).sort(function (a, b) {
      return a.distance - b.distance;
    });
  }

  function attachFormGraphContext(scan, graph) {
    scan = scan || { fields: [] };
    graph = graph || emptyFormGraph("missing_graph");
    var graphControls = Array.isArray(graph.controls) ? graph.controls : [];
    var bySelector = {};
    graphControls.forEach(function (control) {
      var selector = graphControlKey(control);
      if (!selector) return;
      if (!bySelector[selector]) bySelector[selector] = [];
      bySelector[selector].push(control);
    });

    var linked = 0;
    var linkMethods = {};
    (Array.isArray(scan.fields) ? scan.fields : []).forEach(function (field) {
      var match = null;
      var method = "";
      var confidence = 0;
      var selectors = [field.selectorHint, field.widgetSelectorHint].filter(Boolean);
      for (var i = 0; i < selectors.length && !match; i++) {
        var hits = bySelector[String(selectors[i] || "").trim()] || [];
        if (hits.length === 1) {
          match = hits[0];
          method = i === 0 ? "unique_control_selector" : "unique_widget_selector";
          confidence = 1;
        }
      }

      if (!match) {
        var ownerGeometry = logicalOwnerGeometryCandidates(field, graphControls);
        if (ownerGeometry.length === 1 || (ownerGeometry.length > 1 && ownerGeometry[0].distance + 4 < ownerGeometry[1].distance)) {
          match = ownerGeometry[0].control;
          method = "logical_owner_geometry";
          confidence = ownerGeometry[0].contains ? 0.99 : 0.96;
        }
      }

      if (!match) {
        var geometry = geometryCandidates(field, graphControls);
        if (geometry.length === 1 || (geometry.length > 1 && geometry[0].distance + 3 < geometry[1].distance)) {
          match = geometry[0].control;
          method = "geometry";
          confidence = geometry[0].distance === 0 ? 0.98 : 0.94;
        }
      }

      if (!match) {
        var wantedLabel = normalizeText(field.label || (field.safeSemanticCandidates && field.safeSemanticCandidates[0]) || field.placeholder || field.name, 100);
        var wantedType = normalizeCollectorControlType(field.controlType);
        var candidates = graphControls.filter(function (control) {
          var label = graphControlLabel(control);
          var graphType = normalizeGraphControlType(control.controlType);
          return !!wantedLabel && label === wantedLabel && (!wantedType || !graphType || wantedType === graphType);
        });
        if (candidates.length === 1) {
          match = candidates[0];
          method = "unique_label_type";
          confidence = 0.82;
        }
      }

      if (!match) return;
      field.graphFieldId = safeAttr(match.fieldId, 80);
      field.graphSectionId = safeAttr(match.sectionId, 80);
      field.graphSectionTitle = safeAttr(match.sectionTitle, 100);
      // FormGraph owns the control-to-section relation. When a generic nearest-
      // heading scan disagrees with a high-confidence graph owner (CNPC is a
      // representative case), prefer the graph section so AI does not receive
      // an entire 示例资料/示例资料 form mislabeled as the preceding 示例资料 block.
      if (field.graphSectionTitle && confidence >= 0.94 && field.section !== field.graphSectionTitle) {
        field.section = field.graphSectionTitle;
        field.sectionEvidence = "form_graph_owner";
      }
      field.graphRowId = safeAttr(match.rowId, 80);
      field.graphRowLabel = safeAttr(match.rowLabel, 100);
      field.graphLinkMethod = method;
      field.graphLinkConfidence = confidence;
      linked += 1;
      linkMethods[method] = Number(linkMethods[method] || 0) + 1;
    });

    var scanCount = Number(scan.controlCount || (scan.fields && scan.fields.length) || 0);
    var graphCount = Number(graph.totals && graph.totals.controls || graphControls.length || 0);
    var coverage = scanCount > 0 ? linked / scanCount : (graphCount > 0 ? 0 : 1);
    return {
      staticControlCount: scanCount,
      graphControlCount: graphCount,
      linkedStaticFieldCount: linked,
      unlinkedStaticFieldCount: Math.max(0, scanCount - linked),
      graphOnlyControlCount: Math.max(0, graphCount - linked),
      linkedRatio: Number(coverage.toFixed(4)),
      linkMethods: linkMethods
    };
  }


  function applyGraphSemanticContext(scan, matcher) {
    scan = scan || { fields: [] };
    var promoted = 0;
    (Array.isArray(scan.fields) ? scan.fields : []).forEach(function (field) {
      if (!field || !field.graphSectionTitle || Number(field.graphLinkConfidence || 0) < 0.94) return;
      if (field.coreMappingStatus === "trusted" && field.coreFieldKey) return;
      var categoryHint = categoryHintForSection(field.graphSectionTitle, matcher);
      if (!categoryHint || !categoryHint.category) return;
      var mappingHint = fieldMappingHint(matcher, categoryHint.category, field);
      if (!mappingHint || !mappingHint.fieldKey) return;
      field.coreCategory = categoryHint.category;
      field.coreCategorySource = "form_graph_" + (categoryHint.source || "section");
      field.coreCategoryConfidence = Math.min(1, Math.max(Number(categoryHint.confidence || 0), Number(field.graphLinkConfidence || 0)));
      field.coreCategoryEvidence = categoryHint.evidence || field.graphSectionTitle || "";
      field.coreFieldKey = mappingHint.fieldKey;
      field.coreMappingEvidence = mappingHint.evidence || "";
      field.coreMappingMethod = "form_graph_context+" + (mappingHint.method || "core_matcher");
      field.coreMappingConfidence = Number(mappingHint.confidence || 0);
      field.coreMappingStatus = mappingHint.status || "tentative";
      field.coreMappingReasons = (mappingHint.reasons || []).concat(["graph_section_context"]);
      promoted += 1;
    });
    return promoted;
  }

  function graphDiagnostics(graph, coverage, source) {
    graph = graph || emptyFormGraph("missing_graph");
    coverage = coverage || {};
    var safety = graph.safety || {};
    return {
      available: !graph.unavailableReason,
      source: safeAttr(source || "document_body", 40),
      graphVersion: safeAttr(graph.graphVersion, 30),
      schemaVersion: Number(graph.schemaVersion || 0),
      sectionCount: Number(graph.totals && graph.totals.sections || 0),
      rowCount: Number(graph.totals && graph.totals.rows || 0),
      controlCount: Number(graph.totals && graph.totals.controls || 0),
      linkedRatio: Number(coverage.linkedRatio || 0),
      privacySafe: safety.currentValuesIncluded === false &&
        safety.arbitraryRowTextIncluded === false &&
        safety.queryIncluded === false,
      observationMode: "visible_editable_controls",
      emptyBecauseNoVisibleEditableControls: Number(graph.totals && graph.totals.controls || 0) === 0,
      unavailableReason: safeAttr(graph.unavailableReason, 80)
    };
  }

  function mergeInteractiveRecordEvidence(baseGraph, modules) {
    var graph = JSON.parse(JSON.stringify(baseGraph || emptyRecordGraph("missing_graph")));
    graph.groups = Array.isArray(graph.groups) ? graph.groups : [];
    var seen = {};
    graph.groups.forEach(function (group) {
      seen[String(group.categoryHint || "") + "|" + JSON.stringify((group.records || []).map(function (r) { return r.rowLabels || []; }))] = true;
    });
    var graphApi = AF.RecordGraph || {};
    (modules || []).forEach(function (module) {
      var moduleCategory = typeof graphApi.categoryHint === "function" ? graphApi.categoryHint(module && module.title || "") : "";
      var rg = module && module.recordGraph;
      if (!moduleCategory || !rg || !Array.isArray(rg.groups)) return;
      rg.groups.forEach(function (group) {
        if (!group || !group.categoryHint || group.categoryHint !== moduleCategory) return;
        var signature = String(group.categoryHint || "") + "|" + JSON.stringify((group.records || []).map(function (r) { return r.rowLabels || []; }));
        if (seen[signature]) return;
        seen[signature] = true;
        var copy = JSON.parse(JSON.stringify(group));
        copy.source = "interactive_mature_probe";
        copy.interactiveModuleTitle = safeAttr(module.title, 100);
        graph.groups.push(copy);
      });
    });
    var totals = { groups: graph.groups.length, records: 0, savedRecords: 0, editorRecords: 0, addActions: 0 };
    graph.groups.forEach(function (group) {
      totals.records += Number(group.recordCount || (group.records || []).length || 0);
      totals.savedRecords += Number(group.savedRecordCount || 0);
      totals.editorRecords += Number(group.editorRecordCount || 0);
      totals.addActions += Number(group.addActionCount || 0);
    });
    graph.totals = totals;
    graph.structureHints = Object.assign({}, graph.structureHints || {}, {
      interactiveEvidenceMerged: graph.groups.some(function (g) { return g.source === "interactive_mature_probe"; })
    });
    return graph;
  }

  function recordGraphDiagnostics(graph, source) {
    graph = graph || emptyRecordGraph("missing_graph");
    var safety = graph.safety || {};
    return {
      available: !graph.unavailableReason,
      source: safeAttr(source || "document_body", 40),
      graphVersion: safeAttr(graph.graphVersion, 30),
      schemaVersion: Number(graph.schemaVersion || 0),
      groupCount: Number(graph.totals && graph.totals.groups || 0),
      recordCount: Number(graph.totals && graph.totals.records || 0),
      savedRecordCount: Number(graph.totals && graph.totals.savedRecords || 0),
      editorRecordCount: Number(graph.totals && graph.totals.editorRecords || 0),
      addActionCount: Number(graph.totals && graph.totals.addActions || 0),
      privacySafe: safety.currentValuesIncluded === false &&
        safety.arbitraryRecordTextIncluded === false &&
        safety.profileValuesIncluded === false &&
        safety.pageActionsExecuted === false,
      observationMode: "示例资料_record_structure",
      matureFirst: true,
      unavailableReason: safeAttr(graph.unavailableReason, 80)
    };
  }

  async function analyze(options) {
    options = options || {};
    var maxModules = Math.max(1, Math.min(30, Number(options.maxModules || 18)));
    var maxControlsPerSurface = Math.max(20, Math.min(400, Number(options.maxControlsPerSurface || 220)));
    var loader = AF.SiteLoader || {};
    var 示例资料flow = AF.SpecialSiteWorkflow || {};
    var runtime = AF.InteractiveFormRuntime || null;
    var builtIn = null;
    var platform = null;
    var 示例资料flowMatch = null;
    var matcher = null;
    try { if (typeof loader._getConfigForUrl === "function") builtIn = loader._getConfigForUrl(location.href); } catch (_) {}
    try { if (typeof loader._detectSiteType === "function") platform = loader._detectSiteType(); } catch (_) {}
    try { if (typeof 示例资料flow.match === "function") 示例资料flowMatch = 示例资料flow.match(location.href); } catch (_) {}
    try { if (typeof AF.DataMatcher === "function") matcher = new AF.DataMatcher({}, builtIn || null); } catch (_) {}

    var staticScan = scanRoot(document.body, { maxControls: maxControlsPerSurface, matcher: matcher });
    var formGraph = collectFormGraph(document.body);
    var recordGraph = collectRecordGraph(document.body, formGraph);
    var graphCoverage = attachFormGraphContext(staticScan, formGraph);
    var graphSemanticPromotions = applyGraphSemanticContext(staticScan, matcher);

    var result = {
      schemaType: "autofill-lite-site-analysis",
      schemaVersion: 7,
      collectorVersion: VERSION,
      collectedAt: new Date().toISOString(),
      page: {
        protocol: location.protocol,
        hostname: location.hostname,
        pathname: location.pathname
      },
      configProbe: {
        serverConfigEnabled: !!(AF.ServerConfig && AF.ServerConfig.baseUrl),
        builtInConfig: summarizeConfig(builtIn),
        domPlatform: summarizeConfig(platform),
        specialWorkflowId: safeAttr(示例资料flowMatch && (示例资料flowMatch.id || 示例资料flowMatch.示例资料flowId || 示例资料flowMatch.name), 100)
      },
      safety: {
        valuesCaptured: false,
        queryCaptured: false,
        addProbeAllowed: false,
        saveSubmitApplyDeleteUploadAllowed: false
      },
      navigation: {
        discoveryVersion: 3,
        items: collectNavigationSnapshot()
      },
      staticScan: staticScan,
      formGraph: formGraph,
      recordGraph: recordGraph,
      graphCoverage: graphCoverage,
      graphDiagnostics: Object.assign(graphDiagnostics(formGraph, graphCoverage, "document_body"), { semanticPromotions: graphSemanticPromotions }),
      recordGraphDiagnostics: recordGraphDiagnostics(recordGraph, "document_body"),
      interactive: {
        supported: !!runtime,
        probeSource: "generic",
        probeConfigName: "",
        matureProbe: {
          publicTemplateOverlay: false,
          explicitEditConfig: false,
          configuredRecordCount: 0
        },
        detection: null,
        candidates: [],
        modules: [],
        skipped: [],
        failed: [],
        leftOpen: []
      }
    };

    if (!runtime || typeof runtime.discoverModules !== "function") return result;
    var probe = buildMatureInteractiveProbeOptions(builtIn, platform, staticScan.controlCount);
    var probeOptions = probe.options || {};
    result.interactive.probeSource = probe.source || "generic";
    result.interactive.probeConfigName = probe.configName || "";
    result.interactive.matureProbe.publicTemplateOverlay = !!probe.publicTemplateOverlay;
    result.interactive.matureProbe.explicitEditConfig = !!probe.explicitEditConfig;
    var rawDetection = null;
    var configuredRecords = [];
    try {
      rawDetection = typeof runtime.detectPage === "function" ? runtime.detectPage(probeOptions) : null;
      try { configuredRecords = runtime.discoverModules(probeOptions).slice(0, maxModules); } catch (_) { configuredRecords = []; }
      if (!configuredRecords.length && Number(staticScan.controlCount || 0) === 0 && probe.explicitEditConfig) {
        configuredRecords = discoverModulesFromMatureConfig(probeOptions).slice(0, maxModules);
      }
      result.interactive.matureProbe.configuredRecordCount = configuredRecords.length;

      // Mature configs already declare the exact module/title/edit selectors for a
      // number of known sites. If the generic score rejects a single closed module,
      // keep the mature config as the authority: only explicit EDIT actions qualify.
      if (rawDetection && !rawDetection.matched && Number(staticScan.controlCount || 0) === 0 && probe.explicitEditConfig) {
        var editableConfigured = configuredRecords.filter(function (record) {
          return record && record.action && record.action.type === "edit";
        });
        if (editableConfigured.length) {
          rawDetection = Object.assign({}, rawDetection, {
            matched: true,
            interactive: true,
            confidence: Math.max(Number(rawDetection.confidence || 0), 0.96),
            mode: "known-config-edit-probe",
            moduleCount: configuredRecords.length,
            actionCount: editableConfigured.length,
            modules: configuredRecords.map(function (record) {
              return {
                title: record.title || "",
                actionType: record.action && record.action.type || "",
                actionText: record.action && record.action.text || "",
                initialControlCount: Number(record.initialControlCount || 0)
              };
            })
          });
        }
      }

      if (rawDetection) {
        result.interactive.detection = {
          matched: !!rawDetection.matched,
          confidence: Number(rawDetection.confidence || 0),
          mode: safeAttr(rawDetection.mode, 40),
          moduleCount: Number(rawDetection.moduleCount || 0),
          actionCount: Number(rawDetection.actionCount || 0),
          visibleControlCount: Number(rawDetection.visibleControlCount || 0),
          visibleStaticForm: !!rawDetection.visibleStaticForm,
          displayOnlyCount: Number(rawDetection.displayOnlyCount || 0)
        };
        result.interactive.candidates = Array.isArray(rawDetection.modules)
          ? rawDetection.modules.slice(0, maxModules).map(summarizeInteractiveCandidate)
          : configuredRecords.map(summarizeInteractiveCandidate);
      }
    } catch (_) {}

    // Static-first safety from the mature runtime: when a real editable form is
    // already visible, record structure only. Never click an示例资料 edit action.
    if (Number(staticScan.controlCount || 0) > 0) return result;
    if (!result.interactive.detection || !result.interactive.detection.matched) return result;

    var records = configuredRecords;
    if (!records.length) {
      try { records = runtime.discoverModules(probeOptions).slice(0, maxModules); } catch (_) { records = []; }
    }
    for (var i = 0; i < records.length; i++) {
      var record = records[i];
      var actionType = record && record.action && record.action.type || "";
      var moduleMeta = summarizeInteractiveCandidate(record, i);
      if (actionType === "add") {
        result.interactive.skipped.push(Object.assign({}, moduleMeta, { reason: "add_probe_disabled" }));
        continue;
      }
      var opened = null;
      try {
        opened = await runtime.openModule(record, Object.assign({}, probeOptions, {
          allowEditProbe: true,
          allowAddProbe: false,
          allowPageNavigation: false,
          allowNavigationActions: false,
          maxWaitMs: 8000,
          quietWindowMs: 350
        }));
      } catch (error) {
        result.interactive.failed.push(Object.assign({}, moduleMeta, { reason: "open_exception" }));
        continue;
      }
      if (!opened || !opened.success) {
        var failedMeta = Object.assign({}, moduleMeta, { reason: safeAttr(opened && opened.reason || "open_failed", 80) });
        if (opened && opened.skipped) result.interactive.skipped.push(failedMeta);
        else result.interactive.failed.push(failedMeta);
        continue;
      }
      var surfaceRoot = opened.surface && opened.surface.element || document.body;
      var surfaceScan = scanRoot(surfaceRoot, { maxControls: maxControlsPerSurface, matcher: matcher });
      var surfaceFormGraph = collectFormGraph(surfaceRoot);
      var surfaceRecordGraph = collectRecordGraph(surfaceRoot, surfaceFormGraph);
      var surfaceGraphCoverage = attachFormGraphContext(surfaceScan, surfaceFormGraph);
      var surfaceSemanticPromotions = applyGraphSemanticContext(surfaceScan, matcher);
      var closeResult = null;
      try { closeResult = await runtime.closeSurface(opened.transaction); } catch (_) { closeResult = { closed: false, reason: "close_exception" }; }
      result.interactive.modules.push(Object.assign({}, moduleMeta, {
        surfaceType: safeAttr(opened.surface && opened.surface.type, 40),
        scan: surfaceScan,
        formGraph: surfaceFormGraph,
        recordGraph: surfaceRecordGraph,
        graphCoverage: surfaceGraphCoverage,
        graphDiagnostics: Object.assign(graphDiagnostics(surfaceFormGraph, surfaceGraphCoverage, "interactive_surface"), { semanticPromotions: surfaceSemanticPromotions }),
        recordGraphDiagnostics: recordGraphDiagnostics(surfaceRecordGraph, "interactive_surface"),
        close: {
          closed: !!(closeResult && closeResult.closed),
          leftOpen: !!(closeResult && closeResult.leftOpen),
          blocking: !!(closeResult && closeResult.blocking),
          reason: safeAttr(closeResult && closeResult.reason, 80)
        }
      }));
      if (!closeResult || !closeResult.closed) {
        result.interactive.leftOpen.push({ title: moduleMeta.title, reason: safeAttr(closeResult && closeResult.reason || "not_closed", 80) });
        if (closeResult && closeResult.blocking) break;
      }
    }
    result.recordGraph = mergeInteractiveRecordEvidence(result.recordGraph, result.interactive.modules);
    result.recordGraphDiagnostics = recordGraphDiagnostics(result.recordGraph, result.recordGraph && result.recordGraph.structureHints && result.recordGraph.structureHints.interactiveEvidenceMerged ? "document_plus_interactive" : "document_body");
    return result;
  }

  AF.SiteAnalysisCollector = {
    version: VERSION,
    scanRoot: scanRoot,
    analyze: analyze,
    collectNavigationSnapshot: collectNavigationSnapshot,
    collectFormGraph: collectFormGraph,
    collectRecordGraph: collectRecordGraph,
    mergeInteractiveRecordEvidence: mergeInteractiveRecordEvidence,
    attachFormGraphContext: attachFormGraphContext,
    buildMatureInteractiveProbeOptions: buildMatureInteractiveProbeOptions,
    discoverModulesFromMatureConfig: discoverModulesFromMatureConfig,
    logicalOwnerGeometryCandidates: logicalOwnerGeometryCandidates,
    applyGraphSemanticContext: applyGraphSemanticContext
  };
})();
