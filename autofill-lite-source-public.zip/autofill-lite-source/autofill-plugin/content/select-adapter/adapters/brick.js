// content/select-adapter/adapters/brick.js — Brick UI (.brick-select) 适配器
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   BrickSelectAdapter (模块9852):   行 56299-57621 附近
//   triggerBrickSelect (混淆名 v/y): 行 56915-56965
//
// 算法 (对应源码 v() 函数, 行56916-56964):
//   1. container = closest(.brick-select-selection-selected-wrap)
//   2. 若 container 内有可用的 input[type=search/text] (筛选框)，输入 value 触发过滤
//   3. 直接点击 element 本身 (不是 container/trigger) 来展开面板 —— 这点与
//      ant/element 不同，是源码里的真实写法，照抄保留
//   4. 面板类名 .brick-menu，多半被 portal 到 body 外，用 findVisibleDropdownNear 全局搜索
//   5. 找到面板后调用通用 selectMatchingOption
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};
  var H = SA._helpers;
  var CONTAINER_SELECTOR = ".brick-select-selection-selected-wrap";
  var PANEL_SELECTOR = ".brick-menu";

  async function selectOneBrickValue(element, container, value) {
    var searchInput = container.querySelector('input[type="search"], input[type="text"]');
    if (searchInput && !searchInput.disabled && !searchInput.readOnly && typeof value === "string") {
      searchInput.focus();
      searchInput.value = value;
      searchInput.dispatchEvent(new Event("input", { bubbles: true }));
      await AF.Utils.sleep(200);
    }

    await AF.DomUtils.safeClickElement(element);
    await AF.Utils.sleep(200);

    var panel = H.findVisibleDropdownNear(element, PANEL_SELECTOR, CONTAINER_SELECTOR);
    if (!panel) {
      panel = await H.waitForVisibleDropdownNear(element, PANEL_SELECTOR, CONTAINER_SELECTOR, 1500);
    }
    if (!panel) return false;
    return await H.selectMatchingOption(panel, value);
  }

  async function triggerBrickSelect(element, value) {
    try {
      var container = element.closest(CONTAINER_SELECTOR) || element;

      var ok;
      if (Array.isArray(value)) {
        ok = false;
        for (var i = 0; i < value.length; i++) {
          var one = await selectOneBrickValue(element, container, value[i]);
          if (one) ok = true;
          await AF.Utils.sleep(150);
        }
      } else {
        ok = await selectOneBrickValue(element, container, value);
      }
      H.dispatchChangeEvents(element);
      return ok;
    } catch (e) {
      return false;
    }
  }

  SA._registry["brick"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        return await triggerBrickSelect(element, value);
      },
    };
  };
})();
