"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const sites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
const 示例资料flow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-示例资料flow.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const documentStub = { body: null, querySelector: () => null, documentElement: { setAttribute() {} } };
const windowStub = { AF: {}, location: { href: "https://job.bankcomm.com/", hostname: "job.bankcomm.com", pathname: "/" }, getComputedStyle: () => ({ display: "block", visibility: "visible" }) };
const context = { window: windowStub, document: documentStub, URL, console, setTimeout, clearTimeout };
vm.createContext(context);
vm.runInContext(sites, context);
const api = windowStub.AF.PrivateSpecialSites._test;
assert(api && typeof api.enrichBankcommWorkRow === "function", "A: 示例资料 transform hook missing");
assert(typeof api.bankcommAwardLevel === "function", "A: award level hook missing");
const 示例资料 = api.enrichBankcommWorkRow({
  __afCategory: "示例资料Experience",
  startTime: "示例资料",
  endTime: "示例资料",
  startDate: "示例资料",
  endDate: "示例资料"
});
assert(示例资料.startTime === "示例资料", "B: Bankcomm 示例资料 start must prefer exact startDate");
assert(示例资料.endTime === "示例资料", "B: Bankcomm 示例资料 end must prefer exact endDate");
assert(示例资料.bankcommWorkType === "实习生", "B: 示例资料 type regression");
assert(api.bankcommAwardLevel({ awardLevel: "示例资料" }, "奖学金") === "校级-一等奖", "C: 示例资料 scholarship mapping failed");
assert(示例资料flow.includes(".ant-calendar-picker:not(.ant-calendar-picker-disabled)"), "D: Ant v3 date picker support missing");
assert(示例资料flow.includes(".ant-calendar-picker-input:not([disabled])"), "D: Ant v3 date input support missing");
assert(!sites.includes('bankcommStep("#social", "社会招聘应聘者额外填写信息"'), "E: social-recruitment extra section must not enter Bankcomm execution plan");
const buildMatch = main.match(/const BUILD_ID = "([^"]+)"/);
assert(buildMatch && /-\d+$/.test(buildMatch[1]), "F: current numeric Build ID missing");
console.log("bankcomm-示例资料-date-award-social-guard.test.js passed (A-F)");
