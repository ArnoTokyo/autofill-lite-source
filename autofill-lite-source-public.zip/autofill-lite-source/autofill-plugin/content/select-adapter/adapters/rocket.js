// content/select-adapter/adapters/rocket.js — Rocket UI (.rocket-select) 适配器
//
// PDD/Temu 招聘页使用 Rocket Select。搜索框通常是 readonly + opacity:0，
// 真实值提交依赖组件状态，所以必须点击触发器、写入搜索词、等待 portal 下拉并点击选项。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};
  var H = SA._helpers;
  var CFG = SA._config.rocket;
  var rocketMainBridgePromise = null;

  function normalizeKeyword(value) {
    if (value === undefined || value === null) return "";
    if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return String(value).trim();
    if (Array.isArray(value)) return value.map(normalizeKeyword).filter(Boolean);
    if (typeof value === "object") {
      var keys = ["name", "label", "text", "value", "title", "school", "schoolName", "college", "major"];
      for (var i = 0; i < keys.length; i++) {
        if (value[keys[i]] !== undefined && value[keys[i]] !== null && String(value[keys[i]]).trim()) {
          return String(value[keys[i]]).trim();
        }
      }
    }
    return "";
  }

  function nativeSetInputValue(input, value) {
    var text = String(value == null ? "" : value);
    input.removeAttribute && input.removeAttribute("readonly");
    input.readOnly = false;
    var descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    if (descriptor && descriptor.set) descriptor.set.call(input, text);
    else input.value = text;
    if (input._valueTracker && typeof input._valueTracker.setValue === "function") {
      input._valueTracker.setValue("");
    }
    input.setAttribute && input.setAttribute("value", text);
  }

  function setInputValue(input, value) {
    var text = String(value == null ? "" : value);
    nativeSetInputValue(input, text);
    input.dispatchEvent(new InputEvent("input", {
      bubbles: true,
      cancelable: true,
      composed: true,
      data: text,
      inputType: "insertText",
    }));
    input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true, composed: true }));
    input.dispatchEvent(new KeyboardEvent("keyup", {
      bubbles: true,
      cancelable: true,
      composed: true,
      key: text.slice(-1) || "",
    }));
  }

  function dispatchRocketKeyboard(input, type, key, extra) {
    var opts = {
      bubbles: true,
      cancelable: true,
      composed: true,
      key: key || "",
      code: key && key.length === 1 ? "Key" + key.toUpperCase() : key || "",
      keyCode: key && key.length === 1 ? key.charCodeAt(0) : 0,
      which: key && key.length === 1 ? key.charCodeAt(0) : 0,
    };
    if (extra) {
      Object.keys(extra).forEach(function (name) {
        opts[name] = extra[name];
      });
    }
    input.dispatchEvent(new KeyboardEvent(type, opts));
  }

  function dispatchRocketInput(input, inputType, data) {
    try {
      input.dispatchEvent(new InputEvent("beforeinput", {
        bubbles: true,
        cancelable: true,
        composed: true,
        inputType: inputType,
        data: data || null,
      }));
    } catch (e) {}
    input.dispatchEvent(new InputEvent("input", {
      bubbles: true,
      cancelable: true,
      composed: true,
      inputType: inputType,
      data: data || null,
    }));
  }

  function ensureRocketMainBridge() {
    if (rocketMainBridgePromise) return rocketMainBridgePromise;
    rocketMainBridgePromise = new Promise(function (resolve) {
      try {
        var script = document.createElement("script");
        script.src = chrome.runtime.getURL("content/select-adapter/adapters/rocket-main.js");
        script.async = false;
        script.onload = function () {
          script.remove && script.remove();
          resolve(true);
        };
        script.onerror = function () {
          script.remove && script.remove();
          resolve(true);
        };
        (document.documentElement || document.head || document.body).appendChild(script);
        setTimeout(function () {
          resolve(true);
        }, 800);
      } catch (e) {
        resolve(true);
      }
    });
    return rocketMainBridgePromise;
  }

  async function typeRocketSearchInputInPage(input, value) {
    if (!input) return false;
    var bridgeReady = await ensureRocketMainBridge();
    if (!bridgeReady) return false;
    var token = "af_rocket_" + Date.now() + "_" + Math.random().toString(36).slice(2);
    var id = token + "_req";
    input.setAttribute("data-af-rocket-token", token);
    return await new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, 5000);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (!data || data.type !== "AF_ROCKET_TYPE_RESULT" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: "AF_ROCKET_TYPE_REQUEST",
        id: id,
        token: token,
        value: String(value == null ? "" : value),
      }, "*");
    });
  }

  async function clickRocketOptionInPage(option, input, value) {
    await ensureRocketMainBridge();
    var token = "";
    if (option) {
      token = "af_rocket_option_" + Date.now() + "_" + Math.random().toString(36).slice(2);
      option.setAttribute("data-af-rocket-option-token", token);
    }
    var inputToken = input && input.getAttribute && input.getAttribute("data-af-rocket-token") || "";
    var id = (token || inputToken || "af_rocket_click") + "_click";
    return await new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, 2500);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (!data || data.type !== "AF_ROCKET_CLICK_RESULT" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: "AF_ROCKET_CLICK_REQUEST",
        id: id,
        token: token,
        inputToken: inputToken,
        value: String(value == null ? "" : value),
      }, "*");
    });
  }

  async function clickRocketFirstOptionByPointInPage(input, value) {
    await ensureRocketMainBridge();
    var inputToken = input && input.getAttribute && input.getAttribute("data-af-rocket-token") || "";
    if (!inputToken) return false;
    var id = inputToken + "_point_click";
    return await new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, 2600);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (!data || data.type !== "AF_ROCKET_POINT_CLICK_RESULT" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: "AF_ROCKET_POINT_CLICK_REQUEST",
        id: id,
        inputToken: inputToken,
        value: String(value == null ? "" : value),
      }, "*");
    });
  }

  async function clickRocketAddSchoolFullNameInPage(input, value) {
    await ensureRocketMainBridge();
    var inputToken = input && input.getAttribute && input.getAttribute("data-af-rocket-token") || "";
    if (!inputToken) return false;
    var id = inputToken + "_add_school";
    return await new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, 2200);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (!data || data.type !== "AF_ROCKET_ADD_SCHOOL_RESULT" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: "AF_ROCKET_ADD_SCHOOL_REQUEST",
        id: id,
        inputToken: inputToken,
        value: String(value == null ? "" : value),
      }, "*");
    });
  }

  async function typeRocketSearchInput(input, value) {
    var text = String(value == null ? "" : value);
    if (await typeRocketSearchInputInPage(input, text)) return;
    input.removeAttribute && input.removeAttribute("readonly");
    input.readOnly = false;
    try {
      input.focus && input.focus();
    } catch (e) {}
    input.dispatchEvent(new FocusEvent("focus", { bubbles: true, cancelable: false, composed: true }));
    input.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, composed: true, view: window }));

    nativeSetInputValue(input, "");
    dispatchRocketKeyboard(input, "keydown", "Backspace", { keyCode: 8, which: 8, code: "Backspace" });
    dispatchRocketInput(input, "deleteContentBackward", null);
    dispatchRocketKeyboard(input, "keyup", "Backspace", { keyCode: 8, which: 8, code: "Backspace" });
    await AF.Utils.sleep(80);

    // Rocket Select 的学校字段是远程搜索型组件。一次性改 value 往往只改了 DOM，
    // 没有触发组件内部 search 状态；逐字 key/input 更接近真人输入，能唤起搜索请求。
    var composed = "";
    for (var i = 0; i < text.length; i++) {
      var ch = text.charAt(i);
      composed += ch;
      dispatchRocketKeyboard(input, "keydown", ch);
      dispatchRocketKeyboard(input, "keypress", ch);
      try {
        if (document.activeElement === input && document.execCommand) {
          document.execCommand("insertText", false, ch);
        }
      } catch (e) {}
      nativeSetInputValue(input, composed);
      dispatchRocketInput(input, "insertText", ch);
      dispatchRocketKeyboard(input, "keyup", ch);
      await AF.Utils.sleep(60);
    }

    // 某些 type=search 组件额外监听 search/change/paste，末尾补一轮保证兼容。
    input.dispatchEvent(new Event("search", { bubbles: true, cancelable: true, composed: true }));
    input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true, composed: true }));
    try {
      input.dispatchEvent(new ClipboardEvent("paste", {
        bubbles: true,
        cancelable: true,
        composed: true,
        clipboardData: new DataTransfer(),
      }));
    } catch (e) {}
  }

  function selectedText(container) {
    if (!container) return "";
    var selected = container.querySelector(
      ".rocket-select-selection-item, .rocket-select-selection-selected-value, " +
      "[class*='rocket-select-selection'][class*='item'], [class*='rocket-select'][class*='selected']"
    );
    var text = String((selected || container).textContent || "").replace(/\s+/g, " ").trim();
    if (/^(请选择|请输入|Select)$/i.test(text)) return "";
    return text;
  }

  function pressEnter(input) {
    if (!input) return;
    ["keydown", "keypress", "keyup"].forEach(function (type) {
      input.dispatchEvent(new KeyboardEvent(type, {
        bubbles: true,
        cancelable: true,
        composed: true,
        key: "Enter",
        code: "Enter",
        keyCode: 13,
        which: 13,
      }));
    });
  }

  function selectedMatches(container, value) {
    var text = selectedText(container);
    var actual = String(text || "").replace(/\s+/g, "").toLowerCase();
    var expected = String(value || "").replace(/\s+/g, "").toLowerCase();
    return !!expected && actual === expected;
  }

  function optionText(el) {
    return String(
      el && (el.textContent || el.getAttribute && (el.getAttribute("title") || el.getAttribute("aria-label") || el.getAttribute("data-value"))) || ""
    ).replace(/\s+/g, " ").trim();
  }

  function isNodeNearInput(node, input) {
    if (!node || !input || !node.getBoundingClientRect || !input.getBoundingClientRect) return true;
    var nr = node.getBoundingClientRect();
    var ir = input.getBoundingClientRect();
    var horizontalOverlap = Math.min(nr.right, ir.right + 80) - Math.max(nr.left, ir.left - 80);
    var verticallyClose = nr.bottom >= ir.top - 12 && nr.top <= ir.bottom + 420;
    return horizontalOverlap > 0 && verticallyClose;
  }

  function findVisibleRocketOptionsNearInput(input, value) {
    if (!input) return [];
    var target = String(value || "").trim().toLowerCase();
    if (!target) return [];
    return Array.prototype.slice.call(document.querySelectorAll("div,span,li,[role='option'],[data-value]")).filter(function (node) {
      if (!node || !AF.DomUtils.isElementVisible(node)) return false;
      if (node.closest && node.closest(".rocket-select")) return false;
      if (!isNodeNearInput(node, input)) return false;
      var text = optionText(node).toLowerCase();
      if (!text || /没有找到学校|添加学校全称|暂无数据|无匹配结果|loading|加载中/i.test(text)) return false;
      return text === target || (text.indexOf(target) !== -1 && text.length <= target.length + 2);
    });
  }

  function findRocketOptionsFromPoint(input, value) {
    if (!input || !input.getBoundingClientRect || !document.elementsFromPoint) return [];
    var target = String(value || input.value || "").trim().toLowerCase();
    if (!target) return [];
    var rect = input.getBoundingClientRect();
    var xs = [rect.left + 18, rect.left + rect.width / 2, rect.right - 18];
    var ys = [];
    for (var y = rect.bottom + 8; y <= rect.bottom + 260; y += 18) ys.push(y);
    var nodes = [];
    ys.forEach(function (y) {
      xs.forEach(function (x) {
        Array.prototype.slice.call(document.elementsFromPoint(x, y)).forEach(function (node) {
          if (!node || nodes.indexOf(node) !== -1) return;
          if (!AF.DomUtils.isElementVisible(node)) return;
          if (node.closest && node.closest(".rocket-select")) return;
          var text = optionText(node).toLowerCase();
          if (!text || /没有找到学校|添加学校全称|暂无数据|无匹配结果|loading|加载中/i.test(text)) return;
          if (text === target || (text.indexOf(target) !== -1 && text.length <= target.length + 2)) nodes.push(node);
        });
      });
    });
    return nodes;
  }

  function getRocketOptionNodes(panel, input, value) {
    var selector = [
      ".rocket-select-item-option",
      ".rocket-select-dropdown-menu-item",
      ".rocket-select-option",
      "[class*='rocket-select'][class*='option']",
      "[role='option']",
      "[data-value]",
      "li",
      "div"
    ].join(",");
    var nodes = Array.prototype.slice.call((panel || document).querySelectorAll(selector)).filter(function (node) {
      if (!node || !AF.DomUtils.isElementVisible(node)) return false;
      if (node.closest && node.closest(".rocket-select")) return false;
      var text = optionText(node);
      if (!text || /暂无数据|无匹配结果|loading|加载中|没有找到学校|添加学校全称/i.test(text)) return false;
      return true;
    });
    var nearNodes = findVisibleRocketOptionsNearInput(input, value);
    nearNodes.forEach(function (node) {
      if (nodes.indexOf(node) === -1) nodes.push(node);
    });
    var pointNodes = findRocketOptionsFromPoint(input, value);
    pointNodes.forEach(function (node) {
      if (nodes.indexOf(node) === -1) nodes.push(node);
    });
    return nodes;
  }

  function findRocketListFromInput(input) {
    if (!input) return null;
    var listId = input.getAttribute("aria-controls") || input.getAttribute("aria-owns") || "";
    return listId ? document.getElementById(listId) : null;
  }

  async function waitForRocketOptions(input, panel, element, timeoutMs) {
    var started = Date.now();
    var currentPanel = panel || null;
    while (Date.now() - started < timeoutMs) {
      var list = findRocketListFromInput(input);
      currentPanel = list || currentPanel || H.findDropdown(element, "rocket");
      if (currentPanel && getRocketOptionNodes(currentPanel, input, element && element.value).length) return currentPanel;
      if (input && getRocketOptionNodes(null, input, input.value).length) return currentPanel || document.body;
      var active = findActiveOption(input);
      if (active && optionText(active)) return currentPanel || active.parentElement || active;
      await AF.Utils.sleep(180);
    }
    return currentPanel || findRocketListFromInput(input) || H.findDropdown(element, "rocket") || panel;
  }

  function findMatchingRocketOption(panel, value, input) {
    var nodes = getRocketOptionNodes(panel, input, value);
    var target = String(value || "").trim().toLowerCase();
    if (!target) return null;
    nodes.sort(function (a, b) {
      var at = optionText(a).toLowerCase();
      var bt = optionText(b).toLowerCase();
      if (at === target && bt !== target) return -1;
      if (bt === target && at !== target) return 1;
      return at.length - bt.length;
    });
    for (var i = 0; i < nodes.length; i++) {
      if (optionText(nodes[i]).toLowerCase() === target) return nodes[i];
    }
    for (var j = 0; j < nodes.length; j++) {
      var text = optionText(nodes[j]).toLowerCase();
      if (text && text.indexOf(target) !== -1 && text.length <= target.length + 2) return nodes[j];
    }
    for (var k = 0; k < nodes.length; k++) {
      var code = nodes[k].getAttribute("data-value") || nodes[k].getAttribute("value") || "";
      if (H.isOptionMatch(optionText(nodes[k]), code, value)) return nodes[k];
    }
    return null;
  }

  async function robustClickRocketOption(option, input, value) {
    if (!option) return false;
    if (await clickRocketOptionInPage(option, input, value)) {
      await AF.Utils.sleep(450);
      return true;
    }
    var target = (option.closest && option.closest(
      ".rocket-select-item-option, .rocket-select-dropdown-menu-item, .rocket-select-option, [role='option'], [data-value], li"
    )) || option;
    try {
      target.scrollIntoView({ block: "nearest", behavior: "auto" });
    } catch (e) {}
    await AF.Utils.sleep(80);
    try {
      target.focus && target.focus();
    } catch (e) {}
    var clickTargets = [option, target];
    var parent = target.parentElement;
    var hops = 0;
    while (parent && hops < 3) {
      clickTargets.push(parent);
      parent = parent.parentElement;
      hops++;
    }
    clickTargets = clickTargets.filter(function (node, index, arr) {
      return node && arr.indexOf(node) === index;
    });
    for (var t = 0; t < clickTargets.length; t++) {
      var node = clickTargets[t];
      var events = ["pointerover", "mouseover", "mousemove", "pointerdown", "mousedown", "pointerup", "mouseup", "click"];
      for (var i = 0; i < events.length; i++) {
        var eventType = events[i];
        var event;
        if (eventType.indexOf("pointer") === 0 && typeof PointerEvent !== "undefined") {
          event = new PointerEvent(eventType, {
            view: window,
            bubbles: true,
            cancelable: true,
            pointerType: "mouse",
            isPrimary: true,
            buttons: /down|move/.test(eventType) ? 1 : 0,
          });
        } else {
          event = new MouseEvent(eventType, {
            view: window,
            bubbles: true,
            cancelable: true,
            buttons: /down|move/.test(eventType) ? 1 : 0,
          });
        }
        node.dispatchEvent(event);
        await AF.Utils.sleep(15);
      }
      try {
        if (typeof node.click === "function") node.click();
      } catch (e) {}
      await AF.Utils.sleep(80);
      if (!option.isConnected || !target.isConnected) break;
    }
    return true;
  }

  function findActiveOption(input) {
    if (!input) return null;
    var activeId = input.getAttribute("aria-activedescendant") || "";
    var activeOption = activeId ? document.getElementById(activeId) : null;
    if (activeOption) return activeOption;
    var listId = input.getAttribute("aria-controls") || input.getAttribute("aria-owns") || "";
    var list = listId ? document.getElementById(listId) : null;
    if (!list) return null;
    var options = Array.prototype.slice.call(list.querySelectorAll("[role='option'], [id], li, div")).filter(function (node) {
      return AF.DomUtils.isElementVisible(node) && optionText(node);
    });
    return options[0] || null;
  }

  function shortOuterHTML(node) {
    if (!node) return "";
    var html = "";
    try {
      html = String(node.outerHTML || "");
    } catch (e) {
      html = "";
    }
    return html.replace(/\s+/g, " ").slice(0, 500);
  }

  function rocketPointSummary(input, value) {
    return findRocketOptionsFromPoint(input, value).slice(0, 8).map(function (node, index) {
      return [
        index,
        "text=" + optionText(node),
        "tag=" + String(node.tagName || "").toLowerCase(),
        "class=" + String(node.className || "").slice(0, 100),
        "html=" + shortOuterHTML(node)
      ].join(" ");
    }).join(" || ");
  }

  function rocketLiveProbeSummary(input, value) {
    var parts = [];
    var target = String(value || input && input.value || "").trim().toLowerCase();
    try {
      var rect = input && input.getBoundingClientRect && input.getBoundingClientRect();
      parts.push("inputRect=" + (rect ? [Math.round(rect.left), Math.round(rect.top), Math.round(rect.width), Math.round(rect.height)].join(",") : ""));
      parts.push("active=" + (document.activeElement && String(document.activeElement.tagName || "").toLowerCase()) + "#" + (document.activeElement && document.activeElement.id || ""));
      parts.push("value=" + (input && input.value || ""));
      parts.push("expanded=" + (input && input.getAttribute && input.getAttribute("aria-expanded") || ""));
      var exactMatches = Array.prototype.slice.call(document.querySelectorAll("div,span,li,[role='option'],[data-value]")).filter(function (node) {
        if (!node || !AF.DomUtils.isElementVisible(node)) return false;
        var text = optionText(node).toLowerCase();
        return text === target || (target && text.indexOf(target) !== -1 && text.length <= target.length + 20);
      }).slice(0, 12).map(function (node, index) {
        var r = node.getBoundingClientRect && node.getBoundingClientRect();
        return [
          index,
          "text=" + optionText(node),
          "tag=" + String(node.tagName || "").toLowerCase(),
          "class=" + String(node.className || "").slice(0, 80),
          "rect=" + (r ? [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)].join(",") : "")
        ].join(" ");
      });
      parts.push("exact=" + exactMatches.join(" || "));
      if (rect && document.elementsFromPoint) {
        var samples = [];
        var xs = [rect.left + 20, rect.left + rect.width / 2, rect.right - 20];
        var ys = [rect.bottom + 8, rect.bottom + 24, rect.bottom + 40, rect.bottom + 60, rect.bottom + 90, rect.bottom + 130];
        ys.forEach(function (y) {
          xs.forEach(function (x) {
            var stack = document.elementsFromPoint(x, y).slice(0, 5).map(function (node) {
              return String(node.tagName || "").toLowerCase() + "." + String(node.className || "").slice(0, 40) + ":" + optionText(node).slice(0, 40);
            }).join(">");
            samples.push(Math.round(x) + "," + Math.round(y) + "=" + stack);
          });
        });
        parts.push("points=" + samples.join(" || "));
      }
    } catch (e) {
      parts.push("probeError=" + (e && e.message || e));
    }
    return parts.join(" ; ");
  }

  function traceRocketProbe(input, value, reason) {
    if (!AF.FillTrace || !AF.FillTrace.event) return;
    try {
      AF.FillTrace.event("rocket_probe", "value=" + value + " ; reason=" + reason + " ; " + rocketLiveProbeSummary(input, value), "debug");
    } catch (e) {}
  }

  function rocketOptionSummary(input, panel, value) {
    var activeId = input && (input.getAttribute("aria-activedescendant") || "");
    var listId = input && (input.getAttribute("aria-controls") || input.getAttribute("aria-owns") || "");
    var active = activeId ? document.getElementById(activeId) : null;
    var list = listId ? document.getElementById(listId) : null;
    var scope = panel || list || document;
    var options = getRocketOptionNodes(scope, input, value).slice(0, 10).map(function (node, index) {
      return [
        index,
        "text=" + optionText(node),
        "id=" + (node.id || ""),
        "class=" + String(node.className || "").slice(0, 100),
        "role=" + (node.getAttribute && node.getAttribute("role") || ""),
        "selected=" + (node.getAttribute && (node.getAttribute("aria-selected") || node.getAttribute("data-selected")) || "")
      ].join(" ");
    });
    return [
      "activeId=" + activeId,
      "listId=" + listId,
      "activeFound=" + !!active,
      "listFound=" + !!list,
      "panelFound=" + !!panel,
      "activeHTML=" + shortOuterHTML(active),
      "listHTML=" + shortOuterHTML(list),
      "options=" + options.join(" || "),
      "pointOptions=" + rocketPointSummary(input, value)
    ].join(" ; ");
  }

  function traceRocketDebug(input, panel, value, reason) {
    if (!AF.FillTrace || !AF.FillTrace.event) return;
    try {
      AF.FillTrace.event("rocket_debug", "value=" + value + " ; reason=" + reason + " ; " + rocketOptionSummary(input, panel, value), "debug");
    } catch (e) {}
  }

  async function forceCommitByActiveOption(input, container, value) {
    var activeOption = findActiveOption(input);
    if (!activeOption) return false;
    await robustClickRocketOption(activeOption, input, value);
    await AF.Utils.sleep(500);
    if (selectedMatches(container, value)) return true;
    var trigger = container && container.querySelector && container.querySelector(".rocket-select-selector");
    if (trigger) {
      await AF.DomUtils.safeClickElement(trigger);
      await AF.Utils.sleep(120);
      activeOption = findActiveOption(input) || activeOption;
      await robustClickRocketOption(activeOption, input, value);
      await AF.Utils.sleep(500);
      if (selectedMatches(container, value)) return true;
    }
    return false;
  }

  async function commitActiveRocketOption(input, container, value) {
    if (!input) return false;
    if (await forceCommitByActiveOption(input, container, value)) return true;
    pressEnter(input);
    await AF.Utils.sleep(350);
    if (selectedMatches(container, value)) return true;
    input.dispatchEvent(new KeyboardEvent("keydown", {
      bubbles: true,
      cancelable: true,
      composed: true,
      key: "Tab",
      code: "Tab",
      keyCode: 9,
      which: 9,
    }));
    input.dispatchEvent(new Event("blur", { bubbles: true, cancelable: true, composed: true }));
    await AF.Utils.sleep(250);
    return selectedMatches(container, value);
  }

  async function selectMatchingRocketOption(panel, container, input, value) {
    var option = findMatchingRocketOption(panel, value, input);
    if (!option) return false;
    var before = selectedText(container);
    await robustClickRocketOption(option, input, value);
    await AF.Utils.sleep(450);
    var after = selectedText(container);
    return H.isOptionMatch(after, after, value) || (!!after && after !== before && H.isOptionMatch(after, after, value));
  }

  async function selectOneRocketValue(element, rawValue) {
    var value = normalizeKeyword(rawValue);
    if (!value) return false;
    var container = (element.closest && element.closest(CFG.container)) || element;
    var trigger = container.querySelector(CFG.trigger) || container;
    var input = container.querySelector("input.rocket-select-selection-search-input, input[type='search'], input[type='text']");

    if (selectedMatches(container, value)) return true;

    await AF.DomUtils.safeClickElement(trigger);
    await AF.Utils.sleep(150);
    if (input) {
      try {
        input.focus && input.focus();
      } catch (e) {}
      await typeRocketSearchInput(input, value);
      traceRocketProbe(input, value, "after_type_before_point_click");
      if (await clickRocketFirstOptionByPointInPage(input, value)) {
        await AF.Utils.sleep(500);
        traceRocketProbe(input, value, "after_point_click");
        if (selectedMatches(container, value)) {
          H.dispatchChangeEvents(element);
          H.dispatchChangeEvents(input);
          return true;
        }
      }
      if (await clickRocketAddSchoolFullNameInPage(input, value)) {
        await AF.Utils.sleep(500);
        traceRocketProbe(input, value, "after_add_school_full_name");
        if (selectedMatches(container, value)) {
          H.dispatchChangeEvents(element);
          H.dispatchChangeEvents(input);
          return true;
        }
      }
    }

    var panel = await H.waitForVisibleDropdownNear(element, CFG.panelSelectors, CFG.container, 4000);
    if (!panel) panel = H.findDropdown(element, "rocket");
    if (!panel && input) {
      var activeOk = await commitActiveRocketOption(input, container, value);
      if (activeOk) return true;
      pressEnter(input);
      await AF.Utils.sleep(300);
      var enterOk = selectedMatches(container, value);
      if (!enterOk) traceRocketDebug(input, panel, value, "no_panel_after_enter");
      return enterOk;
    }
    if (!panel) {
      traceRocketDebug(input, panel, value, "no_panel_no_input");
      return false;
    }
    if (input) {
      panel = await waitForRocketOptions(input, panel, element, 6000);
      if (!getRocketOptionNodes(panel, input, value).length && !findActiveOption(input)) {
        setInputValue(input, value);
        await AF.Utils.sleep(900);
        panel = await waitForRocketOptions(input, panel, element, 2500);
      }
    }

    var ok = await commitActiveRocketOption(input, container, value);
    if (!ok) ok = await selectMatchingRocketOption(panel, container, input, value);
    if (!ok && input) {
      await AF.Utils.sleep(600);
      ok = await commitActiveRocketOption(input, container, value);
      if (!ok) ok = await selectMatchingRocketOption(panel, container, input, value);
    }
    if (!ok && input) {
      pressEnter(input);
      await AF.Utils.sleep(300);
      ok = selectedMatches(container, value);
    }
    if (!ok) traceRocketDebug(input, panel, value, "select_failed");
    H.dispatchChangeEvents(element);
    if (input) H.dispatchChangeEvents(input);
    return ok;
  }

  async function triggerRocketSelect(element, value) {
    try {
      var normalized = normalizeKeyword(value);
      if (Array.isArray(normalized)) {
        var ok = false;
        for (var i = 0; i < normalized.length; i++) {
          if (await selectOneRocketValue(element, normalized[i])) ok = true;
          await AF.Utils.sleep(150);
        }
        return ok;
      }
      return await selectOneRocketValue(element, normalized);
    } catch (e) {
      return false;
    }
  }

  SA._registry["rocket"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        return await triggerRocketSelect(element, value);
      },
    };
  };
})();
