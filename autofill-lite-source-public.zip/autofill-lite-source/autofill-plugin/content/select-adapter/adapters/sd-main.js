// content/select-adapter/adapters/sd-main.js
// Runs in the page's main world. Moka sd selects are React controlled searchable
// dropdowns, so isolated-world DOM events can show options without committing.
(function () {
  "use strict";
  if (window.__AFSdMainBridge) return;
  window.__AFSdMainBridge = true;

  function sleep(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, ms);
    });
  }

  function esc(value) {
    if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(String(value));
    return String(value).replace(/['"\\]/g, "\\$&");
  }

  function setNativeValue(input, value) {
    var text = String(value == null ? "" : value);
    input.removeAttribute && input.removeAttribute("readonly");
    input.readOnly = false;
    var previous = input.value;
    var descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
    if (descriptor && descriptor.set) descriptor.set.call(input, text);
    else input.value = text;
    if (input._valueTracker && typeof input._valueTracker.setValue === "function") {
      input._valueTracker.setValue(previous);
    }
    input.setAttribute && input.setAttribute("value", text);
  }

  function textOf(node) {
    return String(
      node && (
        node.textContent ||
        node.getAttribute && (
          node.getAttribute("title") ||
          node.getAttribute("aria-label") ||
          node.getAttribute("data-value") ||
          node.getAttribute("value")
        )
      ) || ""
    ).replace(/\s+/g, " ").trim();
  }

  function norm(value) {
    return String(value == null ? "" : value).replace(/\s+/g, "").toLowerCase();
  }

  function isVisible(node) {
    if (!node || !node.getBoundingClientRect) return false;
    var style = window.getComputedStyle ? window.getComputedStyle(node) : null;
    if (style && (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0)) return false;
    var rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function reactPropsOf(node) {
    if (!node) return null;
    var keys = Object.keys(node);
    for (var i = 0; i < keys.length; i++) {
      if (keys[i].indexOf("__reactProps$") === 0 || keys[i].indexOf("__reactEventHandlers$") === 0) {
        return node[keys[i]];
      }
    }
    return null;
  }

  function syntheticEvent(type, target, currentTarget, x, y, keyValue) {
    var keyCodeMap = { Enter: 13, ArrowDown: 40, Down: 40, Backspace: 8 };
    var keyCode = keyCodeMap[keyValue] || (keyValue && keyValue.length === 1 ? keyValue.charCodeAt(0) : 0);
    return {
      type: type,
      target: target,
      currentTarget: currentTarget,
      nativeEvent: {
        type: type,
        target: target,
        currentTarget: currentTarget,
        clientX: x || 0,
        clientY: y || 0,
        button: 0,
        buttons: /down|move/.test(type) ? 1 : 0,
        key: keyValue || "",
        code: keyValue || "",
        keyCode: keyCode,
        which: keyCode,
        data: target && target.value,
      },
      clientX: x || 0,
      clientY: y || 0,
      button: 0,
      buttons: /down|move/.test(type) ? 1 : 0,
      key: keyValue || "",
      code: keyValue || "",
      keyCode: keyCode,
      which: keyCode,
      data: target && target.value,
      bubbles: true,
      cancelable: true,
      defaultPrevented: false,
      isPropagationStopped: function () { return false; },
      isDefaultPrevented: function () { return false; },
      persist: function () {},
      preventDefault: function () { this.defaultPrevented = true; },
      stopPropagation: function () {},
    };
  }

  function invokeReact(node, names, x, y, keyValue, eventTarget) {
    var chain = [];
    var cur = node;
    while (cur && chain.length < 7) {
      chain.push(cur);
      cur = cur.parentElement;
    }
    var called = false;
    chain.forEach(function (el) {
      var props = reactPropsOf(el);
      if (!props) return;
      names.forEach(function (name) {
        if (typeof props[name] !== "function") return;
        try {
          props[name](syntheticEvent(name.slice(2).toLowerCase(), eventTarget || node, el, x, y, keyValue));
          called = true;
        } catch (e) {}
      });
    });
    return called;
  }

  function key(input, type, value, extra) {
    var opts = {
      bubbles: true,
      cancelable: true,
      composed: true,
      key: value || "",
      code: value && value.length === 1 ? "Key" + value.toUpperCase() : value || "",
      keyCode: value && value.length === 1 ? value.charCodeAt(0) : 0,
      which: value && value.length === 1 ? value.charCodeAt(0) : 0,
    };
    if (extra) Object.keys(extra).forEach(function (name) { opts[name] = extra[name]; });
    input.dispatchEvent(new window.KeyboardEvent(type, opts));
  }

  function inputEvent(input, inputType, data) {
    try {
      input.dispatchEvent(new window.InputEvent("beforeinput", {
        bubbles: true,
        cancelable: true,
        composed: true,
        inputType: inputType,
        data: data || null,
      }));
    } catch (e) {}
    input.dispatchEvent(new window.InputEvent("input", {
      bubbles: true,
      cancelable: true,
      composed: true,
      inputType: inputType,
      data: data || null,
    }));
  }

  async function typeSearch(input, value) {
    var text = String(value == null ? "" : value);
    input.removeAttribute && input.removeAttribute("readonly");
    input.readOnly = false;
    input.focus && input.focus();
    input.dispatchEvent(new window.FocusEvent("focus", { bubbles: true, composed: true }));
    input.dispatchEvent(new window.MouseEvent("mousedown", { bubbles: true, cancelable: true, composed: true, view: window }));
    input.dispatchEvent(new window.MouseEvent("mouseup", { bubbles: true, cancelable: true, composed: true, view: window }));
    input.dispatchEvent(new window.MouseEvent("click", { bubbles: true, cancelable: true, composed: true, view: window }));

    setNativeValue(input, "");
    key(input, "keydown", "Backspace", { code: "Backspace", keyCode: 8, which: 8 });
    inputEvent(input, "deleteContentBackward", null);
    invokeReact(input, ["onKeyDown", "onInput", "onChange"], 0, 0, "Backspace", input);
    key(input, "keyup", "Backspace", { code: "Backspace", keyCode: 8, which: 8 });
    await sleep(80);

    input.dispatchEvent(new window.CompositionEvent("compositionstart", { bubbles: true, composed: true, data: "" }));
    invokeReact(input, ["onCompositionStart"], 0, 0, "");
    var composed = "";
    for (var i = 0; i < text.length; i++) {
      var ch = text.charAt(i);
      composed += ch;
      key(input, "keydown", ch);
      key(input, "keypress", ch);
      input.dispatchEvent(new window.CompositionEvent("compositionupdate", { bubbles: true, composed: true, data: composed }));
      setNativeValue(input, composed);
      inputEvent(input, "insertCompositionText", ch);
      inputEvent(input, "insertText", ch);
      invokeReact(input, ["onKeyDown", "onKeyPress", "onCompositionUpdate", "onInput", "onChange"], 0, 0, ch, input);
      key(input, "keyup", ch);
      invokeReact(input, ["onKeyUp"], 0, 0, ch, input);
      await sleep(60);
    }
    input.dispatchEvent(new window.CompositionEvent("compositionend", { bubbles: true, composed: true, data: text }));
    invokeReact(input, ["onCompositionEnd"], 0, 0, "", input);
    setNativeValue(input, text);
    inputEvent(input, "insertText", text);
    input.dispatchEvent(new window.Event("search", { bubbles: true, cancelable: true, composed: true }));
    input.dispatchEvent(new window.Event("change", { bubbles: true, cancelable: true, composed: true }));
    invokeReact(input, ["onInput", "onChange", "onSearch"], 0, 0, "", input);
    await sleep(180);
    return input.value;
  }

  async function clickLikeUser(node) {
    if (!node) return false;
    node = (node.closest && node.closest("[class*='sd-Select-common-item'], [class*='sd-Menu-content-item'], [class*='sd-Menu-container'], [role='option'], [data-value], li")) || node;
    try {
      node.scrollIntoView({ block: "nearest", behavior: "auto" });
    } catch (e) {}
    await sleep(80);
    var rect = node.getBoundingClientRect && node.getBoundingClientRect();
    var x = rect ? rect.left + Math.max(3, Math.min(rect.width / 2, rect.width - 3)) : 0;
    var y = rect ? rect.top + Math.max(3, Math.min(rect.height / 2, rect.height - 3)) : 0;
    var target = (x && y && document.elementFromPoint) ? document.elementFromPoint(x, y) : node;
    target = target || node;
    var chain = [target, node];
    var parent = node.parentElement;
    var hops = 0;
    while (parent && hops < 3) {
      chain.push(parent);
      parent = parent.parentElement;
      hops++;
    }
    chain = chain.filter(function (item, index, arr) {
      return item && arr.indexOf(item) === index;
    });
    for (var i = 0; i < chain.length; i++) {
      var el = chain[i];
      invokeReact(el, ["onMouseEnter", "onMouseMove"], x, y, "");
      var events = ["pointerover", "mouseover", "mousemove", "pointerdown", "mousedown", "pointerup", "mouseup", "click"];
      for (var eventIndex = 0; eventIndex < events.length; eventIndex++) {
        var type = events[eventIndex];
        if (type === "pointerdown") invokeReact(el, ["onPointerDown"], x, y, "");
        if (type === "mousedown") invokeReact(el, ["onMouseDown"], x, y, "");
        if (type === "pointerup") invokeReact(el, ["onPointerUp"], x, y, "");
        if (type === "mouseup") invokeReact(el, ["onMouseUp"], x, y, "");
        if (type === "click") invokeReact(el, ["onClick"], x, y, "");
        var ev;
        if (type.indexOf("pointer") === 0 && window.PointerEvent) {
          ev = new window.PointerEvent(type, {
            view: window,
            bubbles: true,
            cancelable: true,
            composed: true,
            pointerType: "mouse",
            isPrimary: true,
            clientX: x,
            clientY: y,
            button: 0,
            buttons: /down|move/.test(type) ? 1 : 0,
          });
        } else {
          ev = new window.MouseEvent(type, {
            view: window,
            bubbles: true,
            cancelable: true,
            composed: true,
            clientX: x,
            clientY: y,
            button: 0,
            which: 1,
            buttons: /down|move/.test(type) ? 1 : 0,
          });
        }
        el.dispatchEvent(ev);
        if (type === "mousedown" || type === "mouseup" || type === "click") await sleep(60);
      }
      try {
        if (typeof el.click === "function") el.click();
      } catch (e) {}
      await sleep(90);
    }
    return true;
  }

  function findOptionByToken(token) {
    return document.querySelector("[data-af-sd-option-token='" + esc(token) + "']");
  }

  function findOptionByInputAndValue(inputToken, value) {
    var input = document.querySelector("[data-af-sd-token='" + esc(inputToken) + "']");
    var target = norm(value || "");
    var candidates = [];
    Array.prototype.slice.call(document.querySelectorAll(
      ".sugar-portal [class*='sd-Select-common-item'], .sugar-portal [class*='sd-Menu-content-item'], .sugar-portal [class*='sd-Menu-container'], [class*='sd-Dropdown'][class*='dropdown'] [class*='sd-Select-common-item'], [class*='sd-Dropdown'][class*='dropdown'] [class*='sd-Menu-content-item'], [role='listbox'] [role='option'], [role='option'], [data-value], li, div, span"
    )).forEach(function (node) {
      if (!isVisible(node)) return;
      var text = textOf(node);
      if (!text || /暂无|无匹配|没有|loading|加载中/i.test(text)) return;
      if (!input || isNearInput(node, input)) candidates.push(node);
    });
    for (var i = 0; i < candidates.length; i++) {
      if (norm(textOf(candidates[i])) === target) return candidates[i];
    }
    for (var j = 0; j < candidates.length; j++) {
      var text = norm(textOf(candidates[j]));
      if (text && (text.indexOf(target) !== -1 || target.indexOf(text) !== -1)) return candidates[j];
    }
    return null;
  }

  function isNearInput(node, input) {
    if (!node || !input || !node.getBoundingClientRect || !input.getBoundingClientRect) return true;
    var nr = node.getBoundingClientRect();
    var ir = input.getBoundingClientRect();
    var horizontalOverlap = Math.min(nr.right, ir.right + 140) - Math.max(nr.left, ir.left - 140);
    var nearY = Math.abs(nr.top - ir.bottom) < 560 || Math.abs(nr.bottom - ir.top) < 560;
    return horizontalOverlap > 0 && nearY;
  }

  window.addEventListener("message", async function (event) {
    if (event.source !== window) return;
    var data = event.data || {};
    if (!data || ["AF_SD_PING_REQUEST", "AF_SD_TYPE_REQUEST", "AF_SD_CLICK_REQUEST", "AF_SD_LEAF_CLICK_REQUEST"].indexOf(data.type) === -1) return;
    if (data.type === "AF_SD_PING_REQUEST") {
      window.postMessage({ type: "AF_SD_PING_RESULT", id: data.id, ok: true }, "*");
      return;
    }
    var ok = false;
    var error = "";
    var value = "";
    try {
      if (data.type === "AF_SD_TYPE_REQUEST") {
        var input = document.querySelector("[data-af-sd-token='" + esc(data.token) + "']");
        if (!input) throw new Error("input_not_found");
        value = await typeSearch(input, data.value || "");
      } else if (data.type === "AF_SD_CLICK_REQUEST") {
        var inputForClick = data.inputToken ? document.querySelector("[data-af-sd-token='" + esc(data.inputToken) + "']") : null;
        var option = findOptionByToken(data.token) || findOptionByInputAndValue(data.inputToken, data.value);
        if (!option) throw new Error("option_not_found");
        value = textOf(option);
        await clickLikeUser(option);
        if (inputForClick) {
          await sleep(160);
          inputForClick.dispatchEvent(new window.Event("change", { bubbles: true, cancelable: true, composed: true }));
        }
      } else if (data.type === "AF_SD_LEAF_CLICK_REQUEST") {
        var optionRoot = document.querySelector("[data-af-sd-leaf-token='" + esc(data.token) + "']");
        if (!optionRoot) throw new Error("leaf_option_not_found");
        var leaves = [];
        try {
          leaves = Array.prototype.slice.call(optionRoot.querySelectorAll("*:not(:has(*))"));
        } catch (leafQueryError) {
          leaves = Array.prototype.slice.call(optionRoot.querySelectorAll("div, span"));
        }
        var leaf = leaves.find(function (item) {
          return String(item && item.textContent || "").trim().length > 0;
        }) || optionRoot;
        value = textOf(leaf);
        leaf.click();
        try { document.body.click(); } catch (bodyClickError) {}
        await sleep(100);
      }
      ok = true;
    } catch (e) {
      error = e && e.message ? e.message : String(e);
    }
    window.postMessage({
      type: data.type === "AF_SD_LEAF_CLICK_REQUEST"
        ? "AF_SD_LEAF_CLICK_RESULT"
        : data.type === "AF_SD_CLICK_REQUEST"
          ? "AF_SD_CLICK_RESULT"
          : "AF_SD_TYPE_RESULT",
      id: data.id,
      ok: ok,
      value: value,
      error: error,
    }, "*");
  });
})();
