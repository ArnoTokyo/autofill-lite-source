// content/form-handler.js — FormHandler (源码 rt 类, 导出 y.j, 行 12825-13740)
//                            + fillFormElement 静态分发 (行 56136-56200)
//                            + 8 种类型 handler (handleText/Radio/Checkbox/Select/
//                              MultiSelect/Date/SearchInput/ContentEditable)
//
// 源码参考 (/Users/dayu/Desktop/网页端/原始代码和索引/content.readable.js):
//   FormHandler 类定义+构造函数:  行 12825-12844
//   fillBasicInfo:               行 12884-13113
//   fillLabels (核心循环):        行 13114-13227
//   fillSimpleForm:              行 13228-13270
//   fillExperience (总入口):      行 13271-13319 (新版方案 experienceHandler + 旧版兜底)
//   fillExperienceLegacy:        行 13320-13717 (~400行, 依赖 findContainerByTitle/
//                                 findLabelsByCard/findAddButton 等 ElementMatcher 私有方法)
//   fillMatchInfo:                行 13718-13740 (已删除, 属于下线的AI竞赛字段匹配功能)
//   getTitleValue:                行 13901-13903 (委托 elementMatcher.getTitleValue,
//                                 真正实现在行 68559: input/textarea 取 .value, 否则取 .textContent)
//   fillFormElement 分发:         行 56136-56200
//   handleText:                   行 53111-53194 (最关键代码块, 行 53144-53165 原样照搬)
//   handleRadio / handleGenderRadio: 行 53835-53987
//   handleCheckbox:               行 54054-54073
//   handleDate:                   行 48530-48560 (委托 AF.DatePicker，本文件不重复实现)
//   handleSearchInput:            行 50934-51043
//   handleContentEditable:        行 54661-54740
//   handleMultiSelect:            行 55503-55545
//
// ============================================================================
// 关于 fillExperience 的重要说明 (任务书要求必须写清楚):
//   源码 fillExperienceLegacy (行13320-13717, 约400行) + fillExperienceByNewScheme
//   (行11146起, 依赖 ExperienceHandler/ConfigAdapter 两个类和站点 experienceConfig
//   结构, 又是约300行) 加起来接近2000行，核心思路是：
//     1. 用 elementMatcher.findContainerByTitle/findLabelsByCard 等"私有"方法定位
//        分区容器和已有的 label 元素；
//     2. 把 label 按文字分组，同名 label 出现几次就代表页面已经有几张卡片；
//     3. 需要几张卡片 = 简历数组长度 - 已有卡片数，不够就循环点"添加"按钮；
//     4. 点完后重新分组 label，第 i 组的第 col 个元素，就对应简历数组第 col 条数据；
//     5. 每一"列"当成一次 fillLabels 调用。
//   本文件是"忠实于意图的简化版"，不是逐行搬运：
//     - findContainerByTitle/findLabelsByCard/findAddButton/findExperienceToggle(旧版)
//       这些方法在原版里是 ElementMatcher 的私有实现细节，重建版 ElementMatcher 的
//       约定契约里只保证 findAllLabels()/findElementAndTypeByLabel()/findElementByType()
//       三个方法，所以这里改为：自己从 sectionEl(标题元素) 出发向上寻找最近的卡片容器
//       (findSectionContainer)，再用 elementMatcher.findAllLabels() 结果按 container.contains
//       过滤出"属于这个分区"的 label (labelsWithinContainer)。
//     - "添加"按钮改为通用查找 (findAddButtonIn): 优先 AF.SELECTORS.addButton 选择器，
//       退化到关键词 新增/添加/新建/增加/add/new/create 匹配可见的 button/a/[role=button]。
//     - "有没有经历"开关直接复用已实现的 AF.DomUtils.findExperienceToggle，不重新实现。
//     - fillExperienceByNewScheme 依赖的站点 experienceConfig 结构由站点加载模块
//       (另一个并行 agent) 负责，本文件不做站点专属适配，只有通用兜底逻辑。
//     - options.allowInternToWork / allowWorkToIntern / disableOtherLanguage 这几个
//       标志按约定契约直接透传给 dataMatcher.getCategoryByTitle(title, options)，由
//       DataMatcher 决定具体走哪个简历数组，FormHandler 自己不重新判断。
//   这是整个任务里近似度最高的一块，如果之后要接入站点专属 experienceConfig，
//   应该在这个文件之外新增一个"新版方案" handler，再让 fillExperience 优先尝试它。
// ============================================================================
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});

  // Tencent long-text diagnosis.  This state deliberately contains structure
  // only: no planned value, control value, or arbitrary card text is retained.
  function updateTencentLongTextDebug(kind, payload) {
    if (!/^join\.qq\.com$/i.test(location.hostname || "")) return;
    try {
      var root = document.documentElement;
      var state = JSON.parse(root.getAttribute("data-af-longtext-debug") || "{}");
      state.recordScopeDebug = Array.isArray(state.recordScopeDebug) ? state.recordScopeDebug : [];
      state.structuredPlanDebug = Array.isArray(state.structuredPlanDebug) ? state.structuredPlanDebug : [];
      state.longTextTrace = state.longTextTrace && typeof state.longTextTrace === "object" ? state.longTextTrace : {};
      if (kind === "scope") state.recordScopeDebug.push(payload);
      if (kind === "plan") state.structuredPlanDebug.push(payload);
      if (kind === "writer") state.longTextTrace[payload.key] = payload.value;
      root.setAttribute("data-af-longtext-debug", JSON.stringify(state));
    } catch (e) {}
  }

  function visibleTencentTextareaSummary(scope) {
    if (!scope) return { inputCount: 0, textareaCount: 0, contentEditableCount: 0, visibleTextareaPlaceholders: [] };
    var visible = function (el) {
      var rect = el.getBoundingClientRect(), style = getComputedStyle(el);
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
    };
    var textareas = Array.from(scope.querySelectorAll("textarea")).filter(visible);
    return {
      inputCount: Array.from(scope.querySelectorAll("input")).filter(visible).length,
      textareaCount: textareas.length,
      contentEditableCount: Array.from(scope.querySelectorAll('[contenteditable="true"], [role="textbox"]')).filter(visible).length,
      visibleTextareaPlaceholders: textareas.map(function (el) { return String(el.getAttribute("placeholder") || ""); }).filter(Boolean)
    };
  }

  function isLongTextField(fieldKey) {
    return ["detailedContent", "details", "description", "示例资料Introduction", "示例资料Content", "示例资料Content", "responsibility", "achievement"].indexOf(String(fieldKey || "")) !== -1;
  }

  function isLongTextControl(element) {
    if (!element || !(element instanceof HTMLElement)) return false;
    var tag = String(element.tagName || "").toUpperCase();
    return tag === "TEXTAREA" || element.isContentEditable ||
      (element.matches && (element.matches('[contenteditable="true"]') || element.matches('[role="textbox"]')));
  }

  function normalizeLongText(value) {
    return String(value == null ? "" : value).replace(/\r\n?/g, "\n").replace(/[ \t]+$/gm, "").trim();
  }

  function tencentDescriptionValue(rowData) {
    var values = [rowData && rowData.detailedContent, rowData && rowData.result]
      .map(function (item) { return normalizeLongText(item); }).filter(Boolean);
    return values.filter(function (item, index) {
      return values.findIndex(function (candidate) { return candidate === item; }) === index;
    }).join("\n");
  }

  AF.FillTrace = AF.FillTrace || (function () {
    var state = { startedAt: 0, finishedAt: 0, module: "", records: [], events: [], context: null };

    function valueText(value) {
      if (value == null) return "";
      if (typeof value === "boolean") return value ? "是" : "否";
      if (typeof value === "object") {
        if (value.startTime || value.endTime) return [value.startTime, value.endTime].filter(Boolean).join(" ~ ");
        try { return JSON.stringify(value); } catch (e) { return String(value); }
      }
      return String(value).trim();
    }

    function readElementValue(element) {
      if (!element) return "";
      if (Array.isArray(element) || (typeof element.length === "number" && !element.tagName)) {
        return Array.from(element).map(readElementValue).filter(Boolean).join(" / ");
      }
      try {
        var phoneBox = element.closest && element.closest(".cpo-phone-select");
        if (phoneBox) {
          var phoneCountry = phoneBox.querySelector(".cpo-phone-select-inner .next-select-values em");
          var countryText = String(phoneCountry && phoneCountry.getAttribute("title") || phoneCountry && phoneCountry.textContent || "").trim();
          var phoneInput = phoneBox.querySelector(".cpo-phone-select-number input");
          var numberText = String(phoneInput && phoneInput.value || "").trim();
          return [countryText, numberText].filter(Boolean).join(" ");
        }
      } catch (e) {}
      try {
        var sdDropdown = element.closest && element.closest('[class^="sd-Dropdown-container"], [class*=" sd-Dropdown-container"]');
        // 年月范围由多个 SD 下拉组成，必须留给下面的范围读取，不能只返回第一个“年份”。
        var sdYearMonthScope = nearestYearMonthScope(element);
        if (sdDropdown && !sdYearMonthScope) {
          var sdDisplayInDropdown = sdDropdown.querySelector("[class*='sd-Input-display-value']");
          var sdDropdownText = String(sdDisplayInDropdown && sdDisplayInDropdown.textContent || "").replace(/\s+/g, " ").trim();
          if (sdDropdownText && !/^(请选择|请输入|Select)$/i.test(sdDropdownText)) return sdDropdownText;
          return "";
        }
      } catch (e) {}
      try {
        var nextSelect = element.closest && element.closest(".next-select");
        if (nextSelect) {
          var nextText = Array.from(nextSelect.querySelectorAll(
            ".next-tag-body, .next-select-values em[title], .next-select-value, .next-select-selection-item"
          )).map(function (node) {
            return node.getAttribute && node.getAttribute("title") || node.textContent || "";
          }).join(" ").replace(/\s+/g, " ").trim();
          if (nextText && !/^(请选择|请输入|Select|务必输入学校全称)/i.test(nextText)) return nextText;
        }
      } catch (e) {}
      try {
        var genericYmScope = nearestYearMonthScope(element);
        if (genericYmScope) {
          var ymValues = readYearMonthScopeValues(genericYmScope);
          if (ymValues[0] && ymValues[1]) {
            var startYm = ymValues[0] + "-" + String(parseInt(ymValues[1], 10)).padStart(2, "0");
            if (ymValues[2] && ymValues[3]) {
              return startYm + " ~ " + ymValues[2] + "-" + String(parseInt(ymValues[3], 10)).padStart(2, "0");
            }
            if (isCurrentEndChecked(genericYmScope)) return startYm + " ~ 至今";
            return startYm;
          }
        }
      } catch (e) {}
      try {
        var splitYmScope = element.closest && (
          element.closest(".resume-module-left, .resume-module-right, .end-time") ||
          element.closest(".start-time-module")
        );
        if (splitYmScope && splitYmScope.querySelector(".required-year, .required-month")) {
          var yearText = String((splitYmScope.querySelector(".required-year, .select-left") || {}).textContent || "").trim();
          var monthText = String((splitYmScope.querySelector(".required-month, .select-right") || {}).textContent || "").trim();
          var yearMatch = yearText.match(/\d{4}/);
          var monthMatch = monthText.match(/\d{1,2}/);
          if (yearMatch && monthMatch && !/^年$/.test(yearText) && !/^月$/.test(monthText)) {
            return yearMatch[0] + "-" + String(parseInt(monthMatch[0], 10)).padStart(2, "0");
          }
          if (yearMatch && !/^年$/.test(yearText)) return yearMatch[0];
        }
      } catch (e) {}
      var rangeContainer = null;
      try {
        rangeContainer =
          (element.matches && element.matches(".el-range-editor, .ant-picker-range, .ant-calendar-range-picker, .throne-biz-date-range-picker-wrapper, .next-range-picker") ? element : null) ||
          (element.closest && element.closest(".el-range-editor, .ant-picker-range, .ant-calendar-range-picker, .throne-biz-date-range-picker-wrapper, .next-range-picker"));
        if (!rangeContainer) {
          var antV3Picker = element.closest && element.closest(".ant-calendar-picker");
          if (antV3Picker && antV3Picker.querySelectorAll(".ant-calendar-range-picker-input").length >= 2) {
            rangeContainer = antV3Picker;
          }
        }
      } catch (e) {
        rangeContainer = null;
      }
      if (rangeContainer) {
        var rangeValues = Array.from(rangeContainer.querySelectorAll("input"))
          .filter(function (input) { return !AF.DomUtils || AF.DomUtils.isElementVisible(input); })
          .map(function (input) { return String(input.value || "").trim(); })
          .filter(Boolean);
        if (rangeValues.length > 1) return rangeValues.join(" ~ ");
        if (rangeValues.length === 1) {
          var rangeField = rangeContainer.closest && rangeContainer.closest(
            ".ud-formily-item, .ant-form-item, .el-form-item, [class*='form-item']"
          );
          var currentControls = rangeField ? Array.from(rangeField.querySelectorAll(
            "label, button, [role='checkbox'], [role='switch'], input[type='checkbox'], input[type='radio']"
          )) : [];
          var hasCurrent = currentControls.some(function (node) {
            var wrapper = node.closest && node.closest("label, button, [role='checkbox'], [role='switch']") || node;
            var text = String(wrapper.textContent || wrapper.getAttribute("aria-label") || wrapper.getAttribute("title") || "")
              .replace(/[\s:：*]/g, "");
            if (!/^(至今|目前|现在|仍在职|在职|仍在进行|当前)$/.test(text)) return false;
            var input = wrapper.matches && wrapper.matches("input[type='checkbox'], input[type='radio']")
              ? wrapper
              : wrapper.querySelector && wrapper.querySelector("input[type='checkbox'], input[type='radio']");
            var classText = String(wrapper.className || "").toLowerCase();
            return Boolean(
              input && input.checked ||
              wrapper.getAttribute && wrapper.getAttribute("aria-checked") === "true" ||
              /(^|[-_\s])(checked|selected|active)([-_\s]|$)/.test(classText)
            );
          });
          if (hasCurrent) return rangeValues[0] + " ~ 至今";
        }
      }
      try {
        var radioWrapper = element.matches && element.matches(".el-radio, .ant-radio-wrapper, [role='radio']")
          ? element
          : element.closest && element.closest(".el-radio, .ant-radio-wrapper, [role='radio']");
        if (radioWrapper) {
          var radioInput = radioWrapper.matches && radioWrapper.matches('input[type="radio"]')
            ? radioWrapper
            : radioWrapper.querySelector && radioWrapper.querySelector('input[type="radio"]');
          var radioChecked = Boolean(
            radioInput && radioInput.checked ||
            radioWrapper.getAttribute && radioWrapper.getAttribute("aria-checked") === "true" ||
            radioWrapper.classList && Array.from(radioWrapper.classList).some(function (c) {
              return /checked|selected|active/.test(String(c).toLowerCase());
            })
          );
          if (radioChecked) {
            return String(
              radioInput && radioInput.value ||
              radioWrapper.querySelector && radioWrapper.querySelector(".el-radio__label, .ant-radio-label") && radioWrapper.querySelector(".el-radio__label, .ant-radio-label").textContent ||
              radioWrapper.textContent ||
              "已选"
            ).replace(/\s+/g, " ").trim();
          }
          return "未选";
        }
      } catch (e) {}
      // UD 自定义下拉的 input 通常是 readonly，仅负责承接焦点；真正选中值显示在
      // 外层 selector 节点。若直接读 input.value，会把已选中的学历/语言误报成空值。
      try {
        var udSelect = element.closest && element.closest(".ud__select__selector, .ud__select");
        if (udSelect) {
          var udSelected = udSelect.querySelector(
            ".ud__select__selector__selected-item, .ud__select__selector__value, " +
            ".ud__select__selection-item, [class*='ud__select'][class*='selected'], " +
            "[class*='ud__select'][class*='value']"
          );
          var udText = String((udSelected || udSelect).textContent || "").replace(/\s+/g, " ").trim();
          if (udText && !/^(请选择|请选择.+|Select)$/i.test(udText)) return udText;
        }
      } catch (e) {}
      try {
        var nextSelect = element.closest && element.closest(".next-select");
        if (nextSelect) {
          var nextSelected = nextSelect.querySelector(
            ".next-select-values em[title], .next-select-value, .next-select-selection-item, " +
            ".next-select-values [title]:not(input), [class*='next-select'][class*='selected']"
          );
          var nextText = String(nextSelected && (
            nextSelected.getAttribute("title") ||
            nextSelected.textContent ||
            nextSelected.getAttribute("aria-label")
          ) || "").replace(/\s+/g, " ").trim();
          if (nextText && !/^(请选择|请输入|Select)$/i.test(nextText)) return nextText;
          return "";
        }
      } catch (e) {}
      try {
        var antSelect = element.closest && element.closest(".ant-select");
        if (antSelect) {
          var antSelected = antSelect.querySelector(
            ".ant-select-selection-selected-value, .ant-select-selection-item, " +
            ".ant-select-selection-item-content, .ant-select-selection__choice__content"
          );
          var antText = String(antSelected && (
            antSelected.textContent ||
            antSelected.getAttribute("title") ||
            antSelected.getAttribute("aria-label")
          ) || "").replace(/\s+/g, " ").trim();
          if (antText && !/^(请选择|请输入|Select)$/i.test(antText)) return antText;
          return "";
        }
      } catch (e) {}
      try {
        var sdSelect = element.closest && element.closest('[class^="sd-Select-container"], [class*=" sd-Select-container"], [class*="sd-Select"]');
        if (sdSelect) {
          var sdDisplay = sdSelect.querySelector("[class*='sd-Input-display-value']");
          var sdDisplayText = String(sdDisplay && sdDisplay.textContent || "").replace(/\s+/g, " ").trim();
          if (sdDisplayText && !/^(请选择|请输入|Select)$/i.test(sdDisplayText)) return sdDisplayText;
          return "";
        }
      } catch (e) {}
      try {
        var rocketSelect = element.closest && element.closest(".rocket-select");
        if (rocketSelect) {
          var rocketSelected = rocketSelect.querySelector(
            ".rocket-select-selection-item, .rocket-select-selection-selected-value, " +
            "[class*='rocket-select-selection'][class*='item'], [class*='rocket-select'][class*='selected']"
          );
          var rocketText = String((rocketSelected || rocketSelect).textContent || "").replace(/\s+/g, " ").trim();
          if (rocketText && !/^(请选择|请输入|Select)$/i.test(rocketText)) return rocketText;
        }
      } catch (e) {}
      var tag = element.tagName ? element.tagName.toLowerCase() : "";
      if (tag === "input" || tag === "textarea" || tag === "select") {
        if (element.type === "checkbox" || element.type === "radio") return element.checked ? (element.value || "已选") : "未选";
        if (tag === "select") {
          return Array.from(element.selectedOptions || []).map(function (o) { return (o.textContent || o.value || "").trim(); }).join(" / ");
        }
        return String(element.value || "").trim();
      }
      var selected = element.querySelector && element.querySelector(
        ".ant-select-selection-selected-value, .ant-select-selection-item, .el-input__inner, textarea, select"
      );
      if (selected && selected !== element) {
        var nested = readElementValue(selected);
        if (nested) return nested;
      }
      var customSelectTrigger = element.querySelector && element.querySelector(".select-left, .select-right, [class*='select'][class*='trigger'], [class*='select'][class*='value']");
      if (customSelectTrigger && customSelectTrigger !== element) {
        var triggerText = String(customSelectTrigger.textContent || "").replace(/\s+/g, " ").trim();
        if (triggerText) return triggerText;
      }
      return String(element.textContent || "").replace(/\s+/g, " ").trim().slice(0, 300);
    }

    function normalize(value) {
      return valueText(value).toLowerCase().replace(/[\s省市区县：:()（）\-_/]/g, "");
    }

    function matches(planned, actual) {
      var plannedText = valueText(planned);
      var actualText = valueText(actual);
      if (plannedText.indexOf("~") !== -1) {
        var plannedParts = plannedText.split("~").map(function (part) {
          var match = part.trim().match(/(\d{4})[-\/]?(\d{1,2})?/);
          return match ? match[1] + (match[2] ? "-" + String(Number(match[2])).padStart(2, "0") : "") : "";
        });
        var actualParts = actualText.split("~").map(function (part) {
          var match = part.trim().match(/(\d{4})[-\/]?(\d{1,2})?/);
          return match ? match[1] + (match[2] ? "-" + String(Number(match[2])).padStart(2, "0") : "") : "";
        });
        return plannedParts.length === 2 && actualParts.length === 2 &&
          plannedParts[0] === actualParts[0] && plannedParts[1] === actualParts[1];
      }
      var p = normalize(planned);
      var a = normalize(actual);
      if (!p || !a) return false;
      if (p === a) return true;
      if (p.length >= 2 && a.length >= 2 && a.indexOf(p) !== -1) return true;
      if (p.length >= 2 && a.length >= 4 && p.indexOf(a) !== -1) {
        return a.length / p.length >= 0.5;
      }
      return false;
    }

    function formatTraceType(type, element) {
      if (!type) return "";
      var detail = "";
      try {
        if (element && AF.SelectAdapter && typeof AF.SelectAdapter.detectType === "function" && /select|search|multiSelect/i.test(type)) {
          detail = AF.SelectAdapter.detectType(element) || "";
        }
      } catch (e) {
        detail = "";
      }
      return detail ? type + "." + detail : type;
    }

    return {
      start: function (meta) {
        state = { startedAt: Date.now(), finishedAt: 0, module: "", records: [], events: [], context: null, meta: meta || {} };
      },
      finish: function () { state.finishedAt = Date.now(); },
      setModule: function (module) { state.module = String(module || ""); },
      event: function (action, detail, status) {
        state.events.push({ time: Date.now(), module: state.module, action: action, detail: detail || "", status: status || "" });
      },
      setFieldContext: function (context) { state.context = context || null; },
      beginField: function (element) {
        return { context: state.context || {}, before: readElementValue(element) };
      },
      completeField: function (token, element, ok, type, forcedStatus) {
        var context = token && token.context || {};
        var before = token && token.before || "";
        var after = readElementValue(element);
        var isSelectLike = /^(search|select|multiSelect)$/i.test(String(type || ""));
        var isDisabled = Boolean(element && (element.disabled || element.getAttribute && (
          element.getAttribute("aria-disabled") === "true" || element.hasAttribute("disabled")
        )));
        var hasReadonly = Boolean(element && (element.readOnly || element.hasAttribute && element.hasAttribute("readonly")));
        // 自定义下拉内部的 readonly input 是正常触发器，不等于业务字段只读。
        var isNextDateTrigger = Boolean(element && element.closest && element.closest(".next-range-picker, .next-date-picker, .next-month-picker"));
        var isHotjobInteractiveReadonly = Boolean(element && element.matches && (
          element.matches("input.dayType") ||
          (element.matches("input[school-or-subject='1']") && element.closest("dy-form-special"))
        ));
        var isReadOnly = isDisabled || (hasReadonly && !isSelectLike && !isNextDateTrigger && !isHotjobInteractiveReadonly);
        var matchedAfter = matches(context.plannedValue, after);
        var status = forcedStatus || (isReadOnly ? "readonly_skipped" : matchedAfter
          ? (normalize(before) === normalize(after) ? "already_correct" : "verified")
          : !ok ? "fill_failed" : normalize(before) === normalize(after) ? "unchanged_old_value" : "changed_unverified");
        state.records.push({
          time: Date.now(), module: state.module, category: context.category || "", label: context.label || "",
          fieldKey: context.fieldKey || "", plannedValue: valueText(context.plannedValue), before: before,
          after: after, type: formatTraceType(type, element), ok: !!(ok || matchedAfter), status: status,
        });
        state.context = null;
      },
      getState: function () { return state; },
      readElementValue: readElementValue,
    };
  })();

  // ============ 内部小工具 (不属于任何其它模块的既定契约) ============

  var ADD_BUTTON_KEYWORDS = ["新增", "添加", "新建", "增加", "add", "new", "create"];

  function isExplicitlyLockedControl(element) {
    if (!element || !(element instanceof HTMLElement)) return false;
    try {
      if (
        element.disabled ||
        element.getAttribute("aria-disabled") === "true" ||
        element.hasAttribute("disabled")
      ) return true;

      var lockedWrapper = element.closest(
        ".ant-select-disabled, .ant-radio-wrapper-disabled, .ant-checkbox-wrapper-disabled, " +
        ".ant-calendar-picker-disabled, .el-input.is-disabled, .el-select.is-disabled, " +
        "[aria-disabled='true']"
      );
      if (lockedWrapper) return true;

      var readonly = element.readOnly || element.hasAttribute("readonly");
      if (!readonly) return false;
      // 自定义下拉和日期控件经常用 readonly input 作为正常触发器，不能误判成锁定字段。
      if (
        element.matches("input.dayType") ||
        (element.matches("input[school-or-subject='1']") && element.closest("dy-form-special"))
      ) return false;
      if (element.closest(
        ".ant-select:not(.ant-select-disabled), .ant-calendar-picker:not(.ant-calendar-picker-disabled), " +
        ".ant-cascader-picker:not(.ant-cascader-picker-disabled), .el-select:not(.is-disabled), " +
        ".next-select, .next-date-picker, .next-month-picker, .next-range-picker"
      )) return false;
      return true;
    } catch (e) {
      return false;
    }
  }

  function controlsAreLocked(element) {
    var list = Array.isArray(element) || (element && typeof element.length === "number" && !element.tagName)
      ? Array.from(element || [])
      : [element];
    var controls = list.filter(Boolean);
    return controls.length > 0 && controls.every(isExplicitlyLockedControl);
  }

  function labelBelongsToLockedField(label) {
    if (!label || !(label instanceof HTMLElement)) return false;
    try {
      var row = label.closest(
        ".ant-form-item, .el-form-item, .next-form-item, .ivu-form-item, .arco-form-item, " +
        ".semi-form-field, .form-item, .form-group, .field-item, [role='group']"
      );
      if (!row) row = label.parentElement;
      if (!row) return false;
      var controls = Array.from(row.querySelectorAll(
        "input, textarea, select, [role='combobox'], [role='radio'], [role='checkbox'], [contenteditable]"
      )).filter(function (control) {
        return !AF.DomUtils || AF.DomUtils.isElementVisible(control);
      });
      return controls.length > 0 && controls.every(isExplicitlyLockedControl);
    } catch (e) {
      return false;
    }
  }

  function isAddButtonText(text) {
    if (!text) return false;
    var t = String(text).trim().toLowerCase();
    if (!t) return false;
    if (/简历|resume|上传|附件|提交|投递|申请|下一步|删除|移除/.test(t)) return false;
    return ADD_BUTTON_KEYWORDS.some(function (k) {
      return t.includes(k);
    });
  }

  function containedTitleCount(elementMatcher, container) {
    if (!container || !elementMatcher || typeof elementMatcher.findTitle !== "function") return 0;
    try {
      return Array.from(elementMatcher.findTitle() || []).filter(function (title) {
        return title && container.contains(title) && AF.DomUtils.isElementVisible(title);
      }).length;
    } catch (e) {
      return 0;
    }
  }

  function findTightSectionContainer(elementMatcher, titleEl, outerBoundary) {
    if (!titleEl) return null;
    var current = titleEl;
    var depth = 0;
    while (current && depth < 8) {
      current = current.parentElement;
      if (!current) break;
      var controls = current.querySelectorAll
        ? current.querySelectorAll("input, select, textarea, [contenteditable], [role='textbox'], [role='combobox']").length
        : 0;
      if (controls > 0 && containedTitleCount(elementMatcher, current) <= 1) return current;
      if (current === outerBoundary) break;
      depth++;
    }
    return null;
  }

  // 从标题元素向上找最近的"卡片/分区容器" (源码 findContainerByTitle 的近似替代，
  // 因为该方法是 ElementMatcher 的私有实现，未列入本文件依赖的既定契约)
  function findSectionContainer(elementMatcher, titleEl) {
    if (!titleEl) return document;
    // 空分区（例如首次填写前的“自我评价”）本身没有 input。旧逻辑会因此继续
    // 向上爬到整个 form，随后把所有经历卡里的“描述”都当成自我评价填写。
    // 站点配置知道真正的模块容器，必须把它作为硬边界，空模块也不能越界。
    try {
      if (elementMatcher && typeof elementMatcher.findContainerByTitle === "function") {
        var configuredContainer = elementMatcher.findContainerByTitle(titleEl);
        if (configuredContainer && configuredContainer.isConnected) {
          if (containedTitleCount(elementMatcher, configuredContainer) <= 1) return configuredContainer;
          // 配置套错页面时，container 可能覆盖整个表单。此时必须缩回当前标题
          // 对应的最小字段区域；找不到宁可跳过，也不能跨模块填相邻的“描述/职位/公司”。
          var tightConfiguredContainer = findTightSectionContainer(elementMatcher, titleEl, configuredContainer);
          if (tightConfiguredContainer) return tightConfiguredContainer;
          return titleEl.parentElement || titleEl;
        }
        // 点击“添加”后标题和模块也可能整块重建；用标题文字在当前 document
        // 重新找到同名标题，不能返回 detached 的旧 wrapper。
        var wantedTitle = String(titleEl.textContent || "").replace(/\s+/g, "").trim();
        var currentTitles = typeof elementMatcher.findTitle === "function" ? (elementMatcher.findTitle() || []) : [];
        for (var titleIndex = 0; titleIndex < currentTitles.length; titleIndex++) {
          var currentTitle = String(currentTitles[titleIndex].textContent || "").replace(/\s+/g, "").trim();
          if (currentTitle !== wantedTitle) continue;
          var freshConfiguredContainer = elementMatcher.findContainerByTitle(currentTitles[titleIndex]);
          if (freshConfiguredContainer && freshConfiguredContainer.isConnected) {
            if (containedTitleCount(elementMatcher, freshConfiguredContainer) <= 1) return freshConfiguredContainer;
            var tightFreshContainer = findTightSectionContainer(
              elementMatcher,
              currentTitles[titleIndex],
              freshConfiguredContainer
            );
            if (tightFreshContainer) return tightFreshContainer;
          }
        }
        if (configuredContainer) return configuredContainer;
      }
    } catch (e) {}
    if (
      titleEl.querySelectorAll &&
      titleEl.querySelectorAll("input, select, textarea, [contenteditable]").length > 0
    ) {
      return titleEl;
    }
    var container = null;
    try {
      if (AF.SELECTORS && AF.SELECTORS.containers && AF.SELECTORS.containers.length) {
        container = titleEl.closest(AF.SELECTORS.containers.join(","));
      }
    } catch (e) {}
    if (!container) {
      var cur = titleEl.parentElement;
      var depth = 0;
      while (cur && depth < 6) {
        if (cur.querySelectorAll && cur.querySelectorAll("input, select, textarea, [contenteditable]").length > 0) {
          container = cur;
          break;
        }
        cur = cur.parentElement;
        depth++;
      }
    }
    return container || titleEl.parentElement || document;
  }

  // 从 elementMatcher.findAllLabels() 的全局结果里，过滤出属于某个容器内的 label
  // (源码 findLabelsByCard 的近似替代)
  function labelsWithinContainer(elementMatcher, container) {
    if (!container || !elementMatcher || typeof elementMatcher.findAllLabels !== "function") return [];
    var all = elementMatcher.findAllLabels() || [];
    return Array.from(all).filter(function (l) {
      try {
        return container.contains(l);
      } catch (e) {
        return false;
      }
    });
  }

  // 找"添加/新增"按钮 (源码 findAddButton 精确版 行68421 + 简化版 行65394 的合并近似)
  function findAddButtonIn(container) {
    if (!container) return null;
    try {
      if (AF.SELECTORS && AF.SELECTORS.addButton && AF.SELECTORS.addButton.length) {
        var bySelector = Array.from(container.querySelectorAll(AF.SELECTORS.addButton.join(","))).filter(
          function (el) {
            return AF.DomUtils.isElementVisible(el) && AF.DomUtils.isSafeExperienceAddAction(el, container);
          }
        );
        if (bySelector.length) return AF.DomUtils.findVisibleButton(bySelector);
      }
    } catch (e) {}
    try {
      var candidates = Array.from(
        container.querySelectorAll('button, a, [role="button"], .btn, [class*="btn" i], [class*="add" i]')
      );
      var matched = candidates.filter(function (el) {
        var text = el.textContent || el.getAttribute("aria-label") || el.getAttribute("title") || "";
        return AF.DomUtils.isElementVisible(el) && isAddButtonText(text) && AF.DomUtils.isSafeExperienceAddAction(el, container);
      });
      if (matched.length) return AF.DomUtils.findVisibleButton(matched);
    } catch (e) {}
    return null;
  }

  function readYearMonthScopeValues(scope) {
    if (!scope || !scope.querySelectorAll) return [];
    var controls = Array.from(scope.querySelectorAll('[class^="sd-Dropdown-container"], [class*=" sd-Dropdown-container"]')).filter(function (control) {
      try {
        if (!AF.DomUtils.isElementVisible(control)) return false;
        return !!control.querySelector("input, [class*='sd-Input-display-value']");
      } catch (e) {
        return false;
      }
    });
    if (!controls.length) {
      controls = Array.from(scope.querySelectorAll("input")).filter(function (input) {
        var hint = String([input.placeholder, input.name, input.id, input.getAttribute("aria-label")].filter(Boolean).join(" "));
        return AF.DomUtils.isElementVisible(input) && /(年|月|year|month)/i.test(hint);
      });
    }
    return controls.map(function (control) {
      try {
        var display = control.querySelector && control.querySelector('[class*="sd-Input-display-value"]');
        var displayText = String(display && display.textContent || "").trim();
        if (displayText) return displayText;
        var input = control.tagName === "INPUT" ? control : control.querySelector && control.querySelector("input");
        return String(input && input.value || "").trim();
      } catch (e) {
        return "";
      }
    }).filter(Boolean);
  }

  function isCurrentEndChecked(scope) {
    try {
      return Array.from(scope.querySelectorAll("label, [role='checkbox'], input[type='checkbox']")).some(function (node) {
        var text = String(node.textContent || node.getAttribute("aria-label") || node.getAttribute("title") || "").replace(/[\s:：*]/g, "");
        if (!/至今|目前|现在|当前|仍在职|在职|仍在进行/.test(text)) return false;
        var input = node.matches && node.matches("input[type='checkbox']") ? node : node.querySelector && node.querySelector("input[type='checkbox']");
        var cls = String(node.className || "");
        return !!(input && input.checked || node.getAttribute("aria-checked") === "true" || /active|checked|selected/.test(cls));
      });
    } catch (e) {
      return false;
    }
  }

  // 按 label 文字分组 (源码 fillExperienceLegacy 行13404-13418 / 13645-13652 的分组逻辑)
  function groupLabelsByText(labels) {
    var groups = {};
    Array.from(labels || []).forEach(function (l) {
      var text = AF.LabelUtils.getLabelText(l).toLowerCase();
      if (!groups[text]) groups[text] = [];
      groups[text].push(l);
    });
    return groups;
  }

  // 已有卡片数 = 同名 label 分组里最长的那组长度 (源码行13419-13426)
  function countLabelGroups(labels) {
    var groups = groupLabelsByText(labels);
    var max = 0;
    Object.keys(groups).forEach(function (key) {
      if (groups[key].length > max) max = groups[key].length;
    });
    return max;
  }

  // 旧版站点没有 cardSelector，只能从同名 label 推断行。若能找到一个“只包含
  // 当前行 label、不包含其他行 label”的最深祖先，就把它作为本条经历边界。
  // 推断失败时绝不臆造边界；调用方会在字段数量不齐的高风险场景跳过该行。
  function inferLegacyExperienceRowScope(container, rowLabels, allLabels) {
    if (!container || !rowLabels || rowLabels.length < 2) return null;
    var rowSet = new Set(rowLabels);
    var node = rowLabels[0] && rowLabels[0].parentElement;
    while (node && node !== container) {
      var own = rowLabels.filter(function (label) { return node.contains(label); }).length;
      var foreign = Array.from(allLabels || []).some(function (label) {
        return !rowSet.has(label) && node.contains(label);
      });
      if (own >= 2 && !foreign) return node;
      node = node.parentElement;
    }
    return null;
  }

  function detectEducationRecordCards(container, matcher) {
    if (!container || !matcher) return [];

    // Build133: first reuse mature platform card selectors when available.
    // Moka labels are div-based (`title-*`) rather than conventional <label>
    // nodes, so the old 示例资料-only detector returned zero cards even after
    // the platform add action had opened a real editor.
    try {
      var configuredCardSelector = matcher.config && matcher.config.experience &&
        matcher.config.experience.card && matcher.config.experience.card.cardSelector;
      if (configuredCardSelector) {
        var configuredCards = Array.from(container.querySelectorAll(configuredCardSelector)).filter(function (node) {
          return !AF.DomUtils || AF.DomUtils.isElementVisible(node);
        });
        configuredCards = configuredCards.filter(function (candidate) {
          return !configuredCards.some(function (示例资料) {
            return 示例资料 !== candidate && candidate.contains(示例资料);
          });
        });
        if (configuredCards.length) return configuredCards;
      }
    } catch (eConfiguredEducationCards) {}

    // Tencent join/careers renders each 示例资料 record as an .info_list
    // (older skins may wrap it in .experience_box) and uses placeholder-driven
    // Element controls instead of conventional <label> nodes.  The generic
    // label-only detector therefore returned zero cards and the sequential
    // 示例资料 owner skipped the whole section.  Detect only record-like
    // containers inside the already-resolved Education section; never scan the
    // whole page, so 示例资料/示例资料 .info_list nodes cannot leak in.
    try {
      var host = String(window.location && window.location.hostname || "");
      if (/^(?:join|careers)\.qq\.com$/i.test(host)) {
        var tencentCandidates = Array.from(container.querySelectorAll(".info_list, .experience_box")).filter(function (node) {
          if (AF.DomUtils && !AF.DomUtils.isElementVisible(node)) return false;
          var 示例资料Signals = 0;
          var placeholders = [];
          try {
            placeholders = Array.from(node.querySelectorAll("input[placeholder], textarea[placeholder]")).map(function (control) {
              return String(control.getAttribute("placeholder") || "");
            });
          } catch (ePlaceholders) {}
          if (placeholders.some(function (text) { return /学校名称|毕业院校|学校/.test(text); })) 示例资料Signals += 1;
          if (placeholders.some(function (text) { return /学历/.test(text); })) 示例资料Signals += 1;
          if (placeholders.some(function (text) { return /专业/.test(text); })) 示例资料Signals += 1;
          if (placeholders.some(function (text) { return /绩点|成绩排名/.test(text); })) 示例资料Signals += 1;
          return 示例资料Signals >= 2;
        });
        // .experience_box can contain an inner .info_list for the same record.
        // Keep the deepest matching containers so one record is never counted twice.
        tencentCandidates = tencentCandidates.filter(function (candidate) {
          return !tencentCandidates.some(function (示例资料) { return 示例资料 !== candidate && candidate.contains(示例资料); });
        });
        if (tencentCandidates.length) return tencentCandidates;
      }
    } catch (eTencentEducationCards) {}

    var labelSelector = "label,.subtitle,.form-item__text,.el-form-item__label,[class*='label']";
    var labels = Array.from(container.querySelectorAll(labelSelector)).filter(function (label) {
      return !AF.DomUtils || AF.DomUtils.isElementVisible(label);
    });
    var schoolLabels = labels.filter(function (label) {
      return /^(学校名称|学校|毕业院校)$/.test(String(AF.LabelUtils.getLabelText(label) || "").replace(/[\s:*：]/g, ""));
    });
    var cards = [];
    schoolLabels.forEach(function (schoolLabel) {
      var node = schoolLabel.parentElement;
      for (var depth = 0; node && node !== container && depth < 8; depth++, node = node.parentElement) {
        var texts = Array.from(node.querySelectorAll(labelSelector)).map(function (label) {
          return String(AF.LabelUtils.getLabelText(label) || "").replace(/[\s:*：]/g, "");
        });
        var valid = texts.some(function (x) { return /学校/.test(x); }) &&
          texts.some(function (x) { return /专业/.test(x); }) &&
          texts.some(function (x) { return /学历/.test(x); }) &&
          texts.some(function (x) { return /学位/.test(x); });
        if (valid) { if (cards.indexOf(node) === -1) cards.push(node); break; }
      }
    });
    return cards;
  }

  function 示例资料CardIsBlank(card) {
    if (!card) return true;
    return !Array.from(card.querySelectorAll("input,select,textarea")).some(function (control) {
      return String(control.value || "").trim() || (control.tagName === "SELECT" && control.selectedIndex > 0);
    });
  }

  async function findPendingManualExperienceSaveButton(formHandler, scope, container) {
    try {
      var experienceHandler = formHandler && formHandler.experienceHandler;
      var adapter = experienceHandler && experienceHandler.configAdapter;
      if (!experienceHandler || !adapter || adapter.isAutoSaveAllowed() ||
          (typeof adapter.usesInlinePersistence === "function" && adapter.usesInlinePersistence())) return null;
      var selector = adapter.getSaveButtonSelector && adapter.getSaveButtonSelector();
      var texts = adapter.getSaveButtonText && adapter.getSaveButtonText();
      var scopes = [scope, container].filter(function (node, index, list) {
        return node && node.querySelectorAll && list.indexOf(node) === index;
      });
      for (var i = 0; i < scopes.length; i++) {
        var button = await experienceHandler.findElementByPriority(scopes[i], selector, texts);
        if (button && (!AF.DomUtils || AF.DomUtils.isElementVisible(button)) && !button.disabled) return button;
      }
    } catch (e) {}
    return null;
  }

  function buildFormRecordCheckpointMeta(category, title, index, total, row) {
    var fingerprint = AF.CheckpointCore && typeof AF.CheckpointCore.recordFingerprint === "function"
      ? AF.CheckpointCore.recordFingerprint(row || {}) : "";
    return {
      category: String(category || ""),
      sectionTitle: String(title || category || "经历"),
      示例资料Index: Number(index),
      示例资料Total: Number(total || 0),
      recordFingerprint: String(fingerprint || ""),
      row: row || {}
    };
  }

  function writeEducationRepeatTrace(trace) {
    try { document.documentElement.setAttribute("data-af-示例资料-record-trace", JSON.stringify({ 示例资料: trace })); } catch (e) {}
  }

  function writeEducationExecutionRouteTrace(patch) {
    try {
      var root = document.documentElement;
      var state = JSON.parse(root.getAttribute("data-af-execution-route-trace") || "{}");
      state.示例资料 = Object.assign({ genericPlanActionsCreated: 0, genericEducationExecutionCount: 0, sequentialExecutorEntered: false, profileRecordCount: 0, recordsAttempted: 0 }, state.示例资料 || {}, patch || {});
      root.setAttribute("data-af-execution-route-trace", JSON.stringify(state));
    } catch (e) {}
  }

  // 展开折叠的表单区域 (源码 handleFormExpansion, 行26228)。
  // 逻辑: 容器里若已有可见的 .form_m 就直接返回容器; 否则点一次标题元素展开, 等500ms,
  //       重新按标题定位容器。用于"经历/示例资料表单默认折叠、点标题才展开"的站点。
  async function handleFormExpansion(elementMatcher, container, titleEl) {
    try {
      var formM = container && container.querySelectorAll ? container.querySelectorAll(".form_m") : [];
      var hasVisible = Array.from(formM).filter(function (el) {
        return AF.DomUtils.isElementVisible(el);
      }).length !== 0;
      if (hasVisible) return container;
      await AF.DomUtils.safeClickElement(titleEl);
      await AF.Utils.sleep(500);
      var recontainer = elementMatcher && elementMatcher.findContainerByTitle(titleEl);
      if (recontainer) return recontainer;
      return container;
    } catch (e) {
      return container;
    }
  }

  // 示例资料Type 字段的"是否全日制"归一化 (源码行2586-2604，逐行照搬)
  function normalizeEducationTypeToYesNo(value) {
    var text = String(value ?? "").trim();
    if (!text) return text;
    if (text === "是" || text === "否") return text;
    if (/^(true|yes|y|1)$/i.test(text)) return "是";
    if (
      /^(false|no|n|0)$/i.test(text) ||
      /非全日制|非统招|不是|没有|无|未|否|自考|成教|函授|网络教育|自学考试|成人|在职|留学生/.test(text)
    ) {
      return "否";
    }
    if (/全日制|统招|有|是/.test(text)) return "是";
    return text;
  }

  function normalizeLanguageScoreValue(category, fieldKey, value) {
    if (category !== "示例资料Skills" || fieldKey !== "score" || value === undefined || value === null) return value;
    var text = String(value).trim();
    if (!text) return value;
    var numbers = text.match(/\d+(?:\.\d+)?/g);
    if (!numbers || numbers.length === 0) return value;
    return numbers[numbers.length - 1];
  }

  function yesNoFromValue(value) {
    var text = String(value === undefined || value === null ? "" : value).trim();
    if (!text) return "否";
    if (/^(是|true|yes|y|1|有)$/i.test(text)) return "是";
    if (/^(否|false|no|n|0|无|没有|不是)$/i.test(text)) return "否";
    return /是|有|交换|国家奖学金/.test(text) ? "是" : "否";
  }

  function buildLanguageSummary(resumeData) {
    var list = resumeData && resumeData.示例资料Skills;
    if (!Array.isArray(list) || !list.length) return "";
    return list.map(function (item) {
      return [item.name, item.certificateName || item.certificate, item.level, item.score].filter(Boolean).join(" ");
    }).filter(Boolean).join("；");
  }

  function normalizeSpecialEducationValue(labelText, fieldKey, value, data) {
    if (fieldKey === "studyLength" || /^(学制|学习年限|修业年限|培养年限|就读年限)$/.test(String(labelText || "").trim())) {
      var years = AF.DomUtils && AF.DomUtils.parseStudyYears ? AF.DomUtils.parseStudyYears(value) : null;
      if (years !== null) return String(years) + "年";
    }
    if (/国家奖学金/.test(labelText || "")) {
      return /国家奖学金/.test(String(data && data.scholarship || value || "")) ? "是" : "否";
    }
    if (fieldKey === "isExchangeStudent" || /交换生/.test(labelText || "")) {
      return yesNoFromValue(value);
    }
    return value;
  }

  // ============ FormHandler 构造函数 (源码行12825-12844) ============
  function FormHandler(elementMatcher, dataMatcher) {
    this.elementMatcher = elementMatcher;
    this.dataMatcher = dataMatcher;
    this.operationDelay = 20; // 每次填写间隔 20ms (源码行12834)
    this.filledFieldsCount = 0;
    // 非源码字段: 记录"匹配到字段但没填成功"的详情，供 Panel 展示"失败字段"列表用
    this.failedFields = [];
    this._attemptedFieldKeys = new Set();
    // 非源码字段: (current, total) => void，每处理一个 label/条目调用一次，用于进度条
    this.onFieldProgress = null;
    this.shouldStop = function () { return false; };
    // Build132: generic FormGraph FIELD checkpoint runtime. It is injected only
    // by the ordinary FillEngine path; special 示例资料flows keep their own RECORD/STEP recovery.
    this.fieldCheckpointRuntime = null;
    // Build133: ordinary Structured RepeatRecord checkpoint runtime.
    this.recordCheckpointRuntime = null;
    // 源码里这两个字段挂在类的静态属性 t.currentLabelText / t.currentLabel 上，
    // 主要用于 handleText 里判断"专业/学科"字段是否走智联专属分支 (本文件未实现该分支，
    // 详见 handleText 内注释)；这里保留字段是为了方便以后调试定位当前正在填哪个 label。
    this.currentLabelText = null;
    this.currentLabel = null;

    // 新版经历填写方案 (源码 this.experienceHandler)。依赖站点配置的 experience 段，
    // 由 content/experience-handler.js 提供。站点配置从 elementMatcher.config 取。
    // 未加载该模块时降级为 null，fillExperience 会直接走旧版兜底。
    this.experienceHandler =
      AF.ExperienceHandler && elementMatcher
        ? new AF.ExperienceHandler(elementMatcher, dataMatcher, elementMatcher.config || null)
        : null;

    // 注: 源码里还有 this.awardHandler = new O(...)，对应已删除的 AI竞赛字段匹配
    // (fillMatchInfo)，不在本文件职责范围内，此处不创建。
  }

  FormHandler.prototype.resolveCapabilityContext = function (category, fieldKey, labelText, element, type) {
    if (!AF.CapabilityPatch || typeof AF.CapabilityPatch.createContext !== "function") return null;
    return AF.CapabilityPatch.createContext(this.elementMatcher && this.elementMatcher.config, {
      category: category,
      fieldKey: fieldKey,
      labelText: labelText,
      element: element,
      type: type,
    });
  };

  // 把 experienceHandler 累计的 filledFieldsCount 并入本 handler 再清零，
  // 避免下次调用重复计数 (源码 mergeFillStatsFrom, fillExperience 行13294)。
  FormHandler.prototype.mergeFillStatsFrom = function (handler) {
    if (handler && typeof handler.filledFieldsCount === "number") {
      this.filledFieldsCount += handler.filledFieldsCount;
      handler.filledFieldsCount = 0;
    }
  };

  // ============ filterValidLabels (源码行12860-12870) ============
  FormHandler.prototype.filterValidLabels = function (labels) {
    if (!labels || !labels.length) return [];
    return Array.from(labels).filter(function (l) {
      var text = AF.LabelUtils.getLabelText(l);
      return text && text.length > 0 && AF.DomUtils.isElementVisible(l);
    });
  };

  // ============ getTitleValue (源码行68559-68568, 经 13901-13903 委托调用) ============
  FormHandler.prototype.getTitleValue = function (el) {
    if (!el) return "";
    try {
      var graphTitle = el.getAttribute && el.getAttribute("data-af-graph-section-title");
      if (graphTitle) return String(graphTitle).trim();
    } catch (_) {}
    var tag = el.tagName ? el.tagName.toLowerCase() : "";
    var raw = tag === "input" || tag === "textarea" ? el.value : el.textContent;
    return (raw || "").trim();
  };

  function normalizeElementType(type) {
    if (type === "input") return "text";
    if (type === "contenteditable") return "contentEditable";
    return type;
  }

  function resolveFillType(element, elementType, value) {
    var resolvedType = normalizeElementType(elementType || "text");
    if (AF.DomUtils.isDateValue(value) && !/^(radio|checkbox|multiSelect)$/i.test(String(resolvedType || ""))) {
      resolvedType = "date";
    } else if (resolvedType === "text") {
      if (AF.DomUtils.isDatePicker(element) || AF.DomUtils.isDateValue(value)) {
        resolvedType = "date";
      } else if (AF.DomUtils.isNormalSelect(element) || AF.DomUtils.isSearchSelect(element)) {
        resolvedType = "search";
      }
    } else if (resolvedType === "select" && AF.DomUtils.isSearchSelect(element) &&
        !(element && element.closest && element.closest(".ant-cascader-picker, .ant-select.ant-cascader, .ant-cascader"))) {
      resolvedType = "search";
    }
    return resolvedType;
  }



  function checkpointScalarNode(element) {
    if (!element) return null;
    if (Array.isArray(element) || (typeof element.length === "number" && !element.tagName)) {
      var list = Array.from(element);
      return list.find(function (node) { return node && node.tagName; }) || null;
    }
    return element;
  }

  // Patch132 示例资料ally supports only ordinary scalar controls. Frame示例资料
  // searches/cascaders/dialog transactions remain outside generic checkpoints.
  function isSafeFormFieldCheckpointControl(element, resolvedType) {
    var node = checkpointScalarNode(element);
    if (!node || !node.tagName) return false;
    var tag = String(node.tagName || "").toLowerCase();
    var type = String(resolvedType || "").toLowerCase();
    var inputType = String(node.type || "").toLowerCase();
    if (tag === "textarea" && (type === "text" || type === "textarea")) return true;
    if (tag === "select" && type === "select") return true;
    if (tag === "input" && (type === "radio" || type === "checkbox") && (inputType === type || !inputType)) return true;
    if (tag === "input" && type === "date" && /^(?:date|month)$/.test(inputType)) return true;
    if (tag === "input" && type === "text" && /^(?:text|email|tel|number|url|search|password)?$/.test(inputType)) return true;
    return false;
  }
  function deriveStudyDuration(startTime, endTime) {
    if (!startTime || !endTime) return null;
    var start = String(startTime).match(/^(\d{4})(?:-(\d{1,2}))?/);
    var end = String(endTime).match(/^(\d{4})(?:-(\d{1,2}))?/);
    if (!start || !end) return null;
    var startYear = Number(start[1]);
    var endYear = Number(end[1]);
    var startMonth = Number(start[2] || 9);
    var endMonth = Number(end[2] || 6);
    if (!startYear || !endYear || endYear < startYear) return null;
    var years = endYear - startYear;
    if (endMonth > startMonth) years += 1;
    if (years <= 0 || years > 10) return null;
    var chinese = ["", "一", "两", "三", "四", "五"];
    return years <= 5 ? chinese[years] + "年制" : String(years) + "年";
  }

  function buildEducationDialogChoiceValue(category, fieldKey, rowData, value) {
    if (category !== "示例资料" || value == null || !/^(school|major)$/.test(String(fieldKey || ""))) return value;
    if (fieldKey === "school") {
      return { name: String(value), dialogChoice: { allowFirstResult: true } };
    }
    var alternatives = [];
    [rowData && rowData.majorSubcategory, rowData && rowData.majorCategory, rowData && rowData.czbankMajorCategory].forEach(function (item) {
      item = String(item || "").trim();
      if (item && alternatives.indexOf(item) === -1) alternatives.push(item);
    });
    String(rowData && rowData.majorPath || "").split(/\s*(?:\/|>|＞|\|)\s*/).reverse().forEach(function (item) {
      item = String(item || "").trim();
      if (item && item !== String(value) && alternatives.indexOf(item) === -1) alternatives.push(item);
    });
    return { name: String(value), dialogChoice: { alternatives: alternatives, preferExistingOptions: true } };
  }

  function buildEducationMajorCascaderValue(category, fieldKey, rowData, value, element) {
    if (
      category !== "示例资料" ||
      fieldKey !== "majorCategory" ||
      !element || !element.closest ||
      !element.closest(".ant-cascader-picker")
    ) return value;
    var parent = String(value == null ? "" : value).trim().replace(/类$/, "");
    var child = String(rowData && (rowData.majorSubcategory || rowData.czbankMajorCategory) || "").trim();
    return [parent, child].filter(Boolean);
  }

  // ============ fillLabels — 核心填写循环 (源码行13114-13227) ============
  FormHandler.prototype.fillLabels = async function (labels, category, data) {
    if (!labels || !labels.length || !data) return;
    var total = labels.length;
    var labelCounts = {};
    var labelSeen = {};
    Array.from(labels).forEach(function (item) {
      var text = AF.LabelUtils.getLabelText(item);
      if (text) labelCounts[text] = (labelCounts[text] || 0) + 1;
    });

    for (var i = 0; i < labels.length; i++) {
      if (this.shouldStop && this.shouldStop()) break;
      var label = labels[i];
      var labelText = AF.LabelUtils.getLabelText(label);

      // 源码行13137-13139: 身份证号常被拆成两个相邻 input，第二个 label 是空的，
      // 如果上一个 label 含"证件号码"，就把这个空 label 也当作"证件号码"处理
      if (!labelText && i > 0) {
        var prevText = AF.LabelUtils.getLabelText(labels[i - 1]);
        if (prevText.includes("证件号码")) labelText = "证件号码";
      }

      if (this.onFieldProgress) this.onFieldProgress(i + 1, total);
      if (!labelText) continue;

      this.currentLabelText = labelText;
      this.currentLabel = label;

      // 华为新版把“证件类型 + 证件号码”放在同一个“证件”表单项内，页面只有
      // 一张 label。普通的一标签一字段流程无法同时填写两个控件，因此在这里
      // 按控件边界分别处理，避免把国家值或证件类型写进号码输入框。
      if (
        category === "示例资料Info" &&
        labelText.replace(/[\s：:*]/g, "") === "证件" &&
        /(^|\.)career\.huawei\.com$/i.test(String(location.hostname || ""))
      ) {
        var credentialItem = label.closest && label.closest(".aui-form-item");
        var credentialSelectInput = credentialItem && credentialItem.querySelector(".aui-select input.aui-input__inner");
        var credentialTextInputs = credentialItem ? Array.from(credentialItem.querySelectorAll("input.aui-input__inner")) : [];
        var credentialNumberInput = credentialTextInputs.find(function (input) {
          return !(input.closest && input.closest(".aui-select")) && !input.disabled && !input.readOnly;
        });
        var credentialHandled = false;
        if (credentialSelectInput && data.idType) {
          AF.FillTrace.setFieldContext({ category: category, label: "证件类型", fieldKey: "idType", plannedValue: data.idType });
          var idTypeCapability = this.resolveCapabilityContext(category, "idType", "证件", credentialSelectInput, "search");
          if (await AF.FormHandler.fillFormElement(credentialSelectInput, data.idType, "search", idTypeCapability)) {
            this.filledFieldsCount++;
            credentialHandled = true;
          }
        }
        if (credentialNumberInput && data.idNumber) {
          AF.FillTrace.setFieldContext({ category: category, label: "证件号码", fieldKey: "idNumber", plannedValue: data.idNumber });
          if (await AF.FormHandler.fillFormElement(credentialNumberInput, data.idNumber, "text")) {
            this.filledFieldsCount++;
            credentialHandled = true;
          }
        }
        if (credentialHandled) {
          await AF.Utils.sleep(this.operationDelay);
          continue;
        }
      }

      // 源码行13148-13156: 先按字典精确匹配字段名，匹配不到但标签含"时间/日期/年月"
      // 时，退化为 duration / startTime / endTime
      var fieldKey = this.dataMatcher.findFieldByCategory(category, labelText);
      if (!fieldKey && AF.AIConfigGenerator && typeof AF.AIConfigGenerator.resolveSemanticFieldMapping === "function") {
        fieldKey = AF.AIConfigGenerator.resolveSemanticFieldMapping(this.elementMatcher && this.elementMatcher.config, category, labelText);
      }
      if (!fieldKey) {
        if (category === "示例资料" && /语言能力/.test(labelText)) {
          fieldKey = "__示例资料Summary";
        }
      }
      if (!fieldKey) {
        if (labelText.includes("时间") || labelText.includes("日期") || labelText.includes("年月")) {
          if (data.duration) {
            fieldKey = "duration";
          } else if (data.startTime && data.endTime) {
            fieldKey = labelText.includes("开始") ? "startTime" : "endTime";
          }
        }
      }
      if (!fieldKey) continue;

      // 上传类字段必须始终留给用户手动选择文件。Phoenix 的上传控件没有可填写的
      // 普通 input 时，相邻控件定位可能退到上一个文本框（例如“证件照”误命中
      // “邮箱”），从而把“已上传证件照”写进邮箱。这里在元素定位前按字段语义截断。
      if (
        /^(?:photo|idPhoto|lifePhoto|resumeFile|resumeAttachment|attachment|portfolio)$/i.test(String(fieldKey || "")) ||
        /(?:上传|附件|证件照|生活照|头像|简历文件)/.test(String(labelText || ""))
      ) {
        if (AF.FillTrace) AF.FillTrace.event("manual_upload", labelText + "：请手动上传", "skipped");
        continue;
      }

      var occurrence = labelSeen[labelText] || 0;
      labelSeen[labelText] = occurrence + 1;
      if (
        fieldKey === "startTime" &&
        labelCounts[labelText] === 2 &&
        occurrence === 1 &&
        data.startTime && data.endTime &&
        /(时间|日期|年月)/.test(labelText)
      ) {
        fieldKey = "endTime";
      }
      this._attemptedFieldKeys.add(category + "." + fieldKey);

      var fieldCheckpointMeta = {
        category: category,
        fieldKey: fieldKey,
        label: labelText,
        occurrence: occurrence,
        sectionTitle: String(this.currentSectionTitle || "")
      };
      var fieldCheckpointRuntime = this.fieldCheckpointRuntime;
      if (fieldCheckpointRuntime && fieldCheckpointRuntime.enabled && typeof fieldCheckpointRuntime.shouldSkip === "function" &&
          fieldCheckpointRuntime.shouldSkip(fieldCheckpointMeta)) {
        if (AF.FillTrace) AF.FillTrace.event("field_checkpoint_skip", labelText + "：已由恢复游标跳过", "skipped");
        await AF.Utils.sleep(this.operationDelay);
        continue;
      }

      var value = (fieldKey === "__示例资料Summary" || fieldKey === "示例资料Ability") ? buildLanguageSummary(this.dataMatcher && this.dataMatcher.resumeData) : data[fieldKey];
      if (category === "示例资料" && /^(ccbHighestEducation|isHighestEducation)$/.test(String(fieldKey || ""))) {
        if (value == null) value = data.isHighestEducation;
        if (value == null) value = data.ccbHighestEducation;
        if (value != null) value = yesNoFromValue(value);
      }
      if (
        category === "示例资料Info" &&
        AF.DomUtils && typeof AF.DomUtils.resolveAddressValue === "function" &&
        /^(nativePlace|birthOrigin|hukouLocation|archiveLocation|currentAddress|示例资料Location|schoolLocation|expectedLocation)$/.test(fieldKey)
      ) {
        value = AF.DomUtils.resolveAddressValue(data, fieldKey);
      }
      if (value == null && fieldKey === "studyLength" && data.startTime && data.endTime) {
        value = deriveStudyDuration(data.startTime, data.endTime);
      }
      if (value == null && fieldKey === "duration" && data.startTime && data.endTime) {
        value = /学制/.test(labelText) ? deriveStudyDuration(data.startTime, data.endTime) : { startTime: data.startTime, endTime: data.endTime };
      }
      if (value == null) continue;
      if (
        AF.DomUtils && typeof AF.DomUtils.normalizeDegreeValue === "function" &&
        (/^(degree|degreeType|highestDegree|degreeName)$/.test(String(fieldKey || "")) || /学位/.test(String(labelText || "")))
      ) {
        var normalizedDegree = AF.DomUtils.normalizeDegreeValue(value);
        if (normalizedDegree) value = normalizedDegree;
      }
      if (
        /^applyjob\.chinahr\.com$/i.test(String(location.hostname || "")) &&
        (category === "示例资料Experience" || category === "示例资料Experience") &&
        (/^(示例资料Type|employmentType|jobNature)$/.test(String(fieldKey || "")) || /工作类别/.test(String(labelText || "")))
      ) {
        value = "实习（未毕业在校生兼职或实习）";
      }
      value = normalizeLanguageScoreValue(category, fieldKey, value);
      if (category === "示例资料") value = normalizeSpecialEducationValue(labelText, fieldKey, value, data);

      // 源码行13175-13177: "是否全日制"这类标签，值要归一化成 是/否
      if (fieldKey === "示例资料Type" && /是否/.test(labelText)) {
        value = normalizeEducationTypeToYesNo(value);
      }

      var found = this.elementMatcher.findElementAndTypeByLabel(label);
      var elType = found && found.type;
      var el = found && found.element;
      if (
        /^applyjob\.chinahr\.com$/i.test(String(location.hostname || "")) &&
        category === "示例资料" &&
        String(labelText || "").replace(/[\s：:*]/g, "") === "学位"
      ) {
        var chinaHrDegreeRow = label.closest && label.closest(".aply-field-li");
        var chinaHrDegreePicker = chinaHrDegreeRow && chinaHrDegreeRow.querySelector(".ant-cascader-picker");
        if (chinaHrDegreePicker) {
          el = chinaHrDegreePicker;
          elType = "select";
        }
      }
      if (isChinaTelecomHotjobPage() && label && label.closest) {
        var hotjobBasicRow = label.closest(".mdf-table-cell");
        var hotjobBasicDate = hotjobBasicRow && hotjobBasicRow.querySelector("input.dayType");
        if (hotjobBasicDate && (
          AF.DomUtils.isDateValue(value) ||
          /^(graduationDate|availability|birthDate|birthday)$/.test(String(fieldKey || ""))
        )) {
          el = hotjobBasicDate;
          elType = "date";
        }
      }
      if (!el) {
        if (labelBelongsToLockedField(label)) {
          if (AF.FillTrace) AF.FillTrace.event("locked_field", labelText + "：不可编辑，已跳过", "skipped");
          await AF.Utils.sleep(this.operationDelay);
          continue;
        }
        this.failedFields.push({ fieldKey: fieldKey, label: labelText, reason: "element not found" });
        await AF.Utils.sleep(this.operationDelay);
        continue;
      }

      if (controlsAreLocked(el)) {
        if (AF.FillTrace) AF.FillTrace.event("locked_field", labelText + "：不可编辑，已跳过", "skipped");
        await AF.Utils.sleep(this.operationDelay);
        continue;
      }

      try {
        if (await fillProvinceCityPair(label, value)) {
          this.filledFieldsCount++;
          if (fieldCheckpointRuntime && typeof fieldCheckpointRuntime.markCompleted === "function") {
            await fieldCheckpointRuntime.markCompleted(fieldCheckpointMeta);
          }
          await AF.Utils.sleep(this.operationDelay);
          continue;
        }
        if (AF.CurrentEndDate && fieldKey === "endTime" && AF.CurrentEndDate.isCurrentValue(value)) {
          var currentResult = await AF.CurrentEndDate.resolve(fieldKey, value, label, el);
          if (currentResult.handled) {
            this.filledFieldsCount++;
            if (fieldCheckpointRuntime && typeof fieldCheckpointRuntime.markCompleted === "function") {
              fieldCheckpointMeta.controlType = "date";
              await fieldCheckpointRuntime.markCompleted(fieldCheckpointMeta);
            }
            await AF.Utils.sleep(this.operationDelay);
            continue;
          }
          value = currentResult.value;
        }
        // 源码行13188-13196: 类型二次修正。注意源码里 ElementMatcher 返回的类型叫
        // "input"，本重建版契约里对应的类型名是 "text"。
        var resolvedType = resolveFillType(el, elType, value);
        if (
          category === "示例资料" &&
          fieldKey === "city" &&
          /(就读院校|院校|学校|毕业院校)所在城市|院校城市/.test(labelText) &&
          el.closest && el.closest(".phoenix-select") &&
          AF.DomUtils && typeof AF.DomUtils.resolveEducationLocationPath === "function"
        ) {
          var 示例资料LocationPath = AF.DomUtils.resolveEducationLocationPath(data);
          if (示例资料LocationPath.length >= 2) value = 示例资料LocationPath;
        }
        value = buildEducationMajorCascaderValue(category, fieldKey, data, value, el);
        if (resolvedType === "search") value = buildEducationDialogChoiceValue(category, fieldKey, data, value);

        var capabilityContext = this.resolveCapabilityContext(category, fieldKey, labelText, el, resolvedType);
        AF.FillTrace.setFieldContext({ category: category, label: labelText, fieldKey: fieldKey, plannedValue: value });
        fieldCheckpointMeta.controlType = resolvedType;
        var ok = await AF.FormHandler.fillFormElement(el, value, resolvedType, capabilityContext);
        if (ok) {
          this.filledFieldsCount++;
          if (fieldCheckpointRuntime && typeof fieldCheckpointRuntime.markCompleted === "function") {
            await fieldCheckpointRuntime.markCompleted(fieldCheckpointMeta);
          }
        } else {
          this.failedFields.push({ fieldKey: fieldKey, label: labelText, reason: "fill failed" });
          if (fieldCheckpointRuntime && typeof fieldCheckpointRuntime.pause === "function" &&
              isSafeFormFieldCheckpointControl(el, resolvedType)) {
            await fieldCheckpointRuntime.pause(fieldCheckpointMeta, "普通字段填写失败");
          }
        }
      } catch (err) {
        var checkpointErrorReason = String((err && err.message) || err);
        this.failedFields.push({
          fieldKey: fieldKey,
          label: labelText,
          reason: checkpointErrorReason,
        });
        if (fieldCheckpointRuntime && typeof fieldCheckpointRuntime.pause === "function" &&
            fieldCheckpointMeta.controlType && isSafeFormFieldCheckpointControl(el, fieldCheckpointMeta.controlType)) {
          await fieldCheckpointRuntime.pause(fieldCheckpointMeta, checkpointErrorReason);
        }
      }
      await AF.Utils.sleep(this.operationDelay);
      if (fieldCheckpointRuntime && fieldCheckpointRuntime.paused) break;
    }

    this.currentLabelText = null;
    this.currentLabel = null;
  };

  function normalizeCustomQuestion(text) {
    return String(text || "")
      .replace(/[\s：:*?？（）()【】\[\]「」'"“”‘’.,，。;；、]/g, "")
      .replace(/必填|选填|请输入|请选择/g, "")
      .toLowerCase();
  }

  function customQuestionAnswer(resumeData, labelText) {
    var wanted = normalizeCustomQuestion(labelText);
    if (!wanted || !resumeData || !Array.isArray(resumeData.customAnswers)) return null;
    for (var i = 0; i < resumeData.customAnswers.length; i++) {
      var row = resumeData.customAnswers[i];
      if (!row) continue;
      if (normalizeCustomQuestion(row.question) === wanted && row.answer != null && String(row.answer).trim() !== "") {
        return String(row.answer);
      }
    }
    return null;
  }

  function customTargetAlreadyHasValue(element) {
    if (!element) return false;
    try {
      var radios = element.matches && element.matches("input[type='radio'], input[type='checkbox']")
        ? [element] : Array.from(element.querySelectorAll && element.querySelectorAll("input[type='radio'], input[type='checkbox']") || []);
      if (radios.some(function (node) { return !!node.checked; })) return true;
    } catch (e) {}
    try {
      if (element.value != null && String(element.value).trim() !== "") return true;
    } catch (e2) {}
    try {
      var selected = element.closest && element.closest(".el-form-item, .ant-form-item, .form-item, .field-item");
      var node = selected && selected.querySelector(".el-select__selected-item, .ant-select-selection-item, .next-select-values em[title]");
      if (node && String(node.getAttribute && node.getAttribute("title") || node.textContent || "").trim()) return true;
    } catch (e3) {}
    return false;
  }

  FormHandler.prototype.fillCustomAnswers = async function (labels) {
    var resumeData = this.dataMatcher.resumeData || {};
    if (!Array.isArray(resumeData.customAnswers) || !resumeData.customAnswers.length) return 0;
    var filled = 0;
    for (var i = 0; i < labels.length; i++) {
      if (this.shouldStop && this.shouldStop()) break;
      var label = labels[i];
      var labelText = AF.LabelUtils.getLabelText(label);
      if (!labelText) continue;
      // Never use custom Q&A to answer consent/declaration/final-action prompts automatically.
      if (/同意|授权|隐私|声明|真实性|背景调查|最终提交|立即投递|确认投递/.test(labelText)) continue;
      var answer = customQuestionAnswer(resumeData, labelText);
      if (answer == null) continue;
      var found = this.elementMatcher.findElementAndTypeByLabel(label);
      if (!found || !found.element || customTargetAlreadyHasValue(found.element)) continue;
      var resolvedType = resolveFillType(found.element, found.type, answer);
      var ok = await AF.FormHandler.fillFormElement(found.element, answer, resolvedType, { source: "custom_question_bank" });
      if (ok) { this.filledFieldsCount++; filled++; }
      else this.failedFields.push({ fieldKey: "customAnswer", label: labelText, reason: "自定义问答填写失败" });
      await AF.Utils.sleep(20);
    }
    return filled;
  };

  // ============ fillSimpleForm (源码行13228-13270) ============
  FormHandler.prototype.fillSimpleForm = async function (labels) {
    try {
      var valid = this.filterValidLabels(labels);
      if (!valid || !valid.length) return false;

      var resumeData = this.dataMatcher.resumeData || {};
      var 示例资料Info = resumeData.示例资料Info;
      if (!示例资料Info) return false;

      await this.fillLabels(valid, "示例资料Info", 示例资料Info);
      if (this.fieldCheckpointRuntime && this.fieldCheckpointRuntime.paused) return true;

      // 非源码逻辑 (任务书要求的"合理"扩展): 源码 fillSimpleForm 只填 示例资料Info，
      // 这里额外用同一批 label 再匹配一次 jobIntention 字典 (比如"期望城市"这类
      // 示例资料字段)。因为 findFieldByCategory 按分类字典查找，示例资料Info 已经
      // 填过的 label 不会在 jobIntention 字典里再命中，不会重复填写或误填。
      var jobIntention = resumeData.jobIntention;
      if (jobIntention) {
        await this.fillLabels(valid, "jobIntention", jobIntention);
      }
      if (this.fieldCheckpointRuntime && this.fieldCheckpointRuntime.paused) return true;
      await this.fillCustomAnswers(valid);

      this.currentLabelText = null;
      this.currentLabel = null;
      return true;
    } catch (err) {
      this.currentLabelText = null;
      this.currentLabel = null;
      return false;
    }
  };

  // ============ fillBasicInfo — 对象型分类 (源码行12884-13113) ============
  FormHandler.prototype.fillBasicInfo = async function (sectionEl, title, options) {
    options = options || {};
    try {
      var container = findSectionContainer(this.elementMatcher, sectionEl);
      var labels = this.filterValidLabels(labelsWithinContainer(this.elementMatcher, container));

      var categoryInfo;
      if (options.specificCategory) {
        var raw = this.dataMatcher.resumeData && this.dataMatcher.resumeData[options.specificCategory];
        if (!raw) return false;
        categoryInfo = {
          category: options.specificCategory,
          type: Array.isArray(raw) ? "array" : "object",
          data: Array.isArray(raw) ? raw.slice() : Object.assign({}, raw),
        };
      } else {
        categoryInfo = this.dataMatcher.getCategoryByTitle(title, options);
        if (!categoryInfo) return false;
      }

      var category = categoryInfo.category;
      var data = categoryInfo.data;

      if (!labels.length) {
        // 源码行12955-12999: 只有 示例资料Introduction 板块会在没找到 label 时，
        // 尝试点一次"添加"按钮再重新扫描一次 (有的网站自我介绍要先点"添加"才出现输入框)
        if (category === "示例资料Introduction") {
          var addBtn = findAddButtonIn(container);
          if (addBtn) {
            await AF.DomUtils.safeClickElement(addBtn);
            await AF.Utils.sleep(800);
            // Formily 点击“添加”后可能整体替换模块节点，重新按当前标题定位，
            // 避免继续在已脱离 document 的旧容器上扫描。
            var freshContainer = findSectionContainer(this.elementMatcher, sectionEl);
            if (freshContainer && freshContainer.isConnected) container = freshContainer;
            labels = this.filterValidLabels(labelsWithinContainer(this.elementMatcher, container));
          }
        }
        if (!labels.length) return false;
      }

      var previousSectionTitle = this.currentSectionTitle;
      this.currentSectionTitle = String(title || "");
      await this.fillLabels(labels, category, data);
      this.currentSectionTitle = previousSectionTitle || "";
      return true;
    } catch (err) {
      return false;
    }
  };


  // Build153: every RecordGraph-owned 示例资料 category shares the same Action
  // Cursor contract. This is capability-driven, not a site whitelist. A category
  // still cannot execute unless RecordGraph proves the current editor owner and
  // semantic mappings resolve inside that owned scope.
  var UNIVERSAL_ACTION_CURSOR_REPEAT_CATEGORIES = {
    示例资料: true,
    示例资料Experience: true,
    示例资料Experience: true,
    示例资料Experience: true,
    campusLeadership: true,
    campusActivities: true,
    示例资料Experience: true,
    示例资料: true,
    示例资料: true,
    publications: true,
    示例资料s: true,
    示例资料Skills: true,
    示例资料Members: true
  };

  function supportsUniversalRepeatActionCursor(category) {
    category = String(category || "");
    if (AF.RecordGraph && typeof AF.RecordGraph.supportsCategory === "function") {
      return !!AF.RecordGraph.supportsCategory(category);
    }
    return !!UNIVERSAL_ACTION_CURSOR_REPEAT_CATEGORIES[category];
  }

  function graphRepeatActionId(mapping) {
    mapping = mapping || {};
    var fieldKey = String(mapping.fieldKey || "");
    var fieldId = String(mapping.fieldId || "");
    return fieldKey ? ("FIELD:" + fieldKey + (fieldId ? (":" + fieldId) : "")) : "";
  }

  function graphCheckpointNextAction(checkpoint) {
    if (!checkpoint) return "";
    return String(checkpoint.actionCursor && checkpoint.actionCursor.nextAction || checkpoint.nextAction || "");
  }

  function graphCheckpointCompletedActions(checkpoint) {
    if (!checkpoint) return [];
    var direct = Array.isArray(checkpoint.completedActions) ? checkpoint.completedActions : [];
    var nested = checkpoint.actionCursor && Array.isArray(checkpoint.actionCursor.completedActions) ? checkpoint.actionCursor.completedActions : [];
    return (nested.length ? nested : direct).map(String).filter(Boolean);
  }

  function nextGraphRepeatAction(resolvedMappings, rowData, currentIndex) {
    for (var i = Number(currentIndex || 0) + 1; i < (resolvedMappings || []).length; i++) {
      var mapping = resolvedMappings[i] || {};
      var fieldKey = String(mapping.fieldKey || "");
      if (!fieldKey) continue;
      var value = rowData && rowData[fieldKey];
      if (value == null || value === "") continue;
      var actionId = graphRepeatActionId(mapping);
      if (actionId) return actionId;
    }
    return "SAVE";
  }

  function uniqueStrings(values) {
    var out = [];
    (Array.isArray(values) ? values : []).forEach(function (value) {
      var text = String(value || "");
      if (text && out.indexOf(text) === -1) out.push(text);
    });
    return out;
  }

  function buildGraphRepeatRecordMeta(category, title, index, total, row) {
    var fingerprint = AF.CheckpointCore && typeof AF.CheckpointCore.recordFingerprint === "function"
      ? AF.CheckpointCore.recordFingerprint(row || {}) : "";
    return {
      category: String(category || ""),
      sectionTitle: String(title || category || "经历"),
      示例资料Index: Number(index),
      示例资料Total: Number(total || 0),
      recordFingerprint: String(fingerprint || ""),
      row: row || {}
    };
  }

  function visibleOwnedRuntimeNodes(scope, selector) {
    if (!scope || !selector) return [];
    var doc = scope.ownerDocument || document;
    var nodes = [];
    try { nodes = Array.from(doc.querySelectorAll(selector)); } catch (e) { return []; }
    return nodes.filter(function (node) {
      return node && (scope === node || (scope.contains && scope.contains(node))) &&
        (!AF.DomUtils || typeof AF.DomUtils.isElementVisible !== "function" || AF.DomUtils.isElementVisible(node));
    });
  }

  function findGraphRepeatManualSaveAction(scope) {
    if (!scope || !scope.querySelectorAll) return null;
    var matches = Array.from(scope.querySelectorAll("button, a, [role='button'], input[type='button'], input[type='submit']")).filter(function (node) {
      if (!node || node.disabled) return false;
      if (AF.DomUtils && typeof AF.DomUtils.isElementVisible === "function" && !AF.DomUtils.isElementVisible(node)) return false;
      var text = String(node.innerText || node.textContent || node.value || node.getAttribute && (node.getAttribute("aria-label") || node.getAttribute("title")) || "")
        .replace(/\s+/g, "").trim();
      if (!text || /删除|移除|提交|投递|申请|下一步|返回|取消|关闭/i.test(text)) return false;
      return /^(保存|确定|完成)$|保存(?:家庭成员|教育|工作|实习|项目|获奖|奖励|荣誉|经历|信息|记录)/.test(text);
    });
    // Saving is a transaction boundary. A fuzzy "first save-like button" is not
    // enough evidence; automatic recovery may only act when the owned editor has
    // exactly one eligible save action.
    return matches.length === 1 ? matches[0] : null;
  }

  function findGraphRepeatManualAddAction(scope) {
    if (!scope || !scope.querySelectorAll) return null;
    var candidates = Array.from(scope.querySelectorAll("button, a, [role='button'], input[type='button']")).filter(function (node) {
      if (!node || node.disabled) return false;
      if (AF.DomUtils && typeof AF.DomUtils.isElementVisible === "function" && !AF.DomUtils.isElementVisible(node)) return false;
      var text = String(node.innerText || node.textContent || node.value || node.getAttribute && (node.getAttribute("aria-label") || node.getAttribute("title")) || "")
        .replace(/\s+/g, "").trim();
      if (!text || /删除|移除|保存|确定|完成|提交|投递|申请|下一步|返回|取消|关闭/i.test(text)) return false;
      return /^(?:添加|新增)(?:记录|经历|信息|一条)?$|(?:添加|新增).{0,12}(?:家庭|亲属|教育|工作|实习|项目|语言|外语|学生|校园|获奖|奖励|证书|资格|培训|论文|专利|经历|成员|记录)/.test(text);
    });
    return candidates.length === 1 ? candidates[0] : null;
  }

  function resolveGraphRuntimeFillType(controlType, element, value) {
    var raw = String(controlType || "").toLowerCase();
    var base = "text";
    if (raw === "radio") base = "radio";
    else if (raw === "checkbox") base = "checkbox";
    else if (raw === "native-select" || raw === "select") base = "select";
    else if (raw === "textarea") base = "longText";
    else if (raw === "search") base = "search";
    else if (raw === "date") base = "date";
    return resolveFillType(element, base, value);
  }

  // Build145: school/degree on graph-backed 示例资料 editors are identity-bearing
  // choice fields. Treat them as dropdown transactions instead of text setters.
  // The mature product already centralizes dropdown execution in SelectAdapter;
  // this bridge only supplies strict candidate order + post-selection readback.
  function graphEducationChoiceCandidates(category, fieldKey, rowData) {
    if (String(category || "") !== "示例资料") return [];
    var key = String(fieldKey || "");
    if (key === "school") return [rowData && rowData.school].filter(function (v) { return v != null && String(v).trim(); });
    if (key !== "degree") return [];
    var seen = Object.create(null);
    return [rowData && rowData.degreeDetailed, rowData && rowData.degreeSimple, rowData && rowData.degree].filter(function (v) {
      var text = v == null ? "" : String(v).trim();
      if (!text || seen[text]) return false;
      seen[text] = true;
      return true;
    });
  }

  function graphChoiceReadValue(element) {
    try {
      if (AF.FillTrace && typeof AF.FillTrace.readElementValue === "function") return String(AF.FillTrace.readElementValue(element) || "").trim();
    } catch (e) {}
    try { return String(element && element.value || "").trim(); } catch (e2) { return ""; }
  }

  function graphChoiceExactMatch(expected, actual) {
    var norm = function (v) { return String(v == null ? "" : v).replace(/[\s：:*?？（）()【】\[\]「」'"“”‘’.,，。;；、]/g, "").toLowerCase(); };
    var e = norm(expected);
    var a = norm(actual);
    return !!e && e === a;
  }

  function graphChoiceCapabilityContext(baseContext, element) {
    var context = Object.assign({}, baseContext || {});
    var capability = Object.assign({}, context.capability || {});
    capability.fillType = "select";
    capability.matchMode = "exact";
    capability.fallback = "leaveEmpty";
    var detected = null;
    try { detected = AF.SelectAdapter && typeof AF.SelectAdapter.detectType === "function" ? AF.SelectAdapter.detectType(element) : null; } catch (e) {}
    // Unknown visual dropdowns use the existing mature custom adapter rather than
    // the dangerous generic value setter. Known Ant/Element/Next/etc keep their
    // own adapter and merely receive strict matching semantics.
    var registeredAdapter = capability.adapter && AF.SelectAdapter && AF.SelectAdapter._registry && AF.SelectAdapter._registry[capability.adapter];
    if (!detected && !registeredAdapter) {
      capability.forceAdapter = true;
      capability.adapter = "custom";
    }
    context.capability = capability;
    return context;
  }

  async function fillGraphEducationChoice(element, candidates, capabilityContext) {
    var list = Array.isArray(candidates) ? candidates : [];
    if (!element || !list.length || !AF.SelectAdapter) return { success: false, value: "", actual: "" };
    var exactContext = graphChoiceCapabilityContext(capabilityContext, element);
    for (var i = 0; i < list.length; i++) {
      var candidate = String(list[i] == null ? "" : list[i]).trim();
      if (!candidate) continue;
      if (i > 0) {
        try { document.body && document.body.click && document.body.click(); } catch (e) {}
        await AF.Utils.sleep(100);
      }
      var ok = await AF.FormHandler.fillFormElement(element, candidate, "select", exactContext);
      await AF.Utils.sleep(180);
      var actual = graphChoiceReadValue(element);
      if (ok && graphChoiceExactMatch(candidate, actual)) {
        return { success: true, value: candidate, actual: actual };
      }
    }
    return { success: false, value: "", actual: graphChoiceReadValue(element) };
  }


  // Build147: human-review checkpoints are record-scoped. The user may correct
  // only the fields automation could not safely commit, then rerun. Those
  // corrected values become temporary HUMAN_CONFIRMED overrides for this active
  // recovery session and must never be overwritten by the same rerun.
  function graphHumanOverrideMeta(category, recordIndex, fieldKey, label) {
    return {
      category: String(category || ""),
      recordIndex: Number(recordIndex),
      fieldKey: String(fieldKey || ""),
      label: String(label || fieldKey || "")
    };
  }

  function graphReviewCheckpointForRecord(handler, recordMeta, category, recordIndex) {
    var checkpoint = handler && handler.recordCheckpointRuntime && handler.recordCheckpointRuntime.previousCheckpoint;
    var reasonCode = String(checkpoint && checkpoint.reasonCode || "");
    if (!checkpoint || (reasonCode !== "manual_record_review_required" && reasonCode !== "manual_record_action_required")) return null;
    var acknowledgeMode = String(checkpoint.acknowledgeMode || "");
    // Build150 keeps Build147/148 checkpoints readable, but execution authority is
    // the action cursor. HumanOverride is diagnostic only.
    if (acknowledgeMode !== "resume_at_action_cursor" && acknowledgeMode !== "review_then_save") return null;
    if (String(checkpoint.category || "") !== String(category || "")) return null;
    if (Number(checkpoint.示例资料Index) !== Number(recordIndex)) return null;
    if (checkpoint.recordFingerprint && recordMeta && recordMeta.recordFingerprint && String(checkpoint.recordFingerprint) !== String(recordMeta.recordFingerprint)) return null;
    return checkpoint;
  }

  async function captureGraphManualOverrides(handler, owner, mappings, category, recordIndex, checkpoint) {
    var confirmed = [];
    if (!checkpoint || !AF.CheckpointCore || typeof AF.CheckpointCore.markHumanOverride !== "function") return confirmed;
    var pending = Array.isArray(checkpoint.manualFields) ? checkpoint.manualFields : [];
    for (var i = 0; i < pending.length; i++) {
      var fieldKey = String(pending[i] || "");
      if (!fieldKey) continue;
      var mapping = (mappings || []).find(function (item) { return item && String(item.fieldKey || "") === fieldKey; });
      if (!mapping) continue;
      var nodes = visibleOwnedRuntimeNodes(owner && owner.editorScope, String(mapping.selector || ""));
      if (nodes.length !== 1) continue;
      var actual = graphChoiceReadValue(nodes[0]);
      if (!String(actual || "").trim()) continue;
      var semanticLabel = fieldKey;
      try {
        var semanticMappings = handler.elementMatcher && handler.elementMatcher.config && handler.elementMatcher.config._aiSemanticPatch && handler.elementMatcher.config._aiSemanticPatch.fieldMappings || [];
        var semanticHit = semanticMappings.find(function (item) { return item && String(item.fieldId || "") === String(mapping.fieldId || ""); });
        if (semanticHit && semanticHit.label) semanticLabel = String(semanticHit.label);
      } catch (e) {}
      await AF.CheckpointCore.markHumanOverride(graphHumanOverrideMeta(category, recordIndex, fieldKey, semanticLabel), actual, "checkpoint_manual_review");
      confirmed.push(fieldKey);
    }
    return confirmed;
  }

  async function graphFieldHasHumanOverride(category, recordIndex, fieldKey, label) {
    if (!AF.CheckpointCore || typeof AF.CheckpointCore.hasHumanOverride !== "function") return false;
    try { return !!(await AF.CheckpointCore.hasHumanOverride(graphHumanOverrideMeta(category, recordIndex, fieldKey, label))); }
    catch (e) { return false; }
  }

  async function clickAndVerifyGraphRepeatSave(editorScope, saveAction) {
    if (!editorScope || !saveAction) return false;
    var clicked = false;
    try {
      if (AF.DomUtils && typeof AF.DomUtils.safeClickElement === "function") clicked = !!(await AF.DomUtils.safeClickElement(saveAction));
      else if (typeof saveAction.click === "function") { saveAction.click(); clicked = true; }
    } catch (e) { clicked = false; }
    if (!clicked) return false;
    for (var i = 0; i < 18; i++) {
      await AF.Utils.sleep(100);
      var connected = editorScope.isConnected !== false;
      var visible = connected;
      try {
        if (connected && AF.DomUtils && typeof AF.DomUtils.isElementVisible === "function") visible = !!AF.DomUtils.isElementVisible(editorScope);
      } catch (e2) {}
      if (!connected || !visible) return true;
    }
    return false;
  }

  function 示例资料RecordRuntimeMappings(category) {
    try {
      var patch = AF.RuntimeSemanticPatch;
      if (!patch || !Array.isArray(patch.recordSelectorMappings)) return [];
      if (patch.hostname && String(patch.hostname).toLowerCase() !== String(location.hostname || "").toLowerCase()) return [];
      if (patch.pathname && String(patch.pathname) !== String(location.pathname || "/")) return [];
      return patch.recordSelectorMappings.filter(function (item) {
        return item && String(item.category || "") === String(category || "") && item.selector && item.fieldKey;
      });
    } catch (e) { return []; }
  }

  function 示例资料RecordCompleted(handler, category, title, data, index, row) {
    if (!handler || !handler.recordCheckpointRuntime || typeof handler.recordCheckpointRuntime.shouldSkip !== "function") return false;
    return handler.recordCheckpointRuntime.shouldSkip(buildGraphRepeatRecordMeta(category, title, index, data.length, row));
  }

  // Build142: generic Graph-backed RepeatRecord bridge for an editor that is
  // already open on the page.  AI still cannot choose record ownership: the
  // runtime selector metadata is inert until RecordGraph proves section/category
  // scope and resolves the current editor to one profile record.
  FormHandler.prototype.fillGraphBackedRepeatRecord = async function (sectionEl, title, options) {
    options = options || {};
    var categoryInfo = null;
    try {
      if (Array.isArray(options.dataOverride)) {
        categoryInfo = {
          category: options.categoryOverride || options.specificCategory,
          type: "array",
          data: options.dataOverride.slice()
        };
      } else if (options.specificCategory) {
        var specific = this.dataMatcher.resumeData && this.dataMatcher.resumeData[options.specificCategory];
        if (!Array.isArray(specific)) return { handled: false, success: false };
        categoryInfo = { category: options.specificCategory, type: "array", data: specific.slice() };
      } else {
        categoryInfo = this.dataMatcher.getCategoryByTitle(title, options);
      }
    } catch (e) { categoryInfo = null; }
    if (!categoryInfo || categoryInfo.type !== "array" || !categoryInfo.category) return { handled: false, success: false };

    var category = String(categoryInfo.category || "");
    var data = Array.isArray(categoryInfo.data) ? categoryInfo.data : [];
    if (!data.length) {
      this.lastExperienceResult = { requestedRows: 0, filledRows: 0, filledIndexes: [], mode: "graph_示例资料_record", empty: true };
      return { handled: true, success: true };
    }
    var mappings = 示例资料RecordRuntimeMappings(category);
    if (mappings.length < 2) return { handled: false, success: false };
    if (!AF.RecordGraph || typeof AF.RecordGraph.resolveRuntimeEditorOwnership !== "function") return { handled: false, success: false };

    if (this.recordCheckpointRuntime && typeof this.recordCheckpointRuntime.shouldSkip === "function") {
      var allCompletedByCheckpoint = data.every(function (row, index) {
        return 示例资料RecordCompleted(this, category, title, data, index, row);
      }, this);
      if (allCompletedByCheckpoint) {
        this.lastExperienceResult = {
          requestedRows: data.length,
          filledRows: data.length,
          filledIndexes: data.map(function (_, index) { return index; }),
          mode: "graph_示例资料_record",
          ownerStatus: "all_profile_records_completed",
          alreadyCompletedByCheckpoint: true
        };
        return { handled: true, success: true };
      }
    }

    var container = this.elementMatcher.findContainerByTitle(sectionEl);
    if (!container) {
      this.lastExperienceResult = { requestedRows: data.length, filledRows: 0, filledIndexes: [], mode: "graph_示例资料_record", error: "示例资料_section_scope_not_resolved" };
      return { handled: true, success: false };
    }

    // A saved card may collapse the editor before the next profile record is due.
    // Do not auto-click Add from heuristic DOM text.  If RecordGraph can identify
    // the next incomplete profile record and this section exposes exactly one
    // local Add action, keep the recovery session alive with a FIELD checkpoint
    // and ask the user to open the next editor manually.  A field checkpoint is
    // 示例资料al here: acknowledging it must never mark the profile record done.
    var nextIncompleteIndex = -1;
    for (var pendingIndex = 0; pendingIndex < data.length; pendingIndex++) {
      if (!示例资料RecordCompleted(this, category, title, data, pendingIndex, data[pendingIndex])) {
        nextIncompleteIndex = pendingIndex;
        break;
      }
    }
    var visibleMappedControlCount = mappings.reduce(function (count, mapping) {
      return count + (visibleOwnedRuntimeNodes(container, String(mapping && mapping.selector || "")).length ? 1 : 0);
    }, 0);
    if (nextIncompleteIndex >= 0 && visibleMappedControlCount === 0) {
      var addAction = findGraphRepeatManualAddAction(container);
      var previousRecordCheckpoint = this.recordCheckpointRuntime && this.recordCheckpointRuntime.previousCheckpoint;
      var resumedAfterConfirmedSave = !!(this.recordCheckpointRuntime && this.recordCheckpointRuntime.resumed && previousRecordCheckpoint && String(previousRecordCheckpoint.reasonCode || "") === "manual_record_save_required");
      var recoveryDepth = Number(options._graphRecoveryDepth || 0);
      // Build147: once the user has explicitly saved the previously paused
      // record and reruns, a unique section-local Add action is safe to use to
      // open the next known profile record. This is restricted to the active
      // recovery chain; ordinary runs still never auto-click Add heuristically.
      if (addAction && resumedAfterConfirmedSave && recoveryDepth < 2) {
        var addClicked = false;
        try {
          if (AF.DomUtils && typeof AF.DomUtils.safeClickElement === "function") addClicked = !!(await AF.DomUtils.safeClickElement(addAction));
          else if (typeof addAction.click === "function") { addAction.click(); addClicked = true; }
        } catch (eAdd) { addClicked = false; }
        if (addClicked) {
          await AF.Utils.sleep(350);
          var resumedOptions = Object.assign({}, options, { _graphRecoveryDepth: recoveryDepth + 1 });
          return await this.fillGraphBackedRepeatRecord(sectionEl, title, resumedOptions);
        }
      }
      if (addAction && this.fieldCheckpointRuntime && typeof this.fieldCheckpointRuntime.pause === "function") {
        var addMeta = {
          category: category,
          sectionTitle: String(title || category || "重复经历"),
          fieldKey: "__open_示例资料_editor__",
          label: "打开下一条" + String(title || "重复经历") + "编辑器",
          occurrence: nextIncompleteIndex,
          示例资料Index: nextIncompleteIndex,
          示例资料Total: data.length
        };
        var addFailureContext = {
          示例资料flowId: "autofill-core-formgraph-v1",
          stepIndex: -1,
          stepName: String(title || category || "重复经历") + " 第" + (nextIncompleteIndex + 1) + "条",
          category: category,
          示例资料Index: nextIncompleteIndex,
          示例资料Total: data.length,
          fieldKey: "__open_示例资料_editor__",
          fieldLabel: "添加/新增" + String(title || "重复经历"),
          phase: "open_editor",
          reasonCode: "manual_示例资料_editor_open_required",
          rawReason: "当前没有打开可安全归属的编辑器，需要人工点击本分区的添加/新增按钮",
          humanSummary: "下一条" + String(title || "重复经历") + "需要你先打开编辑器",
          suggestedAction: "请点击当前分区的添加/新增按钮；编辑器打开后再次点击“一键填写”。",
          recoverability: "RECOVERABLE_MANUAL",
          granularity: "field"
        };
        await this.fieldCheckpointRuntime.pause(addMeta, addFailureContext.rawReason, {
          forceRecoverable: true,
          reasonCode: addFailureContext.reasonCode,
          failureContext: addFailureContext
        });
        this.lastExperienceResult = {
          requestedRows: data.length,
          filledRows: 0,
          filledIndexes: [],
          mode: "graph_示例资料_record",
          ownerStatus: "editor_not_open_manual_add_available",
          nextRecordIndex: nextIncompleteIndex,
          manualEditorOpenPending: true
        };
        if (AF.FillTrace) AF.FillTrace.event("field_checkpoint_pause", String(title || category) + " 第" + (nextIncompleteIndex + 1) + "条待人工打开编辑器", "waiting_for_user");
        return { handled: true, success: false };
      }
    }

    var 示例资料 = this;
    var owner = AF.RecordGraph.resolveRuntimeEditorOwnership(container, category, {
      sectionTitle: title,
      siteConfig: this.elementMatcher && this.elementMatcher.config || {},
      mappings: mappings,
      profileRecords: data,
      isRecordCompleted: function (index, row) {
        if (!示例资料.recordCheckpointRuntime || typeof 示例资料.recordCheckpointRuntime.shouldSkip !== "function") return false;
        return 示例资料.recordCheckpointRuntime.shouldSkip(buildGraphRepeatRecordMeta(category, title, index, data.length, row));
      }
    });

    if (owner && owner.status === "all_profile_records_completed") {
      this.lastExperienceResult = {
        requestedRows: data.length,
        filledRows: data.length,
        filledIndexes: data.map(function (_, index) { return index; }),
        mode: "graph_示例资料_record",
        ownerStatus: owner.status,
        alreadyCompletedByCheckpoint: true
      };
      return { handled: true, success: true };
    }
    if (!owner || owner.status !== "owned" || Number(owner.confidence || 0) < 0.9 || !owner.editorScope) {
      this.lastExperienceResult = {
        requestedRows: data.length,
        filledRows: 0,
        filledIndexes: [],
        mode: "graph_示例资料_record",
        error: "示例资料_record_ownership_unresolved",
        ownerStatus: owner && owner.status || "unknown",
        identityTrace: owner && owner.identityTrace || null
      };
      return { handled: true, success: false };
    }

    var recordIndex = Number(owner.recordIndex);
    if (!Number.isInteger(recordIndex) || recordIndex < 0 || recordIndex >= data.length) {
      this.lastExperienceResult = {
        requestedRows: data.length,
        filledRows: 0,
        filledIndexes: [],
        mode: "graph_示例资料_record",
        error: "示例资料_record_index_unresolved",
        ownerStatus: owner.status
      };
      return { handled: true, success: false };
    }

    var rowData = data[recordIndex] || {};
    var recordMeta = buildGraphRepeatRecordMeta(category, title, recordIndex, data.length, rowData);
    var committedKeys = [];
    var attemptedKeys = [];
    var failures = [];
    var humanConfirmedKeys = [];
    var resolvedMappings = Array.isArray(owner.mappings) ? owner.mappings.slice() : [];
    var reviewCheckpoint = graphReviewCheckpointForRecord(this, recordMeta, category, recordIndex);
    var cursorResumeAction = reviewCheckpoint ? graphCheckpointNextAction(reviewCheckpoint) : "";
    var cursorCompletedActions = reviewCheckpoint ? graphCheckpointCompletedActions(reviewCheckpoint) : [];
    var startMappingIndex = 0;

    // Build150: resume from the exact next action. Everything before the cursor
    // is frozen, but a checkpoint in the middle of a record must continue the
    // remaining actions rather than jumping unconditionally to SAVE.
    if (reviewCheckpoint) {
      var frozenCommitted = Array.isArray(reviewCheckpoint.committedFields) ? reviewCheckpoint.committedFields.slice() : [];
      var frozenManual = Array.isArray(reviewCheckpoint.manualFields) ? reviewCheckpoint.manualFields.slice() : [];
      committedKeys = uniqueStrings(frozenCommitted);
      humanConfirmedKeys = uniqueStrings(frozenManual);

      if (!cursorResumeAction) cursorResumeAction = "SAVE"; // migration from early 147/148 markers
      if (cursorResumeAction === "SAVE") {
        var frozenFields = uniqueStrings(frozenCommitted.concat(frozenManual));
        var saveLabel = String(title || category || "当前经历") + " 第" + (recordIndex + 1) + "条";
        var saveContext = {
          示例资料flowId: "autofill-core-formgraph-v1",
          stepIndex: -1,
          stepName: saveLabel,
          category: category,
          示例资料Index: recordIndex,
          示例资料Total: data.length,
          fieldKey: "示例资料Record",
          fieldLabel: saveLabel,
          phase: "save",
          reasonCode: "manual_record_save_required",
          rawReason: "人工处理已确认；检查点之前的动作已冻结，当前经历仍需手动保存",
          humanSummary: "人工处理已确认，当前经历还需要你手动保存",
          suggestedAction: "请保存当前经历；保存完成后再次点击“一键填写”，程序会从保存点之后继续，不会重放本条经历字段。",
          recoverability: "RECOVERABLE_MANUAL",
          recordFingerprint: String(recordMeta.recordFingerprint || ""),
          granularity: "record"
        };
        if (this.recordCheckpointRuntime && typeof this.recordCheckpointRuntime.pause === "function") {
          await this.recordCheckpointRuntime.pause(recordMeta, saveContext.rawReason, {
            forceRecoverable: true,
            reasonCode: saveContext.reasonCode,
            failureContext: saveContext,
            acknowledgeMode: "complete_on_rerun",
            nextAction: "NEXT_RECORD",
            freezeBeforeCursor: true,
            committedFields: frozenFields,
            completedActions: uniqueStrings(cursorCompletedActions.concat(["SAVE_READY"]))
          });
        }
        this.lastExperienceResult = {
          requestedRows: data.length,
          filledRows: 0,
          filledIndexes: [],
          mode: "graph_示例资料_record",
          universalActionCursor: supportsUniversalRepeatActionCursor(category),
          ownerStatus: owner.status,
          ownershipMode: owner.ownershipMode,
          recordIndex: recordIndex,
          attemptedFields: [],
          committedFields: frozenCommitted,
          manualReviewFields: frozenManual,
          frozenFields: frozenFields,
          actionCursor: "SAVE",
          completedActions: cursorCompletedActions,
          fieldReplaySuppressed: true,
          manualSavePending: true
        };
        if (AF.FillTrace) AF.FillTrace.event("record_action_cursor_resume", saveLabel + "：冻结检查点前动作，直接进入保存点", "waiting_for_user");
        return { handled: true, success: false };
      }

      startMappingIndex = resolvedMappings.findIndex(function (mapping) {
        return graphRepeatActionId(mapping) === cursorResumeAction;
      });
      if (startMappingIndex < 0) {
        this.lastExperienceResult = {
          requestedRows: data.length,
          filledRows: 0,
          filledIndexes: [],
          mode: "graph_示例资料_record",
          universalActionCursor: supportsUniversalRepeatActionCursor(category),
          error: "示例资料_record_action_cursor_target_missing",
          ownerStatus: owner.status,
          ownershipMode: owner.ownershipMode,
          recordIndex: recordIndex,
          actionCursor: cursorResumeAction,
          fieldReplaySuppressed: true
        };
        return { handled: true, success: false };
      }
      if (AF.FillTrace) AF.FillTrace.event("record_action_cursor_resume", String(title || category) + "：从 " + cursorResumeAction + " 继续", "resume");
    }


    for (var i = startMappingIndex; i < resolvedMappings.length; i++) {
      if (this.shouldStop && this.shouldStop()) break;
      var mapping = resolvedMappings[i] || {};
      var fieldKey = String(mapping.fieldKey || "");
      if (!fieldKey) continue;
      var value = rowData[fieldKey];
      if (value == null || value === "") continue;
      value = normalizeLanguageScoreValue(category, fieldKey, value);
      var freshNodes = visibleOwnedRuntimeNodes(owner.editorScope, String(mapping.selector || ""));
      if (freshNodes.length !== 1) {
        failures.push({ fieldKey: fieldKey, label: fieldKey, reason: freshNodes.length > 1 ? "示例资料_record_selector_ownership_ambiguous" : "示例资料_record_owned_control_not_found" });
        continue;
      }
      var element = freshNodes[0];
      var choiceCandidates = graphEducationChoiceCandidates(category, fieldKey, rowData);
      var controlType = choiceCandidates.length ? "select" : resolveGraphRuntimeFillType(mapping.controlType, element, value);
      var semanticLabel = fieldKey;
      try {
        var semanticMappings = this.elementMatcher && this.elementMatcher.config && this.elementMatcher.config._aiSemanticPatch && this.elementMatcher.config._aiSemanticPatch.fieldMappings || [];
        var semanticHit = semanticMappings.find(function (item) { return item && String(item.fieldId || "") === String(mapping.fieldId || ""); });
        if (semanticHit && semanticHit.label) semanticLabel = String(semanticHit.label);
      } catch (e) {}
      var capabilityContext = this.resolveCapabilityContext(category, fieldKey, semanticLabel, element, controlType);
      if (AF.FillTrace) AF.FillTrace.setFieldContext({
        category: category,
        label: semanticLabel,
        fieldKey: fieldKey,
        plannedValue: value,
        source: "graph_示例资料_record_bridge"
      });
      attemptedKeys.push(fieldKey);
      var ok = false;
      var choiceResult = null;
      if (choiceCandidates.length) {
        choiceResult = await fillGraphEducationChoice(element, choiceCandidates, capabilityContext);
        ok = !!(choiceResult && choiceResult.success);
      } else {
        ok = await AF.FormHandler.fillFormElement(element, value, controlType, capabilityContext);
      }
      var currentActionId = graphRepeatActionId(mapping);
      if (ok) {
        committedKeys = uniqueStrings(committedKeys.concat([fieldKey]));
        cursorCompletedActions = uniqueStrings(cursorCompletedActions.concat([currentActionId]));
        this.filledFieldsCount++;
      } else {
        var fillReason = choiceCandidates.length ? "示例资料_record_choice_not_committed" : "示例资料_record_field_fill_failed";
        var failure = {
          fieldKey: fieldKey,
          label: semanticLabel,
          reason: fillReason,
          choiceCandidateCount: choiceCandidates.length || undefined
        };
        failures.push(failure);

        // Build150 universal action-cursor checkpoint: for the five supported
        // RepeatRecord categories, stop at the first recoverable field failure.
        // The user completes this one action manually; rerun resumes at the next
        // field action (or SAVE if this was the last field), never replaying the
        // already-completed prefix.
        if (supportsUniversalRepeatActionCursor(category) && this.recordCheckpointRuntime && typeof this.recordCheckpointRuntime.pause === "function") {
          Array.prototype.push.apply(this.failedFields, failures);
          var nextAction = nextGraphRepeatAction(resolvedMappings, rowData, i);
          var actionLabel = String(title || category || "当前经历") + " 第" + (recordIndex + 1) + "条";
          var actionContext = {
            示例资料flowId: "autofill-core-formgraph-v1",
            stepIndex: -1,
            stepName: actionLabel,
            category: category,
            示例资料Index: recordIndex,
            示例资料Total: data.length,
            fieldKey: fieldKey,
            fieldLabel: semanticLabel,
            phase: "manual_field",
            reasonCode: "manual_record_action_required",
            rawReason: String(semanticLabel || fieldKey) + "未能安全自动填写，需要人工处理",
            humanSummary: actionLabel + "的“" + String(semanticLabel || fieldKey) + "”需要你人工处理",
            suggestedAction: "请只处理当前字段；完成后再次点击“一键填写”，程序会从下一个动作继续，不会重放检查点之前的内容。",
            recoverability: "RECOVERABLE_MANUAL",
            recordFingerprint: String(recordMeta.recordFingerprint || ""),
            granularity: "record"
          };
          await this.recordCheckpointRuntime.pause(recordMeta, actionContext.rawReason, {
            forceRecoverable: true,
            reasonCode: actionContext.reasonCode,
            failureContext: actionContext,
            acknowledgeMode: "resume_at_action_cursor",
            nextAction: nextAction,
            freezeBeforeCursor: true,
            manualFields: [fieldKey],
            committedFields: uniqueStrings(committedKeys.concat(humanConfirmedKeys)),
            completedActions: uniqueStrings(cursorCompletedActions.concat([currentActionId]))
          });
          this.lastExperienceResult = {
            requestedRows: data.length,
            filledRows: 0,
            filledIndexes: [],
            mode: "graph_示例资料_record",
            universalActionCursor: true,
            error: "manual_record_action_required",
            ownerStatus: owner.status,
            ownershipMode: owner.ownershipMode,
            recordIndex: recordIndex,
            attemptedFields: attemptedKeys,
            committedFields: committedKeys,
            manualReviewFields: [fieldKey],
            manualReviewPending: true,
            actionCursor: nextAction,
            completedActions: uniqueStrings(cursorCompletedActions.concat([currentActionId])),
            fieldReplaySuppressed: !!reviewCheckpoint
          };
          if (AF.FillTrace) AF.FillTrace.event("record_action_cursor_pause", actionLabel + "：" + fieldKey + " -> " + nextAction, "waiting_for_user");
          return { handled: true, success: false };
        }
      }
      await AF.Utils.sleep(20);
    }

    var identity = owner.identityFieldKeys || {};
    var satisfiedKeys = committedKeys.concat(humanConfirmedKeys.filter(function (key) { return committedKeys.indexOf(key) === -1; }));
    var primaryCommitted = identity.primary && (rowData[identity.primary] == null || rowData[identity.primary] === "" || satisfiedKeys.indexOf(identity.primary) !== -1);
    var secondaryCommitted = !identity.requireSecondary || !identity.secondary || rowData[identity.secondary] == null || rowData[identity.secondary] === "" || satisfiedKeys.indexOf(identity.secondary) !== -1;
    if (!primaryCommitted || !secondaryCommitted) {
      failures.push({ fieldKey: "示例资料Record", label: title || category, reason: "示例资料_record_identity_not_committed" });
    }

    if (failures.length) {
      var manualFailureKeys = failures.filter(function (item) {
        return item && item.fieldKey && item.fieldKey !== "示例资料Record" && /^(?:示例资料_record_choice_not_committed|示例资料_record_field_fill_failed)$/.test(String(item.reason || ""));
      }).map(function (item) { return String(item.fieldKey); }).filter(function (key, index, list) { return list.indexOf(key) === index; });
      var hasUnsafeFailure = failures.some(function (item) {
        var reason = String(item && item.reason || "");
        if (/^(?:示例资料_record_choice_not_committed|示例资料_record_field_fill_failed)$/.test(reason)) return false;
        if (reason === "示例资料_record_identity_not_committed" && identity.primary && manualFailureKeys.indexOf(String(identity.primary)) !== -1) return false;
        return true;
      });

      Array.prototype.push.apply(this.failedFields, failures);
      if (!supportsUniversalRepeatActionCursor(category) && manualFailureKeys.length && !hasUnsafeFailure && this.recordCheckpointRuntime && typeof this.recordCheckpointRuntime.pause === "function") {
        var reviewLabel = String(title || category || "当前经历") + " 第" + (recordIndex + 1) + "条";
        var reviewContext = {
          示例资料flowId: "autofill-core-formgraph-v1",
          stepIndex: -1,
          stepName: reviewLabel,
          category: category,
          示例资料Index: recordIndex,
          示例资料Total: data.length,
          fieldKey: "示例资料Record",
          fieldLabel: reviewLabel,
          phase: "manual_review",
          reasonCode: "manual_record_review_required",
          rawReason: "部分字段未能安全自动提交，需要人工确认后继续",
          humanSummary: reviewLabel + "有字段需要你人工确认",
          suggestedAction: "请只修改当前经历中未正确填写的字段；完成后再次点击“一键填写”。程序会保护你的人工结果，并在能够确认保存事务时继续。",
          recoverability: "RECOVERABLE_MANUAL",
          recordFingerprint: String(recordMeta.recordFingerprint || ""),
          granularity: "record"
        };
        await this.recordCheckpointRuntime.pause(recordMeta, reviewContext.rawReason, {
          forceRecoverable: true,
          reasonCode: reviewContext.reasonCode,
          failureContext: reviewContext,
          acknowledgeMode: "resume_at_action_cursor",
          nextAction: "SAVE",
          freezeBeforeCursor: true,
          manualFields: manualFailureKeys,
          committedFields: uniqueStrings(committedKeys.concat(humanConfirmedKeys)),
          completedActions: uniqueStrings(cursorCompletedActions.concat(["SAVE_READY"]))
        });
        this.lastExperienceResult = {
          requestedRows: data.length,
          filledRows: 0,
          filledIndexes: [],
          mode: "graph_示例资料_record",
          error: "manual_record_review_required",
          ownerStatus: owner.status,
          ownershipMode: owner.ownershipMode,
          recordIndex: recordIndex,
          attemptedFields: attemptedKeys,
          committedFields: committedKeys,
          manualReviewFields: manualFailureKeys,
          manualReviewPending: true
        };
        if (AF.FillTrace) AF.FillTrace.event("record_checkpoint_pause", reviewLabel + "待人工复核字段：" + manualFailureKeys.join(","), "waiting_for_user");
        return { handled: true, success: false };
      }

      this.lastExperienceResult = {
        requestedRows: data.length,
        filledRows: 0,
        filledIndexes: [],
        mode: "graph_示例资料_record",
        error: failures[0].reason,
        ownerStatus: owner.status,
        ownershipMode: owner.ownershipMode,
        recordIndex: recordIndex,
        attemptedFields: attemptedKeys,
        committedFields: committedKeys,
        humanConfirmedFields: humanConfirmedKeys
      };
      return { handled: true, success: false };
    }

    if (!satisfiedKeys.length) {
      this.lastExperienceResult = {
        requestedRows: data.length,
        filledRows: 0,
        filledIndexes: [],
        mode: "graph_示例资料_record",
        error: "示例资料_record_no_fields_committed",
        ownerStatus: owner.status,
        recordIndex: recordIndex
      };
      return { handled: true, success: false };
    }

    var saveAction = findGraphRepeatManualSaveAction(owner.editorScope);
    var universalCursorCategory = supportsUniversalRepeatActionCursor(category);

    // Build150: these five generic RepeatRecord categories stop at a manual SAVE
    // boundary even when a site-specific save button cannot be recognized. We are
    // not clicking anything here: the user's next One-click Fill is the explicit
    // acknowledgement that the manual save was completed, matching the proven
    // Build142 contract and making the flow usable on unfamiliar sites.
    if ((saveAction || universalCursorCategory) && this.recordCheckpointRuntime && typeof this.recordCheckpointRuntime.pause === "function") {
      var normalSaveLabel = String(title || category || "当前经历") + " 第" + (recordIndex + 1) + "条";
      var normalSaveContext = {
        示例资料flowId: "autofill-core-formgraph-v1",
        stepIndex: -1,
        stepName: normalSaveLabel,
        category: category,
        示例资料Index: recordIndex,
        示例资料Total: data.length,
        fieldKey: "示例资料Record",
        fieldLabel: normalSaveLabel,
        phase: "save",
        reasonCode: "manual_record_save_required",
        rawReason: "当前经历已填写，仍需手动保存",
        humanSummary: "当前经历已填写，但还需要你手动保存",
        suggestedAction: "请保存当前经历；保存完成后再次点击“一键填写”，程序会从保存点之后继续。",
        recoverability: "RECOVERABLE_MANUAL",
        recordFingerprint: String(recordMeta.recordFingerprint || ""),
        granularity: "record"
      };
      var allCommittedFields = uniqueStrings(committedKeys.concat(humanConfirmedKeys));
      await this.recordCheckpointRuntime.pause(recordMeta, normalSaveContext.rawReason, {
        forceRecoverable: true,
        reasonCode: normalSaveContext.reasonCode,
        failureContext: normalSaveContext,
        acknowledgeMode: "complete_on_rerun",
        nextAction: "NEXT_RECORD",
        freezeBeforeCursor: true,
        committedFields: allCommittedFields,
        completedActions: uniqueStrings(cursorCompletedActions.concat(["SAVE_READY"]))
      });
      this.lastExperienceResult = {
        requestedRows: data.length,
        filledRows: 1,
        filledIndexes: [recordIndex],
        mode: "graph_示例资料_record",
        universalActionCursor: universalCursorCategory,
        ownerStatus: owner.status,
        ownershipMode: owner.ownershipMode,
        recordIndex: recordIndex,
        attemptedFields: attemptedKeys,
        committedFields: committedKeys,
        humanConfirmedFields: humanConfirmedKeys,
        actionCursor: "SAVE",
        completedActions: cursorCompletedActions,
        saveActionObserved: !!saveAction,
        manualSavePending: true
      };
      if (AF.FillTrace) AF.FillTrace.event("record_checkpoint_pause", normalSaveLabel + "待手动保存", "waiting_for_user");
      return { handled: true, success: false };
    }

    // Categories outside the universal capability keep the stricter legacy rule:
    // unknown persistence is not equivalent to a committed RepeatRecord.
    this.lastExperienceResult = {
      requestedRows: data.length,
      filledRows: 1,
      filledIndexes: [recordIndex],
      mode: "graph_示例资料_record",
      error: "record_save_state_unknown",
      ownerStatus: owner.status,
      ownershipMode: owner.ownershipMode,
      recordIndex: recordIndex,
      attemptedFields: attemptedKeys,
      committedFields: committedKeys
    };
    return { handled: true, success: false };
  };

  // ============ fillExperience — 数组型分类总入口 (源码行13271-13303) ============
  // 先试新版方案(依赖站点 experienceConfig)，成功即返回；否则回退到旧版 fillExperienceLegacy。
  FormHandler.prototype.fillExperience = async function (sectionEl, title, options) {
    options = options || {};
    this.lastExperienceResult = null;
    // Education has one owner.  The site-config ExperienceHandler previously
    // returned true here and prevented the sequential legacy branch below from
    // ever running, while its static record bindings reused card 0.
    var routedCategory = options.specificCategory || options.categoryOverride || "";
    if (!routedCategory) {
      try {
        var routedInfo = this.dataMatcher.getCategoryByTitle(title, options);
        routedCategory = routedInfo && routedInfo.category || "";
      } catch (e) {}
    }
    if (routedCategory === "示例资料") {
      var 示例资料Rows = this.dataMatcher.resumeData && this.dataMatcher.resumeData.示例资料 || [];
      // Build143: unsupported/AI-discovered sites may now route 示例资料 through
      // the same Graph-backed RepeatRecord ownership bridge already validated on
      // 示例资料Members.  This is attempted only when RuntimeSemanticPatch carries
      // >=2 locally observed 示例资料 selectors; 示例资料wise the mature sequential
      // 示例资料 executor below remains the owner exactly as before.
      var graphEducationResult = await this.fillGraphBackedRepeatRecord(sectionEl, title, Object.assign({}, options, { specificCategory: "示例资料" }));
      if (graphEducationResult && graphEducationResult.handled) {
        writeEducationExecutionRouteTrace({
          genericPlanActionsCreated: 0,
          genericEducationExecutionCount: 0,
          graphRepeatBridgeEntered: true,
          graphRepeatBridgeHandled: true,
          graphRepeatOwnerStatus: this.lastExperienceResult && this.lastExperienceResult.ownerStatus || "",
          graphRepeatRecordIndex: this.lastExperienceResult && Number.isInteger(this.lastExperienceResult.recordIndex) ? this.lastExperienceResult.recordIndex : null,
          sequentialExecutorEntered: false,
          profileRecordCount: 示例资料Rows.length,
          recordsAttempted: this.lastExperienceResult && Number(this.lastExperienceResult.requestedRows || 0)
        });
        return !!graphEducationResult.success;
      }
      writeEducationExecutionRouteTrace({ genericPlanActionsCreated: 0, genericEducationExecutionCount: 0, graphRepeatBridgeEntered: true, graphRepeatBridgeHandled: false, sequentialExecutorEntered: true, profileRecordCount: 示例资料Rows.length, recordsAttempted: 0 });
      var 示例资料Result = await this.fillExperienceLegacy(sectionEl, title, Object.assign({}, options, { specificCategory: "示例资料" }));
      var attempted = this.lastExperienceResult && Number(this.lastExperienceResult.requestedRows || 0);
      writeEducationExecutionRouteTrace({ sequentialExecutorEntered: true, profileRecordCount: 示例资料Rows.length, recordsAttempted: attempted });
      return 示例资料Result;
    }
    // Build150: Internship / Project / Family / Awards share the same generic
    // Graph-backed RepeatRecord + action-cursor route as Education. The bridge is
    // attempted before site-config ExperienceHandler so unsupported/new sites can
    // benefit without per-site code; mature fallbacks remain intact when local
    // semantic selectors are insufficient.
    var graphRepeatResult = await this.fillGraphBackedRepeatRecord(sectionEl, title, options);
    if (graphRepeatResult && graphRepeatResult.handled) return !!graphRepeatResult.success;
    if (this.experienceHandler) {
      try {
        var okNew = await this.experienceHandler.fillExperienceByNewScheme(sectionEl, title, options);
        this.mergeFillStatsFrom(this.experienceHandler);
        if (this.shouldStop && this.shouldStop()) {
          this.lastExperienceResult = { stopped: true };
          return true;
        }
        if (okNew) {
          this.lastExperienceResult = this.experienceHandler.lastResult;
          return true;
        }
        // 新方案已经写入任意一张卡后，不允许旧方案再从第 1 条重新执行。
        // 两套方案的卡片分组方式不同，二次回退最容易造成本科字段覆盖硕士、
        // 第一家公司字段写入第二张卡。保留 partial 结果并明确返回失败即可。
        if (this.experienceHandler.lastResult && Number(this.experienceHandler.lastResult.filledRows || 0) > 0) {
          this.lastExperienceResult = this.experienceHandler.lastResult;
          return false;
        }
        if (/^campus-talent\.alibaba\.com$/i.test(location.hostname || "")) {
          this.lastExperienceResult = this.experienceHandler.lastResult;
          return false;
        }
      } catch (e) {
        this.mergeFillStatsFrom(this.experienceHandler);
        console.warn("[AF.FormHandler] 新版经历方案异常，回退旧版:", e);
        if (/^campus-talent\.alibaba\.com$/i.test(location.hostname || "")) {
          this.lastExperienceResult = this.experienceHandler.lastResult || { error: String(e) };
          return false;
        }
      }
    }
    return await this.fillExperienceLegacy(sectionEl, title, options);
  };

  // ============ resolveExperienceGroupLabel (源码行12872-12882) ============
  // 在容器里重新按 labelText 定位第 index 个同名 label（应对填写触发的 DOM 重渲染，
  // 让"加卡后 label 变化"也能拿到最新的那个元素）。
  FormHandler.prototype.resolveExperienceGroupLabel = function (container, labelText, index) {
    if (!container) return null;
    var labels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(container));
    var target = String(labelText || "").toLowerCase();
    return (
      labels.filter(function (l) {
        return AF.LabelUtils.getLabelText(l).toLowerCase() === target;
      })[index] || null
    );
  };

  function isCurrentEndValue(value) {
    return typeof value === "string" && /^(至今|目前|现在|仍在职|在职|仍在进行|当前)$/.test(value.trim());
  }

  function todayDateString() {
    var now = new Date();
    var pad = function (n) { return String(n).padStart(2, "0"); };
    return now.getFullYear() + "-" + pad(now.getMonth() + 1) + "-" + pad(now.getDate());
  }

  function linkedTemporalValue(labelEl, labelText, rowData, config) {
    if (!rowData || !rowData.startTime || !rowData.endTime || !/(时间|日期|年月)/.test(labelText || "")) return null;
    var configured = config && config.domStrategy && config.domStrategy.temporalGroups || [];
    var normalized = String(labelText || "").replace(/\s+/g, "");
    var configuredMatch = configured.some(function (group) {
      var groupLabel = String(group && group.label || "").replace(/\s+/g, "");
      return group && group.type === "linked_range" && groupLabel &&
        (normalized.indexOf(groupLabel) !== -1 || groupLabel.indexOf(normalized) !== -1);
    });
    var scope = labelEl && labelEl.closest && labelEl.closest(
      ".ant-form-item, .el-form-item, .pt-l, .pt-r, [class*='form-item' i], [role='group'], fieldset"
    );
    var dateInputs = scope ? Array.from(scope.querySelectorAll("input")).filter(function (input) {
      return AF.DomUtils.isElementVisible(input);
    }) : [];
    var domRange = Boolean(
      scope && (
        scope.querySelector(".ant-picker-range, .ant-calendar-range-picker, .el-range-editor, .next-range-picker, .next-date-picker, .next-month-picker") ||
        dateInputs.length >= 2
      )
    );
    if (!configuredMatch && !domRange) return null;
    return {
      startTime: rowData.startTime,
      endTime: rowData.endTime,
      current: isCurrentEndValue(rowData.endTime)
    };
  }

  function resolveTemporalRangeValue(rowData, capability) {
    var dayPrecision = String(capability && capability.datePrecision || "").toLowerCase() === "day";
    return {
      startTime: dayPrecision ? (rowData.startDate || rowData.startTime) : (rowData.startTime || rowData.startDate),
      endTime: dayPrecision ? (rowData.endDate || rowData.endTime) : (rowData.endTime || rowData.endDate),
      current: isCurrentEndValue(dayPrecision ? (rowData.endDate || rowData.endTime) : (rowData.endTime || rowData.endDate))
    };
  }

  function normalizedDateReadback(value) {
    var match = String(value || "").match(/(\d{4})\D+(\d{1,2})(?:\D+(\d{1,2}))?/);
    if (!match) return "";
    var output = match[1] + "-" + String(match[2]).padStart(2, "0");
    return match[3] ? output + "-" + String(match[3]).padStart(2, "0") : output;
  }

  async function verifyDateRangeReadback(element, value) {
    await AF.Utils.sleep(360);
    var found = nearestDateRangeInputScope(element);
    var inputs = found && found.inputs || [];
    var startExpected = normalizedDateReadback(value && value.startTime);
    var endExpected = normalizedDateReadback(value && value.endTime);
    var startCommitted = !!(inputs[0] && startExpected && normalizedDateReadback(inputs[0].value) === startExpected);
    var current = value && isCurrentEndValue(value.endTime);
    var endCommitted = current
      ? isCurrentEndChecked(found && found.scope)
      : !!(inputs[1] && endExpected && normalizedDateReadback(inputs[1].value) === endExpected);
    return { success: startCommitted && endCommitted, inputCount: inputs.length, startCommitted: startCommitted, endCommitted: endCommitted, currentSelected: current && endCommitted };
  }

  function recordDateDebug(capabilityContext, element, executionPath, verification) {
    try {
      var capability = capabilityContext && capabilityContext.capability || {};
      var key = String(capabilityContext && capabilityContext.category || "date") + "." + String(capabilityContext && capabilityContext.fieldKey || "field");
      var debug = JSON.parse(document.documentElement.getAttribute("data-af-date-debug") || "{}");
      var isTencentDuration = /(^|\.)qq\.com$/i.test(String(location.hostname || "")) && capabilityContext && capabilityContext.labelText === "起止时间";
      var item = isTencentDuration && element && element.closest && element.closest(".el-form-item, [class*='form-item']");
      debug[key] = {
        category: String(capabilityContext && capabilityContext.category || ""), fieldKey: String(capabilityContext && capabilityContext.fieldKey || ""), label: String(capabilityContext && capabilityContext.labelText || ""),
        detectedAdapter: capability.dateAdapter || (AF.DatePicker && AF.DatePicker.detectType && AF.DatePicker.detectType(element)) || "",
        inputCount: Number(verification && verification.inputCount || 0), rangeMode: "linked_pair", requestedPrecision: String(capability.datePrecision || ""), executionPath: executionPath,
        startCommitted: !!(verification && verification.startCommitted), endCommitted: !!(verification && verification.endCommitted), currentSelected: !!(verification && verification.currentSelected)
      };
      if (item) debug[key].structure = { formItemClass: String(item.className || ""), hasElementDateEditor: !!item.querySelector(".el-date-editor"), hasElementRangeEditor: !!item.querySelector(".el-range-editor"), inputs: Array.from(item.querySelectorAll("input")).map(function (input) { return { type: input.type || "", class: String(input.className || ""), placeholder: input.getAttribute("placeholder") || "", readonly: !!input.readOnly, ariaLabel: input.getAttribute("aria-label") || "" }; }) };
      document.documentElement.setAttribute("data-af-date-debug", JSON.stringify(debug));
    } catch (e) {}
  }

  async function trySelectCurrentEndControl(labelEl, dateElement) {
    try {
      var item = labelEl && labelEl.closest && labelEl.closest(".ant-form-item, .el-form-item, [class*='form-item']");
      var scopes = [item, item && item.parentElement, dateElement && dateElement.parentElement && dateElement.parentElement.parentElement]
        .filter(Boolean);
      var cursor = item || (dateElement && dateElement.parentElement);
      for (var depth = 0; cursor && depth < 6; depth++) {
        scopes.push(cursor);
        cursor = cursor.parentElement;
      }
      var seen = new Set();
      var candidates = [];
      scopes.forEach(function (scope) {
        Array.from(scope.querySelectorAll(
          "input[type='checkbox'], input[type='radio'], [role='checkbox'], [role='switch'], [role='radio'], button, label, .ant-checkbox-wrapper, .ant-radio-wrapper, .el-checkbox, .el-radio, .phoenix-checkbox, .phoenix-checkbox__realInput, .phoenix-checkbox__text"
        )).forEach(function (candidate) {
          if (!seen.has(candidate)) {
            seen.add(candidate);
            candidates.push(candidate);
          }
        });
      });

      var originRect = (dateElement || labelEl).getBoundingClientRect();
      var matches = candidates.map(function (candidate) {
        var wrapper = candidate.closest && candidate.closest("label, .ant-checkbox-wrapper, .ant-radio-wrapper, .el-checkbox, .el-radio, .phoenix-checkbox");
        var text = String((wrapper && wrapper.textContent) || candidate.textContent || candidate.getAttribute("aria-label") || candidate.getAttribute("title") || "")
          .replace(/[\s:：*]/g, "");
        var exact = /^(至今|目前|现在|仍在职|在职|仍在进行|当前)$/.test(text);
        var visibleTarget = wrapper || candidate;
        if (!exact || !AF.DomUtils.isElementVisible(visibleTarget)) return null;
        var rect = visibleTarget.getBoundingClientRect();
        var dx = rect.left - originRect.left;
        var dy = rect.top - originRect.top;
        return { element: visibleTarget, distance: Math.sqrt(dx * dx + dy * dy) };
      }).filter(Boolean).sort(function (a, b) { return a.distance - b.distance; });

      if (!matches.length || matches[0].distance > 500) return false;
      var target = matches[0].element;
      var input = target.matches && target.matches("input[type='checkbox'], input[type='radio']")
        ? target
        : target.querySelector && target.querySelector("input[type='checkbox'], input[type='radio']");
      if (input && input.checked) return true;
      await AF.DomUtils.safeClickElement(target);
      await AF.Utils.sleep(150);
      return input ? input.checked : true;
    } catch (e) {
      return false;
    }
  }

  async function resolveCurrentEndValue(fieldKey, value, labelEl, dateElement) {
    if (fieldKey !== "endTime" || !isCurrentEndValue(value)) {
      return { handled: false, value: value };
    }
    var selected = await trySelectCurrentEndControl(labelEl, dateElement);
    return selected
      ? { handled: true, value: value }
      : { handled: false, value: todayDateString() };
  }

  AF.CurrentEndDate = {
    isCurrentValue: isCurrentEndValue,
    today: todayDateString,
    resolve: resolveCurrentEndValue,
  };

  function parseProvinceCity(value) {
    var text = String(value || "").replace(/\s+/g, "");
    if (!text) return null;
    var municipalities = ["北京", "上海", "天津", "重庆"];
    for (var i = 0; i < municipalities.length; i++) {
      var municipality = municipalities[i];
      if (text.indexOf(municipality) === 0) {
        // Hotjob/Honor 的 `.cascader-plugins-wrap` 是两个并排下拉：
        // 第一个选省/直辖市，第二个选城市。直辖市场景第二个仍然应选
        // "上海市/北京市"，而不是把后面的"徐汇区"当作第二级。
        var municipalityName = municipality + "市";
        return { province: municipalityName, city: municipalityName };
      }
    }
    var provinceMatch = text.match(/^(.+?(?:省|自治区|特别行政区))/);
    if (!provinceMatch) return null;
    var province = provinceMatch[1];
    var cityText = text.slice(province.length);
    var cityMatch = cityText.match(/^(.+?(?:市|自治州|地区|盟))/);
    return { province: province, city: cityMatch ? cityMatch[1] : cityText };
  }

  function addressControlHint(control) {
    var input = control.querySelector && control.querySelector("input");
    return String([
      control.textContent,
      control.getAttribute("title"),
      control.getAttribute("aria-label"),
      input && input.getAttribute("placeholder"),
    ].filter(Boolean).join(" ")).replace(/\s+/g, "");
  }

  async function fillProvinceCityPair(labelEl, value) {
    try {
      var parsed = parseProvinceCity(value);
      if (!parsed || !parsed.province || !parsed.city) return false;
      var item = labelEl && labelEl.closest && labelEl.closest(".ant-form-item, .el-form-item, [class*='form-item']");
      var wrapper = item && item.querySelector(".cascader-plugins-wrap");
      if (!wrapper) return false;
      var controls = Array.from(wrapper.children || []).filter(function (el) {
        return el.matches && el.matches(".ant-select, .el-select");
      });
      if (controls.length < 2) controls = Array.from(wrapper.querySelectorAll(".ant-select, .el-select")).slice(0, 2);
      if (controls.length < 2) return false;

      var firstHint = addressControlHint(controls[0]);
      var secondHint = addressControlHint(controls[1]);
      var cityFirst = /(市|城市)/.test(firstHint) && /(省|省份)/.test(secondHint);
      var provinceControl = cityFirst ? controls[1] : controls[0];
      var cityControl = cityFirst ? controls[0] : controls[1];

      async function selectWithLocationVariants(control, raw) {
        var text = String(raw || "").trim();
        if (!text) return false;
        var variants = [text];
        var stripped = text
          .replace(/壮族自治区$/g, "")
          .replace(/回族自治区$/g, "")
          .replace(/维吾尔自治区$/g, "")
          .replace(/自治区$/g, "")
          .replace(/特别行政区$/g, "")
          .replace(/省$/g, "")
          .replace(/市$/g, "");
        if (stripped && variants.indexOf(stripped) === -1) variants.push(stripped);
        for (var i = 0; i < variants.length; i++) {
          // 省/市地址不能走通用相似度兜底：湖南/河南这类相近名称一旦
          // 没有精确命中，猜错比留空更危险。只允许 exactOrContains。
          if (await AF.SelectAdapter.create(
            control,
            "string",
            null,
            null,
            { matchMode: "exactOrContains", fallback: "leaveEmpty" }
          ).selectValue(variants[i])) return true;
          await AF.Utils.sleep(120);
        }
        return false;
      }

      var provinceOk = await selectWithLocationVariants(provinceControl, parsed.province);
      if (!provinceOk) {
        provinceControl = cityFirst ? controls[0] : controls[1];
        cityControl = cityFirst ? controls[1] : controls[0];
        provinceOk = await selectWithLocationVariants(provinceControl, parsed.province);
      }
      if (!provinceOk) return false;
      await AF.Utils.sleep(500);
      return !!(await selectWithLocationVariants(cityControl, parsed.city));
    } catch (e) {
      return false;
    }
  }

  AF.AddressAdapter = {
    parseProvinceCity: parseProvinceCity,
    fillProvinceCityPair: fillProvinceCityPair,
  };

  // ============ fillSingleExperienceGroup — 填一张卡(一"列"label) (源码行13741-13897) ============
  // resolveFn(labelText): 每个字段填写前重新定位当前卡内的对应 label，避免用到已失效的旧引用。
  FormHandler.prototype.fillSingleExperienceGroup = async function (labels, rowData, category, resolveFn, debugMeta) {
    resolveFn = resolveFn || null;
    try {
      if (category === "示例资料Experience" || category === "示例资料Experience") {
        var debugScope = debugMeta && debugMeta.scope || (labels && labels[0] && labels[0].closest && labels[0].closest(".send_box, .el-form-item, [class*='experience'], [class*='intern'], [class*='示例资料']"));
        var scopeInfo = visibleTencentTextareaSummary(debugScope);
        scopeInfo.category = category;
        scopeInfo.recordIndex = debugMeta && Number.isFinite(debugMeta.recordIndex) ? debugMeta.recordIndex : -1;
        updateTencentLongTextDebug("scope", scopeInfo);
      }
      var infos = Array.from(labels || []).map(function (l) {
        return { originalLabel: l, labelText: AF.LabelUtils.getLabelText(l) };
      });
      for (var i = 0; i < infos.length; i++) {
        var info = infos[i];
        var targetLabel = info.originalLabel;
        var labelText = info.labelText;
        // 源码行13798: 重新定位 label（DOM 可能因上一次填写而重渲染）
        if (resolveFn) {
          var resolved = resolveFn(labelText);
          // 已声明重定位器时，找不到就跳过，不能继续拿重渲染前的旧节点。
          targetLabel = resolved || null;
        }
        if (!targetLabel || !targetLabel.isConnected) {
          if (debugMeta && debugMeta.strictScope) this.failedFields.push({ fieldKey: "", label: labelText || "教育字段", reason: "field_not_found_in_record_scope" });
          continue;
        }
        if (!labelText) continue;
        this.currentLabelText = labelText;
        this.currentLabel = targetLabel;
        // 源码行13804: 空 label + 父节点文本含"起止时间/时间" → 当作"起止时间"
        if (labelText === "") {
          var parentText =
            targetLabel.parentElement && targetLabel.parentElement.textContent
              ? targetLabel.parentElement.textContent.trim()
              : "";
          if (parentText && (parentText.includes("起止时间") || parentText.includes("时间"))) {
            labelText = "起止时间";
            this.currentLabelText = labelText;
          }
        }
        if (!labelText) continue;
        var rangeValue = linkedTemporalValue(targetLabel, labelText, rowData, this.elementMatcher && this.elementMatcher.config);
        var fieldKey = rangeValue ? "duration" : this.dataMatcher.findFieldByCategory(category, labelText);
        if (!fieldKey && AF.AIConfigGenerator && typeof AF.AIConfigGenerator.resolveSemanticFieldMapping === "function") {
          fieldKey = AF.AIConfigGenerator.resolveSemanticFieldMapping(this.elementMatcher && this.elementMatcher.config, category, labelText);
        }
        if (!fieldKey && category === "示例资料" && /语言能力/.test(labelText)) {
          fieldKey = "__示例资料Summary";
        }
        if (!fieldKey && (labelText.includes("时间") || labelText.includes("日期") || labelText.includes("年月"))) {
          if (rowData.duration) {
            fieldKey = "duration";
          } else if (rowData.startTime && rowData.endTime) {
            fieldKey = labelText.includes("开始") ? "startTime" : "endTime";
          }
        }
        if (!fieldKey) continue;
        var value = (fieldKey === "__示例资料Summary" || fieldKey === "示例资料Ability") ? buildLanguageSummary(this.dataMatcher && this.dataMatcher.resumeData) : (rangeValue || rowData[fieldKey]);
        if (/^join\.qq\.com$/i.test(location.hostname || "") && category === "示例资料Experience" && fieldKey === "detailedContent") {
          value = tencentDescriptionValue(rowData);
        }
        if (category === "示例资料" && /^(ccbHighestEducation|isHighestEducation)$/.test(String(fieldKey || ""))) {
          if (value == null) value = rowData.isHighestEducation;
          if (value == null) value = rowData.ccbHighestEducation;
          if (value != null) value = yesNoFromValue(value);
        }
        if (value == null && fieldKey === "studyLength" && rowData.startTime && rowData.endTime) {
          value = deriveStudyDuration(rowData.startTime, rowData.endTime);
        }
        if (value == null && fieldKey === "duration" && rowData.startTime && rowData.endTime) {
          value = /学制/.test(labelText) ? deriveStudyDuration(rowData.startTime, rowData.endTime) : { startTime: rowData.startTime, endTime: rowData.endTime };
        }
      if (value == null) continue;
        value = normalizeLanguageScoreValue(category, fieldKey, value);
        if (category === "示例资料") value = normalizeSpecialEducationValue(labelText, fieldKey, value, rowData);
        var isLongText = isLongTextField(fieldKey);
        var found = isLongText && this.elementMatcher.findLongTextElement
          ? this.elementMatcher.findLongTextElement(targetLabel, fieldKey, debugMeta && debugMeta.scope)
          : this.elementMatcher.findElementAndTypeByLabel(targetLabel);
        var elType = found.type;
        var el = found.element;
        if (!el) {
          if (debugMeta && debugMeta.strictScope) this.failedFields.push({ fieldKey: fieldKey, label: labelText || "教育字段", reason: "field_not_found_in_record_scope" });
          if (isLongText) this.failedFields.push({ fieldKey: fieldKey, label: labelText || "描述", reason: "long text control not found" });
          continue;
        }
        if (category === "示例资料Experience" || category === "示例资料Experience") {
          updateTencentLongTextDebug("plan", {
            category: category,
            recordIndex: debugMeta && Number.isFinite(debugMeta.recordIndex) ? debugMeta.recordIndex : -1,
            fieldKey: String(fieldKey || ""),
            label: String(labelText || ""),
            controlType: String(elType || ""),
            hasValue: value != null
          });
        }
        try {
          // 籍贯在 示例资料Info 主循环中读取的是完整地址；示例资料则进入此多卡片
          // 循环，原本只会取 rowData.city（如“杭州市”）。北森 Phoenix 的
          // “院校所在城市”与籍贯同为地址级联，必须在这里也组装省→市路径。
          if (
            category === "示例资料" &&
            fieldKey === "city" &&
            /(就读院校|院校|学校|毕业院校)所在城市|院校城市/.test(labelText) &&
            el.closest && el.closest(".phoenix-select") &&
            AF.DomUtils && typeof AF.DomUtils.resolveEducationLocationPath === "function"
          ) {
            var experienceEducationLocationPath = AF.DomUtils.resolveEducationLocationPath(rowData);
            if (experienceEducationLocationPath.length >= 2) value = experienceEducationLocationPath;
          }
          if (await fillProvinceCityPair(targetLabel, value)) {
            this.filledFieldsCount++;
            await AF.Utils.sleep(this.operationDelay);
            continue;
          }
          if (fieldKey === "endTime" && isCurrentEndValue(value)) {
            var currentResult = await resolveCurrentEndValue(fieldKey, value, targetLabel, el);
            if (currentResult.handled) {
              this.filledFieldsCount++;
              await AF.Utils.sleep(this.operationDelay);
              continue;
            }
            value = currentResult.value;
          }
          // 类型二次修正 (源码行13838)。源码判断 "input"，rebuild 契约用 "text"。
          var resolvedType = isLongText ? "longText" : resolveFillType(el, elType, value);
          if (resolvedType === "search") value = buildEducationDialogChoiceValue(category, fieldKey, rowData, value);
          var capabilityContext = this.resolveCapabilityContext(category, fieldKey, labelText, el, resolvedType);
          if (isLongText) {
            capabilityContext = capabilityContext || {};
            capabilityContext.expectedControlType = "textarea";
            capabilityContext.longTextRecordScope = debugMeta && debugMeta.scope || null;
            capabilityContext.longTextSource = found.source || "";
          }
          if (fieldKey === "duration" && value && typeof value === "object") {
            value = resolveTemporalRangeValue(rowData, capabilityContext && capabilityContext.capability);
          }
          AF.FillTrace.setFieldContext({ category: category, label: labelText, fieldKey: fieldKey, plannedValue: value });
          var ok = await AF.FormHandler.fillFormElement(el, value, resolvedType, capabilityContext);

          // Moka 示例资料 search/select controls occasionally rerender after the
          // first school/major/level selection. Retry only these identity fields
          // inside the same owned 示例资料 card; never widen scope or use page
          // geometry. A failed identity field is surfaced explicitly instead of
          // marking the record complete because some dates happened to fill.
          var isMokaCriticalEducation = /(^|\.)mokahr\.com$/i.test(String(location.hostname || "")) &&
            category === "示例资料" && /^(school|major|level)$/.test(String(fieldKey || ""));
          if (!ok && isMokaCriticalEducation && resolveFn) {
            await AF.Utils.sleep(320);
            var retryLabel = resolveFn(labelText);
            if (retryLabel && retryLabel.isConnected) {
              var retryFound = this.elementMatcher.findElementAndTypeByLabel(retryLabel);
              if (retryFound && retryFound.element) {
                var retryType = resolveFillType(retryFound.element, retryFound.type, value);
                var retryContext = this.resolveCapabilityContext(category, fieldKey, labelText, retryFound.element, retryType);
                if (retryType === "search") value = buildEducationDialogChoiceValue(category, fieldKey, rowData, value);
                AF.FillTrace.setFieldContext({ category: category, label: labelText, fieldKey: fieldKey, plannedValue: value });
                ok = await AF.FormHandler.fillFormElement(retryFound.element, value, retryType, retryContext);
              }
            }
          }

          // Moka's React select can report a successful click while the controlled
          // value is discarded during the following rerender.  Successful return
          // values are therefore not enough for school/major/level ownership.
          // Re-resolve the same card, read the visible committed value, retry once
          // inside that card, and only then allow the 示例资料 record to commit.
          if (ok && isMokaCriticalEducation && resolveFn) {
            var expectedMokaIdentity = value && typeof value === "object" && value.name != null ? String(value.name) : String(value == null ? "" : value);
            var normalizeMokaIdentity = function (input) {
              return String(input == null ? "" : input).replace(/\s+/g, "").replace(/[：:]/g, "").toLowerCase();
            };
            var mokaIdentityMatches = function (actual, expected) {
              var a = normalizeMokaIdentity(actual);
              var e = normalizeMokaIdentity(expected);
              return !!a && !!e && (a === e || a.indexOf(e) !== -1 || e.indexOf(a) !== -1);
            };
            var readFreshMokaIdentity = function (freshFound) {
              try {
                return freshFound && freshFound.element && AF.FillTrace && AF.FillTrace.readElementValue
                  ? AF.FillTrace.readElementValue(freshFound.element) : "";
              } catch (_) { return ""; }
            };
            await AF.Utils.sleep(260);
            var verifyLabel = resolveFn(labelText);
            var verifyFound = verifyLabel && verifyLabel.isConnected ? this.elementMatcher.findElementAndTypeByLabel(verifyLabel) : null;
            var retainedValue = readFreshMokaIdentity(verifyFound);
            if (!mokaIdentityMatches(retainedValue, expectedMokaIdentity) && verifyFound && verifyFound.element) {
              var verifyType = resolveFillType(verifyFound.element, verifyFound.type, value);
              var verifyContext = this.resolveCapabilityContext(category, fieldKey, labelText, verifyFound.element, verifyType);
              var verifyValue = value;
              if (verifyType === "search" && !(verifyValue && typeof verifyValue === "object" && verifyValue.name != null)) {
                verifyValue = buildEducationDialogChoiceValue(category, fieldKey, rowData, verifyValue);
              }
              AF.FillTrace.setFieldContext({ category: category, label: labelText, fieldKey: fieldKey, plannedValue: verifyValue });
              await AF.FormHandler.fillFormElement(verifyFound.element, verifyValue, verifyType, verifyContext);
              await AF.Utils.sleep(320);
              verifyLabel = resolveFn(labelText);
              verifyFound = verifyLabel && verifyLabel.isConnected ? this.elementMatcher.findElementAndTypeByLabel(verifyLabel) : null;
              retainedValue = readFreshMokaIdentity(verifyFound);
            }
            if (!mokaIdentityMatches(retainedValue, expectedMokaIdentity)) {
              ok = false;
              if (AF.FillTrace) AF.FillTrace.event("moka_identity_verify", String(labelText || fieldKey) + " expected=" + expectedMokaIdentity + " actual=" + String(retainedValue || ""), "failed");
            }
          }
          if ((category === "示例资料Experience" || category === "示例资料Experience") && isLongText) {
            var traceDetail = capabilityContext && capabilityContext.longTextTrace || {};
            updateTencentLongTextDebug("writer", {
              key: category + "." + (debugMeta && Number.isFinite(debugMeta.recordIndex) ? debugMeta.recordIndex : -1) + "." + fieldKey,
              value: Object.assign({ category: category, recordIndex: debugMeta && Number.isFinite(debugMeta.recordIndex) ? debugMeta.recordIndex : -1, fieldKey: String(fieldKey), label: String(labelText || ""), expectedControlType: "textarea", enteredWriter: true, committed: !!ok }, traceDetail)
            });
          }
          if (ok) this.filledFieldsCount++;
          else if (isMokaCriticalEducation) this.failedFields.push({ fieldKey: fieldKey, label: labelText || fieldKey, reason: "moka_示例资料_identity_fill_failed" });
          else if (isLongText) this.failedFields.push({ fieldKey: fieldKey, label: labelText || "描述", reason: capabilityContext && capabilityContext.longTextTrace && capabilityContext.longTextTrace.reason || "long text fill failed" });
        } catch (e) {}
        await AF.Utils.sleep(this.operationDelay);
      }
      this.currentLabelText = null;
      this.currentLabel = null;
      return true;
    } catch (e) {
      this.currentLabelText = null;
      this.currentLabel = null;
      return false;
    }
  };

  FormHandler.prototype.fillEducationSequentially = async function (container, sectionEl, title, data) {
    var 示例资料 = this;
    var beforeCards = detectEducationRecordCards(container, this.elementMatcher);
    var trace = { profileRecordCount: data.length, pageRecordCountBefore: beforeCards.length, pageRecordCountAfter: beforeCards.length, duplicateScopeDetected: false, records: [] };
    var usedPageIndexes = new Set();
    var filledRows = 0;
    for (var index = 0; index < data.length; index++) {
      var cards = detectEducationRecordCards(container, this.elementMatcher);
      if (index > 0 && cards.length <= usedPageIndexes.size) {
        for (var waitIndex = 0; waitIndex < 6 && cards.length <= usedPageIndexes.size; waitIndex++) {
          await AF.Utils.sleep(150);
          cards = detectEducationRecordCards(container, this.elementMatcher);
        }
      }
      if (cards.length <= usedPageIndexes.size) {
        var buttons = await this.elementMatcher.findAddButton(container, sectionEl, title);
        if (!(buttons && buttons.length)) buttons = await this.elementMatcher.findAddButtonByAlternativeMethods(container, title);
        var addButton = AF.DomUtils.findVisibleButton(buttons);
        if (addButton) {
          var oldCount = cards.length;
          await AF.DomUtils.safeClickElement(addButton);
          for (var addWait = 0; addWait < 6; addWait++) { await AF.Utils.sleep(150); cards = detectEducationRecordCards(container, this.elementMatcher); if (cards.length > oldCount) break; }
        }
      }
      var available = cards.map(function (card, pageIndex) { return { card: card, pageIndex: pageIndex, blank: 示例资料CardIsBlank(card) }; })
        .filter(function (item) { return !usedPageIndexes.has(item.pageIndex); });
      available.sort(function (a, b) { return Number(b.blank) - Number(a.blank) || a.pageIndex - b.pageIndex; });
      var allocation = available[0];
      var recordTrace = { profileIndex: index, cardsVisibleBefore: cards.length, pageIndex: allocation ? allocation.pageIndex : -1, scopeIdentity: allocation ? "示例资料-card-" + allocation.pageIndex : "", scopeResolved: !!allocation, scopeWasBlank: !!(allocation && allocation.blank), scopeReused: !!(allocation && usedPageIndexes.has(allocation.pageIndex)), committed: false, cardsVisibleAfter: cards.length };
      trace.records.push(recordTrace);
      if (!allocation) { this.failedFields.push({ fieldKey: "示例资料Record", label: title || "示例资料", reason: "示例资料_record_capacity_shortage" }); writeEducationRepeatTrace(trace); break; }
      if (usedPageIndexes.has(allocation.pageIndex)) { trace.duplicateScopeDetected = true; this.failedFields.push({ fieldKey: "示例资料Record", label: title || "示例资料", reason: "duplicate_示例资料_scope" }); writeEducationRepeatTrace(trace); break; }
      usedPageIndexes.add(allocation.pageIndex);
      var recordCheckpointMeta = buildFormRecordCheckpointMeta("示例资料", title, index, data.length, data[index]);
      if (this.recordCheckpointRuntime && this.recordCheckpointRuntime.enabled &&
          typeof this.recordCheckpointRuntime.shouldSkip === "function" &&
          this.recordCheckpointRuntime.shouldSkip(recordCheckpointMeta)) {
        recordTrace.skippedByCheckpoint = true;
        recordTrace.committed = true;
        recordTrace.cardsVisibleAfter = cards.length;
        filledRows++;
        writeEducationRepeatTrace(trace);
        continue;
      }
      var scope = allocation.card;
      var scopeLabels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(scope));
      var beforeFilled = this.filledFieldsCount;
      var beforeFailureCount = this.failedFields.length;
      await this.fillSingleExperienceGroup(scopeLabels, data[index], "示例资料", function (labelText) {
        if (!scope.isConnected) {
          var refreshed = detectEducationRecordCards(container, 示例资料.elementMatcher);
          scope = refreshed[allocation.pageIndex] || null;
        }
        if (!scope) return null;
        return 示例资料.filterValidLabels(示例资料.elementMatcher.findLabelsByCard(scope)).find(function (label) { return AF.LabelUtils.getLabelText(label).toLowerCase() === String(labelText || "").toLowerCase(); }) || null;
      }, { recordIndex: index, scope: scope, strictScope: true });
      await AF.Utils.sleep(350);
      var afterCards = detectEducationRecordCards(container, this.elementMatcher);
      recordTrace.cardsVisibleAfter = afterCards.length;
      var inlineEducationPersistence = Boolean(
        this.experienceHandler && this.experienceHandler.configAdapter &&
        typeof this.experienceHandler.configAdapter.usesInlinePersistence === "function" &&
        this.experienceHandler.configAdapter.usesInlinePersistence()
      );
      // Moka 等行内持久化平台的 SD Select/Date 控件值未必反映到原生 input.value，
      // 示例资料CardIsBlank() 会把已经成功填写的卡片误判为空。只要本轮确实提交了
      // 字段且卡片仍存在，就把该 record 记入 RECORD ledger，供后续断点恢复跳过。
      var rowFailures = this.failedFields.slice(beforeFailureCount);
      var hasCriticalEducationFailure = rowFailures.some(function (failure) {
        return /moka_示例资料_identity_fill_failed/.test(String(failure && failure.reason || ""));
      });
      recordTrace.criticalFailure = hasCriticalEducationFailure;
      recordTrace.committed = this.filledFieldsCount > beforeFilled && !hasCriticalEducationFailure && !!afterCards[allocation.pageIndex] &&
        (inlineEducationPersistence || !示例资料CardIsBlank(afterCards[allocation.pageIndex]));
      if (recordTrace.committed) {
        filledRows++;
        var pendingEducationSave = await findPendingManualExperienceSaveButton(this, afterCards[allocation.pageIndex] || scope, container);
        if (pendingEducationSave && this.recordCheckpointRuntime && typeof this.recordCheckpointRuntime.pause === "function") {
          recordTrace.manualSavePending = true;
          await this.recordCheckpointRuntime.pause(recordCheckpointMeta, "当前教育记录已填写，仍需手动保存");
          trace.pageRecordCountAfter = afterCards.length;
          writeEducationRepeatTrace(trace);
          break;
        }
        if (this.recordCheckpointRuntime && typeof this.recordCheckpointRuntime.markCompleted === "function") {
          await this.recordCheckpointRuntime.markCompleted(recordCheckpointMeta);
        }
      }
      trace.pageRecordCountAfter = afterCards.length;
      writeEducationRepeatTrace(trace);
    }
    var finalCards = detectEducationRecordCards(container, this.elementMatcher);
    trace.pageRecordCountAfter = finalCards.length;
    if (data.length > 1 && trace.records.filter(function (record) { return record.committed; }).length < data.length) {
      this.failedFields.push({ fieldKey: "示例资料Record", label: title || "示例资料", reason: "record_count_mismatch" });
    }
    writeEducationRepeatTrace(trace);
    this.lastExperienceResult = { requestedRows: data.length, filledRows: filledRows, mode: "示例资料_sequential", 示例资料RecordTrace: trace };
    return filledRows === data.length;
  };

  // ============ fillExperienceLegacy — 旧版经历填写 (源码行13320-13717, 逐行复现) ============
  // 关键: 先把卡片"加够"(必要时点添加按钮/"有无经历"开关并等待渲染), 每加一张都重新扫描 label
  //       确认卡片确实增加了, 最后按 label 文本分组、第 index 条数据填进第 index 组的第 index 个元素,
  //       且每个字段填写前用 resolveExperienceGroupLabel 重新定位, 保证"一次填充就把值填进去"。
  FormHandler.prototype.fillExperienceLegacy = async function (sectionEl, title, options) {
    options = options || {};
    try {
      // 1. 定位容器 + 展开折叠表单 (源码行13362-13365)
      var container = this.elementMatcher.findContainerByTitle(sectionEl);
      container = await handleFormExpansion(this.elementMatcher, container, sectionEl);

      // 2. 取分类数据 (源码行13369-13390)
      var categoryInfo;
      if (Array.isArray(options.dataOverride)) {
        categoryInfo = {
          category: options.categoryOverride || options.specificCategory,
          type: "array",
          data: options.dataOverride.slice(),
        };
      } else if (options.specificCategory) {
        var raw = this.dataMatcher.resumeData[options.specificCategory];
        if (!raw) return false;
        var rt = Array.isArray(raw) ? "array" : "object";
        categoryInfo = { category: options.specificCategory, type: rt, data: rt === "array" ? raw.slice() : Object.assign({}, raw) };
      } else {
        categoryInfo = this.dataMatcher.getCategoryByTitle(title, options);
        if (!categoryInfo) return false;
      }
      var data = categoryInfo.data;
      var category = categoryInfo.category;
      var need = data.length;
      if (need === 0) return true; // 源码行13398: 无数据视为成功
      var filledRows = 0;
      var filledIndexes = [];

      if (category === "示例资料") {
        return await this.fillEducationSequentially(container, sectionEl, title, data);
      }

      // 3. 数已有卡片数 b (源码行13404-13426): 同名 label 出现次数, 有重复取最大重复数, 否则有label则记1
      var labels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(container));
      var grouped = groupLabelsByText(labels);
      var dupKeys = Object.keys(grouped).filter(function (k) { return grouped[k].length > 1; });
      var existing = 0;
      if (dupKeys.length > 0) {
        existing = Math.max.apply(Math, dupKeys.map(function (k) { return grouped[k].length; }));
      } else if (labels.length > 0) {
        existing = 1;
      }
      var toAdd = Math.max(0, need - existing); // 源码行13427: g = max(0, need - existing)

      var 示例资料 = this;
      // 复用的"找并点添加按钮"关键词兜底: 源码找不到时会试"有无经历"开关
      // 4. 源码行13428: 仅当"当前一张卡都没有(existing===0)且确实需要填(need>0)"时, 先点亮第一张卡
      if (existing === 0 && need > 0) {
        var w = await this.elementMatcher.findAddButton(container, sectionEl, title); // 精确
        if (!(w && w.length)) {
          w = await this.elementMatcher.findAddButtonByAlternativeMethods(container, title); // 备用
        }
        if (w && w.length) {
          var vis = AF.DomUtils.findVisibleButton(w);
          if (!vis) {
            // 有按钮但都不可见 → 试"有无经历"开关 (源码行86-104)
            var tgl = AF.DomUtils.findExperienceToggle(container);
            if (!tgl) return false;
            if (tgl.type === "radio") await AF.DomUtils.safeClickElement(tgl.element);
            else if (tgl.type === "checkbox" && tgl.element.checked) await AF.DomUtils.safeClickElement(tgl.element);
            await AF.Utils.sleep(700);
            labels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(container));
            if (labels.length > 0) { toAdd -= 1; existing = 1; }
            else return false;
          } else {
            // 点可见按钮打开第一张卡 (源码行121-140)
            await vis.click();
            await AF.Utils.sleep(500);
            labels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(container));
            if (labels.length === 0) {
              // 没出现 label → 换备用方法再点一次
              w = await this.elementMatcher.findAddButtonByAlternativeMethods(container, title);
              var altVis = AF.DomUtils.findVisibleButton(w);
              if (altVis) {
                await AF.DomUtils.safeClickElement(altVis);
                await AF.Utils.sleep(700);
                labels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(container));
              }
            }
            toAdd -= 1;
          }
        } else {
          // 完全没找到添加按钮 → 试"有无经历"开关 (源码行50-84)
          var tgl2 = AF.DomUtils.findExperienceToggle(container);
          if (!tgl2) return false;
          if (tgl2.type === "radio") await AF.DomUtils.safeClickElement(tgl2.element);
          else if (tgl2.type === "checkbox" && tgl2.element.checked) await AF.DomUtils.safeClickElement(tgl2.element);
          await AF.Utils.sleep(700);
          labels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(container));
          if (labels.length > 0) { toAdd -= 1; existing = 1; }
          else return false;
        }
      }

      // 5. 循环补齐剩余 toAdd 张卡片 (源码行141-187): 每点一次都重新扫描确认 label 数增加了
      var L = 0;
      while (L < toAdd) {
        if (this.shouldStop && this.shouldStop()) break;
        var O = await this.elementMatcher.findAddButton(container, sectionEl, title);
        if (!(O && O.length)) {
          O = await this.elementMatcher.findAddButtonByAlternativeMethods(container, title);
        }
        if (!(O && O.length)) break;
        var vb = AF.DomUtils.findVisibleButton(O);
        if (!vb) break;
        vb.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
        await AF.Utils.sleep(500);
        var newLabels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(container));
        if (newLabels && newLabels.length > labels.length) {
          labels = newLabels;
        } else {
          // label 没增加 → 换备用方法再点一次
          var P = await this.elementMatcher.findAddButtonByAlternativeMethods(container, title);
          var altVb = AF.DomUtils.findVisibleButton(P);
          if (altVb) {
            await AF.DomUtils.safeClickElement(altVb);
            await AF.Utils.sleep(700);
            var newLabels2 = this.filterValidLabels(this.elementMatcher.findLabelsByCard(container));
            if (newLabels2.length > labels.length) labels = newLabels2;
          }
        }
        L++;
      }

      // 6. 分组填写 (源码行188-201): 第 index 条数据 → 每组 label 的第 index 个元素
      var finalLabels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(container));
      var groups = groupLabelsByText(finalLabels);
      var groupKeys = Object.keys(groups);
      var groupLengths = groupKeys.map(function (key) { return groups[key].length; });
      var hasUnevenGroups = groupLengths.some(function (length) { return length !== groupLengths[0]; });
      var allocatedScopes = new Set();
      for (var idx = 0; idx < need; idx++) {
        if (this.shouldStop && this.shouldStop()) break;
        if (this.onFieldProgress) this.onFieldProgress(idx + 1, need);
        var row = [];
        for (var gi = 0; gi < groupKeys.length; gi++) {
          if (this.shouldStop && this.shouldStop()) break;
          var arr = groups[groupKeys[gi]];
          if (idx < arr.length) row.push(arr[idx]);
        }
        if (row.length === 0) continue; // 源码行: row 空则跳过该条
        var rowScope = inferLegacyExperienceRowScope(container, row, finalLabels);
        // A 示例资料ed record may never reuse an示例资料 record's DOM scope.  The
        // old global fallback was the direct cause of later rows overwriting
        // the first 示例资料 card after a frame示例资料 rerender.
        if (category === "示例资料" && rowScope && allocatedScopes.has(rowScope)) {
          this.failedFields.push({ fieldKey: "示例资料Record", label: title || category, reason: "duplicate_示例资料_scope" });
          this.lastExperienceResult = { requestedRows: need, filledRows: filledRows, mode: "legacy", error: "duplicate_示例资料_scope" };
          return false;
        }
        // 多条经历的字段组数量不一致时，“第 N 个同名字段”不再能证明属于
        // 第 N 张卡。无法推断独立卡片边界就跳过，避免本科时间写进硕士。
        if (need > 1 && hasUnevenGroups && !rowScope) continue;
        if (category === "示例资料" && rowScope) allocatedScopes.add(rowScope);
        var rowScopeToken = rowScope ? ("af-legacy-row-" + Date.now() + "-" + idx + "-" + Math.random().toString(36).slice(2)) : "";
        if (rowScopeToken) {
          try { rowScope.setAttribute("data-af-legacy-experience-row", rowScopeToken); } catch (e) {}
        }
        var rowCategory = data[idx] && data[idx].__afCategory || category;
        var filledBeforeRow = this.filledFieldsCount;
        await this.fillSingleExperienceGroup(
          row,
          data[idx],
          rowCategory,
          (function (index, boundScope, boundToken) {
            return function (labelText) {
              if (boundScope) {
                var latestScope = boundScope.isConnected
                  ? boundScope
                  : container.querySelector("[data-af-legacy-experience-row='" + boundToken + "']");
                if (!latestScope) return null;
                var scopedLabels = 示例资料.filterValidLabels(示例资料.elementMatcher.findLabelsByCard(latestScope));
                var scopedTarget = String(labelText || "").toLowerCase();
                return scopedLabels.find(function (label) {
                  return AF.LabelUtils.getLabelText(label).toLowerCase() === scopedTarget;
                }) || null;
              }
              return 示例资料.resolveExperienceGroupLabel(container, labelText, index);
            };
          })(idx, rowScope, rowScopeToken),
          { recordIndex: idx, scope: rowScope }
        );
        // 网页可能展示注册阶段锁定的历史记录。只有当前记录至少有一个
        // 字段真正填写成功/确认正确，才算消耗了一条简历数组数据；仅仅
        // 找到一组只读标签不能算“已填一条”。
        if (this.filledFieldsCount > filledBeforeRow) {
          filledRows++;
          filledIndexes.push(idx);
        }
      }
      this.lastExperienceResult = {
        requestedRows: need,
        filledRows: filledRows,
        filledIndexes: filledIndexes,
        mode: "legacy",
        visibleRows: Math.max(existing, filledRows)
      };
      return filledRows >= need;
    } catch (err) {
      this.lastExperienceResult = { requestedRows: 0, filledRows: 0, mode: "legacy", error: String(err) };
      console.warn("[AF.FormHandler] fillExperienceLegacy 出错:", err);
      return false;
    }
  };

  AF.FormHandler = FormHandler;

  // ============================================================================
  // fillFormElement 及 8 种类型 handler (源码行56136-56200 分发 + 各 handler 类)
  // ============================================================================

  async function tryElectronTrustedText(element, value) {
    if (
      !window.__OFFER_ELECTRON_AUTOFILL__ || !element ||
      !(element.closest && element.closest('[class*="phoenix" i]')) ||
      !window.chrome || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function"
    ) return null;
    var marker = "af-trusted-text-" + Date.now() + "-" + Math.random().toString(36).slice(2);
    try { element.setAttribute("data-af-trusted-text-id", marker); } catch (e) { return null; }
    return await new Promise(function (resolve) {
      var settled = false;
      var timer = setTimeout(function () { finish(null); }, 5200);
      function finish(result) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        try { element.removeAttribute("data-af-trusted-text-id"); } catch (e) {}
        resolve(result === true ? true : null);
      }
      try {
        chrome.runtime.sendMessage({
          action: "trustedTextInput",
          marker: marker,
          value: String(value == null ? "" : value)
        }, function (response) {
          if (response && response.success) {
            finish(true);
            return;
          }
          if (AF.FillTrace) AF.FillTrace.event(
            "trusted_text_input",
            String(response && response.error || "可信输入桥未返回成功"),
            "failed"
          );
          finish(null);
        });
      } catch (e) {
        if (AF.FillTrace) AF.FillTrace.event("trusted_text_input", String(e && e.message || e), "failed");
        finish(null);
      }
    });
  }

  async function tryControlledTextMainBridge(element, value) {
    if (
      !element || !document.documentElement ||
      !document.documentElement.hasAttribute("data-af-controlled-text-main-bridge") ||
      !(element.closest && element.closest('[class*="phoenix" i]'))
    ) return null;
    var token = "af-text-" + Date.now() + "-" + Math.random().toString(36).slice(2);
    try { element.setAttribute("data-af-controlled-text-token", token); } catch (e) { return null; }
    return await new Promise(function (resolve) {
      var done = false;
      var timer = null;
      function finish(result) {
        if (done) return;
        done = true;
        if (timer) clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        try { element.removeAttribute("data-af-controlled-text-token"); } catch (e) {}
        resolve(result);
      }
      function onMessage(event) {
        var data = event && event.data;
        if (
          event.source !== window || !data ||
          data.type !== "AF_CONTROLLED_TEXT_RESPONSE_V2" || data.token !== token
        ) return;
        finish(data.success === true);
      }
      window.addEventListener("message", onMessage);
      timer = setTimeout(function () { finish(false); }, 1500);
      window.postMessage({
        type: "AF_CONTROLLED_TEXT_REQUEST_V2",
        token: token,
        value: String(value == null ? "" : value)
      }, "*");
    });
  }

  // ---------- handleText (源码行53111-53194，行53144-53165 是全插件最关键代码) ----------
  function appendTagText(existingValue, incomingValue) {
    var existing = String(existingValue == null ? "" : existingValue);
    var incoming = String(incomingValue == null ? "" : incomingValue);
    if (!existing) return incoming;
    return /\s$/.test(existing) ? existing + incoming : existing + "\n" + incoming;
  }

  async function handleLongText(element, value, capabilityContext) {
    var trace = {
      expectedControlType: "textarea",
      resolvedTag: String(element && element.tagName || "").toUpperCase(),
      resolvedInputType: String(element && element.getAttribute && element.getAttribute("type") || "").toLowerCase(),
      placeholderMatched: !!(element && /描述|描述内容|工作内容|项目内容/.test(String(element.getAttribute && (element.getAttribute("placeholder") || element.getAttribute("aria-label")) || ""))),
      executionPath: capabilityContext && capabilityContext.longTextSource || "longtext_writer",
      committed: false,
      reason: ""
    };
    var finish = function (success, reason) {
      trace.committed = !!success;
      trace.reason = reason || "";
      if (capabilityContext) capabilityContext.longTextTrace = trace;
      return !!success;
    };
    if (!isLongTextControl(element)) return finish(false, "control_type_mismatch");
    try {
      var target = String(value == null ? "" : value);
      if (String(element.tagName || "").toUpperCase() === "TEXTAREA") {
        var descriptor = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value");
        if (descriptor && descriptor.set) descriptor.set.call(element, target);
        else element.value = target;
      } else {
        element.textContent = target;
      }
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
      if (typeof element.blur === "function") element.blur();
      await AF.Utils.sleep(320);
      var scope = capabilityContext && capabilityContext.longTextRecordScope;
      var readback = element;
      if (scope && scope.isConnected) {
        var candidates = Array.from(scope.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]')).filter(isLongTextControl);
        if (candidates.length === 1) readback = candidates[0];
        else if (!readback.isConnected) return finish(false, "readback_control_not_found");
      }
      var actual = String(readback && (String(readback.tagName || "").toUpperCase() === "TEXTAREA" ? readback.value : readback.textContent) || "");
      return normalizeLongText(actual) === normalizeLongText(target)
        ? finish(true, "")
        : finish(false, "commit_readback_mismatch");
    } catch (e) {
      return finish(false, "longtext_writer_error");
    }
  }


  // Build157 Input Strategy Normalizer
  // 将文本输入策略收敛到统一决策入口，避免后续站点能力参数继续散落。
  function resolveInputStrategy(element, capabilityContext) {
    var capability = capabilityContext && capabilityContext.capability || {};
    var tagName = String(element && element.tagName || "").toLowerCase();
    var mode = String(capability.inputMode || "").trim();

    if (mode !== "keyboardEvents" && mode !== "nativeSetter") {
      mode = "frame示例资料Aware";
    }

    return {
      mode: mode,
      typingDelayMs: Math.max(0, Number(capability.typingDelayMs || 25)),
      verifyAfterFill: capability.verifyAfterFill !== false,
      isTextArea: tagName === "textarea",
      reactLike: !!(capability.reactControlled || capability.vueControlled || capability.frame示例资料Controlled)
    };
  }

  async function handleText(element, value, capabilityContext) {
    if (!element || value === undefined) return false;
    if (
      element.disabled || element.readOnly ||
      (element.hasAttribute && (element.hasAttribute("disabled") || element.hasAttribute("readonly")))
    ) {
      // readonly/disabled 只表示普通文本无法直接写入，不能等同于填写成功。
      // 已有值与目标相符时保留成功；空值或不同值必须失败，让 date/search/
      // select 的正确路由或失败日志接管。
      return String(element.value == null ? "" : element.value).trim() === String(value == null ? "" : value).trim();
    }
    // 注: 源码行53131-53138 还有一个"专业/学科"标签 + 智联招聘站点专属分支，
    // 会改路由到 handleSelect。该分支依赖 currentLabelText 全局状态和站点检测工具
    // isZhaopinRelatedSite，属于单一站点的特殊适配，本文件不处理这一冷门分支。
    try {
      var capability = capabilityContext && capabilityContext.capability || null;
      var str = String(value);
      var tagName = String(element.tagName || "").toLowerCase();
      var shouldAppend = !!(capabilityContext && capabilityContext.appendText && tagName === "textarea");
      var previousValue = String(element.value || "");
      var nextValue = shouldAppend ? appendTagText(previousValue, str) : str;
      var insertedText = shouldAppend ? nextValue.slice(previousValue.length) : str;
      var trusted = await tryElectronTrustedText(element, nextValue);
      if (trusted === true) return true;
      var prototype = tagName === "textarea" ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
      var descriptor = Object.getOwnPropertyDescriptor(prototype, "value");
      var setNativeValue = function (nextValue) {
        if (descriptor && descriptor.set) descriptor.set.call(element, nextValue);
        else element.value = nextValue;
      };
      var waitForFrame示例资料 = function (delay) {
        return new Promise(function (resolve) { setTimeout(resolve, delay); });
      };

      // Vue/Element 的受控 input 不能只留下 value attribute。那会造成页面看起来
      // 曾经填上，但组件下一次重渲染又从空的 model 把 property 清掉。优先走浏览器
      // 的真实编辑命令，让框架收到和用户键入一致的 beforeinput/input 变更链。
      try { element.focus(); } catch (e0) {}
      try {
        if (shouldAppend && typeof element.setSelectionRange === "function") {
          element.setSelectionRange(previousValue.length, previousValue.length);
        } else if (typeof element.select === "function") {
          element.select();
        } else if (typeof element.setSelectionRange === "function") {
          element.setSelectionRange(0, previousValue.length);
        }
      } catch (e1) {}

      var insertedByCommand = false;
      var inputStrategy = resolveInputStrategy(element, capabilityContext);
      var inputMode = inputStrategy.mode === "frame示例资料Aware" ? "" : inputStrategy.mode;
      if (inputMode === "keyboardEvents") {
        if (!shouldAppend) {
          setNativeValue("");
          element.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: null, inputType: "deleteContentBackward" }));
        }
        var current = shouldAppend ? previousValue : "";
        var typingDelayMs = inputStrategy.typingDelayMs;
        for (var charIndex = 0; charIndex < insertedText.length; charIndex++) {
          var character = insertedText.charAt(charIndex);
          current += character;
          element.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, composed: true, key: character }));
          setNativeValue(current);
          element.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: character, inputType: "insertText" }));
          element.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, composed: true, key: character }));
          if (typingDelayMs) await waitForFrame示例资料(typingDelayMs);
        }
        insertedByCommand = true;
      } else if (inputMode !== "nativeSetter") {
        try {
          insertedByCommand = !!(document.execCommand && document.execCommand("insertText", false, insertedText));
        } catch (e2) {}
      }
      await waitForFrame示例资料(30);

      // 不支持 execCommand 的页面再使用原生 setter，并补齐 beforeinput/input。
      if (!insertedByCommand || String(element.value || "") !== nextValue) {
        if (!shouldAppend) {
          setNativeValue("");
          element.dispatchEvent(
            new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: null, inputType: "deleteContentBackward" })
          );
          await waitForFrame示例资料(16);
        }
        element.dispatchEvent(
          new InputEvent("beforeinput", { bubbles: true, cancelable: true, composed: true, data: insertedText, inputType: "insertText" })
        );
        setNativeValue(nextValue);
        element.dispatchEvent(
          new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: insertedText, inputType: "insertText" })
        );
      }

      element.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      if (!capability || capability.blurAfterFill !== false) {
        try { element.blur(); } catch (e3) {
          element.dispatchEvent(new FocusEvent("blur", { bubbles: false, composed: true }));
        }
      }
      // 必须等一次组件更新后再判断，不能以刚写入 property 的瞬时值作为成功。
      await waitForFrame示例资料(120);
      return capability && capability.verifyAfterFill === false ? true : String(element.value || "") === nextValue;
    } catch (err) {
      console.warn("[AF.FormHandler] handleText 失败:", err);
      return false;
    }
  }

  // 找到 element 所属的整个 radio 选项组 (源码里 handleRadio 的入参本身就是一个
  // radio 集合；本重建版契约里 findElementAndTypeByLabel 只返回单个代表元素，
  // 所以这里补一步：从单个元素出发，还原出整个同组 radio 列表)
  function normalizeRadioTarget(el) {
    if (!el || !(el instanceof Element)) return el;
    return (
      (el.closest && el.closest(".ant-radio-wrapper, .el-radio, .phoenix-radio, label")) ||
      (el.matches && el.matches('[role="radio"]') ? el : null) ||
      el
    );
  }

  function collectRadioGroup(element) {
    try {
      if (typeof element.length === "number" && element.length > 0 && element[0] && element[0].nodeType) {
        var normalized = Array.from(element)
          .map(normalizeRadioTarget)
          .filter(Boolean);
        return Array.from(new Set(normalized));
      }
      if (element.type === "radio" && element.name) {
        return Array.from(document.getElementsByName(element.name)).filter(function (el) {
          return el.type === "radio";
        }).map(normalizeRadioTarget);
      }
      var group =
        element.closest && element.closest('.el-radio-group, .ant-radio-group, .phoenix-radio-group, .radio_selector, [role="radiogroup"]');
      if (group) {
        var wrappers = Array.from(group.querySelectorAll(".ant-radio-wrapper, .el-radio, .phoenix-radio, .label_radio, [role='radio']"));
        if (wrappers.length) return Array.from(new Set(wrappers.map(normalizeRadioTarget)));
        return Array.from(group.querySelectorAll('input[type="radio"]')).map(normalizeRadioTarget);
      }
      if (element.parentElement) {
        var siblings = Array.from(
          element.parentElement.querySelectorAll('input[type="radio"], [role="radio"], .el-radio, .ant-radio-wrapper, .phoenix-radio, .label_radio')
        ).map(normalizeRadioTarget);
        if (siblings.length) return siblings;
      }
      return [normalizeRadioTarget(element)];
    } catch (e) {
      return [normalizeRadioTarget(element)];
    }
  }

  // ---------- 相似度评分函数 (源码 xi(), 行53801-53814, 逐行照搬) ----------
  // Jaccard 字符集合相似度: 两串转小写后完全相等直接返回 1；否则把各自拆成"字符集合"，
  // 用 交集大小 / 并集大小 作为相似度分数 (0~1之间)。源码本身不做 trim，
  // trim 由调用方(handleRadio 对 textContent 的 trim)负责，这里保持一致。
  function textSimilarityScore(a, b) {
    if (!a || !b) return 0;
    var ta = String(a).toLowerCase();
    var tb = String(b).toLowerCase();
    if (ta === tb) return 1;
    var setA = new Set(ta.split(""));
    var setB = new Set(tb.split(""));
    var intersectionSize = 0;
    setA.forEach(function (ch) {
      if (setB.has(ch)) intersectionSize++;
    });
    var unionSize = new Set(ta.split("").concat(tb.split(""))).size;
    return unionSize === 0 ? 0 : intersectionSize / unionSize;
  }

  function getRadioInput(el) {
    if (!el) return null;
    if (el.matches && el.matches('input[type="radio"]')) return el;
    return el.querySelector && el.querySelector('input[type="radio"]');
  }

  function getRadioOptionText(el) {
    var input = getRadioInput(el);
    var wrapper = input && input.closest
      ? input.closest(".wt-switch-radio, .ant-radio-wrapper, .el-radio, .phoenix-radio, label, [role='radio']")
      : null;
    if (!wrapper && el && el.closest) {
      wrapper = el.closest(".wt-switch-radio, .ant-radio-wrapper, .el-radio, .phoenix-radio, label, [role='radio']");
    }
    var titled = wrapper && wrapper.querySelector && wrapper.querySelector("span[title], [aria-label]");
    var phoenixText = wrapper && wrapper.querySelector && wrapper.querySelector(".phoenix-radio__radio-text");
    return String(
      (titled && (titled.getAttribute("title") || titled.getAttribute("aria-label") || titled.textContent)) ||
      (phoenixText && phoenixText.textContent) ||
      (wrapper && wrapper.textContent) ||
      (el && el.textContent) ||
      (input && (input.getAttribute("aria-label") || input.getAttribute("title"))) ||
      ""
    ).replace(/\s+/g, "").trim();
  }

  function isRadioSelected(el) {
    var input = getRadioInput(el);
    if (input) return !!input.checked;
    return !!(
      el &&
      (
        el.getAttribute && el.getAttribute("aria-checked") === "true" ||
        el.classList && Array.from(el.classList).some(function (c) {
          return /checked|selected|active|(^|[-_])r_on($|[-_])/.test(String(c).toLowerCase());
        }) ||
        el.closest && el.closest(".phoenix-radio--checked")
      )
    );
  }

  function dispatchRadioMouseSequence(element) {
    if (!element) return false;
    try {
      ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach(function (eventName) {
        var Ctor = /^pointer/.test(eventName) && typeof PointerEvent !== "undefined" ? PointerEvent : MouseEvent;
        element.dispatchEvent(new Ctor(eventName, { bubbles: true, cancelable: true, view: window }));
      });
      return true;
    } catch (e) {
      try {
        element.click();
        return true;
      } catch (err) {
        return false;
      }
    }
  }

  async function clickRadioOption(el) {
    if (!el) return false;
    var phoenixRoot = el.matches && el.matches(".phoenix-radio") ? el : el.closest && el.closest(".phoenix-radio");
    if (phoenixRoot) {
      if (isRadioSelected(phoenixRoot)) return true;
      var phoenixTargets = [
        phoenixRoot.querySelector(".phoenix-radio__wrapper"),
        phoenixRoot.querySelector(".phoenix-radio__circle-wrapper"),
        phoenixRoot.querySelector(".phoenix-radio__circle"),
        phoenixRoot.querySelector(".phoenix-radio__dot"),
        phoenixRoot.querySelector(".phoenix-radio__radio-text"),
        phoenixRoot,
      ].filter(Boolean);
      for (var pi = 0; pi < phoenixTargets.length; pi++) {
        dispatchRadioMouseSequence(phoenixTargets[pi]);
        await AF.Utils.sleep(80);
        if (isRadioSelected(phoenixRoot)) return true;
      }
      return isRadioSelected(phoenixRoot);
    }
    var input = getRadioInput(el);
    if (isRadioSelected(el)) return true;
    await AF.DomUtils.safeClickElement(el);
    await AF.Utils.sleep(80);
    if (isRadioSelected(el)) return true;
    // 建行旧版组件把 click 监听直接绑在 label.label_radio 上，合成坐标事件
    // 偶尔不会触发它的 jQuery 处理器；原生 click() 作为同元素兜底。
    if (el.matches && el.matches(".label_radio")) {
      try { el.click(); } catch (e) {}
      await AF.Utils.sleep(80);
      if (isRadioSelected(el)) return true;
    }
    if (input) {
      await AF.DomUtils.safeClickElement(input);
      input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
      input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      await AF.Utils.sleep(80);
      return isRadioSelected(el) || !!input.checked;
    }
    return isRadioSelected(el);
  }

  // ---------- handleGenderRadio (源码行53905-53987) ----------
  // 注: 名字叫"性别"，但源码里其实被复用做任意"是/否"型二选一(甚至三选一带"保密")
  // 单选组的兜底：按选项在 DOM 里出现的顺序，均分成 2 段(或 3 段，若含"保密"选项)，
  // 第一段点击代表"男/是"，第二段代表"女/否"。
  async function handleGenderRadio(radios, genderLabel) {
    try {
      var hasConfidential = radios.some(function (el) {
        var text = (el.textContent || "").trim().toLowerCase();
        return text.includes("保密") || text.includes("不公开");
      });
      var segment = hasConfidential ? Math.floor(radios.length / 3) : Math.floor(radios.length / 2);
      if (segment <= 0) return false;

      var offset;
      if (genderLabel === "男") {
        offset = 0;
      } else if (genderLabel === "女") {
        offset = segment;
      } else {
        return false;
      }

      var clicked = false;
      for (var i = offset; i < offset + segment; i++) {
        if (radios[i]) {
          clicked = (await clickRadioOption(radios[i])) || clicked;
        }
      }
      return clicked;
    } catch (err) {
      return false;
    }
  }

  // ---------- handleRadio (源码行53835-53904) ----------
  async function handleRadio(element, value, capabilityContext) {
    if (!element || value === null || value === undefined) return false;
    try {
      var radios = collectRadioGroup(element);
      if (!radios.length) return false;
      var capability = capabilityContext && capabilityContext.capability || null;
      var matchMode = String(capability && capability.matchMode || "");

      var directText = String(value).trim();
      var exact = radios.find(function (el) {
        return getRadioOptionText(el) === directText.replace(/\s+/g, "");
      });
      if (exact) return await clickRadioOption(exact);
      if (matchMode === "exact") {
        return capability && capability.fallback === "firstOption" ? await clickRadioOption(radios[0]) : false;
      }

      if (matchMode === "exactOrContains") {
        var contained = radios.find(function (el) {
          var option = getRadioOptionText(el);
          var target = directText.replace(/\s+/g, "");
          return option && (option.indexOf(target) !== -1 || target.indexOf(option) !== -1);
        });
        if (contained) return await clickRadioOption(contained);
        return capability && capability.fallback === "firstOption" ? await clickRadioOption(radios[0]) : false;
      }

      // 源码行53853-53869: 布尔/是否类值先归一化成 男/女 两档位置，
      // 复用 handleGenderRadio 的"按位置二分/三分"兜底逻辑
      if (typeof value === "boolean" || value === "true" || value === "false" || value === "是" || value === "否") {
        var mapped = value === true || value === "true" || value === "是" ? "男" : "女";
        return await handleGenderRadio(radios, mapped);
      }
      if (value === "男" || value === "女") {
        return await handleGenderRadio(radios, value);
      }

      // 源码行53871-53890: 通用文字相似度匹配，取分数最高且 > 0.3 的选项
      var candidates = radios
        .map(function (el) {
          var text = getRadioOptionText(el);
          return { element: el, text: text, score: textSimilarityScore(text, String(value)) };
        })
        .sort(function (a, b) {
          return b.score - a.score;
        });

      var best = candidates[0];
      if (best && best.score > 0.3) {
        return await clickRadioOption(best.element);
      }
      return false;
    } catch (err) {
      console.warn("[AF.FormHandler] handleRadio 失败:", err);
      return false;
    }
  }

  function collectCheckboxGroup(element) {
    try {
      if (Array.isArray(element)) return element;
      if (typeof element.length === "number" && element.length > 0 && element[0] && element[0].nodeType) {
        return Array.from(element);
      }
      var group = element.closest && element.closest(".ant-checkbox-group, .el-checkbox-group, [role='group']");
      if (group) {
        return Array.from(group.querySelectorAll('input[type="checkbox"], [role="checkbox"], .ant-checkbox-wrapper, .el-checkbox'));
      }
      return [element];
    } catch (e) {
      return [element];
    }
  }

  function getCheckboxInput(el) {
    return el && el.matches && el.matches('input[type="checkbox"]') ? el : el.querySelector && el.querySelector('input[type="checkbox"]') || el;
  }

  function getCheckboxText(el) {
    var input = getCheckboxInput(el);
    return String(
      (input && input.value) ||
        (el && (el.textContent || el.getAttribute && (el.getAttribute("aria-label") || el.getAttribute("title")))) ||
        ""
    ).trim();
  }

  // ---------- handleCheckbox (源码行54054-54073，扩展支持 checkbox 组) ----------
  async function handleCheckbox(element, value, capabilityContext) {
    if (!element) return false;
    try {
      var boxes = collectCheckboxGroup(element);
      var capability = capabilityContext && capabilityContext.capability || null;
      var matchMode = String(capability && capability.matchMode || "");
      var wanted = Array.isArray(value) ? value.map(String) : [String(value)];
      var clicked = false;

      for (var i = 0; i < boxes.length; i++) {
        var box = boxes[i];
        var input = getCheckboxInput(box);
        if (!input) continue;
        var optionText = getCheckboxText(box).toLowerCase();
        var shouldCheck;
        if (typeof value === "boolean" || value === "true" || value === "false" || value === "是" || value === "否") {
          shouldCheck = value === true || value === "true" || value === "是";
        } else {
          shouldCheck = wanted.some(function (v) {
            var t = String(v).toLowerCase();
            if (matchMode === "exact") return optionText === t;
            return optionText === t || optionText.indexOf(t) !== -1 || t.indexOf(optionText) !== -1;
          });
        }

        if (!!input.checked !== !!shouldCheck) {
          await AF.DomUtils.safeClickElement(box);
          clicked = true;
        } else {
          input.dispatchEvent(new Event("change", { bubbles: true }));
        }
      }
      return clicked || boxes.length > 0;
    } catch (err) {
      console.warn("[AF.FormHandler] handleCheckbox 失败:", err);
      return false;
    }
  }

  // 通用下拉选项选择器集合 (综合各 UI 框架常见 class，供 handleSearchInput /
  // handleMultiSelect 查找弹出面板里的候选项使用；源码里这部分逻辑分散在
  // SelectAdapter 各适配器里，本文件不重复实现完整适配器体系，只做够用的通用扫描)
  var GENERIC_DROPDOWN_OPTION_SELECTORS = [
    ".ant-select-item-option",
    ".ant-select-dropdown-menu-item",
    ".el-select-dropdown__item",
    ".el-cascader__suggestion-item",
    ".el-cascader-node",
    ".el-cascader-menu__item",
    ".aui-select-dropdown__item",
    ".aui-select-dropdown li",
    ".aui-select-option",
    ".aui-option",
    ".aui-dropdown-item",
    "[class*='aui-select'][class*='item']",
    "[class*='aui-option']",
    ".ivu-select-item",
    ".mtd-option",
    ".kuma-select2-dropdown-menu-item",
    '[role="option"]',
    'li[role="option"]',
  ];

  function isFrame示例资料SelectLike(element) {
    return Boolean(
      element &&
      element.closest &&
      element.closest(
        ".el-select, .el-autocomplete, .el-cascader, .ant-select, .ant-cascader-picker, .aui-select, .ivu-select, .layui-form-select, .kuma-select2, .brick-select, .phoenix-select, .select2-container, .chosen-container, [class^='sd-Select-container'], [class*=' sd-Select-container'], [class*='sd-Select']"
      )
    );
  }

  var SEARCH_OPTION_CLASS_PATTERNS = [
    "item", "option", "result", "suggestion", "dropdown-item",
    "select-option", "list-item", "menu-item", "choice", "tree-title"
  ];
  var SEARCH_OPTION_ROLES = [
    "option", "listitem", "menuitem", "menuitemcheckbox", "menuitemradio", "tab", "treeitem"
  ];
  var SEARCH_OPTION_TAGS = ["li", "option", "a", "ul", "span"];
  var SEARCH_CONTAINER_CLASS_PATTERNS = [
    "dropdown", "container", "menu", "list", "select", "popup", "panel", "wrapper", "group"
  ];

  function setSearchInputValue(input, value) {
    var previous = input.value;
    try {
      var descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
      if (descriptor && descriptor.set) descriptor.set.call(input, value);
      else input.value = value;
    } catch (e) {
      input.value = value;
    }
    // React controlled inputs compare the DOM value with _valueTracker. When
    // code runs in the page main world (Electron webview), assigning .value
    // updates the tracker too, so the following input event is ignored unless
    // the tracker is restored to the previous value.
    try {
      if (input._valueTracker && typeof input._valueTracker.setValue === "function") {
        input._valueTracker.setValue(previous);
      }
    } catch (e2) {}
    input.setAttribute("value", value);
  }

  function searchInputData(input, value, shouldBlur) {
    return (async function () {
      input.dispatchEvent(new Event("focus"));
      await AF.Utils.sleep(10);
      setSearchInputValue(input, value);
      input.dispatchEvent(new Event("input", { bubbles: true, cancelable: false }));
      if (shouldBlur !== false) input.dispatchEvent(new Event("blur"));
    })();
  }

  async function searchDialogInputData(input, value) {
    if (!input) return;
    try { input.focus(); } catch (e0) {
      input.dispatchEvent(new Event("focus"));
    }
    try { input.dispatchEvent(new FocusEvent("focusin", { bubbles: true, composed: true })); } catch (e1) {}
    await AF.Utils.sleep(20);
    setSearchInputValue(input, "");
    input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    await AF.Utils.sleep(16);
    setSearchInputValue(input, value);
    try {
      input.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        cancelable: true,
        composed: true,
        data: String(value),
        inputType: "insertText",
      }));
    } catch (e2) {
      input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    }
    // 部分旧组件监听 change/keyup 而不是 input；仅在独立弹窗搜索框内补齐事件链。
    input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    try { input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "Unidentified" })); } catch (e3) {}
    await AF.Utils.sleep(40);
  }

  function searchOptionClassName(element) {
    if (!element) return "";
    if (typeof element.className === "string") return element.className || "";
    if (element.className && element.className.baseVal !== undefined) return element.className.baseVal || "";
    return Array.from(element.classList || []).join(" ");
  }

  function isSearchOptionElement(element) {
    if (!element || element.nodeType !== Node.ELEMENT_NODE) return false;
    var role = element.getAttribute("role");
    if (role && SEARCH_OPTION_ROLES.indexOf(role) !== -1) return true;
    var tag = String(element.tagName || "").toLowerCase();
    var className = searchOptionClassName(element);
    var optionClass = SEARCH_OPTION_CLASS_PATTERNS.some(function (pattern) {
      return className.indexOf(pattern) !== -1;
    });
    if (SEARCH_OPTION_TAGS.indexOf(tag) !== -1) {
      var containerClass = SEARCH_CONTAINER_CLASS_PATTERNS.some(function (pattern) {
        return className.indexOf(pattern) !== -1;
      });
      return !(containerClass && !optionClass);
    }
    return optionClass;
  }

  function isSearchOptionVisible(element) {
    try {
      for (var current = element; current; current = current.parentElement) {
        var style = window.getComputedStyle(current);
        if (style.display === "none" || style.visibility === "hidden" || parseFloat(style.opacity) === 0) return false;
      }
      return true;
    } catch (e) {
      return true;
    }
  }

  function isSubordinateSchoolOption(text, target) {
    var option = String(text || "").toLowerCase();
    var wanted = String(target || "").toLowerCase();
    if (!option || !wanted || option === wanted || option.indexOf(wanted) === -1) return false;
    return ["学院", "分校", "分院", "校区"].some(function (suffix) {
      return option.indexOf(suffix) !== -1 && !wanted.endsWith(suffix);
    });
  }

  function searchOptionScore(text, target) {
    var option = String(text || "").trim().toLowerCase();
    var wanted = String(target || "").trim().toLowerCase();
    if (!option || !wanted) return 0;
    if (option === wanted) return 1;
    if (option.replace(/\s*[|\/]\s*/, " ").startsWith(wanted + " ")) return 0.95;
    var chinese = (String(text || "").match(/[\u4e00-\u9fa5]+/g) || []).join("").toLowerCase();
    if (chinese && chinese === wanted) return 0.9;
    if (isSubordinateSchoolOption(option, wanted)) return 0.4;
    if (option.indexOf(wanted) !== -1) return Math.min(0.85, wanted.length / option.length * 0.8 + 0.2);
    if (wanted.indexOf(option) !== -1) return Math.min(0.75, option.length / wanted.length * 0.7 + 0.1);
    try {
      if (AF.DomUtils.isSimilarText(option, wanted)) return 0.7;
      if (AF.DomUtils.isOptionMatch(option, option, wanted)) return 0.65;
    } catch (e) {}
    return 0;
  }

  function findMatchingSearchOption(elements, value) {
    var target = String(value == null ? "" : value).trim();
    if (!target) return null;
    var candidates = Array.from(elements || []).filter(function (element) {
      return element && isSearchOptionVisible(element) && !element.querySelector("input");
    }).map(function (element) {
      var text = String(element.textContent || "").trim();
      return { element: element, text: text, score: searchOptionScore(text, target) };
    }).filter(function (entry) {
      return entry.text && entry.score >= 0.3;
    }).sort(function (a, b) {
      var aSub = isSubordinateSchoolOption(a.text, target);
      var bSub = isSubordinateSchoolOption(b.text, target);
      if (aSub !== bSub) return aSub ? 1 : -1;
      return b.score - a.score;
    });
    return candidates[0] && candidates[0].element || null;
  }

  function collectSearchOptionCandidates(root) {
    var found = new Set();
    function add(element) {
      if (!element || element.nodeType !== Node.ELEMENT_NODE) return;
      if (isSearchOptionElement(element)) found.add(element);
      try {
        element.querySelectorAll("*").forEach(function (child) {
          if (isSearchOptionElement(child)) found.add(child);
        });
      } catch (e) {}
    }
    add(root || document.body);
    return Array.from(found);
  }

  function monitorSearchOptionsAppearance(value, timeoutMs) {
    return new Promise(function (resolve) {
      var finished = false;
      var observer = null;
      var timer = null;
      var pending = null;
      function finish(option) {
        if (finished) return;
        finished = true;
        if (observer) observer.disconnect();
        if (timer) clearTimeout(timer);
        if (pending) clearTimeout(pending);
        resolve(option || null);
      }
      function scan(root) {
        var option = findMatchingSearchOption(collectSearchOptionCandidates(root || document.body), value);
        if (option) finish(option);
      }
      try {
        observer = new MutationObserver(function (mutations) {
          if (finished) return;
          if (pending) clearTimeout(pending);
          pending = setTimeout(function () {
            pending = null;
            var roots = [];
            mutations.forEach(function (mutation) {
              if (mutation.target && mutation.target.nodeType === Node.ELEMENT_NODE) roots.push(mutation.target);
              Array.from(mutation.addedNodes || []).forEach(function (node) {
                if (node.nodeType === Node.ELEMENT_NODE) roots.push(node);
              });
            });
            for (var i = 0; i < roots.length && !finished; i++) scan(roots[i]);
            if (!finished) scan(document.body);
          }, 20);
        });
        observer.observe(document.body, { attributes: true, attributeOldValue: true, childList: true, subtree: true });
      } catch (e) {}
      timer = setTimeout(function () {
        scan(document.body);
        if (!finished) finish(null);
      }, timeoutMs || 1000);
    });
  }

  async function clickSearchOptionLeaf(option) {
    if (!option) return false;
    var leaves = [];
    try {
      leaves = Array.from(option.querySelectorAll("*:not(:has(*))"));
    } catch (e) {
      leaves = Array.from(option.querySelectorAll("div, span"));
    }
    var leaf = leaves.find(function (element) {
      return String(element && element.textContent || "").trim().length > 0;
    });
    // SearchInputHandler 原产品这里必须直接调用文字叶节点的原生 click()。
    // Moka 学校候选项的 React onClick 依赖该事件沿 DOM 冒泡；safeClickElement
    // 的坐标事件会落到其他覆盖节点，表现为文字已输入、候选项仍展开但没有选中。
    (leaf || option).click();
    return true;
  }

  function normalizeSearchCommitValue(value) {
    return String(value == null ? "" : value).toLowerCase().replace(/[\s：:()（）\-_/]/g, "");
  }

  function searchCommitMatches(expected, actual) {
    var wanted = normalizeSearchCommitValue(expected);
    var committed = normalizeSearchCommitValue(actual);
    if (!wanted || !committed) return false;
    return wanted === committed || committed.indexOf(wanted) !== -1 || wanted.indexOf(committed) !== -1;
  }

  function readCommittedSearchValue(element, input) {
    try {
      var control = element && element.closest && element.closest(
        '[class^="sd-Dropdown-container"], [class*=" sd-Dropdown-container"], ' +
        '[class^="sd-Select-container"], [class*=" sd-Select-container"], [class*="sd-Select"]'
      );
      if (!control && element && element.querySelector) control = element;
      var display = control && control.querySelector && control.querySelector('[class*="sd-Input-display-value"]');
      var displayText = String(display && display.textContent || "").replace(/\s+/g, " ").trim();
      if (displayText && !/^(请选择|请输入|Select)$/i.test(displayText)) return displayText;
    } catch (e) {}
    return String(input && input.value || "").trim();
  }

  function isVisibleDialogElement(element) {
    if (!element) return false;
    if (AF.DomUtils && typeof AF.DomUtils.isElementVisible === "function") {
      return AF.DomUtils.isElementVisible(element);
    }
    return Boolean(element.offsetWidth || element.offsetHeight || element.getClientRects().length);
  }

  function normalizeDialogChoiceText(value) {
    return String(value == null ? "" : value)
      .toLowerCase()
      .replace(/[\s:：()（）\-_/]/g, "");
  }

  function visibleChoiceDialogs() {
    try {
      var dialogs = Array.from(document.querySelectorAll(
        "[role='dialog'], .ant-modal, .ant-modal-wrap, .el-dialog, .el-dialog__wrapper, " +
        ".common-unmodeled-layer:not(.common-unmodeled-layer-hidden), .phoenix-unmodeled-layer:not(.phoenix-unmodeled-layer-hidden)"
      )).filter(function (dialog) {
        if (!isVisibleDialogElement(dialog)) return false;
        var text = String(dialog.textContent || "").replace(/\s+/g, " ").trim();
        var hasEditableInput = Array.from(dialog.querySelectorAll("input[type='text'], input[type='search'], input:not([type])")).some(function (input) {
          return isVisibleDialogElement(input) && !input.disabled && !input.readOnly;
        });
        var hasConfirm = Array.from(dialog.querySelectorAll("button, [role='button']")).some(function (button) {
          return isVisibleDialogElement(button) && /^(选择|确定|确认|完成|应用)$/.test(String(button.textContent || "").trim());
        });
        return hasEditableInput && hasConfirm && /(选择|请选择|学校|院校|专业|职位|行业|类别)/.test(text);
      });
      // Ant/Element 弹窗经常同时命中 wrapper 和内部 dialog，优先返回面积更小的真实内容层。
      return dialogs.sort(function (a, b) {
        var ar = a.getBoundingClientRect();
        var br = b.getBoundingClientRect();
        return ar.width * ar.height - br.width * br.height;
      });
    } catch (e) {
      return [];
    }
  }

  function closeChoiceDialog(dialog) {
    try {
      var buttons = Array.from(dialog.querySelectorAll("button, [role='button']")).filter(isVisibleDialogElement);
      var close = buttons.find(function (button) {
        return /^(取消|关闭|Cancel|Close)$/i.test(String(button.textContent || "").trim());
      }) || dialog.querySelector(".ant-modal-close, .el-dialog__headerbtn, [aria-label='Close'], [aria-label='关闭']");
      if (close) close.click();
    } catch (e) {}
  }

  function findDialogChoiceCandidate(dialog, keyword) {
    var target = normalizeDialogChoiceText(keyword);
    if (!target) return null;
    // 学校、专业弹窗有省份标签和大块容器，不能把这些带有目标文字的父节点
    // 当成候选项。优先只在站点真实候选项中匹配，找不到专用节点时才兼容
    // 原有通用弹窗选项。
    var dedicatedNodes = Array.from(dialog.querySelectorAll(".school-item, .subject-item"));
    var nodes = (dedicatedNodes.length ? dedicatedNodes : Array.from(dialog.querySelectorAll(
      "[role='option'], [role='treeitem'], [role='menuitem'], [data-value], li, .ant-list-item, .ant-select-dropdown-menu-item, " +
      "[class*='option'], [class*='item'], [class*='tree-node'], [class*='treeNode'], [class*='node-name'], [class*='nodeName']"
    ))).filter(function (node) {
      if (!isVisibleDialogElement(node)) return false;
      if (node.closest("button, [role='button']")) return false;
      if (node.querySelector("input, textarea, button, [role='button']")) return false;
      var text = String(node.textContent || "").replace(/\s+/g, " ").trim();
      if (!text || /^(取消|关闭|选择|确定|确认|完成|应用)$/.test(text)) return false;
      var normalized = normalizeDialogChoiceText(text);
      return normalized === target || normalized.indexOf(target) !== -1 || target.indexOf(normalized) !== -1;
    });
    // 精确文字优先；没有完全一致时，保持站点搜索结果原顺序并取第一条。
    // 模糊专业由用户在流程结束后的检查提示中复核，不在这里猜测分类。
    return nodes.find(function (node) {
      return normalizeDialogChoiceText(node.textContent) === target;
    }) || nodes[0] || null;
  }

  function dialogChoiceCandidates(dialog) {
    try {
      return Array.from(dialog.querySelectorAll(
        ".school-item, .subject-item, [role='option'], [role='treeitem'], [role='menuitem'], [data-value], " +
        ".ant-list-item, .ant-select-dropdown-menu-item, [class*='tree-node'], [class*='treeNode'], [class*='node-name'], [class*='nodeName']"
      )).filter(function (node) {
        return isVisibleDialogElement(node) &&
          !node.closest("button, [role='button']") &&
          !/暂无数据|无匹配结果|加载中|loading/i.test(String(node.textContent || ""));
      });
    } catch (e) {
      return [];
    }
  }

  function findFirstDialogChoiceCandidate(dialog) {
    return dialogChoiceCandidates(dialog)[0] || null;
  }

  function isChinaTelecomHotjobPage() {
    return /(^|\.)job\.chinatelecom\.com\.cn$/i.test(String(location.hostname || ""));
  }

  function normalizeHotjobDate(value, isEndDate) {
    if (value && typeof value === "object") {
      value = isEndDate ? value.endTime || value.endDate : value.startTime || value.startDate;
    }
    var text = String(value == null ? "" : value).trim();
    if (!text || /至今|目前|现在|present|current/i.test(text)) return "";
    var match = text.match(/(\d{4})\D+(\d{1,2})(?:\D+(\d{1,2}))?/);
    if (!match) return text;
    var year = Number(match[1]);
    var month = Number(match[2]);
    var day = match[3] ? Number(match[3]) : (isEndDate ? new Date(year, month, 0).getDate() : 1);
    var pad = function (number) { return String(number).padStart(2, "0"); };
    return year + "/" + pad(month) + "/" + pad(day);
  }

  function requestHotjobMainDate(input, target) {
    return new Promise(function (resolve) {
      if (!input || !document.documentElement.hasAttribute("data-af-hotjob-main-bridge")) {
        resolve(null);
        return;
      }
      var id = "af-hotjob-date-" + Date.now() + "-" + Math.random().toString(36).slice(2);
      var token = id + "-input";
      var finished = false;
      input.setAttribute("data-af-hotjob-date-token", token);
      var cleanup = function () {
        window.removeEventListener("message", onMessage);
        if (input && input.removeAttribute) input.removeAttribute("data-af-hotjob-date-token");
      };
      var onMessage = function (event) {
        var data = event.data || {};
        if (event.source !== window || data.type !== "AF_HOTJOB_DATE_RESULT" || data.id !== id) return;
        finished = true;
        cleanup();
        resolve({ handled: true, success: !!data.ok, value: data.value || "", error: data.error || "" });
      };
      window.addEventListener("message", onMessage);
      window.postMessage({ type: "AF_HOTJOB_DATE_REQUEST", id: id, token: token, target: target }, "*");
      setTimeout(function () {
        if (finished) return;
        cleanup();
        resolve({ handled: true, success: false, error: "main_date_bridge_timeout" });
      }, 3000);
    });
  }

  async function tryFillHotjobDayType(element, value) {
    if (!isChinaTelecomHotjobPage()) return { handled: false, success: false };
    var input = element && element.matches && element.matches("input.dayType")
      ? element
      : element && element.querySelector && element.querySelector("input.dayType");
    if (!input) return { handled: false, success: false };
    var target = normalizeHotjobDate(value, input.classList.contains("endDate") || /毕业|结束|截止/.test(String(input.getAttribute("msg") || "")));
    if (!target) return { handled: true, success: false };
    try {
      // 页面会保留多个 `.datetimepicker` 实例。优先在主页面直接调用当前 input
      // 自己绑定的 Bootstrap datetimepicker，避免按全局面板误命中其他日期字段。
      var mainDateResult = await requestHotjobMainDate(input, target);
      if (mainDateResult && mainDateResult.success) return mainDateResult;

      var parts = target.split("/").map(Number);
      var targetYear = parts[0];
      var targetMonth = parts[1];
      var targetDay = parts[2];
      await AF.DomUtils.safeClickElement(input);
      var panel = null;
      for (var panelWait = 0; panelWait < 20; panelWait++) {
        await AF.Utils.sleep(80);
        panel = Array.from(document.querySelectorAll(".datetimepicker")).find(function (candidate) {
          return isVisibleDialogElement(candidate);
        }) || null;
        if (panel) break;
      }
      if (!panel) return { handled: true, success: false };

      var daySwitch = panel.querySelector(".datetimepicker-days th.switch");
      if (!daySwitch) return { handled: true, success: false };
      await AF.DomUtils.safeClickElement(daySwitch);
      await AF.Utils.sleep(60);
      var monthSwitch = panel.querySelector(".datetimepicker-months th.switch");
      if (!monthSwitch) return { handled: true, success: false };
      await AF.DomUtils.safeClickElement(monthSwitch);
      await AF.Utils.sleep(60);

      var yearsView = panel.querySelector(".datetimepicker-years");
      var yearSelected = false;
      for (var decadeMove = 0; decadeMove < 20; decadeMove++) {
        var yearOption = Array.from(yearsView.querySelectorAll("span.year")).find(function (node) {
          return Number(String(node.textContent || "").trim()) === targetYear;
        });
        if (yearOption) {
          await AF.DomUtils.safeClickElement(yearOption);
          yearSelected = true;
          break;
        }
        var rangeText = String(yearsView.querySelector("th.switch") && yearsView.querySelector("th.switch").textContent || "");
        var rangeMatch = rangeText.match(/(\d{4})\D+(\d{4})/);
        if (!rangeMatch) return { handled: true, success: false };
        var direction = targetYear < Number(rangeMatch[1]) ? ".prev" : ".next";
        var decadeButton = yearsView.querySelector("th" + direction);
        if (!decadeButton) return { handled: true, success: false };
        await AF.DomUtils.safeClickElement(decadeButton);
        await AF.Utils.sleep(45);
      }
      if (!yearSelected) return { handled: true, success: false };

      var monthsView = panel.querySelector(".datetimepicker-months");
      var monthOption = Array.from(monthsView.querySelectorAll("span.month")).find(function (node, index) {
        var number = Number(String(node.textContent || "").replace(/\D/g, ""));
        return number ? number === targetMonth : index + 1 === targetMonth;
      });
      if (!monthOption) return { handled: true, success: false };
      await AF.DomUtils.safeClickElement(monthOption);
      await AF.Utils.sleep(60);

      var daysView = panel.querySelector(".datetimepicker-days");
      var dayOption = Array.from(daysView.querySelectorAll("td.day:not(.old):not(.new)")).find(function (node) {
        return Number(String(node.textContent || "").trim()) === targetDay;
      });
      if (!dayOption) return { handled: true, success: false };
      await AF.DomUtils.safeClickElement(dayOption);
      await AF.Utils.sleep(120);
      // 该组件内部模型使用 YYYY-MM-DD，日历展示有时使用 YYYY/MM/DD。
      // 只比较数字日期，不能因为分隔符不同误判失败后再落入通用日期器；后者
      // 会按当前面板默认值点击“今天”，正是页面出现 2026/08/22 的原因。
      var comparable = function (dateText) {
        var parts = String(dateText || "").match(/(\d{4})\D+(\d{1,2})\D+(\d{1,2})/);
        return parts ? [Number(parts[1]), Number(parts[2]), Number(parts[3])].join("-") : "";
      };
      var committedDate = String(input.value || input.getAttribute("value") || "").trim();
      return { handled: true, success: comparable(committedDate) === comparable(target) };
    } catch (e) {
      try { document.body.click(); } catch (closeError) {}
      return { handled: true, success: false };
    }
  }

  function hotjobChoiceText(node) {
    return String(node && (node.getAttribute("title") || node.textContent) || "").replace(/\s+/g, " ").trim();
  }

  function resolveHotjobSchoolSubjectRoot(element) {
    if (!element || !element.closest) return null;
    if (element.matches && element.matches("dy-form-special")) return element;
    var root = element.closest("dy-form-special");
    if (root) return root;
    if (element.querySelector) {
      root = element.querySelector("dy-form-special");
      if (root) return root;
    }
    var cell = element.closest(".mdf-table-cell");
    return cell && cell.querySelector("dy-form-special");
  }

  function requestHotjobMainChoice(input, keyword) {
    return new Promise(function (resolve) {
      if (!input || !document.documentElement.hasAttribute("data-af-hotjob-main-bridge")) {
        resolve(null);
        return;
      }
      var id = "af-hotjob-" + Date.now() + "-" + Math.random().toString(36).slice(2);
      var token = id + "-input";
      var finished = false;
      input.setAttribute("data-af-hotjob-token", token);
      var cleanup = function () {
        window.removeEventListener("message", onMessage);
        if (input && input.removeAttribute) input.removeAttribute("data-af-hotjob-token");
      };
      var onMessage = function (event) {
        var data = event.data || {};
        if (event.source !== window || data.type !== "AF_HOTJOB_CHOICE_RESULT" || data.id !== id) return;
        finished = true;
        cleanup();
        resolve({ handled: true, success: !!data.ok, value: data.value || "", error: data.error || "" });
      };
      window.addEventListener("message", onMessage);
      window.postMessage({ type: "AF_HOTJOB_CHOICE_REQUEST", id: id, token: token, keyword: String(keyword || "") }, "*");
      setTimeout(function () {
        if (finished) return;
        cleanup();
        resolve({ handled: true, success: false, error: "main_bridge_timeout" });
      }, 10000);
    });
  }

  async function fillHotjobInlineChoice(root, input, hidden, opener, keyword) {
    var mainResult = await requestHotjobMainChoice(input, keyword);
    if (mainResult) return mainResult;
    var before = String(hidden && hidden.value || opener && (opener.value || opener.title) || "").trim();
    if (!isVisibleDialogElement(input) && opener && isVisibleDialogElement(opener)) {
      await AF.DomUtils.safeClickElement(opener);
      await AF.Utils.sleep(100);
    }
    if (!isVisibleDialogElement(input)) return { handled: true, success: false };
    await searchDialogInputData(input, keyword);
    var candidates = [];
    for (var waitIndex = 0; waitIndex < 50; waitIndex++) {
      await AF.Utils.sleep(100);
      candidates = Array.from(root.querySelectorAll(".schoolOrSubject li")).filter(function (node) {
        return isVisibleDialogElement(node) && hotjobChoiceText(node);
      });
      if (candidates.length) break;
    }
    if (!candidates.length) return { handled: true, success: false };
    var wanted = normalizeDialogChoiceText(keyword);
    var selected = candidates.find(function (node) {
      return normalizeDialogChoiceText(hotjobChoiceText(node)) === wanted;
    }) || candidates.find(function (node) {
      var text = normalizeDialogChoiceText(hotjobChoiceText(node));
      return text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1;
    }) || candidates[0];
    await AF.DomUtils.safeClickElement(selected);
    await AF.Utils.sleep(180);
    var committed = String(hidden && hidden.value || opener && (opener.value || opener.title) || input.value || "").trim();
    return { handled: true, success: Boolean(committed && (committed !== before || normalizeDialogChoiceText(committed) === wanted)) };
  }

  async function tryFillHotjobSchoolSubject(element, keyword) {
    if (!isChinaTelecomHotjobPage()) return { handled: false, success: false };
    var root = resolveHotjobSchoolSubjectRoot(element);
    if (!root) return { handled: false, success: false };
    var schoolModal = root.querySelector("#choose-school");
    var subjectModal = root.querySelector("#choose-subject");
    var modal = schoolModal || subjectModal;
    var visibleInlineInput = Array.from(root.querySelectorAll("input[school-or-subject='2']")).find(function (candidate) {
      return isVisibleDialogElement(candidate);
    }) || root.querySelector("input[school-or-subject='2'][ng-model='justForModelVal2']");
    if (visibleInlineInput) {
      return await fillHotjobInlineChoice(
        root,
        visibleInlineInput,
        root.querySelector("input[type='hidden']"),
        root.querySelector("input[school-or-subject='1']"),
        keyword
      );
    }
    if (!modal) {
      var inlineInput = root.querySelector("input[school-or-subject='2']");
      var inlineHidden = root.querySelector("input[type='hidden']");
      var inlineOpener = root.querySelector("input[school-or-subject='1']");
      if (!inlineInput || !inlineHidden || !/奖励名称/.test(String(inlineHidden.getAttribute("msg") || ""))) {
        return { handled: false, success: false };
      }
      try {
        return await fillHotjobInlineChoice(root, inlineInput, inlineHidden, inlineOpener, keyword);
      } catch (e) {
        return { handled: true, success: false };
      }
    }
    var searchSelector = schoolModal ? ".search-school" : ".search-job";
    var opener = root.querySelector("input[school-or-subject='1']");
    var hidden = root.querySelector("input[type='hidden']");
    var beforeValue = String(hidden && hidden.value || opener && (opener.value || opener.title) || "").trim();
    try {
      await AF.DomUtils.safeClickElement(opener || element);
      for (var openWait = 0; openWait < 20 && !isVisibleDialogElement(modal); openWait++) {
        await AF.Utils.sleep(100);
      }
      if (!isVisibleDialogElement(modal)) return { handled: true, success: false };
      var searchInput = modal.querySelector(searchSelector);
      if (!searchInput) return { handled: true, success: false };
      await searchDialogInputData(searchInput, keyword);
      var searchButton = modal.querySelector(".search-img");
      if (searchButton) await AF.DomUtils.safeClickElement(searchButton);

      var candidates = [];
      for (var waitIndex = 0; waitIndex < 50; waitIndex++) {
        await AF.Utils.sleep(100);
        candidates = Array.from(modal.querySelectorAll(".search-result-li li")).filter(function (node) {
          return isVisibleDialogElement(node) && hotjobChoiceText(node);
        });
        if (candidates.length) break;
      }
      if (!candidates.length) return { handled: true, success: false };
      var wanted = normalizeDialogChoiceText(keyword);
      var candidate = candidates.find(function (node) {
        return normalizeDialogChoiceText(hotjobChoiceText(node)) === wanted;
      }) || candidates.find(function (node) {
        var text = normalizeDialogChoiceText(hotjobChoiceText(node));
        return text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1;
      }) || candidates[0];
      await AF.DomUtils.safeClickElement(candidate);

      for (var verifyIndex = 0; verifyIndex < 25; verifyIndex++) {
        await AF.Utils.sleep(100);
        var committed = String(hidden && hidden.value || opener && (opener.value || opener.title) || "").trim();
        if (committed && committed !== beforeValue) return { handled: true, success: true };
        if (!isVisibleDialogElement(modal) && committed) return { handled: true, success: true };
      }
      return { handled: true, success: false };
    } catch (e) {
      return { handled: true, success: false };
    }
  }

  function isHotjobSchoolField(element) {
    if (!isChinaTelecomHotjobPage() || !element || !element.closest) return false;
    var root = resolveHotjobSchoolSubjectRoot(element);
    if (!root) return false;
    var hidden = root.querySelector("input[type='hidden']");
    return String(hidden && hidden.getAttribute("msg") || "").trim() === "学校名称" &&
      Boolean(root.querySelector("input[school-or-subject='1'], input[school-or-subject='2']"));
  }

  // 普通搜索框优先保持原逻辑；只有点击后真实出现“搜索 + 选项 + 确认”的独立弹窗，
  // 才接管为弹窗选择器。未检测到弹窗时返回 handled:false，调用方继续旧流程。
  async function tryFillDialogChoice(element, input, keyword, choiceHints) {
    choiceHints = choiceHints || {};
    var placeholder = String(input && input.getAttribute && input.getAttribute("placeholder") || "").trim();
    var standardSelect = input && input.closest && input.closest(
      ".ant-select, .el-select, .ivu-select, .next-select, .rocket-select, [role='combobox']"
    );
    // 避免给所有原有搜索下拉增加弹窗等待时间。普通选择器继续走旧逻辑；
    // 这里只探测“请选择学校/专业”等看似输入框、实际点击打开大弹窗的入口。
    var forceProbe = choiceHints.forceProbe === true;
    if (!forceProbe && (!/^(请选择|请搜索|点击选择)/.test(placeholder) || standardSelect)) return { handled: false, success: false };
    var beforeDialogs = visibleChoiceDialogs();
    var beforeValue = String(input && input.value || "").trim();
    var openerInputs = Array.from(document.querySelectorAll("input")).filter(function (candidate) {
      return String(candidate.getAttribute("placeholder") || "").trim() === placeholder && isVisibleDialogElement(candidate);
    });
    var openerIndex = Math.max(0, openerInputs.indexOf(input));
    var resolveLiveInput = function () {
      if (input && input.isConnected) return input;
      var current = Array.from(document.querySelectorAll("input")).filter(function (candidate) {
        return String(candidate.getAttribute("placeholder") || "").trim() === placeholder && isVisibleDialogElement(candidate);
      });
      return current[openerIndex] || current[0] || input;
    };
    // 学校/专业候选被点击后，部分 React 弹窗会整体重渲染。旧 dialog
    // 引用此时已经 detached，但新的“选择”按钮仍在新弹窗中。后续确认和
    // 校验必须重新取得当前可见弹窗，否则会出现候选已点中却无法确认回填。
    var resolveLiveDialog = function (previousDialog) {
      var dialogs = visibleChoiceDialogs();
      if (previousDialog && previousDialog.isConnected && isVisibleDialogElement(previousDialog)) return previousDialog;
      if (!dialogs.length) return previousDialog || null;
      var previousClass = previousDialog && String(previousDialog.className || "");
      var sameKind = dialogs.find(function (candidate) {
        var candidateClass = String(candidate.className || "");
        return previousClass && candidateClass && (
          candidateClass === previousClass ||
          (previousClass.indexOf("school-wrap") !== -1 && candidateClass.indexOf("school-wrap") !== -1)
        );
      });
      return sameKind || dialogs[0] || previousDialog || null;
    };
    try {
      await AF.DomUtils.safeClickElement(input || element);
      var dialog = null;
      for (var waitIndex = 0; waitIndex < 25; waitIndex++) {
        await AF.Utils.sleep(100);
        var dialogs = visibleChoiceDialogs();
        dialog = dialogs.find(function (candidate) { return beforeDialogs.indexOf(candidate) === -1; }) || dialogs[0] || null;
        if (dialog) break;
      }
      if (!dialog) return { handled: false, success: false };

      var searchInput = Array.from(dialog.querySelectorAll("input[type='text'], input[type='search'], input:not([type])")).find(function (candidate) {
        if (candidate === input || !isVisibleDialogElement(candidate) || candidate.disabled || candidate.readOnly) return false;
        return /(搜索|请输入|学校|院校|专业|职位|行业|名称|关键字)/.test(String(candidate.placeholder || ""));
      }) || Array.from(dialog.querySelectorAll("input[type='text'], input[type='search'], input:not([type])")).find(function (candidate) {
        return candidate !== input && isVisibleDialogElement(candidate) && !candidate.disabled && !candidate.readOnly;
      });
      if (!searchInput) {
        // Mature dialog-choice logic normally searches first. Some Phoenix taxonomy
        // pickers expose the exact leaf directly without a dedicated search box. In
        // that case we only accept an exact normalized text match; never choose a
        // fuzzy/first item from an unfiltered taxonomy tree.
        var exactVisible = findDialogChoiceCandidate(dialog, keyword);
        if (exactVisible && normalizeDialogChoiceText(exactVisible.textContent) === normalizeDialogChoiceText(keyword)) {
          await AF.DomUtils.safeClickElement(exactVisible);
          await AF.Utils.sleep(180);
          dialog = resolveLiveDialog(dialog);
          if (!dialog || !dialog.isConnected || !isVisibleDialogElement(dialog)) return { handled: true, success: true };
          var exactConfirm = Array.from(dialog.querySelectorAll("button, [role='button']")).find(function (button) {
            return isVisibleDialogElement(button) && /^(选择|确定|确认|完成|应用)$/.test(String(button.textContent || "").trim());
          });
          if (exactConfirm) {
            await AF.DomUtils.safeClickElement(exactConfirm);
            await AF.Utils.sleep(180);
            var exactLiveInput = resolveLiveInput();
            if (searchCommitMatches(keyword, String(exactLiveInput && exactLiveInput.value || ""))) return { handled: true, success: true };
          }
        }
        closeChoiceDialog(dialog);
        return { handled: true, success: false };
      }

      var option = null;
      var selectedKeyword = keyword;
      var initialCandidateSignature = dialogChoiceCandidates(dialog).map(function (node) {
        return normalizeDialogChoiceText(node.textContent);
      }).join("|");
      var keywords = [keyword].concat(Array.isArray(choiceHints.alternatives) ? choiceHints.alternatives : []).filter(function (item, index, all) {
        item = String(item || "").trim();
        return item && all.map(function (value) { return String(value || "").trim(); }).indexOf(item) === index;
      });

      // 学校与专业都必须先把名称输入弹窗搜索框，让站点建立真实搜索状态；
      // 即使未搜索的完整专业列表里碰巧已有同名项，也不能直接点击跳过输入。
      for (var keywordIndex = 0; !option && keywordIndex < keywords.length; keywordIndex++) {
        var currentKeyword = keywords[keywordIndex];
        var typedInPage = false;
        if (AF.SelectAdapter && typeof AF.SelectAdapter.typeSearchInputInPage === "function") {
          typedInPage = await AF.SelectAdapter.typeSearchInputInPage(searchInput, currentKeyword);
        }
        if (!typedInPage) await searchDialogInputData(searchInput, currentKeyword);

        // 弹窗搜索通常带有 debounce + 远程请求（部分站点需要 2~4 秒）。
        for (var optionWait = 0; optionWait < 60; optionWait++) {
          await AF.Utils.sleep(100);
          dialog = resolveLiveDialog(dialog);
          if (!searchInput.isConnected && dialog) {
            searchInput = Array.from(dialog.querySelectorAll("input[type='text'], input[type='search'], input:not([type])")).find(function (candidate) {
              return isVisibleDialogElement(candidate) && !candidate.disabled && !candidate.readOnly &&
                String(candidate.placeholder || "").trim() === String(searchInput.placeholder || "").trim();
            }) || searchInput;
          }
          var waitingCandidateSignature = dialogChoiceCandidates(dialog).map(function (node) {
            return normalizeDialogChoiceText(node.textContent);
          }).join("|");
          var searchValueReady = normalizeDialogChoiceText(searchInput && searchInput.value) === normalizeDialogChoiceText(currentKeyword);
          var searchResultsReady = waitingCandidateSignature && waitingCandidateSignature !== initialCandidateSignature;
          // 输入框表面出现文字并不代表 React 搜索已生效。必须等候默认完整列表
          // 真正刷新成搜索结果，才允许点候选，避免专业列表尚未过滤时提前误点。
          option = searchValueReady && searchResultsReady ? findDialogChoiceCandidate(dialog, currentKeyword) : null;
          if (option) {
            selectedKeyword = currentKeyword;
            break;
          }
        }
        // 学校名称通常很精确；若接口做了近似检索但没有完全包含关系，
        // 选择搜索结果中的第一项作为最近候选，不在无搜索结果时盲选。
        if (!option && choiceHints.allowFirstResult) {
          var currentSearchValue = String(searchInput && searchInput.value || "").trim();
          var currentCandidateSignature = dialogChoiceCandidates(dialog).map(function (node) {
            return normalizeDialogChoiceText(node.textContent);
          }).join("|");
          // 只有输入值真实进入受控组件、且默认省份学校列表已经刷新为搜索结果，
          // 才允许用第一条作近似兜底；否则宁可不填，也不能误选默认列表第一项。
          if (normalizeDialogChoiceText(currentSearchValue) === normalizeDialogChoiceText(currentKeyword) &&
              currentCandidateSignature && currentCandidateSignature !== initialCandidateSignature) {
            option = findFirstDialogChoiceCandidate(dialog);
            if (option) selectedKeyword = String(option.textContent || "").trim() || currentKeyword;
          }
        }
      }
      if (!option) {
        closeChoiceDialog(dialog);
        return { handled: true, success: false };
      }

      var clickedInPage = false;
      // 此站学校/专业候选本身就是 React 点击目标，直接 click 最稳定；Ant
      // Select 的主页面桥接仍保留给其他通用选项。
      if (option.matches && option.matches(".school-item, .subject-item")) {
        option.click();
        clickedInPage = true;
      } else if (AF.SelectAdapter && typeof AF.SelectAdapter.clickOptionInPage === "function") {
        clickedInPage = await AF.SelectAdapter.clickOptionInPage(option, searchInput, selectedKeyword);
      }
      if (!clickedInPage) await AF.DomUtils.safeClickElement(option);
      await AF.Utils.sleep(260);
      dialog = resolveLiveDialog(dialog);
      var liveAfterOption = resolveLiveInput();
      var valueAfterOption = String(liveAfterOption && liveAfterOption.value || "").trim();
      if (!dialog || !dialog.isConnected || !isVisibleDialogElement(dialog)) {
        if (valueAfterOption && valueAfterOption !== beforeValue) return { handled: true, success: true };
      }
      dialog = resolveLiveDialog(dialog);
      if (!dialog || !dialog.isConnected || !isVisibleDialogElement(dialog)) {
        return { handled: true, success: false };
      }
      var confirm = Array.from(dialog.querySelectorAll("button, [role='button']")).find(function (button) {
        return isVisibleDialogElement(button) && /^(选择|确定|确认|完成|应用)$/.test(String(button.textContent || "").trim());
      });
      if (!confirm) {
        closeChoiceDialog(dialog);
        return { handled: true, success: false };
      }
      await AF.DomUtils.safeClickElement(confirm);

      for (var verifyWait = 0; verifyWait < 30; verifyWait++) {
        await AF.Utils.sleep(100);
        var liveInput = resolveLiveInput();
        var committed = String(liveInput && liveInput.value || "").trim();
        var normalizedCommitted = normalizeDialogChoiceText(committed);
        var normalizedKeyword = normalizeDialogChoiceText(selectedKeyword);
        var matchesKeyword = normalizedCommitted && normalizedKeyword && (
          normalizedCommitted === normalizedKeyword ||
          normalizedCommitted.indexOf(normalizedKeyword) !== -1 ||
          normalizedKeyword.indexOf(normalizedCommitted) !== -1
        );
        if (matchesKeyword || (committed && committed !== beforeValue)) {
          return { handled: true, success: true };
        }
      }
      closeChoiceDialog(dialog);
      return { handled: true, success: false };
    } catch (e) {
      return { handled: false, success: false };
    }
  }

  // Public, safety-scoped bridge for mature platform adapters. This exposes only
  // the existing search/dialog choice routine; it does not add/save/submit anything.
  AF.FormHandler.tryFillDialogChoice = async function (element, value, choiceHints) {
    try {
      var input = element && element.tagName && element.tagName.toLowerCase() === "input"
        ? element
        : element && element.querySelector && element.querySelector("input");
      var keyword = value && typeof value === "object" ? value.name || value.label || value.text || "" : String(value == null ? "" : value);
      if (!input || !keyword) return { handled: false, success: false };
      return await tryFillDialogChoice(element, input, keyword, choiceHints || {});
    } catch (e) {
      return { handled: false, success: false };
    }
  };

  // ---------- handleSearchInput (源码 SearchInputHandler 完整主链路) ----------
  async function handleSearchInput(element, value, capabilityContext) {
    if (!element || value === null || value === undefined) return false;
    var input = null;
    try {
      input = element.tagName && element.tagName.toLowerCase() === "input" ? element : element.querySelector("input");
      var keyword = typeof value === "object" ? value.name || value.label || value.text || "" : String(value);
      var choiceHints = typeof value === "object" && value.dialogChoice || {};
      if (!keyword) return false;

      if (!input) return false;
      var hotjobChoice = await tryFillHotjobSchoolSubject(element, keyword);
      if (hotjobChoice.handled) return hotjobChoice.success;
      // 字段能力补丁明确指定了适配器时，必须优先走该适配器。否则可编辑的
      // 搜索框会先进入旧的通用候选扫描，配置的键盘事件/等待策略根本没有机会执行。
      if (capabilityContext && capabilityContext.capability && capabilityContext.capability.adapter && AF.SelectAdapter) {
        return await AF.SelectAdapter.create(
          element,
          typeof value === "object" ? "object" : "string",
          null,
          null,
          capabilityContext
        ).selectValue(value);
      }
      if (input.disabled || input.readOnly) {
        return AF.SelectAdapter
          ? await AF.SelectAdapter.create(element, typeof value === "object" ? "object" : "string", null, null, capabilityContext).selectValue(value)
          : false;
      }

      var dialogChoice = await tryFillDialogChoice(element, input, keyword, choiceHints);
      if (dialogChoice.handled) return dialogChoice.success;

      var isMoka = /(^|\.)mokahr\.com$/i.test(String(location.hostname || ""));
      var attempts = isMoka ? 2 : 1;
      for (var attempt = 0; attempt < attempts; attempt++) {
        await searchInputData(input, keyword, false);
        var searchWaitMs = capabilityContext && capabilityContext.capability && Number(capabilityContext.capability.waitForOptionsMs);
        var option = await monitorSearchOptionsAppearance(keyword, searchWaitMs > 0 ? searchWaitMs : (isMoka ? 1600 : 1000));
        if (!option) break;
        await clickSearchOptionLeaf(option);
        await AF.Utils.sleep(isMoka ? 560 : 120);

        // Moka 是 React 受控下拉：点到候选项不等于数据已经提交。
        // 必须以 sd-Input-display-value 为准；未稳定写入时再完整搜索选择一次。
        if (!isMoka || !element.isConnected || searchCommitMatches(keyword, readCommittedSearchValue(element, input))) {
          return true;
        }
      }
      setSearchInputValue(input, "");
      input.dispatchEvent(new Event("input", { bubbles: true }));
      return AF.SelectAdapter
        ? await AF.SelectAdapter.create(element, typeof value === "object" ? "object" : "string", null, null, capabilityContext).selectValue(value)
        : false;
    } catch (err) {
      console.warn("[AF.FormHandler] handleSearchInput 失败:", err);
      return false;
    } finally {
      try { document.body.click(); } catch (e) {}
      await AF.Utils.sleep(100);
    }
  }

  // ---------- handleMultiSelect (源码行55503-55545，简化为通用"逐个搜索+点击") ----------
  // 注: 源码真实逻辑绝大部分是路由到 Bitable/Phoenix 两套站点专属的多选触发器，
  // 通用兜底分支甚至只取数组第一个值扔给 handleSelect，并不会真正遍历多选。
  // 本文件按任务书要求实现一个更通用、更"多选"的版本：打开面板 → 依次搜索勾选每个
  // 值 → 关闭面板，这样才能覆盖 Bitable/Phoenix 之外的常见 UI 框架多选控件。
  async function handleMultiSelect(element, value, capabilityContext) {
    if (!element || value === null || value === undefined) return false;
    var values = (Array.isArray(value) ? value : [value]).filter(function (v) {
      return v !== null && v !== undefined && String(v).trim() !== "";
    });
    if (!values.length) return false;

    try {
      var capability = capabilityContext && capabilityContext.capability || null;
      var matchMode = String(capability && capability.matchMode || "");
      var optionWaitMs = Math.max(100, Number(capability && capability.waitForOptionsMs || 2000));
      await AF.DomUtils.enhancedClick(element); // 打开多选面板

      var clickedAny = false;
      for (var i = 0; i < values.length; i++) {
        var target = String(values[i]);
        var option = await AF.Utils.waitForElement(function () {
          var nodes = document.querySelectorAll(GENERIC_DROPDOWN_OPTION_SELECTORS.join(","));
          for (var j = 0; j < nodes.length; j++) {
            var text = (nodes[j].textContent || "").trim();
            if (!text) continue;
            var alreadySelected =
              nodes[j].getAttribute("aria-selected") === "true" ||
              nodes[j].classList.contains("is-selected") ||
              /selected/i.test(nodes[j].className || "");
            if (alreadySelected) continue;
            var matchesOption = text === target;
            if (!matchesOption && matchMode !== "exact") matchesOption = text.includes(target) || target.includes(text);
            if (!matchesOption && !matchMode) matchesOption = AF.DomUtils.isSimilarText(text, target);
            if (matchesOption) {
              return nodes[j];
            }
          }
          return null;
        }, optionWaitMs);

        if (option) {
          await AF.DomUtils.safeClickElement(option);
          clickedAny = true;
          await AF.Utils.sleep(150); // 部分多选面板选中后会重新渲染，稍等再选下一个
        }
      }

      // 关闭面板 (点击空白处，模拟原逻辑里各适配器"选完关闭下拉"的收尾动作)
      document.body.click();
      await AF.Utils.sleep(100);
      return clickedAny;
    } catch (err) {
      console.warn("[AF.FormHandler] handleMultiSelect 失败:", err);
      return false;
    }
  }

  // ---------- handleContentEditable (源码行54661-54740，简化版) ----------
  // 注: 源码里还有 isBitableEditor/handleBitableEditor/dispatchPaste/insertTextByCommand/
  // writeTextFallback 等一整套子方法，本文件按任务书指引实现精简但等价的版本：
  // focus → 全选清空 → execCommand insertText → 不行就直接写 textContent → 派发事件。
  async function handleContentEditable(element, value, capabilityContext) {
    if (!element || value === null || value === undefined) return false;
    var text = String(value).trim();
    if (!text) return false;
    try {
      var target =
        element.getAttribute && element.getAttribute("contenteditable") != null
          ? element
          : element.querySelector('[contenteditable="true"], [contenteditable=""]') || element;

      await AF.DomUtils.safeClickElement(target);
      target.focus();
      await AF.Utils.sleep(100);

      var shouldAppend = !!(capabilityContext && capabilityContext.appendText);
      var previousText = String(target.textContent || "");
      var nextText = shouldAppend ? appendTagText(previousText, text) : text;
      var insertedText = shouldAppend ? nextText.slice(previousText.length) : text;

      // 标签填入长文本时把光标移动到末尾；普通填充仍然覆盖旧内容。
      try {
        var selection = window.getSelection();
        var range = document.createRange();
        if (shouldAppend) range.selectNodeContents(target), range.collapse(false);
        else range.selectNodeContents(target);
        selection.removeAllRanges();
        selection.addRange(range);
      } catch (e) {}

      var inserted = false;
      try {
        inserted = document.execCommand("insertText", false, insertedText);
      } catch (e) {
        inserted = false;
      }
      if (!inserted || String(target.textContent || "") !== nextText) {
        target.textContent = nextText; // execCommand 不可用时的兜底
      }

      target.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
      target.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      await AF.Utils.sleep(100);
      target.blur();
      target.dispatchEvent(new Event("blur", { bubbles: true, composed: true }));

      return String(target.textContent || "") === nextText;
    } catch (err) {
      console.warn("[AF.FormHandler] handleContentEditable 失败:", err);
      return false;
    }
  }

  // ---------- fillFormElement 静态分发 (源码行56136-56200) ----------
  function isUploadTarget(element) {
    var nodes = element && typeof element.length === "number" && !element.tagName
      ? Array.from(element)
      : [element];
    return nodes.some(function (node) {
      if (!(node instanceof Element)) return false;
      if (node.matches('input[type="file"]')) return true;
      var action = node.closest && node.closest("button, label, a, [role='button'], [onclick], [class*='button' i], [class*='btn' i]");
      var actionText = String([
        action && action.textContent,
        action && action.getAttribute && action.getAttribute("aria-label"),
        action && action.getAttribute && action.getAttribute("title"),
      ].filter(Boolean).join(" ")).replace(/\s+/g, "");
      if (/上传|附件|选择文件|照片|证件照|生活照|upload|attachment|choose\s*file/i.test(actionText)) return true;
      var current = node;
      for (var depth = 0; current && depth < 4; depth++) {
        var cls = String(current.className || "").toLowerCase();
        var roleText = [current.getAttribute("aria-label"), current.getAttribute("title")].filter(Boolean).join(" ");
        if (/upload|attachment|file[_-]?picker|portrait[_-]?upload/.test(cls)) return true;
        if (/上传|附件|upload|attachment/i.test(roleText)) return true;
        if (depth < 2 && current.querySelector && current.querySelector('input[type="file"]')) return true;
        current = current.parentElement;
      }
      return false;
    });
  }

  function parseYearMonthParts(value) {
    var text = String(value || "").trim();
    var match = text.match(/(\d{4})\D+(\d{1,2})/);
    if (!match) return null;
    return { year: match[1], month: String(parseInt(match[2], 10)) };
  }

  function splitDateValues(value) {
    if (!value) return null;
    if (typeof value === "object") {
      var start = parseYearMonthParts(value.startTime);
      var end = parseYearMonthParts(value.endTime);
      return { start: start, end: end, current: AF.CurrentEndDate && AF.CurrentEndDate.isCurrentValue && AF.CurrentEndDate.isCurrentValue(value.endTime) };
    }
    var text = String(value || "");
    var parts = text.split("~");
    return { start: parseYearMonthParts(parts[0]), end: parseYearMonthParts(parts[1]), current: /至今|目前|现在|当前/.test(text) };
  }

  function nearestYearMonthScope(element) {
    try {
      var range = element && element.closest && element.closest(".month-range-select.date_info, .month-range-select, .date_info");
      if (range && range.querySelectorAll) {
        var sdControls = range.querySelectorAll('[class^="sd-Dropdown-container"], [class*=" sd-Dropdown-container"]');
        if (sdControls.length >= 2) return range;
        var rangeInputs = Array.from(range.querySelectorAll("input")).filter(function (input) {
          var hint = String([input.placeholder, input.name, input.id, input.getAttribute("aria-label")].filter(Boolean).join(" "));
          return AF.DomUtils.isElementVisible(input) && /(年|月|year|month)/i.test(hint);
        });
        if (rangeInputs.length >= 2) return range;
      }
    } catch (e) {}
    var cur = element;
    for (var depth = 0; cur && depth < 8; depth++) {
      if (cur.querySelectorAll) {
        var isDateLikeScope = cur.matches && cur.matches(".month-range-select, .date_info, [class*='date_info']");
        var sdControls = cur.querySelectorAll('[class^="sd-Dropdown-container"], [class*=" sd-Dropdown-container"]');
        if (sdControls.length >= 2 && sdControls.length <= 6 && isDateLikeScope) return cur;
        var inputs = Array.from(cur.querySelectorAll("input")).filter(function (input) {
          var hint = String([input.placeholder, input.name, input.id, input.getAttribute("aria-label")].filter(Boolean).join(" "));
          return AF.DomUtils.isElementVisible(input) && /(年|月|year|month)/i.test(hint);
        });
        if (inputs.length >= 2 && inputs.length <= 6 && isDateLikeScope) return cur;
      }
      cur = cur.parentElement;
    }
    return null;
  }

  async function setInputValue(input, value) {
    if (!input || value == null || value === "") return false;
    input.focus && input.focus();
    try {
      var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      if (setter) setter.call(input, String(value));
      else input.value = String(value);
    } catch (e) {
      input.value = String(value);
    }
    input.setAttribute && input.setAttribute("value", String(value));
    input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    input.dispatchEvent(new Event("blur", { bubbles: true, composed: true }));
    await AF.Utils.sleep(60);
    return String(input.value || "").indexOf(String(value)) !== -1;
  }

  function toMonthValue(value) {
    var match = String(value || "").match(/(\d{4})[-\/.年](\d{1,2})/);
    if (!match) return String(value || "");
    return match[1] + "-" + String(parseInt(match[2], 10)).padStart(2, "0");
  }

  async function commitNextDateInput(input) {
    try {
      input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
      input.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
      input.dispatchEvent(new Event("blur", { bubbles: true, composed: true }));
      await AF.Utils.sleep(80);
    } catch (e) {}
  }

  async function tryFillNextDateRangeInputs(element, value) {
    try {
      if (!value || typeof value !== "object" || !value.startTime || !value.endTime) return false;
      var range = element && element.closest && element.closest(".next-range-picker");
      if (!range || !range.querySelectorAll) return false;
      function visibleInputs(root) {
        return Array.from((root || range).querySelectorAll("input")).filter(function (input) {
          return AF.DomUtils.isElementVisible(input);
        });
      }
      function openedPanel() {
        return Array.from(document.querySelectorAll(
          ".next-overlay-wrapper.opened .next-range-picker-body, " +
          ".next-overlay-wrapper .next-range-picker-body[aria-hidden='false'], " +
          ".next-range-picker-body"
        )).filter(function (node) {
          return AF.DomUtils.isElementVisible(node);
        })[0] || null;
      }
      async function waitPanel() {
        var found = null;
        for (var wait = 0; wait < 12; wait++) {
          found = openedPanel();
          if (found) break;
          await AF.Utils.sleep(120);
        }
        return found;
      }

      var startValue = toMonthValue(value.startTime);
      var endValue = AF.CurrentEndDate && AF.CurrentEndDate.isCurrentValue && AF.CurrentEndDate.isCurrentValue(value.endTime)
        ? toMonthValue(todayDateString())
        : toMonthValue(value.endTime);
      var triggerInputs = visibleInputs(range);
      if (triggerInputs.length < 2) return false;

      await AF.DomUtils.safeClickElement(triggerInputs[0]);
      await AF.Utils.sleep(180);
      var panel = await waitPanel();
      var panelInputs = panel ? visibleInputs(panel) : [];
      var startInput = panelInputs[0] || triggerInputs[0];
      var okStart = await setInputValue(startInput, startValue);
      await commitNextDateInput(startInput);

      triggerInputs = visibleInputs(range);
      if (triggerInputs.length < 2) return false;
      await AF.DomUtils.safeClickElement(triggerInputs[1]);
      await AF.Utils.sleep(180);
      panel = openedPanel() || await waitPanel();
      panelInputs = panel ? visibleInputs(panel) : [];
      var endInput = panelInputs[1] || panelInputs[0] || triggerInputs[1];
      var okEnd = await setInputValue(endInput, endValue);
      await commitNextDateInput(endInput);
      if (panel) {
        var confirm = Array.from(panel.querySelectorAll("button")).filter(function (button) {
          var text = String(button.textContent || button.getAttribute("title") || "").replace(/\s+/g, "").trim();
          return /^(确定|OK)$/i.test(text) && !button.disabled && !(button.hasAttribute && button.hasAttribute("disabled"));
        })[0];
        if (confirm) {
          await AF.DomUtils.safeClickElement(confirm);
          await AF.Utils.sleep(180);
        }
      }
      triggerInputs = visibleInputs(range);
      var displayedStart = triggerInputs[0] && String(triggerInputs[0].value || "");
      var displayedEnd = triggerInputs[1] && String(triggerInputs[1].value || "");
      return !!(
        okStart &&
        okEnd &&
        displayedStart.indexOf(startValue) !== -1 &&
        displayedEnd.indexOf(endValue) !== -1
      );
    } catch (e) {
      return false;
    }
  }

  async function tryFillSplitYearMonthInputs(element, value) {
    try {
      var parsed = splitDateValues(value);
      if (!parsed || !parsed.start) return false;
      var scope = nearestYearMonthScope(element);
      if (!scope) return false;
      var inputs = Array.from(scope.querySelectorAll("input")).filter(function (input) {
        var hint = String([input.placeholder, input.name, input.id, input.getAttribute("aria-label")].filter(Boolean).join(" "));
        return AF.DomUtils.isElementVisible(input) && /(年|月|year|month)/i.test(hint);
      });
      if (inputs.length < 2 && scope.matches && scope.matches(".month-range-select, .date_info, [class*='date_info']")) {
        inputs = Array.from(scope.querySelectorAll("[class^='sd-Dropdown-container'] input, [class*=' sd-Dropdown-container'] input")).filter(function (input) {
          return AF.DomUtils.isElementVisible(input);
        });
      }
      if (inputs.length < 2) return false;
      var values = [parsed.start.year, parsed.start.month];
      if (parsed.end) values.push(parsed.end.year, parsed.end.month);
      var ok = true;
      for (var i = 0; i < inputs.length && i < values.length; i++) {
        ok = (await setInputValue(inputs[i], values[i])) && ok;
      }
      if (parsed.current) {
        await trySelectCurrentEndControl(null, element);
      }
      return ok;
    } catch (e) {
      return false;
    }
  }

  function nearestDateRangeInputScope(element) {
    if (!element || !element.closest) return null;
    var selectors = [
      ".ant-form-item",
      ".el-form-item",
      ".pt-l",
      ".pt-r",
      "[class*='form-item' i]",
      "[role='group']",
      "fieldset"
    ];
    var scopes = [];
    var current = element;
    for (var depth = 0; current && depth < 6; depth++, current = current.parentElement) {
      if (scopes.indexOf(current) === -1) scopes.push(current);
    }
    for (var selectorIndex = 0; selectorIndex < selectors.length; selectorIndex++) {
      var matchedScope = element.closest(selectors[selectorIndex]);
      if (matchedScope && scopes.indexOf(matchedScope) === -1) scopes.push(matchedScope);
    }
    for (var i = 0; i < scopes.length; i++) {
      try {
        var scope = scopes[i];
        if (!scope || !scope.querySelectorAll) continue;
        var inputs = Array.from(scope.querySelectorAll("input")).filter(function (input) {
          if (!AF.DomUtils.isElementVisible(input)) return false;
          var hint = String([
            input.type,
            input.placeholder,
            input.name,
            input.id,
            input.getAttribute("aria-label")
          ].filter(Boolean).join(" "));
          return /(date|time|日期|时间|选择|year|month)/i.test(hint) ||
            input.classList.contains("mdf-cal") ||
            !!(input.closest && input.closest(".date-ipt"));
        });
        if (inputs.length >= 2 && inputs.length <= 4) return { scope: scope, inputs: inputs };
      } catch (e) {}
    }
    return null;
  }

  async function tryFillGenericDateRangeInputs(element, value) {
    try {
      if (!value || typeof value !== "object" || !value.startTime || !value.endTime) return false;
      var found = nearestDateRangeInputScope(element);
      if (!found || !found.inputs || found.inputs.length < 2) return false;
      var inputs = found.inputs;
      var startInput = inputs[0];
      var endInput = inputs[1];
      var okStart = await setInputValue(startInput, value.startTime);
      var okEnd = true;
      if (AF.CurrentEndDate && AF.CurrentEndDate.isCurrentValue && AF.CurrentEndDate.isCurrentValue(value.endTime)) {
        okEnd = await trySelectCurrentEndControl(null, endInput);
        if (!okEnd) okEnd = await setInputValue(endInput, todayDateString());
      } else {
        okEnd = await setInputValue(endInput, value.endTime);
      }
      if (!okStart || !okEnd) return false;
      return (await verifyDateRangeReadback(element, value)).success;
    } catch (e) {
      return false;
    }
  }

  async function tryFillCpoPhone(element, value) {
    try {
      var box = element && element.closest && element.closest(".cpo-phone-select");
      if (!box || value === null || value === undefined) return false;
      var text = String(value || "").replace(/[^\d+]/g, "");
      var digits = text.replace(/\D/g, "");
      if (digits.indexOf("86") === 0 && digits.length > 11) digits = digits.slice(2);
      if (digits.length > 11) digits = digits.slice(-11);
      var country = box.querySelector(".cpo-phone-select-inner");
      var countryText = String((country && country.textContent) || "");
      if (country && countryText.indexOf("+86") === -1 && AF.SelectAdapter) {
        await AF.SelectAdapter.create(country, "string").selectValue("+86");
        await AF.Utils.sleep(120);
      }
      var input = box.querySelector(".cpo-phone-select-number input");
      if (!input || !digits) return false;
      return await setInputValue(input, digits);
    } catch (e) {
      return false;
    }
  }

  AF.FormHandler.fillFormElement = async function (element, value, type, capabilityContext) {
    var traceToken = AF.FillTrace && element ? AF.FillTrace.beginField(element) : null;
    var result = false;
    try {
      var capability = capabilityContext && capabilityContext.capability;
      if (capability && capability.fillType) type = capability.fillType;
      type = normalizeElementType(type);
      if (!element || value === null || value === undefined || !type) {
        if (AF.FillTrace && traceToken) AF.FillTrace.completeField(traceToken, element, false, type);
        return false;
      }
      // Uploads are always manual. This guard applies to every fill mode.
      if (isUploadTarget(element)) {
        if (AF.FillTrace && traceToken) AF.FillTrace.completeField(traceToken, element, false, type, "manual_upload");
        return false;
      }
      if (typeof value === "string") value = value.trim();
      if (capability && AF.CapabilityPatch && typeof AF.CapabilityPatch.transformValue === "function") {
        value = AF.CapabilityPatch.transformValue(value, capability);
        if (AF.FillTrace && capabilityContext) {
          AF.FillTrace.setFieldContext({
            category: capabilityContext.category,
            label: capabilityContext.labelText,
            fieldKey: capabilityContext.fieldKey,
            plannedValue: value,
          });
        }
      }
      if (element && element.closest && element.closest(".cpo-phone-select")) {
        result = await tryFillCpoPhone(element, value);
        if (AF.FillTrace && traceToken) AF.FillTrace.completeField(traceToken, element, result, type);
        return result;
      }
      // 中国电信的学校名称外观是普通 text，但实际上必须更新 Angular 模型并
      // 从联想列表选择。不能依赖 AI 配置把它识别成 search。
      if (isHotjobSchoolField(element)) {
        var hotjobSchoolKeyword = typeof value === "object"
          ? value.name || value.label || value.text || value.value || ""
          : String(value || "");
        var hotjobSchoolChoice = await tryFillHotjobSchoolSubject(element, String(hotjobSchoolKeyword || ""));
        result = hotjobSchoolChoice.handled && hotjobSchoolChoice.success;
        if (AF.FillTrace && traceToken) AF.FillTrace.completeField(traceToken, element, result, "search");
        return result;
      }
      // 建行旧版控件统一带 search_selector，但普通下拉的唯一 input 实际是隐藏的
      // edit_field_value。若按 search 路由，会把隐藏值承载框误当搜索框；这些组件
      // 必须统一交给已识别其 select_box/multi_select_box 结构的 SelectAdapter。
      if (
        element instanceof Element &&
        /^(search|select|multiSelect)$/i.test(String(type || "")) &&
        (
          element.matches(".select_box, .multi_select_box") ||
          (element.closest && element.closest(".select_box, .multi_select_box"))
        )
      ) {
        type = "select";
      }
      var preserveChoiceAdapterForDateLike = !!(
        capability && capability.forceAdapter === true && capability.adapter &&
        (capability.preserveDateLikeSelect === true || /^(select|search)$/i.test(String(capability.fillType || "")))
      );
      if (
        AF.DomUtils.isDateValue && AF.DomUtils.isDateValue(value) &&
        !/^(radio|checkbox|multiSelect)$/i.test(String(type || "")) &&
        !preserveChoiceAdapterForDateLike
      ) {
        type = "date";
      }
      if (type === "date" && capability && AF.CapabilityPatch && AF.CapabilityPatch.transformDateValue) {
        value = AF.CapabilityPatch.transformDateValue(value, capability);
      }

      if (
        (type === "search" || type === "select") &&
        element instanceof Element &&
        element.closest &&
        element.closest(".cascader-plugins-wrap") &&
        typeof value === "string"
      ) {
        result = await fillProvinceCityPair(element, value);
        if (AF.FillTrace && traceToken) AF.FillTrace.completeField(traceToken, element, result, type);
        return result;
      }

      switch (type) {
        case "longText":
          result = await handleLongText(element, value, capabilityContext);
          break;
        case "radio":
          result = await handleRadio(element, value, capabilityContext);
          break;
        case "checkbox":
          result = await handleCheckbox(element, value, capabilityContext);
          break;
        case "select":
          // select 的开合/查找/点击完全交给 SelectAdapter 模块 (另一 agent 实现)
          result = await AF.SelectAdapter.create(element, typeof value === "object" ? "object" : "string", null, null, capabilityContext).selectValue(
            value
          );
          break;
        case "multiSelect":
          result = await handleMultiSelect(element, value, capabilityContext);
          break;
        case "date":
          // 日期面板的打开/翻月/点击完全交给 DatePicker 模块 (另一 agent 实现)
          if (typeof value === "string" && /^(至今|现在|当前|present|current)$/i.test(value)) {
            result = await trySelectCurrentEndControl(null, element);
            if (result) break;
          }
          var hotjobDate = await tryFillHotjobDayType(element, value);
          if (hotjobDate.handled) {
            // 中国电信日期器一旦接管，无论成功与否都不能再交给通用日期器。
            // 通用日期器不认识该 Bootstrap 面板，会误点当天日期。
            result = hotjobDate.success;
          } else {
            var dateExecutionPath = "";
            var isRangeValue = typeof value === "object";
            var detectedDateAdapter = (capability && (capability.dateAdapter || capability.adapter)) || (AF.DatePicker && AF.DatePicker.detectType && AF.DatePicker.detectType(element));
            // 腾讯等受控组件的字段能力明确要求 adapter 优先：generic setter
            // 只能在没有已知 adapter、或 adapter 已确认失败后才尝试。
            if (isRangeValue && capability && capability.preferAdapter === true && detectedDateAdapter) {
              result = await AF.DatePicker.create(element, "object", capabilityContext).setValue(value);
              dateExecutionPath = "adapter";
            }
            if (!result && isRangeValue) {
              result = await tryFillNextDateRangeInputs(element, value);
              if (result) dateExecutionPath = "next_adapter";
            }
            if (!result && isRangeValue) {
              result = await tryFillGenericDateRangeInputs(element, value);
              if (result) dateExecutionPath = "generic_readback";
            }
            if (!result) {
              result = await AF.DatePicker.create(element, isRangeValue ? "object" : "string", capabilityContext).setValue(value);
              if (result) dateExecutionPath = "adapter";
            }
            if (!result && isRangeValue) {
              result = await tryFillGenericDateRangeInputs(element, value);
              if (result) dateExecutionPath = "generic_readback";
            }
            if (!result) result = await tryFillSplitYearMonthInputs(element, value);
            if (isRangeValue) {
              var dateVerification = await verifyDateRangeReadback(element, value);
              result = !!result && dateVerification.success;
              recordDateDebug(capabilityContext, element, dateExecutionPath || "failed", dateVerification);
            }
          }
          break;
        case "search":
          // The original product routes every search field through
          // SearchInputHandler first, including Moka sd school/major selects.
          result = await handleSearchInput(element, value, capabilityContext);
          break;
        case "contentEditable":
          result = await handleContentEditable(element, value, capabilityContext);
          break;
        default:
          result = await handleText(element, value, capabilityContext);
          break;
      }
      if (!result && /^(search|select|multiSelect)$/i.test(String(type || "")) && AF.FillTrace && AF.FillTrace.readElementValue) {
        try {
          result = matches(value, AF.FillTrace.readElementValue(element));
        } catch (e) {}
      }
      var isMokaControlledChoice = /mokahr\.com$/i.test(String(location.hostname || "")) && /^(search|select|multiSelect)$/i.test(String(type || ""));
      await AF.Utils.sleep(isMokaControlledChoice ? 420 : 80);
      if (AF.FillTrace && traceToken) AF.FillTrace.completeField(traceToken, element, result, type);
      return result;
    } catch (err) {
      console.warn("[AF.FormHandler] fillFormElement 失败:", err);
      if (AF.FillTrace && traceToken) AF.FillTrace.completeField(traceToken, element, false, type);
      return false;
    }
  };
})();
