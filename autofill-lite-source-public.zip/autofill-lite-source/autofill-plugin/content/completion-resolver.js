// Build154 revised Completion Resolver.
// Separates execution completion from harmless diagnostic reconciliation noise.
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  if (AF.CompletionResolver) return;

  function resolve(input) {
    var x = input || {};
    var unhandled = Array.isArray(x.unhandledFields) ? x.unhandledFields : [];
    var hasOnlyReconciliation = unhandled.length > 0 &&
      unhandled.every(function (item) {
        return String(item && item.reason || "") === "core_count_reconciliation";
      });
    var noFailureContext = !x.failureContext;
    var checkpointsResolved = x.resumedFromRecoveryCheckpoint === true && x.recoveryCheckpointResolved === true;
    var failedCount = Number(x.failedCount || 0);

    if (noFailureContext && checkpointsResolved && failedCount === 0 && hasOnlyReconciliation && !x.manualActionRequired && !x.stopped) {
      return {
        status: "complete",
        resolved: true,
        reason: "resolved_recovery_reconciliation_only"
      };
    }

    if (x.manualActionRequired) {
      return {
        status: "waiting_manual",
        resolved: false,
        reason: "manual_action_required"
      };
    }

    return {
      status: String(x.status || "unknown"),
      resolved: false,
      reason: "unchanged"
    };
  }

  AF.CompletionResolver = { resolve: resolve };
})();
