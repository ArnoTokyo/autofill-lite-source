"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

// Load the browser-side private special-site registry in the Node realm.  The
// page guard used by the PSBC entry is simply body, so a tiny DOM stub is enough
// to exercise URL routing without pretending to run the actual browser workflow.
global.window = { AF: {} };
global.document = {
  body: { innerText: "", textContent: "", querySelectorAll() { return []; } },
  querySelector(selector) { return selector === "body" ? {} : null; },
  querySelectorAll() { return []; },
};

const file = path.join(__dirname, "..", "autofill-plugin", "private", "private-special-sites.js");
new Function(fs.readFileSync(file, "utf8"))();

const currentUrl = "https://xiaoyuan.zhaopin.com/scrd/resume2?cid=10138584&pid=771924&projectId=";
const workflow = window.AF.PrivateSpecialSites.getWorkflowForUrl(currentUrl);
assert(workflow, "PSBC current URL should match a private workflow");
assert.strictEqual(workflow.id, "zhaopin-psbc-campus-resume-v1");

const education = (workflow.steps || []).find((step) => step && step.name === "教育经历");
assert(education, "PSBC workflow should include education step");
const dateItems = (education.fieldSequence || []).filter((item) => item && item.type === "elementDate");
assert(dateItems.some((item) => item.field === "startTime"), "education step should fill startTime through elementDate");
assert(dateItems.some((item) => item.field === "endTime"), "education step should fill endTime through elementDate");


const startDate = dateItems.find((item) => item.field === "startTime");
const endDate = dateItems.find((item) => item.field === "endTime");
assert.strictEqual(startDate.allowElementMonthPanel, true, "PSBC startTime must allow readonly Element month-panel fallback");
assert.strictEqual(endDate.allowElementMonthPanel, true, "PSBC endTime must allow readonly Element month-panel fallback");
assert.strictEqual(startDate.forceElementMonthPanel, true, "PSBC startTime must force month-panel handling when the control class is ambiguous");
assert.strictEqual(endDate.forceElementMonthPanel, true, "PSBC endTime must force month-panel handling when the control class is ambiguous");

console.log("zhaopin psbc route test: PASS");
