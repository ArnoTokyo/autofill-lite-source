"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const workflowSource = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-workflow.js"), "utf8");

const buildMatch = main.match(/const BUILD_ID = \"([^\"]+)-(\d+)\"/);
assert(buildMatch && Number(buildMatch[2]) >= 154, "A: Build154+ baseline required");
assert(main.includes("function resolveAutofillCompletionState"), "B: main-process completion resolver missing");
assert(main.includes('reason: "resolved_recovery_reconciliation_only"'), "B: reconciliation completion reason missing");
assert(main.includes('success: completionStatus'), "B: user-facing summary must receive normalized success state");
assert(main.includes('completionResolver: completionResolution'), "B: completion resolver diagnostic missing");

assert(workflowSource.includes("var recoveryResumeRecordLock = null"), "C: recovery record lock state missing");
assert(workflowSource.includes("__afRecoveryRecordLock"), "C: recovery lock not attached to subsequent repeat rows");
assert(workflowSource.includes("__afDisablePositionalRepeatRepair"), "C: positional repair barrier missing");
assert(workflowSource.includes("needs_review:repeat_recovery_record_identity_unresolved"), "C: ambiguous recovery identity must stop for review");
assert(workflowSource.includes("Array.isArray(dataDecision.rows) ? dataDecision.rows.length : rows.length"), "D: repeatTotal must remain full profile-plan count after recovery filtering");

// Load the public helper surface and verify the lock predicate itself.
global.HTMLElement = function(){};
global.Element = function(){};
global.document = {
  body: {},
  documentElement: { getAttribute() { return null; }, setAttribute() {}, removeAttribute() {}, hasAttribute() { return false; } },
  querySelectorAll() { return []; }, querySelector() { return null; }
};
global.window = {
  AF: {}, top: null,
  location: { hostname: "test", pathname: "/", href: "https://test/" },
  getComputedStyle() { return { display: "block", visibility: "visible", cursor: "default", zIndex: "0" }; },
  sessionStorage: { getItem() { return null; }, removeItem() {}, setItem() {} },
  postMessage() {}
};
window.top = window;
const realSetTimeout = global.setTimeout;
global.setTimeout = () => 0;
new Function(workflowSource)();
global.setTimeout = realSetTimeout;
const api = window.AF.SpecialSiteWorkflow._test;
assert.strictEqual(api.isZhaopinRecoveryRecordLock({}), false, "E: ordinary repeat step must not be locked");
assert.strictEqual(api.isZhaopinRecoveryRecordLock({ __afRecoveryRecordLock: { active: true } }), true, "E: acknowledged manual-record recovery must lock positional repair");

console.log("build154-completion-record-lock.test.js PASS");
