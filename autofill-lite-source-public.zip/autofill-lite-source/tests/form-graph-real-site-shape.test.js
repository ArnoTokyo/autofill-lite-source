"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");

// Generic fallback should be narrower than the mature v1 scanner. Mature platform/site
// assets take priority when available; broad block/item substring matching is only a
// fallback risk and must not fragment every Phoenix wrapper into its own section/row.
const graph = require(path.join(root, "autofill-plugin", "content", "form-graph.js"));
assert.strictEqual(graph.version, "1.3.0");
assert(!graph.constants.SECTION_CONTAINER_SELECTOR.includes("[class*='block']"), "generic block wrappers must not fragment FormGraph sections");
assert(!graph.constants.ROW_CONTAINER_SELECTOR.includes("[class*='item']"), "generic item/control wrappers must not become rows");
assert(!graph.constants.SECTION_CONTAINER_SELECTOR.includes(".form-part"), "Phoenix inner form-part must not own the whole module");
assert(graph.constants.ROW_CONTAINER_SELECTOR.includes(".form-item"), "Phoenix semantic form-item rows should be recognized");

// Geometry is deliberately a last-resort linker for the one gap the mature product did
// not have: Lite runs a static scanner and FormGraph side-by-side. When they represent
// the same widget at the same visible rectangle, linkage must remain deterministic.
global.location = { href: "https://example.test/form", hostname: "example.test", pathname: "/form" };
global.document = { body: null };
global.window = { AF: {}, getComputedStyle: () => ({}) };
const collectorPath = path.join(root, "autofill-plugin", "content", "site-analysis-collector.js");
delete require.cache[require.resolve(collectorPath)];
require(collectorPath);
const collector = global.window.AF.SiteAnalysisCollector;
const scan = {
  controlCount: 4,
  fields: [
    { label: "开始时间", controlType: "text", selectorHint: "input.nonunique", rect: { x: 420, y: 1300, width: 650, height: 26 } },
    { label: "开始时间", controlType: "text", selectorHint: "input.nonunique", rect: { x: 420, y: 1700, width: 650, height: 26 } },
    { label: "学校名称", controlType: "text", selectorHint: "input[placeholder=\"请输入\"]", rect: { x: 410, y: 1240, width: 690, height: 32 } },
    { label: "学校名称", controlType: "text", selectorHint: "input[placeholder=\"请输入\"]", rect: { x: 410, y: 1640, width: 690, height: 32 } }
  ]
};
const formGraph = {
  schemaType: "autofill-lite-form-graph",
  schemaVersion: 1,
  graphVersion: "1.3.0",
  totals: { sections: 2, rows: 4, controls: 4 },
  safety: { currentValuesIncluded: false, arbitraryRowTextIncluded: false, queryIncluded: false },
  controls: [
    { fieldId: "f1", selectorHint: ".widget-a", label: "开始时间", controlType: "custom-select", sectionId: "s1", rowId: "r1", rect: { x: 411, y: 1297, width: 695, height: 32 } },
    { fieldId: "f2", selectorHint: ".widget-b", label: "开始时间", controlType: "custom-select", sectionId: "s2", rowId: "r2", rect: { x: 411, y: 1697, width: 695, height: 32 } },
    { fieldId: "f3", selectorHint: ".widget-c", label: "学校名称", controlType: "text", sectionId: "s1", rowId: "r3", rect: { x: 407, y: 1237, width: 700, height: 38 } },
    { fieldId: "f4", selectorHint: ".widget-d", label: "学校名称", controlType: "text", sectionId: "s2", rowId: "r4", rect: { x: 407, y: 1637, width: 700, height: 38 } }
  ]
};
const coverage = collector.attachFormGraphContext(scan, formGraph);
assert.strictEqual(coverage.linkedStaticFieldCount, 4);
assert.strictEqual(coverage.linkedRatio, 1);
assert.strictEqual(coverage.linkMethods.logical_owner_geometry, 4);
assert.deepStrictEqual(scan.fields.map(x => x.graphFieldId), ["f1", "f2", "f3", "f4"]);

const renderer = fs.readFileSync(path.join(root, "renderer.js"), "utf8");
assert(renderer.includes("当前没有可见编辑控件"), "collapsed/read-only analyzer guidance missing");
console.log("form graph real-site shape regression: PASS");
