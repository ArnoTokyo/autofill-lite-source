"use strict";

function norm(value) {
  return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
}

function stableSelector(selector) {
  const text = String(selector || "").trim();
  if (!text || /[{};]/.test(text)) return false;
  // Analysis-owned selectors may legitimately contain nth-of-type.  Reject only
  // selectors whose meaning depends on transient active/selected state.
  if (/(?:^|[.\s:#\[])(?:on|active|selected|current|checked|is-active|is-selected|is-current)(?:$|[.\s:#\]])/i.test(text)) return false;
  return true;
}

function routeKeyFromUrl(rawUrl) {
  try {
    const u = new URL(String(rawUrl || ""));
    let pathname = String(u.pathname || "/").replace(/\/+/g, "/").replace(/\/$/, "").toLowerCase() || "/";
    return pathname.split("/").map((segment) => {
      if (/^\d{5,}$/.test(segment)) return ":id";
      if (/^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(segment)) return ":id";
      if (/^[a-z0-9_-]{32,}$/i.test(segment)) return ":token";
      return segment;
    }).join("/").slice(0, 255);
  } catch (_) {
    return "/";
  }
}

function latestUsefulSnapshot(bundle) {
  const snapshots = Array.isArray(bundle && bundle.snapshots) ? bundle.snapshots.slice().reverse() : [];
  return snapshots.find((snapshot) => {
    const graph = snapshot && snapshot.analysis && snapshot.analysis.formGraph;
    const coverage = snapshot && snapshot.analysis && snapshot.analysis.graphCoverage;
    return graph && Array.isArray(graph.sections) && graph.sections.length > 0 &&
      Number(graph.totals && graph.totals.controls || 0) > 0 &&
      Number(coverage && coverage.linkedRatio || 0) >= 0.7;
  }) || null;
}

function compileGraphStructureFromBundle(bundle, rawUrl) {
  const snapshot = latestUsefulSnapshot(bundle);
  if (!snapshot) return null;
  const analysis = snapshot.analysis || {};
  const graph = analysis.formGraph || {};
  const staticFields = analysis.staticScan && Array.isArray(analysis.staticScan.fields)
    ? analysis.staticScan.fields : [];
  const staticByRow = new Map();
  staticFields.forEach((field) => {
    const rowId = String(field && field.graphRowId || "");
    if (!rowId) return;
    const existing = staticByRow.get(rowId) || [];
    existing.push(field);
    staticByRow.set(rowId, existing);
  });

  const sections = [];
  let rowCount = 0;
  let controlCount = 0;
  (graph.sections || []).forEach((section) => {
    const selector = String(section && section.selectorHint || "").trim();
    const title = norm(section && section.title);
    if (!selector || !title || !stableSelector(selector)) return;
    const rows = [];
    (section.rows || []).forEach((row) => {
      const rowSelector = String(row && row.selectorHint || "").trim();
      if (!rowSelector || !stableSelector(rowSelector)) return;
      const staticMatches = staticByRow.get(String(row && row.rowId || "")) || [];
      const bestStatic = staticMatches.find((field) => norm(field && field.label)) || staticMatches[0] || null;
      const control = row && Array.isArray(row.controls) && row.controls.length === 1 ? row.controls[0] : null;
      const label = norm(bestStatic && bestStatic.label) || norm(row && row.label) || norm(control && control.label);
      if (!label) return;
      rows.push({
        rowId: String(row && row.rowId || ""),
        selector: rowSelector,
        label,
        fieldId: String(control && control.fieldId || bestStatic && bestStatic.graphFieldId || ""),
        controlSelector: String(control && control.selectorHint || bestStatic && bestStatic.selectorHint || ""),
        controlType: String(control && control.controlType || bestStatic && bestStatic.controlType || ""),
        required: !!(control && control.required || bestStatic && bestStatic.required)
      });
      rowCount += 1;
      controlCount += Number(row && row.controlCount || 0);
    });
    if (!rows.length) return;
    sections.push({
      sectionId: String(section && section.sectionId || ""),
      selector,
      title,
      rows
    });
  });

  if (!sections.length || !rowCount) return null;
  let hostname = "";
  try { hostname = new URL(String(rawUrl || "")).hostname.toLowerCase(); } catch (_) {}
  const selectors = {
    container: { class: sections.map((section) => section.selector).join(", ") },
    title: { class: "" },
    labels: { class: "" }
  };
  return {
    schemaType: "autofill-lite-graph-structure-candidate",
    schemaVersion: 1,
    page: { hostname, routeKey: routeKeyFromUrl(rawUrl) },
    sourceSnapshotAt: String(snapshot.at || ""),
    sourceFingerprint: String(snapshot.fingerprint || ""),
    graphVersion: String(graph.graphVersion || ""),
    graphCoverage: Number(analysis.graphCoverage && analysis.graphCoverage.linkedRatio || 0),
    sections,
    selectors,
    summary: {
      sectionCount: sections.length,
      rowCount,
      controlCount,
      aiAuthoredSelectors: false,
      structureSource: "local_form_graph"
    }
  };
}

function attachGraphStructureToSiteCandidate(siteCandidate, graphStructure) {
  if (!siteCandidate || !siteCandidate.configTemplate || !graphStructure) return siteCandidate;
  const out = JSON.parse(JSON.stringify(siteCandidate));
  const config = out.configTemplate;
  config.selectors = Object.assign({}, config.selectors || {}, graphStructure.selectors || {});
  config._graphStructure = {
    schemaVersion: graphStructure.schemaVersion,
    sourceSnapshotAt: graphStructure.sourceSnapshotAt,
    sourceFingerprint: graphStructure.sourceFingerprint,
    graphVersion: graphStructure.graphVersion,
    graphCoverage: graphStructure.graphCoverage,
    sections: graphStructure.sections
  };
  config._autoConfigStrategy = Object.assign({}, config._autoConfigStrategy || {}, {
    mode: "graph_backed_structure_candidate_v1",
    graphAware: true,
    graphBacked: true,
    aiAuthoredSelectors: false,
    requiresMatureBaseConfig: false,
    structureSource: "local_form_graph"
  });
  out.summary = Object.assign({}, out.summary || {}, {
    requiresMatureBaseConfig: false,
    aiAuthoredSelectors: false,
    graphBacked: true,
    graphStructureSections: Number(graphStructure.summary && graphStructure.summary.sectionCount || 0),
    graphStructureRows: Number(graphStructure.summary && graphStructure.summary.rowCount || 0)
  });
  out.safety = Object.assign({}, out.safety || {}, {
    selectorsAuthoredByAi: false,
    structureSelectorsSource: "local_form_graph"
  });
  return out;
}

function reconcileSemanticMappingsWithGraphStructure(siteCandidate) {
  if (!siteCandidate || !siteCandidate.configTemplate) return siteCandidate;
  const out = JSON.parse(JSON.stringify(siteCandidate));
  const config = out.configTemplate || {};
  const graph = config._graphStructure || {};
  const sections = Array.isArray(graph.sections) ? graph.sections : [];
  const semantic = config._aiSemanticPatch || {};
  const mappings = Array.isArray(semantic.fieldMappings) ? semantic.fieldMappings : [];
  if (!sections.length || !mappings.length) return out;

  const rowByFieldId = new Map();
  sections.forEach((section) => {
    (Array.isArray(section && section.rows) ? section.rows : []).forEach((row) => {
      const fieldId = String(row && row.fieldId || "");
      if (!fieldId || rowByFieldId.has(fieldId)) return;
      rowByFieldId.set(fieldId, {
        label: norm(row && row.label),
        rawLabel: String(row && row.label || "").trim(),
        sectionTitle: String(section && section.title || "").trim()
      });
    });
  });

  let relabeled = 0;
  const sectionEvidence = new Map();
  semantic.fieldMappings = mappings.map((mapping) => {
    const cloned = Object.assign({}, mapping || {});
    const fieldId = String(cloned.fieldId || "");
    const row = rowByFieldId.get(fieldId);
    if (!row || !row.rawLabel) return cloned;
    if (String(cloned.label || "").trim() !== row.rawLabel) {
      cloned.aiObservedLabel = String(cloned.label || "").trim();
      cloned.label = row.rawLabel;
      cloned.graphLabelReconciled = true;
      relabeled += 1;
    }
    const category = String(cloned.category || "").trim();
    if (row.sectionTitle && category) {
      if (!sectionEvidence.has(row.sectionTitle)) sectionEvidence.set(row.sectionTitle, []);
      sectionEvidence.get(row.sectionTitle).push({ category, confidence: Number(cloned.confidence || 0) });
    }
    return cloned;
  });

  const existingSections = Array.isArray(semantic.sectionMappings) ? semantic.sectionMappings.slice() : [];
  sectionEvidence.forEach((items, title) => {
    const categories = Array.from(new Set(items.map((item) => item.category).filter(Boolean)));
    if (categories.length !== 1) return;
    const category = categories[0];
    const confidence = Math.min.apply(null, items.map((item) => Number(item.confidence || 0)).filter((n) => Number.isFinite(n)));
    const idx = existingSections.findIndex((item) => item && (String(item.label || "").trim() === title || String(item.category || "") === category));
    const next = {
      category,
      label: title,
      confidence: Number.isFinite(confidence) ? confidence : 0.8,
      source: "graph_fieldid_semantic_consensus"
    };
    if (idx >= 0) existingSections[idx] = Object.assign({}, existingSections[idx], next);
    else existingSections.push(next);
  });
  semantic.sectionMappings = existingSections;
  config._aiSemanticPatch = semantic;
  config._autoConfigStrategy = Object.assign({}, config._autoConfigStrategy || {}, {
    graphSemanticLabelBridge: true,
    graphSemanticRelabeledFieldCount: relabeled
  });
  out.summary = Object.assign({}, out.summary || {}, {
    graphSemanticRelabeledFieldCount: relabeled,
    acceptedSectionMappings: existingSections.length
  });
  return out;
}

module.exports = {
  stableSelector,
  latestUsefulSnapshot,
  compileGraphStructureFromBundle,
  attachGraphStructureToSiteCandidate,
  reconcileSemanticMappingsWithGraphStructure
};
