// content/date-picker/handlers/native.js — 原生 <input type="date"|"month"> 日期选择器
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   子类 go (native-date): 行 47795-47875
//   原生日期值设置器 Cn()/Nn(): 行 45159-45228 — 直接赋 .value，依次派发 input→change→blur (每步间隔10ms)
//   范围日期兜底: n.c.findSimilarElements + ho() 打分选出"结束日期"兄弟输入框，找不到则退回
//     n.c.findSurroundingInputs 取邻近的第一个 input
//
// 注: 任务书原文猜测 51job 是"自定义三连下拉"，但源码显示 51job 的日期字段就是普通 <input>，
// 直接清空再赋值 + 派发事件 (Kr/Jr 函数)，跟原生 <input type=date> 的思路一致但不完全相同
// (51job 会先清空一次、多一次 focus)。为了跟 manifest.json 里独立的 handlers/job51.js 对齐，
// 51job 的真实实现放在 job51.js 里，这里只保留 native-date 类型。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  // 源码 Cn()/Nn(), 行45159
  async function setNativeValue(el, dateStr) {
    if (!el || !dateStr) return false;
    try {
      el.value = dateStr;
      el.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
      await AF.Utils.sleep(10);
      el.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      await AF.Utils.sleep(10);
      el.dispatchEvent(new Event("blur", { bubbles: true, cancelable: true }));
      return true;
    } catch (e) {
      return false;
    }
  }

  AF.DatePicker._registry["native-date"] = function (element, valueType) {
    return {
      setValue: async function (value) {
        try {
          if (!value) throw new Error("日期为空");
          if (typeof value === "string" || valueType === "string") {
            return await setNativeValue(element, value);
          }
          if (typeof value !== "object" || !("startTime" in value) || !("endTime" in value)) {
            throw new Error("dateValue必须包含startTime和endTime属性");
          }
          await setNativeValue(element, value.startTime);
          await AF.Utils.sleep(100);
          var candidates = AF.DomUtils.findSimilarElements(element, 4, { sameTag: true, sameClass: false, sameParent: false });
          if (candidates.length > 0) {
            var best = AF.DatePicker._pickEndDateCandidate(element, candidates);
            await setNativeValue(best, value.endTime);
          } else {
            var surrounding = AF.DomUtils.findSurroundingInputs(element);
            if (surrounding.length > 0) await setNativeValue(surrounding[0], value.endTime);
          }
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
