"use strict";

const fs = require("fs");
const path = require("path");
const { URL } = require("url");
const crypto = require("crypto");

function safeAnalysisHost(rawUrl) {
  try { return new URL(rawUrl).hostname.toLowerCase().replace(/[^a-z0-9.-]+/g, "_").slice(0, 120) || "site"; }
  catch (_) { return "site"; }
}

function safeAnalysisRoute(rawUrl) {
  try {
    const pathname = new URL(rawUrl).pathname || "/";
    const slug = pathname.replace(/[^a-z0-9._-]+/gi, "_").replace(/^_+|_+$/g, "").slice(0, 100);
    return slug || "root";
  } catch (_) {
    return "root";
  }
}

function uniqueStringList(values, limit) {
  const result = [];
  (Array.isArray(values) ? values : []).forEach((value) => {
    const text = String(value == null ? "" : value).trim();
    if (!text || result.includes(text)) return;
    result.push(text);
  });
  return result.slice(0, Number(limit || 120));
}

const AI_PROFILE_FIELD_KEYS = Object.freeze({
  basicInfo: [
    "name", "gender", "birthDate", "country", "nativePlace", "ethnicity", "maritalStatus",
    "phone", "wechat", "qq", "email", "homepage", "politicalStatus", "healthStatus",
    "emergencyContactName", "emergencyPhone", "emergencyContactRelation", "currentAddress",
    "currentResidence", "currentAddressDetail", "hukouLocation", "birthOrigin", "idType",
    "idNumber", "height", "weight", "postalCode", "hobbies", "selfIntroduction",
    "writtenExamCity", "acceptPositionAdjustment", "workYears"
  ],
  jobIntention: [
    "position", "industry", "city", "currentLocation", "expectedLocation", "salary", "currentSalary",
    "availability", "cityFlexible", "acceptAdjustment", "obeyAssignment"
  ],
  education: [
    "school", "schoolAffiliation", "schoolLocation", "level", "educationType", "degree",
    "department", "major", "researchDirection", "majorCategory", "majorCourses",
    "studyLength", "gpa", "gpaScore", "gpaTotal", "startTime", "endTime", "classRank",
    "integratedTraining", "hasOverseasStudy", "isOverseas", "secondDegreeOrMinor"
  ],
  internshipExperience: [
    "company", "department", "industry", "workLocation", "position", "detailedContent",
    "result", "startTime", "endTime", "reasonForLeaving", "custom_referencePerson",
    "custom_referencePersonPhone"
  ],
  workExperience: [
    "company", "department", "industry", "workLocation", "position", "detailedContent",
    "result", "startTime", "endTime", "reasonForLeaving", "custom_referencePerson",
    "custom_referencePersonPhone"
  ],
  projectExperience: [
    "name", "company", "role", "details", "result", "startTime", "endTime", "link"
  ],
  awards: [
    "awardScope", "awardClass", "awardCategory", "awardName", "awardTime", "awardIssuer",
    "awardLevel", "awardGrade", "awardDescription"
  ],
  languageSkills: [
    "name", "level", "proficiency", "certificate", "certificateName", "score", "obtainedTime",
    "speakingListening", "readingWriting", "description", "cet4Score", "cet6Score",
    "otherEnglishExam", "otherEnglishScore", "ieltsScore", "englishLevel"
  ],
  campusLeadership: [
    "projectName", "title", "leadershipLevel", "startTime", "endTime", "description", "roleDescription"
  ],
  campusActivities: [
    "projectName", "title", "leadershipLevel", "startTime", "endTime", "description", "roleDescription"
  ],
  certificates: [
    "certificateType", "certificateName", "obtainedTime", "description"
  ],
  familyMembers: [
    "name", "birthDate", "politicalStatus", "relationship", "company", "position", "phone"
  ],
  trainingExperience: [
    "name", "organization", "startTime", "endTime", "description"
  ],
  patents: [
    "patentName", "patentNumber", "patentType", "applicationDate", "authorizationDate", "grantDate", "description"
  ],
  selfIntroduction: ["selfIntroduction"],
  publications: [
    "paperTitle", "journal", "publishYear", "publishTime", "publicationLevel", "contribution", "paperLink"
  ]
});


const AI_PROFILE_FIELD_SEMANTICS = Object.freeze({
  "basicInfo.workYears": "years of work experience; not desired tenure",
  "jobIntention.position": "desired or target position; never current occupation",
  "jobIntention.industry": "desired or target industry; never current industry",
  "jobIntention.city": "desired work city/location",
  "jobIntention.expectedLocation": "desired work location",
  "jobIntention.currentLocation": "current residence/current physical location; not current work city",
  "jobIntention.salary": "desired/expected salary",
  "jobIntention.currentSalary": "current/present salary, including current monthly salary",
  "jobIntention.availability": "expected start/onboarding availability",
  "familyMembers.name": "family member name; never applicant name",
  "familyMembers.birthDate": "family member date of birth; never applicant birth date",
  "familyMembers.relationship": "relationship of the family member to the applicant",
  "familyMembers.company": "family member employer/work unit",
  "familyMembers.position": "family member occupation, job title or position",
  "familyMembers.phone": "family member contact phone; never applicant phone"
});


function expectedCategoryFromModuleTitle(title) {
  const text = normalizeIdentityText(title);
  if (!text) return "";
  if (/个人信息|基本信息|基础信息|个人资料/.test(text)) return "basicInfo";
  if (/求职意向|投递信息|意向信息/.test(text)) return "jobIntention";
  if (/教育经历|教育背景|学习经历|高中教育|高等教育/.test(text)) return "education";
  if (/实习|工作经历|工作经验|入伍经历/.test(text)) return "internshipExperience";
  if (/项目经历|项目经验|研究成果/.test(text)) return "projectExperience";
  if (/奖励|获奖|荣誉/.test(text)) return "awards";
  if (/语言|外语|英语/.test(text)) return "languageSkills";
  if (/学生工作|校园经历|校园活动|社会实践/.test(text)) return "campusLeadership";
  if (/家庭成员|家庭关系|家庭情况/.test(text)) return "familyMembers";
  if (/证书|资格|资质/.test(text)) return "certificates";
  if (/培训/.test(text)) return "trainingExperience";
  if (/专利/.test(text)) return "patents";
  if (/自我介绍|自我评价|自我描述/.test(text)) return "selfIntroduction";
  if (/论文|科研/.test(text)) return "publications";
  return "";
}

function interactiveFieldSignature(fields) {
  const parts = (Array.isArray(fields) ? fields : []).map((field) => {
    return [
      String(field && field.coreCategory || ""),
      String(field && field.coreFieldKey || ""),
      semanticIdentity(field),
      String(field && field.controlType || "")
    ].join("|");
  }).filter(Boolean).sort();
  return crypto.createHash("sha1").update(parts.join("\n")).digest("hex").slice(0, 16);
}

function compactTrustedInteractiveModules(interactive) {
  const modules = Array.isArray(interactive && interactive.modules) ? interactive.modules : [];
  const seenSignatures = new Map();
  const result = [];
  modules.forEach((module, index) => {
    const scan = module && module.scan || {};
    const rawFields = Array.isArray(scan.fields) ? scan.fields : [];
    if (!rawFields.length) return;
    const fields = annotateSnapshotFields(rawFields.map(compactAiField));
    const categoryCounts = new Map();
    fields.forEach((field) => {
      if (!field.coreCategory) return;
      categoryCounts.set(field.coreCategory, Number(categoryCounts.get(field.coreCategory) || 0) + 1);
    });
    const dominant = Array.from(categoryCounts.entries()).sort((a, b) => b[1] - a[1])[0] || ["", 0];
    const expectedCategory = expectedCategoryFromModuleTitle(module && module.title);
    const categoryMismatch = !!(expectedCategory && dominant[0] && expectedCategory !== dominant[0] && Number(dominant[1] || 0) >= 2);
    const signature = interactiveFieldSignature(fields);
    const duplicateOf = signature && seenSignatures.has(signature) ? seenSignatures.get(signature) : null;
    if (signature && duplicateOf == null) seenSignatures.set(signature, index);
    const trusted = !categoryMismatch && duplicateOf == null;
    result.push({
      index,
      title: String(module && module.title || "").slice(0, 100),
      actionType: String(module && module.actionType || "").slice(0, 40),
      actionText: String(module && module.actionText || "").slice(0, 40),
      surfaceType: String(module && module.surfaceType || "").slice(0, 40),
      trusted,
      expectedCategory,
      dominantCategory: String(dominant[0] || ""),
      categoryMismatch,
      duplicateOfIndex: duplicateOf == null ? -1 : Number(duplicateOf),
      semanticFingerprint: signature,
      fields: trusted ? fields : [],
      formGraph: trusted ? compactFormGraph(module && module.formGraph) : null,
      graphCoverage: trusted ? compactGraphCoverage(module && module.graphCoverage) : compactGraphCoverage(null)
    });
  });
  return result;
}

function normalizeIdentityText(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/必填|选填|未完成|删除经历|添加/g, "")
    .replace(/^\s*[*＊]+\s*/g, "")
    .replace(/[\s\u00a0：:，,。.!！?？、;；·•\-_/\\()（）\[\]【】<>《》“”"'`~+*=＊#]/g, "")
    .slice(0, 180);
}

function structuralTokens(field) {
  const raw = [
    field && field.selectorHint,
    field && field.widgetSelectorHint,
    field && field.name,
    field && field.id
  ].filter(Boolean).join(" ");
  const tokens = [];
  const generic = new Set([
    "el-input", "el-input__inner", "el-select", "el-date-editor", "el-cascader",
    "el-radio", "el-textarea", "el-textarea__inner", "input_box", "info_box",
    "send_content", "apply-form-input", "apply-form-select", "apply-form-date",
    "apply-form-input__node", "apply-form-select__node"
  ]);
  const re = /[#.]([A-Za-z_][A-Za-z0-9_-]{2,})/g;
  let match;
  while ((match = re.exec(raw))) {
    const token = match[1];
    if (!token || generic.has(token) || /^nth-of-type$/i.test(token)) continue;
    if (!tokens.includes(token)) tokens.push(token);
  }
  return tokens.slice(0, 12);
}

function semanticIdentity(field) {
  const candidates = Array.isArray(field && field.semanticCandidates) ? field.semanticCandidates : [];
  return normalizeIdentityText(candidates[0] || field && field.label || field && field.placeholder ||
    field && field.name || field && field.id || field && field.controlType || "field");
}

function annotateSnapshotFields(fields) {
  const list = Array.isArray(fields) ? fields : [];
  const sectionPosition = new Map();
  const semanticTotals = new Map();

  list.forEach((field) => {
    const section = normalizeIdentityText(field && field.section || "当前页面") || "current";
    const semantic = semanticIdentity(field) || normalizeIdentityText(field && field.controlType || "field");
    const key = [section, semantic, String(field && field.controlType || "")].join("|");
    semanticTotals.set(key, (semanticTotals.get(key) || 0) + 1);
  });

  const semanticSeen = new Map();
  return list.map((field) => {
    const section = normalizeIdentityText(field && field.section || "当前页面") || "current";
    const semantic = semanticIdentity(field) || normalizeIdentityText(field && field.controlType || "field");
    const groupKey = [section, semantic, String(field && field.controlType || "")].join("|");
    const sectionIndex = sectionPosition.get(section) || 0;
    sectionPosition.set(section, sectionIndex + 1);
    const ordinal = (semanticSeen.get(groupKey) || 0) + 1;
    semanticSeen.set(groupKey, ordinal);
    const sameCount = semanticTotals.get(groupKey) || 1;
    const identity = [section, semantic, String(field && field.controlType || ""), ordinal].join("|");
    return Object.assign({}, field, {
      fieldId: "fld_" + crypto.createHash("sha256").update(identity).digest("hex").slice(0, 16),
      sectionFieldIndex: sectionIndex,
      sameSemanticOrdinal: ordinal,
      sameSemanticCount: sameCount,
      structuralTokens: structuralTokens(field)
    });
  });
}

function mappingStatusRank(field) {
  if (field && field.coreMappingStatus === "trusted" && field.coreFieldKey) return 3;
  if (field && field.coreFieldKey) return 2;
  return 1;
}

function mergeFieldIdentity(field) {
  var selector = String(field && field.selectorHint || "").trim();
  if (selector && Number(field && field.selectorHitCount || 0) === 1 && isStablePatchSelector(selector)) {
    return "selector:" + selector;
  }
  var widgetSelector = String(field && field.widgetSelectorHint || "").trim();
  if (widgetSelector && Number(field && field.widgetSelectorHitCount || 0) === 1 && isStablePatchSelector(widgetSelector)) {
    return "widget:" + widgetSelector;
  }
  return "field:" + String(field && field.fieldId || "");
}

function mergeFieldQuality(field) {
  var score = mappingStatusRank(field) * 100;
  if (field && field.graphSectionTitle) score += 30;
  score += Math.round(Number(field && field.graphLinkConfidence || 0) * 20);
  if (field && field.label) score += 5;
  if (field && field.graphRowLabel) score += 5;
  return score;
}

function mergeUniqueFields(fields) {
  const map = new Map();
  (Array.isArray(fields) ? fields : []).forEach((field) => {
    const id = String(field && field.fieldId || "");
    if (!id) return;
    const key = mergeFieldIdentity(field);
    const existing = map.get(key);
    if (!existing) {
      map.set(key, field);
      return;
    }
    const existingRank = mappingStatusRank(existing);
    const incomingRank = mappingStatusRank(field);
    if (existingRank === incomingRank && existing.coreFieldKey && field.coreFieldKey && existing.coreFieldKey !== field.coreFieldKey) {
      const preferred = mergeFieldQuality(field) >= mergeFieldQuality(existing) ? field : existing;
      map.set(key, Object.assign({}, preferred, {
        coreFieldKey: "",
        coreMappingStatus: "unmapped",
        coreMappingConfidence: 0,
        coreMappingReasons: uniqueStringList(
          (existing.coreMappingReasons || []).concat(field.coreMappingReasons || [], ["cross_snapshot_mapping_conflict"]),
          8
        )
      }));
      return;
    }
    // For the same stable selector, prefer stronger graph/mapping evidence; ties
    // deliberately prefer the later snapshot so stale section ownership is retired.
    if (mergeFieldQuality(field) >= mergeFieldQuality(existing)) map.set(key, field);
  });
  return Array.from(map.values());
}

function profileKeyAllowed(category, fieldKey) {
  const keys = AI_PROFILE_FIELD_KEYS[String(category || "")] || [];
  return !!fieldKey && keys.includes(String(fieldKey));
}

function looksLikeGenericDate(field) {
  const token = normalizeIdentityText(
    (field && field.semanticCandidates && field.semanticCandidates[0]) ||
    field && field.label || field && field.placeholder
  );
  return /^(?:日期|选择日期|日期选择)$/.test(token) || token === "";
}

function deriveReviewSuggestion(field) {
  const reasons = uniqueStringList(field && field.coreMappingReasons, 8);
  let category = String(field && field.coreCategory || "");
  let fieldKey = String(field && field.coreFieldKey || "");
  let status = String(field && field.coreMappingStatus || (fieldKey ? "tentative" : "unmapped"));
  let method = String(field && field.coreMappingMethod || "");
  let confidence = Number(field && field.coreMappingConfidence || 0);

  const graphCategory = expectedCategoryFromModuleTitle(field && field.graphSectionTitle || "");
  if (graphCategory && Number(field && field.graphLinkConfidence || 0) >= 0.9 && category !== graphCategory) {
    category = graphCategory;
    reasons.push("graph_section_category_override");
  }

  if (fieldKey && !profileKeyAllowed(category, fieldKey)) {
    reasons.push("suggested_key_outside_profile_contract");
    fieldKey = "";
    status = "unmapped";
    method = "";
    confidence = 0;
  }

  const optionTokens = uniqueStringList(field && field.options, 10).map(normalizeIdentityText).filter(Boolean);
  const tokens = (field && field.structuralTokens || []).map((token) => String(token).toLowerCase());

  if (!fieldKey && category === "basicInfo" && String(field && field.controlType || "") === "radio") {
    const hasMale = optionTokens.includes("男");
    const hasFemale = optionTokens.includes("女");
    if (hasMale && hasFemale) {
      fieldKey = "gender";
      status = "tentative";
      method = "structural_option_set";
      confidence = 0.85;
      reasons.push("gender_option_pair");
    }
  }

  if (!fieldKey && category === "jobIntention" &&
      tokens.some((token) => /citydistributable|jobcitydistributable/.test(token))) {
    fieldKey = "cityFlexible";
    status = "tentative";
    method = "structural_token_hint";
    confidence = 0.85;
    reasons.push("structural_token_city_distributable");
  }

  if (!fieldKey && category === "awards" &&
      /获奖类型|奖项类型|获奖类别|奖项类别/.test(String(field && field.section || "")) &&
      /select/.test(String(field && field.controlType || ""))) {
    fieldKey = "awardCategory";
    status = "tentative";
    method = "section_control_hint";
    confidence = 0.8;
    reasons.push("section_implies_award_category");
  }

  const datePairCategories = new Set(["education", "internshipExperience", "projectExperience", "campusLeadership"]);
  if (!fieldKey && datePairCategories.has(category) &&
      /date/.test(String(field && field.controlType || "")) &&
      Number(field && field.sameSemanticCount || 0) === 2 && looksLikeGenericDate(field)) {
    fieldKey = Number(field && field.sameSemanticOrdinal || 1) === 1 ? "startTime" : "endTime";
    status = "tentative";
    method = "positional_date_pair";
    confidence = 0.8;
    reasons.push("positional_date_pair");
  }

  const semanticText = String((field && field.semanticCandidates && field.semanticCandidates[0]) || field && field.label || "")
    .replace(/^\s*[*＊]+\s*/, "");
  const boolQuestion = /^(是否|有无|能否|可否)/.test(semanticText);
  if (boolQuestion && fieldKey && !/^(?:is|has|was|accept|allow|obey|can|need|cityFlexible|overseasMigration|secondDegreeOrMinor|integratedTraining)/i.test(fieldKey)) {
    reasons.push("boolean_question_non_boolean_key");
    fieldKey = "";
    status = "unmapped";
    method = "";
    confidence = 0;
  }

  if (category === "education" && fieldKey === "gpa" && /满绩|满分/.test(semanticText)) {
    fieldKey = "gpaTotal";
    status = "tentative";
    method = "semantic_conflict_correction";
    confidence = 0.85;
    reasons.push("gpa_total_semantic_correction");
  }
  if (category === "education" && fieldKey === "major" && /学科属性|学科门类/.test(semanticText)) {
    fieldKey = "majorCategory";
    status = "tentative";
    method = "semantic_conflict_correction";
    confidence = 0.85;
    reasons.push("major_category_semantic_correction");
  }
  if (category === "languageSkills" && fieldKey === "name" && /成绩|水平|熟练|掌握程度/.test(semanticText)) {
    reasons.push("language_name_semantic_conflict");
    fieldKey = "";
    status = "unmapped";
    method = "";
    confidence = 0;
  }
  if (category === "languageSkills" && fieldKey === "certificate" && /成绩|分数/.test(semanticText)) {
    reasons.push("certificate_score_semantic_conflict");
    fieldKey = "";
    status = "unmapped";
    method = "";
    confidence = 0;
  }
  if (category === "campusLeadership" && fieldKey === "title" && /描述|内容|职责/.test(semanticText)) {
    reasons.push("leadership_title_description_conflict");
    fieldKey = "";
    status = "unmapped";
    method = "";
    confidence = 0;
  }

  return {
    category,
    fieldKey,
    status,
    method,
    confidence,
    reasons: uniqueStringList(reasons, 10)
  };
}

function isStablePatchSelector(selector) {
  const text = String(selector || "").trim();
  if (!text) return false;
  // Candidate patches must survive ordinary user interaction. Reject selectors that
  // encode transient UI state rather than structural identity.
  if (/(?:^|[.\[:_-])(is-checked|is-focus|is-focused|is-active|active|selected|current|hover|focus)(?:$|[.\]:_ -])/i.test(text)) return false;
  if (/:checked\b|:focus(?:-within)?\b|:hover\b|\[aria-(?:checked|selected|expanded)=["']?(?:true|false)["']?\]/i.test(text)) return false;
  return true;
}

function patchTargetForField(field) {
  const safeLabel = String(field && field.label || "").trim();
  if (safeLabel && field && field.labelSource !== "nearby_text" && Number(field.sameSemanticCount || 1) === 1) {
    return { kind: "semantic_label", label: safeLabel };
  }
  if (Number(field && field.selectorHitCount || 0) === 1 && field && isStablePatchSelector(field.selectorHint)) {
    return { kind: "unique_selector", selector: String(field.selectorHint).slice(0, 260) };
  }
  if (Number(field && field.widgetSelectorHitCount || 0) === 1 && field && isStablePatchSelector(field.widgetSelectorHint)) {
    return { kind: "unique_widget_selector", selector: String(field.widgetSelectorHint).slice(0, 260) };
  }
  return { kind: "field_id_only" };
}

function compactAiSelectorCandidates(field) {
  const candidates = Array.isArray(field && field.selectorCandidates) ? field.selectorCandidates : [];
  return candidates
    .map((item) => ({
      selector: String(item && item.selector || "").slice(0, 260),
      hitCount: Number(item && item.hitCount || 0),
      kind: String(item && item.kind || "").slice(0, 40)
    }))
    .filter((item) => item.selector)
    .sort((a, b) => {
      const au = a.hitCount === 1 ? 0 : 1;
      const bu = b.hitCount === 1 ? 0 : 1;
      if (au !== bu) return au - bu;
      return a.hitCount - b.hitCount;
    })
    .slice(0, 4);
}

function compactAiField(field) {
  const labelSource = String(field && field.labelSource || "");
  const safeLabel = labelSource && labelSource !== "nearby_text"
    ? String(field && field.label || "").slice(0, 120)
    : "";
  return {
    section: String(field && field.section || "").slice(0, 100),
    label: safeLabel,
    labelSource,
    semanticCandidates: uniqueStringList(field && field.safeSemanticCandidates, 10),
    controlType: String(field && field.controlType || "").slice(0, 60),
    widgetFamily: String(field && field.widgetFamily || "").slice(0, 40),
    name: String(field && field.name || "").slice(0, 90),
    id: String(field && field.id || "").slice(0, 90),
    placeholder: String(field && field.placeholder || "").slice(0, 140),
    required: !!(field && field.required),
    requiredEvidence: uniqueStringList(field && field.requiredEvidence, 8),
    options: uniqueStringList(field && field.options, 40),
    selectorHint: String(field && field.selectorHint || "").slice(0, 260),
    selectorHitCount: Number(field && field.selectorHitCount || 0),
    selectorCandidates: compactAiSelectorCandidates(field),
    widgetSelectorHint: String(field && field.widgetSelectorHint || "").slice(0, 260),
    widgetSelectorHitCount: Number(field && field.widgetSelectorHitCount || 0),
    coreCategory: String(field && field.coreCategory || "").slice(0, 80),
    coreCategorySource: String(field && field.coreCategorySource || "").slice(0, 60),
    coreCategoryConfidence: Number(field && field.coreCategoryConfidence || 0),
    coreCategoryEvidence: String(field && field.coreCategoryEvidence || "").slice(0, 120),
    coreFieldKey: String(field && field.coreFieldKey || "").slice(0, 100),
    coreMappingEvidence: String(field && field.coreMappingEvidence || "").slice(0, 120),
    coreMappingMethod: String(field && field.coreMappingMethod || "").slice(0, 60),
    coreMappingConfidence: Number(field && field.coreMappingConfidence || 0),
    coreMappingStatus: String(field && field.coreMappingStatus || (field && field.coreFieldKey ? "tentative" : "unmapped")).slice(0, 30),
    coreMappingReasons: uniqueStringList(field && field.coreMappingReasons, 8),
    graphFieldId: String(field && field.graphFieldId || "").slice(0, 80),
    graphSectionId: String(field && field.graphSectionId || "").slice(0, 80),
    graphSectionTitle: String(field && field.graphSectionTitle || "").slice(0, 100),
    graphRowId: String(field && field.graphRowId || "").slice(0, 80),
    graphRowLabel: String(field && field.graphRowLabel || "").slice(0, 100),
    graphLinkMethod: String(field && field.graphLinkMethod || "").slice(0, 50),
    graphLinkConfidence: Number(field && field.graphLinkConfidence || 0),
    sourceIndex: Number(field && field.index || 0),
    sectionEvidence: String(field && field.sectionEvidence || "").slice(0, 60)
  };
}

function compactFormGraph(graph) {
  if (!graph || typeof graph !== "object") return null;
  const sections = (Array.isArray(graph.sections) ? graph.sections : []).slice(0, 50).map((section) => ({
    sectionId: String(section && section.sectionId || "").slice(0, 80),
    title: String(section && section.title || "").slice(0, 100),
    role: String(section && section.role || "").slice(0, 40),
    rowCount: Number(section && section.rowCount || 0),
    controlCount: Number(section && section.controlCount || 0),
    rows: (Array.isArray(section && section.rows) ? section.rows : []).slice(0, 120).map((row) => ({
      rowId: String(row && row.rowId || "").slice(0, 80),
      role: String(row && row.role || "").slice(0, 40),
      label: String(row && row.label || "").slice(0, 100),
      controlCount: Number(row && row.controlCount || 0),
      controls: (Array.isArray(row && row.controls) ? row.controls : []).slice(0, 12).map((control) => ({
        fieldId: String(control && control.fieldId || "").slice(0, 80),
        label: String(control && control.label || "").slice(0, 100),
        controlType: String(control && control.controlType || "").slice(0, 60),
        widgetFamily: String(control && control.widgetFamily || "").slice(0, 40),
        required: !!(control && control.required)
      }))
    }))
  }));
  return {
    schemaType: String(graph.schemaType || "").slice(0, 60),
    schemaVersion: Number(graph.schemaVersion || 0),
    graphVersion: String(graph.graphVersion || "").slice(0, 30),
    totals: {
      sections: Number(graph.totals && graph.totals.sections || sections.length || 0),
      rows: Number(graph.totals && graph.totals.rows || 0),
      controls: Number(graph.totals && graph.totals.controls || 0)
    },
    sections
  };
}

function compactGraphCoverage(coverage) {
  coverage = coverage || {};
  return {
    staticControlCount: Number(coverage.staticControlCount || 0),
    graphControlCount: Number(coverage.graphControlCount || 0),
    linkedStaticFieldCount: Number(coverage.linkedStaticFieldCount || 0),
    unlinkedStaticFieldCount: Number(coverage.unlinkedStaticFieldCount || 0),
    graphOnlyControlCount: Number(coverage.graphOnlyControlCount || 0),
    linkedRatio: Number(coverage.linkedRatio || 0)
  };
}

function snapshotIsCurrentSchema(snapshot) {
  return Number(snapshot && snapshot.analysis && snapshot.analysis.schemaVersion || 0) >= 4;
}

function snapshotHasAiEvidence(snapshot) {
  const analysis = snapshot && snapshot.analysis || {};
  if (!snapshotIsCurrentSchema(snapshot)) return false;
  const scan = analysis.staticScan || {};
  const navigation = analysis.navigation || {};
  const interactive = analysis.interactive || {};
  return Number(scan.controlCount || 0) > 0 ||
    (Array.isArray(navigation.items) && navigation.items.length > 0) ||
    (Array.isArray(interactive.candidates) && interactive.candidates.length > 0) ||
    (Array.isArray(interactive.modules) && interactive.modules.length > 0);
}

function buildAiSiteInput(bundleFile, rawUrl, siteAnalysisDir) {
  let bundle = null;
  try { bundle = JSON.parse(fs.readFileSync(bundleFile, "utf8")); } catch (_) {}
  if (!bundle || !Array.isArray(bundle.snapshots)) return null;

  const sourceSnapshots = bundle.snapshots.slice(-10);
  const legacySnapshotCount = sourceSnapshots.filter((snapshot) => !snapshotIsCurrentSchema(snapshot)).length;
  const snapshots = sourceSnapshots.filter(snapshotHasAiEvidence);
  const builtInConfigSet = new Map();
  const workflowSet = new Set();
  const platformSet = new Map();
  let serverConfigEnabled = false;
  let trustedMappedFieldCount = 0;
  let tentativeMappedFieldCount = 0;
  let unmappedFieldCount = 0;
  const unknownSectionSet = new Set();
  const allFields = [];

  const compactSnapshots = snapshots.map((snapshot) => {
    const analysis = snapshot && snapshot.analysis || {};
    const scan = analysis.staticScan || {};
    const interactive = analysis.interactive || {};
    const navigation = analysis.navigation || {};
    const probe = analysis.configProbe || {};
    const formGraph = compactFormGraph(analysis.formGraph);
    const graphCoverage = compactGraphCoverage(analysis.graphCoverage);
    const graphDiagnostics = analysis.graphDiagnostics || {};

    if (probe.serverConfigEnabled) serverConfigEnabled = true;
    const builtIn = probe.builtInConfig;
    if (builtIn && (builtIn.name || builtIn.type || builtIn.source)) {
      const key = JSON.stringify([builtIn.name || "", builtIn.type || "", builtIn.source || "", builtIn.platform || ""]);
      builtInConfigSet.set(key, {
        name: String(builtIn.name || "").slice(0, 100),
        type: String(builtIn.type || "").slice(0, 60),
        source: String(builtIn.source || "").slice(0, 80),
        platform: String(builtIn.platform || "").slice(0, 80),
        pageType: String(builtIn.pageType || "").slice(0, 80)
      });
    }
    const workflowId = String(probe.specialWorkflowId || "").trim();
    if (workflowId) workflowSet.add(workflowId);
    const platform = probe.domPlatform;
    if (platform && (platform.name || platform.type || platform.platform)) {
      const key = JSON.stringify([platform.name || "", platform.type || "", platform.platform || ""]);
      platformSet.set(key, {
        name: String(platform.name || "").slice(0, 100),
        type: String(platform.type || "").slice(0, 60),
        platform: String(platform.platform || "").slice(0, 80),
        source: String(platform.source || "").slice(0, 80)
      });
    }

    const fields = annotateSnapshotFields((Array.isArray(scan.fields) ? scan.fields : []).map(compactAiField));
    const interactiveModules = compactTrustedInteractiveModules(interactive);
    fields.forEach((field) => {
      allFields.push(field);
      if (field.coreMappingStatus === "trusted" && field.coreFieldKey) trustedMappedFieldCount += 1;
      else if (field.coreFieldKey) tentativeMappedFieldCount += 1;
      else unmappedFieldCount += 1;
      if (field.section && field.section !== "当前页面" && !field.coreCategory) unknownSectionSet.add(field.section);
    });
    interactiveModules.filter((module) => module.trusted).forEach((module) => {
      (module.fields || []).forEach((field) => {
        allFields.push(field);
        if (field.coreMappingStatus === "trusted" && field.coreFieldKey) trustedMappedFieldCount += 1;
        else if (field.coreFieldKey) tentativeMappedFieldCount += 1;
        else unmappedFieldCount += 1;
        if (field.section && field.section !== "当前页面" && !field.coreCategory) unknownSectionSet.add(field.section);
      });
    });

    return {
      fingerprint: String(snapshot && snapshot.fingerprint || ""),
      at: String(snapshot && snapshot.at || ""),
      sections: (Array.isArray(scan.sections) ? scan.sections : []).map((section) => ({
        title: String(section && section.title || "").slice(0, 100),
        fieldCount: Number(section && section.fieldCount || 0),
        labels: uniqueStringList(section && section.labels, 80),
        controlTypes: uniqueStringList(section && section.controlTypes, 30)
      })),
      fields,
      formGraph,
      graphCoverage,
      graphDiagnostics: {
        available: !!graphDiagnostics.available,
        source: String(graphDiagnostics.source || "").slice(0, 40),
        graphVersion: String(graphDiagnostics.graphVersion || "").slice(0, 30),
        schemaVersion: Number(graphDiagnostics.schemaVersion || 0),
        sectionCount: Number(graphDiagnostics.sectionCount || 0),
        rowCount: Number(graphDiagnostics.rowCount || 0),
        controlCount: Number(graphDiagnostics.controlCount || 0),
        linkedRatio: Number(graphDiagnostics.linkedRatio || 0),
        privacySafe: graphDiagnostics.privacySafe !== false
      },
      navigation: (Array.isArray(navigation.items) ? navigation.items : []).slice(0, 80).map((item) => ({
        text: String(item && item.text || "").slice(0, 80),
        active: !!(item && item.active),
        role: String(item && item.role || "").slice(0, 40),
        hrefPath: String(item && item.hrefPath || "").slice(0, 160),
        selectorHint: String(item && item.selectorHint || "").slice(0, 260),
        selectorHitCount: Number(item && item.selectorHitCount || 0)
      })),
      interactiveModules,
      interactiveCandidates: (Array.isArray(interactive.candidates) ? interactive.candidates : []).slice(0, 30).map((item) => ({
        title: String(item && item.title || "").slice(0, 100),
        actionType: String(item && item.actionType || "").slice(0, 40),
        actionText: String(item && item.actionText || "").slice(0, 40),
        initialControlCount: Number(item && item.initialControlCount || 0)
      }))
    };
  });

  const uniqueFields = mergeUniqueFields(allFields);
  trustedMappedFieldCount = uniqueFields.filter((field) => field.coreMappingStatus === "trusted" && field.coreFieldKey).length;
  tentativeMappedFieldCount = uniqueFields.filter((field) => field.coreMappingStatus !== "trusted" && !!field.coreFieldKey).length;
  unmappedFieldCount = uniqueFields.filter((field) => !field.coreFieldKey).length;
  const repeatedSelectorCount = uniqueFields.filter((field) => Number(field.selectorHitCount || 0) !== 1).length;
  const aiInput = {
    schemaType: "autofill-lite-ai-site-input",
    schemaVersion: 4,
    generatedAt: new Date().toISOString(),
    page: {
      hostname: String(bundle.hostname || safeAnalysisHost(rawUrl)),
      pathname: String(bundle.pathname || (() => { try { return new URL(rawUrl).pathname || "/"; } catch (_) { return "/"; } })())
    },
    sourceBundleFile: path.basename(bundleFile),
    safety: {
      resumeValuesIncluded: false,
      currentFieldValuesIncluded: false,
      fullUrlQueryIncluded: false,
      cookiesTokensSessionsIncluded: false,
      nearbyFreeTextExcludedFromAiPacket: true,
      formGraphCurrentValuesIncluded: false,
      formGraphArbitraryRowTextIncluded: false,
      allowedOutputIntent: "candidate_site_config_only"
    },
    coreContext: {
      serverConfigEnabled,
      builtInConfigs: Array.from(builtInConfigSet.values()),
      specialWorkflowIds: Array.from(workflowSet).slice(0, 30),
      domPlatforms: Array.from(platformSet.values())
    },
    observed: {
      sections: uniqueStringList(bundle.observed && bundle.observed.sections, 160),
      navigationItems: uniqueStringList(bundle.observed && bundle.observed.navigationItems, 160),
      controlTypes: uniqueStringList(bundle.observed && bundle.observed.controlTypes, 80)
    },
    mappingSummary: {
      totalFields: uniqueFields.length,
      totalFieldOccurrences: allFields.length,
      coreMappedFieldCount: trustedMappedFieldCount,
      trustedCoreMappedFieldCount: trustedMappedFieldCount,
      tentativeCoreMappedFieldCount: tentativeMappedFieldCount,
      unmappedFieldCount: unmappedFieldCount,
      aiMappingNeededFieldCount: tentativeMappedFieldCount + unmappedFieldCount,
      nonUniqueSelectorFieldCount: repeatedSelectorCount,
      unknownSections: Array.from(unknownSectionSet).slice(0, 80),
      sourceSnapshotCount: sourceSnapshots.length,
      includedSnapshotCount: snapshots.length,
      legacySnapshotCountExcluded: legacySnapshotCount,
      emptyOrLegacySnapshotCountExcluded: sourceSnapshots.length - snapshots.length,
      graphLinkedFieldCount: uniqueFields.filter((field) => !!field.graphFieldId).length,
      graphLinkedRowCount: new Set(uniqueFields.map((field) => field.graphRowId).filter(Boolean)).size,
      graphLinkedSectionCount: new Set(uniqueFields.map((field) => field.graphSectionId).filter(Boolean)).size,
      trustedInteractiveModuleCount: compactSnapshots.reduce((sum, snapshot) =>
        sum + (Array.isArray(snapshot.interactiveModules) ? snapshot.interactiveModules.filter((module) => module.trusted).length : 0), 0),
      rejectedInteractiveModuleCount: compactSnapshots.reduce((sum, snapshot) =>
        sum + (Array.isArray(snapshot.interactiveModules) ? snapshot.interactiveModules.filter((module) => !module.trusted).length : 0), 0)
    },
    outputContract: {
      mustBeDeclarative: true,
      mayUseExistingCoreAdapters: true,
      mayInventResumeValues: false,
      mayClickSaveSubmitApplyDeleteUpload: false,
      shouldPreserveExistingVerifiedMappings: true,
      shouldReviewTentativeCoreMappings: true,
      mayOverrideTrustedCoreMappings: false
    },
    snapshots: compactSnapshots
  };

  const directory = siteAnalysisDir || path.dirname(bundleFile);
  fs.mkdirSync(directory, { recursive: true });
  const aiFile = path.join(directory, `ai-input__${safeAnalysisHost(rawUrl)}__${safeAnalysisRoute(rawUrl)}.json`);
  fs.writeFileSync(aiFile, JSON.stringify(aiInput, null, 2), "utf8");

  const trustedMappings = uniqueFields
    .filter((field) => field.coreMappingStatus === "trusted" && !!field.coreFieldKey && !!field.coreCategory)
    .map((field) => ({
      fieldId: field.fieldId,
      category: field.coreCategory,
      fieldKey: field.coreFieldKey,
      label: String(field.label || field.graphRowLabel || "").slice(0, 140),
      confidence: Number(field.coreMappingConfidence || 1),
      graphFieldId: field.graphFieldId,
      graphSectionId: field.graphSectionId,
      graphSectionTitle: field.graphSectionTitle,
      graphLinkConfidence: Number(field.graphLinkConfidence || 0),
      source: "local_core_trusted"
    }));

  const reviewFields = uniqueFields
    .filter((field) => field.coreMappingStatus !== "trusted" || !field.coreFieldKey)
    .map((field) => {
      const suggestion = deriveReviewSuggestion(field);
      return {
        fieldId: field.fieldId,
        section: field.section,
        sectionFieldIndex: Number(field.sectionFieldIndex || 0),
        sameSemanticOrdinal: Number(field.sameSemanticOrdinal || 1),
        sameSemanticCount: Number(field.sameSemanticCount || 1),
        graphFieldId: field.graphFieldId,
        graphSectionId: field.graphSectionId,
        graphSectionTitle: field.graphSectionTitle,
        graphRowId: field.graphRowId,
        graphRowLabel: field.graphRowLabel,
        graphLinkMethod: field.graphLinkMethod,
        graphLinkConfidence: Number(field.graphLinkConfidence || 0),
        label: field.label,
        labelSource: field.labelSource,
        semanticCandidates: field.semanticCandidates,
        structuralTokens: uniqueStringList(field.structuralTokens, 12),
        controlType: field.controlType,
        widgetFamily: field.widgetFamily,
        options: field.options,
        selectorHint: field.selectorHint,
        selectorHitCount: field.selectorHitCount,
        widgetSelectorHint: field.widgetSelectorHint,
        widgetSelectorHitCount: field.widgetSelectorHitCount,
        patchTarget: patchTargetForField(field),
        coreCategory: field.coreCategory,
        coreCategoryConfidence: field.coreCategoryConfidence,
        suggestedCoreFieldKey: suggestion.fieldKey,
        suggestedCoreMappingStatus: suggestion.status,
        suggestedCoreMappingMethod: suggestion.method,
        suggestedCoreMappingConfidence: suggestion.confidence,
        suggestedCoreMappingEvidence: field.coreMappingEvidence,
        reviewReasons: suggestion.reasons
      };
    });
  const reviewRequest = {
    schemaType: "autofill-lite-ai-mapping-review-request",
    schemaVersion: 2,
    generatedAt: aiInput.generatedAt,
    page: aiInput.page,
    safety: aiInput.safety,
    coreContext: aiInput.coreContext,
    mappingSummary: aiInput.mappingSummary,
    profileContract: {
      categories: AI_PROFILE_FIELD_KEYS,
      fieldSemantics: AI_PROFILE_FIELD_SEMANTICS,
      crossCategoryMappingAllowed: true,
      unknownKeysForbidden: true
    },
    trustedMappings,
    outputContract: {
      mustBeDeclarative: true,
      outputSchemaType: "autofill-lite-ai-semantic-patch",
      mayInventResumeValues: false,
      mayWriteJavascript: false,
      mayChangeSelectors: false,
      mayChangeCategory: true,
      mayClickSaveSubmitApplyDeleteUpload: false,
      mustPreserveTrustedMappings: true,
      mustReferenceFieldId: true,
      mapCategoryAndFieldKeyMustExistInProfileContract: true,
      allowedDecisions: ["map", "leave_unmapped", "needs_special_workflow"]
    },
    reviewFields
  };
  const reviewFile = path.join(directory, `ai-review__${safeAnalysisHost(rawUrl)}__${safeAnalysisRoute(rawUrl)}.json`);
  fs.writeFileSync(reviewFile, JSON.stringify(reviewRequest, null, 2), "utf8");

  return {
    file: aiFile,
    reviewFile,
    snapshotCount: snapshots.length,
    totalFieldCount: uniqueFields.length,
    totalFieldOccurrenceCount: allFields.length,
    mappedFieldCount: trustedMappedFieldCount,
    tentativeMappedFieldCount,
    unmappedFieldCount,
    aiMappingNeededFieldCount: tentativeMappedFieldCount + unmappedFieldCount,
    legacySnapshotCountExcluded: legacySnapshotCount,
    emptySnapshotCountExcluded: sourceSnapshots.length - snapshots.length - legacySnapshotCount
  };
}

module.exports = {
  buildAiSiteInput,
  compactAiField,
  compactFormGraph,
  snapshotHasAiEvidence,
  safeAnalysisHost,
  safeAnalysisRoute,
  annotateSnapshotFields,
  mergeUniqueFields,
  deriveReviewSuggestion,
  patchTargetForField,
  isStablePatchSelector,
  expectedCategoryFromModuleTitle,
  interactiveFieldSignature,
  compactTrustedInteractiveModules,
  AI_PROFILE_FIELD_KEYS,
  AI_PROFILE_FIELD_SEMANTICS
};
