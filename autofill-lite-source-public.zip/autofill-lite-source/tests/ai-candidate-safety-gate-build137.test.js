"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const { compileAiCandidateSafetyGate } = require("../ai-candidate-safety-gate");

const review = {
  page: { hostname: "example.com", pathname: "/resume" },
  trustedMappings: [
    { fieldId: "trusted1", category: "basicInfo", fieldKey: "email", label: "电子邮箱", confidence: 1 }
  ],
  reviewFields: [
    { fieldId: "a1", label: "姓名全拼", controlType: "text", patchTarget: { kind: "semantic_label", label: "姓名全拼" } },
    { fieldId: "a2", label: "是否接受调剂", controlType: "radio", selectorCandidates: [{ kind: "name", selector: 'input[name="adjust"]', hitCount: 2 }], patchTarget: { kind: "unique_selector", selector: '#adjust-yes' } },
    { fieldId: "a3", label: "毕业院校", controlType: "text", patchTarget: { kind: "semantic_label", label: "毕业院校" } },
    { fieldId: "a4", label: "电子邮箱", controlType: "text", patchTarget: { kind: "semantic_label", label: "电子邮箱" } },
    { fieldId: "a5", label: "手机号", controlType: "element-select", patchTarget: { kind: "semantic_label", label: "手机号" } },
    { fieldId: "a6", label: "模糊字段", controlType: "text", patchTarget: { kind: "semantic_label", label: "模糊字段" } },
    { fieldId: "a7", label: "复杂经历", controlType: "text", patchTarget: { kind: "semantic_label", label: "复杂经历" } }
  ]
};

const patch = {
  schemaType: "autofill-lite-ai-semantic-patch",
  schemaVersion: 1,
  decisions: [
    { fieldId: "a1", decision: "map", category: "basicInfo", fieldKey: "name", confidence: 0.97 },
    { fieldId: "a2", decision: "map", category: "jobIntention", fieldKey: "acceptAdjustment", confidence: 0.95 },
    { fieldId: "a3", decision: "map", category: "education", fieldKey: "school", confidence: 0.99 },
    { fieldId: "a4", decision: "map", category: "basicInfo", fieldKey: "phone", confidence: 0.99 },
    { fieldId: "a5", decision: "map", category: "basicInfo", fieldKey: "phone", confidence: 0.98 },
    { fieldId: "a6", decision: "map", category: "basicInfo", fieldKey: "healthStatus", confidence: 0.84 },
    { fieldId: "a7", decision: "needs_special_workflow", category: "", fieldKey: "", confidence: 0.98 }
  ]
};

const gate = compileAiCandidateSafetyGate(review, patch, {});
assert.strictEqual(gate.mode, "decision_only");
assert.strictEqual(gate.policy.autoApply, false);
assert.strictEqual(gate.policy.autoExecute, false);
assert.strictEqual(gate.policy.aiMayChooseRepeatRecordOwner, false);
assert.strictEqual(gate.policy.eligibleCandidatesMustReenterAutofillCore, true);
assert.strictEqual(gate.summary.eligibleForCore, 2, "high-confidence scalar text/radio fields should become execution-eligible candidates");
assert.ok(gate.executableCandidates.some((x) => x.fieldId === "a1"));
assert.ok(gate.executableCandidates.some((x) => x.fieldId === "a2"));
assert.ok(gate.reviewOnlyCandidates.some((x) => x.fieldId === "a3" && x.reasons.includes("repeat_record_requires_recordgraph_ownership")), "repeat records must never bypass RecordGraph ownership");
assert.ok(gate.rejectedCandidates.some((x) => x.fieldId === "a4" && x.reasons.includes("trusted_local_mapping_conflict")), "trusted local mapping must win over AI conflict");
assert.ok(gate.reviewOnlyCandidates.some((x) => x.fieldId === "a5"), "complex control must remain review-only");
assert.ok(gate.reviewOnlyCandidates.some((x) => x.fieldId === "a6" && x.reasons.includes("confidence_below_sensitive_auto_threshold")), "medium confidence must remain review-only");
assert.ok(gate.rejectedCandidates.some((x) => x.fieldId === "a7" && x.reasons.includes("needs_special_workflow")), "AI-requested special workflow must never be executable");

const specialGate = compileAiCandidateSafetyGate(review, {
  schemaType: patch.schemaType,
  schemaVersion: 1,
  decisions: [{ fieldId: "a1", decision: "map", category: "basicInfo", fieldKey: "name", confidence: 0.99 }]
}, { matchedWorkflowId: "known-special-flow" });
assert.strictEqual(specialGate.summary.eligibleForCore, 0);
assert.ok(specialGate.reviewOnlyCandidates.some((x) => x.reasons.includes("special_workflow_owns_page_execution")));

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const buildMatch = main.match(/const BUILD_ID = "([^"]+)";/);
assert(buildMatch && /-(?:13[7-9]|1[4-9]\d|[2-9]\d{2,})$/.test(buildMatch[1]), "Safety Gate must remain present after Build137");
assert(main.includes("compileAiCandidateSafetyGate"), "main must compile Safety Gate decisions");
assert(main.includes("foundation.safetyGate"), "post-fill AI Gap must expose Safety Gate output");
assert(main.includes("safeSelectorMappings"), "controlled apply must filter selector mappings through Safety Gate");
assert(main.includes("eligibleIds.has"), "only Safety-Gate eligible fieldIds may re-enter Core");
assert(main.includes("fieldMappings: []"), "controlled apply must never install AI label mappings directly");
assert(main.includes("selectorMappings: safeSelectorMappings"), "controlled re-entry must remain selector-gated");

console.log("ai-candidate-safety-gate-build137.test.js PASS");
