"use strict";
const assert = require("assert");
const path = require("path");

class FakeElement {
  constructor(tag, opts = {}) {
    this.nodeType = 1;
    this.tagName = String(tag || "div").toUpperCase();
    this.id = opts.id || "";
    this.type = opts.type || "";
    this.className = opts.className || "";
    this.classList = this.className.split(/\s+/).filter(Boolean);
    this.attrs = Object.assign({}, opts.attrs || {});
    this.textContent = opts.text || "";
    this.required = !!opts.required;
    this.checked = !!opts.checked;
    this.value = opts.value || "";
    this.options = opts.options || [];
    this.children = [];
    this.parentElement = null;
    this.previousElementSibling = null;
    this.isConnected = true;
    this._kind = opts.kind || "";
    this._isControl = !!opts.control;
    this._isLabel = !!opts.label;
    this._isHeading = !!opts.heading;
    this._isRadioOption = !!opts.radioOption;
    this._rect = opts.rect || { left: 0, top: 0, width: 100, height: 24 };
  }
  append(...nodes) {
    nodes.forEach(node => {
      if (this.children.length) node.previousElementSibling = this.children[this.children.length - 1];
      node.parentElement = this;
      this.children.push(node);
    });
    return this;
  }
  getAttribute(name) {
    if (name === "class") return this.className;
    if (name === "type") return this.type || null;
    return Object.prototype.hasOwnProperty.call(this.attrs, name) ? this.attrs[name] : null;
  }
  contains(node) {
    if (node === this) return true;
    return this.children.some(child => child.contains(node));
  }
  getBoundingClientRect() { return this._rect; }
  _descendants() {
    const out = [];
    const visit = n => { n.children.forEach(c => { out.push(c); visit(c); }); };
    visit(this);
    return out;
  }
  querySelectorAll(selector) {
    const nodes = this._descendants();
    if (selector.includes("input:not") && selector.includes(".ant-select") && selector.includes("[role='textbox']")) {
      return nodes.filter(n => n._isControl);
    }
    if (selector.includes(".ant-form-item-label") && selector.includes("[class*='label']")) {
      return nodes.filter(n => n._isLabel);
    }
    if (selector.includes("h1") && selector.includes("legend") && selector.includes("section-title")) {
      return nodes.filter(n => n._isHeading);
    }
    if (selector.includes("label,.ant-radio-wrapper")) {
      return nodes.filter(n => n._isRadioOption || n._isLabel);
    }
    if (selector.startsWith("#")) {
      const id = selector.slice(1).replace(/\\/g, "");
      return [this, ...nodes].filter(n => n.id === id);
    }
    const attrMatch = selector.match(/^([a-z*]+)\[([^=]+)=\"([^\"]*)\"\]$/i);
    if (attrMatch) {
      const [, tag, attr, value] = attrMatch;
      return [this, ...nodes].filter(n => (tag === "*" || n.tagName.toLowerCase() === tag.toLowerCase()) && String(n.getAttribute(attr) || "") === value);
    }
    return [];
  }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
  closest(selector) {
    let cur = this;
    while (cur) {
      if (selector.includes("[role='radiogroup']") && cur._kind === "radio-group") return cur;
      if ((selector.includes(".ant-select") || selector.includes(".phoenix-select")) && cur._kind === "widget-host") return cur;
      if (selector.includes(".phoenix-radio-group") && cur._kind === "phoenix-radio-group") return cur;
      if (selector.includes(".ant-form-item") && cur._kind === "row") return cur;
      if (selector.includes("section") && cur._kind === "section") return cur;
      cur = cur.parentElement;
    }
    return null;
  }
}

class FakeDocument {
  constructor(body) { this.body = body; this.title = "Fixture"; }
  querySelectorAll(selector) { return this.body.querySelectorAll(selector); }
  querySelector(selector) {
    const labelFor = selector.match(/^label\[for=\"([^\"]+)\"\]$/);
    if (labelFor) {
      return [this.body, ...this.body._descendants()].find(n => n._isLabel && n.getAttribute("for") === labelFor[1]) || null;
    }
    return this.body.querySelector(selector);
  }
}

function rect(y) { return { left: 20, top: y, width: 500, height: 40 }; }

// Fixture: one education section, two rows, native input + select.
const body = new FakeElement("body", { id: "body", kind: "body", rect: rect(0) });
const section = new FakeElement("section", { id: "education-section", kind: "section", rect: rect(100) });
const title = new FakeElement("h2", { text: "教育信息", heading: true, rect: rect(100) });
const row1 = new FakeElement("div", { id: "row-school", className: "ant-form-item", kind: "row", rect: rect(150) });
const label1 = new FakeElement("label", { text: "学校名称 *", label: true, attrs: { for: "school" }, rect: rect(150) });
const school = new FakeElement("input", { id: "school", type: "text", control: true, attrs: { name: "school", placeholder: "请输入学校" }, rect: rect(150), value: "SENSITIVE SHOULD NOT APPEAR" });
row1.append(label1, school);
const row2 = new FakeElement("div", { id: "row-degree", className: "ant-form-item is-required", kind: "row", rect: rect(200) });
const label2 = new FakeElement("label", { text: "学历", label: true, attrs: { for: "degree" }, rect: rect(200) });
const degree = new FakeElement("select", { id: "degree", control: true, required: true, attrs: { name: "degree" }, rect: rect(200), options: [
  new FakeElement("option", { text: "本科" }), new FakeElement("option", { text: "硕士" })
] });
row2.append(label2, degree);
section.append(title, row1, row2);
body.append(section);

const document = new FakeDocument(body);
global.document = document;
global.location = { href: "https://example.test/resume?token=secret", hostname: "example.test", pathname: "/resume" };
global.getComputedStyle = () => ({ display: "block", visibility: "visible", opacity: "1" });
global.CSS = { escape: s => String(s).replace(/([^A-Za-z0-9_-])/g, "\\$1") };

const modulePath = path.resolve(__dirname, "..", "autofill-plugin", "content", "form-graph.js");
delete require.cache[require.resolve(modulePath)];
const graphApi = require(modulePath);
const graph1 = graphApi.scan(body, { document });
const graph2 = graphApi.scan(body, { document });

assert.deepStrictEqual(graph1, graph2, "same DOM must produce the same graph and IDs");
assert.strictEqual(graph1.schemaType, "autofill-lite-form-graph");
assert.strictEqual(graph1.page.hostname, "example.test");
assert.strictEqual(graph1.page.pathname, "/resume", "query string must not be retained");
assert.strictEqual(graph1.totals.sections, 1);
assert.strictEqual(graph1.totals.rows, 2);
assert.strictEqual(graph1.totals.controls, 2);
assert.strictEqual(graph1.sections[0].title, "教育信息");
assert.strictEqual(graph1.sections[0].rows[0].label, "学校名称");
assert.strictEqual(graph1.sections[0].rows[1].label, "学历");
assert.strictEqual(graph1.sections[0].rows[1].controls[0].controlType, "native-select");
assert.deepStrictEqual(graph1.sections[0].rows[1].controls[0].options, ["本科", "硕士"]);
assert.strictEqual(graph1.safety.currentValuesIncluded, false);
assert(!JSON.stringify(graph1).includes("SENSITIVE SHOULD NOT APPEAR"), "current field values leaked into graph");
assert(!JSON.stringify(graph1).includes("token=secret"), "URL query leaked into graph");

// Fixture: visual wrapper with an Ant select host should be one control, not its internal input.
const body2 = new FakeElement("body", { id: "body2", kind: "body" });
const section2 = new FakeElement("section", { id: "basic-section", kind: "section", rect: rect(100) });
const title2 = new FakeElement("h2", { text: "基本信息", heading: true, rect: rect(100) });
const row3 = new FakeElement("div", { id: "row-gender", className: "ant-form-item", kind: "row", rect: rect(150) });
const label3 = new FakeElement("label", { text: "性别", label: true, rect: rect(150) });
const antSelect = new FakeElement("div", { id: "gender-select", className: "ant-select", kind: "widget-host", control: true, attrs: { role: "combobox" }, rect: rect(150) });
const internal = new FakeElement("input", { id: "gender-internal", type: "text", control: true, attrs: { role: "textbox" }, rect: rect(150) });
antSelect.append(internal);
row3.append(label3, antSelect);
section2.append(title2, row3);
body2.append(section2);
const document2 = new FakeDocument(body2);
global.document = document2;
const graph3 = graphApi.scan(body2, { document: document2 });
assert.strictEqual(graph3.totals.controls, 1, "internal input of an already captured custom select should be deduplicated");
assert.strictEqual(graph3.controls[0].controlType, "custom-select");
assert.strictEqual(graph3.controls[0].widgetFamily, "ant");

// Fixture: Phoenix select wrapper + internal input must canonicalize to one logical control.
const body3 = new FakeElement("body", { id: "body3", kind: "body" });
const section3 = new FakeElement("section", { id: "intention-section", kind: "section", rect: rect(100) });
const title3 = new FakeElement("h2", { text: "求职意向", heading: true, rect: rect(100) });
const row4 = new FakeElement("div", { id: "row-city", className: "form-item", kind: "row", rect: rect(150) });
const label4 = new FakeElement("label", { text: "期望工作城市", label: true, rect: rect(150) });
const phoenixSelect = new FakeElement("div", { id: "city-select", className: "phoenix-select", kind: "widget-host", control: true, rect: rect(150) });
const phoenixInput = new FakeElement("input", { id: "city-input", type: "text", control: true, className: "phoenix-select__input", rect: rect(151) });
phoenixSelect.append(phoenixInput);
row4.append(label4, phoenixSelect);
section3.append(title3, row4);
body3.append(section3);
const document3 = new FakeDocument(body3);
global.document = document3;
const graph4 = graphApi.scan(body3, { document: document3 });
assert.strictEqual(graph4.totals.controls, 1, "Phoenix internal input must not duplicate its mature widget host");
assert.strictEqual(graph4.controls[0].controlType, "custom-select");
assert.strictEqual(graph4.controls[0].widgetFamily, "phoenix");

// Mature Phoenix radio wrapper should be typed as one radio-group control.
const phoenixRadio = new FakeElement("div", { id: "gender-radio", className: "phoenix-radio-group", kind: "phoenix-radio-group", control: true, rect: rect(180) });
assert.strictEqual(graphApi.__test.detectControlType(phoenixRadio), "radio-group");

console.log("form graph fixtures: PASS");
