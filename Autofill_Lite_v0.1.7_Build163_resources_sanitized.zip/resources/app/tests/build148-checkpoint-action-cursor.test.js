"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
assert(/const BUILD_ID = "202609\d{2}-.+-(?:14[8-9]|1[5-9]\d|[2-9]\d{2,})";/.test(main), "Build148+ compatible build ID missing");

const formSource = fs.readFileSync(path.join(root, "autofill-plugin/content/form-handler.js"), "utf8");
const runtimeSource = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-runtime.js"), "utf8");
const fillSource = fs.readFileSync(path.join(root, "autofill-plugin/content/fill-engine.js"), "utf8");

assert(formSource.includes('acknowledgeMode: "resume_at_action_cursor"'), "manual review must persist action cursor mode");
assert(formSource.includes('actionCursor: "SAVE"'), "review resume must advance to SAVE cursor");
assert(formSource.includes('fieldReplaySuppressed: true'), "review resume must freeze all earlier field actions");
assert(formSource.includes('startMappingIndex'), "action-cursor resume must have a mapping start cursor");
assert(!formSource.includes('autoSaveAttemptedAfterManualReview: true'), "Build148 should not auto-save a review checkpoint");
assert(runtimeSource.includes('acknowledgeMode !== "resume_at_action_cursor"'), "action-cursor review must not pre-complete its record");
assert(runtimeSource.includes('nextAction:'), "checkpoint must persist next action");
assert(runtimeSource.includes('freezeBeforeCursor:'), "checkpoint must persist frozen-prefix semantics");
assert(fillSource.includes('resumeRepeatCursorWithoutEditor'), "post-save no-editor cursor recovery missing");
assert(fillSource.includes('reasonCode: "manual_示例资料_editor_open_required"'), "post-save next-editor checkpoint missing");

// Runtime-level test for the post-save cursor. This directly covers the bug where
// a manually saved card leaves no editor in the DOM and Structured mode used to
// fail with "未找到标题元素" before the recovery cursor could advance.
global.location = { href: "https://example.test/resume", hostname: "example.test", pathname: "/resume" };
global.window = {
  location: global.location,
  AF: {
    DataMatcher: function DataMatcher() {},
    FormHandler: function FormHandler() { this.filledFieldsCount = 0; this.failedFields = []; },
    Utils: { async sleep() {} },
    DomUtils: { isElementVisible() { return true; } }
  }
};
global.document = { documentElement: { style: {} } };
require(path.join(root, "autofill-plugin/content/fill-engine.js"));
const AF = window.AF;

(async () => {
  const engine = new AF.FillEngine({}, { config: {} });
  let pause = null;
  engine.recordCheckpointRuntime = {
    resumed: true,
    previousCheckpoint: {
      granularity: "record",
      reasonCode: "manual_record_save_required",
      category: "示例资料",
      sectionTitle: "教育背景",
      示例资料Index: 0,
      示例资料Total: 2
    }
  };
  engine.fieldCheckpointRuntime = {
    resumed: false,
    previousCheckpoint: null,
    async pause(meta, reason, opts) {
      pause = { meta, reason, opts };
      return { active: meta };
    }
  };

  const next = await engine.resumeRepeatCursorWithoutEditor();
  assert.strictEqual(next.success, false, "saved record with remaining row should pause for next editor");
  assert(pause, "next-editor checkpoint was not created");
  assert.strictEqual(pause.opts.reasonCode, "manual_示例资料_editor_open_required");
  assert.strictEqual(pause.opts.acknowledgeMode, "resume_at_action_cursor");
  assert.strictEqual(pause.opts.nextAction, "FILL_NEXT_RECORD");
  assert.strictEqual(pause.opts.freezeBeforeCursor, true);
  assert.strictEqual(pause.meta.示例资料Index, 1, "cursor should advance from record 0 to record 1");
  assert.strictEqual(engine.formHandler.lastExperienceResult.actionCursor, "OPEN_NEXT_RECORD");
  assert.strictEqual(engine.formHandler.lastExperienceResult.fieldReplaySuppressed, true);

  // Last record: no editor after manual save means the section is complete, not
  // an error and not a request to replay the record.
  const engine2 = new AF.FillEngine({}, { config: {} });
  engine2.recordCheckpointRuntime = {
    resumed: true,
    previousCheckpoint: {
      granularity: "record",
      reasonCode: "manual_record_save_required",
      category: "示例资料",
      sectionTitle: "教育背景",
      示例资料Index: 1,
      示例资料Total: 2
    }
  };
  engine2.fieldCheckpointRuntime = { resumed: false, previousCheckpoint: null, async pause() { throw new Error("last record must not request an示例资料 editor"); } };
  const done = await engine2.resumeRepeatCursorWithoutEditor();
  assert.strictEqual(done.success, true);
  assert.strictEqual(engine2.formHandler.lastExperienceResult.actionCursor, "SECTION_DONE");
  assert.strictEqual(engine2.formHandler.lastExperienceResult.fieldReplaySuppressed, true);

  console.log("build148-checkpoint-action-cursor.test.js PASS");
})().catch(err => { console.error(err); process.exit(1); });
