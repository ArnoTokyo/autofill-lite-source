这里用于本地 Site Config。v0.1 不连接原作者配置服务器。
优先文件名：<hostname>__<route>.json，其次 <hostname>.json。
未知网站请先保存失败日志，再让 Codex 基于当前页面脱敏结构制作本地 config。
