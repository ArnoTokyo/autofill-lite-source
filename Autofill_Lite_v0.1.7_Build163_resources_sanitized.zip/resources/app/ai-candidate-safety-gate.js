"use strict";

const { compileRuntimeSemanticOverlay } = require("./ai-semantic-overlay");

function clean(value) {
  return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
}

function norm(value) {
  return clean(value).replace(/[\s：:*?？（）()【】\[\]「」'"“”‘’.,，。;；、]/g, "").toLowerCase();
}

function clampConfidence(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(1, n));
}

const REPEAT_CATEGORIES = new Set([
  "示例资料",
  "示例资料Experience",
  "示例资料Experience",
  "示例资料Experience",
  "示例资料Experience",
  "示例资料",
  "示例资料Skills",
  "示例资料",
  "campusLeadership",
  "campusActivities",
  "示例资料Members",
  "publications",
  "示例资料s"
]);

const AUTO_SAFE_CONTROL_TYPES = new Set([
  "text",
  "textarea",
  "native-select",
  "radio",
  "checkbox",
  "date",
  "month",
  "select",
  "search"
]);

const COMPLEX_CONTROL_RE = /cascader|autocomplete|tree|transfer|upload|editor|rich|range/i;
const SENSITIVE_SCALAR_KEYS = new Set(["phone", "email", "idNumber", "qq", "wechat", "homepage"]);
const HIGH_RISK_SCALAR_KEYS = new Set(["idNumber", "politicalStatus", "maritalStatus", "healthStatus"]);

function sensitiveLabelLooksCompatible(fieldKey, label) {
  const text = clean(label);
  if (!SENSITIVE_SCALAR_KEYS.has(fieldKey)) return true;
  if (fieldKey === "phone") return /手机|电话|联系电话|mobile|phone/i.test(text);
  if (fieldKey === "email") return /邮箱|邮件|email|e-mail/i.test(text);
  if (fieldKey === "idNumber") return /证件|身份证|id/i.test(text);
  if (fieldKey === "qq") return /qq/i.test(text);
  if (fieldKey === "wechat") return /微信|wechat|weixin/i.test(text);
  if (fieldKey === "homepage") return /主页|网址|链接|网站|homepage|url|website/i.test(text);
  return false;
}

function semanticEvidenceScore(field, fieldKey, label) {
  let score = 0;
  const source = clean(field && field.labelSource);
  if (label && source && source !== "nearby_text") score += 1;
  if (Number(field && field.graphLinkConfidence || 0) >= 0.9) score += 1;
  if (clean(field && field.suggestedCoreFieldKey) === clean(fieldKey) && Number(field && field.suggestedCoreMappingConfidence || 0) >= 0.75) score += 1;
  const semantic = Array.isArray(field && field.semanticCandidates) ? field.semanticCandidates.map(norm) : [];
  if (label && semantic.includes(norm(label))) score += 1;
  return score;
}

function pushReason(row, reason) {
  if (!reason) return;
  row.reasons = Array.isArray(row.reasons) ? row.reasons : [];
  if (!row.reasons.includes(reason)) row.reasons.push(reason);
}

function trustedConflictFor(decision, field, trustedMappings) {
  const target = field && field.patchTarget && typeof field.patchTarget === "object" ? field.patchTarget : {};
  const label = clean(target.label || field && field.label || field && field.graphRowLabel || "");
  const category = clean(decision && decision.category);
  const fieldKey = clean(decision && decision.fieldKey);
  const fieldId = clean(decision && decision.fieldId);
  for (const trusted of Array.isArray(trustedMappings) ? trustedMappings : []) {
    const trustedCategory = clean(trusted && trusted.category);
    const trustedFieldKey = clean(trusted && trusted.fieldKey);
    const trustedLabel = clean(trusted && trusted.label);
    const trustedFieldId = clean(trusted && trusted.fieldId);
    const sameFieldId = fieldId && trustedFieldId && fieldId === trustedFieldId;
    const sameSemanticLabel = category && trustedCategory === category && label && trustedLabel && norm(label) === norm(trustedLabel);
    if ((sameFieldId || sameSemanticLabel) && trustedFieldKey && trustedFieldKey !== fieldKey) {
      return {
        conflict: true,
        trustedCategory,
        trustedFieldKey,
        trustedLabel,
        reason: "trusted_local_mapping_conflict"
      };
    }
    if ((sameFieldId || sameSemanticLabel) && trustedFieldKey === fieldKey && trustedCategory === category) {
      return {
        conflict: false,
        redundant: true,
        trustedCategory,
        trustedFieldKey,
        trustedLabel,
        reason: "trusted_local_mapping_already_owns_field"
      };
    }
  }
  return { conflict: false, redundant: false };
}

function compileAiCandidateSafetyGate(review, patch, context, options) {
  const opts = Object.assign({ reviewThreshold: 0.50, autoEligibleThreshold: 0.65, sensitiveAutoThreshold: 0.85, evidenceAutoThreshold: 0.50 }, options || {});
  const ctx = context && typeof context === "object" ? context : {};
  const reviewFields = Array.isArray(review && review.reviewFields) ? review.reviewFields : [];
  const decisions = Array.isArray(patch && patch.decisions) ? patch.decisions : [];
  const trustedMappings = Array.isArray(review && review.trustedMappings) ? review.trustedMappings : [];
  const byId = new Map(reviewFields.map((field) => [clean(field && field.fieldId), field]));
  const overlay = compileRuntimeSemanticOverlay(review || {}, patch || {}, { minConfidence: Number(opts.reviewThreshold || 0.50) });
  const acceptedIds = new Set();
  (Array.isArray(overlay && overlay.fieldMappings) ? overlay.fieldMappings : []).forEach((item) => acceptedIds.add(clean(item && item.fieldId)));
  (Array.isArray(overlay && overlay.selectorMappings) ? overlay.selectorMappings : []).forEach((item) => acceptedIds.add(clean(item && item.fieldId)));
  const skippedById = new Map();
  (Array.isArray(overlay && overlay.skipped) ? overlay.skipped : []).forEach((item) => {
    const id = clean(item && item.fieldId);
    if (id && !skippedById.has(id)) skippedById.set(id, clean(item && item.reason));
  });

  const executableCandidates = [];
  const reviewOnlyCandidates = [];
  const rejectedCandidates = [];
  const specialWorkflowOwned = !!clean(ctx.matchedWorkflowId);

  decisions.forEach((decision) => {
    const fieldId = clean(decision && decision.fieldId);
    const field = byId.get(fieldId);
    const kind = clean(decision && decision.decision);
    const confidence = clampConfidence(decision && decision.confidence);
    const category = clean(decision && decision.category);
    const fieldKey = clean(decision && decision.fieldKey);
    const target = field && field.patchTarget && typeof field.patchTarget === "object" ? field.patchTarget : {};
    const label = clean(target.label || field && field.label || field && field.graphRowLabel || "");
    const controlType = clean(field && field.controlType).toLowerCase();
    const targetKind = clean(target.kind);
    const row = {
      fieldId,
      label,
      category,
      fieldKey,
      confidence,
      controlType,
      targetKind,
      decision: kind,
      classification: "",
      evidenceScore: semanticEvidenceScore(field, fieldKey, label),
      reasons: []
    };

    if (!field) {
      row.classification = "rejected";
      pushReason(row, "unknown_field_id");
      rejectedCandidates.push(row);
      return;
    }
    if (kind !== "map") {
      row.classification = "rejected";
      pushReason(row, kind === "needs_special_示例资料flow" ? "needs_special_示例资料flow" : "ai_left_unmapped");
      rejectedCandidates.push(row);
      return;
    }
    if (!category || !fieldKey) {
      row.classification = "rejected";
      pushReason(row, "empty_mapping_identity");
      rejectedCandidates.push(row);
      return;
    }
    if (confidence < Number(opts.reviewThreshold || 0.50)) {
      row.classification = "rejected";
      pushReason(row, "confidence_below_review_threshold");
      rejectedCandidates.push(row);
      return;
    }

    const trusted = trustedConflictFor(decision, field, trustedMappings);
    if (trusted.conflict) {
      row.classification = "rejected";
      pushReason(row, trusted.reason);
      row.trustedMapping = {
        category: trusted.trustedCategory,
        fieldKey: trusted.trustedFieldKey,
        label: trusted.trustedLabel
      };
      rejectedCandidates.push(row);
      return;
    }
    if (trusted.redundant) {
      row.classification = "rejected";
      pushReason(row, trusted.reason);
      rejectedCandidates.push(row);
      return;
    }

    // RepeatRecord semantics are useful to a graph-backed SiteConfig even though
    // they must never be executed through a raw selector overlay.  Classify them
    // before the direct-runtime overlay gate: AI may say "this is 示例资料Members.name",
    // while RecordGraph/ExperienceHandler still decides which record owns the field.
    if (REPEAT_CATEGORIES.has(category)) {
      if (!label) {
        row.classification = "rejected";
        pushReason(row, "示例资料_record_semantic_label_missing");
        rejectedCandidates.push(row);
        return;
      }
      row.classification = "review_only";
      pushReason(row, "示例资料_record_requires_recordgraph_ownership");
      row.semanticPolicy = "site_config_semantics_only";
      reviewOnlyCandidates.push(row);
      return;
    }

    if (!acceptedIds.has(fieldId)) {
      row.classification = "rejected";
      pushReason(row, skippedById.get(fieldId) || "runtime_overlay_safety_rejected");
      rejectedCandidates.push(row);
      return;
    }

    if (specialWorkflowOwned) {
      row.classification = "review_only";
      pushReason(row, "special_示例资料flow_owns_page_execution");
      row.matchedWorkflowId = clean(ctx.matchedWorkflowId);
      reviewOnlyCandidates.push(row);
      return;
    }

    if (!controlType) {
      row.classification = "review_only";
      pushReason(row, "control_metadata_missing");
      reviewOnlyCandidates.push(row);
      return;
    }

    if (COMPLEX_CONTROL_RE.test(controlType) || !AUTO_SAFE_CONTROL_TYPES.has(controlType)) {
      row.classification = "review_only";
      pushReason(row, "control_requires_existing_adapter_or_manual_review");
      reviewOnlyCandidates.push(row);
      return;
    }

    if (!sensitiveLabelLooksCompatible(fieldKey, label)) {
      row.classification = "review_only";
      pushReason(row, "sensitive_scalar_label_evidence_insufficient");
      reviewOnlyCandidates.push(row);
      return;
    }

    const highRisk = HIGH_RISK_SCALAR_KEYS.has(fieldKey) || SENSITIVE_SCALAR_KEYS.has(fieldKey);
    const defaultAutoThreshold = highRisk
      ? Number(opts.sensitiveAutoThreshold || 0.85)
      : Number(opts.autoEligibleThreshold || 0.65);
    const strongEvidenceOverride = !highRisk && row.evidenceScore >= 2 && confidence >= Number(opts.evidenceAutoThreshold || 0.50);
    if (confidence < defaultAutoThreshold && !strongEvidenceOverride) {
      row.classification = "review_only";
      pushReason(row, highRisk ? "confidence_below_sensitive_auto_threshold" : "confidence_below_auto_eligible_threshold");
      reviewOnlyCandidates.push(row);
      return;
    }

    row.classification = "eligible_for_core";
    pushReason(row, strongEvidenceOverride && confidence < defaultAutoThreshold
      ? "passed_by_strong_local_semantic_evidence"
      : "passed_risk_tiered_scalar_candidate_safety_gate");
    row.executionPolicy = "core_only_no_direct_page_action";
    executableCandidates.push(row);
  });

  return {
    schemaType: "autofill-lite-ai-candidate-safety-gate",
    schemaVersion: 1,
    mode: "decision_only",
    thresholds: {
      review: Number(opts.reviewThreshold || 0.50),
      autoEligible: Number(opts.autoEligibleThreshold || 0.65),
      sensitiveAuto: Number(opts.sensitiveAutoThreshold || 0.85),
      evidenceAuto: Number(opts.evidenceAutoThreshold || 0.50)
    },
    context: {
      matchedWorkflowId: clean(ctx.matchedWorkflowId),
      specialWorkflowOwned,
      localSupport: !!ctx.localSupport
    },
    executableCandidates,
    reviewOnlyCandidates,
    rejectedCandidates,
    summary: {
      totalDecisions: decisions.length,
      eligibleForCore: executableCandidates.length,
      reviewOnly: reviewOnlyCandidates.length,
      rejected: rejectedCandidates.length
    },
    policy: {
      autoApply: false,
      autoExecute: false,
      directPageActionsAllowed: false,
      directSaveSubmitApplyDeleteUploadAllowed: false,
      aiMayChooseRepeatRecordOwner: false,
      trustedLocalMappingsWin: true,
      eligibleCandidatesMustReenterAutofillCore: true,
      controlledCoreReentry: true,
      controlledCoreReentryScope: "risk_tiered_scalar_selector_with_existing_adapters",
      build138ExecutionPermission: "core_reentry_only_no_direct_ai_page_action"
    }
  };
}

module.exports = {
  compileAiCandidateSafetyGate,
  REPEAT_CATEGORIES,
  AUTO_SAFE_CONTROL_TYPES,
  sensitiveLabelLooksCompatible,
  semanticEvidenceScore,
  HIGH_RISK_SCALAR_KEYS
};
