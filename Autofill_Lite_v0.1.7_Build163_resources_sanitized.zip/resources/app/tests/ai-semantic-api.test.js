"use strict";
const assert = require("assert");
const {
  buildProviderRequest,
  buildProviderRetryRequest,
  parseProviderResponse,
  parseStructuredJsonText,
  validateSemanticPatch,
  summarizePatch,
  isDeepSeekEndpoint
} = require("../ai-semantic-api");

const review = {
  schemaType: "autofill-lite-ai-mapping-review-request",
  schemaVersion: 2,
  page: { hostname: "example.com", pathname: "/resume" },
  profileContract: { categories: { 示例资料Info: ["gender"], 示例资料: ["startTime", "endTime"] } },
  mappingSummary: { aiMappingNeededFieldCount: 3 },
  reviewFields: [
    { fieldId: "fld_gender", section: "基础信息", label: "", options: ["男", "女"] },
    { fieldId: "fld_date1", section: "示例资料", label: "选择日期" },
    { fieldId: "fld_date2", section: "示例资料", label: "选择日期" }
  ]
};
const settings = { provider: "openai-responses", endpoint: "https://api.openai.com/v1/responses", model: "gpt-test", reasoningEffort: "low", maxOutputTokens: 4000 };
const req = buildProviderRequest(settings, review);
assert.strictEqual(req.store, false);
assert.strictEqual(req.text.format.type, "json_schema");
assert.strictEqual(req.text.format.strict, true);
assert(JSON.stringify(req).includes("fld_gender"));
assert(JSON.stringify(req).includes("Return ONLY one valid JSON object"));

const deepseekSettings = { ...settings, endpoint: "https://api.deepseek.com/responses", model: "deepseek-v4-flash" };
assert.strictEqual(isDeepSeekEndpoint(deepseekSettings.endpoint), true);
const deepReq = buildProviderRequest(deepseekSettings, review);
assert.strictEqual(deepReq.text.format.type, "json_schema");
assert.strictEqual(Object.prototype.hasOwnProperty.call(deepReq.text.format, "strict"), false);
const deepRetry = buildProviderRetryRequest(deepseekSettings, review);
assert.strictEqual(deepRetry.text.format.type, "json_object");

const rawPatch = {
  schemaType: "autofill-lite-ai-semantic-patch",
  schemaVersion: 1,
  decisions: [
    { fieldId: "fld_gender", decision: "map", category: "示例资料Info", fieldKey: "gender", confidence: 0.95, reason: "男/女选项" },
    { fieldId: "fld_date1", decision: "map", category: "示例资料", fieldKey: "startTime", confidence: 0.9, reason: "第一日期" },
    { fieldId: "fld_date2", decision: "map", category: "示例资料", fieldKey: "endTime", confidence: 0.9, reason: "第二日期" }
  ]
};
const validated = validateSemanticPatch(review, rawPatch);
assert.strictEqual(validated.decisions.length, 3);
assert.deepStrictEqual(summarizePatch(validated), { mapped: 3, leftUnmapped: 0, needsSpecialWorkflow: 0 });
assert.throws(() => validateSemanticPatch(review, { ...rawPatch, decisions: rawPatch.decisions.slice(0, 2) }), /未覆盖全部/);
assert.throws(() => validateSemanticPatch(review, {
  ...rawPatch,
  decisions: rawPatch.decisions.map((d, i) => i === 0 ? { ...d, fieldKey: "madeUp" } : d)
}), /超出 profileContract/);
assert.throws(() => validateSemanticPatch(review, {
  ...rawPatch,
  decisions: rawPatch.decisions.map((d, i) => i === 0 ? { ...d, decision: "leave_unmapped", category: "示例资料Info", fieldKey: "gender" } : d)
}), /不得携带/);

const json = JSON.stringify(rawPatch);
const responseBody = { status: "completed", output: [{ type: "reasoning", content: [{ type: "reasoning_text", text: "ignore this" }] }, { type: "message", content: [{ type: "output_text", text: json }] }] };
assert.deepStrictEqual(parseProviderResponse("openai-responses", responseBody), rawPatch);
const chatBody = { choices: [{ message: { content: json } }] };
assert.deepStrictEqual(parseProviderResponse("openai-compatible-chat", chatBody), rawPatch);
assert.deepStrictEqual(parseStructuredJsonText("```json\n" + json + "\n```"), rawPatch);
assert.deepStrictEqual(parseStructuredJsonText("Here is the JSON:\n" + json + "\nDone."), rawPatch);
assert.throws(() => parseProviderResponse("openai-responses", { status: "incomplete", incomplete_details: { reason: "max_output_tokens" }, output: [] }), /未完成：max_output_tokens/);
console.log("ai-semantic-api.test.js PASS");
