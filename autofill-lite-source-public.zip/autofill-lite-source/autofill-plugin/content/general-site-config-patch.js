// content/general-site-config-patch.js — 插件端普通站点配置补丁运行时。
(function () {
  "use strict";

  var AF = (window.AF = window.AF || {});

  function normalizeHostname(value) {
    return String(value || "").trim().toLowerCase().replace(/\.$/, "");
  }

  function normalizeRouteKey(value) {
    var pathname = String(value || "").trim();
    if (!pathname || pathname === "default") return "default";
    try {
      if (/^https?:\/\//i.test(pathname)) pathname = new URL(pathname).pathname;
    } catch (e) {
      return "";
    }
    pathname = pathname
      .split("?")[0]
      .split("#")[0]
      .replace(/\/+/g, "/")
      .replace(/\/$/, "")
      .toLowerCase();
    if (pathname.charAt(0) !== "/") pathname = "/" + pathname;
    return pathname || "/";
  }

  function isPlainObject(value) {
    return Boolean(value) && Object.prototype.toString.call(value) === "[object Object]";
  }

  function cloneValue(value) {
    if (Array.isArray(value)) return value.map(cloneValue);
    if (!isPlainObject(value)) return value;
    var output = {};
    Object.keys(value).forEach(function (key) {
      if (key === "__proto__" || key === "prototype" || key === "constructor") return;
      output[key] = cloneValue(value[key]);
    });
    return output;
  }

  function mergePatch(base, patch) {
    if (!isPlainObject(patch)) return cloneValue(patch);
    var output = isPlainObject(base) ? cloneValue(base) : {};
    Object.keys(patch).forEach(function (key) {
      if (key === "__proto__" || key === "prototype" || key === "constructor") return;
      output[key] = isPlainObject(patch[key])
        ? mergePatch(output[key], patch[key])
        : cloneValue(patch[key]);
    });
    return output;
  }

  function hostnameMatches(pattern, hostname) {
    var expected = normalizeHostname(pattern);
    if (!expected) return false;
    if (expected.indexOf("*.") === 0) {
      var suffix = expected.slice(1);
      return hostname.slice(-suffix.length) === suffix && hostname.length > suffix.length;
    }
    return hostname === expected;
  }

  function routeMatches(pattern, routeKey) {
    if (pattern instanceof RegExp) {
      pattern.lastIndex = 0;
      return pattern.test(routeKey);
    }
    return normalizeRouteKey(pattern) === routeKey;
  }

  function matchesRule(rule, context) {
    if (!rule || rule.enabled === false || !isPlainObject(rule.patch)) return false;
    var match = rule.match || {};
    var hostnames = Array.isArray(match.hostnames)
      ? match.hostnames
      : match.hostname
        ? [match.hostname]
        : [];
    if (!hostnames.length || !hostnames.some(function (item) {
      return hostnameMatches(item, context.hostname);
    })) return false;

    var routePatterns = Array.isArray(match.routePatterns)
      ? match.routePatterns
      : match.routePattern
        ? [match.routePattern]
        : [];
    return !routePatterns.length || routePatterns.some(function (pattern) {
      return routeMatches(pattern, context.routeKey);
    });
  }

  function resolve(context) {
    context = {
      hostname: normalizeHostname(context && context.hostname),
      routeKey: normalizeRouteKey(context && context.routeKey || "default"),
    };
    if (!context.hostname || !context.routeKey) return [];
    return (AF.GENERAL_SITE_CONFIG_PATCHES || []).filter(function (rule) {
      return matchesRule(rule, context);
    });
  }

  function apply(config, context) {
    var original = isPlainObject(config) ? config : {};
    if (original.privateSpecialSite === true) {
      return { config: cloneValue(original), appliedPatches: [] };
    }

    var existingApplied = Array.isArray(original._generalSiteConfigPatches)
      ? original._generalSiteConfigPatches
      : [];
    var matched = resolve(context || {}).filter(function (rule) {
      // 服务器返回的配置若已经应用同一补丁的相同或更高版本，必须以服务器为准。
      // 这样旧安装包里的本地副本不会覆盖线上新规则；本地规则只负责离线兜底。
      var serverApplied = existingApplied.find(function (item) {
        return String(item && item.id || "") === String(rule && rule.id || "");
      });
      return !serverApplied || Number(serverApplied.revision || 0) < Number(rule.revision || 1);
    });
    var merged = cloneValue(original);
    matched.forEach(function (rule) {
      merged = mergePatch(merged, rule.patch);
    });

    var appliedPatches = matched.map(function (rule) {
      return {
        id: String(rule.id || "unnamed-patch"),
        displayName: String(rule.displayName || rule.id || "未命名站点"),
        revision: Number(rule.revision || 1),
        note: String(rule.note || ""),
      };
    });
    if (appliedPatches.length) {
      var retained = existingApplied.filter(function (item) {
        return !appliedPatches.some(function (patch) { return patch.id === String(item && item.id || ""); });
      });
      merged._generalSiteConfigPatches = retained.concat(appliedPatches);
      merged._generalSiteConfigPatchSource = "plugin_local";
    }
    return { config: merged, appliedPatches: appliedPatches };
  }

  AF.GeneralSiteConfigPatch = {
    apply: apply,
    mergePatch: mergePatch,
    normalizeRouteKey: normalizeRouteKey,
    resolve: resolve,
  };
})();
