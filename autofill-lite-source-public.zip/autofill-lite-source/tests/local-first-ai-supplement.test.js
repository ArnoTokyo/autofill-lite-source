"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const adapter = fs.readFileSync(path.join(root, "autofill-plugin/content/electron-adapter.js"), "utf8");

assert(main.includes('local_first_candidate_available'), "strong-local candidate discovery route missing");
assert(main.includes('loadValidatedAiCandidate(rawUrl)'), "strong-local path may inspect existing candidate without applying it");
assert(main.includes('已命中本地适配；发现已有 AI 语义候选'), "local-first must still keep mature local config ahead of AI");
assert(adapter.includes('hasSelectorSupplement'), "legacy selector supplement capability should remain available for future verified use");
assert(adapter.includes('executeRuntimeSelectorOverlayFill()'), "safe overlay executor should remain intact for Build159 controlled Core re-entry");
console.log("local-first-ai-supplement.test.js PASS");
