// 通用/示例特殊站点工作流配置（当前不保存正式特殊站点规则）。
//
// 这里只描述“怎样依次打开各个大类表单”，不描述字段怎样填写。
// 字段识别、DOM 定位、下拉、日期、经历卡片等仍全部复用现有 FillEngine。
//
// 正式特殊站点必须统一写入 private/private-special-sites.js，禁止复制到本文件。
// 下面仅保留结构示例，供工作流引擎开发时参考：
//   1. hostname / urlPattern / pageGuardSelector
//   2. steps[].triggerSelector：大类入口
//   3. steps[].readySelector：点击后确认表单已出现的元素
//   4. steps[].scopeSelector：当前大类表单的根容器（visible 模式使用）
//
// fillMode:
//   - "full"（默认）：每次打开大类后调用原来的 engine.execute()，支持经历新增/编辑。
//   - "visible"：调用 engine.executeVisibleFormFill(scope)，只补填当前可见且为空的字段。
(function () {
  "use strict";

  var AF = (window.AF = window.AF || {});

  AF.SPECIAL_SITE_WORKFLOWS = [
    // {
    //   id: "example-bank-resume",
    //   name: "示例银行分步简历",
    //   enabled: true,
    //   hostname: "career.example-bank.com",
    //   urlPattern: /\/resume\/edit/i,
    //   pageGuardSelector: ".resume-category-navigation",
    //   continueOnError: true,
    //   steps: [
    //     {
    //       name: "基本信息",
    //       category: "basicInfo",
    //       triggerSelector: '[data-menu-key="basic"]',
    //       triggerText: ["基本信息"],
    //       activeSelector: '[data-menu-key="basic"].active',
    //       readySelector: ".basic-info-form",
    //       scopeSelector: ".basic-info-form",
    //       fillMode: "full",
    //       timeoutMs: 5000,
    //       waitAfterClickMs: 200
    //     },
    //     {
    //       name: "教育经历",
    //       category: "education",
    //       triggerSelector: '[data-menu-key="education"]',
    //       triggerText: ["教育经历", "教育背景"],
    //       activeSelector: '[data-menu-key="education"].active',
    //       readySelector: ".education-form",
    //       scopeSelector: ".education-form",
    //       fillMode: "full"
    //     },
    //     {
    //       name: "工作经历",
    //       category: "workExperience",
    //       triggerSelector: '[data-menu-key="work"]',
    //       triggerText: ["工作经历"],
    //       readySelector: ".work-experience-form",
    //       scopeSelector: ".work-experience-form",
    //       fillMode: "full",
    //       // 可选：只有该站点切换大类前必须额外保存时才配置。
    //       // 经历模块自身的保存优先继续使用 site-templates.js 中的 experience.save。
    //       saveSelector: ".work-experience-form .save-button",
    //       saveText: ["保存"],
    //       savedSelector: ".save-success"
    //     }
    //   ]
    // }
  ];
})();
