// Hotjob Angular 学校/专业联想框主页面桥。
(function () {
  "use strict";
  if (window.__AFHotjobMainBridge) return;
  window.__AFHotjobMainBridge = true;
  try { document.documentElement.setAttribute("data-af-hotjob-main-bridge", "1"); } catch (e) {}

  function sleep(ms) { return new Promise(function (resolve) { setTimeout(resolve, ms); }); }
  function norm(value) {
    return String(value == null ? "" : value).replace(/[\s：:，,。.;；、()（）\-_\/\\]/g, "").toLowerCase();
  }
  function textOf(node) {
    return String(node && (node.getAttribute("title") || node.textContent) || "").replace(/\s+/g, " ").trim();
  }
  function visible(node) {
    if (!node || !node.getBoundingClientRect) return false;
    var style = window.getComputedStyle(node);
    var rect = node.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
  }
  function setValue(input, value) {
    var descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
    if (descriptor && descriptor.set) descriptor.set.call(input, value);
    else input.value = value;
    input.setAttribute("value", value);
  }
  function updateAngularModel(input, value) {
    try {
      var angular = window.angular;
      if (!angular || !angular.element) return false;
      var wrapped = angular.element(input);
      var scope = wrapped.scope && wrapped.scope();
      var modelController = wrapped.controller && wrapped.controller("ngModel");
      if (!scope || !modelController || typeof modelController.$setViewValue !== "function") return false;
      var applyValue = function () {
        modelController.$setViewValue(value);
        if (typeof modelController.$render === "function") modelController.$render();
      };
      if (scope.$root && scope.$root.$$phase) applyValue();
      else scope.$apply(applyValue);
      return true;
    } catch (e) {
      return false;
    }
  }
  async function typeKeyword(input, keyword) {
    input.focus();
    input.dispatchEvent(new window.FocusEvent("focusin", { bubbles: true, composed: true }));
    setValue(input, "");
    input.dispatchEvent(new window.InputEvent("input", {
      bubbles: true, cancelable: true, composed: true, inputType: "deleteContentBackward", data: null,
    }));
    await sleep(20);
    setValue(input, keyword);
    var angularUpdated = updateAngularModel(input, keyword);
    if (!angularUpdated) {
      input.dispatchEvent(new window.InputEvent("input", {
        bubbles: true, cancelable: true, composed: true, inputType: "insertText", data: keyword,
      }));
    }
    input.dispatchEvent(new window.Event("change", { bubbles: true, composed: true }));
    input.dispatchEvent(new window.KeyboardEvent("keyup", {
      bubbles: true, cancelable: true, composed: true,
      key: keyword ? keyword.charAt(keyword.length - 1) : "Unidentified",
    }));
  }
  async function clickChoice(node) {
    var events = ["mousedown", "mouseup", "click"];
    for (var i = 0; i < events.length; i++) {
      node.dispatchEvent(new window.MouseEvent(events[i], {
        view: window, bubbles: true, cancelable: true, composed: true,
        button: 0, buttons: events[i] === "mousedown" ? 1 : 0,
      }));
      await sleep(20);
    }
  }
  async function choose(token, keyword) {
    var escaped = String(token).replace(/['"\\]/g, "\\$&");
    var input = document.querySelector("[data-af-hotjob-token='" + escaped + "']");
    if (!input) throw new Error("input_not_found");
    var root = input.closest("dy-form-special");
    if (!root) throw new Error("root_not_found");
    var hidden = root.querySelector("input[type='hidden']");
    var opener = root.querySelector("input[school-or-subject='1']");
    var before = String(hidden && hidden.value || opener && (opener.value || opener.title) || "").trim();
    await typeKeyword(input, String(keyword || ""));
    var candidates = [];
    for (var waitIndex = 0; waitIndex < 60; waitIndex++) {
      await sleep(100);
      candidates = Array.prototype.slice.call(root.querySelectorAll(".schoolOrSubject li")).filter(function (node) {
        return visible(node) && textOf(node);
      });
      if (candidates.length) break;
    }
    if (!candidates.length) throw new Error("option_not_found");
    var wanted = norm(keyword);
    var selected = candidates.find(function (node) { return norm(textOf(node)) === wanted; }) ||
      candidates.find(function (node) {
        var text = norm(textOf(node));
        return text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1;
      }) || candidates[0];
    await clickChoice(selected);
    for (var verifyIndex = 0; verifyIndex < 30; verifyIndex++) {
      await sleep(100);
      // 选中后页面会把 school-or-subject="2" 搜索框替换成只读的
      // school-or-subject="1" 展示框，不能继续只读取旧节点引用。
      var liveHidden = root.querySelector("input[type='hidden']");
      var liveOpener = root.querySelector("input[school-or-subject='1']");
      var liveSearch = root.querySelector("input[school-or-subject='2']");
      var committed = String(
        liveHidden && liveHidden.value ||
        liveOpener && (liveOpener.value || liveOpener.title) ||
        liveSearch && liveSearch.value ||
        input && input.value || ""
      ).trim();
      if (committed && (committed !== before || norm(committed) === wanted)) return committed;
    }
    throw new Error("commit_failed");
  }

  function comparableDate(value) {
    var parts = String(value || "").match(/(\d{4})\D+(\d{1,2})\D+(\d{1,2})/);
    return parts ? [Number(parts[1]), Number(parts[2]), Number(parts[3])].join("-") : "";
  }

  async function setBoundDate(token, target) {
    var escaped = String(token).replace(/['"\\]/g, "\\$&");
    var input = document.querySelector("[data-af-hotjob-date-token='" + escaped + "']");
    if (!input) throw new Error("date_input_not_found");
    var parts = String(target || "").match(/(\d{4})\D+(\d{1,2})\D+(\d{1,2})/);
    if (!parts) throw new Error("invalid_date");
    var date = new Date(Number(parts[1]), Number(parts[2]) - 1, Number(parts[3]), 12, 0, 0);
    var iso = [parts[1], String(Number(parts[2])).padStart(2, "0"), String(Number(parts[3])).padStart(2, "0")].join("-");
    var jq = window.jQuery || window.$;
    var instance = null;
    try { instance = jq && jq(input).data("datetimepicker"); } catch (e) {}
    if (instance && typeof instance.setDate === "function") {
      instance.setDate(date);
    } else if (jq && jq.fn && typeof jq.fn.datetimepicker === "function") {
      try { jq(input).datetimepicker("setDate", date); }
      catch (e1) {
        try { jq(input).datetimepicker("update", date); } catch (e2) {}
      }
    }
    if (comparableDate(input.value) !== comparableDate(iso)) setValue(input, iso);
    input.setAttribute("value", iso);
    input.dispatchEvent(new window.InputEvent("input", { bubbles: true, composed: true, data: iso, inputType: "insertText" }));
    input.dispatchEvent(new window.Event("change", { bubbles: true, composed: true }));
    if (jq) {
      try { jq(input).trigger({ type: "changeDate", date: date }); } catch (e3) {}
    }
    input.dispatchEvent(new window.FocusEvent("blur", { bubbles: true, composed: true }));
    await sleep(80);
    var committed = String(input.value || input.getAttribute("value") || "").trim();
    if (comparableDate(committed) !== comparableDate(iso)) throw new Error("date_commit_failed");
    return committed;
  }

  window.addEventListener("message", async function (event) {
    if (event.source !== window) return;
    var data = event.data || {};
    if (data.type === "AF_HOTJOB_DATE_REQUEST") {
      var dateOk = false;
      var dateValue = "";
      var dateError = "";
      try {
        dateValue = await setBoundDate(data.token, data.target);
        dateOk = true;
      } catch (dateException) {
        dateError = dateException && dateException.message ? dateException.message : String(dateException);
      }
      window.postMessage({ type: "AF_HOTJOB_DATE_RESULT", id: data.id, ok: dateOk, value: dateValue, error: dateError }, "*");
      return;
    }
    if (data.type !== "AF_HOTJOB_CHOICE_REQUEST") return;
    var ok = false;
    var value = "";
    var error = "";
    try {
      document.documentElement.setAttribute("data-af-hotjob-last-request", String(data.keyword || ""));
      value = await choose(data.token, data.keyword);
      ok = true;
      document.documentElement.setAttribute("data-af-hotjob-last-result", value || "ok");
      document.documentElement.removeAttribute("data-af-hotjob-last-error");
    }
    catch (e) { error = e && e.message ? e.message : String(e); }
    if (error) document.documentElement.setAttribute("data-af-hotjob-last-error", error);
    window.postMessage({ type: "AF_HOTJOB_CHOICE_RESULT", id: data.id, ok: ok, value: value, error: error }, "*");
  });
})();
