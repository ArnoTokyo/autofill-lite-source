// Autofill Lite v0.1: local-only site configuration mode.
// The original app's remote config service is 示例资料ally disabled.
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.ServerConfig = { baseUrl: "" };
})();
