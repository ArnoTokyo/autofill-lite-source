// content/date-picker/handlers/element.js — Element UI 日期选择器 (.el-date-editor / .el-range-editor)
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   工厂分支 Kn.create() case "el": closest(.el-range-editor) -> po(范围), 否则 -> no(单选)。行46011-46016
//   no.setValue (单选): 行 46654-46748 (调用 se())
//   se()/fe() (单选打开面板+导航, Element UI 面板打开器): 行 34390-34459 — 选择器已核实
//   po.setValue (范围): 行 47445-47494 (调用 be())
//   be()/ge() (范围, 左右两栏各自比较年月再点箭头翻页, 非通用 w()): 行 35066-35156 — 已核实
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  var HEADER_LABEL_SEL = '.el-date-picker__header-label:not([style*="display: none"])';

  function isVisibleElementDatePanel(panel) {
    if (!panel) return false;
    var popper = panel.classList && panel.classList.contains("el-picker__popper")
      ? panel
      : panel.closest && panel.closest(".el-picker__popper");
    if (popper && popper.getAttribute("aria-hidden") === "true") return false;
    return AF.DomUtils.isElementVisible(panel) || (popper && AF.DomUtils.isElementVisible(popper));
  }

  function findElementDatePanel(input) {
    var controlsId = input && input.getAttribute && input.getAttribute("aria-controls");
    if (controlsId) {
      var linkedPopper = document.getElementById(controlsId);
      if (linkedPopper && isVisibleElementDatePanel(linkedPopper)) {
        return linkedPopper.querySelector(".el-date-picker") || linkedPopper;
      }
    }
    var poppers = Array.from(document.querySelectorAll(".el-picker__popper")).filter(isVisibleElementDatePanel);
    if (poppers.length) {
      var latest = poppers.sort(function (a, b) {
        var za = parseInt(getComputedStyle(a).zIndex, 10) || 0;
        var zb = parseInt(getComputedStyle(b).zIndex, 10) || 0;
        return zb - za;
      })[0];
      return latest.querySelector(".el-date-picker") || latest;
    }
    var panels = Array.from(document.querySelectorAll(".el-date-picker")).filter(isVisibleElementDatePanel);
    return panels[0] || null;
  }

  // ---- 单选 (源码 se()/fe(), 行34390) ----
  async function elementSingleNavigate(triggerEl, dateStr) {
    var parsed = AF.DatePicker._parseDateValue && AF.DatePicker._parseDateValue(String(dateStr || ""));
    var isMonthOnly = !!(parsed && !parsed.day);
    var input = (triggerEl.querySelector && triggerEl.querySelector("input")) || triggerEl;
    input.focus();
    await AF.DomUtils.enhancedClick(input);
    await AF.Utils.sleep(300);
    var panel = findElementDatePanel(input);
    if (!panel) throw new Error("没有找到日期选择器");
    var ok = await AF.DatePicker._navigatePanel({
      container: panel,
      dateString: dateStr,
      headerClickSelector: HEADER_LABEL_SEL,
      yearCellSelector: ".el-year-table a.cell, .el-year-table span.cell",
      disabledClassList: ["disabled"],
      yearBoundarySelector: HEADER_LABEL_SEL,
      // Element UI 2.x 的翻年图标本身就是 button：
      // button.el-picker-panel__icon-btn.el-date-picker__prev-btn.el-icon-d-arrow-left。
      // 旧选择器写成“父级 .prev-btn 里的 .d-arrow-left”，导致 2020–2029
      // 年份页无法翻到 2010–2019；工作日期较新所以没暴露，教育开始日期 2019 会失败。
      nextYearSelector: '.el-date-picker__next-btn.el-icon-d-arrow-right, .el-date-picker__next-btn.d-arrow-right, button.el-date-picker__next-btn[aria-label="后一年"], .el-date-picker__next-btn .d-arrow-right, .el-date-picker__next-btn button[aria-label="后一年"]',
      prevYearSelector: '.el-date-picker__prev-btn.el-icon-d-arrow-left, .el-date-picker__prev-btn.d-arrow-left, button.el-date-picker__prev-btn[aria-label="前一年"], .el-date-picker__prev-btn .d-arrow-left, .el-date-picker__prev-btn button[aria-label="前一年"]',
      monthCellSelector: ".el-month-table a.cell, .el-month-table span.cell",
      dayCellSelector: isMonthOnly ? null : ".el-date-table td.available",
      maxRetries: 20,
    });
    await AF.Utils.sleep(250);
    if (!ok) throw new Error("Element日期导航失败");
    return true;
  }

  // ---- 范围: 左右两栏 (源码 be()/ge(), 行35066) ----
  function parseYearMonthHeader(text) {
    var m = String(text || "").match(/(\d{4})\D+(\d{1,2})/);
    return m ? { year: parseInt(m[1], 10), month: parseInt(m[2], 10) } : null;
  }

  async function navigateRangeSide(sidePanel, targetYear, targetMonth, maxSteps) {
    maxSteps = maxSteps === undefined ? 30 : maxSteps;
    for (var i = 0; i < maxSteps; i++) {
      var headerEl = sidePanel.querySelector(".el-date-range-picker__header div");
      if (!headerEl) return false;
      var cur = parseYearMonthHeader(headerEl.textContent);
      if (!cur) return false;
      if (cur.year === targetYear && cur.month === targetMonth) return true;
      var curIndex = cur.year * 12 + cur.month;
      var targetIndex = targetYear * 12 + targetMonth;
      var forward = targetIndex > curIndex;
      var farAway = Math.abs(targetIndex - curIndex) >= 12;
      var btn = sidePanel.querySelector(
        farAway ? (forward ? ".el-icon-d-arrow-right" : ".el-icon-d-arrow-left") : (forward ? ".el-icon-arrow-right" : ".el-icon-arrow-left")
      );
      if (!btn) return false;
      await AF.DomUtils.safeClickElement(btn);
      await AF.Utils.sleep(200);
    }
    return false;
  }

  async function pickDayInSide(sidePanel, day) {
    var cells = sidePanel.querySelectorAll(".el-date-table td:not(.prev-month):not(.next-month)");
    var matches = Array.from(cells).filter(function (c) { return parseInt(c.textContent.trim(), 10) === day; });
    if (!matches.length) return false;
    await AF.DomUtils.safeClickElement(matches[0]);
    await AF.Utils.sleep(200);
    return true;
  }

  async function elementRangeNavigate(triggerEl, startStr, endStr) {
    try {
      var s = AF.DatePicker._parseDateValue(startStr);
      var e = AF.DatePicker._parseDateValue(endStr);
      if (!s || !e) throw new Error("日期格式不正确");
      await AF.DomUtils.enhancedClick(triggerEl);
      await AF.Utils.sleep(100);
      var panel = document.querySelector('.el-date-range-picker:not([style*="display: none"])');
      if (!panel) throw new Error("未找到日期范围选择器面板");
      var left = panel.querySelector(".el-date-range-picker__content.is-left");
      var right = panel.querySelector(".el-date-range-picker__content.is-right");
      if (!left || !right) throw new Error("未找到日期范围选择器的左右面板");
      await navigateRangeSide(left, s.year, s.month);
      var rightHeaderEl = right.querySelector(".el-date-range-picker__header div");
      var rightCur = rightHeaderEl ? parseYearMonthHeader(rightHeaderEl.textContent) : null;
      if (!rightCur || rightCur.year !== e.year || rightCur.month !== e.month) {
        await navigateRangeSide(right, e.year, e.month);
      }
      await pickDayInSide(left, s.day);
      await pickDayInSide(right, e.day);
      document.body.click();
      return true;
    } catch (e) {
      document.body.click();
      throw e;
    }
  }

  AF.DatePicker._registry["el"] = function (element, valueType) {
    return {
      setValue: async function (value) {
        try {
          if (!value) throw new Error("日期为空");
          var isRange = !!(element.classList.contains("el-range-editor") || element.closest(".el-range-editor") ||
            element.querySelector(".el-range-editor") || element.classList.contains("el-range-input") || element.closest(".el-range-input"));

          if (isRange) {
            if (typeof value !== "object" || !("startTime" in value) || !("endTime" in value)) {
              throw new Error("dateValue必须包含startTime和endTime属性");
            }
            return await elementRangeNavigate(element, value.startTime, value.endTime);
          }

          if (typeof value === "string" || valueType === "string") {
            return await elementSingleNavigate(element, value);
          }
          if (typeof value !== "object" || !("startTime" in value) || !("endTime" in value)) {
            throw new Error("当option为对象时，dateValue必须包含startTime和endTime属性");
          }
          await elementSingleNavigate(element, value.startTime);
          await AF.Utils.sleep(500);
          var candidates = AF.DomUtils.findSimilarElements(element, 4, { sameTag: true, sameClass: true, sameParent: false });
          if (candidates.length > 0) {
            var best = AF.DatePicker._pickEndDateCandidate(element, candidates);
            await elementSingleNavigate(best, value.endTime);
          } else {
            var surrounding = AF.DomUtils.findSurroundingInputs(element);
            if (surrounding.length > 0) await elementSingleNavigate(surrounding[0], value.endTime);
          }
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
