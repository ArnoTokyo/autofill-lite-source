"use strict";

function norm(value) {
  return String(value == null ? "" : value)
    .replace(/[\s：:*?？（）()【】\[\]「」'"“”‘’.,，。;；、]/g, "")
    .toLowerCase();
}

function clampConfidence(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(1, n));
}

function routeKeyFromPath(pathname) {
  let text = String(pathname || "/").split("?")[0].split("#")[0].replace(/\/+/g, "/").replace(/\/$/, "").toLowerCase() || "/";
  if (text.charAt(0) !== "/") text = "/" + text;
  return text.split("/").map((segment) => {
    if (/^\d{5,}$/.test(segment)) return ":id";
    if (/^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(segment)) return ":id";
    if (/^[a-z0-9_-]{32,}$/i.test(segment)) return ":token";
    return segment;
  }).join("/").slice(0, 255);
}

function compileSemanticSiteCandidate(review, patch, options) {
  const opts = Object.assign({ minConfidence: 0.50 }, options || {});
  const reviewFields = Array.isArray(review && review.reviewFields) ? review.reviewFields : [];
  const trustedMappings = Array.isArray(review && review.trustedMappings) ? review.trustedMappings : [];
  const decisions = Array.isArray(patch && patch.decisions) ? patch.decisions : [];
  const byId = new Map(reviewFields.map((field) => [String(field && field.fieldId || ""), field]));
  const accepted = [];
  const skipped = [];
  const blockedCandidates = [];

  // Mature-product rule: a candidate is the complete declarative semantic layer,
  // not merely the AI delta. Preserve locally trusted Core mappings first and let
  // AI supplement only unresolved semantic gaps.
  trustedMappings.forEach((item) => {
    const category = String(item && item.category || "").trim();
    const fieldKey = String(item && item.fieldKey || "").trim();
    const label = String(item && item.label || "").trim();
    if (!category || !fieldKey || !label) return;
    accepted.push({
      fieldId: String(item && item.fieldId || ""),
      category,
      fieldKey,
      label,
      confidence: Math.max(0.8, clampConfidence(item && item.confidence) || 1),
      graphFieldId: String(item && item.graphFieldId || ""),
      graphSectionId: String(item && item.graphSectionId || ""),
      graphSectionTitle: String(item && item.graphSectionTitle || "").trim(),
      graphLinkConfidence: clampConfidence(item && item.graphLinkConfidence),
      source: "local_core_trusted"
    });
  });

  decisions.forEach((decision) => {
    const fieldId = String(decision && decision.fieldId || "");
    const field = byId.get(fieldId);
    if (!field) {
      skipped.push({ fieldId, reason: "unknown_field_id" });
      return;
    }
    if (String(decision && decision.decision || "") !== "map") {
      const decisionType = String(decision && decision.decision || "leave_unmapped");
      const confidence = clampConfidence(decision && decision.confidence);
      const target = field && field.patchTarget && typeof field.patchTarget === "object" ? field.patchTarget : {};
      const label = String(target.label || field && field.label || field && field.graphRowLabel || "").trim();
      if (decisionType === "leave_unmapped" && confidence >= Number(opts.minConfidence || 0.50) && label) {
        blockedCandidates.push({
          fieldId,
          label,
          confidence,
          source: "ai_review_leave_unmapped"
        });
      }
      skipped.push({ fieldId, reason: decisionType });
      return;
    }
    const confidence = clampConfidence(decision && decision.confidence);
    if (confidence < Number(opts.minConfidence || 0.50)) {
      skipped.push({ fieldId, reason: "low_confidence", confidence });
      return;
    }
    const category = String(decision && decision.category || "").trim();
    const fieldKey = String(decision && decision.fieldKey || "").trim();
    const target = field && field.patchTarget && typeof field.patchTarget === "object" ? field.patchTarget : {};
    const label = String(target.label || field && field.label || field && field.graphRowLabel || "").trim();
    if (!category || !fieldKey || !label) {
      skipped.push({ fieldId, reason: "semantic_candidate_missing_identity" });
      return;
    }
    accepted.push({
      fieldId,
      category,
      fieldKey,
      label,
      confidence,
      graphFieldId: String(field && field.graphFieldId || ""),
      graphSectionId: String(field && field.graphSectionId || ""),
      graphSectionTitle: String(field && field.graphSectionTitle || "").trim(),
      graphLinkConfidence: clampConfidence(field && field.graphLinkConfidence),
      source: "ai_semantic_patch"
    });
  });

  // Mature DataMatcher semantics are label based. Conflicting decisions for the
  // same category+label must never enter a SiteConfig candidate.
  const fieldGroups = new Map();
  accepted.forEach((item) => {
    const key = `${item.category}::${norm(item.label)}`;
    if (!fieldGroups.has(key)) fieldGroups.set(key, []);
    fieldGroups.get(key).push(item);
  });
  const fieldMappings = [];
  for (const items of fieldGroups.values()) {
    const localItems = items.filter((item) => item.source === "local_core_trusted");
    const localKeys = Array.from(new Set(localItems.map((item) => item.fieldKey)));
    if (localKeys.length > 1) {
      items.forEach((item) => skipped.push({ fieldId: item.fieldId, reason: "candidate_conflicting_local_trusted_mapping" }));
      continue;
    }
    let eligible = items;
    if (localKeys.length === 1) {
      const localKey = localKeys[0];
      items.filter((item) => item.source !== "local_core_trusted" && item.fieldKey !== localKey)
        .forEach((item) => skipped.push({ fieldId: item.fieldId, reason: "ai_conflicts_with_local_trusted_mapping" }));
      eligible = items.filter((item) => item.fieldKey === localKey);
    } else {
      const keys = Array.from(new Set(items.map((item) => item.fieldKey)));
      if (keys.length !== 1) {
        items.forEach((item) => skipped.push({ fieldId: item.fieldId, reason: "candidate_conflicting_label_mapping" }));
        continue;
      }
    }
    const best = eligible.slice().sort((a, b) => {
      if (a.source === "local_core_trusted" && b.source !== "local_core_trusted") return -1;
      if (b.source === "local_core_trusted" && a.source !== "local_core_trusted") return 1;
      return b.confidence - a.confidence;
    })[0];
    fieldMappings.push({
      fieldId: best.fieldId,
      category: best.category,
      fieldKey: best.fieldKey,
      label: best.label,
      confidence: best.confidence,
      source: best.source
    });
  }

  // Section mappings are compiled only from high-confidence graph ownership.
  // This mirrors the mature-product idea: AI describes enterprise structure,
  // while the local platform template keeps control interaction capabilities.
  const sectionGroups = new Map();
  accepted.forEach((item) => {
    const title = item.graphSectionTitle;
    if (!title || title === "当前页面" || item.graphLinkConfidence < 0.9) return;
    const key = norm(title);
    if (!key) return;
    if (!sectionGroups.has(key)) sectionGroups.set(key, []);
    sectionGroups.get(key).push(item);
  });
  const sectionMappings = [];
  for (const items of sectionGroups.values()) {
    const categories = Array.from(new Set(items.map((item) => item.category)));
    if (categories.length !== 1) {
      items.forEach((item) => skipped.push({ fieldId: item.fieldId, reason: "candidate_conflicting_section_category" }));
      continue;
    }
    const title = items[0].graphSectionTitle;
    const confidence = Math.min.apply(null, items.map((item) => item.confidence));
    sectionMappings.push({
      category: categories[0],
      label: title,
      confidence,
      source: "form_graph_semantic_consensus"
    });
  }

  // A high-confidence leave_unmapped decision is also useful site knowledge.
  // Preserve it as a declarative denylist so the generic dictionary/fuzzy matcher
  // cannot later re-introduce the exact semantic mistake that AI explicitly rejected.
  // Locally trusted mappings always win: if a trusted field owns the same label, do
  // not block it.
  const acceptedLabels = new Set(fieldMappings.map((item) => norm(item.label)).filter(Boolean));
  const blockedLabels = [];
  const blockedSeen = new Set();
  blockedCandidates.forEach((item) => {
    const key = norm(item.label);
    if (!key || acceptedLabels.has(key) || blockedSeen.has(key)) return;
    blockedSeen.add(key);
    blockedLabels.push({
      label: item.label,
      confidence: item.confidence,
      source: item.source
    });
  });

  const page = review && review.page || patch && patch.page || {};
  const hostname = String(page.hostname || "").toLowerCase();
  const pathname = String(page.pathname || "/") || "/";
  const semanticPatch = { fieldMappings, sectionMappings, blockedLabels };
  const configTemplate = {
    name: hostname || "AI semantic candidate",
    type: "structured",
    _source: "ai_generated",
    _serverStatus: "candidate",
    _manualCandidate: true,
    _routeKey: routeKeyFromPath(pathname),
    _autoConfigStrategy: {
      mode: "local_first_semantic_candidate_v2",
      graphAware: true,
      aiAuthoredSelectors: false,
      requiresMatureBaseConfig: true
    },
    _aiSemanticPatch: semanticPatch
  };

  return {
    schemaType: "autofill-lite-site-config-candidate",
    schemaVersion: 1,
    page: { hostname, pathname },
    minConfidence: Number(opts.minConfidence || 0.50),
    configTemplate,
    semanticPatch,
    skipped,
    summary: {
      acceptedFieldMappings: fieldMappings.length,
      acceptedLocalFieldMappings: fieldMappings.filter((item) => item.source === "local_core_trusted").length,
      acceptedAiFieldMappings: fieldMappings.filter((item) => item.source === "ai_semantic_patch").length,
      acceptedSectionMappings: sectionMappings.length,
      acceptedBlockedLabels: blockedLabels.length,
      skippedDecisions: skipped.length,
      requiresMatureBaseConfig: true,
      aiAuthoredSelectors: false
    },
    safety: {
      profileValuesIncluded: false,
      selectorsAuthoredByAi: false,
      javascriptGenerated: false,
      pageActionsExecuted: false,
      saveSubmitApplyDeleteUploadAllowed: false
    }
  };
}

module.exports = { compileSemanticSiteCandidate, routeKeyFromPath };
