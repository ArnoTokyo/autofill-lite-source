"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");

class FakeElement {
  constructor(tag, text = "", className = "") {
    this.tagName = String(tag || "div").toUpperCase();
    this.textContent = text;
    this.className = className;
    this.parentElement = null;
    this.children = [];
    this.attrs = {};
    this.id = "";
    this.type = "";
    this._value = "";
    this.disabled = false;
    this.readOnly = false;
    this.required = false;
    this.checked = false;
    this.labels = [];
    this.isConnected = true;
    this.options = [];
    this.selectedIndex = -1;
    this.rect = { left: 20, top: 20, right: 180, bottom: 50, width: 160, height: 30 };
  }
  set value(value) {
    this._value = String(value == null ? "" : value);
    if (this.tagName === "SELECT" && Array.isArray(this.options)) {
      const index = this.options.findIndex((option) => String(option.value) === this._value);
      if (index >= 0) this.selectedIndex = index;
    }
  }
  get value() { return this._value; }
  append(child) { child.parentElement = this; this.children.push(child); return child; }
  contains(node) { return node === this || this.children.some((child) => child.contains(node)); }
  getBoundingClientRect() { return this.rect; }
  getClientRects() { return this.isConnected ? [this.rect] : []; }
  getAttribute(name) {
    if (name === "id") return this.id || null;
    if (name === "type") return this.type || null;
    if (name === "name") return this.attrs.name || null;
    if (name === "value") return this.value || null;
    return Object.prototype.hasOwnProperty.call(this.attrs, name) ? this.attrs[name] : null;
  }
  setAttribute(name, value) { this.attrs[name] = String(value); if (name === "id") this.id = String(value); }
  hasAttribute(name) { return this.getAttribute(name) != null; }
  scrollIntoView() {}
  dispatchEvent() { return true; }
  click() {}
  matches(selector) {
    if (selector.includes("input") && this.tagName === "INPUT") return true;
    if (selector.includes("select") && this.tagName === "SELECT") return true;
    if (selector.includes("textarea") && this.tagName === "TEXTAREA") return true;
    if (selector.includes("button") && this.tagName === "BUTTON") return true;
    return false;
  }
  closest(selector) {
    for (let node = this; node; node = node.parentElement) {
      if (selector.includes("form") && node.tagName === "FORM") return node;
      if (selector.includes("li") && node.tagName === "LI") return node;
    }
    return null;
  }
  _all() {
    const out = [];
    const walk = (node) => { for (const child of node.children) { out.push(child); walk(child); } };
    walk(this);
    return out.filter((node) => node.isConnected !== false);
  }
  querySelectorAll(selector) {
    const all = this._all();
    const idMatch = String(selector).match(/^\[id="([^"]+)"\]$/);
    if (idMatch) return all.filter((node) => node.id === idMatch[1]);
    const nameMatch = String(selector).match(/^\[name="([^"]+)"\]$/);
    if (nameMatch) return all.filter((node) => node.attrs.name === nameMatch[1]);
    const radioNameMatch = String(selector).match(/^input\[type="radio"\]\[name="([^"]+)"\]$/);
    if (radioNameMatch) return all.filter((node) => node.tagName === "INPUT" && node.type === "radio" && node.attrs.name === radioNameMatch[1]);
    const radioIdMatch = String(selector).match(/^input\[type="radio"\]\[id="([^"]+)"\]$/);
    if (radioIdMatch) return all.filter((node) => node.tagName === "INPUT" && node.type === "radio" && node.id === radioIdMatch[1]);
    if (selector === "label") return [];
    if (selector === "*") return all;
    if (selector.includes("button") || selector.includes("[role='button']") || selector.includes("input[type='submit']") || selector.includes("input[type='button']")) {
      return all.filter((node) => node.tagName === "BUTTON" || node.tagName === "A");
    }
    if (selector.includes("input") || selector.includes("select") || selector.includes("textarea") || selector.includes("contenteditable")) {
      return all.filter((node) => ["INPUT", "SELECT", "TEXTAREA"].includes(node.tagName));
    }
    return [];
  }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
}

function option(text, value) { return { textContent: text, label: text, value: value == null ? text : value }; }
function select(form, id, name, texts) {
  const node = form.append(new FakeElement("select"));
  node.id = id; node.attrs.name = name;
  node.options = texts.map((text, index) => option(text, String(index)));
  node.selectedIndex = 0; node.value = "0";
  return node;
}
function input(form, id, name, type = "text") {
  const node = form.append(new FakeElement("input"));
  node.id = id; node.attrs.name = name; node.type = type;
  return node;
}

const root = new FakeElement("html");
const body = root.append(new FakeElement("body"));
const navLi = body.append(new FakeElement("li", "", "on"));
const nav = navLi.append(new FakeElement("a", "教育背景"));
const add = body.append(new FakeElement("div", "+添加教育背景", "add-btn"));
const form = body.append(new FakeElement("form", "", "education-editor"));
const province = select(form, "province", "province", ["请选择省份", "北京市", "广东省"]);
const educationType = select(form, "educationType", "educationType", ["请选择", "普通全日制"]);
const schoolTypeDomestic = input(form, "", "type", "radio"); schoolTypeDomestic.value = "境内";
const schoolTypeOverseas = input(form, "", "type", "radio"); schoolTypeOverseas.value = "境外";
const schoolCode = select(form, "schoolCode", "schoolCode", ["请选择学校", "示例大学"]);
const schoolChinaName = input(form, "schoolChinaName", "schoolChinaName");
const start = input(form, "educationStartDate", "educationStartDate"); start.readOnly = true;
const degree = select(form, "xw", "degree", ["请选择", "经济学硕士", "经济学学士"]);
const end = input(form, "educationEndDate", "educationEndDate"); end.readOnly = true;
const degreeNumber = input(form, "degreeNumber", "degreeNumber");
const level = select(form, "xl", "education", ["请选择", "硕士研究生", "大学本科"]);
const educationNumber = input(form, "educationNumber", "educationNumber");
const major = input(form, "major", "major"); major.attrs.placeholder = "请输入专业关键字...";
const gradePointType = select(form, "gradePointType", "gradePointType", ["四分制", "五分制", "十分制", "百分制"]);
const majorDirection = input(form, "majorDirection", "majorDirection");
const gpa = input(form, "gradePoint", "gradePoint");
const researchDirection = input(form, "researchDirection", "researchDirection");
const academicType = input(form, "", "researchType", "radio"); academicType.value = "学术型";
const professionalType = input(form, "", "researchType", "radio"); professionalType.value = "专业型";
const maxEdu = input(form, "maxEdu", "maxEdu", "checkbox");
const maxDeg = input(form, "maxDeg", "maxDeg", "checkbox");
const firstEdu = input(form, "firstEdu", "firstEdu", "checkbox");
const dubbleEdu = input(form, "dubbleEdu", "dubbleEdu", "checkbox");
const save = form.append(new FakeElement("button", "保存教育背景"));
const back = form.append(new FakeElement("button", "返回"));
let saveClicks = 0;
save.click = () => { saveClicks += 1; };

let editorOpen = false;
const editorNodes = form._all().concat([form]);
for (const node of editorNodes) node.isConnected = false;
add.click = () => { editorOpen = true; for (const node of editorNodes) node.isConnected = true; };
back.click = () => { editorOpen = false; for (const node of editorNodes) node.isConnected = false; };

const documentStub = {
  nodeType: 9,
  documentElement: root,
  body,
  querySelectorAll(selector) {
    if (selector === "#eduNav") return [nav];
    if (selector.includes("button, a, [role='button'], [onclick], div, span, li")) return editorOpen ? [navLi, nav, add, save, back] : [navLi, nav, add];
    return body.querySelectorAll(selector);
  },
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; },
  createEvent() { return { initMouseEvent() {} }; }
};

global.HTMLElement = FakeElement;
global.Element = FakeElement;
global.HTMLSelectElement = FakeElement;
global.HTMLInputElement = FakeElement;
global.HTMLTextAreaElement = FakeElement;
global.InputEvent = function () {};
global.Event = function () {};
global.KeyboardEvent = function () {};
global.MouseEvent = function () {};
global.document = documentStub;
global.window = {
  AF: {
    Utils: { sleep: async () => {} },
    FormHandler: {
      fillFormElement: async (element, value) => { element.value = String(value == null ? "" : value); return true; }
    }
  },
  top: null,
  location: { hostname: "zhaopin.cnpc.com.cn", pathname: "/web/createResume.html", href: "https://zhaopin.cnpc.com.cn/web/createResume.html" },
  innerWidth: 1400,
  innerHeight: 900,
  getComputedStyle: () => ({ display: "block", visibility: "visible", cursor: "default", zIndex: "0" }),
  sessionStorage: { getItem() { return null; }, removeItem() {} },
  postMessage() {}
};
window.top = window;

const realSetTimeout = global.setTimeout;
global.setTimeout = () => 0;
const source = fs.readFileSync(path.join(__dirname, "..", "autofill-plugin", "content", "special-site-workflow.js"), "utf8");
new Function(source)();
global.setTimeout = realSetTimeout;

(async () => {
  const api = window.AF.SpecialSiteWorkflow._test;
  assert.strictEqual(typeof api.runAnalyzedEducationRecordPreviewFill, "function");
  const result = await api.runAnalyzedEducationRecordPreviewFill({
    section: { text: "教育背景", selectorHint: "#eduNav" },
    requireSectionActive: true,
    profileRecordIndex: 0,
    profileRecordCount: 2,
    record: {
      school: "示例大学",
      schoolLocation: "北京",
      schoolAffiliation: "国内高校",
      educationType: "全日制",
      startTime: "2024-09-01",
      endTime: "2026-06-30",
      degree: "硕士",
      majorCategory: "经济学",
      level: "硕士",
      major: "金融",
      gradePointType: "四分制",
      majorDirection: "证券投资与金融管理",
      gpa: "3.61",
      degreeType: "专业型",
      researchDirection: "证券投资与金融管理",
      isHighestEducation: "是",
      isHighestDegree: "是",
      isFirstEducation: "否"
    },
    editorOpenTimeoutMs: 50,
    dynamicOptionTimeoutMs: 50
  });
  assert.strictEqual(result.result, "preview_filled_left_open");
  assert.strictEqual(result.sectionActiveBefore, true);
  assert.strictEqual(result.editorOpened, true);
  assert.strictEqual(result.profileRecordCount, 2);
  assert(result.committedFieldCount >= 8, `expected >=8 committed fields, got ${result.committedFieldCount}`);
  assert.strictEqual(province.options[province.selectedIndex].textContent, "北京市");
  assert.strictEqual(educationType.options[educationType.selectedIndex].textContent, "普通全日制");
  assert.strictEqual(schoolTypeDomestic.checked, true);
  assert.strictEqual(schoolCode.options[schoolCode.selectedIndex].textContent, "示例大学");
  assert.strictEqual(schoolChinaName.value, "示例大学");
  assert.strictEqual(start.value, "2024-09-01");
  assert.strictEqual(degree.options[degree.selectedIndex].textContent, "经济学硕士");
  assert.strictEqual(level.options[level.selectedIndex].textContent, "硕士研究生");
  assert.strictEqual(major.value, "金融");
  assert.strictEqual(gradePointType.options[gradePointType.selectedIndex].textContent, "四分制");
  assert.strictEqual(majorDirection.value, "证券投资与金融管理");
  assert.strictEqual(gpa.value, "3.61");
  assert.strictEqual(professionalType.checked, true);
  assert.strictEqual(researchDirection.value, "证券投资与金融管理");
  assert.strictEqual(maxEdu.checked, true);
  assert.strictEqual(maxDeg.checked, true);
  assert.strictEqual(firstEdu.checked, false);
  assert.strictEqual(result.saveControlFound, true);
  assert.strictEqual(result.saveExecuted, false);
  assert.strictEqual(result.editorLeftOpen, true);
  assert.strictEqual(saveClicks, 0, "preview must never click save");
  assert.strictEqual(result.safety.saveExecuted, false);
  assert.strictEqual(result.safety.finalSubmitExecuted, false);

  const profileAdapter = fs.readFileSync(path.join(__dirname, "..", "profile-adapter.js"), "utf8");
  assert(profileAdapter.includes('educationNumber: "学历证书编号"'));
  assert(profileAdapter.includes('degreeNumber: "学位证书编号"'));
  const main = fs.readFileSync(path.join(__dirname, "..", "main.js"), "utf8");
  const preload = fs.readFileSync(path.join(__dirname, "..", "ui-preload.js"), "utf8");
  const renderer = fs.readFileSync(path.join(__dirname, "..", "renderer.js"), "utf8");
  const index = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
  assert(main.includes('kind: "education_record_preview_fill"'));
  assert(main.includes('educationRows[0]'));
  assert(preload.includes('previewFillEducationRecord'));
  assert(renderer.includes('previewFillEducationRecord'));
  assert(!index.includes('id="educationPreviewFill"'), "Build160 removes the manual education preview toolbar entry");
  console.log("education record preview fill fixture: PASS");
})().catch((error) => { console.error(error); process.exitCode = 1; });
