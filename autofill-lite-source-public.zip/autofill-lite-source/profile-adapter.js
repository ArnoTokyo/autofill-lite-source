"use strict";

const fs = require("fs");

function nonEmpty(value) {
  return value !== undefined && value !== null && String(value).trim() !== "";
}

function copyMapped(source, map) {
  const out = {};
  for (const [target, sourceKey] of Object.entries(map)) {
    const value = source ? source[sourceKey] : undefined;
    if (nonEmpty(value)) out[target] = value;
  }
  return out;
}

function sortLatestFirst(records) {
  return records.slice().sort((a, b) => {
    const pick = (r) => String(r.endTime || r.endDate || r.startTime || r.startDate || "");
    return pick(b).localeCompare(pick(a));
  });
}

function asValues(section) {
  return section && section.values && typeof section.values === "object" ? section.values : {};
}

function asItems(section) {
  return Array.isArray(section && section.items) ? section.items : [];
}

function valuesOf(item) {
  return item && item.values && typeof item.values === "object" ? item.values : {};
}

// User-confirmed education-date convention (2026-09-13):
// every education period starts on Sep 1 of the source start year and ends
// on Jun 30 of the source end year. This is intentionally limited to the
// education section; internship/work/project dates retain their original
// precision and values.
function normalizeEducationBoundary(value, boundary) {
  if (!nonEmpty(value)) return value;
  const text = String(value).trim();
  if (/至今|目前|现在|present|current/i.test(text)) return text;
  const match = text.match(/(19|20)\d{2}/);
  if (!match) return value;
  const year = match[0];
  return boundary === "start" ? `${year}-09-01` : `${year}-06-30`;
}

// User-confirmed discipline mapping (2026-09-13): the user's finance master's
// and fiscal-studies bachelor's belong to the Economics discipline. Preserve an
// explicit source value when present; otherwise only infer the narrow finance /
// fiscal / economics cases needed by this profile. Do not guess unrelated majors.
function deriveEducationMajorCategory(values, row) {
  const explicitKeys = [
    "学位所属学科门类", "学位所属门类", "学科门类", "专业所属门类", "专业门类"
  ];
  for (const key of explicitKeys) {
    if (nonEmpty(values && values[key])) return String(values[key]).trim();
  }
  const text = [
    row && row.major,
    row && row.majorDescription,
    values && values["专业"],
    values && values["专业描述"]
  ].filter(nonEmpty).join(" ");
  if (/(?:金融|财政|税收|经济学|应用经济学)/.test(text)) return "经济学";
  return "";
}

// Build145: keep both detailed and simple degree names in the canonical profile.
// The source profile may explicitly provide them (preferred); otherwise derive only
// deterministic variants from the already-confirmed discipline + degree level.
// This is profile knowledge, not a CNPC/site-specific rule.
function canonicalSimpleDegree(value, level) {
  const text = [value, level].filter(nonEmpty).join(" ");
  if (/博士/.test(text)) return "博士";
  if (/硕士|研究生/.test(text)) return "硕士";
  if (/学士|本科|大学/.test(text)) return "学士";
  if (/^(?:无|无学位|未取得|未获得)$/i.test(String(value || "").trim())) return "无学位";
  return nonEmpty(value) ? String(value).trim() : "";
}

function enrichEducationDegreeVariants(row) {
  if (!row || typeof row !== "object") return row;
  const simple = nonEmpty(row.degreeSimple)
    ? String(row.degreeSimple).trim()
    : canonicalSimpleDegree(row.degree, row.level);
  if (nonEmpty(simple)) row.degreeSimple = simple;

  if (!nonEmpty(row.degreeDetailed)) {
    const discipline = nonEmpty(row.majorCategory) ? String(row.majorCategory).trim() : "";
    if (discipline && /^(?:博士|硕士|学士)$/.test(simple)) row.degreeDetailed = discipline + simple;
    else if (nonEmpty(row.degree)) row.degreeDetailed = String(row.degree).trim();
  }
  return row;
}

function normalizeProfileBackup(raw) {
  if (!raw || !raw.profileV2 || !raw.profileV2.sections) {
    throw new Error("candidate-profile-merged.json 格式不受支持：缺少 profileV2.sections");
  }

  const sections = raw.profileV2.sections;
  const basic = asValues(sections.basic);
  const self = asValues(sections.self);
  const other = asValues(sections.other);
  const intentions = asItems(sections.intention).map(valuesOf);

  const education = sortLatestFirst(asItems(sections.education).map((item) => {
    const v = valuesOf(item);
    const row = copyMapped(v, {
      studentId: "学号",
      school: "学校",
      level: "学历",
      educationType: "学习形式",
      degree: "学位",
      degreeDetailed: "详细学位",
      degreeSimple: "简化学位",
      department: "学院（院系）",
      major: "专业",
      researchDirection: "研究方向",
      majorDirection: "专业方向",
      city: "城市",
      schoolLocation: "城市",
      schoolType: "学校类别",
      studyLength: "学制",
      gpa: "个人绩点",
      rank: "年级排名",
      integratedTraining: "是否贯通式培养",
      trainingMode: "培养方式",
      startTime: "开始时间",
      endTime: "结束时间",
      classRank: "专业排名",
      cohortRank: "班级排名",
      hasOverseasStudy: "是否有国外、港澳台地区学习经历",
      isOverseas: "是否为海外教育经历",
      gaokaoAdmissionBatch: "录取批次",
      majorCourses: "专业课程",
      majorDescription: "专业描述",
      educationNumber: "学历证书编号",
      degreeNumber: "学位证书编号",
      gradePointType: "绩点制",
      degreeType: "学位类型",
      isHighestEducation: "是否最高学历",
      isHighestDegree: "是否最高学位",
      isFirstEducation: "是否第一学历",
      isDoubleEducation: "是否双学历",
      otherDesc: "其他描述"
    });
    // 用户已明确授权学历日期统一采用学年边界：入学 9 月 1 日，毕业 6 月 30 日。
    // 只取原始资料中的年份，不把这条规则扩展到实习/工作/项目经历。
    const sourceStart = nonEmpty(v["开始日期"]) ? v["开始日期"] : row.startTime;
    const sourceEnd = nonEmpty(v["结束日期"]) ? v["结束日期"] : row.endTime;
    row.startTime = normalizeEducationBoundary(sourceStart, "start");
    row.endTime = normalizeEducationBoundary(sourceEnd, "end");
    const majorCategory = deriveEducationMajorCategory(v, row);
    if (nonEmpty(majorCategory)) row.majorCategory = majorCategory;
    enrichEducationDegreeVariants(row);
    if (!nonEmpty(row.gpa) && nonEmpty(v["成绩"])) row.gpa = v["成绩"];
    if (!nonEmpty(row.majorDirection) && nonEmpty(row.researchDirection)) row.majorDirection = row.researchDirection;
    // “办学属地”在招聘表单中表示境内/境外院校类别，不是学校所在城市。
    // 用户已确认当前教育记录统一为国内高校；城市仍保留在 city/schoolLocation。
    row.schoolAffiliation = "国内高校";
    if (!nonEmpty(row.majorCategory) && nonEmpty(v["学科门类"])) row.majorCategory = v["学科门类"];
    if (nonEmpty(row.majorCourses)) row.courses = String(row.majorCourses).split(/[、，,]/).map((x) => x.trim()).filter(Boolean);
    row.startDate = row.startTime;
    row.endDate = row.endTime;
    return row;
  }).filter((row) => row.school && !/^高中$/.test(String(row.level || "").trim())));

  // Shared education-role metadata. These flags describe the canonical record set,
  // not any one site's DOM. Preserve explicit source values; otherwise derive only
  // deterministic relationships from the complete higher-education list.
  function educationLevelRank(row) {
    const text = String(row && (row.level || row.degree) || "");
    if (/博士/.test(text)) return 4;
    if (/硕士|研究生/.test(text)) return 3;
    if (/本科|学士|大学/.test(text)) return 2;
    if (/专科|大专|高职/.test(text)) return 1;
    return 0;
  }
  function educationDegreeRank(row) {
    const text = String(row && row.degree || "");
    if (/博士/.test(text)) return 4;
    if (/硕士/.test(text)) return 3;
    if (/学士/.test(text)) return 2;
    if (/^(?:无|未取得|未获得)$/i.test(text.trim())) return 0;
    return 0;
  }
  const highestRank = education.reduce((max, row) => Math.max(max, educationLevelRank(row)), 0);
  const highestIndex = education.findIndex((row) => educationLevelRank(row) === highestRank);
  const highestDegreeRank = education.reduce((max, row) => Math.max(max, educationDegreeRank(row)), 0);
  const highestDegreeIndex = education.findIndex((row) => educationDegreeRank(row) === highestDegreeRank);
  const firstIndex = education.length ? education.reduce((best, row, index) => {
    if (best < 0) return index;
    const a = String(education[best].startTime || education[best].startDate || "9999");
    const b = String(row.startTime || row.startDate || "9999");
    return b && b < a ? index : best;
  }, -1) : -1;
  education.forEach((row, index) => {
    if (!nonEmpty(row.isHighestEducation)) row.isHighestEducation = index === highestIndex ? "是" : "否";
    if (!nonEmpty(row.isHighestDegree)) row.isHighestDegree = highestDegreeRank > 0 && index === highestDegreeIndex ? "是" : "否";
    if (!nonEmpty(row.isFirstEducation)) row.isFirstEducation = index === firstIndex ? "是" : "否";
  });

  const latestEducation = education[0] || {};

  const basicInfo = Object.assign({}, copyMapped(basic, {
    idNumber: "证件号码",
    highestEducation: "最高学历",
    name: "姓名",
    gender: "性别",
    birthDate: "出生日期",
    country: "国籍（国家或地区）",
    nativePlace: "籍贯",
    ethnicity: "民族",
    birthOrigin: "生源地",
    currentAddress: "现居住城市",
    currentResidence: "现居住城市",
    currentAddressDetail: "现居住详细地址",
    communicationAddress: "通讯地址",
    mailingAddress: "通讯地址",
    maritalStatus: "婚姻状况",
    phone: "电话",
    wechat: "微信号",
    qq: "QQ",
    email: "邮箱",
    politicalStatus: "政治面貌",
    partyJoinDate: "取得政治面貌时间",
    workYears: "工作年限",
    healthStatus: "健康状况",
    emergencyContactName: "紧急联系人",
    emergencyPhone: "紧急联系人电话",
    emergencyContactRelation: "与紧急联系人关系",
    postalCode: "邮政编码",
    hobbies: "兴趣爱好",
    height: "身高",
    weight: "体重",
    idType: "证件号码类型",
    hukouLocation: "户籍"
  }));

  if (nonEmpty(latestEducation.degree)) basicInfo.highestDegree = latestEducation.degree;
  if (nonEmpty(latestEducation.major)) basicInfo.highestMajor = latestEducation.major;
  if (nonEmpty(latestEducation.school)) basicInfo.graduationSchool = latestEducation.school;
  if (nonEmpty(latestEducation.endTime)) basicInfo.graduationDate = latestEducation.endTime;
  const selfText = self["自我评价"] || self["自我描述"];
  if (nonEmpty(selfText)) basicInfo.selfIntroduction = selfText;
  if (nonEmpty(other["招聘信息来源"])) basicInfo.recruitmentChannel = other["招聘信息来源"];
  if (nonEmpty(other["爱好及专长"]) && !nonEmpty(basicInfo.hobbies)) basicInfo.hobbies = other["爱好及专长"];

  const normalizedIntentions = intentions.map((item) => copyMapped(item, {
    position: "意向岗位",
    city: "期望工作城市",
    expectedLocation: "期望工作城市",
    salary: "期望薪资",
    currentSalary: "当前薪资",
    availability: "预计入职时间",
    interviewCity: "面试城市",
    acceptAdjustment: "是否接受调剂"
  }));
  const primaryIntention = normalizedIntentions[0] || {};
  const jobIntention = Object.assign({}, primaryIntention);
  // Preserve the historical single-value contract while also exposing every
  // confirmed intention from the merged profile. Site adapters that only accept
  // one value keep using the first record; richer adapters may inspect options.
  if (nonEmpty(jobIntention.position)) jobIntention.expectedPosition = jobIntention.position;
  if (nonEmpty(jobIntention.salary)) jobIntention.expectedSalary = jobIntention.salary;
  jobIntention.positionOptions = Array.from(new Set(normalizedIntentions.map((row) => row.position).filter(nonEmpty)));
  jobIntention.salaryOptions = Array.from(new Set(normalizedIntentions.map((row) => row.salary).filter(nonEmpty)));
  jobIntention.cityOptions = Array.from(new Set(normalizedIntentions.map((row) => row.city).filter(nonEmpty)));
  jobIntention.intentions = normalizedIntentions;
  if (nonEmpty(jobIntention.position)) basicInfo.expectedPosition = jobIntention.position;
  if (nonEmpty(jobIntention.expectedLocation)) basicInfo.expectedLocation = jobIntention.expectedLocation;
  if (nonEmpty(jobIntention.salary)) basicInfo.expectedSalary = jobIntention.salary;

  const internshipExperience = sortLatestFirst(asItems(sections.internship).map((item) => {
    const v = valuesOf(item);
    const row = copyMapped(v, {
      company: "公司",
      department: "部门",
      industry: "行业",
      workLocation: "地点",
      position: "职位",
      detailedContent: "工作内容",
      result: "工作成果",
      startTime: "开始时间",
      endTime: "结束时间",
      startDate: "开始日期",
      endDate: "结束日期",
      reasonForLeaving: "离职原因",
      custom_income: "工资",
      custom_referencePerson: "证明人姓名",
      custom_referencePersonPhone: "证明人联系方式"
    });
    if (!nonEmpty(row.startTime) && nonEmpty(row.startDate)) row.startTime = row.startDate;
    if (!nonEmpty(row.endTime) && nonEmpty(row.endDate)) row.endTime = row.endDate;
    return row;
  }).filter((row) => row.company || row.position));

  const projectExperience = sortLatestFirst(asItems(sections.project).map((item) => {
    const v = valuesOf(item);
    if (String(v["记录状态"] || "").includes("不用于后续填写")) return null;
    const row = copyMapped(v, {
      name: "项目名称",
      role: "职责",
      details: "项目内容",
      startTime: "开始时间",
      endTime: "结束时间",
      startDate: "开始日期",
      endDate: "结束日期"
    });
    if (!nonEmpty(row.startTime) && nonEmpty(row.startDate)) row.startTime = row.startDate;
    if (!nonEmpty(row.endTime) && nonEmpty(row.endDate)) row.endTime = row.endDate;
    return row;
  }).filter(Boolean).filter((row) => row.name || row.details));

  const campusLeadership = sortLatestFirst(asItems(sections.student).map((item) => {
    const v = valuesOf(item);
    const row = copyMapped(v, {
      projectName: "组织名称",
      title: "职位",
      description: "工作内容",
      roleDescription: "本人职责",
      startTime: "开始时间",
      endTime: "结束时间",
      startDate: "开始日期",
      endDate: "结束日期"
    });
    if (!nonEmpty(row.startTime) && nonEmpty(v["开始日期"])) row.startTime = v["开始日期"];
    if (!nonEmpty(row.endTime) && nonEmpty(v["结束日期"])) row.endTime = v["结束日期"];
    if (nonEmpty(v["本人职责"])) row.description = [row.description, v["本人职责"]].filter(nonEmpty).join("；");
    return row;
  }).filter((row) => row.projectName || row.title));

  const awards = sortLatestFirst(asItems(sections.awards).map((item) => {
    const v = valuesOf(item);
    const row = copyMapped(v, {
      awardName: "奖惩名称",
      awardLevel: "奖励等级",
      awardDescription: "奖惩描述",
      awardIssuer: "颁奖单位",
      awardTime: "奖惩时间",
      awardDate: "奖惩日期"
    });
    if (!nonEmpty(row.awardTime) && nonEmpty(v["奖惩日期"])) row.awardTime = v["奖惩日期"];
    return row;
  }).filter((row) => row.awardName));

  const languageSkills = asItems(sections.language).map((item) => {
    const v = valuesOf(item);
    const row = copyMapped(v, {
      name: "外语种类",
      proficiency: "掌握程度",
      certificate: "证书名称（技能名称）",
      certificateName: "证书名称（技能名称）",
      score: "成绩",
      obtainedTime: "获得时间",
      speakingListening: "听说能力",
      readingWriting: "读写能力",
      otherEnglishExam: "其他英语等级考试",
      otherEnglishScore: "其他英语等级考试成绩"
    });
    row.cet4Score = v["CET4成绩"];
    row.cet6Score = v["CET6成绩"];
    row.englishLevel = v["英语熟练度"] || row.proficiency;
    // Keep standardized English-exam facts explicit in the normalized adapter.
    // Existing sites can continue using certificateName/score, while fixed-form
    // campus pages can consume CET4/CET6 and "other English exam" independently.
    if (!nonEmpty(row.otherEnglishExam) && /雅思|IELTS/i.test(String(row.certificateName || row.certificate || ""))) {
      row.otherEnglishExam = "IELTS";
    }
    if (!nonEmpty(row.otherEnglishScore) && /雅思|IELTS/i.test(String(row.otherEnglishExam || row.certificateName || row.certificate || ""))) {
      row.otherEnglishScore = row.score;
    }
    if (/雅思|IELTS/i.test(String(row.otherEnglishExam || row.certificateName || row.certificate || "")) && nonEmpty(row.otherEnglishScore)) {
      row.ieltsScore = row.otherEnglishScore;
    }
    return row;
  }).filter((row) => row.name || row.certificateName);

  const familyMembers = asItems(sections.family).map((item) => {
    const v = valuesOf(item);
    return copyMapped(v, {
      name: "姓名",
      birthDate: "出生日期",
      politicalStatus: "政治面貌",
      relationship: "关系",
      company: "公司",
      position: "职位",
      phone: "电话"
    });
  }).filter((row) => row.name || row.relationship);

  const selfIntroduction = {};
  if (nonEmpty(selfText)) selfIntroduction.selfIntroduction = selfText;

  function normalizeQuestionKey(text) {
    return String(text || "")
      .replace(/[\s：:*?？（）()【】\[\]「」'"“”‘’.,，。;；、]/g, "")
      .replace(/必填|选填|请输入|请选择/g, "")
      .toLowerCase();
  }

  // Build161: the profile editor intentionally allows users to add new fields.
  // Simple-section values must therefore remain usable even before we add a new
  // canonical mapping for them. Expose them as exact-label custom answers; the
  // existing conservative custom-answer runtime only fills a highly matching
  // empty control and refuses consent/declaration/final-submit prompts.
  // Repeat sections are deliberately excluded so duplicate labels such as
  // “学校 / 公司 / 项目名称” never lose RecordGraph ownership.
  const libraryExactAnswers = [];
  Object.values(sections || {}).forEach((section) => {
    if (!section || section.kind === "repeat") return;
    const values = asValues(section);
    Object.entries(values).forEach(([question, answer]) => {
      if (!String(question || "").trim() || !nonEmpty(answer)) return;
      libraryExactAnswers.push({ question: String(question).trim(), answer: String(answer) });
    });
    const customRows = Array.isArray(section.custom) ? section.custom : [];
    customRows.forEach((row) => {
      const question = String(row && (row.label || row.question) || "").trim();
      const answer = row && row.value != null ? String(row.value) : (row && row.answer != null ? String(row.answer) : "");
      if (question && answer.trim()) libraryExactAnswers.push({ question, answer });
    });
  });

  const explicitAnswers = Array.isArray(raw.profileV2.questionBank)
    ? raw.profileV2.questionBank.map((row) => ({
        question: String(row && row.question || "").trim(),
        answer: row && row.answer != null ? String(row.answer) : "",
      })).filter((row) => row.question && row.answer.trim() !== "")
    : [];
  const customAnswers = [];
  const seenCustomQuestions = new Set();
  // Explicit Q&A has priority over automatically exposed library fields.
  explicitAnswers.concat(libraryExactAnswers).forEach((row) => {
    const key = normalizeQuestionKey(row.question);
    if (!key || seenCustomQuestions.has(key)) return;
    seenCustomQuestions.add(key);
    customAnswers.push(row);
  });

  // Intentionally omit declaration/consent fields. v0.1 never turns consent,
  // background-check declarations, privacy acknowledgements or final submission
  // into automatic actions.
  const disciplinaryAction = { value: "无", textValue: "无", booleanValue: "否" };
  const awardsSummary = awards.map((row) => row.awardName).filter(nonEmpty).join("；");
  const awardsAndDisciplineSummary = "奖励情况：" + (awardsSummary || "无") + "；惩处情况：无";
  return {
    basicInfo,
    jobIntention,
    education,
    internshipExperience,
    workExperience: [],
    projectExperience,
    campusLeadership,
    // 用户明确授权“学生工作”和“在校经历”读取同一 canonical 数据；
    // 社会实践仍保留独立 category，绝不从这里复制。
    campusActivities: campusLeadership,
    awards,
    disciplinaryAction,
    awardsSummary,
    awardsAndDisciplineSummary,
    languageSkills,
    certificates: [],
    familyMembers,
    trainingExperience: [],
    publications: [],
    patents: [],
    selfIntroduction,
    customAnswers
  };
}

function loadProfile(filePath) {
  const raw = JSON.parse(fs.readFileSync(filePath, "utf8"));
  return normalizeProfileBackup(raw);
}

function summarizeResumeData(data) {
  const arrays = [
    "education", "internshipExperience", "workExperience", "projectExperience",
    "campusLeadership", "awards", "languageSkills", "certificates", "familyMembers"
  ];
  return {
    basicFields: Object.keys(data.basicInfo || {}).length,
    intentionFields: Object.keys(data.jobIntention || {}).length,
    sections: arrays.reduce((acc, key) => {
      acc[key] = Array.isArray(data[key]) ? data[key].length : 0;
      return acc;
    }, {})
  };
}

module.exports = { normalizeProfileBackup, loadProfile, summarizeResumeData };
