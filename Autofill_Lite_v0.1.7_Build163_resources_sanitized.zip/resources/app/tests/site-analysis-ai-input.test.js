"use strict";
const assert = require("assert");
const fs = require("fs");
const os = require("os");
const path = require("path");
const {
  buildAiSiteInput,
  compactAiField,
  snapshotHasAiEvidence,
  annotateSnapshotFields,
  deriveReviewSuggestion,
  AI_PROFILE_FIELD_KEYS,
  patchTargetForField,
  isStablePatchSelector
} = require("../site-analysis-ai-input");

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "af-ai-input-"));
const bundleFile = path.join(tmp, "bundle__example.com__resume.json");
const bundle = {
  schemaType: "autofill-lite-site-analysis-bundle",
  schemaVersion: 1,
  hostname: "example.com",
  pathname: "/resume",
  observed: { sections: ["个人信息"], navigationItems: [], controlTypes: ["text"] },
  snapshots: [
    {
      fingerprint: "legacy",
      at: "2026-09-15T00:00:00Z",
      analysis: { schemaVersion: 2, staticScan: { controlCount: 1, fields: [{ label: "旧字段" }] } }
    },
    {
      fingerprint: "empty",
      at: "2026-09-15T00:01:00Z",
      analysis: { schemaVersion: 4, staticScan: { controlCount: 0, fields: [] }, navigation: { items: [] }, interactive: { candidates: [], modules: [] } }
    },
    {
      fingerprint: "current",
      at: "2026-09-15T00:02:00Z",
      analysis: {
        schemaVersion: 4,
        configProbe: { serverConfigEnabled: false, builtInConfig: { name: "example/resume", type: "structured" }, specialWorkflowId: "" },
        staticScan: {
          controlCount: 3,
          sections: [{ title: "个人信息", fieldCount: 3, labels: ["姓名", "证件号码类型", "陌生字段"], controlTypes: ["text", "element-select"] }],
          fields: [
            {
              section: "个人信息", label: "姓名", labelSource: "form_item_label", safeSemanticCandidates: ["姓名"],
              controlType: "text", widgetFamily: "native", placeholder: "请输入姓名", selectorHint: "#name", selectorHitCount: 1,
              selectorCandidates: [{ selector: "#name", hitCount: 1, kind: "id" }], coreCategory: "示例资料Info", coreFieldKey: "name", coreMappingEvidence: "姓名",
              coreMappingStatus: "trusted", coreMappingMethod: "dictionary_exact_alias", coreMappingConfidence: 1, coreMappingReasons: [],
              currentValuePresent: true, nearbyTextCandidates: ["用户真实姓名"]
            },
            {
              section: "个人信息", label: "证件号码类型", labelSource: "form_item_label", safeSemanticCandidates: ["证件号码类型"],
              controlType: "element-select", widgetFamily: "element", placeholder: "请选择证件类型", selectorHint: "#idType", selectorHitCount: 1,
              coreCategory: "示例资料Info", coreFieldKey: "idNumber", coreMappingEvidence: "证件号码类型",
              coreMappingStatus: "tentative", coreMappingMethod: "core_matcher_fallback", coreMappingConfidence: 0.45, coreMappingReasons: ["fuzzy_or_semantic_core_match"]
            },
            {
              section: "个人信息", label: "页面旁边的值", labelSource: "nearby_text", safeSemanticCandidates: ["customField"],
              controlType: "text", widgetFamily: "native", name: "customField", selectorHint: "input[name=customField]", selectorHitCount: 1,
              coreCategory: "示例资料Info", coreFieldKey: "", coreMappingStatus: "unmapped", coreMappingReasons: ["no_safe_semantic_match"], currentValuePresent: true, nearbyTextCandidates: ["不应进入AI包的自由文本"]
            }
          ]
        },
        navigation: { items: [] },
        interactive: { candidates: [], modules: [] }
      }
    }
  ]
};
fs.writeFileSync(bundleFile, JSON.stringify(bundle, null, 2));

assert.strictEqual(snapshotHasAiEvidence(bundle.snapshots[0]), false, "legacy schema snapshot must be excluded");
assert.strictEqual(snapshotHasAiEvidence(bundle.snapshots[1]), false, "empty current-schema snapshot must be excluded");
assert.strictEqual(snapshotHasAiEvidence(bundle.snapshots[2]), true, "current evidence snapshot must be included");

const compact = compactAiField(bundle.snapshots[2].analysis.staticScan.fields[2]);
assert.strictEqual(compact.label, "", "nearby-text-derived label must not leave the AI privacy boundary");
assert.deepStrictEqual(compact.semanticCandidates, ["customField"], "only safe semantic candidates should be exported");
assert.strictEqual(Object.prototype.hasOwnProperty.call(compact, "currentValuePresent"), false, "value-presence telemetry should be omitted from AI packet");

const result = buildAiSiteInput(bundleFile, "https://example.com/resume?token=secret#x", tmp);
assert(result && fs.existsSync(result.file), "AI input file should be written");
assert.strictEqual(result.snapshotCount, 1, "only one current, non-empty snapshot should remain");
assert.strictEqual(result.totalFieldCount, 3);
assert.strictEqual(result.mappedFieldCount, 1);
assert.strictEqual(result.tentativeMappedFieldCount, 1);
assert.strictEqual(result.unmappedFieldCount, 1);
assert.strictEqual(result.aiMappingNeededFieldCount, 2);
assert.strictEqual(result.legacySnapshotCountExcluded, 1);
assert.strictEqual(result.emptySnapshotCountExcluded, 1);
const out = JSON.parse(fs.readFileSync(result.file, "utf8"));
assert.strictEqual(out.page.hostname, "example.com");
assert.strictEqual(out.page.pathname, "/resume");
assert.strictEqual(out.safety.resumeValuesIncluded, false);
assert.strictEqual(out.safety.nearbyFreeTextExcludedFromAiPacket, true);
assert.strictEqual(out.safety.formGraphCurrentValuesIncluded, false);
assert.strictEqual(out.safety.formGraphArbitraryRowTextIncluded, false);
assert.strictEqual(out.snapshots.length, 1);
assert.strictEqual(out.schemaVersion, 4);
assert.strictEqual(out.mappingSummary.trustedCoreMappedFieldCount, 1);
assert.strictEqual(out.mappingSummary.tentativeCoreMappedFieldCount, 1);
assert.strictEqual(out.mappingSummary.unmappedFieldCount, 1);
const serialized = JSON.stringify(out);
assert(!serialized.includes("secret"), "query/hash secrets must not be persisted");
assert(!serialized.includes("用户真实姓名"), "nearby free text must not be persisted to AI packet");
assert(!serialized.includes("不应进入AI包的自由文本"), "nearby free text must not be persisted to AI packet");
assert(!serialized.includes("currentValuePresent"), "current value presence must not be exported to AI packet");
assert(result.reviewFile && fs.existsSync(result.reviewFile), "compact AI review file should be written");
const review = JSON.parse(fs.readFileSync(result.reviewFile, "utf8"));
assert.strictEqual(review.schemaType, "autofill-lite-ai-mapping-review-request");
assert.strictEqual(review.schemaVersion, 2);
assert.strictEqual(review.reviewFields.length, 2, "only tentative/unmapped fields should need AI review");
assert(review.reviewFields.some((field) => field.suggestedCoreMappingStatus === "tentative"), "tentative core mapping must be exposed for review");
assert(review.reviewFields.every((field) => /^fld_[0-9a-f]{16}$/.test(field.fieldId)), "every review field must have a stable fieldId");
assert(review.reviewFields.every((field) => field.patchTarget && field.patchTarget.kind), "every review field must expose a declarative patch target");
assert(review.profileContract && review.profileContract.unknownKeysForbidden === true, "API review must include an explicit profile-key contract");
assert(review.profileContract.categories.示例资料Info.includes("idType"), "profile contract must expose valid 示例资料-info keys");
assert(review.outputContract.mustReferenceFieldId === true && review.outputContract.mayChangeCategory === true, "future API output must bind to fieldId and may correct a wrong section category");
assert(review.reviewFields.every((field) => !Object.prototype.hasOwnProperty.call(field, "currentValuePresent")), "review packet must not include current value telemetry");


const pair = annotateSnapshotFields([
  { section: "示例资料-1 删除经历", label: "选择日期", labelSource: "placeholder", semanticCandidates: ["选择日期"], controlType: "element-date", selectorHint: "#start", selectorHitCount: 1, coreCategory: "示例资料Experience", coreFieldKey: "", coreMappingStatus: "unmapped", options: [] },
  { section: "示例资料-1 删除经历", label: "选择日期", labelSource: "placeholder", semanticCandidates: ["选择日期"], controlType: "element-date", selectorHint: "#end", selectorHitCount: 1, coreCategory: "示例资料Experience", coreFieldKey: "", coreMappingStatus: "unmapped", options: [] }
]);
assert.strictEqual(pair[0].sameSemanticCount, 2);
assert.strictEqual(pair[0].sameSemanticOrdinal, 1);
assert.strictEqual(pair[1].sameSemanticOrdinal, 2);
assert.notStrictEqual(pair[0].fieldId, pair[1].fieldId, "same-label start/end controls need distinct stable identities");
assert.strictEqual(deriveReviewSuggestion(pair[0]).fieldKey, "startTime");
assert.strictEqual(deriveReviewSuggestion(pair[1]).fieldKey, "endTime");
assert(deriveReviewSuggestion(pair[0]).reasons.includes("positional_date_pair"));

const genderField = annotateSnapshotFields([{
  section: "基础信息", label: "", labelSource: "nearby_text", semanticCandidates: [], controlType: "radio",
  selectorHint: ".sex-scroll .el-radio:nth-of-type(1)", selectorHitCount: 1, coreCategory: "示例资料Info",
  coreFieldKey: "", coreMappingStatus: "unmapped", options: ["男", "女"]
}])[0];
const genderSuggestion = deriveReviewSuggestion(genderField);
assert.strictEqual(genderSuggestion.fieldKey, "gender");
assert(genderSuggestion.reasons.includes("gender_option_pair"));

const invalidKey = deriveReviewSuggestion({
  coreCategory: "示例资料Skills", coreFieldKey: "ccbEnglishLevel", coreMappingStatus: "tentative",
  coreMappingReasons: ["fuzzy_or_semantic_core_match"], semanticCandidates: ["英语口语水平"]
});
assert.strictEqual(invalidKey.fieldKey, "", "keys outside the normalized profile contract must not anchor the AI");
assert(invalidKey.reasons.includes("suggested_key_outside_profile_contract"));
assert(AI_PROFILE_FIELD_KEYS.示例资料Skills.includes("cet4Score") && AI_PROFILE_FIELD_KEYS.示例资料.includes("integratedTraining"));

const badBooleanAnchor = deriveReviewSuggestion({
  coreCategory: "示例资料Info", coreFieldKey: "country", coreMappingStatus: "tentative",
  coreMappingReasons: ["fuzzy_or_semantic_core_match"], semanticCandidates: ["是否具有其他国家国籍"]
});
assert.strictEqual(badBooleanAnchor.fieldKey, "", "boolean questions must not keep a non-boolean Core anchor");
assert(badBooleanAnchor.reasons.includes("boolean_question_non_boolean_key"));

const smallLanguageScore = deriveReviewSuggestion({
  coreCategory: "示例资料Skills", coreFieldKey: "name", coreMappingStatus: "tentative",
  coreMappingReasons: ["fuzzy_or_semantic_core_match"], semanticCandidates: ["小语种掌握情况及水平（成绩）"]
});
assert.strictEqual(smallLanguageScore.fieldKey, "", "示例资料 score/proficiency text must not be anchored to 示例资料 name");
assert(smallLanguageScore.reasons.includes("示例资料_name_semantic_conflict"));

console.log("site analysis AI input regression: PASS");

// Build 50: transient state selectors must never become patch targets.
assert.strictEqual(isStablePatchSelector("label.el-radio.is-checked"), false, "checked-state class is transient");
assert.strictEqual(isStablePatchSelector("input:checked"), false, ":checked is transient");
assert.strictEqual(isStablePatchSelector("div[aria-selected=\"true\"]"), false, "aria selected state is transient");
assert.strictEqual(isStablePatchSelector("div.info_box.jobCityDistributable > label.el-radio:nth-of-type(2)"), true, "structural selector should remain eligible");
const transientPatchTarget = patchTargetForField({
  label: "",
  labelSource: "nearby_text",
  sameSemanticCount: 2,
  selectorHitCount: 1,
  selectorHint: "label.el-radio.is-checked",
  widgetSelectorHitCount: 0,
  widgetSelectorHint: ""
});
assert.deepStrictEqual(transientPatchTarget, { kind: "field_id_only" }, "transient unique selector must fall back to field_id_only");
