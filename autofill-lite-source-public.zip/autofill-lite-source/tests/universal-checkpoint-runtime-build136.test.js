"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const root = path.join(__dirname, "..");
const coreSource = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-core.js"), "utf8");
const runtimeSource = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-runtime.js"), "utf8");
const store = {};
const sandbox = {
  window: { AF: {}, location: { hostname: "example.test", pathname: "/resume", hash: "#/edit" } },
  chrome: { storage: { local: {
    get(keys, cb) { const out = {}; keys.forEach(k => { if (Object.prototype.hasOwnProperty.call(store, k)) out[k] = store[k]; }); cb(out); },
    set(payload, cb) { Object.assign(store, payload); cb && cb(); },
    remove(keys, cb) { keys.forEach(k => delete store[k]); cb && cb(); }
  } }, runtime: { lastError: null } },
  console, Date, Math, Promise, Set, setTimeout, clearTimeout
};
vm.createContext(sandbox);
vm.runInContext(coreSource, sandbox, { filename: "checkpoint-core.js" });
vm.runInContext(runtimeSource, sandbox, { filename: "checkpoint-runtime.js" });
const RT = sandbox.window.AF.CheckpointRuntime;
const CC = sandbox.window.AF.CheckpointCore;

(async () => {
  const loc = sandbox.window.location;
  const run1 = await RT.begin(loc, { workflowId: RT.WORKFLOW_ID });
  const field = RT.facade(run1, "field");
  const record = RT.facade(run1, "record");
  const section = RT.facade(run1, "section");
  assert.strictEqual(run1.resumed, false, "A: fresh universal run must not resume");

  const fieldMeta = { category: "basicInfo", fieldKey: "name", label: "姓名", occurrence: 0, sectionTitle: "个人信息" };
  const sectionMeta = { sectionTitle: "个人信息", category: "" };
  const row = { company: "公司A", position: "实习生", startTime: "2025-01", endTime: "2025-02" };
  const recordMeta = { category: "internshipExperience", sectionTitle: "实习经历", repeatIndex: 0, repeatTotal: 2, row, recordFingerprint: CC.recordFingerprint(row) };
  await field.markCompleted(fieldMeta);
  await section.markCompleted(sectionMeta);
  await record.pause(recordMeta, "需要人工处理", { forceRecoverable: true });
  assert(store[RT.STORAGE_KEY], "B: active universal checkpoint must persist one session");
  assert.strictEqual(store[RT.STORAGE_KEY].active.granularity, "record", "B: active granularity should be record");
  assert(store[RT.STORAGE_KEY].completed.field.length === 1 && store[RT.STORAGE_KEY].completed.section.length === 1, "B: same session must carry prior field/section ledger");

  const run2 = await RT.begin(loc, { workflowId: RT.WORKFLOW_ID });
  const field2 = RT.facade(run2, "field");
  const record2 = RT.facade(run2, "record");
  const section2 = RT.facade(run2, "section");
  const workflow2 = RT.facade(run2, "workflow");
  assert.strictEqual(run2.resumed, true, "C: rerun should resume universal session");
  assert.strictEqual(record2.shouldSkip(recordMeta), true, "C: rerun itself acknowledges paused record");
  assert.strictEqual(field2.shouldSkip(fieldMeta), true, "C: field completed before checkpoint must remain skipped");
  assert.strictEqual(section2.shouldSkip(sectionMeta), true, "C: section completed before checkpoint must remain skipped");

  await workflow2.pause({ workflowId: RT.WORKFLOW_ID, name: "最终人工流程", sectionTitle: "最终人工流程" }, "需要上传附件", { forceRecoverable: true });
  assert.strictEqual(store[RT.STORAGE_KEY].active.granularity, "workflow", "D: same runtime supports workflow checkpoint");
  assert(store[RT.STORAGE_KEY].completed.record.length === 1, "D: acknowledged record must survive into next checkpoint");

  const run3 = await RT.begin(loc, { workflowId: RT.WORKFLOW_ID });
  const workflow3 = RT.facade(run3, "workflow");
  assert.strictEqual(workflow3.shouldSkip({ workflowId: RT.WORKFLOW_ID, name: "最终人工流程", sectionTitle: "最终人工流程" }), true, "E: workflow checkpoint should acknowledge on rerun");
  await run3.finalize();
  assert.strictEqual(store[RT.STORAGE_KEY], undefined, "E: completed recovery chain must leave no permanent skip cache");

  const run4 = await RT.begin(loc, { workflowId: RT.WORKFLOW_ID });
  assert.strictEqual(RT.facade(run4, "field").shouldSkip(fieldMeta), false, "F: later normal run must start clean");
  assert.strictEqual(RT.facade(run4, "record").shouldSkip(recordMeta), false, "F: later normal run must not inherit record tokens");
  console.log("universal-checkpoint-runtime-build136.test.js passed (A-F)");
})().catch(err => { console.error(err); process.exit(1); });
