"use strict";

function clamp(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(1, n));
}

function buildLocalSemanticFallbackPatch(review, options) {
  const opts = Object.assign({ minCandidateConfidence: 0.5 }, options || {});
  const fields = Array.isArray(review && review.reviewFields) ? review.reviewFields : [];
  const decisions = fields.map((field) => {
    const fieldId = String(field && field.fieldId || "");
    const category = String(field && field.coreCategory || "").trim();
    const fieldKey = String(field && field.suggestedCoreFieldKey || "").trim();
    const confidence = clamp(field && field.suggestedCoreMappingConfidence);
    const reasons = Array.isArray(field && field.reviewReasons) ? field.reviewReasons.map(String) : [];
    const allowed = review && review.profileContract && review.profileContract.categories || {};
    const contractOk = !!(category && fieldKey && Array.isArray(allowed[category]) && allowed[category].includes(fieldKey));
    if (contractOk && confidence >= Number(opts.minCandidateConfidence || 0.5)) {
      return {
        fieldId,
        decision: "map",
        category,
        fieldKey,
        confidence,
        reason: "local_semantic_fallback:" + (reasons.slice(0, 2).join("|") || String(field && field.suggestedCoreMappingMethod || "core_hint"))
      };
    }
    return {
      fieldId,
      decision: "leave_unmapped",
      category: "",
      fieldKey: "",
      confidence: Math.max(0.5, confidence),
      reason: "local_semantic_fallback_no_safe_mapping"
    };
  });
  return {
    schemaType: "autofill-lite-ai-semantic-patch",
    schemaVersion: 1,
    decisions,
    localFallback: true
  };
}

module.exports = { buildLocalSemanticFallbackPatch };
