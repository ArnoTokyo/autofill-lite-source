"use strict";
const fs = require("fs");
const path = require("path");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const 示例资料flow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-示例资料flow.js"), "utf8");
const sites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
assert(示例资料flow.includes('getManualWorkflowCheckpointForCurrentPage'), "checkpoint peek API missing");
assert(main.includes('resumeStartsAfterBasic'), "checkpoint-first resume guard missing");
assert(main.includes('skippedForResumeCheckpoint: true'), "trusted 示例资料 preflight must be skipped during 示例资料 resume");
assert(main.includes('manual_checkpoint_resume_after_示例资料'), "checkpoint-first resume diagnostic reason missing");
assert(sites.includes('bankcommCollectEducationReadOnlyCandidates'), "saved 示例资料 card fallback missing");
assert(sites.includes('edit_action_scope'), "saved 示例资料 card edit-action scope missing");
assert(sites.includes('level_text_scope'), "saved 示例资料 card text-anchored scope missing");
console.log("bankcomm-resume-state-fix.test.js passed");
