"use strict";

const { contextBridge, ipcRenderer } = require("electron");
const path = require("path");
const { pathToFileURL } = require("url");

contextBridge.exposeInMainWorld("lite", {
  guestPreloadUrl: pathToFileURL(path.join(__dirname, "guest-preload.js")).toString(),
  runAutofill: (guestId) => ipcRenderer.invoke("lite:run-autofill", guestId),
  analyzeSite: (guestId) => ipcRenderer.invoke("lite:analyze-site", guestId),
  testNextSection: (guestId) => ipcRenderer.invoke("lite:test-next-section", guestId),
  probeEducationEditor: (guestId) => ipcRenderer.invoke("lite:probe-education-editor", guestId),
  previewFillEducationRecord: (guestId) => ipcRenderer.invoke("lite:preview-fill-education-record", guestId),
  continuePreviewEducationRecords: (guestId) => ipcRenderer.invoke("lite:continue-preview-education-records", guestId),
  continueEducationRecords: (guestId) => ipcRenderer.invoke("lite:continue-education-records", guestId),
  surveyResumeSectionEditors: (guestId) => ipcRenderer.invoke("lite:survey-resume-section-editors", guestId),
  previewResumeSections: (guestId) => ipcRenderer.invoke("lite:preview-resume-sections", guestId),
  saveResumeSections: (guestId) => ipcRenderer.invoke("lite:save-resume-sections", guestId),
  runAiMapping: (guestId) => ipcRenderer.invoke("lite:run-ai-mapping", guestId),
  verifySiteCandidate: (guestId) => ipcRenderer.invoke("lite:verify-site-candidate", guestId),
  getAiSettings: () => ipcRenderer.invoke("lite:get-ai-settings"),
  saveAiSettings: (payload) => ipcRenderer.invoke("lite:save-ai-settings", payload),
  stopAutofill: (guestId) => ipcRenderer.invoke("lite:stop-autofill", guestId),
  getProgress: (guestId) => ipcRenderer.invoke("lite:get-progress", guestId),
  getBuildInfo: () => ipcRenderer.invoke("lite:get-build-info"),
  getProfileSummary: () => ipcRenderer.invoke("lite:get-profile-summary"),
  openProfileEditor: () => ipcRenderer.invoke("lite:open-profile-editor"),
  openProfileQuick: () => ipcRenderer.invoke("lite:open-profile-quick"),
  copyText: (value) => ipcRenderer.invoke("lite:copy-text", value),
  getProfileRaw: () => ipcRenderer.invoke("lite:get-profile-raw"),
  saveProfileRaw: (payload) => ipcRenderer.invoke("lite:save-profile-raw", payload),
  openDataDir: () => ipcRenderer.invoke("lite:open-data-dir"),
  saveDiagnostic: (payload) => ipcRenderer.invoke("lite:save-diagnostic", payload),

  openBookmarkManager: (payload) => ipcRenderer.invoke("lite:open-bookmark-manager", payload),
  getBookmarkLibrary: () => ipcRenderer.invoke("lite:get-bookmark-library"),
  getBookmarkPrefill: () => ipcRenderer.invoke("lite:get-bookmark-prefill"),
  addBookmarkFolder: (payload) => ipcRenderer.invoke("lite:add-bookmark-folder", payload),
  addBookmark: (payload) => ipcRenderer.invoke("lite:add-bookmark", payload),
  updateBookmarkNode: (payload) => ipcRenderer.invoke("lite:update-bookmark-node", payload),
  moveBookmarkNode: (payload) => ipcRenderer.invoke("lite:move-bookmark-node", payload),
  deleteBookmarkNode: (payload) => ipcRenderer.invoke("lite:delete-bookmark-node", payload),
  searchBookmarks: (query) => ipcRenderer.invoke("lite:search-bookmarks", query),
  openBookmarkUrl: (url) => ipcRenderer.invoke("lite:open-bookmark-url", url),
  navigateGuest: (guestId, url) => ipcRenderer.invoke("lite:navigate-guest", guestId, url),
  onBookmarkPrefill: (callback) => {
    if (typeof callback !== "function") return () => {};
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on("lite:bookmark-prefill", listener);
    return () => ipcRenderer.removeListener("lite:bookmark-prefill", listener);
  },
  onNavigate: (callback) => {
    if (typeof callback !== "function") return () => {};
    const listener = (_event, url) => callback(url);
    ipcRenderer.on("lite:navigate", listener);
    return () => ipcRenderer.removeListener("lite:navigate", listener);
  },
  onProfileUpdated: (callback) => {
    if (typeof callback !== "function") return () => {};
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on("lite:profile-updated", listener);
    return () => ipcRenderer.removeListener("lite:profile-updated", listener);
  }
});
