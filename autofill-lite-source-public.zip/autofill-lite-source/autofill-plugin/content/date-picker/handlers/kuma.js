// content/date-picker/handlers/kuma.js — 阿里 Kuma 日期选择器 (.kuma-calendar-picker-input)
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   工厂分支 Kn.create() case "kuma": 行46001 -> Qn
//   Qn.setValue: 行 46375-46461 (string 走 Rt() 单选; object 走 findSimilarElements+ho() 兄弟填结束)
//   Rt()/qt() (click 打开 .kuma-calendar-picker 面板 -> 调通用导航器 w()): 行 31665-31700
//   w() 调用选择器: 行 31696 (已核实, 逐参数照搬; 注意源码把 monthPanelSelector 传成字符串 "null")
//
// 注: 之前版本是"委托给 ant 工厂 + input.value= 兜底"。阿里 kuma 面板是 .kuma-calendar-picker，
//     ant 工厂找的是 .ant-picker-dropdown 面板, 根本找不到 -> 必然失败退到直接赋值 -> 填不上。
//     现按源码恢复真实的 kuma 面板导航。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  // 源码 Rt()/qt() (行31665): click 打开 kuma 面板, 再用通用导航器 w() 选日期
  async function kumaSingleNavigate(triggerEl, dateStr) {
    triggerEl.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
    await AF.Utils.sleep(AF.DatePicker._STANDARD_DELAY || 30); // 源码 standardSleep()
    var panel = document.querySelector('.kuma-calendar-picker:not([style*="display: none"])');
    if (!panel) throw new Error("Calendar picker not found or not visible");
    // 源码行31696: w(panel, dateStr, ".kuma-calendar-month-panel-year-select",
    //   ".kuma-calendar-year-panel-year", true, ".kuma-calendar-year-panel-decade-select-content",
    //   ".kuma-calendar-year-panel-next-decade-btn", ".kuma-calendar-year-panel-prev-decade-btn",
    //   "null", ".kuma-calendar-month-panel-month", ".kuma-calendar-day-panel-day")
    var ok = await AF.DatePicker._navigatePanel({
      container: panel,
      dateString: dateStr,
      headerClickSelector: ".kuma-calendar-month-panel-year-select",
      yearCellSelector: ".kuma-calendar-year-panel-year",
      disabledClassList: true,
      yearBoundarySelector: ".kuma-calendar-year-panel-decade-select-content",
      nextYearSelector: ".kuma-calendar-year-panel-next-decade-btn",
      prevYearSelector: ".kuma-calendar-year-panel-prev-decade-btn",
      monthPanelSelector: "null", // 源码原样传字符串 "null" (等效: 无独立月份子面板, 直接找月份格子)
      monthCellSelector: ".kuma-calendar-month-panel-month",
      dayCellSelector: ".kuma-calendar-day-panel-day",
      maxRetries: 20,
    });
    if (!ok) throw new Error("Kuma calendar navigation failed");
    return true;
  }

  AF.DatePicker._registry["kuma"] = function (element, valueType) {
    return {
      setValue: async function (value) {
        try {
          if (!value) throw new Error("日期为空");
          if (typeof value === "string" || valueType === "string") {
            return await kumaSingleNavigate(element, value);
          }
          if (typeof value !== "object" || !("startTime" in value) || !("endTime" in value)) {
            throw new Error("当option为对象时，dateValue必须包含startTime和endTime属性");
          }
          // 源码 Qn.setValue object 分支: 先取兄弟候选, 填开始, 再挑"结束"兄弟框填结束
          var candidates = AF.DomUtils.findSimilarElements(element, 4, { sameTag: true, sameClass: true, sameParent: false });
          await kumaSingleNavigate(element, value.startTime);
          await AF.Utils.sleep(500);
          if (candidates.length > 0) {
            var best = AF.DatePicker._pickEndDateCandidate(element, candidates);
            await kumaSingleNavigate(best, value.endTime);
          } else {
            var surrounding = AF.DomUtils.findSurroundingInputs(element);
            if (surrounding.length > 0) await kumaSingleNavigate(surrounding[0], value.endTime);
          }
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
