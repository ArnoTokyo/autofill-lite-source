// content/date-picker/handlers/sd.js — 滴滴 SD UI 日期选择器
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   工厂分支 Kn.create() case "sd": closest(.month-range-select) -> ro(范围), 否则 -> eo(单选日历)。行46005-46010
//   eo.setValue (单选, 真正的日历面板): 行 46550-46583 (调用 Kt())
//   Kt()/Zt() (通用导航器 w(), 用属性前缀选择器): 行 32831-32885 — 已核实
//   findAncestorWithClassStartingWith (向上找 class 以 "sd-Dropdown-container" 开头的祖先): 行 27278-27298
//   ro.setValue (范围, .month-range-select.date_info, 本质是2或4个文本输入框直接填年月): 行 46584-46653 (调用 ne())
//   ne()/oe() (直接给 input[type=text] 赋年/月数字 + 可选"至今"复选框): 行 33492-33690 — 已核实
//     (源码里还有一个仅在"输入框数量介于2~4之间"这种罕见边界情况下才会用到的 ie() 兜底函数，未在
//     附近定位到具体实现，这里对该极端情况做了尽量填充的简化处理，见 ro 分支里的注释)
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  function findAncestorWithClassStartingWith(el, prefix) {
    var cur = el && el.parentElement;
    while (cur) {
      var classes = Array.from(cur.classList || []);
      if (classes.some(function (c) { return c.startsWith(prefix); })) return cur;
      cur = cur.parentElement;
    }
    return null;
  }

  function parseDateRangeValue(value) {
    if (!value) return null;
    if (typeof value === "object") return value;
    var text = String(value || "").trim();
    if (!text) return null;
    var parts = text.split(/\s*~\s*/);
    if (parts.length >= 2) {
      return {
        startTime: parts[0].trim(),
        endTime: parts[1].trim(),
        current: /^(至今|目前|现在|当前)$/.test(parts[1].trim()),
      };
    }
    return { startTime: text, endTime: text };
  }

  function findRangeContainer(element) {
    if (!element) return null;
    if (element.matches && element.matches(".month-range-select, .date_info, [class*='date_info']")) return element;
    return element.closest && element.closest(".month-range-select, .date_info, [class*='date_info']");
  }

  // ---- 单选: 真正的日历面板 (源码 Kt()/Zt(), 行32831) ----
  async function sdSingleNavigate(triggerEl, dateStr) {
    await AF.DomUtils.enhancedClick(triggerEl);
    await AF.Utils.sleep(300);
    var container = findAncestorWithClassStartingWith(triggerEl, "sd-Dropdown-container");
    if (!container) throw new Error("SD calendar picker not found or not visible");
    var ok = await AF.DatePicker._navigatePanel({
      container: container,
      dateString: dateStr,
      headerClickSelector: '[class^="sd-示例资料-selector-year"]',
      yearCellSelector: '[class^="sd-示例资料-year-item"]',
      disabledClassList: true,
      yearBoundarySelector: '[class^="sd-示例资料-selector-year"]',
      nextYearSelector: '[class*="sd-Icon-icondoubleRight"]',
      prevYearSelector: '[class*="sd-Icon-icondoubleLeft"]',
      monthPanelSelector: '[class^="sd-示例资料-selector-month"]',
      monthCellSelector: '[class^="sd-示例资料-year-item"]',
      dayCellSelector: '[class*="sd-示例资料-date-item"]',
      maxRetries: 20,
    });
    if (!ok) throw new Error("SD calendar navigation failed");
    return true;
  }

  // ---- 范围: .month-range-select.date_info, 直接填文本输入框 (源码 ne()/oe(), 行33492) ----
  async function sdRangeNavigate(container, dateValue) {
    if (!container || !dateValue) throw new Error("容器元素或日期对象为空");
    if (!dateValue.startTime) throw new Error("日期对象必须包含startTime属性");
    var inputs = Array.from(container.querySelectorAll('input[type="text"]'));

    if (inputs.length === 2) {
      var parts = dateValue.startTime.split("-").map(Number);
      await fillYm(inputs[0], parts[0]);
      await AF.Utils.sleep(300);
      await fillYm(inputs[1], parts[1]);
      return true;
    }

    if (dateValue.endTime === "至今" || dateValue.current === true) {
      var startParts = dateValue.startTime.split("-").map(Number);
      var checkbox = container.querySelector('input[type="checkbox"]');
      if (inputs.length < 2) throw new Error("未找到足够的输入框，至少需要2个，实际找到" + inputs.length + "个");
      if (!checkbox) throw new Error('未找到"至今"复选框');
      await fillYm(inputs[0], startParts[0]);
      await AF.Utils.sleep(300);
      await fillYm(inputs[1], startParts[1]);
      await AF.Utils.sleep(300);
      if (!checkbox.checked) {
        checkbox.click();
        await AF.Utils.sleep(300);
      }
      return true;
    }

    var sParts = dateValue.startTime.split("-").map(Number);
    var eParts = dateValue.endTime ? dateValue.endTime.split("-").map(Number) : [0, 0];

    if (inputs.length < 4) {
      // 简化重建: 源码此处走 ie() 兜底函数(未在源码中定位到具体实现)，这里尽量按现有输入框数量填入
      var vals = [sParts[0], sParts[1], eParts[0], eParts[1]];
      for (var i = 0; i < inputs.length; i++) {
        await fillYm(inputs[i], vals[i]);
        await AF.Utils.sleep(300);
      }
      return true;
    }

    var existingChecked = container.querySelector('input[type="checkbox"]');
    if (existingChecked && existingChecked.checked) {
      existingChecked.click();
      await AF.Utils.sleep(300);
    }
    await fillYm(inputs[0], sParts[0]);
    await AF.Utils.sleep(300);
    await fillYm(inputs[1], sParts[1]);
    await AF.Utils.sleep(300);
    await fillYm(inputs[2], eParts[0]);
    await AF.Utils.sleep(300);
    await fillYm(inputs[3], eParts[1]);
    return true;
  }

  async function fillYm(input, value) {
    if (!input || value == null || value === "") return false;
    var text = String(parseInt(value, 10) || value);
    var container = input.closest && (
      input.closest('[class^="sd-Dropdown-container"], [class*=" sd-Dropdown-container"]') ||
      input.closest('[class^="sd-Select-container"], [class*=" sd-Select-container"], [class*="sd-Select"]')
    );
    if (container && AF.SelectAdapter && typeof AF.SelectAdapter.create === "function") {
      var selected = await AF.SelectAdapter.create(container, "string").selectValue(text);
      if (selected) return true;
      if (/^\d{1,2}$/.test(text)) {
        selected = await AF.SelectAdapter.create(container, "string").selectValue(text + "月");
        if (selected) return true;
      }
    }
    input.focus && input.focus();
    input.click && input.click();
    try {
      var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      if (setter) setter.call(input, text);
      else input.value = text;
    } catch (e) {
      input.value = text;
    }
    input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    input.dispatchEvent(new Event("blur", { bubbles: true, composed: true }));
    await AF.Utils.sleep(80);
    return true;
  }

  AF.DatePicker._registry["sd"] = function (element, valueType) {
    var rangeContainer = findRangeContainer(element);
    var isRange = !!rangeContainer;
    return {
      setValue: async function (value) {
        try {
          if (!value) throw new Error("日期为空");
          if (isRange) {
            var rangeValue = parseDateRangeValue(value);
            if (typeof rangeValue !== "object" || !rangeValue.hasOwnProperty("startTime")) throw new Error("dateValue必须包含startTime属性");
            var isCurrentField = rangeContainer.classList.contains("date_info-nCj8tT_zjw") || rangeContainer.closest(".date_info-nCj8tT_zjw") || rangeContainer.classList.contains("apply-field-Q2iJ7AtQGX");
            if (rangeValue.current === true || rangeValue.endTime === "至今") {
              return await sdRangeNavigate(rangeContainer, { startTime: rangeValue.startTime, current: true });
            }
            if (!rangeValue.hasOwnProperty("endTime") && !isCurrentField) throw new Error("dateValue必须包含endTime属性");
            return await sdRangeNavigate(rangeContainer, rangeValue);
          }
          if (typeof value === "string" || valueType === "string") {
            return await sdSingleNavigate(element, value);
          }
          throw new Error("不支持的dateValue类型");
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
