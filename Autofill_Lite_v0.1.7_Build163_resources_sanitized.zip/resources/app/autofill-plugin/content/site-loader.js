// content/site-loader.js — AF.SiteLoader: 站点配置4级回退
// 源码参考:
//   入口 nn()/on():        webcrack-output/content/deobfuscated.js 行 76170-76222
//   第1级 getConfigForUrl: 行 72918
//   第2级 detectSiteType:  行 16614-16633 (7种DOM特征检测)
//   第3级 getConfigByHostname: 行 70156 (原版远程API GET /resume/:hostname)
//   第4级 analyzeHtmlForConfig: 行 70213 (原版远程API POST /analyze-resume)
//
// 改造点 (开发任务书.md 任务6.3):
//   - 第1级: 从 Qe 表提取到 AF.SITE_TEMPLATES (见 content/config/site-templates.js)，
//            原样保留 25 域名精确匹配 + 每个配置自身可能带的 urlPattern。
//   - 第2级: 7种DOM特征检测逻辑原样保留，检测条件与源码逐条对应。
//   - 第3级: 原版远程 API `/resume/{hostname}` 改为本地 chrome.storage.local 缓存
//            (key: site_config_cache_<hostname>，30天过期)。
//   - 第4级: 原版远程 AI 分析 `/analyze-resume` 不在本 Phase 实现 (由 Phase 8 负责)，
//            这里只提供 registerFallbackGenerator() 挂载点；若已注册且返回了配置，
//            会缓存进第3级同一个 storage key，下次直接命中第3级。
//
// 依赖: AF.PrivateSpecialSites / AF.SITE_TEMPLATES / AF.SITE_TEMPLATE_REFS / AF.SiteConfig.processConfig
//       (由 content/config/site-templates.js 提供，必须先于本文件加载，或至少在
//       第一次调用 AF.SiteLoader.loadConfig() 之前加载完毕)。
//
// 编码规则: loadConfig() 永不 throw —— 任何内部异常都 console.warn 后降级到下一级，
// 最终兜底返回 null（调用方已经能优雅处理"无配置"的情况）。
(function () {
  "use strict";

  var AF = (window.AF = window.AF || {});

  var CACHE_KEY_PREFIX = "site_config_cache_";
  var CACHE_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30天

  var fallbackGenerator = null;
  var preferLocalTemplatesForTesting = true;
  var prefetchedConfigs = {};

  function normalizeRouteKey(value) {
    var pathname = String(value || "").trim();
    if (!pathname || pathname === "default") return "default";
    try {
      if (/^https?:\/\//i.test(pathname)) pathname = new URL(pathname).pathname;
    } catch (e) {
      return "default";
    }
    pathname = pathname.split("?")[0].split("#")[0].replace(/\/+/g, "/").replace(/\/$/, "").toLowerCase() || "/";
    if (pathname.charAt(0) !== "/") pathname = "/" + pathname;
    return pathname.split("/").map(function (segment) {
      if (/^\d{5,}$/.test(segment)) return ":id";
      if (/^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(segment)) return ":id";
      if (/^[a-z0-9_-]{32,}$/i.test(segment)) return ":token";
      return segment;
    }).join("/").slice(0, 255);
  }

  function identityKey(hostname, urlOrRouteKey) {
    return String(hostname || "").trim().toLowerCase() + "|" + normalizeRouteKey(urlOrRouteKey || "default");
  }

  // 插件端测试补丁必须作用于所有配置来源：服务器、桌面端预取、本地缓存、
  // 内置模板和本次 AI 新生成配置。补丁先合并，再交给 SiteConfig 做公共处理。
  function processEffectiveConfig(config) {
    if (!config) return null;
    var effective = config;
    try {
      if (AF.GeneralSiteConfigPatch && typeof AF.GeneralSiteConfigPatch.apply === "function") {
        var patched = AF.GeneralSiteConfigPatch.apply(config, {
          hostname: window.location.hostname,
          routeKey: normalizeRouteKey(window.location.href),
        });
        effective = patched && patched.config || config;
        if (patched && patched.appliedPatches && patched.appliedPatches.length) {
          console.info("[AF.SiteLoader] 已应用插件端普通站点补丁", patched.appliedPatches);
        }
      }
    } catch (e) {
      console.warn("[AF.SiteLoader] 插件端普通站点补丁失败，继续使用原配置", e);
      effective = config;
    }
    return AF.SiteConfig && AF.SiteConfig.processConfig
      ? AF.SiteConfig.processConfig(effective)
      : effective;
  }

  // 平台模板只提供控件操作方式，AI 配置才描述企业真实表单结构。
  // AI 配置缺少 Phoenix 控件槽位时，仅补齐控件选择器，不覆盖 AI 的结构选择器。
  function overlayPlatformControlCapabilities(config, platform) {
    if (!config || !platform || !platform.preferAiStructure || !platform.selectors) return config;
    var result = Object.assign({}, config);
    result.selectors = Object.assign({}, config.selectors || {});
    ["radio", "checkbox", "select", "datePicker", "upload"].forEach(function (slot) {
      var fallback = platform.selectors[slot];
      if (!fallback) return;
      var current = result.selectors[slot];
      var currentText = typeof current === "string" ? current : current && (current.class || current.selector) || "";
      var fallbackText = typeof fallback === "string" ? fallback : fallback.class || fallback.selector || "";
      if (!currentText) result.selectors[slot] = Object.assign({}, fallback);
      else if (fallbackText && currentText.indexOf(fallbackText) === -1) {
        var merged = Object.assign({}, typeof current === "object" ? current : {});
        merged.class = currentText + ", " + fallbackText;
        result.selectors[slot] = merged;
      }
    });
    // Phoenix 的条件式经历是平台级交互：新增卡片后要在卡片内先选“是”，
    // 才会挂载真实字段。AI 只描述企业模块/字段，缺少这段平台流程时补上；
    // 已有企业专属 experience 配置只补缺失项，不覆盖它的按钮和保存策略。
    var platformExperience = platform.experience;
    if (platformExperience) {
      result.experience = Object.assign({}, platformExperience, result.experience || {});
      ["container", "card", "add", "editor", "save"].forEach(function (part) {
        if (platformExperience[part]) {
          result.experience[part] = Object.assign({}, platformExperience[part] || {}, (result.experience && result.experience[part]) || {});
        }
      });
      result.experience.platformConditionalGates = true;
      // Phoenix 的多经历执行器是客户端平台能力。AI 可以识别模块标题和字段，
      // 但不能覆盖卡片计数、添加入口和逐卡绑定参数；否则一次重新 AI 分析就会
      // 把真实多卡模块降级成单卡，只填写第一条经历。
      if (String(platform.name || "").toLowerCase() === "beisen-phoenix") {
        ["card", "add", "editor", "save"].forEach(function (part) {
          if (platformExperience[part]) result.experience[part] = Object.assign({}, platformExperience[part]);
        });
        result.experience.platformConditionalGates = true;
      }
    }
    result._platformCapability = platform.name || "";
    result._platformCapabilitySource = "dom_platform_overlay";
    return result;
  }

  function isAiStructurePlatform(config) {
    return Boolean(config && config.preferAiStructure === true);
  }

  // 桌面端在执行新站点 AI 分析后，会把本次返回的完整配置直接交给填写内核。
  // 这样首次填写使用的就是刚生成的配置，不需要再请求服务器、重新序列化或降级。
  function setPrefetchedConfig(hostname, config, url) {
    var host = String(hostname || "").trim().toLowerCase();
    if (!host || !config || typeof config !== "object") return false;
    var routeKey = config._routeKey || normalizeRouteKey(url || window.location.href);
    var key = identityKey(host, routeKey);
    config._routeKey = routeKey;
    prefetchedConfigs[key] = config;
    return true;
  }

  // ============ chrome.storage.local Promise 包装 ============

  function storageGet(keys) {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(keys, function (result) {
          if (chrome.runtime.lastError) {
            console.warn("[AF.SiteLoader] storage.get 出错", chrome.runtime.lastError.message);
            resolve({});
          } else {
            resolve(result || {});
          }
        });
      } catch (e) {
        console.warn("[AF.SiteLoader] storage.get 异常", e);
        resolve({});
      }
    });
  }

  function storageSet(obj) {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.set(obj, function () {
          if (chrome.runtime.lastError) {
            console.warn("[AF.SiteLoader] storage.set 出错", chrome.runtime.lastError.message);
          }
          resolve();
        });
      } catch (e) {
        console.warn("[AF.SiteLoader] storage.set 异常", e);
        resolve();
      }
    });
  }

  function storageRemove(keys) {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.remove(keys, function () {
          if (chrome.runtime.lastError) {
            console.warn("[AF.SiteLoader] storage.remove 出错", chrome.runtime.lastError.message);
          }
          resolve();
        });
      } catch (e) {
        console.warn("[AF.SiteLoader] storage.remove 异常", e);
        resolve();
      }
    });
  }

  // ============ 第1级: 硬编码精确域名匹配 (源码 getConfigForUrl, 行72918) ============

  function getConfigForUrl(url) {
    try {
      var privateSpecial = AF.PrivateSpecialSites && AF.PrivateSpecialSites.getConfigForUrl
        ? AF.PrivateSpecialSites.getConfigForUrl(url)
        : null;
      if (privateSpecial) return privateSpecial;

      var templates = AF.SITE_TEMPLATES || {};
      var hostname = new URL(url).hostname;

      var exact = templates[hostname];
      if (exact && (!exact.urlPattern || exact.urlPattern.test(url))) return exact;

      // 兜底: 遍历所有配置对象自身携带的 urlPattern，用完整 url 做正则匹配
      // (用于 hostname 精确匹配没有命中，但域名其实是某个已知配置 urlPattern
      // 能覆盖的变体子域名/协议的情况)
      var seen = [];
      for (var key in templates) {
        if (!Object.prototype.hasOwnProperty.call(templates, key)) continue;
        var cfg = templates[key];
        if (seen.indexOf(cfg) !== -1) continue;
        seen.push(cfg);
        if (cfg && cfg.urlPattern && cfg.urlPattern.test(url)) {
          return cfg;
        }
      }
      return null;
    } catch (e) {
      console.warn("[AF.SiteLoader] 第1级 getConfigForUrl 出错", e);
      return null;
    }
  }

  // ============ 第2级: DOM 特征检测 (源码 detectSiteType, 行16614-16633) ============
  // 7种检测按源码原始优先级顺序排列，命中即返回对应的预关联配置。

  function detectSiteType() {
    try {
      var refs = AF.SITE_TEMPLATE_REFS || {};

      // ① 字节系 urlPattern 正则匹配 (覆盖字节本身及走DOM检测的小米/米哈游纸鸢等场景)
      if (refs.byteUi && refs.byteUi.urlPattern && refs.byteUi.urlPattern.test(window.location.href)) {
        return refs.byteUi;
      }

      // ② Moka / Mokahr: block 导航 + apply-fields + ctrl + SD dropdown
      if (
        document.querySelector('[data-nav-id^="block-"][class*="apply-block-"]') &&
        document.querySelector('[class^="apply-fields-"], [class*=" apply-fields-"]') &&
        document.querySelector('[class^="ctrl-"], [class*=" ctrl-"]') &&
        document.querySelector('[class^="sd-Dropdown-container-"], [class*=" sd-Dropdown-container-"]')
      ) {
        return refs.mokaSd || null;
      }

      // ③ 滴滴 SD UI: .apply-block-* + .text-*.theme-border-color + .title-*
      if (
        document.querySelector('[class^="apply-block-"]') &&
        document.querySelector('[class^="text-"].theme-border-color') &&
        document.querySelector('[class^="title-"]')
      ) {
        return refs.didiSd || null;
      }

      // ④ 阿里 Kuma UI: .uxcore-card + .uxcore-card-title-text + .kuma-label
      if (
        document.querySelector(".uxcore-card") &&
        document.querySelector(".uxcore-card-title-text") &&
        document.querySelector(".kuma-label.vertical-align")
      ) {
        return refs.alibabaKuma || null;
      }

      // ⑤ 北森 Phoenix 平台: styled-components 分区 + Phoenix 表单标签
      if (
        document.querySelector(".sc-iAKWXU, .sc-cTAqQK") &&
        document.querySelector(".sc-efQSVx, .sc-jObWnj") &&
        document.querySelector(".form-item__text")
      ) {
        return refs.beisenPhoenix || refs.picc || null;
      }

      // ⑥ 北森/智业旧版 Portal：必须同时满足域名、RecruitmentPortal 表单、
      // 直属多经历容器和四段年月。不能只凭 zhiye.com 域名命中，以免覆盖 Phoenix。
      if (
        /(^|\.)zhiye\.com$/i.test(window.location.hostname || "") &&
        document.querySelector(".dl_示例资料info") &&
        document.querySelector(".dl_示例资料wrap.mainContainer") &&
        document.querySelector(".form_container[id^='RecruitmentPortal.']") &&
        document.querySelector(".sel_date_year") &&
        document.querySelector(".sel_date_month")
      ) {
        return refs.legacyZhiyePortal || null;
      }

      // ⑦ 飞书招聘 SaaS: saas-career 外壳 + UD Formily 字段 + 模块标题。
      // 不依赖企业域名，也不绑定构建生成的 CSS 哈希后缀。
      if (
        document.body && document.body.classList.contains("saas-career") &&
        document.querySelector(".ud-formily-item") &&
        document.querySelector(".ud-formily-item-label") &&
        document.querySelector(".applyFormModuleWrapper-title")
      ) {
        return refs.feishuFormily || null;
      }

      // ⑧ 字节兜底: [class^='createFormSection'] + [class^='applyFormModuleWrapper']
      if (
        document.querySelector('[class^="createFormSection"]') &&
        document.querySelector('[class^="applyFormModuleWrapper"]')
      ) {
        return refs.byteUi || null;
      }

      return null;
    } catch (e) {
      console.warn("[AF.SiteLoader] 第2级 detectSiteType 出错", e);
      return null;
    }
  }

  // ============ 第3级: 本地缓存 (替代原版远程 GET /resume/:hostname) ============

  function cacheKeyFor(hostname, urlOrRouteKey) {
    return CACHE_KEY_PREFIX + identityKey(hostname, urlOrRouteKey || "default");
  }

  function isLegacyAiConfig(config) {
    return Boolean(
      config &&
      config._source === "ai_generated" &&
      !config._autoConfigStrategy &&
      !config._serverStatus &&
      !config._candidateGeneratedAt &&
      config._remoteSource !== "verified"
    );
  }

  function isRetiredExperimentalConfig(config) {
    return Boolean(config && (config._source === "strong_scan_generated" || config._strongScan || (config.domStrategy && config.domStrategy.strongScanGenerated)));
  }

  function isVerifiedConfig(config) {
    return Boolean(config && (config._serverStatus === "verified" || config._remoteSource === "verified"));
  }

  function isCandidateConfig(config) {
    return Boolean(config && config._serverStatus === "candidate");
  }

  function isManualCandidateConfig(config) {
    return Boolean(isCandidateConfig(config) && config._manualCandidate === true);
  }

  function isOldUnverifiedAiConfig(config) {
    return Boolean(
      config &&
      config._source === "ai_generated" &&
      config._autoConfigStrategy &&
      !config._serverStatus &&
      config._remoteSource !== "verified"
    );
  }

  async function getCachedConfig(hostname, urlOrRouteKey) {
    try {
      var key = cacheKeyFor(hostname, urlOrRouteKey);
      var result = await storageGet([key]);
      var entry = result[key];
      if (!entry || !entry.config) return null;
      var cachedAt = entry.cachedAt || 0;
      if (Date.now() - cachedAt > CACHE_TTL_MS) {
        return null; // 已过期
      }
      return entry.config;
    } catch (e) {
      console.warn("[AF.SiteLoader] 第3级 getCachedConfig 出错", e);
      return null;
    }
  }

  async function setCachedConfig(hostname, config, urlOrRouteKey) {
    try {
      var routeKey = config && config._routeKey || normalizeRouteKey(urlOrRouteKey || window.location.href);
      var key = cacheKeyFor(hostname, routeKey);
      if (config && typeof config === "object") config._routeKey = routeKey;
      var payload = {};
      payload[key] = { config: config, cachedAt: Date.now() };
      await storageSet(payload);
    } catch (e) {
      console.warn("[AF.SiteLoader] 写入本地配置缓存出错", e);
    }
  }

  // ============ 第3级增强: 远程配置服务 ============
  // 读: GET {baseUrl}/api/site-config/:hostname，命中就直接用，且顺手写一份进本地缓存
  //     (离线/服务器临时不可达时兜底)。找不到/请求失败一律静默返回null，降级到本地缓存。
  // 写: PUT 同一个地址，AI生成新配置成功后调用，让测试过的站点配置不会只留在本地。
  // 两个函数都不抛错，出错就当没有这回事，不影响4级回退主流程。

  async function fetchRemoteConfig(hostname, url) {
    try {
      if (!AF.ServerConfig || !AF.ServerConfig.baseUrl) return null;
      var controller = new AbortController();
      var timeoutId = setTimeout(function () { controller.abort(); }, 5000);
      var res;
      try {
        var safeUrl = "";
        try {
          var parsed = new URL(url || window.location.href);
          safeUrl = parsed.origin + parsed.pathname;
        } catch (e) {}
        res = await fetch(
          AF.ServerConfig.baseUrl + "/api/site-config/" + encodeURIComponent(hostname) +
            "?url=" + encodeURIComponent(safeUrl),
          {
            method: "GET",
            cache: "no-store",
            signal: controller.signal,
          }
        );
      } finally {
        clearTimeout(timeoutId);
      }
      if (!res.ok) return null; // 404或其它错误，视为"服务器上没有"
      var data = await res.json();
      if (!data || !data.config) return null;
      data.config._remoteSource = data.source || "";
      data.config._remoteUpdatedAt = data.updatedAt || "";
      data.config._routeKey = data.routeKey || normalizeRouteKey(url || window.location.href);
      return data.config;
    } catch (e) {
      console.warn("[AF.SiteLoader] 远程配置读取失败，降级到本地缓存", e);
      return null;
    }
  }

  async function pushRemoteConfig(hostname, config, source, url) {
    try {
      if (!AF.ServerConfig || !AF.ServerConfig.baseUrl || !AF.ServerConfig.writeKey) {
        return { ok: false, error: "远程服务器或写入Key未配置" };
      }
      var res = await fetch(AF.ServerConfig.baseUrl + "/api/site-config/" + encodeURIComponent(hostname), {
        method: "PUT",
        headers: { "Content-Type": "application/json", "X-API-Key": AF.ServerConfig.writeKey },
        body: JSON.stringify({
          config: config,
          source: source || "ai_generated",
          routeKey: config && config._routeKey || normalizeRouteKey(url || window.location.href),
          url: url || window.location.href,
        }),
      });
      if (!res.ok) {
        var errorText = "";
        try { errorText = await res.text(); } catch (_) {}
        return { ok: false, error: "服务器返回 " + res.status + (errorText ? ": " + errorText.slice(0, 160) : "") };
      }
      return { ok: true };
    } catch (e) {
      console.warn("[AF.SiteLoader] 同步配置到远程服务器失败(不影响本次填写)", e);
      return { ok: false, error: e && e.message ? e.message : String(e) };
    }
  }

  // ============ 第4级: AI 配置生成挂载点 (由 Phase 8 注册实现) ============

  function registerFallbackGenerator(asyncFn) {
    fallbackGenerator = typeof asyncFn === "function" ? asyncFn : null;
  }

  function summarizeConfig(config) {
    var sections = config && config._aiSections ? Object.keys(config._aiSections).length : 0;
    var fieldCount = 0;
    if (config && config._aiSections) {
      Object.keys(config._aiSections).forEach(function (key) {
        var fields = config._aiSections[key] && config._aiSections[key].fields;
        if (fields) fieldCount += Object.keys(fields).length;
      });
    }
    return {
      name: config && config.name || "",
      type: config && config.type || "structured",
      source: config && config._source || "",
      serverStatus: config && config._serverStatus || "",
      remoteSource: config && config._remoteSource || "",
      strategy: config && config._autoConfigStrategy && config._autoConfigStrategy.mode || "",
      sectionCount: sections,
      fieldCount: fieldCount,
    };
  }

  function cloneForLocalTemplate(config) {
    try {
      return JSON.parse(JSON.stringify(config || {}, function (key, value) {
        if (key === "_serverStatus" || key === "_candidateGeneratedAt" || key === "_candidateUrl" || key === "_manualCandidate" || key === "_publishedAt" || key === "_remoteUpdatedAt") {
          return undefined;
        }
        return value;
      }));
    } catch (e) {
      return config || {};
    }
  }

  function makeConfigVariableName(hostname) {
    var base = String(hostname || "site")
      .replace(/^www\./, "")
      .replace(/[^a-zA-Z0-9]+/g, " ")
      .trim()
      .replace(/\s+([a-zA-Z0-9])/g, function (_, ch) { return ch.toUpperCase(); })
      .replace(/^[^a-zA-Z_$]+/, "");
    if (!base) base = "site";
    return base.charAt(0).toLowerCase() + base.slice(1) + "Config";
  }

  function generateLocalTemplateCode(hostname, config, status) {
    var variableName = makeConfigVariableName(hostname);
    var localConfig = cloneForLocalTemplate(config);
    localConfig.name = localConfig.name || hostname;
    localConfig._source = localConfig._source || "ai_generated";
    var json = JSON.stringify(localConfig, null, 2);
    return [
      "// AI 站点配置候选代码",
      "// hostname: " + hostname,
      "// status: " + (status || "candidate"),
      "// generatedAt: " + new Date().toISOString(),
      "// 用法: 如果确认这是通用且稳定的站点配置，可把 var 配置对象放入 content/config/site-templates.js，",
      "// 然后在 AF.SITE_TEMPLATES 里增加: \"" + hostname + "\": " + variableName + ",",
      "",
      "var " + variableName + " = " + json + ";",
      "",
      "// 映射示例:",
      "// AF.SITE_TEMPLATES[\"" + hostname + "\"] = " + variableName + ";",
      ""
    ].join("\n");
  }

  function downloadConfigCode(hostname, config, status) {
    try {
      if (!document || !document.createElement) return;
      var code = generateLocalTemplateCode(hostname, config, status);
      var blob = new Blob([code], { type: "text/javascript;charset=utf-8" });
      var url = URL.createObjectURL(blob);
      var a = document.createElement("a");
      var ts = new Date().toISOString().replace(/[:.]/g, "-");
      a.href = url;
      a.download = "站点配置代码_" + hostname + "_" + (status || "candidate") + "_" + ts + ".js";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (e) {
      console.warn("[AF.SiteLoader] 下载站点配置代码失败", e);
    }
  }

  function selectorText(entry) {
    if (!entry) return "";
    if (typeof entry === "string") return entry;
    return entry.class || entry.selector || "";
  }

  function selectorHitCount(selector) {
    if (!selector) return null;
    try {
      return document.querySelectorAll(selector).length;
    } catch (e) {
      return 0;
    }
  }

  function experienceSelector(config, group, field) {
    var block = config && config.experience && config.experience[group];
    return block && (block[field] || block.class || block.selector) || "";
  }

  function evaluateConfigCompatibility(config) {
    var graphStructure = config && config._graphStructure;
    if (graphStructure && Array.isArray(graphStructure.sections) && graphStructure.sections.length) {
      var graphChecks = [];
      var graphReasons = [];
      var totalRows = 0;
      var matchedRows = 0;
      var matchedSections = 0;
      graphStructure.sections.forEach(function (section, sectionIndex) {
        var selector = String(section && section.selector || "");
        var count = selectorHitCount(selector);
        var sectionMatched = Number(count || 0) === 1;
        if (sectionMatched) matchedSections++;
        else graphReasons.push("graph.section[" + sectionIndex + "] 非唯一命中(" + Number(count || 0) + ")");
        graphChecks.push({ name: "graph.section." + sectionIndex, selector: selector, count: count, matched: sectionMatched, critical: true });
        (Array.isArray(section && section.rows) ? section.rows : []).forEach(function (row, rowIndex) {
          var rowSelector = String(row && row.selector || "");
          if (!rowSelector) return;
          totalRows++;
          var rowCount = selectorHitCount(rowSelector);
          var rowMatched = Number(rowCount || 0) === 1;
          if (rowMatched) matchedRows++;
          graphChecks.push({ name: "graph.row." + sectionIndex + "." + rowIndex, selector: rowSelector, count: rowCount, matched: rowMatched, critical: false });
        });
      });
      var sectionRatio = graphStructure.sections.length ? matchedSections / graphStructure.sections.length : 0;
      var rowRatio = totalRows ? matchedRows / totalRows : 0;
      if (rowRatio < 0.7) graphReasons.push("graph row 命中率过低(" + rowRatio.toFixed(2) + ")");
      return {
        compatible: graphReasons.length === 0 && sectionRatio === 1 && rowRatio >= 0.7,
        score: totalRows ? (sectionRatio + rowRatio) / 2 : sectionRatio,
        checks: graphChecks,
        reasons: graphReasons,
        graphBacked: true,
        sectionRatio: sectionRatio,
        rowRatio: rowRatio
      };
    }
    var selectors = config && config.selectors;
    if (!selectors) return { compatible: true, score: 1, checks: [], reasons: [] };
    var labelSelector = selectorText(selectors.labels);
    var containerSelector = selectorText(selectors.container);
    var titleSelector = selectorText(selectors.title);
    var checks = [
      { name: "labels", selector: labelSelector, critical: true },
      { name: "container", selector: containerSelector, critical: true },
      { name: "title", selector: titleSelector, critical: true },
      { name: "experience.container", selector: experienceSelector(config, "container", "containerSelector"), critical: true },
      { name: "experience.card", selector: experienceSelector(config, "card", "cardSelector"), critical: false },
      { name: "experience.add", selector: experienceSelector(config, "add", "addButtonSelector"), critical: false },
    ].filter(function (check) { return Boolean(check.selector); });
    var matched = 0;
    var reasons = [];
    checks.forEach(function (check) {
      check.count = selectorHitCount(check.selector);
      check.matched = Number(check.count || 0) > 0;
      if (check.matched) matched++;
      else if (check.critical) reasons.push(check.name + " 未命中");
    });
    var score = checks.length ? matched / checks.length : 1;
    return {
      compatible: reasons.length === 0 && score >= 0.5,
      score: score,
      checks: checks,
      reasons: reasons,
    };
  }

  function isConfigUsable(config, source) {
    // 私有特殊站点可能需要先点击栏目，表单容器才会以弹窗/抽屉形式挂载。
    // getConfigForUrl() 已通过 hostname、urlPattern 和 pageGuardSelector 完成页面守卫，
    // 此时不能再用“当前页面必须已经存在 labels/container/title”这一通用规则拒绝它。
    if (config && config.privateSpecialSite === true) {
      config._compatibility = {
        compatible: true,
        score: 1,
        checks: [],
        reasons: [],
        deferredUntilWorkflowActivation: true,
      };
      return true;
    }
    var result = evaluateConfigCompatibility(config);
    if (config && typeof config === "object") config._compatibility = result;
    if (!result.compatible) {
      console.warn("[AF.SiteLoader] 拒绝不兼容的站点配置", {
        source: source || config && config._source || "",
        routeKey: normalizeRouteKey(window.location.href),
        score: result.score,
        reasons: result.reasons,
      });
    }
    return result.compatible;
  }

  function isDomDetectedConfigUsable(config) {
    return isConfigUsable(config, "dom_detect");
  }

  async function generateFreshConfig(url) {
    var hostname = "";
    try {
      hostname = new URL(url).hostname;
    } catch (e) {
      throw new Error("无法解析当前页面URL");
    }
    if (AF.PrivateSpecialSites && AF.PrivateSpecialSites.has && AF.PrivateSpecialSites.has(url)) {
      throw new Error("当前网站属于本地隔离的特殊站点，配置只能在 private/private-special-sites.js 中维护");
    }
    if (!fallbackGenerator) {
      throw new Error("AI站点配置生成器未加载");
    }
    var generated = await fallbackGenerator(url);
    if (!generated) {
      throw new Error("AI没有生成可用站点配置，请确认当前页面是表单页且AI配置可用");
    }
    generated._source = generated._source || "ai_generated";
    generated._serverStatus = "candidate";
    generated._candidateGeneratedAt = new Date().toISOString();
    generated._candidateUrl = url;
    generated._routeKey = normalizeRouteKey(url);
    generated._manualCandidate = true;
    // 手动重新 AI 分析生成的候选配置也必须叠加平台控件能力。
    // 否则下一次填写命中本地 candidate 时会绕过 Phoenix 多经历流程。
    var generatedPlatform = null;
    try { generatedPlatform = getConfigForUrl(url) || detectSiteType(); } catch (e) {}
    if (isAiStructurePlatform(generatedPlatform)) {
      generated = overlayPlatformControlCapabilities(generated, generatedPlatform);
    }
    await setCachedConfig(hostname, generated, url);
    downloadConfigCode(hostname, generated, "candidate");
    var processed = processEffectiveConfig(generated);
    return {
      hostname: hostname,
      config: processed || generated,
      summary: summarizeConfig(processed || generated),
    };
  }

  async function publishCachedConfig(hostname, url) {
    url = url || window.location.href;
    if (AF.PrivateSpecialSites && AF.PrivateSpecialSites.has && AF.PrivateSpecialSites.has(url)) {
      throw new Error("特殊站点配置受本地隔离保护，禁止发布到服务器");
    }
    var config = await getCachedConfig(hostname, url);
    if (!config) {
      throw new Error("当前域名没有可发布的本地候选配置，请先点“重新AI分析本站”");
    }
    if (isRetiredExperimentalConfig(config)) {
      throw new Error("当前缓存是旧实验配置，不能发布，请先重新AI分析本站");
    }
    config._serverStatus = "verified";
    config._publishedAt = new Date().toISOString();
    var result = await pushRemoteConfig(hostname, config, "verified", url);
    if (!result || !result.ok) {
      throw new Error(result && result.error || "发布失败");
    }
    await setCachedConfig(hostname, config, url);
    downloadConfigCode(hostname, config, "verified");
    return {
      hostname: hostname,
      summary: summarizeConfig(config),
    };
  }

  async function publishCurrentEffectiveConfig(url) {
    var hostname = "";
    var config = null;
    var publishSource = "candidate_verified";
    try {
      hostname = new URL(url).hostname;
    } catch (e) {
      throw new Error("无法解析当前页面URL");
    }

    config = await getCachedConfig(hostname, url);
    if (!config && preferLocalTemplatesForTesting) {
      config = getConfigForUrl(url);
      publishSource = "hardcoded_testing";
    }
    if (!config && preferLocalTemplatesForTesting) {
      config = detectSiteType();
      publishSource = "dom_detect_testing";
    }
    if (!config) {
      throw new Error("当前域名没有可发布配置，请先点“重新AI分析本站”");
    }
    if (config.privateSpecialSite) {
      throw new Error("特殊站点配置受本地隔离保护，禁止发布到服务器");
    }
    if (isRetiredExperimentalConfig(config)) {
      throw new Error("当前配置是旧实验配置，不能发布，请先重新AI分析本站");
    }

    var publishConfig = cloneForLocalTemplate(config);
    publishConfig._routeKey = normalizeRouteKey(url);
    publishConfig._serverStatus = "verified";
    publishConfig._publishedAt = new Date().toISOString();
    var result = await pushRemoteConfig(hostname, publishConfig, publishSource, url);
    if (!result || !result.ok) {
      throw new Error(result && result.error || "发布失败");
    }
    await setCachedConfig(hostname, publishConfig, url);
    downloadConfigCode(hostname, publishConfig, "verified");
    return {
      hostname: hostname,
      source: publishSource,
      summary: summarizeConfig(publishConfig),
    };
  }

  async function discardLocalCandidateConfig(hostname, url) {
    url = url || window.location.href;
    var config = await getCachedConfig(hostname, url);
    if (!config) {
      return { hostname: hostname, removed: false, reason: "当前域名没有本地候选配置" };
    }
    if (!isCandidateConfig(config)) {
      return {
        hostname: hostname,
        removed: false,
        reason: "当前本地配置不是 candidate，已保留本地兜底缓存",
        summary: summarizeConfig(config),
      };
    }
    await storageRemove([cacheKeyFor(hostname, url)]);
    return {
      hostname: hostname,
      removed: true,
      summary: summarizeConfig(config),
    };
  }

  // ============ 主入口: 4级回退 ============

  async function loadConfig(url, options) {
    options = options || {};
    var allowGenerate = options.allowGenerate !== false;
    var hostname = "";
    var routeKey = normalizeRouteKey(url);
    try {
      hostname = new URL(url).hostname;
    } catch (e) {
      console.warn("[AF.SiteLoader] 无法解析 URL", url, e);
      return null;
    }

    var hardcodedForHost = getConfigForUrl(url);
    var cachedOverride = null;
    var detectedPlatform = null;
    try { detectedPlatform = detectSiteType(); } catch (e) {}
    function applyPlatformOverlay(config) {
      var platform = hardcodedForHost || detectedPlatform;
      return isAiStructurePlatform(platform)
        ? overlayPlatformControlCapabilities(config, platform)
        : config;
    }

    // 手动点“重新AI分析本站”生成的候选配置，是开发/验证当前页面用的，
    // 应该优先于硬编码模板。非手动 candidate 仍保留下面的保护逻辑。
    try {
      cachedOverride = await getCachedConfig(hostname, routeKey);
      if (
        cachedOverride &&
        isManualCandidateConfig(cachedOverride) &&
        !isRetiredExperimentalConfig(cachedOverride) &&
        !isLegacyAiConfig(cachedOverride)
      ) {
        if (hardcodedForHost && hardcodedForHost.blockManualCandidates && !isAiStructurePlatform(hardcodedForHost)) {
          await storageRemove([cacheKeyFor(hostname, routeKey)]);
          console.info("[AF.SiteLoader] 已丢弃已知站点的手动AI候选配置，恢复内置配置", hostname);
        } else {
          cachedOverride = applyPlatformOverlay(cachedOverride);
          var processedManualCandidate = processEffectiveConfig(cachedOverride);
          if (processedManualCandidate) {
            processedManualCandidate._source = "local_template";
            processedManualCandidate._originalSource = cachedOverride._source || "";
            if (isConfigUsable(processedManualCandidate, "manual_candidate")) return processedManualCandidate;
          }
        }
      }
    } catch (e) {
      console.warn("[AF.SiteLoader] 手动候选配置读取异常，继续正常回退", e);
    }

    // 专用人工模板包含通用 AI 配置无法表达的交互逻辑，必须优先于服务器配置。
    if (hardcodedForHost && hardcodedForHost.preferBuiltIn) {
      var preferred = processEffectiveConfig(hardcodedForHost);
      if (preferred) {
        preferred._source = hardcodedForHost.privateSpecialSite ? "special_site_local" : "hardcoded";
        if (isConfigUsable(preferred, "hardcoded_preferred")) return preferred;
      }
    }

    // 第0级: 用户刚生成但尚未发布的 candidate 配置优先，方便新站点当场测试。
    // 已知硬编码站点不让 AI candidate 抢跑；否则 PDD 这类老适配会被一次临时分析覆盖。
    try {
      cachedOverride = cachedOverride || await getCachedConfig(hostname, routeKey);
      if (
        cachedOverride &&
        isCandidateConfig(cachedOverride) &&
        !isRetiredExperimentalConfig(cachedOverride) &&
        !isLegacyAiConfig(cachedOverride)
      ) {
        if (hardcodedForHost && !isAiStructurePlatform(hardcodedForHost)) {
          await storageRemove([cacheKeyFor(hostname, routeKey)]);
          console.info("[AF.SiteLoader] 已丢弃已知站点的本地AI候选配置，恢复硬编码配置", hostname);
        } else {
          cachedOverride = applyPlatformOverlay(cachedOverride);
          var processed0 = processEffectiveConfig(cachedOverride);
          if (processed0) {
            processed0._source = "local_template";
            processed0._originalSource = cachedOverride._source || "";
            if (isConfigUsable(processed0, "local_candidate")) return processed0;
          }
        }
      }
    } catch (e) {
      console.warn("[AF.SiteLoader] 第0级本地候选配置异常，继续远程配置", e);
    }

    // 桌面端本次一键填充刚取得的配置。放在本地 candidate 之后，保证开发插件
    // 的“重新AI分析本站”测试结果仍拥有最高优先级；放在远程 GET 之前，保证软件
    // 首次分析与随后填写使用同一个配置对象。
    try {
      var prefetched = prefetchedConfigs[identityKey(hostname, routeKey)];
      if (prefetched && !isRetiredExperimentalConfig(prefetched) && !isLegacyAiConfig(prefetched)) {
        prefetched = applyPlatformOverlay(prefetched);
        var processedPrefetched = processEffectiveConfig(prefetched);
        if (processedPrefetched) {
          processedPrefetched._originalSource = prefetched._source || "";
          processedPrefetched._source = "prefetched_server";
          if (isConfigUsable(processedPrefetched, "prefetched_server")) return processedPrefetched;
        }
      }
    } catch (e) {
      console.warn("[AF.SiteLoader] 桌面端预取配置异常，继续远程配置", e);
    }

    // 第1级: 远程配置服务器。已验证的服务器配置应优先于内置旧配置，
    // 否则 careers.tencent.com 这类原版内置域名会永远挡住后续验证过的新配置。
    try {
      var remote = await fetchRemoteConfig(hostname, url);
      if (remote && isVerifiedConfig(remote) && !isRetiredExperimentalConfig(remote) && !isLegacyAiConfig(remote)) {
        remote = applyPlatformOverlay(remote);
        var processedRemote = processEffectiveConfig(remote);
        if (processedRemote) {
          processedRemote._source = "remote_server";
          if (isConfigUsable(processedRemote, "remote_server")) {
            setCachedConfig(hostname, remote, routeKey); // 顺手存一份本地兜底，不等它完成
            return processedRemote;
          }
        }
      }
      if (isLegacyAiConfig(remote)) {
        console.info("[AF.SiteLoader] 服务器返回旧版静态AI配置，本次重新执行分层配置生成");
      }
      if (isRetiredExperimentalConfig(remote)) {
        console.info("[AF.SiteLoader] 忽略服务器旧实验配置，继续正式配置回退");
      }
      if (remote && !isVerifiedConfig(remote) && !isLegacyAiConfig(remote) && !isRetiredExperimentalConfig(remote)) {
        console.info("[AF.SiteLoader] 服务器配置尚未 verified，本次不自动采用", {
          remoteSource: remote._remoteSource || "",
          serverStatus: remote._serverStatus || "",
          strategy: remote._autoConfigStrategy && remote._autoConfigStrategy.mode || "",
        });
      }
    } catch (e) {
      console.warn("[AF.SiteLoader] 第1级(远程)异常，降级到第2级(硬编码)", e);
    }

    // 可复用平台（如北森 Phoenix）必须先让 AI 识别当前企业页面，平台模板
    // 只负责补控件能力。这样 inovance.zhiye.com 不会被 DOM 检测提前截断。
    if (isAiStructurePlatform(hardcodedForHost || detectedPlatform) && fallbackGenerator && allowGenerate) {
      try {
        var platformGenerated = await fallbackGenerator(url);
        if (platformGenerated) {
          platformGenerated._source = platformGenerated._source || "ai_generated";
          platformGenerated._serverStatus = platformGenerated._serverStatus || "candidate";
          platformGenerated._candidateGeneratedAt = platformGenerated._candidateGeneratedAt || new Date().toISOString();
          platformGenerated._candidateUrl = platformGenerated._candidateUrl || url;
          platformGenerated._routeKey = platformGenerated._routeKey || routeKey;
          platformGenerated = applyPlatformOverlay(platformGenerated);
          var processedPlatformAi = processEffectiveConfig(platformGenerated);
          if (processedPlatformAi && isConfigUsable(processedPlatformAi, "platform_ai_generated")) {
            await setCachedConfig(hostname, platformGenerated, routeKey);
            return processedPlatformAi;
          }
        }
      } catch (e) {
        console.warn("[AF.SiteLoader] 平台AI结构分析失败，继续使用平台模板", e);
      }
    }

    // 第2级: 硬编码精确域名匹配
    try {
      var hardcoded = hardcodedForHost;
      if (hardcoded) {
        var processed1 = processEffectiveConfig(hardcoded);
        if (processed1) {
          processed1._source = "hardcoded";
          if (isConfigUsable(processed1, "hardcoded")) return processed1;
        }
      }
    } catch (e) {
      console.warn("[AF.SiteLoader] 第2级异常，降级到第3级", e);
    }

    // 第3级: DOM 特征检测
    try {
      var detected = detectSiteType();
      if (detected) {
        var processed2 = processEffectiveConfig(detected);
        if (processed2) {
          processed2._source = "dom_detect";
          if (isDomDetectedConfigUsable(processed2)) {
            return processed2;
          }
          console.info("[AF.SiteLoader] 第2级DOM检测配置与当前页面选择器不匹配，继续降级", summarizeConfig(processed2));
        }
      }
    } catch (e) {
      console.warn("[AF.SiteLoader] 第3级异常，降级到第4级", e);
    }

    // 第4级: 本地缓存模板 (远程没有/不可达时的兜底)
    try {
      var cached = await getCachedConfig(hostname, routeKey);
      if (cached && (isVerifiedConfig(cached) || isCandidateConfig(cached) || !isOldUnverifiedAiConfig(cached)) && !isRetiredExperimentalConfig(cached) && !isLegacyAiConfig(cached)) {
        cached = applyPlatformOverlay(cached);
        var processed3 = processEffectiveConfig(cached);
        if (processed3) {
          processed3._source = "local_template";
          if (isConfigUsable(processed3, "local_template")) return processed3;
        }
      }
      if (isLegacyAiConfig(cached)) {
        console.info("[AF.SiteLoader] 检测到旧版静态AI缓存，本次重新执行分层配置生成");
      }
      if (isRetiredExperimentalConfig(cached)) {
        console.info("[AF.SiteLoader] 忽略本地旧实验配置，本次恢复静态HTML + AI生成");
      }
      if (isOldUnverifiedAiConfig(cached)) {
        console.info("[AF.SiteLoader] 忽略本地旧版未验证AI配置，本次重新生成候选配置");
      }
    } catch (e) {
      console.warn("[AF.SiteLoader] 第4级异常，降级到第5级", e);
    }

    // 第5级: AI 配置生成挂载点 (Phase 8 实现，此处只调用已注册的钩子)
    try {
      if (fallbackGenerator && allowGenerate) {
        var generated = await fallbackGenerator(url);
        if (generated) {
          generated._source = generated._source || "ai_generated";
          generated._serverStatus = generated._serverStatus || "candidate";
          generated._candidateGeneratedAt = generated._candidateGeneratedAt || new Date().toISOString();
          generated._candidateUrl = generated._candidateUrl || url;
          generated._routeKey = generated._routeKey || routeKey;
          generated = applyPlatformOverlay(generated);
          var processed4 = processEffectiveConfig(generated);
          if (processed4) {
            processed4._source = generated._source;
            processed4._serverStatus = generated._serverStatus;
            processed4._candidateGeneratedAt = generated._candidateGeneratedAt;
            processed4._candidateUrl = generated._candidateUrl;
            processed4._routeKey = generated._routeKey;
            // 生成成功后写入与第3级相同的缓存 key，下次直接命中第3级
            if (isConfigUsable(processed4, "ai_generated")) {
              await setCachedConfig(hostname, generated, routeKey);
              return processed4;
            }
          }
        }
      }
    } catch (e) {
      console.warn("[AF.SiteLoader] 第4级 (AI生成) 异常", e);
    }

    return null;
  }

  // 软件端服务器配置执行结果为 0 时的安全兜底。这里只返回本地明确模板或
  // DOM 指纹模板，不读取服务器、不使用缓存、也不再次调用 AI。调用方只有
  // 在服务器配置完全未填入任何字段时才会执行它，因此不会干扰正常流程。
  function loadBuiltInFallbackConfig(url) {
    var candidates = [];
    var direct = getConfigForUrl(url || window.location.href);
    if (direct) candidates.push({ config: direct, source: "hardcoded_zero_fill_fallback" });
    var detected = detectSiteType();
    if (detected && candidates.every(function (entry) { return entry.config !== detected; })) {
      candidates.push({ config: detected, source: "dom_detect_zero_fill_fallback" });
    }
    for (var i = 0; i < candidates.length; i++) {
      var processed = processEffectiveConfig(candidates[i].config);
      if (!processed) continue;
      processed._source = candidates[i].source;
      if (isConfigUsable(processed, candidates[i].source)) return processed;
    }
    return null;
  }

  AF.SiteLoader = {
    loadConfig: loadConfig,
    inspectConfig: function (url) {
      return loadConfig(url, { allowGenerate: false });
    },
    hasBuiltInConfig: function (url) {
      var config = getConfigForUrl(url);
      if (!config) return false;
      var processed = processEffectiveConfig(config);
      return Boolean(processed && isConfigUsable(processed, "hardcoded_probe"));
    },
    shouldPreferBuiltInConfig: function (url) {
      var config = getConfigForUrl(url);
      if (!config || !config.preferBuiltIn) return false;
      var processed = processEffectiveConfig(config);
      return Boolean(processed && isConfigUsable(processed, "preferred_hardcoded_probe"));
    },
    registerFallbackGenerator: registerFallbackGenerator,
    setPrefetchedConfig: setPrefetchedConfig,
    loadBuiltInFallbackConfig: loadBuiltInFallbackConfig,
    // 暴露内部方法方便调试/单测
    _detectSiteType: detectSiteType,
    _getConfigForUrl: getConfigForUrl,
    _getCachedConfig: getCachedConfig,
    _setCachedConfig: setCachedConfig,
    normalizeRouteKey: normalizeRouteKey,
    evaluateConfigCompatibility: evaluateConfigCompatibility,
    generateFreshConfig: generateFreshConfig,
    publishCachedConfig: publishCachedConfig,
    publishCurrentEffectiveConfig: publishCurrentEffectiveConfig,
    discardLocalCandidateConfig: discardLocalCandidateConfig,
  };
})();
