// content/date-picker/handlers/job51.js — 51job 日期输入框 (普通 <input>, 直接键入文本)
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   工厂分支 Kn.create() case "51job": 行46031 -> fo
//   fo.setValue: 行 47302-47357 (string 走 Kr(); object 需含 startTime/endTime 否则抛错, 走 Jr())
//   Kr()/Zr() (单值填写): 行 42168-42221 — 已核实, 事件时序为:
//     focus → standardSleep(30) → 清空+input → sleep(50) → 赋值+input+change → sleep(50) → blur
//     (change 之后必须等 50ms 再 blur, 给 51job 页面的校验/格式化逻辑留出处理时间;
//      没有 setAttribute("value") 这一步)
//     输入元素: tagName==="input" 用自身, 否则 querySelector("input"), 找不到抛错
//   Jr()/Xr() (范围填写): 行 42222-42280 — 已核实:
//     Kr(开始) → sleep(200) → findSimilarElements(el,4,{sameTag,sameClass,sameParent:false});
//     候选>0: 源码里 findBestEndDateElement 在该作用域实际未定义(恒跳过), 真实运行行为是
//       直接 Kr(候选[0], 结束) —— 这里保留"打分器可用则用, 否则退回候选[0]"的源码代码结构,
//       打分失败绝不放弃填写;
//     候选为0: findSurroundingInputs 取邻近 input 兜底 Kr(邻近[0], 结束)
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  // 源码 Kr()/Zr() (行42168-42221)
  async function setInputValue(el, value) {
    var input = el.tagName && el.tagName.toLowerCase() === "input" ? el : el.querySelector("input");
    if (!input) throw new Error("找不到有效的输入元素");
    input.focus();
    await AF.Utils.sleep(AF.DatePicker._STANDARD_DELAY || 30); // 源码 standardSleep()
    input.value = "";
    input.dispatchEvent(new Event("input", { bubbles: true }));
    await AF.Utils.sleep(50);
    input.value = String(value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    await AF.Utils.sleep(50);
    input.dispatchEvent(new Event("blur", { bubbles: true }));
  }

  // 源码 Jr()/Xr() (行42222-42280)
  async function setRangeValue(el, startTime, endTime) {
    await setInputValue(el, startTime);
    await AF.Utils.sleep(200);
    var candidates = AF.DomUtils.findSimilarElements(el, 4, { sameTag: true, sameClass: true, sameParent: false });
    if (candidates.length > 0) {
      // 打分器选不出正分候选时退回候选[0] (源码真实运行行为), 不放弃填写
      var best = AF.DatePicker._pickEndDateCandidate(el, candidates) || candidates[0];
      await setInputValue(best, endTime);
      return;
    }
    var surrounding = AF.DomUtils.findSurroundingInputs(el);
    if (surrounding.length > 0) {
      await setInputValue(surrounding[0], endTime);
    }
  }

  AF.DatePicker._registry["51job"] = function (element, valueType) {
    return {
      setValue: async function (value) {
        try {
          if (!value) throw new Error("日期为空");
          if (typeof value === "string" || valueType === "string") {
            await setInputValue(element, value);
            return true;
          }
          if (typeof value !== "object" || !("startTime" in value) || !("endTime" in value)) {
            throw new Error("当option为对象时，dateValue必须包含startTime和endTime属性");
          }
          await setRangeValue(element, value.startTime, value.endTime);
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
