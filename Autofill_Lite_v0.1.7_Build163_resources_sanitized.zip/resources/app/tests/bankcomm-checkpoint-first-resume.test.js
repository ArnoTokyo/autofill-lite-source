"use strict";
const fs = require("fs");
const path = require("path");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const 示例资料flow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-示例资料flow.js"), "utf8");
const sites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
assert(main.includes("resumeStartsAfterBasic"), "one-click must honor persisted checkpoint before Bankcomm 示例资料 preflight");
assert(main.includes("checkpointStepIndex: resumeStepIndex"), "checkpoint diagnostic cursor missing");
assert(示例资料flow.includes("manualResumeResolvedStepIndex"), "resolved manual checkpoint cursor missing");
assert(示例资料flow.includes("skipManualCheckpoint: manualResumeResolvedStepIndex === stepIndex"), "resolved checkpoint must bypass the manual gate exactly for its step");
assert(示例资料flow.includes("已按用户再次运行确认人工检查点"), "user-ack manual checkpoint resume notice missing");
assert(sites.includes("manualCheckpointResolvedWhen: bankcommHasSavedPreHigherEducation"), "Bankcomm compatibility resolver config missing");
assert(示例资料flow.includes("manualResumeResolvedStepIndex = storedStepIndex"), "rerun must acknowledge manual gate without re-probing it");
assert(sites.includes("bankcommCollectEducationReadOnlyCandidates"), "record-scoped saved 示例资料 scanner missing");
assert(sites.includes("Number(signal.dateCount || 0) >= 2"), "saved high-school fallback must require a real date range");
assert(sites.includes("excludedBecauseEditor"), "示例资料 editor exclusion signal missing");
console.log("bankcomm-checkpoint-first-resume.test.js passed");
