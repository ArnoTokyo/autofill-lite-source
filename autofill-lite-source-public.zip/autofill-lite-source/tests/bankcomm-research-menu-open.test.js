"use strict";
const fs = require("fs");
const path = require("path");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const workflow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-workflow.js"), "utf8");

// A. Open the actual Ant3 cascader trigger, not just the outer wrapper.
const openStart = workflow.indexOf("async function openBankcommResearchCustomDropdown");
const openEnd = workflow.indexOf("\n  function findVisibleBankcommResearchDropdown", openStart);
assert(openStart !== -1 && openEnd > openStart, "A: research menu opener missing");
const openFn = workflow.slice(openStart, openEnd);
assert(openFn.includes('".ant-cascader-picker input"'), "A: cascader input trigger missing");
assert(openFn.includes('".ant-cascader-picker-label"'), "A: cascader label trigger missing");
assert(openFn.includes('".ant-select-selection"'), "A: Ant3 selection trigger missing");
assert(openFn.includes("clickCascaderElement(trigger, true)"), "A: full pointer/mousedown click sequence missing");

// B. Menu-open success is determined by the unique visible custom-research checkbox.
assert(openFn.includes("findVisibleBankcommResearchCheckbox(checkboxText)"), "B: checkbox visibility gate missing");
assert(workflow.includes("resolveBankcommResearchPopupFromCheckbox"), "B: popup reverse ownership resolver missing");

// C. The custom transaction must use the opener before typing/submitting.
const fillStart = workflow.indexOf("async function fillBankcommResearchCustomValue");
const fillEnd = workflow.indexOf("\n  // 兴业银行学校名称", fillStart);
const fillFn = workflow.slice(fillStart, fillEnd);
assert(fillFn.includes("openBankcommResearchCustomDropdown(formItem, checkboxText, item)"), "C: custom filler does not use robust opener");
assert(fillFn.includes("research_custom_menu_not_opened"), "C: menu-open stage diagnostic missing");
assert(fillFn.includes("typeBankcommResearchCustomInputInPage"), "C: React input commit path regressed");
assert(fillFn.includes("fallbackSubmitButtonText"), "C: submit transaction regressed");

console.log("bankcomm-research-menu-open.test.js passed (A-C)");
