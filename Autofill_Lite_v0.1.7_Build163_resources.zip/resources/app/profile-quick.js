"use strict";

const $ = (id) => document.getElementById(id);
let profile = null;
let lastQuery = "";
let loadNonce = 0;

function text(value) { return String(value == null ? "" : value); }
function clean(value) { return text(value).replace(/\s+/g, " ").trim(); }
function nonEmpty(value) { return value !== undefined && value !== null && clean(value) !== ""; }
function normalize(value) { return clean(value).toLowerCase(); }

function setStatus(message, kind) {
  const el = $("status");
  el.textContent = message;
  el.className = "status" + (kind ? " " + kind : "");
}

function sections() {
  return profile && profile.profileV2 && profile.profileV2.sections || {};
}

function fieldEntries(values) {
  return Object.entries(values && typeof values === "object" ? values : {})
    .filter(([, value]) => nonEmpty(value));
}

function recordText(title, values) {
  const rows = fieldEntries(values).map(([key, value]) => `${key}：${text(value)}`);
  return [title, ...rows].filter(Boolean).join("\n");
}

function sectionText(section) {
  if (!section) return "";
  const title = clean(section.title) || "资料分区";
  if (section.kind === "repeat") {
    const items = Array.isArray(section.items) ? section.items : [];
    return [title, ...items.map((item, index) => recordText(clean(item && item.title) || `记录 ${index + 1}`, item && item.values))].filter(Boolean).join("\n\n");
  }
  return recordText(title, section.values);
}

async function copyValue(value, button, successText) {
  try {
    await window.lite.copyText(text(value));
    if (button) {
      const old = button.textContent;
      button.textContent = "已复制";
      button.classList.add("copied");
      setTimeout(() => { if (!button.isConnected) return; button.textContent = old; button.classList.remove("copied"); }, 900);
    }
    setStatus(successText || "已复制到剪贴板。", "ok");
  } catch (error) {
    setStatus(`复制失败：${error && error.message || error}`, "error");
  }
}

function makeField(key, value) {
  const node = $("fieldTemplate").content.firstElementChild.cloneNode(true);
  node.querySelector(".field-key").textContent = key;
  node.querySelector(".field-value").textContent = text(value);
  const copy = node.querySelector(".copy");
  copy.addEventListener("click", () => copyValue(value, copy, `已复制：${key}`));
  node.querySelector(".field-value").addEventListener("dblclick", () => copyValue(value, copy, `已复制：${key}`));
  return node;
}

function matchesQuery(sectionTitle, recordTitle, key, value, query) {
  if (!query) return true;
  return [sectionTitle, recordTitle, key, value].some((part) => normalize(part).includes(query));
}

function appendFields(host, entries, sectionTitle, recordTitle, query) {
  let count = 0;
  entries.forEach(([key, value]) => {
    if (!matchesQuery(sectionTitle, recordTitle, key, value, query)) return;
    host.appendChild(makeField(key, value));
    count += 1;
  });
  return count;
}

function renderSection(key, section, query) {
  const sectionTitle = clean(section && section.title) || key;
  const details = document.createElement("details");
  details.className = "section";
  details.open = !!query || true;
  const summary = document.createElement("summary");
  const titleSpan = document.createElement("span");
  titleSpan.className = "section-title";
  titleSpan.textContent = sectionTitle;
  const countSpan = document.createElement("span");
  countSpan.className = "section-count";
  summary.append(titleSpan, countSpan);
  details.appendChild(summary);

  const actions = document.createElement("div");
  actions.className = "section-actions";
  const copySection = document.createElement("button");
  copySection.className = "secondary";
  copySection.textContent = "复制分区";
  copySection.addEventListener("click", (event) => {
    event.preventDefault(); event.stopPropagation();
    copyValue(sectionText(section), copySection, `已复制分区：${sectionTitle}`);
  });
  actions.appendChild(copySection);
  details.appendChild(actions);

  let visibleCount = 0;
  if (section && section.kind === "repeat") {
    const items = Array.isArray(section.items) ? section.items : [];
    items.forEach((item, index) => {
      const recordTitle = clean(item && item.title) || `记录 ${index + 1}`;
      const entries = fieldEntries(item && item.values);
      const matching = entries.filter(([fieldKey, value]) => matchesQuery(sectionTitle, recordTitle, fieldKey, value, query));
      if (query && !matching.length && !normalize(recordTitle).includes(query) && !normalize(sectionTitle).includes(query)) return;
      const record = document.createElement("div");
      record.className = "record";
      const head = document.createElement("div");
      head.className = "record-head";
      const label = document.createElement("span");
      label.textContent = recordTitle;
      const copy = document.createElement("button");
      copy.className = "secondary";
      copy.textContent = "复制记录";
      copy.addEventListener("click", () => copyValue(recordText(recordTitle, item && item.values), copy, `已复制记录：${recordTitle}`));
      head.append(label, copy);
      record.appendChild(head);
      const fields = document.createElement("div");
      fields.className = "fields";
      const added = appendFields(fields, entries, sectionTitle, recordTitle, query);
      if (!added && !query) fields.innerHTML = '<div class="empty">这条记录没有可复制的值。</div>';
      record.appendChild(fields);
      details.appendChild(record);
      visibleCount += added;
    });
  } else {
    const fields = document.createElement("div");
    fields.className = "fields";
    visibleCount = appendFields(fields, fieldEntries(section && section.values), sectionTitle, "", query);
    details.appendChild(fields);
  }

  countSpan.textContent = `${visibleCount} 项`;
  if (query && visibleCount === 0 && !normalize(sectionTitle).includes(query)) return null;
  return details;
}

function renderQuestionBank(query) {
  const bank = profile && profile.profileV2 && Array.isArray(profile.profileV2.questionBank) ? profile.profileV2.questionBank : [];
  const filtered = bank.filter((entry) => matchesQuery("自定义问答", "", entry && entry.question, entry && entry.answer, query));
  if (!filtered.length) return null;
  const section = document.createElement("details");
  section.className = "section";
  section.open = true;
  const summary = document.createElement("summary");
  summary.innerHTML = '<span class="section-title">自定义问答</span>';
  const count = document.createElement("span"); count.className = "section-count"; count.textContent = `${filtered.length} 项`; summary.appendChild(count);
  section.appendChild(summary);
  const note = document.createElement("div"); note.className = "qa-note"; note.textContent = "这里显示资料库中保存的自定义招聘问题与答案。"; section.appendChild(note);
  const fields = document.createElement("div"); fields.className = "fields";
  filtered.forEach((entry) => fields.appendChild(makeField(clean(entry.question) || "未命名问题", entry.answer)));
  section.appendChild(fields);
  return section;
}

function render() {
  const host = $("content");
  host.innerHTML = "";
  if (!profile || !profile.profileV2) {
    host.innerHTML = '<div class="empty">没有可显示的资料。</div>';
    return;
  }
  const query = normalize(lastQuery);
  let sectionCount = 0;
  let itemCount = 0;
  Object.entries(sections()).forEach(([key, section]) => {
    const node = renderSection(key, section, query);
    if (!node) return;
    const countText = node.querySelector(".section-count");
    itemCount += Number((countText && countText.textContent || "0").match(/\d+/)?.[0] || 0);
    host.appendChild(node);
    sectionCount += 1;
  });
  const qa = renderQuestionBank(query);
  if (qa) { host.appendChild(qa); sectionCount += 1; itemCount += Number((qa.querySelector(".section-count").textContent.match(/\d+/) || [0])[0]); }
  if (!sectionCount) host.innerHTML = `<div class="empty">没有找到“${lastQuery.replace(/[<>&]/g, "")}”相关资料。</div>`;
  else setStatus(query ? `筛选结果：${sectionCount} 个分区 · ${itemCount} 个可复制字段` : `已读取运行时资料 · ${sectionCount} 个分区 · ${itemCount} 个可复制字段`);
}

async function load() {
  const nonce = ++loadNonce;
  setStatus("正在读取运行时资料…");
  try {
    const next = await window.lite.getProfileRaw();
    if (nonce !== loadNonce) return;
    profile = next;
    render();
  } catch (error) {
    if (nonce !== loadNonce) return;
    setStatus(`读取失败：${error && error.message || error}`, "error");
    $("content").innerHTML = '<div class="empty">资料读取失败。</div>';
  }
}

$("reload").addEventListener("click", load);
$("edit").addEventListener("click", () => window.lite.openProfileEditor());
$("search").addEventListener("input", (event) => { lastQuery = event.target.value || ""; render(); });
window.addEventListener("focus", load);
window.lite.onProfileUpdated(() => load());
load();
