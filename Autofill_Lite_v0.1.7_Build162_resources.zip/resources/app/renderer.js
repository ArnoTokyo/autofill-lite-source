"use strict";

const $ = (id) => document.getElementById(id);
const browser = $("browser");
const urlBar = $("url");
const fillBtn = $("fill");
const analyzeBtn = $("analyze");
const sectionTxnBtn = $("sectionTxn");
const educationProbeBtn = $("educationProbe");
const educationPreviewFillBtn = $("educationPreviewFill");
const educationContinuePreviewBtn = $("educationContinuePreview");
const multiSectionSurveyBtn = $("multiSectionSurvey");
const multiSectionPreviewBtn = $("multiSectionPreview");
const multiSectionSaveBtn = $("multiSectionSave");
const verifySiteCandidateBtn = $("verifySiteCandidate");
const aiMapBtn = $("aiMap");
const aiSettingsBtn = $("aiSettings");
const stopBtn = $("stop");
const report = $("report");
const runStatus = $("runStatus");
let progressTimer = null;
let appBuildInfo = { version: "0.1.7", buildId: "", buildShort: "" };

function updateWindowTitle() {
  const buildLabel = appBuildInfo.buildShort ? `build ${appBuildInfo.buildShort}` : "build";
  document.title = `Autofill Lite · v${appBuildInfo.version || "0.1.7"} · 测试版 · build ${appBuildInfo.buildShort || appBuildInfo.buildId}`;
}

async function initBuildInfo() {
  try {
    if (!window.lite || typeof window.lite.getBuildInfo !== "function") return;
    const info = await window.lite.getBuildInfo();
    if (!info || !info.buildId) return;
    appBuildInfo = {
      version: String(info.version || "0.1.7"),
      buildId: String(info.buildId || ""),
      buildShort: String(info.buildShort || ""),
    };
    const versionNode = document.querySelector(".app-version");
    if (versionNode) {
      versionNode.textContent = `v${appBuildInfo.version} · 测试版 · build ${appBuildInfo.buildShort || appBuildInfo.buildId}`;
      versionNode.title = `build ${appBuildInfo.buildId}`;
    }
    updateWindowTitle();
  } catch (_) {}
}

browser.setAttribute("preload", window.lite.guestPreloadUrl);


function initToolbarMenus() {
  const menus = Array.from(document.querySelectorAll(".toolbar-menu"));
  if (!menus.length) return;
  menus.forEach((menu) => {
    menu.addEventListener("toggle", () => {
      if (!menu.open) return;
      menus.forEach((other) => { if (other !== menu) other.open = false; });
    });
    menu.querySelectorAll("button").forEach((button) => {
      button.addEventListener("click", () => { menu.open = false; });
    });
  });
  document.addEventListener("click", (event) => {
    if (event.target && event.target.closest && event.target.closest(".toolbar-menu")) return;
    menus.forEach((menu) => { menu.open = false; });
  });
}

function normalizeUrl(value) {
  const raw = String(value || "").trim();
  if (!raw) return "about:blank";
  if (/^[a-z]+:\/\//i.test(raw)) return raw;
  return "https://" + raw;
}

function navigate(value) {
  const target = normalizeUrl(value);
  // User-initiated cross-site navigation should preempt the current page instead of
  // waiting for its pending load / beforeunload / injected observers to settle.
  try { browser.stop(); } catch (_) {}
  urlBar.value = target;
  report.classList.add("hidden");
  if (window.lite && typeof window.lite.navigateGuest === "function") {
    try {
      const guestId = browser.getWebContentsId();
      if (guestId) {
        window.lite.navigateGuest(guestId, target).catch(() => {
          try { browser.loadURL(target); } catch (_) {}
        });
        return;
      }
    } catch (_) {}
  }
  try { browser.loadURL(target); } catch (_) {}
}

function setRunning(running) {
  fillBtn.disabled = running;
  if (analyzeBtn) analyzeBtn.disabled = running;
  if (sectionTxnBtn) sectionTxnBtn.disabled = running;
  if (educationProbeBtn) educationProbeBtn.disabled = running;
  if (educationPreviewFillBtn) educationPreviewFillBtn.disabled = running;
  if (educationContinuePreviewBtn) educationContinuePreviewBtn.disabled = running;
  if (multiSectionSurveyBtn) multiSectionSurveyBtn.disabled = running;
  if (multiSectionPreviewBtn) multiSectionPreviewBtn.disabled = running;
  if (multiSectionSaveBtn) multiSectionSaveBtn.disabled = running;
  if (verifySiteCandidateBtn) verifySiteCandidateBtn.disabled = running;
  if (aiMapBtn) aiMapBtn.disabled = running;
  stopBtn.disabled = !running;
  if (!running && progressTimer) {
    clearInterval(progressTimer);
    progressTimer = null;
  }
}

function showReport(result) {
  const failed = Array.isArray(result && result.failedFields) ? result.failedFields : [];
  const failedText = failed.slice(0, 12).map((f) => `${f.label || f.fieldKey || "未知字段"}：${f.reason || "失败"}`).join("；");
  const unhandled = Number(result && result.unhandledCount || 0);
  const summary = result && result.userFacingSummary && typeof result.userFacingSummary === "object"
    ? result.userFacingSummary
    : {
        title: failed.length ? "一键填写有未完成项" : "一键填写已完成",
        reason: failed.length ? "请检查当前页面的未完成字段。" : "请在最终保存或投递前快速核对关键信息。",
        action: "",
        checkpoint: "",
      };
  const topSummary = `<div style="font-size:14px;line-height:1.55">` +
    `<div style="font-weight:700;font-size:15px">${escapeHtml(summary.title || "一键填写结果")}</div>` +
    (summary.reason ? `<div style="margin-top:3px"><strong>原因：</strong>${escapeHtml(summary.reason)}</div>` : "") +
    (summary.action ? `<div style="margin-top:3px"><strong>下一步：</strong>${escapeHtml(summary.action)}</div>` : "") +
    (summary.checkpoint ? `<div style="margin-top:3px"><strong>恢复：</strong>${escapeHtml(summary.checkpoint)}</div>` : "") +
    `</div>`;
  const technicalDetails = `<div style="margin-top:10px;padding-top:8px;border-top:1px solid rgba(0,0,0,.12)">` +
    `<div style="font-weight:700;margin-bottom:4px">技术详情</div>` +
    `<strong>填写 ${result.filledCount || 0}</strong> ` +
    `<strong>识别 ${result.totalFieldsFound || 0}</strong> ` +
    `<strong>未处理 ${unhandled}</strong> ` +
    `<strong>失败 ${result.failedCount || 0}</strong>` +
    (result.matchedWorkflowId ? `<div style="margin-top:5px">站点工作流：${escapeHtml(result.matchedWorkflowId)}</div>` : "") +
    (result.siteSupportDiagnostic && result.siteSupportDiagnostic.summary ? `<div style="margin-top:5px"><strong>站点诊断：</strong>${escapeHtml(result.siteSupportDiagnostic.summary)}${result.siteSupportDiagnostic.recommendation ? `；${escapeHtml(result.siteSupportDiagnostic.recommendation)}` : ""}</div>` : "") +
    (result.aiAssist && result.aiAssist.message ? `<div style="margin-top:5px"><strong>智能路由：</strong>${escapeHtml(result.aiAssist.message)}</div>` : "") +
    (result.sameClickAiRecovery && result.sameClickAiRecovery.attempted ? `<div style="margin-top:5px"><strong>同次自动恢复：</strong>${result.sameClickAiRecovery.success ? `AI候选已回送 Core，并在本次一键填写内自动重试成功（填写 ${Number(result.sameClickAiRecovery.retryFilledCount || 0)}）。` : `已自动分析并尝试回送 Core，但本次没有新增可提交字段（${escapeHtml(result.sameClickAiRecovery.reason || "未成功")}）。`}</div>` : "") +
    (result.aiGapFoundation && result.aiGapFoundation.eligible ? `<div style="margin-top:5px"><strong>AI Gap：</strong>${escapeHtml(result.aiGapFoundation.message || (result.aiGapFoundation.candidateAvailable ? "已生成/发现候选；安全候选会在一键填写内或下一次运行中受控回到 Core。" : "已检测到语义缺口，正在/等待自动候选分析。"))}${Array.isArray(result.aiGapFoundation.candidates) && result.aiGapFoundation.candidates.length ? ` · 候选 ${escapeHtml(result.aiGapFoundation.candidates.map((x) => `${x.label}→${x.category}.${x.fieldKey} (${Math.round(Number(x.confidence || 0) * 100)}%)`).join("；"))}` : ""}</div>` : "") +
    (result.aiGapFoundation && result.aiGapFoundation.safetyGate && result.aiGapFoundation.safetyGate.summary ? `<div style="margin-top:5px"><strong>AI Safety Gate：</strong>可进入 Core ${Number(result.aiGapFoundation.safetyGate.summary.eligibleForCore || 0)} · 仅候选 ${Number(result.aiGapFoundation.safetyGate.summary.reviewOnly || 0)} · 拒绝 ${Number(result.aiGapFoundation.safetyGate.summary.rejected || 0)}；只有安全候选可受控执行。</div>` : "") +
    (result.manualActionRequired ? `<div style="margin-top:7px"><strong>人工检查点：</strong>${escapeHtml(result.manualActionStep || "当前步骤")} · ${escapeHtml(result.manualActionReason || result.message || "需要人工补充页面要求")}<br>${Array.isArray(result.manualActionFields) && result.manualActionFields.length ? `需要处理：${escapeHtml(result.manualActionFields.map((item) => item && (item.label || item.message || item.reason) || "").filter(Boolean).join("、"))}<br>` : ""}请在网页中手动填写并保存，完成后再次点击“一键填写”继续。</div>` : "") +
    (result.recoveryCheckpointCreated ? `<div style="margin-top:5px"><strong>恢复检查点：</strong>已记录本次中断位置；手动处理后再次运行会从后续内容继续。</div>` : "") +
    (!result.manualActionRequired && result.message ? `<div style="margin-top:5px">${escapeHtml(result.message)}</div>` : "") +
    (result.postFillGap && result.postFillGap.summary ? `<div style="margin-top:5px"><strong>失败类型：</strong>${escapeHtml(result.postFillGap.summary)}${result.postFillGap.recommendation ? `；${escapeHtml(result.postFillGap.recommendation)}` : ""}</div>` : "") +
    (failedText ? `<div style="margin-top:5px">${escapeHtml(failedText)}</div>` : "") +
    (Array.isArray(result.missingProfileFields) && result.missingProfileFields.length ? `<div style="margin-top:7px"><strong>资料库明确缺少：</strong>${escapeHtml(result.missingProfileFields.map(x => x.label).join("、"))}</div>` : "") +
    (Array.isArray(result.remainingRequiredFields) && result.remainingRequiredFields.length ? `<div style="margin-top:7px"><strong>页面仍待处理：</strong>${escapeHtml(result.remainingRequiredFields.map(x => x.label).join("、"))}</div>` : "") +
    `<div style="margin-top:5px">“页面仍待处理”可能是资料缺失，也可能是控件填写失败；请人工核对后再保存或提交。</div>` +
    `</div>`;
  report.classList.remove("hidden");
  report.innerHTML = topSummary + technicalDetails;
}


function showAnalysisReport(result) {
  const summary = result && result.summary || {};
  const probe = result && result.siteSupportProbe || {};
  const analysis = result && result.analysis || {};
  const platform = analysis.configProbe && analysis.configProbe.domPlatform;
  const builtIn = analysis.configProbe && analysis.configProbe.builtInConfig;
  const staticScan = analysis.staticScan || {};
  const navigationItems = analysis.navigation && Array.isArray(analysis.navigation.items) ? analysis.navigation.items : [];
  const interactiveCandidates = analysis.interactive && Array.isArray(analysis.interactive.candidates) ? analysis.interactive.candidates : [];
  const graphCoverage = analysis.graphCoverage || {};
  const graphDiagnostics = analysis.graphDiagnostics || {};
  const recordGraphDiagnostics = analysis.recordGraphDiagnostics || {};
  report.classList.remove("hidden");
  report.innerHTML = `<strong>站点分析完成</strong> ` +
    `<strong>静态控件 ${summary.staticControlCount || 0}</strong> ` +
    `<strong>带标签 ${summary.staticLabeledControlCount || 0}</strong> ` +
    `<strong>唯一选择器 ${Number(staticScan.uniqueSelectorCount || 0)}</strong> ` +
    `<strong>FormGraph ${Number(summary.formGraphSectionCount || 0)}区/${Number(summary.formGraphRowCount || 0)}行/${Number(summary.formGraphControlCount || 0)}控件</strong> ` +
    `<strong>RecordGraph ${Number(summary.recordGraphGroupCount || 0)}组/${Number(summary.recordGraphRecordCount || 0)}记录</strong> ` +
    `<strong>交互模块 ${summary.interactiveModuleCount || 0}</strong>` +
    (builtIn ? `<div style="margin-top:5px">内置配置：${escapeHtml(builtIn.name || builtIn.type || builtIn.source || "已命中")}</div>` : "") +
    (platform ? `<div style="margin-top:5px">平台识别：${escapeHtml(platform.name || platform.type || platform.platform || "已识别")}</div>` : "") +
    (!builtIn && !platform && probe.visibleEditableControlCount ? `<div style="margin-top:5px">未命中现有配置，但页面检测到 ${Number(probe.visibleEditableControlCount || 0)} 个可编辑控件。</div>` : "") +
    (navigationItems.length ? `<div style="margin-top:5px">导航快照：${navigationItems.length} 项；${escapeHtml(navigationItems.slice(0, 12).map((x) => x.text).filter(Boolean).join("、"))}</div>` : "") +
    (graphDiagnostics.available ? `<div style="margin-top:5px"><strong>FormGraph：</strong>${graphDiagnostics.emptyBecauseNoVisibleEditableControls ? `当前没有可见编辑控件，因此本次结构图为 0 控件；这是只读/收起状态，不代表页面没有已保存记录。打开“编辑/资料编辑”后再次分析即可采集字段结构。` : `结构图已生成；静态字段关联 ${Number(graphCoverage.linkedStaticFieldCount || 0)}/${Number(graphCoverage.staticControlCount || 0)}（${Math.round(Number(graphCoverage.linkedRatio || 0) * 100)}%），Graph 版本 ${escapeHtml(graphDiagnostics.graphVersion || "")}。`}本阶段只用于分析，不参与填写。</div>` : `<div style="margin-top:5px"><strong>FormGraph：</strong>本页未生成结构图${graphDiagnostics.unavailableReason ? `（${escapeHtml(graphDiagnostics.unavailableReason)}）` : ""}；现有分析与填写路径仍可继续。</div>`) +
    (recordGraphDiagnostics.available ? `<div style="margin-top:5px"><strong>RecordGraph：</strong>识别 ${Number(recordGraphDiagnostics.groupCount || 0)} 个重复模块、${Number(recordGraphDiagnostics.recordCount || 0)} 条记录结构（编辑态 ${Number(recordGraphDiagnostics.editorRecordCount || 0)}、只读态 ${Number(recordGraphDiagnostics.savedRecordCount || 0)}），新增入口 ${Number(recordGraphDiagnostics.addActionCount || 0)}。优先复用成熟 experience 配置；本版仍只观察，不参与 RepeatRecord 执行。</div>` : `<div style="margin-top:5px"><strong>RecordGraph：</strong>本页未生成重复记录结构${recordGraphDiagnostics.unavailableReason ? `（${escapeHtml(recordGraphDiagnostics.unavailableReason)}）` : ""}。</div>`) +
    (interactiveCandidates.length ? `<div style="margin-top:5px">交互候选：${interactiveCandidates.length} 个；即使为静态表单也只记录候选，不会点击。</div>` : "") +
    (summary.interactiveSkippedCount ? `<div style="margin-top:5px">安全跳过 ${summary.interactiveSkippedCount} 个模块（例如仅有“新增/添加”的入口）。</div>` : "") +
    (summary.interactiveLeftOpenCount ? `<div style="margin-top:5px"><strong>注意：</strong>${summary.interactiveLeftOpenCount} 个编辑面无法安全关闭，已停止继续展开；请人工检查页面。</div>` : "") +
    `<div style="margin-top:5px">分析文件：${escapeHtml(result.analysisFileName || "已保存到数据目录/site-analysis")}</div>` +
    (result.analysisBundleFileName ? `<div style="margin-top:5px">合并快照：${escapeHtml(result.analysisBundleFileName)} · 当前 ${Number(result.analysisBundleSnapshotCount || 0)} 个不同页面状态</div>` : "") +
    (result.aiInputFileName ? `<div style="margin-top:5px"><strong>AI输入包：</strong>${escapeHtml(result.aiInputFileName)} · ${Number(result.aiInputSnapshotCount || 0)} 个有效状态 · ${Number(result.aiInputTotalFieldCount || 0)} 个字段；可信 Core 映射 ${Number(result.aiInputMappedFieldCount || 0)}，待复核映射 ${Number(result.aiInputTentativeMappedFieldCount || 0)}，未映射 ${Number(result.aiInputUnmappedFieldCount || 0)}，合计需 AI 判断 ${Number(result.aiInputMappingNeededFieldCount || 0)}${Number(result.aiInputLegacySnapshotCountExcluded || 0) ? `；旧版分析状态 ${Number(result.aiInputLegacySnapshotCountExcluded || 0)} 个需重新分析后才进入 AI 包` : ""}${Number(result.aiInputEmptySnapshotCountExcluded || 0) ? `；已排除 ${Number(result.aiInputEmptySnapshotCountExcluded || 0)} 个无结构空快照` : ""}</div>` : "") +
    (result.aiReviewFileName ? `<div style="margin-top:5px"><strong>AI复核包：</strong>${escapeHtml(result.aiReviewFileName)} · 只保留待复核/未映射字段，并带稳定 fieldId、补丁目标和允许的资料字段契约，供下一步 API 直接消费。</div>` : "") +
    `<div style="margin-top:5px">本次只采集脱敏结构并准备 AI 输入包：未执行自动填写、保存、添加、提交或投递，也未调用任何 AI API。</div>`;
}


function openAiSettingsPanel() {
  const panel = $("aiSettingsPanel");
  if (!panel) return;
  panel.classList.remove("hidden");
  panel.setAttribute("aria-hidden", "false");
}

function closeAiSettingsPanel() {
  const panel = $("aiSettingsPanel");
  if (!panel) return;
  panel.classList.add("hidden");
  panel.setAttribute("aria-hidden", "true");
  $("aiApiKey").value = "";
}

function defaultEndpointForProvider(provider) {
  return provider === "openai-compatible-chat"
    ? "https://api.openai.com/v1/chat/completions"
    : "https://api.openai.com/v1/responses";
}

async function refreshAiSettings() {
  const settings = await window.lite.getAiSettings();
  $("aiProvider").value = settings.provider || "openai-responses";
  $("aiEndpoint").value = settings.endpoint || defaultEndpointForProvider(settings.provider);
  $("aiModel").value = settings.model || "gpt-5.6-luna";
  $("aiReasoning").value = settings.reasoningEffort || "low";
  $("aiMaxTokens").value = Number(settings.maxOutputTokens || 24000);
  $("aiApiKey").value = "";
  const storageText = settings.apiKeyStorage === "encrypted"
    ? "Key 已使用系统安全存储加密保存。"
    : settings.apiKeyStorage === "memory"
      ? "当前系统无法使用安全存储：Key 仅保留在本次程序运行内存中，重启后需重新输入。"
      : "尚未保存 API Key。";
  $("aiKeyStatus").textContent = storageText + (settings.encryptionAvailable ? "" : " 不会将 Key 明文写入磁盘。");
  return settings;
}

async function saveAiSettings(clearApiKey) {
  const payload = {
    provider: $("aiProvider").value,
    endpoint: $("aiEndpoint").value,
    model: $("aiModel").value,
    reasoningEffort: $("aiReasoning").value,
    maxOutputTokens: Number($("aiMaxTokens").value || 24000),
    clearApiKey: !!clearApiKey
  };
  const key = $("aiApiKey").value.trim();
  if (key) payload.apiKey = key;
  const saved = await window.lite.saveAiSettings(payload);
  $("aiApiKey").value = "";
  await refreshAiSettings();
  return saved;
}

function escapeHtml(text) {
  return String(text || "").replace(/[&<>"']/g, (ch) => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[ch]));
}

async function refreshProfileStatus() {
  try {
    const s = await window.lite.getProfileSummary();
    const sectionCount = Object.values(s.sections || {}).reduce((a,b) => a + Number(b || 0), 0);
    $("profileStatus").textContent = `资料已加载：基础字段 ${s.basicFields} · 经历/记录 ${sectionCount}`;
  } catch (error) {
    $("profileStatus").textContent = `资料读取失败：${error.message || error}`;
  }
}

async function pollProgress() {
  try {
    const p = await window.lite.getProgress(browser.getWebContentsId());
    if (!p) return;
    if (p.status === "running" || p.status === "stopping") {
      runStatus.textContent = `自动填写中：${p.current || 0}/${p.total || 0} · 已填 ${p.filledCount || 0} · 失败 ${p.failedCount || 0}`;
    }
  } catch (_) {}
}

$("go").addEventListener("click", () => navigate(urlBar.value));
urlBar.addEventListener("keydown", (e) => { if (e.key === "Enter") navigate(urlBar.value); });
$("back").addEventListener("click", () => { if (browser.canGoBack()) browser.goBack(); });
$("forward").addEventListener("click", () => { if (browser.canGoForward()) browser.goForward(); });
$("reload").addEventListener("click", () => browser.reload());
$("devtools").addEventListener("click", () => browser.openDevTools());
$("profile").addEventListener("click", () => window.lite.openProfileEditor());
$("bookmarks").addEventListener("click", () => window.lite.openBookmarkManager({
  url: /^https?:\/\//i.test(browser.getURL() || "") ? browser.getURL() : "",
  name: browser.getTitle() || ""
}));
$("data").addEventListener("click", () => window.lite.openDataDir());



if (aiSettingsBtn) aiSettingsBtn.addEventListener("click", async () => {
  try {
    await refreshAiSettings();
    openAiSettingsPanel();
  } catch (error) {
    runStatus.textContent = `AI设置读取失败：${error.message || error}`;
  }
});
$("aiSettingsClose").addEventListener("click", closeAiSettingsPanel);
$("aiSettingsPanel").addEventListener("click", (event) => { if (event.target === $("aiSettingsPanel")) closeAiSettingsPanel(); });
$("aiProvider").addEventListener("change", () => {
  const current = $("aiEndpoint").value.trim();
  if (!current || /api\.openai\.com\/v1\/(responses|chat\/completions)/.test(current)) {
    $("aiEndpoint").value = defaultEndpointForProvider($("aiProvider").value);
  }
});
$("aiSaveSettings").addEventListener("click", async () => {
  try {
    const saved = await saveAiSettings(false);
    $("aiKeyStatus").textContent = saved.apiKeyStorage === "encrypted"
      ? "设置已保存；API Key 已加密存储。"
      : saved.apiKeyStorage === "memory"
        ? "设置已保存；API Key 仅保留在本次运行内存中。"
        : "设置已保存；尚未配置 API Key。";
  } catch (error) {
    $("aiKeyStatus").textContent = `保存失败：${error.message || error}`;
  }
});
$("aiClearKey").addEventListener("click", async () => {
  try {
    await saveAiSettings(true);
    $("aiKeyStatus").textContent = "API Key 已清除。";
  } catch (error) {
    $("aiKeyStatus").textContent = `清除失败：${error.message || error}`;
  }
});


if (multiSectionSaveBtn) multiSectionSaveBtn.addEventListener("click", async () => {
  report.classList.add("hidden");
  setRunning(true);
  runStatus.textContent = "正在批量保存已验证的后续分区…英语默认只处理 IELTS；遇到必填附件、缺失字段或新的格式要求会停在当前编辑器交给人工处理。";
  try {
    const batch = await window.lite.saveResumeSections(browser.getWebContentsId());
    const detail = batch && batch.result || {};
    const items = Array.isArray(detail.records) ? detail.records : [];
    const rows = items.map((item) => {
      const state = item.result === "already_present" ? "已存在，跳过"
        : item.result === "saved_and_verified" ? "保存并回读成功"
          : item.result === "manual_action_required" ? "已自动处理可确定字段，等待人工补充页面要求"
            : item.result === "skipped_no_profile_records" ? "资料库无明确记录，跳过"
              : `未完成${item.reason ? `（${item.reason}）` : ""}`;
      const fields = Array.isArray(item.fieldTrace) ? item.fieldTrace : [];
      const committed = fields.filter((x) => x && x.committed).map((x) => x.fieldKey).filter(Boolean);
      const failed = fields.filter((x) => x && x.attempted && !x.committed).map((x) => `${x.fieldKey}:${x.reason || "未回读"}`);
      const manualFields = Array.isArray(item.manualActionFields) ? item.manualActionFields.map((x) => {
        const label = x && (x.label || x.fieldKey || x.controlId || x.controlName) || "未知字段";
        const suffix = x && x.reason === "min_length" && Number(x.minLength || 0) ? `（至少 ${Number(x.minLength)} 字）`
          : x && x.validationMessage ? `（${x.validationMessage}）`
            : x && x.reason === "required_empty" ? "（必填）" : "";
        return `${label}${suffix}`;
      }).filter(Boolean) : [];
      const manualKinds = Array.isArray(item.manualRequirementKinds) ? item.manualRequirementKinds : [];
      return `<div style="margin-top:8px"><strong>${escapeHtml(item.section || "未知分区")}</strong>${item.recordKind ? ` / ${escapeHtml(item.recordKind)}` : ""}：${escapeHtml(state)}` +
        (committed.length ? `<div style="margin-left:14px">已写入/保留：${escapeHtml(committed.join("、"))}</div>` : "") +
        (failed.length ? `<div style="margin-left:14px">字段失败：${escapeHtml(failed.join("；"))}</div>` : "") +
        (manualKinds.length ? `<div style="margin-left:14px">人工检查点：${escapeHtml(manualKinds.join("、"))}</div>` : "") +
        (manualFields.length ? `<div style="margin-left:14px">需要补充/修正：${escapeHtml(manualFields.join("；"))}</div>` : "") +
        `</div>`;
    }).join("");
    report.classList.remove("hidden");
    report.innerHTML = `<strong>${detail.result === "complete" ? "后续分区批量保存完成" : detail.result === "paused_for_manual_action" ? "已停在需要人工补充字段/附件的检查点" : "后续分区批量保存已安全停止"}</strong>` +
      `<div style="margin-top:5px">计划 ${Number(detail.plannedRecordCount || 0)} 条 · 新保存 ${Number(detail.savedRecordCount || 0)} · 已存在 ${Number(detail.alreadyPresentCount || 0)} · 人工处理 ${Number(detail.manualActionCount || 0)} · 跳过 ${Number(detail.skippedRecordCount || 0)}</div>` +
      rows +
      (detail.reason ? `<div style="margin-top:8px">停止原因：${escapeHtml(detail.reason)}</div>` : "") +
      `<div style="margin-top:8px">诊断日志：${escapeHtml(batch.logFileName || "已写入 logs")}</div>` +
      `<div style="margin-top:5px">英语默认只自动处理 IELTS 一条。遇到附件、必填空字段或新的格式/字数要求会被动停在当前编辑器；人工补完后可直接重新运行，程序会接管当前编辑器并保留人工非空修改继续保存；也可以人工保存后再重跑。不会最终提交整份简历。</div>`;
    runStatus.textContent = detail.result === "complete"
      ? "后续分区批量保存事务完成。"
      : detail.result === "paused_for_manual_action"
        ? "已停在当前人工检查点；请补充页面要求的附件/字段或修正格式。补完后直接重新运行即可继续（也可人工保存后再运行）。"
        : `批量保存已安全停止：${detail.reason || "请查看日志"}`;
  } catch (error) {
    runStatus.textContent = `批量保存失败：${error.message || error}`;
    report.classList.remove("hidden");
    report.textContent = "批量保存已停止；不会上传附件或最终提交。请保留最新日志。";
  } finally {
    setRunning(false);
  }
});

if (aiMapBtn) aiMapBtn.addEventListener("click", async () => {
  report.classList.add("hidden");
  setRunning(true);
  runStatus.textContent = "正在生成语义/值候选…无 API 时自动走本地降级；不会执行保存、提交、删除或上传。";
  try {
    const result = await window.lite.runAiMapping(browser.getWebContentsId());
    if (result && result.skipped) {
      const localCandidate = result.siteCandidateSummary || {};
      report.classList.remove("hidden");
      report.innerHTML = `<strong>无需调用 AI</strong>` +
        `<div style="margin-top:5px">${escapeHtml(result.message || "本地映射已覆盖全部字段。")}</div>` +
        (result.siteCandidateFileName ? `<div style="margin-top:5px">站点候选：${escapeHtml(result.siteCandidateFileName)} · 语义字段 ${Number(localCandidate.acceptedFieldMappings || 0)}（本地可信 ${Number(localCandidate.acceptedLocalFieldMappings || 0)} + AI补充 ${Number(localCandidate.acceptedAiFieldMappings || 0)}） · 分区 ${Number(localCandidate.acceptedSectionMappings || 0)}。</div>` : "");
      runStatus.textContent = result.message || "本地映射已覆盖全部字段，无需调用 AI。";
      return;
    }
    const summary = result.summary || {};
    const usage = result.usage || {};
    report.classList.remove("hidden");
    report.innerHTML = `<strong>AI semantic candidate 已通过本地校验</strong>` +
      `<strong>映射 ${Number(summary.mapped || 0)}</strong>` +
      `<strong>留空 ${Number(summary.leftUnmapped || 0)}</strong>` +
      `<strong>需特殊流程 ${Number(summary.needsSpecialWorkflow || 0)}</strong>` +
      `<div style="margin-top:5px">Provider：${escapeHtml(result.provider || "")} · Model：${escapeHtml(result.model || "")}</div>` +
      `<div style="margin-top:5px">Patch：${escapeHtml(result.patchFileName || "已保存")}</div>` +
      (result.safetyGate && result.safetyGate.summary ? `<div style="margin-top:5px"><strong>Safety Gate：</strong>可进入 Core ${Number(result.safetyGate.summary.eligibleForCore || 0)} · 仅人工复核 ${Number(result.safetyGate.summary.reviewOnly || 0)} · 拒绝 ${Number(result.safetyGate.summary.rejected || 0)}。低风险普通字段采用风险分级门槛；RepeatRecord owner 与不可逆操作权限不放宽。</div>` : "") +
      (result.candidateFileName ? `<div style="margin-top:5px">语义候选：${escapeHtml(result.candidateFileName)} · 安全候选 ${Number(result.candidateSummary && result.candidateSummary.acceptedMappings || 0)} 条；其余 ${Number(result.candidateSummary && result.candidateSummary.skippedDecisions || 0)} 条保留审计。安全候选可在后续一键填写中重新进入 Core。</div>` : "") +
      (result.siteCandidateFileName ? `<div style="margin-top:5px">站点候选：${escapeHtml(result.siteCandidateFileName)} · 语义字段 ${Number(result.siteCandidateSummary && result.siteCandidateSummary.acceptedFieldMappings || 0)}（本地可信 ${Number(result.siteCandidateSummary && result.siteCandidateSummary.acceptedLocalFieldMappings || 0)} + AI补充 ${Number(result.siteCandidateSummary && result.siteCandidateSummary.acceptedAiFieldMappings || 0)}） · 分区 ${Number(result.siteCandidateSummary && result.siteCandidateSummary.acceptedSectionMappings || 0)}。AI 不生成 selector；FormGraph/现有 Adapter 仍负责定位和执行。</div>` : "") +
      (result.valueCandidates && result.valueCandidates.available ? `<div style="margin-top:5px"><strong>候选值：</strong>目标 ${Number(result.valueCandidates.reviewTargetCount || 0)} · 本地提取/归一化 ${Number(result.valueCandidates.localCandidateCount || 0)} · API候选 ${Number(result.valueCandidates.apiCandidateCount || 0)} · 可进入 Core ${Number(result.valueCandidates.gate && result.valueCandidates.gate.summary && result.valueCandidates.gate.summary.eligibleForCore || 0)} · 仅人工复核 ${Number(result.valueCandidates.gate && result.valueCandidates.gate.summary && result.valueCandidates.gate.summary.reviewOnly || 0)}。</div>` : "") +
      (result.apiFallbackReason ? `<div style="margin-top:5px"><strong>API降级：</strong>${escapeHtml(result.apiFallbackReason === "no_api_key" ? "未配置 API Key，已自动改用本地语义/值解析。" : "API 调用失败，已自动改用本地语义/值解析；本次一键填写不会因此中断。")}</div>` : "") +
      (result.retryAttempted ? `<div style="margin-top:5px">兼容恢复：首次结构化输出未通过，本次已自动用 JSON Object 模式重试并通过校验。</div>` : "") +
      `<div style="margin-top:5px">Token预算：语义阶段上限 ${Number(result.semanticTokenBudget || 0)}${result.valueCandidates && result.valueCandidates.tokenBudget ? ` · 候选值阶段上限 ${Number(result.valueCandidates.tokenBudget || 0)}` : ""}。${(usage.inputTokens || usage.outputTokens) ? `实际语义调用：输入 ${Number(usage.inputTokens || 0)} · 输出 ${Number(usage.outputTokens || 0)} · 合计 ${Number(usage.totalTokens || 0)}。` : "本次语义阶段未消耗 API token。"}</div>` +
      `<div style="margin-top:5px">本地适配/人工 verified 配置始终优先；AI 只提供语义和候选值，保存、提交、删除、上传以及 RepeatRecord 归属仍由确定性 Core/人工控制。</div>`;
    runStatus.textContent = `AI候选完成：${Number(summary.mapped || 0)} 个映射候选，${Number(summary.leftUnmapped || 0)} 个保留为空。`;
  } catch (error) {
    runStatus.textContent = `AI候选失败：${error.message || error}`;
    report.classList.remove("hidden");
    report.textContent = "未修改页面，也未应用不完整/不合规的 AI 输出。请检查 AI设置、网络或重新“分析本站”。";
  } finally {
    setRunning(false);
  }
});

if (verifySiteCandidateBtn) verifySiteCandidateBtn.addEventListener("click", async () => {
  try {
    setRunning(true);
    runStatus.textContent = "正在把当前已测试 semantic SiteConfig candidate 标记为本地 verified…";
    const result = await window.lite.verifySiteCandidate(browser.getWebContentsId());
    report.classList.remove("hidden");
    const gaps = result && result.verification && Array.isArray(result.verification.knownExecutionGapLabels)
      ? result.verification.knownExecutionGapLabels : [];
    report.innerHTML = `<strong>站点候选已验证</strong>` +
      `<div style="margin-top:5px">本地 verified 文件：${escapeHtml(result.fileName || "已保存")}</div>` +
      `<div style="margin-top:5px">语义字段 ${Number(result.semanticFieldCount || 0)} · 分区 ${Number(result.sectionCount || 0)}；后续该路径优先使用 verified semantic SiteConfig，不再重复调用 AI。</div>` +
      (gaps.length ? `<div style="margin-top:5px">已知执行层缺口：${escapeHtml(gaps.join("、"))}。这些缺口会保留在验证摘要中，不会被当成语义映射错误。</div>` : "") +
      `<div style="margin-top:5px">验证文件不包含简历字段值、Cookie、Token 或 AI 生成 selector。</div>`;
    runStatus.textContent = "当前站点 semantic candidate 已标记为本地 verified。";
  } catch (error) {
    runStatus.textContent = `验证站点候选失败：${error.message || error}`;
    report.classList.remove("hidden");
    report.textContent = String(error && error.message || error);
  } finally {
    setRunning(false);
  }
});

if (sectionTxnBtn) sectionTxnBtn.addEventListener("click", async () => {
  report.classList.add("hidden");
  setRunning(true);
  runStatus.textContent = "正在测试当前分区局部保存并导航到下一分区…不会最终提交。";
  try {
    const txn = await window.lite.testNextSection(browser.getWebContentsId());
    const detail = txn && txn.result || {};
    report.classList.remove("hidden");
    const saveState = detail.saveFeedbackVerified
      ? `保存反馈已回读：${escapeHtml(detail.saveFeedbackText || "已验证")}`
      : detail.saveClickDispatched
        ? "已点击局部保存，但页面没有提供可回读的保存成功反馈，因此不把服务器保存记为已验证"
        : "未执行局部保存";
    const feedbackTiming = detail.saveFeedbackWaitMs ? ` · 等待 ${Number(detail.saveFeedbackWaitMs)}ms` : "";
    const feedbackStrategy = detail.saveFeedbackDetectionStrategy ? ` · 识别方式 ${escapeHtml(detail.saveFeedbackDetectionStrategy)}` : "";
    const modalState = detail.saveModalDetected
      ? detail.saveModalClosed
        ? `保存成功弹窗已识别并关闭${detail.saveModalCloseText ? `（${escapeHtml(detail.saveModalCloseText)}）` : ""}`
        : `保存成功弹窗已识别，但未安全关闭${detail.saveModalCloseStrategy ? `（${escapeHtml(detail.saveModalCloseStrategy)}）` : ""}`
      : "";
    const resultText = detail.result === "success_verified_save"
      ? "事务成功"
      : detail.result === "partial_save_unverified_navigation_success"
        ? "导航成功，保存状态待人工确认"
        : detail.result === "blocked_by_validation"
          ? "保存校验阻断，未跳转"
          : detail.reason === "save_feedback_timeout"
            ? "保存反馈等待超时，已安全停止"
            : "事务未完成";
    report.innerHTML = `<strong>${escapeHtml(resultText)}</strong>` +
      `<div style="margin-top:5px">${escapeHtml(txn.fromSection || "")} → ${escapeHtml(txn.targetSection || "")}</div>` +
      `<div style="margin-top:5px">${saveState}${feedbackTiming}${feedbackStrategy}</div>` +
      (modalState ? `<div style="margin-top:5px">${modalState}</div>` : "") +
      (Array.isArray(detail.newValidationMessages) && detail.newValidationMessages.length ? `<div style="margin-top:5px"><strong>新出现校验：</strong>${escapeHtml(detail.newValidationMessages.join("、"))}</div>` : "") +
      `<div style="margin-top:5px">目标导航点击：${detail.targetNavClickDispatched ? "是" : "否"} · 目标 active 回读：${detail.targetActiveAfter ? "是" : "否"}</div>` +
      (detail.reason ? `<div style="margin-top:5px">状态原因：${escapeHtml(detail.reason)}</div>` : "") +
      `<div style="margin-top:5px">诊断日志：${escapeHtml(txn.logFileName || "已写入 logs")}</div>` +
      `<div style="margin-top:5px">Build65 只允许“基本信息 → 教育背景”这一跳，不会继续教育填写、附件上传或最终提交。</div>`;
    runStatus.textContent = detail.targetActiveAfter
      ? "下一分区测试完成：教育背景已成为 active。"
      : `下一分区测试未完成：${detail.reason || "请查看诊断日志"}`;
  } catch (error) {
    runStatus.textContent = `下一分区测试失败：${error.message || error}`;
    report.classList.remove("hidden");
    report.textContent = "事务已停止；没有继续到后续分区，也没有最终提交。请先重新“分析本站”并确认当前仍为基本信息。";
  } finally {
    setRunning(false);
  }
});


if (educationProbeBtn) educationProbeBtn.addEventListener("click", async () => {
  report.classList.add("hidden");
  setRunning(true);
  runStatus.textContent = "正在安全打开教育背景编辑器并采集结构…不会填写或保存。";
  try {
    const probe = await window.lite.probeEducationEditor(browser.getWebContentsId());
    const detail = probe && probe.result || {};
    report.classList.remove("hidden");
    const fieldLabels = Array.isArray(detail.fields)
      ? detail.fields.slice(0, 18).map((field) => field.label || field.placeholder || field.name || field.id || field.tagName).filter(Boolean)
      : [];
    const resultText = detail.result === "probe_complete_closed"
      ? "教育编辑器探测完成并已安全关闭"
      : detail.result === "probe_complete_left_open"
        ? "教育编辑器结构已采集，但未找到可验证的安全关闭方式"
        : "教育编辑器探测未完成";
    report.innerHTML = `<strong>${escapeHtml(resultText)}</strong>` +
      `<div style="margin-top:5px">当前分区：${escapeHtml(detail.section || probe.section || "教育背景")} · active 回读：${detail.sectionActiveBefore ? "是" : "否"}</div>` +
      `<div style="margin-top:5px">添加入口：${detail.addButtonFound ? "已找到" : "未找到"}${detail.addButtonText ? `（${escapeHtml(detail.addButtonText)}）` : ""} · 点击：${detail.addClickDispatched ? "是" : "否"}</div>` +
      `<div style="margin-top:5px">编辑器打开：${detail.editorOpened ? "是" : "否"} · 新出现可编辑控件 ${Number(detail.newVisibleControlCount || 0)} 个${detail.editorOpenWaitMs ? ` · 等待 ${Number(detail.editorOpenWaitMs)}ms` : ""}</div>` +
      (fieldLabels.length ? `<div style="margin-top:5px"><strong>字段结构：</strong>${escapeHtml(fieldLabels.join("、"))}</div>` : "") +
      (Array.isArray(detail.actionTexts) && detail.actionTexts.length ? `<div style="margin-top:5px"><strong>编辑器动作：</strong>${escapeHtml(detail.actionTexts.join("、"))}</div>` : "") +
      `<div style="margin-top:5px">安全关闭：${detail.safeCloseFound ? `已找到${detail.safeCloseText ? `（${escapeHtml(detail.safeCloseText)}）` : ""}` : "未找到"} · 已关闭：${detail.editorClosed ? "是" : "否"}</div>` +
      (detail.reason ? `<div style="margin-top:5px">状态原因：${escapeHtml(detail.reason)}</div>` : "") +
      `<div style="margin-top:5px">诊断日志：${escapeHtml(probe.logFileName || "已写入 logs")}</div>` +
      `<div style="margin-top:5px">本轮只打开并观察教育编辑器：没有写入字段、没有点击保存、没有创建已保存记录，也没有最终提交。</div>`;
    runStatus.textContent = detail.editorOpened
      ? (detail.editorClosed ? "教育编辑器结构探测完成，已安全关闭。" : "教育编辑器结构已采集；未自动关闭，请人工检查。")
      : `教育编辑器探测未完成：${detail.reason || "请查看诊断日志"}`;
  } catch (error) {
    runStatus.textContent = `教育编辑器探测失败：${error.message || error}`;
    report.classList.remove("hidden");
    report.textContent = "探测已停止；没有填写、保存或最终提交。请确认当前右侧“教育背景”为 active，并保留最新日志。";
  } finally {
    setRunning(false);
  }
});


if (educationPreviewFillBtn) educationPreviewFillBtn.addEventListener("click", async () => {
  report.classList.add("hidden");
  setRunning(true);
  runStatus.textContent = "正在把资料库最新一条教育记录填入教育编辑器并回读…本轮不会保存。";
  try {
    const preview = await window.lite.previewFillEducationRecord(browser.getWebContentsId());
    const detail = preview && preview.result || {};
    const traces = Array.isArray(detail.fieldTrace) ? detail.fieldTrace : [];
    const committed = traces.filter((item) => item && item.committed).map((item) => item.fieldKey).filter(Boolean);
    const failed = traces.filter((item) => item && item.attempted && !item.committed).map((item) => `${item.fieldKey}:${item.reason || "未回读"}`);
    const skipped = traces.filter((item) => item && !item.attempted).map((item) => `${item.fieldKey}:${item.reason || "跳过"}`);
    report.classList.remove("hidden");
    report.innerHTML = `<strong>${detail.result === "preview_filled_left_open" ? "教育记录预览填充完成，编辑器已留在页面供人工核对" : "教育记录预览填充未完成"}</strong>` +
      `<div style="margin-top:5px">资料记录：第 ${Number(detail.profileRecordIndex || 0) + 1} / ${Number(detail.profileRecordCount || preview.profileRecordCount || 0)} 条 · 当前分区 active：${detail.sectionActiveBefore ? "是" : "否"}</div>` +
      `<div style="margin-top:5px">尝试 ${Number(detail.attemptedFieldCount || 0)} 个字段 · 回读成功 ${Number(detail.committedFieldCount || 0)} · 失败 ${Number(detail.failedFieldCount || 0)} · 跳过 ${Number(detail.skippedFieldCount || 0)}</div>` +
      (committed.length ? `<div style="margin-top:5px"><strong>已回读：</strong>${escapeHtml(committed.join("、"))}</div>` : "") +
      (failed.length ? `<div style="margin-top:5px"><strong>未提交成功：</strong>${escapeHtml(failed.join("；"))}</div>` : "") +
      (skipped.length ? `<div style="margin-top:5px"><strong>本轮跳过：</strong>${escapeHtml(skipped.join("；"))}</div>` : "") +
      `<div style="margin-top:5px">学校下拉动态选项数：${Number(detail.dynamicSchoolOptionCount || 0)} · 找到“保存教育背景”：${detail.saveControlFound ? "是" : "否"} · 已点击保存：否</div>` +
      (detail.reason ? `<div style="margin-top:5px">状态原因：${escapeHtml(detail.reason)}</div>` : "") +
      `<div style="margin-top:5px">诊断日志：${escapeHtml(preview.logFileName || "已写入 logs")}</div>` +
      `<div style="margin-top:5px">请直接检查页面里的教育表单；本轮不会创建已保存记录。确认后可手动点“返回”放弃这次预览。</div>`;
    runStatus.textContent = detail.result === "preview_filled_left_open"
      ? "教育记录已填入但未保存，请人工核对页面。"
      : `教育预览填充未完成：${detail.reason || "请查看日志"}`;
  } catch (error) {
    runStatus.textContent = `教育预览填充失败：${error.message || error}`;
    report.classList.remove("hidden");
    report.textContent = "预览已停止；没有点击“保存教育背景”，也没有最终提交。";
  } finally {
    setRunning(false);
  }
});

if (analyzeBtn) analyzeBtn.addEventListener("click", async () => {
  report.classList.add("hidden");
  setRunning(true);
  runStatus.textContent = "正在安全分析本站结构…不会填写、保存或新增记录。";
  try {
    const result = await window.lite.analyzeSite(browser.getWebContentsId());
    showAnalysisReport(result);
    runStatus.textContent = `站点分析完成：静态控件 ${result.summary && result.summary.staticControlCount || 0}，交互模块 ${result.summary && result.summary.interactiveModuleCount || 0}。`;
  } catch (error) {
    runStatus.textContent = `站点分析失败：${error.message || error}`;
    report.classList.remove("hidden");
    report.textContent = "未修改页面数据。可打开开发者工具或数据目录进一步检查。";
  } finally {
    setRunning(false);
  }
});

fillBtn.addEventListener("click", async () => {
  report.classList.add("hidden");
  setRunning(true);
  runStatus.textContent = "正在注入 Autofill Core 并执行…";
  progressTimer = setInterval(pollProgress, 350);
  try {
    const result = await window.lite.runAutofill(browser.getWebContentsId());
    showReport(result);
    runStatus.textContent = result.stopped ? "已停止。" : `完成：已填 ${result.filledCount || 0}，失败 ${result.failedCount || 0}。请人工复核。`;
  } catch (error) {
    runStatus.textContent = `执行失败：${error.message || error}`;
    report.classList.remove("hidden");
    report.textContent = "本次未完成。可打开“数据目录”查看脱敏日志，或打开开发者工具查看控制台。";
  } finally {
    setRunning(false);
  }
});

stopBtn.addEventListener("click", async () => {
  try {
    await window.lite.stopAutofill(browser.getWebContentsId());
    runStatus.textContent = "正在停止…";
  } catch (error) {
    runStatus.textContent = `停止失败：${error.message || error}`;
  }
});

if (educationContinuePreviewBtn) educationContinuePreviewBtn.addEventListener("click", async () => {
  report.classList.add("hidden");
  setRunning(true);
  runStatus.textContent = "正在执行共享教育记录事务：身份匹配、补缺、局部保存并回读…";
  try {
    const continued = await window.lite.continueEducationRecords(browser.getWebContentsId());
    const detail = continued && continued.result || {};
    const preview = detail.preview || {};
    const traces = Array.isArray(preview.fieldTrace) ? preview.fieldTrace : [];
    const committed = traces.filter((item) => item && item.committed).map((item) => item.fieldKey).filter(Boolean);
    const failed = traces.filter((item) => item && item.attempted && !item.committed).map((item) => `${item.fieldKey}:${item.reason || "未回读"}`);
    const skipped = traces.filter((item) => item && !item.attempted).map((item) => `${item.fieldKey}:${item.reason || "跳过"}`);
    report.classList.remove("hidden");
    const state = detail.result === "complete"
      ? "教育记录完整性校验通过：资料库记录均已在页面找到"
      : detail.result === "saved_and_complete"
        ? "缺失教育记录已填写、保存并完成身份回读，教育模块已完整"
        : detail.result === "saved_and_verified"
          ? "缺失教育记录已填写、保存并通过身份回读"
          : detail.result === "needs_review"
            ? "已有教育记录身份无法唯一匹配，已停止避免重复新增"
            : detail.result === "blocked_by_validation"
              ? "教育保存被页面校验拦截，编辑器已保留供人工处理"
              : detail.result === "blocked_by_fill_failure"
                ? "教育字段写入存在回读失败，未点击保存"
                : "教育记录事务未完成";
    report.innerHTML = `<strong>${escapeHtml(state)}</strong>` +
      `<div style="margin-top:5px">资料库 ${Number(detail.profileRecordCount || continued.profileRecordCount || 0)} 条 · 页面保存前 ${Number(detail.existingPageRecordCountBefore || 0)} 条 · 保存后 ${Number(detail.existingPageRecordCountAfter || detail.existingPageRecordCountBefore || 0)} 条</div>` +
      (Array.isArray(detail.matchedProfileIndicesBefore) && detail.matchedProfileIndicesBefore.length ? `<div style="margin-top:5px">保存前已匹配资料记录：${escapeHtml(detail.matchedProfileIndicesBefore.map((x) => Number(x) + 1).join("、"))}</div>` : "") +
      (Number.isInteger(detail.targetProfileRecordIndex) && detail.targetProfileRecordIndex >= 0 ? `<div style="margin-top:5px">本轮补充目标：资料库第 ${Number(detail.targetProfileRecordIndex) + 1} 条</div>` : "") +
      (committed.length ? `<div style="margin-top:5px"><strong>已回读字段：</strong>${escapeHtml(committed.join("、"))}</div>` : "") +
      (failed.length ? `<div style="margin-top:5px"><strong>写入失败：</strong>${escapeHtml(failed.join("；"))}</div>` : "") +
      (skipped.length ? `<div style="margin-top:5px"><strong>资料缺失/跳过：</strong>${escapeHtml(skipped.join("；"))}</div>` : "") +
      (detail.saveClickDispatched ? `<div style="margin-top:5px">局部保存：已点击 · 保存反馈：${detail.saveFeedbackVerified ? "已验证" : "未验证"}${detail.saveModalDetected ? ` · 成功弹窗已关闭：${detail.saveModalClosed ? "是" : "否"}` : ""}</div>` : "") +
      (Array.isArray(detail.newValidationMessages) && detail.newValidationMessages.length ? `<div style="margin-top:5px"><strong>页面校验：</strong>${escapeHtml(detail.newValidationMessages.join("；"))}</div>` : "") +
      (detail.targetIdentityVerified ? `<div style="margin-top:5px">保存后身份回读：通过</div>` : "") +
      (detail.reason && detail.reason !== "education_no_missing_record" ? `<div style="margin-top:5px">状态原因：${escapeHtml(detail.reason)}</div>` : "") +
      `<div style="margin-top:5px">诊断日志：${escapeHtml(continued.logFileName || "已写入 logs")}</div>` +
      `<div style="margin-top:5px">本事务只处理教育背景局部记录，不会上传附件或执行最终提交。</div>`;
    runStatus.textContent = detail.result === "complete"
      ? "教育记录完整性校验通过。"
      : detail.result === "saved_and_complete" || detail.result === "saved_and_verified"
        ? "教育记录已局部保存并通过身份回读。"
        : `教育记录事务已停止：${detail.reason || "请查看日志"}`;
  } catch (error) {
    runStatus.textContent = `教育记录事务失败：${error.message || error}`;
    report.classList.remove("hidden");
    report.textContent = "教育事务已停止；不会上传附件或最终提交。请查看最新诊断日志。";
  } finally {
    setRunning(false);
  }
});


if (multiSectionSurveyBtn) multiSectionSurveyBtn.addEventListener("click", async () => {
  report.classList.add("hidden");
  setRunning(true);
  runStatus.textContent = "正在批量探测后续简历分区…只打开并关闭编辑器，不填写、不保存。";
  try {
    const survey = await window.lite.surveyResumeSectionEditors(browser.getWebContentsId());
    const detail = survey && survey.result || {};
    const items = Array.isArray(detail.sections) ? detail.sections : [];
    const rows = items.map((item) => {
      const probe = item && item.probe || {};
      const fields = Array.isArray(probe.fields) ? probe.fields : [];
      const labels = fields.slice(0, 12).map((field) => field.label || field.placeholder || field.name || field.id || field.tagName).filter(Boolean);
      const state = probe.result === "probe_complete_closed" ? "完成" : `未完成${probe.reason ? `（${probe.reason}）` : ""}`;
      return `<div style="margin-top:7px"><strong>${escapeHtml(item.section || "未知分区")}</strong>：${escapeHtml(state)} · 新控件 ${Number(probe.newVisibleControlCount || 0)} 个${labels.length ? ` · ${escapeHtml(labels.join("、"))}` : ""}</div>`;
    }).join("");
    report.classList.remove("hidden");
    report.innerHTML = `<strong>${detail.result === "complete" ? "后续分区批量探测完成" : detail.result === "complete_with_gaps" ? "后续分区探测完成，但部分分区没有可安全探测的新增编辑器" : "后续分区探测提前停止"}</strong>` +
      `<div style="margin-top:5px">目标 ${Number(detail.requestedSectionCount || 0)} 个 · 完成 ${Number(detail.completedSectionCount || 0)} · 未完成 ${Number(detail.failedSectionCount || 0)}</div>` +
      rows +
      (detail.reason ? `<div style="margin-top:7px">总体状态：${escapeHtml(detail.reason)}</div>` : "") +
      `<div style="margin-top:7px">诊断日志：${escapeHtml(survey.logFileName || "已写入 logs")}</div>` +
      `<div style="margin-top:5px">本轮不会写入资料、不会局部保存、不会上传附件，也不会最终提交。</div>`;
    runStatus.textContent = detail.result === "complete"
      ? "六个后续分区结构已一次性采集完成。"
      : detail.result === "complete_with_gaps"
        ? "批量探测完成，部分分区需单独处理。"
        : `批量探测提前停止：${detail.reason || "请查看日志"}`;
  } catch (error) {
    runStatus.textContent = `批量分区探测失败：${error.message || error}`;
    report.classList.remove("hidden");
    report.textContent = "批量探测已停止；没有填写、保存、上传附件或最终提交。请保留最新日志。";
  } finally {
    setRunning(false);
  }
});


if (multiSectionPreviewBtn) multiSectionPreviewBtn.addEventListener("click", async () => {
  report.classList.add("hidden");
  setRunning(true);
  runStatus.textContent = "正在批量验证后续分区数据绑定…写入后会回读、恢复为空并安全返回，不会保存。";
  try {
    const batch = await window.lite.previewResumeSections(browser.getWebContentsId());
    const detail = batch && batch.result || {};
    const items = Array.isArray(detail.sections) ? detail.sections : [];
    const rows = items.map((item) => {
      const preview = item && item.preview || {};
      const traces = Array.isArray(preview.fieldTrace) ? preview.fieldTrace : [];
      const committed = traces.filter((x) => x && x.committed).map((x) => x.fieldKey).filter(Boolean);
      const failed = traces.filter((x) => x && x.attempted && !x.committed).map((x) => `${x.fieldKey}:${x.reason || "未回读"}`);
      const skipped = traces.filter((x) => x && !x.attempted).map((x) => `${x.fieldKey}:${x.reason || "跳过"}`);
      const state = preview.result === "preview_complete" ? "预填验证通过"
        : preview.result === "preview_with_field_gaps" ? "预填完成但有字段缺口"
          : preview.result === "probe_complete_closed" ? "结构探测完成"
            : `未完成${preview.reason ? `（${preview.reason}）` : ""}`;
      return `<div style="margin-top:8px"><strong>${escapeHtml(item.section || "未知分区")}</strong>${item.recordKind && item.recordKind !== "structure_probe" ? ` / ${escapeHtml(item.recordKind)}` : ""}：${escapeHtml(state)}` +
        (committed.length ? `<div style="margin-left:14px">已回读：${escapeHtml(committed.join("、"))}</div>` : "") +
        (failed.length ? `<div style="margin-left:14px">写入失败：${escapeHtml(failed.join("；"))}</div>` : "") +
        (skipped.length ? `<div style="margin-left:14px">资料缺失/跳过：${escapeHtml(skipped.join("；"))}</div>` : "") +
        (Array.isArray(item.unmappedProfileFields) && item.unmappedProfileFields.length ? `<div style="margin-left:14px">尚无控件映射：${escapeHtml(item.unmappedProfileFields.join("、"))}</div>` : "") +
        `</div>`;
    }).join("");
    report.classList.remove("hidden");
    report.innerHTML = `<strong>${detail.result === "complete" ? "后续分区批量预填验证完成" : detail.result === "complete_with_gaps" ? "后续分区预填验证完成，但仍有少量缺口" : "后续分区预填验证提前停止"}</strong>` +
      rows +
      (detail.reason ? `<div style="margin-top:8px">总体状态：${escapeHtml(detail.reason)}</div>` : "") +
      `<div style="margin-top:8px">诊断日志：${escapeHtml(batch.logFileName || "已写入 logs")}</div>` +
      `<div style="margin-top:5px">本轮真实写入只用于回读验证；随后恢复原始空值并点击返回。不会局部保存、上传附件或最终提交。</div>`;
    runStatus.textContent = detail.result === "complete"
      ? "后续分区数据绑定批量验证完成。"
      : detail.result === "complete_with_gaps"
        ? "批量预填验证完成，仍有少量字段或结构需处理。"
        : `批量预填验证提前停止：${detail.reason || "请查看日志"}`;
  } catch (error) {
    runStatus.textContent = `批量预填验证失败：${error.message || error}`;
    report.classList.remove("hidden");
    report.textContent = "验证已停止；不会保存、上传附件或最终提交。请保留最新日志。";
  } finally {
    setRunning(false);
  }
});


browser.addEventListener("did-navigate", (e) => { urlBar.value = e.url || browser.getURL(); report.classList.add("hidden"); });
browser.addEventListener("did-navigate-in-page", (e) => { urlBar.value = e.url || browser.getURL(); });
browser.addEventListener("page-title-updated", updateWindowTitle);
browser.addEventListener("did-fail-load", (e) => {
  if (e.errorCode === -3) return;
  runStatus.textContent = `页面加载失败：${e.errorDescription || e.errorCode}`;
});

if (window.lite && typeof window.lite.onNavigate === "function") {
  window.lite.onNavigate((url) => {
    navigate(url);
  });
}

initToolbarMenus();
initBuildInfo();
refreshProfileStatus();

window.addEventListener("focus", refreshProfileStatus);
