// content/date-picker/handlers/mtd.js — 美团 MTD 日期选择器 (.mtd-date-picker)
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   工厂分支 Kn.create() case "mtd": 行46006 -> to
//   to.setValue: 行 46461-46530 (string 走 zt() 单选; object 走 findSimilarElements+ho() 兄弟填结束)
//   zt()/Ht() (打开 .mtd-datepicker-pop-wrapper 面板 -> 调通用导航器 w()): 行 32255-32300
//   w() 调用选择器: 行 32282 (已核实, 逐参数照搬)
//
// 注: 之前版本是"直接 input.value= 赋值"的占位实现，对美团这种自定义 MTD 组件根本不会打开面板、
//     也不触发框架状态更新 -> 填不上。现按源码恢复真实的"打开面板->翻年->翻月->点日期"流程。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  // 源码 zt()/Ht() (行32255): focus+click 打开 MTD 面板, 再用通用导航器 w() 选日期
  async function mtdSingleNavigate(triggerEl, dateStr, maxRetries) {
    maxRetries = maxRetries || 20;
    var input = (triggerEl.querySelector && triggerEl.querySelector("input")) || triggerEl;
    input.dispatchEvent(new FocusEvent("focus"));
    input.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
    await AF.Utils.sleep(200);
    var panel = document.querySelector('.mtd-datepicker-pop-wrapper:not([style*="display: none"])');
    if (!panel) throw new Error("MTD calendar picker not found or not visible");
    // 源码行32282: w(panel, dateStr, ".mtd-month-calendar-year-btn", ".mtd-year-panel-list-data",
    //   false, ".mtd-month-calendar-year-header-range", ".right-switcher", ".left-switcher",
    //   null, ".mtd-month-panel-list-data", ".mtd-day-panel-list-data", maxRetries)
    var ok = await AF.DatePicker._navigatePanel({
      container: panel,
      dateString: dateStr,
      headerClickSelector: ".mtd-month-calendar-year-btn",
      yearCellSelector: ".mtd-year-panel-list-data",
      disabledClassList: false,
      yearBoundarySelector: ".mtd-month-calendar-year-header-range",
      nextYearSelector: ".right-switcher",
      prevYearSelector: ".left-switcher",
      monthPanelSelector: null,
      monthCellSelector: ".mtd-month-panel-list-data",
      dayCellSelector: ".mtd-day-panel-list-data",
      maxRetries: maxRetries,
    });
    if (!ok) throw new Error("MTD calendar navigation failed");
    return true;
  }

  AF.DatePicker._registry["mtd"] = function (element, valueType) {
    return {
      setValue: async function (value) {
        try {
          if (!value) throw new Error("日期为空");
          if (typeof value === "string" || valueType === "string") {
            return await mtdSingleNavigate(element, value);
          }
          if (typeof value !== "object" || !("startTime" in value) || !("endTime" in value)) {
            throw new Error("当option为对象时，dateValue必须包含startTime和endTime属性");
          }
          // 源码 to.setValue object 分支 (行46471): 先取兄弟候选, 再填开始, 再挑"结束"兄弟框填结束
          var candidates = AF.DomUtils.findSimilarElements(element, 4, { sameTag: true, sameClass: true, sameParent: false });
          await mtdSingleNavigate(element, value.startTime);
          await AF.Utils.sleep(500);
          if (candidates.length > 0) {
            var best = AF.DatePicker._pickEndDateCandidate(element, candidates);
            await mtdSingleNavigate(best, value.endTime);
          } else {
            var surrounding = AF.DomUtils.findSurroundingInputs(element);
            if (surrounding.length > 0) await mtdSingleNavigate(surrounding[0], value.endTime);
          }
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
