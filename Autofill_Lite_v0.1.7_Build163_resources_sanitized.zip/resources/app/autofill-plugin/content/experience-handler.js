// content/experience-handler.js — ExperienceHandler「新版经历填写方案」
//
// 源码参考 (/Users/dayu/Desktop/网页端/原始代码和索引/content.readable.js):
//   ExperienceHandler 类 (混淆名内联):  行 11135-12060
//   ConfigAdapter 类 (混淆名 h):         行 7613-7830 (supportsNewExperienceScheme 起 7625)
//
// 这是把源码 fillExperienceByNewScheme 一整套(17个方法) + ConfigAdapter(全部 getter)
// 从 regenerator 状态机 de-sugar 成 async/await 的逐方法忠实移植。它专门消费站点配置里
// 的 `experience` 段 (card/editor/add/save/special)，实现:
//   - 进入容器/卡片编辑模式 (ensureContainerEditMode / ensureCardEditMode)
//   - 按需点"添加"补齐卡片 (addNewCard)
//   - 填一张卡 → (可选)保存 → 再填下一张 (requiresSaveBeforeNext)
//   - 单卡片模式 (singleCardMode + dataIndexByCardCount)
//   - 北森 Phoenix 卡片的 ".phoenix-select 先选'开始添加'" 前置流程
//
// 唯一对齐 rebuild 契约的改动 (非逻辑改动):
//   源码 findElementAndTypeByLabel 返回的文本类型叫 "input"，rebuild 的 ElementMatcher
//   契约里统一叫 "text"，所以 fillSingleField 的类型二次修正判断用 "text" (见下方注释)。
//
// 依赖: AF.Utils.sleep / AF.DomUtils.* / AF.LabelUtils.getLabelText /
//       AF.FormHandler.fillFormElement / elementMatcher.findContainerByTitle /
//       elementMatcher.findLabelsByCard / elementMatcher.findElementAndTypeByLabel /
//       dataMatcher.findFieldByCategory / dataMatcher.getCategoryByTitle / dataMatcher.resumeData
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});

  // Build111 RecordGraph execution bridge.
// It only supplies ownership/identity hints; existing ExperienceHandler remains
// responsible for fill/save transaction ordering.
function getRecordGraphExecutionHints(graph) {
  try {
    if (globalThis.AF && globalThis.AF.RecordGraph && typeof globalThis.AF.RecordGraph.buildExecutionBridge === "function") {
      return globalThis.AF.RecordGraph.buildExecutionBridge(graph);
    }
  } catch (_) {}
  return [];
}

// Build112: convert RecordGraph ownership hints into an execution preparation
// object. This remains planning-only: no click/fill/save/submit side effects.
function buildRecordExecutionPlan(graph) {
  var hints = getRecordGraphExecutionHints(graph);
  return hints.map(function (hint) {
    return {
      groupId: hint.groupId || "",
      categoryHint: hint.categoryHint || "",
      mode: hint.editorRecordCount > 0 ? "edit_existing" : (hint.addActionCount > 0 ? "add_candidate" : "unknown"),
      recordsReady: Number(hint.recordCount || 0),
      safety: {
        executeActions: false,
        saveAllowed: false,
        submitAllowed: false
      }
    };
  });
}

// 数组型经历的通用身份规则。这里只描述“同一条记录如何辨认”，不包含站点选择器.
  // 动态策略层会先用它盘点页面已有记录，再把未命中的记录交回原填写器。
  var RECORD_IDENTITIES = AF.RecordGraph && AF.RecordGraph.identityRules
    ? AF.RecordGraph.identityRules
    : {
      示例资料: { primary: ["school"], secondary: ["level", "startTime"] },
      示例资料Experience: { primary: ["company"], secondary: ["position", "startTime"] },
      示例资料Experience: { primary: ["company"], secondary: ["position", "startTime"] },
      示例资料Experience: { primary: ["示例资料Name", "name", "title"], secondary: ["role", "startTime"] },
      campusLeadership: { primary: ["示例资料Name", "title"], secondary: ["startTime", "endTime"] },
      campusActivities: { primary: ["activityName", "name", "示例资料Name"], secondary: ["role", "startTime"] },
      示例资料Experience: { primary: ["name", "示例资料Name"], secondary: ["organization", "startTime"] },
      示例资料: { primary: ["awardName"], secondary: ["awardTime", "awardGrade"] },
      示例资料: { primary: ["certificateName", "name"], secondary: ["certificateNo", "obtainedTime", "obtainTime"] },
      publications: { primary: ["paperTitle", "title", "name"], secondary: ["publishTime", "publishYear", "journal"] },
      示例资料s: { primary: ["示例资料Name", "name"], secondary: ["grantDate", "authorizationDate", "示例资料Type"] },
      示例资料Skills: { primary: ["name", "示例资料"], secondary: ["level", "score", "certificateName"] },
      示例资料Members: { primary: ["name"], secondary: ["relationship"], requireSecondary: true }
    };
  var RECORD_IGNORED_SELECTOR = "#autofill-panel-root, #__af_report_buttons__, #__af_diagnostic_btn__, #autofill-mini-logo";
  // 默认不主动点经历卡片保存，避免对未知站点产生提交类副作用。
  // 只有站点配置显式声明 save.allowAutoSave=true 时才启用。
  var ENABLE_AUTO_SAVE_EXPERIENCE_CARDS_BY_DEFAULT = false;

  AF.ExperienceRecordBridge = AF.ExperienceRecordBridge || {
    getExecutionHints: getRecordGraphExecutionHints,
    buildExecutionPlan: buildRecordExecutionPlan
  };

  function buildEducationDialogChoiceValue(category, fieldKey, rowData, value) {
    if (category !== "示例资料" || value == null || !/^(school|major)$/.test(String(fieldKey || ""))) return value;
    if (fieldKey === "school") {
      return { name: String(value), dialogChoice: { allowFirstResult: true } };
    }
    var alternatives = [];
    [rowData && rowData.majorSubcategory, rowData && rowData.majorCategory, rowData && rowData.czbankMajorCategory].forEach(function (item) {
      item = String(item || "").trim();
      if (item && alternatives.indexOf(item) === -1) alternatives.push(item);
    });
    String(rowData && rowData.majorPath || "").split(/\s*(?:\/|>|＞|\|)\s*/).reverse().forEach(function (item) {
      item = String(item || "").trim();
      if (item && item !== String(value) && alternatives.indexOf(item) === -1) alternatives.push(item);
    });
    return { name: String(value), dialogChoice: { alternatives: alternatives, preferExistingOptions: true } };
  }

  function buildEducationMajorCascaderValue(category, fieldKey, rowData, value, element) {
    if (
      category !== "示例资料" ||
      fieldKey !== "majorCategory" ||
      !element || !element.closest ||
      !element.closest(".ant-cascader-picker")
    ) return value;
    var parent = String(value == null ? "" : value).trim().replace(/类$/, "");
    var child = String(rowData && (rowData.majorSubcategory || rowData.czbankMajorCategory) || "").trim();
    return [parent, child].filter(Boolean);
  }

  function normalizedRecordText(value) {
    return String(value == null ? "" : value)
      .toLowerCase()
      .replace(/至今|目前|现在|仍在职|在职|当前/g, "至今")
      .replace(/[\s：:，,。.;；、()（）\-_\/\\]/g, "");
  }

  function firstRecordValue(data, keys) {
    for (var i = 0; i < (keys || []).length; i++) {
      var value = data && data[keys[i]];
      if (value != null && String(value).trim()) return String(value).trim();
    }
    return "";
  }

  function visiblePageSnapshot(root) {
    var scope = root && root.ownerDocument ? root.ownerDocument : document;
    var textParts = [];
    if (scope.body && scope.createTreeWalker) {
      var walker = scope.createTreeWalker(scope.body, NodeFilter.SHOW_TEXT);
      var textNode;
      while ((textNode = walker.nextNode())) {
        var parent = textNode.parentElement;
        if (!parent || parent.closest(RECORD_IGNORED_SELECTOR)) continue;
        if (!AF.DomUtils || !AF.DomUtils.isElementVisible(parent)) continue;
        var value = String(textNode.nodeValue || "").trim();
        if (value) textParts.push(value);
      }
    }
    var bodyText = textParts.join(" ");
    var controlValues = Array.from(scope.querySelectorAll("input, textarea, select")).filter(function (el) {
      return !el.closest(RECORD_IGNORED_SELECTOR) && AF.DomUtils && AF.DomUtils.isElementVisible(el);
    }).map(function (el) {
      if (el.tagName === "SELECT") {
        return Array.from(el.selectedOptions || []).map(function (option) {
          return option.textContent || option.value || "";
        }).join(" ");
      }
      return el.value || "";
    }).filter(Boolean).join(" ");
    return normalizedRecordText(bodyText + " " + controlValues);
  }

  function countOccurrences(haystack, needle) {
    if (!needle || needle.length < 2) return 0;
    var count = 0;
    var offset = 0;
    while ((offset = haystack.indexOf(needle, offset)) !== -1) {
      count++;
      offset += needle.length;
    }
    return count;
  }

  function identityFor(record) {
    var category = record && record.category;
    var data = record && record.data || {};
    var rule = RECORD_IDENTITIES[category];
    if (!rule) return null;
    var primaryValue = firstRecordValue(data, rule.primary);
    if (!primaryValue) return null;
    var secondaryValue = firstRecordValue(data, rule.secondary);
    return {
      category: category,
      primary: primaryValue,
      primaryNormalized: normalizedRecordText(primaryValue),
      secondary: secondaryValue,
      secondaryNormalized: normalizedRecordText(secondaryValue),
      requireSecondary: Boolean(rule.requireSecondary),
      label: primaryValue + (secondaryValue ? " / " + secondaryValue : "")
    };
  }

  function elementRecordText(el) {
    if (!el) return "";
    var text = String(el.innerText || el.textContent || "");
    var values = Array.from(el.querySelectorAll ? el.querySelectorAll("input, textarea, select") : []).filter(function (control) {
      return AF.DomUtils && AF.DomUtils.isElementVisible(control);
    }).map(function (control) {
      if (control.tagName === "SELECT") {
        return Array.from(control.selectedOptions || []).map(function (option) {
          return option.textContent || option.value || "";
        }).join(" ");
      }
      return control.value || "";
    }).join(" ");
    return normalizedRecordText(text + " " + values);
  }

  function findEditAction(card) {
    if (!card || !card.querySelectorAll) return null;
    return Array.from(card.querySelectorAll("button, a, [role='button'], [onclick]")).filter(function (el) {
      return AF.DomUtils && AF.DomUtils.isElementVisible(el) && !el.closest(RECORD_IGNORED_SELECTOR);
    }).find(function (el) {
      var text = String([
        el.textContent,
        el.getAttribute("aria-label"),
        el.getAttribute("title"),
        el.getAttribute("data-icon")
      ].filter(Boolean).join(" ")).replace(/\s+/g, "").toLowerCase();
      var editIcon = el.querySelector && el.querySelector('[data-icon*="edit" i], .anticon-edit, [class*="edit" i]');
      var unsafe = /删除|移除|提交|投递|申请|下一步|delete|remove|submit|apply|next/.test(text);
      return !unsafe && (Boolean(editIcon) || /^(编辑|修改|edit|modify)$/.test(text) || /(^|[^a-z])(edit|modify)([^a-z]|$)/.test(text));
    }) || null;
  }

  function candidateCardRoots(identity, doc) {
    var anchors = [];
    var primary = identity.primaryNormalized;
    if (doc.body && doc.createTreeWalker) {
      var walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
      var node;
      while ((node = walker.nextNode())) {
        var parent = node.parentElement;
        if (!parent || parent.closest(RECORD_IGNORED_SELECTOR)) continue;
        if (!AF.DomUtils || !AF.DomUtils.isElementVisible(parent)) continue;
        if (normalizedRecordText(node.nodeValue).indexOf(primary) !== -1) anchors.push(parent);
      }
    }
    Array.from(doc.querySelectorAll("input, textarea, select")).filter(function (control) {
      return !control.closest(RECORD_IGNORED_SELECTOR) && AF.DomUtils && AF.DomUtils.isElementVisible(control);
    }).forEach(function (control) {
      var value = control.tagName === "SELECT"
        ? Array.from(control.selectedOptions || []).map(function (option) { return option.textContent || option.value || ""; }).join(" ")
        : control.value || "";
      if (normalizedRecordText(value).indexOf(primary) !== -1) anchors.push(control);
    });

    var candidates = [];
    anchors.forEach(function (anchor) {
      var current = anchor;
      for (var depth = 0; current && depth < 8; depth++, current = current.parentElement) {
        if (current === doc.body || current === doc.documentElement || current.closest(RECORD_IGNORED_SELECTOR)) break;
        if (!AF.DomUtils || !AF.DomUtils.isElementVisible(current)) continue;
        var snapshot = elementRecordText(current);
        if (snapshot.indexOf(primary) === -1 || snapshot.length > 5000) continue;
        var editAction = findEditAction(current);
        var classText = String(current.className || "").toLowerCase();
        var cardLike = /card|item|record|experience|resume|list|row|panel/.test(classText) ||
          /^(LI|TR|ARTICLE|SECTION|DL)$/.test(current.tagName);
        var 示例资料ed = Boolean(current.parentElement && Array.from(current.parentElement.children || []).filter(function (sibling) {
          return sibling.tagName === current.tagName;
        }).length > 1);
        var secondaryPresent = !identity.secondaryNormalized || snapshot.indexOf(identity.secondaryNormalized) !== -1;
        var score = 50 + (editAction ? 30 : 0) + (cardLike ? 14 : 0) + (示例资料ed ? 10 : 0) +
          (secondaryPresent ? 8 : 0) - Math.min(25, Math.floor(snapshot.length / 200));
        candidates.push({
          card: current,
          editAction: editAction,
          score: score,
          secondaryPresent: secondaryPresent,
          textLength: snapshot.length
        });
      }
    });
    return candidates.sort(function (a, b) {
      return b.score - a.score || a.textLength - b.textLength;
    });
  }

  function findCardBinding(identity, root, usedCards) {
    var doc = root && root.ownerDocument ? root.ownerDocument : document;
    var candidates = candidateCardRoots(identity, doc).filter(function (candidate) {
      return !(usedCards || []).some(function (used) {
        return used === candidate.card || used.contains(candidate.card) || candidate.card.contains(used);
      });
    });
    if (!candidates.length) return null;
    var best = candidates[0];
    if (identity.requireSecondary && identity.secondaryNormalized && !best.secondaryPresent) return null;
    return {
      card: best.card,
      editAction: best.editAction,
      confidence: Number(Math.min(1, 0.72 + (best.editAction ? 0.12 : 0) + (best.secondaryPresent ? 0.1 : 0)).toFixed(2)),
      bindingType: best.editAction ? "card_with_edit" : "visible_record"
    };
  }

  function reconcileExistingRecords(records, root) {
    var snapshot = visiblePageSnapshot(root);
    var usedCards = [];
    var matched = [];
    var pending = [];
    (records || []).forEach(function (record, queueIndex) {
      var identity = identityFor(record);
      if (!identity || identity.primaryNormalized.length < 2) {
        pending.push(record);
        return;
      }
      var binding = findCardBinding(identity, root, usedCards);
      if (binding) {
        usedCards.push(binding.card);
        matched.push({
          record: record,
          queueIndex: queueIndex,
          identity: identity,
          action: "reuse",
          targetCard: binding.card,
          editAction: binding.editAction,
          confidence: binding.confidence,
          bindingType: binding.bindingType
        });
      } else {
        pending.push(record);
      }
    });
    return { matched: matched, pending: pending, snapshotLength: snapshot.length };
  }

  AF.ExperienceRecordMatcher = {
    identities: RECORD_IDENTITIES,
    identityFor: identityFor,
    findCardBinding: findCardBinding,
    reconcile: reconcileExistingRecords
  };

  function isCurrentEndValue(value) {
    return typeof value === "string" && /^(至今|目前|现在|仍在职|在职|仍在进行|当前)$/.test(value.trim());
  }

  function todayDateString() {
    var now = new Date();
    var pad = function (n) { return String(n).padStart(2, "0"); };
    return now.getFullYear() + "-" + pad(now.getMonth() + 1) + "-" + pad(now.getDate());
  }

  function linkedTemporalValue(labelEl, labelText, rowData, config) {
    if (!rowData || !rowData.startTime || !rowData.endTime || !/(时间|日期|年月)/.test(labelText || "")) return null;
    var configured = config && config.domStrategy && config.domStrategy.temporalGroups || [];
    var normalized = String(labelText || "").replace(/\s+/g, "");
    var configuredMatch = configured.some(function (group) {
      var groupLabel = String(group && group.label || "").replace(/\s+/g, "");
      return group && group.type === "linked_range" && groupLabel &&
        (normalized.indexOf(groupLabel) !== -1 || groupLabel.indexOf(normalized) !== -1);
    });
    var scope = labelEl && labelEl.closest && labelEl.closest(
      ".ant-form-item, .el-form-item, .pt-l, .pt-r, [class*='form-item' i], [role='group'], fieldset"
    );
    var dateInputs = scope ? Array.from(scope.querySelectorAll("input")).filter(function (input) {
      return AF.DomUtils && AF.DomUtils.isElementVisible(input);
    }) : [];
    var domRange = Boolean(
      scope && (
        scope.querySelector(".ant-picker-range, .ant-calendar-range-picker, .el-range-editor, .next-range-picker, .next-date-picker, .next-month-picker") ||
        dateInputs.length >= 2
      )
    );
    if (!configuredMatch && !domRange) return null;
    return {
      startTime: rowData.startTime,
      endTime: rowData.endTime,
      current: isCurrentEndValue(rowData.endTime)
    };
  }

  // ============================================================
  // ConfigAdapter (源码 h 类, 行 7613-7830)
  // 把站点配置的 experience 段包装成一组语义 getter，缺省值与源码逐条一致。
  // ============================================================
  function ConfigAdapter(siteConfig) {
    this.siteConfig = siteConfig || {};
    this.experienceConfig = (siteConfig && siteConfig.experience) || {};
  }

  // 把 xxxText 归一化成数组 (源码 getContainerEditButtonText 等的写法, 行7663-7671)
  function toTextArray(v) {
    if (Array.isArray(v)) return v;
    if (v) return [v];
    return [];
  }

  ConfigAdapter.prototype.supportsNewExperienceScheme = function () {
    return Boolean(this.experienceConfig && Object.keys(this.experienceConfig).length > 0);
  };
  ConfigAdapter.prototype.getExperienceConfig = function () {
    return this.experienceConfig;
  };
  ConfigAdapter.prototype.getContainerConfig = function () {
    return this.experienceConfig.container || {};
  };
  ConfigAdapter.prototype.getContainerSelector = function () {
    return this.getContainerConfig().containerSelector || "";
  };
  ConfigAdapter.prototype.getCardConfig = function () {
    return this.experienceConfig.card || {};
  };
  ConfigAdapter.prototype.getCardSelector = function () {
    return this.getCardConfig().cardSelector || "";
  };
  ConfigAdapter.prototype.getEditorConfig = function () {
    return this.experienceConfig.editor || {};
  };
  ConfigAdapter.prototype.getContainerEditButtonSelector = function () {
    return this.getEditorConfig().containerEditButtonSelector;
  };
  ConfigAdapter.prototype.getContainerEditButtonText = function () {
    return toTextArray(this.getEditorConfig().containerEditButtonText);
  };
  ConfigAdapter.prototype.getCardEditButtonSelector = function () {
    return this.getEditorConfig().cardEditButtonSelector;
  };
  ConfigAdapter.prototype.getCardEditButtonText = function () {
    return toTextArray(this.getEditorConfig().cardEditButtonText);
  };
  ConfigAdapter.prototype.getEditModeGuardSelector = function () {
    return this.getEditorConfig().editModeGuardSelector;
  };
  // Build116 Existing Editor Adoption: mature/site configs may explicitly expose
  // the active editor shell.  Global adoption remains opt-in so an unrelated
  // modal/drawer can never be mistaken for the current experience record.
  ConfigAdapter.prototype.getExistingEditorScopeSelector = function () {
    var editor = this.getEditorConfig();
    return editor.existingEditorScopeSelector || editor.activeEditorScopeSelector || "";
  };
  ConfigAdapter.prototype.allowGlobalExistingEditorAdoption = function () {
    var editor = this.getEditorConfig();
    return editor.allowGlobalExistingEditorAdoption === true;
  };
  ConfigAdapter.prototype.getEditTimeoutMs = function () {
    return this.getEditorConfig().editTimeoutMs || 200;
  };
  ConfigAdapter.prototype.getAddConfig = function () {
    return this.experienceConfig.add || {};
  };
  ConfigAdapter.prototype.getAddButtonSelector = function () {
    return this.getAddConfig().addButtonSelector;
  };
  ConfigAdapter.prototype.getAddButtonText = function () {
    return toTextArray(this.getAddConfig().addButtonText);
  };
  ConfigAdapter.prototype.getAddTimeoutMs = function () {
    return this.getAddConfig().addTimeoutMs || 200;
  };
  ConfigAdapter.prototype.getSaveConfig = function () {
    return this.experienceConfig.save || {};
  };
  ConfigAdapter.prototype.isAutoSaveAllowed = function () {
    var saveConfig = this.getSaveConfig();
    return Boolean(
      saveConfig.allowAutoSave ||
      this.experienceConfig.allowAutoSave ||
      this.siteConfig.allowAutoSaveExperienceCards ||
      ENABLE_AUTO_SAVE_EXPERIENCE_CARDS_BY_DEFAULT
    );
  };
  ConfigAdapter.prototype.requiresSaveBeforeNext = function () {
    return this.isAutoSaveAllowed() && Boolean(this.getSaveConfig().requiresSaveBeforeNext);
  };
  ConfigAdapter.prototype.usesInlinePersistence = function () {
    return Boolean(this.getSaveConfig().inlinePersistence);
  };
  ConfigAdapter.prototype.getSaveButtonSelector = function () {
    return this.getSaveConfig().saveButtonSelector;
  };
  ConfigAdapter.prototype.getSaveButtonText = function () {
    return toTextArray(this.getSaveConfig().saveButtonText);
  };
  ConfigAdapter.prototype.getSaveWaitForSelector = function () {
    return this.getSaveConfig().saveWaitForSelector;
  };
  ConfigAdapter.prototype.getSaveTimeoutMs = function () {
    return this.getSaveConfig().saveTimeoutMs || 200;
  };
  // validateConfig (源码行7768-7806): errors 决定 valid，warnings 仅提示
  ConfigAdapter.prototype.validateConfig = function () {
    var warnings = [];
    var errors = [];
    if (!this.getContainerSelector()) errors.push("缺少 container.containerSelector 配置");
    if (!this.getCardSelector()) errors.push("缺少 card.cardSelector 配置");
    var hasContainerEditSel = Boolean(this.getContainerEditButtonSelector());
    var hasContainerEditText = this.getContainerEditButtonText().length > 0;
    if (!hasContainerEditSel && !hasContainerEditText) warnings.push("容器编辑按钮配置不完整，可能影响编辑模式进入");
    var hasCardEditSel = Boolean(this.getCardEditButtonSelector());
    var hasCardEditText = this.getCardEditButtonText().length > 0;
    if (!hasCardEditSel && !hasCardEditText) warnings.push("卡片编辑按钮配置不完整，可能影响编辑模式进入");
    var hasAddSel = Boolean(this.getAddButtonSelector());
    var hasAddText = this.getAddButtonText().length > 0;
    if (!hasAddSel && !hasAddText) warnings.push("添加按钮配置不完整，可能无法添加新卡片");
    if (this.requiresSaveBeforeNext()) {
      var hasSaveSel = Boolean(this.getSaveButtonSelector());
      var hasSaveText = this.getSaveButtonText().length > 0;
      if (!hasSaveSel && !hasSaveText) warnings.push("需要保存但保存按钮配置不完整");
    }
    return { valid: errors.length === 0, errors: errors, warnings: warnings };
  };
  ConfigAdapter.prototype.debugConfig = function () {
    // 源码行7807-7812: 仅读取 validateConfig 结果，无副作用 (原版是 console 调试，此处留空)
    this.validateConfig();
  };
  ConfigAdapter.prototype.isSingleCardMode = function () {
    var exp = this.siteConfig && this.siteConfig.experience;
    var special = exp && exp.special;
    return Boolean(special && special.singleCardMode);
  };
  ConfigAdapter.prototype.isDataIndexByCardCount = function () {
    var exp = this.siteConfig && this.siteConfig.experience;
    var special = exp && exp.special;
    return Boolean(special && special.dataIndexByCardCount);
  };
  ConfigAdapter.prototype.isNonBlockingCategory = function (category) {
    var exp = this.siteConfig && this.siteConfig.experience;
    var special = exp && exp.special || {};
    var list = special.nonBlockingCategories || exp && exp.nonBlockingCategories || [];
    return Array.isArray(list) && list.indexOf(category) !== -1;
  };

  function 示例资料RoleFromLabel(labelText) {
    var text = String(labelText || "").replace(/\s+/g, "");
    if (/父亲|父/.test(text)) return "father";
    if (/母亲|母/.test(text)) return "m示例资料";
    return null;
  }

  function findFamilyRecordByRole(data, role) {
    var list = Array.isArray(data) ? data : [];
    var rolePattern = role === "father" ? /父|father/i : /母|m示例资料/i;
    for (var i = 0; i < list.length; i++) {
      var relationship = String(list[i] && list[i].relationship || "");
      if (rolePattern.test(relationship)) return list[i];
    }
    if (role === "father") return list[0] || null;
    if (role === "m示例资料") return list[1] || null;
    return null;
  }

  // ============================================================
  // ExperienceHandler (源码行 11135-12060)
  // ============================================================
  function ExperienceHandler(elementMatcher, dataMatcher, siteConfig) {
    this.elementMatcher = elementMatcher;
    this.dataMatcher = dataMatcher;
    this.configAdapter = new ConfigAdapter(siteConfig);
    // Moka 的受控下拉在选中后会重建经历卡，给 React 状态提交和 DOM 替换留出时间。
    // Moka 控件只需留出很短的 React 重渲染窗口；过长的固定等待会让教育/经历
    // 字段逐个停顿。学校/专业字段另有提交复核，不依赖这里的长延时。
    this.operationDelay = siteConfig && siteConfig.name === "moka" ? 80 : 20;
    this.filledFieldsCount = 0;
    this.lastResult = null;
    // Patch113: cache active editor transaction scope so 示例资料 records can reuse
    // ownership discovered by RecordGraph instead of rediscovering DOM each time.
    this._activeEditorScope = null;
    this._activeRecordOwnership = null;
    // Patch115: ownership survives 示例资料-record DOM rerenders inside one 示例资料flow.
    this._recordOwnershipSession = {};
    // Build133: generic Structured RepeatRecord checkpoint runtime.
    this.recordCheckpointRuntime = null;
    this.shouldStop = function () { return false; };
  }

  function getRecordGraphOwnership(handler, container, category) {
    try {
      var graph = AF.RecordGraph;
      if (!graph || typeof graph.resolveOwnership !== "function" || !container) return null;
      var key = String(category || handler && handler._activeCategory || "unknown");
      // Patch115: keep a 示例资料-record ownership session during one fill run.
      // React pages may replace DOM nodes after the first record is saved.
      // Re-discovery from the fresh DOM can incorrectly return zero cards.
      if (handler) {
        handler._recordOwnershipSession = handler._recordOwnershipSession || {};
        if (handler._recordOwnershipSession[key] && handler._recordOwnershipSession[key].cards && handler._recordOwnershipSession[key].cards.length) {
          var cached = handler._recordOwnershipSession[key];
          cached.cards = cached.cards.filter(function (node) {
            return node && node.isConnected;
          });
          if (cached.cards.length) return cached;
        }
      }
      var owner = graph.resolveOwnership(container, key);
      if (!owner || Number(owner.confidence || 0) < 0.85) return null;
      if (handler) {
        handler._recordOwnershipSession = handler._recordOwnershipSession || {};
        handler._recordOwnershipSession[key] = owner;
      }
      return owner;
    } catch (_) { return null; }
  }

  function isMokaPage(handler) {
    return Boolean(
      handler && handler.configAdapter && handler.configAdapter.siteConfig && handler.configAdapter.siteConfig.name === "moka"
    ) || /(^|\.)mokahr\.com$/i.test(String(location.hostname || ""));
  }

  function buildExperienceRecordCheckpointMeta(category, title, index, total, row) {
    var fingerprint = AF.CheckpointCore && typeof AF.CheckpointCore.recordFingerprint === "function"
      ? AF.CheckpointCore.recordFingerprint(row || {}) : "";
    return {
      category: String(category || ""),
      sectionTitle: String(title || category || "经历"),
      示例资料Index: Number(index),
      示例资料Total: Number(total || 0),
      recordFingerprint: String(fingerprint || ""),
      row: row || {}
    };
  }

  ExperienceHandler.prototype.findPendingManualSaveButton = async function (container, card) {
    try {
      if (this.configAdapter.isAutoSaveAllowed() || this.configAdapter.usesInlinePersistence()) return null;
      var scopes = [card, this._activeEditorScope, container].filter(function (node, index, list) {
        return node && node.querySelectorAll && list.indexOf(node) === index;
      });
      for (var i = 0; i < scopes.length; i++) {
        var button = await this.findElementByPriority(
          scopes[i],
          this.configAdapter.getSaveButtonSelector(),
          this.configAdapter.getSaveButtonText()
        );
        if (button && (!AF.DomUtils || AF.DomUtils.isElementVisible(button)) && !button.disabled) return button;
      }
    } catch (e) {}
    return null;
  };

  // Moka 与北森 Phoenix 都可能把经历模块先渲染成“是否有经历”的门控
  // 占位卡。这里按平台控件特征识别，不按企业域名写死，供所有复用平台的
  // 企业页面使用；普通站点仍需显式配置 conditionalExperienceGateBeforeCards。
  function isPhoenixPage(handler) {
    var configName = handler && handler.configAdapter && handler.configAdapter.siteConfig &&
      String(handler.configAdapter.siteConfig.name || "").toLowerCase();
    if (configName === "beisen-phoenix" || configName.indexOf("phoenix") !== -1) return true;
    try {
      return Boolean(
        document.querySelector(".phoenix-select, .phoenix-radio, .phoenix-radio-group, .phoenix-checkbox")
      );
    } catch (e) {
      return false;
    }
  }

  // Phoenix 的模块标题位于经历内容区之外。AI 常把字段内层 `.form-part`
  // 识别成通用 container；经历流程若从该节点开始，就再也找不到外层卡片和
  // “添加经历”入口。优先采用配置选择器命中的标题祖先，否则按 Phoenix
  // 控件和单模块标题的结构向上恢复完整模块，不依赖企业域名。
  function findPhoenixSectionContainer(handler, sectionEl, preferredSelector) {
    if (!sectionEl || !isPhoenixPage(handler)) return null;
    try {
      if (preferredSelector && sectionEl.closest) {
        var configuredAncestor = sectionEl.closest(preferredSelector);
        if (configuredAncestor) return configuredAncestor;
      }
    } catch (e) {}

    var titles = [];
    try {
      titles = Array.from(handler.elementMatcher.findTitle() || []);
    } catch (e2) {}
    var current = sectionEl.parentElement;
    var depth = 0;
    while (current && depth < 8) {
      var containsPhoenixForm = Boolean(current.querySelector && current.querySelector(
        ".form-item__text, .phoenix-select, .phoenix-radio-group, .ux-standard-form, [id$='_addButton']"
      ));
      if (containsPhoenixForm) {
        var containedTitles = titles.filter(function (title) {
          return title && current.contains(title);
        }).length;
        if (containedTitles === 1 || (titles.length === 0 && depth <= 2)) return current;
      }
      current = current.parentElement;
      depth++;
    }
    return null;
  }

  function supportsConditionalExperienceGates(handler) {
    return isMokaPage(handler) || isPhoenixPage(handler);
  }

  // Phoenix 的 radio 不是原生 input，而是 React 组件的 div。经历卡新增后，
  // 只有点中这一项“是”才会把真实字段挂载到下一段 form-part；因此这里不把
  // 通用 radio 的失败结果静默吞掉，而是就近在当前标签的 form-item 内点击并
  // 以 --checked 类做确认。这个分支只处理已经按“是否有xx经历”识别出的门控题。
  async function selectPhoenixConditionalGate(gateLabel, expected) {
    try {
      if (!gateLabel || !/^(是|否)$/.test(String(expected || ""))) return false;
      // 不能写成 `.form-item, [class*='form-item']`：Phoenix 的 label 外层
      // `.form-item__title` 也会先命中，却不包含 radio 组。必须落到整行字段。
      var field = gateLabel.closest && gateLabel.closest(".form-item");
      var group = field && field.querySelector && field.querySelector(".phoenix-radio-group");
      if (!group) return false;
      var options = Array.from(group.querySelectorAll(".phoenix-radio"));
      var target = options.find(function (option) {
        var text = String((option.querySelector(".phoenix-radio__radio-text") || option).textContent || "").replace(/\s+/g, "");
        return text === expected;
      });
      if (!target) return false;
      if (target.classList.contains("phoenix-radio--checked")) return true;

      // 先点组件真正绑定 click 的 wrapper；部分 Phoenix 租户把监听器放在
      // 外层 radio 上，因此再以外层 click 兜底，并在每一步后复核状态。
      var targets = [target.querySelector(".phoenix-radio__wrapper"), target].filter(Boolean);
      for (var i = 0; i < targets.length; i++) {
        await AF.DomUtils.safeClickElement(targets[i]);
        try { targets[i].click(); } catch (e) {}
        await AF.Utils.sleep(120);
        if (target.classList.contains("phoenix-radio--checked")) return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  async function ensurePhoenixCardGate(card) {
    if (!card || !card.querySelector) return true;
    try {
      var gateLabels = Array.from(card.querySelectorAll(".form-item__text, label")).filter(function (label) {
        var text = String(label.textContent || "").replace(/\s+/g, "");
        return /^(是否|有无|有没有).{0,18}(经历|经验|实践)/.test(text) && /实习|工作|项目|科研|活动|竞赛|论文|专利|发明|培训/.test(text);
      });
      if (!gateLabels.length) return true;
      for (var i = 0; i < gateLabels.length; i++) {
        var field = gateLabels[i].closest && gateLabels[i].closest(".form-item");
        var group = field && field.querySelector && field.querySelector(".phoenix-radio-group");
        if (!group) continue;
        var yes = Array.from(group.querySelectorAll(".phoenix-radio")).find(function (node) {
          return String((node.querySelector(".phoenix-radio__radio-text") || node).textContent || "").replace(/\s+/g, "") === "是";
        });
        if (!yes || yes.classList.contains("phoenix-radio--checked")) continue;
        if (!await selectPhoenixConditionalGate(gateLabels[i], "是")) return false;
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  // Phoenix 的“论文/专著（或论文/专利）”是类型门控，不是“是否”题。
  // 选中类型后才会渲染该卡片的明细字段；仅靠普通字段匹配会拿到空卡片。
  async function ensurePhoenixPublicationType(card, category) {
    if (!card || category !== "publications" && category !== "示例资料s") return true;
    try {
      var groups = Array.from(card.querySelectorAll(".phoenix-radio-group"));
      for (var i = 0; i < groups.length; i++) {
        var options = Array.from(groups[i].querySelectorAll(".phoenix-radio"));
        var texts = options.map(function (node) {
          return String((node.querySelector(".phoenix-radio__radio-text") || node).textContent || "").replace(/\s+/g, "");
        });
        if (!texts.some(function (text) { return /论文|专著|专利/.test(text); })) continue;
        var expected = category === "示例资料s" ? "专利" : "论文";
        var target = options.find(function (node) {
          var text = String((node.querySelector(".phoenix-radio__radio-text") || node).textContent || "").replace(/\s+/g, "");
          return text === expected || (expected === "论文" && text === "专著");
        });
        if (!target || target.classList.contains("phoenix-radio--checked")) return true;
        var clickTargets = [target.querySelector(".phoenix-radio__wrapper"), target].filter(Boolean);
        for (var j = 0; j < clickTargets.length; j++) {
          await AF.DomUtils.safeClickElement(clickTargets[j]);
          try { clickTargets[j].click(); } catch (e) {}
          await AF.Utils.sleep(120);
          if (target.classList.contains("phoenix-radio--checked")) return true;
        }
        return false;
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  function isChinaTelecomHotjobPage() {
    return /(^|\.)job\.chinatelecom\.com\.cn$/i.test(String(location.hostname || ""));
  }

  function resolveHighestEducationValue(fieldKey, value, rowData) {
    if (!/^(ccbHighestEducation|isHighestEducation)$/.test(String(fieldKey || ""))) return value;
    if (value == null) value = rowData && rowData.isHighestEducation;
    if (value == null) value = rowData && rowData.ccbHighestEducation;
    if (value === true) return "是";
    if (value === false) return "否";
    var text = String(value == null ? "" : value).trim();
    if (/^(是|true|yes|y|1)$/i.test(text)) return "是";
    if (/^(否|false|no|n|0)$/i.test(text)) return "否";
    return value;
  }

  function filterExperienceRecords(handler, category, data) {
    if (!Array.isArray(data)) return data;
    var siteConfig = handler && handler.configAdapter && handler.configAdapter.siteConfig || {};
    var special = siteConfig.experience && siteConfig.experience.special || {};
    var filters = special.recordFilters && special.recordFilters[category];
    var excluded = filters && filters.excludeLevels;
    if (category !== "示例资料" || !Array.isArray(excluded) || !excluded.length) return data;
    var normalizedExcluded = excluded.map(function (level) {
      return String(level || "").toLowerCase().replace(/[\s/、及以下]/g, "");
    }).filter(Boolean);
    return data.filter(function (row) {
      var level = String(row && (row.level || row.示例资料Level || row.示例资料) || "")
        .toLowerCase()
        .replace(/[\s/、及以下]/g, "");
      if (!level) return true;
      return !normalizedExcluded.some(function (excludedLevel) {
        return level === excludedLevel || level.indexOf(excludedLevel) !== -1 || excludedLevel.indexOf(level) !== -1;
      });
    });
  }

  function experienceValueMatches(expected, actual) {
    var normalize = function (value) {
      return String(value == null ? "" : value).toLowerCase().replace(/[\s：:()（）\-_/]/g, "");
    };
    var wanted = normalize(expected);
    var current = normalize(actual);
    if (!wanted || !current) return false;
    return wanted === current || current.indexOf(wanted) !== -1 || wanted.indexOf(current) !== -1;
  }

  function conditionalExperienceGatePattern(category) {
    var patterns = {
      示例资料Experience: /(?:是否|有无|有没有).{0,12}(?:项目|课题|科研).{0,8}(?:经历|经验|实践)?/,
      示例资料Experience: /(?:是否|有无|有没有).{0,12}(?:实习|实践).{0,8}(?:经历|经验)?/,
      示例资料Experience: /(?:是否|有无|有没有).{0,12}(?:工作|任职|全职).{0,8}(?:经历|经验)?/,
      示例资料Experience: /(?:是否|有无|有没有).{0,12}培训.{0,8}(?:经历|经验)?/,
      campusActivities: /(?:是否|有无|有没有).{0,12}(?:校园|校内|学生).{0,8}(?:活动|经历|经验|实践)/,
      示例资料: /(?:是否|有无|有没有).{0,12}(?:奖学金|获奖|荣誉|竞赛)/,
      publications: /(?:是否|有无|有没有).{0,12}(?:核心期刊|论文|发表)/,
      示例资料s: /(?:是否|有无|有没有).{0,12}(?:专利|发明)/,
      示例资料: /(?:是否|有无|有没有).{0,12}(?:证书|资质|资格|认证)/,
      示例资料Skills: /(?:是否|有无|有没有).{0,12}(?:语言|外语|英语|四六级|CET)/i,
      campusLeadership: /(?:是否|有无|有没有).{0,12}(?:学生工作|校内任职|校园经历|社团职务)/,
    };
    return patterns[category] || null;
  }

  function matchesConfiguredConditionalGate(category, labelText, gateSpecial) {
    var configured = gateSpecial && gateSpecial.conditionalGateLabels;
    var labels = configured && configured[category];
    if (!Array.isArray(labels) || !labels.length) return false;
    var current = String(labelText || "").replace(/\s+/g, "");
    return labels.some(function (item) {
      var expected = String(item || "").replace(/\s+/g, "");
      return expected && (current === expected || current.indexOf(expected) !== -1);
    });
  }

  // Moka 的租户可以自由改写门控问题。模块类别已经由标题/站点配置确定时，
  // 对“只有一个待回答字段”的占位卡，允许使用通用是否题兜底，例如
  // “是否具备相关经验”。限制标签数量是为了避免在已经展开的完整表单里
  // 把“是否保密”等普通问题误判成经历开关。
  function matchesCategoryScopedConditionalGate(category, labelText, gateSpecial, labelCount) {
    var pattern = conditionalExperienceGatePattern(category);
    var text = String(labelText || "").replace(/\s+/g, "");
    if (pattern && pattern.test(text)) return true;
    if (matchesConfiguredConditionalGate(category, text, gateSpecial)) return true;
    if (Number(labelCount || 0) > 2) return false;
    if (!/(?:是否|有无|有没有)/.test(text)) return false;
    return /(?:经历|经验|实践|项目|实习|工作|任职|活动|奖学金|获奖|荣誉|竞赛|论文|期刊|专利|发明)/.test(text);
  }

  function rememberConditionalExperienceGate(handler, category, labelText) {
    if (!handler || !category || !labelText) return;
    if (!handler._conditionalExperienceGateLabels) handler._conditionalExperienceGateLabels = {};
    if (!handler._conditionalExperienceGateLabels[category]) handler._conditionalExperienceGateLabels[category] = {};
    handler._conditionalExperienceGateLabels[category][String(labelText).replace(/\s+/g, "")] = true;
  }

  function isRememberedConditionalExperienceGate(handler, category, labelText) {
    var labels = handler && handler._conditionalExperienceGateLabels && handler._conditionalExperienceGateLabels[category];
    return Boolean(labels && labels[String(labelText || "").replace(/\s+/g, "")]);
  }

  function isConditionalExperienceGateCard(handler, card, category, placeholderOnly) {
    if (!handler || !card || !category) return false;
    try {
      var gateSpecial = handler.configAdapter.siteConfig && handler.configAdapter.siteConfig.experience &&
        handler.configAdapter.siteConfig.experience.special || {};
      var labels = handler.filterValidLabels(handler.elementMatcher.findLabelsByCard(card));
      if (placeholderOnly && labels.length > 2) return false;
      return labels.some(function (label) {
        var text = String(AF.LabelUtils.getLabelText(label) || "").replace(/\s+/g, "");
        return matchesCategoryScopedConditionalGate(
          category,
          text,
          gateSpecial,
          placeholderOnly ? labels.length : Number.MAX_SAFE_INTEGER
        ) || isRememberedConditionalExperienceGate(handler, category, text);
      });
    } catch (e) {
      return false;
    }
  }

  function semanticKeysForCard(handler, card, category) {
    if (!handler || !card || !category) return [];
    try {
      var keys = [];
      var labels = handler.elementMatcher.findLabelsByCard(card) || [];
      Array.from(labels).forEach(function (label) {
        if (!AF.DomUtils.isElementVisible(label)) return;
        var text = AF.LabelUtils.getLabelText(label);
        var key = handler.dataMatcher.findFieldByCategory(category, text);
        if (key && keys.indexOf(key) === -1) keys.push(key);
      });
      return keys;
    } catch (e) {
      return [];
    }
  }

  function cardMatchesCategory(handler, card, category) {
    var keys = semanticKeysForCard(handler, card, category);
    if (!keys.length) return false;
    var identityRule = RECORD_IDENTITIES[category] || {};
    var primary = identityRule.primary || [];
    var hasPrimary = keys.some(function (key) { return primary.indexOf(key) !== -1; });
    var specificCount = keys.filter(function (key) {
      return !/^(startTime|endTime|duration|city|description|details)$/.test(String(key));
    }).length;
    return hasPrimary || specificCount >= 2;
  }

  function cardBindingToken() {
    return "af-exp-card-" + Date.now() + "-" + Math.random().toString(36).slice(2);
  }

  // ---------- fillExperienceByNewScheme (源码行11146-11319, 总入口) ----------
  ExperienceHandler.prototype.fillExperienceByNewScheme = async function (sectionEl, title, options) {
    options = options || {};
    try {
      if (this.shouldStop && this.shouldStop()) return true;
      if (!this.configAdapter.supportsNewExperienceScheme()) return false;
      this.configAdapter.debugConfig();
      if (!this.configAdapter.validateConfig().valid) return false;

      var container = await this.locateContainer(sectionEl);
      if (!container) return false;

      // 动态组合模块可以传入本次要处理的记录；普通站点仍走原数据读取逻辑。
      var categoryInfo;
      if (Array.isArray(options.dataOverride)) {
        categoryInfo = {
          category: options.categoryOverride || options.specificCategory,
          type: "array",
          data: options.dataOverride.slice(),
        };
      } else if (options.specificCategory) {
        var raw = this.dataMatcher.resumeData[options.specificCategory];
        if (!raw) return false;
        var t = Array.isArray(raw) ? "array" : "object";
        categoryInfo = {
          category: options.specificCategory,
          type: t,
          data: t === "array" ? raw.slice() : Object.assign({}, raw),
        };
      } else {
        categoryInfo = this.dataMatcher.getCategoryByTitle(title, options);
        if (!categoryInfo) return false;
      }

      var data = filterExperienceRecords(this, categoryInfo.category, categoryInfo.data);
      var category = categoryInfo.category;
      this._activeCategory = category;
      var count = data.length;
      if (count === 0) {
        var emptySpecial = this.configAdapter.siteConfig && this.configAdapter.siteConfig.experience &&
          this.configAdapter.siteConfig.experience.special || {};
        if (emptySpecial.answerEmptyConditionalGates) {
          await this.ensureConditionalExperienceGate(container, title, category, "否");
        }
        return true; // 没数据, 视为成功 (源码行11185)
      }
      var filledRows = 0;
      var filledIndexes = [];
      var nonBlockingCategory = this.configAdapter.isNonBlockingCategory(category);

      // “没有工作/示例资料”属于页面状态，不是简历字段。简历数组有数据时先关闭
      // 反向开关，等待当前分区重新渲染出添加入口或卡片，再开始计算卡片数。
      container = await this.ensureExperienceEnabled(container, title);
      if (!container) {
        this.lastResult = { requestedRows: count, filledRows: 0, filledIndexes: [], mode: "experience_config", error: "experience_disabled" };
        return false;
      }

      container = await this.ensureConditionalExperienceGate(container, title, category, "是");
      if (!container) {
        this.lastResult = { requestedRows: count, filledRows: 0, filledIndexes: [], mode: "experience_config", error: "conditional_gate_failed" };
        return false;
      }

      await this.ensureContainerEditMode(container);
      var existingCount = this.getExistingCardCount(container);

      // 有些 AntD 招聘站（例如 Honor 这类结构）会把同一个 `.form-cell`
      // 同时当成模块容器和“卡片”选择器。多条经历实际是平铺在这个容器里的
      // 重复 label 组，而不是多张可 querySelectorAll 出来的子卡片。新版方案
      // 按卡片循环会误以为没有卡，先报“加卡失败”；这里安静降级给旧版
      // label 分组方案处理，它正适合这种结构。
      if (this.shouldDeferFlatMultiRowContainer(container, count)) {
        this.lastResult = {
          requestedRows: count,
          filledRows: 0,
          filledIndexes: [],
          mode: "experience_config_deferred",
          error: "flat_multi_row_container"
        };
        return false;
      }

      // 单卡片模式分支 (源码行11228-11235)
      if (this.configAdapter.isSingleCardMode()) {
        return await this.handleSingleCardMode(container, data, category, existingCount);
      }

      if (category === "示例资料Members") {
        var compositeCard = await this.locateCompositeFamilyCard(container);
        if (compositeCard) {
          await this.ensureCardEditMode(compositeCard);
          var filledBeforeComposite = this.filledFieldsCount;
          var 示例资料ForComposite = this;
          await this.fillCompositeFamilyCard(compositeCard, data, category, function () {
            return 示例资料ForComposite.locateCompositeFamilyCard(container) || compositeCard;
          });
          this.lastResult = {
            requestedRows: count,
            filledRows: this.filledFieldsCount > filledBeforeComposite ? 1 : 0,
            filledIndexes: [0],
            mode: "示例资料_composite_card"
          };
          return true;
        }
      }

      // 常规多卡片循环 (源码行11236-11302 的内联生成器 p(d))
      // 生成器返回 0 表示"加卡失败/定位卡片失败" → 外层 break; 正常完成 → continue。
      for (var index = 0; index < count; index++) {
        if (this.shouldStop && this.shouldStop()) break;
        var recordCategory = data[index] && data[index].__afCategory || category;
        var recordCheckpointMeta = buildExperienceRecordCheckpointMeta(recordCategory, title, index, count, data[index]);
        if (this.recordCheckpointRuntime && this.recordCheckpointRuntime.enabled &&
            typeof this.recordCheckpointRuntime.shouldSkip === "function" &&
            this.recordCheckpointRuntime.shouldSkip(recordCheckpointMeta)) {
          filledRows++;
          filledIndexes.push(index);
          if (AF.FillTrace) AF.FillTrace.event("record_checkpoint_skip", title + " 第" + (index + 1) + "条：用户已手动处理", "skipped");
          continue;
        }
        if (index >= existingCount) {
          var added = await this.addNewCard(container, index, title);
          if (!added) {
            if (this.configAdapter.requiresSaveBeforeNext() && index > 0 && AF.FillTrace) {
              AF.FillTrace.event("manual_save_required", title + " 第" + (index + 1) + "条", "waiting_for_user");
            }
            this.lastResult = {
              requestedRows: count,
              filledRows: filledRows,
              filledIndexes: filledIndexes,
              mode: "experience_config",
              error: "add_card_failed",
              failedIndex: index
            };
            if (AF.FillTrace) AF.FillTrace.event("experience_rows", title + " " + filledRows + "/" + count + "，第" + (index + 1) + "条加卡失败", "failed");
            if (nonBlockingCategory) {
              if (AF.FillTrace) AF.FillTrace.event("experience_rows", title + " 加卡失败，已跳过并继续后续模块", "skipped");
              return true;
            }
            return false;
          }
          container = this.locateContainerByTitle(title) || container;
          existingCount = Math.max(existingCount, this.getExistingCardCount(container));
        }
        var rowCategory = recordCategory;
        var card = await this.locateAndPrepareCardForRow(container, index, data[index], rowCategory);
        if (!card) {
          if (this.configAdapter.requiresSaveBeforeNext() && index > 0 && AF.FillTrace) {
            AF.FillTrace.event("manual_save_required", title + " 第" + (index + 1) + "条", "waiting_for_user");
          }
          this.lastResult = {
            requestedRows: count,
            filledRows: filledRows,
            filledIndexes: filledIndexes,
            mode: "experience_config",
            error: "locate_card_failed",
            failedIndex: index
          };
          if (AF.FillTrace) AF.FillTrace.event("experience_rows", title + " " + filledRows + "/" + count + "，第" + (index + 1) + "条卡片定位失败", "failed");
          if (nonBlockingCategory) {
            if (AF.FillTrace) AF.FillTrace.event("experience_rows", title + " 卡片定位失败，已跳过并继续后续模块", "skipped");
            return true;
          }
          return false;
        }

        var 示例资料 = this;
        var cardBinding = this.captureCardBinding(card, index, data[index], rowCategory);
        var filledBeforeRow = this.filledFieldsCount;
        await this.fillSingleCard(card, data[index], rowCategory, function () {
          // Moka 选择学校/专业/学历后可能连整个 apply-block 都替换掉。
          // 每个字段前都按标题重新取得当前容器，不能继续在 detached 容器里找卡片。
          var latestContainer = 示例资料.locateContainerByTitle(title);
          if (latestContainer && latestContainer.isConnected) container = latestContainer;
          return 示例资料.resolveBoundCard(container, cardBinding);
        });
        if (this.filledFieldsCount > filledBeforeRow) {
          filledRows++;
          filledIndexes.push(index);
        }

        var shouldSaveCurrentRow = this.configAdapter.requiresSaveBeforeNext() && (
          index < count - 1 ||
          /^applyjob\.chinahr\.com$/i.test(location.hostname || "") ||
          /^campus-talent\.alibaba\.com$/i.test(location.hostname || "")
        );
        var recordConfirmed = false;
        if (shouldSaveCurrentRow) {
          var currentCard = this.resolveBoundCard(container, cardBinding);
          // 多卡片页面重渲染后若无法确认原卡身份，绝不拿旧节点或同索引卡片
          // 代替保存；否则可能把下一条经历的编辑态误当成当前记录。
          if (!currentCard) {
            if (AF.FillTrace) AF.FillTrace.event("experience_card_binding", title + " 第" + (index + 1) + "条保存前身份丢失", "failed");
            return false;
          }
          var savedCurrentRow = await this.saveCurrentCard(container, currentCard);
          this.clearActiveEditorScope();
          if (!savedCurrentRow) return false;
          recordConfirmed = true;
          existingCount = this.getExistingCardCount(container);
        } else if (this.filledFieldsCount > filledBeforeRow) {
          var pendingCard = this.resolveBoundCard(container, cardBinding) || card;
          var pendingManualSave = await this.findPendingManualSaveButton(container, pendingCard);
          if (pendingManualSave && this.recordCheckpointRuntime && typeof this.recordCheckpointRuntime.pause === "function") {
            await this.recordCheckpointRuntime.pause(recordCheckpointMeta, "当前经历已填写，仍需手动保存");
            this.lastResult = {
              requestedRows: count,
              filledRows: filledRows,
              filledIndexes: filledIndexes,
              mode: "experience_config",
              manualSavePending: true,
              failedIndex: index
            };
            if (AF.FillTrace) AF.FillTrace.event("record_checkpoint_pause", title + " 第" + (index + 1) + "条待手动保存", "waiting_for_user");
            return false;
          }
          // No owned save action remains visible: treat this record as committed
          // by the page's inline/automatic persistence semantics.
          recordConfirmed = !pendingManualSave;
        }
        if (recordConfirmed && this.recordCheckpointRuntime && typeof this.recordCheckpointRuntime.markCompleted === "function") {
          await this.recordCheckpointRuntime.markCompleted(recordCheckpointMeta);
        }
      }
      this.lastResult = {
        requestedRows: count,
        filledRows: filledRows,
        filledIndexes: filledIndexes,
        mode: "experience_config"
      };
      if (AF.FillTrace) AF.FillTrace.event(
        "experience_rows",
        title + " " + filledRows + "/" + count,
        filledRows >= count ? "completed" : "partial"
      );
      // 新方案只有完整覆盖全部请求记录才算成功。部分完成必须返回 false，允许
      // FormHandler 自动回退到旧的动态加卡方案继续补齐，而不是静默吞掉后续记录。
      if (nonBlockingCategory) return true;
      return filledRows >= count;
    } catch (e) {
      this.lastResult = { requestedRows: 0, filledRows: 0, mode: "experience_config", error: String(e) };
      return false;
    }
  };

  // ---------- locateContainer (源码行11324-11352) ----------
  ExperienceHandler.prototype.locateContainer = async function (sectionEl) {
    // 中国电信所有模块共用 `.edit-resume-div` 外层，远程配置中的通用
    // cardSelector 会同时选中个人信息、教育、项目等全部 subGroup，导致教育
    // 第 1 条实际落到个人信息卡、第 2 条落到教育第 1 卡，整组错位一位。
    // 从当前模块标题所在的首张卡提取 subGroup 前缀，后续只处理同模块卡片。
    if (isChinaTelecomHotjobPage() && sectionEl && sectionEl.closest) {
      var hotjobSectionCard = sectionEl.closest("[id^='subGroup_']");
      var hotjobSectionId = String(hotjobSectionCard && hotjobSectionCard.id || "");
      var hotjobPrefixMatch = hotjobSectionId.match(/^(subGroup_\d+_)\d+$/);
      this._hotjobCardPrefix = hotjobPrefixMatch ? hotjobPrefixMatch[1] : "";
    }
    var selector = this.configAdapter.getContainerSelector();
    var phoenixContainer = findPhoenixSectionContainer(this, sectionEl, selector);
    if (phoenixContainer) return phoenixContainer;
    var container = this.elementMatcher.findContainerByTitle(sectionEl);
    if (container && selector) {
      if (!container.matches(selector)) {
        var nested = container.querySelector(selector);
        if (nested) container = nested;
      }
    }
    // 标题已定位到具体分区时不能退回页面第一个匹配容器，否则空分区会串写到示例资料。
    if (!container && selector) container = document.querySelector(selector);
    return container || null;
  };

  ExperienceHandler.prototype.locateContainerByTitle = function (title) {
    try {
      var normalized = String(title || "").replace(/\s+/g, "").trim();
      var titles = this.elementMatcher.findTitle() || [];
      for (var i = 0; i < titles.length; i++) {
        var text = String(titles[i].textContent || "").replace(/\s+/g, "").trim();
        if (text === normalized) {
          return findPhoenixSectionContainer(this, titles[i], this.configAdapter.getContainerSelector()) ||
            this.elementMatcher.findContainerByTitle(titles[i]);
        }
      }
    } catch (e) {}
    return null;
  };

  ExperienceHandler.prototype.ensureExperienceEnabled = async function (container, title) {
    try {
      var toggle = AF.DomUtils.findExperienceToggle(container);
      if (!toggle || !toggle.element) return container;
      var input = toggle.element;
      var isChecked = Boolean(input.checked || input.getAttribute && input.getAttribute("aria-checked") === "true");
      var shouldClick = toggle.type === "checkbox" ? isChecked : !isChecked;
      if (!shouldClick) return container;

      if (toggle.type === "radio" && AF.FormHandler && AF.FormHandler.fillFormElement) {
        await AF.FormHandler.fillFormElement(input, "是", "radio");
      } else {
        await AF.DomUtils.safeClickElement(input);
      }
      if (AF.FillTrace) AF.FillTrace.event("enable_experience", title, "clicked");

      var timeoutAt = Date.now() + 2500;
      while (Date.now() < timeoutAt) {
        if (this.shouldStop && this.shouldStop()) return false;
        await AF.Utils.sleep(100);
        var latest = this.locateContainerByTitle(title) || container;
        var latestToggle = AF.DomUtils.findExperienceToggle(latest);
        var latestInput = latestToggle && latestToggle.element;
        var stillChecked = Boolean(latestInput && (
          latestInput.checked || latestInput.getAttribute && latestInput.getAttribute("aria-checked") === "true"
        ));
        var hasCard = this.getExistingCardCount(latest) > 0;
        var hasAdd = await this.findElementByPriority(
          latest,
          this.configAdapter.getAddButtonSelector(),
          this.configAdapter.getAddButtonText()
        );
        if ((!latestToggle || !stillChecked) && (hasCard || hasAdd)) return latest;
      }
      return null;
    } catch (e) {
      return null;
    }
  };

  // Moka 等平台存在两种经历入口：有些页面直接渲染卡片，有些页面要先回答
  // “是否有 XX 经历”，之后才挂载卡片或启用“添加”。前置问题可能是
  // Select、Radio 或普通控件，必须按 ElementMatcher 识别出的真实类型填写。
  ExperienceHandler.prototype.ensureConditionalExperienceGate = async function (container, title, category, desiredValue) {
    try {
      if (!container) return null;
      var gateSpecial = this.configAdapter.siteConfig && this.configAdapter.siteConfig.experience &&
        this.configAdapter.siteConfig.experience.special || {};
      if (!supportsConditionalExperienceGates(this) && !gateSpecial.conditionalExperienceGateBeforeCards) return container;
      // 已存在卡片（包括只有“是否有经历”的占位卡）时，交给 fillSingleCard 内原有的
      // ensureConditionalExperienceExpanded 处理。这里若再次选择并等待，会让同一个
      // Moka 下拉执行两遍并额外等待最多 3 秒。
      if (this.getExistingCardCount(container) > 0) return container;
      var pattern = conditionalExperienceGatePattern(category);
      if (!pattern) return container;
      var labels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(container));
      var gateLabel = labels.find(function (label) {
        var text = String(AF.LabelUtils.getLabelText(label) || "").replace(/\s+/g, "");
        return matchesCategoryScopedConditionalGate(category, text, gateSpecial, labels.length);
      });
      if (!gateLabel) return container;
      rememberConditionalExperienceGate(this, category, AF.LabelUtils.getLabelText(gateLabel));

      var found = this.elementMatcher.findElementAndTypeByLabel(gateLabel);
      var gateElement = found && found.element;
      if (!gateElement || !container.contains(gateElement)) return container;
      if (gateElement.matches && gateElement.matches('input[type="file"]')) return container;
      if (gateElement.closest && gateElement.closest('[class*="upload" i], [class*="attachment" i]')) return container;

      var expected = String(desiredValue || "是");
      var current = "";
      if (AF.FillTrace && AF.FillTrace.readElementValue) current = AF.FillTrace.readElementValue(gateElement);
      if (!current && "value" in gateElement) current = gateElement.value;
      current = String(current || "").replace(/\s+/g, "");
      if (current === expected) return container;

      var beforeCards = this.getExistingCardCount(container);
      var beforeControls = container.querySelectorAll("input, textarea, select, [role='combobox']").length;
      var opened = await AF.FormHandler.fillFormElement(gateElement, expected, found.type || "select");
      if (!opened) return null;
      if (AF.FillTrace) AF.FillTrace.event("conditional_experience_gate", title + " → " + expected, "success");

      var latest = container;
      var timeoutAt = Date.now() + 3000;
      while (Date.now() < timeoutAt) {
        if (this.shouldStop && this.shouldStop()) return null;
        await AF.Utils.sleep(100);
        latest = this.locateContainerByTitle(title) || latest;
        if (!latest) continue;
        if (expected === "否") return latest;
        var latestCards = this.getExistingCardCount(latest);
        var latestControls = latest.querySelectorAll("input, textarea, select, [role='combobox']").length;
        if (latestCards > beforeCards || latestControls > beforeControls) return latest;
      }
      // 有些 Moka 模块选择“是”后只会解锁已经存在的添加按钮，DOM 数量不变。
      // 返回当前模块，让后续受安全闸门保护的 add 流程继续处理。
      return latest;
    } catch (e) {
      return null;
    }
  };

  // ---------- ensureContainerEditMode (源码行11355-11401) ----------
  ExperienceHandler.prototype.ensureContainerEditMode = async function (container) {
    var guard = this.configAdapter.getEditModeGuardSelector();
    if (this.isInEditMode(container, guard)) return true;
    var btn = await this.findElementByPriority(
      container,
      this.configAdapter.getContainerEditButtonSelector(),
      this.configAdapter.getContainerEditButtonText()
    );
    if (!btn) return false;
    try {
      await AF.DomUtils.safeClickElement(btn);
      await AF.Utils.sleep(this.configAdapter.getEditTimeoutMs());
      return this.isInEditMode(container, guard);
    } catch (e) {
      return false;
    }
  };

  // ---------- getExistingCardCount (源码行11403-11410) ----------
  ExperienceHandler.prototype.getCardElements = function (container) {
    var sel = this.configAdapter.getCardSelector();
    if (!container || !sel) return [];
    var recordGraphOwner = getRecordGraphOwnership(this, container, this._activeCategory);
    if (recordGraphOwner && Number(recordGraphOwner.confidence || 0) >= 0.99 && recordGraphOwner.cards && recordGraphOwner.cards.length && isPhoenixPage(this)) {
      if (AF.FillTrace) AF.FillTrace.event("record_graph_owner", "cards=" + recordGraphOwner.cards.length + " category=" + String(this._activeCategory || ""), "matched");
      return recordGraphOwner.cards.slice();
    }

    // 北森 Phoenix 的 AI 配置偶尔会把整个 section 或首个 form 当作 card，
    // 于是第二条项目经历“已经有 1 张卡”后再也加不出来。该平台的每一张
    // 实际经历卡都有独立 `.sc-khQegj` 外壳，且只在当前模块内取，避免跨模块。
    if (isPhoenixPage(this)) {
      try {
        var phoenixCards = Array.from(container.querySelectorAll(".sc-khQegj")).filter(function (node) {
          return node.querySelector && node.querySelector(".form-item, .form-item__text");
        });
        if (phoenixCards.length) return phoenixCards;
        // `.ux-standard-form` 是北森表单组件的稳定语义外壳，可在 styled-components
        // 构建类变化时继续作为逐卡兜底。排除嵌套副本，避免一张卡重复计数。
        var standardCards = Array.from(container.querySelectorAll(".ux-standard-form")).filter(function (node) {
          return node.querySelector && node.querySelector(".form-item, .form-item__text") &&
            !(node.parentElement && node.parentElement.closest && node.parentElement.closest(".ux-standard-form"));
        });
        if (standardCards.length) return standardCards;
      } catch (e) {}
    }

    // Hotjob/Honor 这类 AntD 模板的外层 `.form-cell` 是模块容器；
    // 多条经历实际重复在内部 `.form-cell-inner` 上，例如:
    //   <div class="form-cell" id="14">
    //     <div class="form-cell-right">
    //       <div class="form-cell-inner">..._0...</div>
    //       <div class="form-cell-inner">..._1...</div>
    //     </div>
    //   </div>
    // 远程配置常把 cardSelector 也写成 `.form-cell`，若照选会把整个模块
    // 当成一张卡，导致第二条示例资料读写错位。这里优先把这些 inner 识别为卡片。
    try {
      if (container.matches && container.matches(sel)) {
        var innerCards = Array.from(container.querySelectorAll(".form-cell-right > .form-cell-inner, :scope > .form-cell-right > .form-cell-inner")).filter(function (node) {
          return node && node.querySelector && node.querySelector(".ant-form-item, label, input, textarea, .ant-select");
        });
        if (innerCards.length > 0) return innerCards;
      }
    } catch (e) {}

    var cards = Array.from(container.querySelectorAll(sel));
    try {
      if (container.matches && container.matches(sel) && cards.indexOf(container) === -1) {
        cards.unshift(container);
      }
    } catch (e) {}
    // ChinaHR 每个 .aply-form 默认带一个隐藏的 .aply-group 模板。
    // 模板不是用户已存在的经历，不能计入 existingCount，否则首条数据
    // 会直接写入模板，后续也不会点击“添加示例资料”。
    if (/^applyjob\.chinahr\.com$/i.test(String(location.hostname || ""))) {
      cards = cards.filter(function (card) {
        return AF.DomUtils.isElementVisible(card);
      });
    }
    if (isChinaTelecomHotjobPage() && this._hotjobCardPrefix) {
      var hotjobPrefix = this._hotjobCardPrefix;
      cards = cards.filter(function (card) {
        return String(card && card.id || "").indexOf(hotjobPrefix) === 0;
      });
    }
    if (this._activeCategory && cards.length > 1) {
      var compatibleCards = cards.filter(function (card) {
        // Moka 条件式经历的新卡刚创建时，通常只渲染一项
        // “是否有项目/实习/示例资料”。在选择“是”以前还没有项目名、
        // 公司名等身份字段，不能因为 cardMatchesCategory 暂时不成立就
        // 把这张卡过滤掉；否则新增后的卡片数仍被算成 1，后续记录全部
        // 停在第一张。保留当前类别的门控占位卡，随后由
        // ensureConditionalExperienceExpanded 选择“是”并等待真实字段挂载。
        return cardMatchesCategory(this, card, this._activeCategory) || (
          supportsConditionalExperienceGates(this) &&
          isConditionalExperienceGateCard(this, card, this._activeCategory, true)
        );
      }, this);
      // 只有确实识别出当前分类卡片时才收窄，识别不到则保持原配置行为。
      // 这样能拦住“大容器选中教育+工作+项目全部卡片”，又不破坏无 label 站点。
      if (compatibleCards.length) cards = compatibleCards;
    }
    try {
      if (/^campus-talent\.alibaba\.com$/i.test(location.hostname || "")) {
        var isEducationContainer = Boolean(
          (container.matches && container.matches("#示例资料Info")) ||
          (container.closest && container.closest("#示例资料Info")) ||
          (container.querySelector && container.querySelector("#示例资料Info"))
        );
        var isExperienceContainer = Boolean(
          (container.matches && container.matches("#experienceInfo")) ||
          (container.closest && container.closest("#experienceInfo")) ||
          (container.querySelector && container.querySelector("#experienceInfo"))
        );
        if (isEducationContainer) {
          cards = cards.filter(function (card) {
            var text = String(card.textContent || "");
            var controls = Array.from(card.querySelectorAll("label, input[name], input[id]")).map(function (node) {
              return [node.textContent, node.getAttribute("name"), node.getAttribute("id")].filter(Boolean).join(" ");
            }).join(" ");
            var haystack = text + " " + controls;
            return /学校全称|所在院系|GPA成绩|gpa成绩|topDegree|\.school|\.academy|\.gpaScore/i.test(haystack);
          });
        } else if (isExperienceContainer) {
          cards = cards.filter(function (card) {
            var text = String(card.textContent || "");
            var controls = Array.from(card.querySelectorAll("label, input[name], textarea[name]")).map(function (node) {
              return [node.textContent, node.getAttribute("name")].filter(Boolean).join(" ");
            }).join(" ");
            var haystack = text + " " + controls;
            return /公司或组织名称|职位或职责|工作描述|tfitem_\d+\.name|tfitem_\d+\.responsibility|tfitem_\d+\.description/i.test(haystack);
          });
        }
      }
    } catch (e) {}
    return cards;
  };

  ExperienceHandler.prototype.shouldDeferFlatMultiRowContainer = function (container, rowCount) {
    if (!container || rowCount <= 1) return false;
    var sel = this.configAdapter.getCardSelector();
    if (!sel) return false;
    try {
      if (container.matches && container.matches(sel) && container.querySelectorAll(".form-cell-right > .form-cell-inner").length >= rowCount) {
        return false;
      }
      return Boolean(container.matches && container.matches(sel) && container.querySelectorAll(sel).length === 0);
    } catch (e) {
      return false;
    }
  };

  ExperienceHandler.prototype.getExistingCardCount = function (container) {
    return this.getCardElements(container).length;
  };

  // ---------- resolveCardAtIndex (源码行11413-11417) ----------
  ExperienceHandler.prototype.resolveCardAtIndex = function (container, index) {
    return this.getCardElements(container)[index] || null;
  };

  ExperienceHandler.prototype.locateAndPrepareCardForRow = async function (container, index, rowData, category) {
    var cards = this.getCardElements(container);
    var rule = RECORD_IDENTITIES[category] || {};
    var anchor = normalizedRecordText(firstRecordValue(rowData, rule.primary || []));
    if (anchor) {
      var secondary = normalizedRecordText(firstRecordValue(rowData, rule.secondary || []));
      var matches = cards.filter(function (candidate) {
        return elementRecordText(candidate).indexOf(anchor) !== -1;
      });
      var identityResolution = null;
      try {
        if (AF.RecordGraph && typeof AF.RecordGraph.resolveIdentityCard === "function") {
          identityResolution = AF.RecordGraph.resolveIdentityCard(cards, anchor, secondary);
        }
      } catch (_) {}
      var identityCard = identityResolution && identityResolution.card || null;
      // RecordGraph ownership + identity is only a resolver, not an executor. When the
      // primary key appears on multiple cards, a unique secondary key (level/position/
      // start time etc.) must disambiguate it; 示例资料wise stop instead of falling back
      // to array order and risking cross-record writes.
      if (identityResolution && identityResolution.status === "ambiguous") {
        if (AF.FillTrace) AF.FillTrace.event("record_identity", String(category || "") + " primary=" + matches.length + " secondary=" + Number(identityResolution.secondaryMatches || 0), "ambiguous");
        return null;
      }
      if (identityCard || matches.length === 1) {
        var matchedCard = identityCard || matches[0];
        if (AF.FillTrace && identityResolution) AF.FillTrace.event("record_identity", String(category || "") + " " + identityResolution.status, "matched");
        try {
          matchedCard.scrollIntoView({ block: "center", behavior: "auto" });
          await AF.Utils.sleep(80);
        } catch (e) {}
        this.clearActiveEditorScope();
        var mokaInlineCard = isMokaPage(this) && this.configAdapter.usesInlinePersistence();
        if (!mokaInlineCard) {
          var adoptedEditor = this.adoptExistingEditorScope(container, matchedCard, rowData, category, index);
          if (!adoptedEditor) {
            await this.ensureCardEditMode(matchedCard);
            this.adoptExistingEditorScope(container, matchedCard, rowData, category, index);
          }
        }
        // Moka is an inline React-card platform.  Reusing an editor scope captured
        // before a searchable select rerender can bind later fields back to an示例资料
        // 示例资料 card.  Mature Moka execution keeps ownership on the bound card
        // and re-resolves that card before every field instead.
        if (matchedCard.isConnected) return matchedCard;
        // 点击“编辑”可能替换整张卡，重新按身份找一次；找不到就停止，
        // 不退回原 index 猜测另一张卡。
        var refreshedMatches = this.getCardElements(container).filter(function (candidate) {
          return elementRecordText(candidate).indexOf(anchor) !== -1;
        });
        return refreshedMatches.length === 1 ? refreshedMatches[0] : null;
      }
    }
    return await this.locateAndPrepareCard(container, index);
  };

  ExperienceHandler.prototype.captureCardBinding = function (card, index, rowData, category) {
    var token = cardBindingToken();
    try { if (card && card.setAttribute) card.setAttribute("data-af-experience-card", token); } catch (e) {}
    var rule = RECORD_IDENTITIES[category] || {};
    var anchorValue = firstRecordValue(rowData, rule.primary || []);
    return {
      token: token,
      index: index,
      category: category,
      anchorNormalized: normalizedRecordText(anchorValue),
      conditionalGatePlaceholder: supportsConditionalExperienceGates(this) &&
        isConditionalExperienceGateCard(this, card, category, true),
      id: String(card && card.id || ""),
      element: card || null
    };
  };

  ExperienceHandler.prototype.resolveBoundCard = function (container, binding) {
    if (!container || !binding) return null;
    var cards = this.getCardElements(container);
    if (binding.element && binding.element.isConnected && cards.indexOf(binding.element) !== -1) {
      return binding.element;
    }
    var byToken = cards.find(function (card) {
      return card && card.getAttribute && card.getAttribute("data-af-experience-card") === binding.token;
    });
    if (byToken) return byToken;
    if (binding.id) {
      var byId = cards.filter(function (card) { return String(card && card.id || "") === binding.id; });
      // Vue/React 招聘站经常复制整张经历模块并保留相同 id。重复 id 不能
      // 作为卡片身份，否则第二条示例资料重渲染后会被错误绑定回第一条。
      if (byId.length === 1) return byId[0];
    }
    // 受控组件重渲染后自定义 token/id 可能消失。只要学校、公司、项目名等
    // 主身份字段已经落入页面，就按该值重新锁定原卡，不能继续盲信旧索引。
    if (binding.anchorNormalized) {
      var byAnchor = cards.filter(function (card) {
        return elementRecordText(card).indexOf(binding.anchorNormalized) !== -1;
      });
      if (byAnchor.length === 1) return byAnchor[0];
    }
      // Moka/Phoenix 条件式多经历卡在选择“是”后会整卡重建，新增卡尚未写入项目名、
    // 公司名等身份字段，自定义 token 也会消失。只对“绑定时确认为单一门控
    // 占位卡”的记录，允许按原索引找回仍包含同类门控的卡；普通多卡片绝不
    // 放宽，避免把本科数据写进硕士或把第二段经历写回第一段。
    if (binding.conditionalGatePlaceholder && Number.isInteger(binding.index)) {
      var conditionalCandidate = cards[binding.index];
      if (conditionalCandidate && isConditionalExperienceGateCard(this, conditionalCandidate, binding.category, false)) {
        return conditionalCandidate;
      }
    }
    // 单卡页面没有串卡可能，可安全返回唯一卡片。多卡页面禁止仅凭旧 index
    // 猜测：新增、删除、排序或框架重渲染都可能改变 index，宁可漏填也不串写。
    return cards.length === 1 ? cards[0] : null;
  };

  // ---------- addNewCard (源码行11419-11466) ----------
  ExperienceHandler.prototype.addNewCard = async function (container, index, title) {
    var before = this.getExistingCardCount(container);
    if (before >= index + 1) return true; // 已有足够卡片
    var btn = null;
    var isChinaHr = /^applyjob\.chinahr\.com$/i.test(String(location.hostname || ""));
    var selector = this.configAdapter.getAddButtonSelector();
    var recordGraphOwner = getRecordGraphOwnership(this, container, this._activeCategory);
    if (recordGraphOwner && recordGraphOwner.addActions && recordGraphOwner.addActions.length === 1) {
      var graphAdd = recordGraphOwner.addActions[0];
      if (AF.DomUtils.isElementVisible(graphAdd) && AF.DomUtils.isSafeExperienceAddAction(graphAdd, container)) {
        btn = graphAdd;
        if (AF.FillTrace) AF.FillTrace.event("record_graph_owner", "unique add action category=" + String(this._activeCategory || ""), "matched");
      }
    }
    if (isChinaHr) {
      btn = Array.from(container.querySelectorAll(".aply-form-opt.add, .aply-form-empty")).find(function (node) {
        return AF.DomUtils.isElementVisible(node) &&
          (/添加\s*(示例资料|实习示例资料)/.test(String(node.textContent || "")) ||
           (node.matches && node.matches(".aply-form-opt.add") && String(node.textContent || "").replace(/\s+/g, "") === "添加"));
      }) || null;
      if (!btn && AF.FillTrace) AF.FillTrace.event("chinahr.add_lookup",
        String(title || "") + " 当前容器未找到可见新增入口", "failed");
    }
    if (!btn && selector) {
      var candidates = Array.from(container.querySelectorAll(selector)).filter(function (node) {
        return AF.DomUtils.isElementVisible(node) && AF.DomUtils.isSafeExperienceAddAction(node, container);
      });
      // 飞书经历模块同时有“悬浮添加”和每张卡片内的“添加”。优先使用模块级
      // 悬浮入口；否则使用最后一张卡片的入口，避免总点第一张导致框架不新增。
      btn = candidates.find(function (node) {
        return node.matches && node.matches(
          '[class^="apply-form-array-card-add-float-right"], [class*=" apply-form-array-card-add-float-right"]'
        );
      }) || candidates.filter(function (node) {
        return !(node.closest && node.closest(
          '[class^="apply-form-array-card__"], [class*=" apply-form-array-card__"]'
        ));
      })[0] || candidates[candidates.length - 1] || null;
    }
    // ChinaHR 的新增入口是当前 .aply-form 直属的 <p>，保存上一张卡后
    // 由页面把它从 .hide 切换为可见。固定模块内直接取，避免通用按钮安全闸门
    // 因文本节点/图标结构变化而漏掉第二条经历。
    if (!btn && isChinaHr) {
      btn = Array.from(container.querySelectorAll(".aply-form-empty, p")).find(function (node) {
        var text = String(node.textContent || "").replace(/\s+/g, "");
        return AF.DomUtils.isElementVisible(node) &&
          (/^添加(?:示例资料|实习示例资料)$/.test(text) || /添加/.test(text)) &&
          !/删除|投递|报名/.test(text);
      }) || null;
    }
    if (!btn) {
      btn = await this.findElementByPriority(
        container,
        null,
        this.configAdapter.getAddButtonText()
      );
    }
    // 文本兜底同样必须经过最终安全闸门。站点配置容器过大时，页面首个
    // “添加志愿”很容易被误认成教育/示例资料的新增按钮。
    if (btn && !AF.DomUtils.isSafeExperienceAddAction(btn, container) && !isChinaHr) btn = null;
    if (!btn) return false;
    try {
      if (AF.FillTrace) AF.FillTrace.event("add_card", title + " 第" + (index + 1) + "条", "started");
      await AF.DomUtils.safeClickElement(btn);
      var timeoutAt = Date.now() + Math.max(3000, this.configAdapter.getAddTimeoutMs());
      var firstClickAt = Date.now();
      var phoenixFallbackTried = false;
      while (Date.now() < timeoutAt) {
        await AF.Utils.sleep(100);
        var latest = title ? (this.locateContainerByTitle(title) || container) : container;
        if (this.getExistingCardCount(latest) > before || this.resolveCardAtIndex(latest, index)) {
          if (AF.FillTrace) AF.FillTrace.event("add_card", title + " 第" + (index + 1) + "条", "success");
          return true;
        }
        // AI 配置可能把 Phoenix 的图标内层 `.sc-jeraig` 当成按钮；首击无
        // 反应时，改为在同一模块内精确找“添加 + 当前模块标题”的真实外层。
        // 仅在首次点击 700ms 后执行一次，绝不跨模块、绝不点“添加志愿”。
        if (!phoenixFallbackTried && isPhoenixPage(this) && Date.now() - firstClickAt >= 700) {
          phoenixFallbackTried = true;
          var expectedText = ("添加" + String(title || "")).replace(/\s+/g, "");
          var phoenixAdd = Array.from(latest.querySelectorAll("[id$='_addButton'], .sc-iNGGcK, .sc-jeraig"))
            .find(function (node) {
              var text = String(node.textContent || "").replace(/\s+/g, "");
              return text === expectedText && AF.DomUtils.isElementVisible(node) && AF.DomUtils.isSafeExperienceAddAction(node, latest);
            });
          if (phoenixAdd) {
            await AF.Utils.sleep(600);
            await AF.DomUtils.safeClickElement(phoenixAdd);
            try { phoenixAdd.click(); } catch (e) {}
          }
        }
      }
      if (AF.FillTrace) AF.FillTrace.event("add_card", title + " 第" + (index + 1) + "条超时", "failed");
      return false;
    } catch (e) {
      if (AF.FillTrace) AF.FillTrace.event("add_card", String(e), "failed");
      return false;
    }
  };

  // ---------- Existing Editor Adoption (Build116) ----------
  // Reuse an editor that is already open instead of clicking Edit again.  The
  // default path only adopts an editor owned by the current record card.  A
  // container/global editor shell must be explicitly declared by mature/site
  // config; global adoption additionally requires an identity match (or a
  // single-record container), preventing cross-record writes.
  ExperienceHandler.prototype.resolveExistingEditorScope = function (container, card, rowData, category) {
    var guard = this.configAdapter.getEditModeGuardSelector();
    if (!guard || !card) return null;
    var 示例资料 = this;
    function visible(node) {
      if (!node) return false;
      try { return AF.DomUtils.isElementVisible(node); } catch (e) { return true; }
    }
    function usable(scope) {
      if (!scope || !scope.querySelectorAll || !visible(scope)) return false;
      try {
        var controls = Array.from(scope.querySelectorAll("input:not([type='hidden']):not([type='file']), textarea, select, [contenteditable='true'], [role='combobox'], [role='textbox']"));
        return controls.some(visible);
      } catch (e) { return false; }
    }
    // Inline/card-owned editors are always safe to adopt: ownership is already
    // established by locateAndPrepareCardForRow / RecordGraph identity.
    if (示例资料.isInEditMode(card, guard) && usable(card)) {
      return { scope: card, source: "card_guard", identityMatched: true };
    }

    var selector = 示例资料.configAdapter.getExistingEditorScopeSelector();
    if (!selector) return null;
    var candidates = [];
    function collect(scope, source) {
      if (!scope || !scope.querySelectorAll) return;
      try {
        if (scope.matches && scope.matches(selector) && usable(scope)) candidates.push({ scope: scope, source: source });
        Array.from(scope.querySelectorAll(selector)).forEach(function (node) {
          if (usable(node)) candidates.push({ scope: node, source: source });
        });
      } catch (e) {}
    }
    collect(card, "card_selector");
    if (container && container !== card) collect(container, "container_selector");
    if (示例资料.configAdapter.allowGlobalExistingEditorAdoption() && typeof document !== "undefined") collect(document, "global_selector");

    var unique = [];
    candidates.forEach(function (candidate) {
      if (!unique.some(function (item) { return item.scope === candidate.scope; })) unique.push(candidate);
    });
    if (!unique.length) return null;

    var rule = RECORD_IDENTITIES[category] || {};
    var primary = normalizedRecordText(firstRecordValue(rowData || {}, rule.primary || []));
    var secondary = normalizedRecordText(firstRecordValue(rowData || {}, rule.secondary || []));
    function identityMatches(scope) {
      if (!primary) return false;
      var haystack = elementRecordText(scope);
      if (haystack.indexOf(primary) === -1) return false;
      return !secondary || haystack.indexOf(secondary) !== -1;
    }
    var matched = unique.filter(function (candidate) { return identityMatches(candidate.scope); });
    if (matched.length === 1) {
      matched[0].identityMatched = true;
      return matched[0];
    }

    // If the current container has only one record, a single explicitly scoped
    // editor cannot belong to a sibling record.  Do not apply this relaxation to
    // global portals unless the config explicitly opted in above.
    var cardCount = 0;
    try { cardCount = 示例资料.getCardElements(container).length; } catch (eCount) {}
    var local = unique.filter(function (candidate) { return candidate.source !== "global_selector"; });
    if (cardCount <= 1 && local.length === 1) {
      local[0].identityMatched = false;
      return local[0];
    }
    return null;
  };

  ExperienceHandler.prototype.adoptExistingEditorScope = function (container, card, rowData, category, index) {
    var adopted = this.resolveExistingEditorScope(container, card, rowData, category);
    if (!adopted || !adopted.scope) return null;
    this._activeEditorScope = adopted.scope;
    this._activeRecordOwnership = {
      category: String(category || this._activeCategory || ""),
      index: Number.isInteger(index) ? index : -1,
      source: "existing_editor",
      acquisition: adopted.source || "existing_editor",
      identityMatched: adopted.identityMatched === true
    };
    if (AF.FillTrace) AF.FillTrace.event(
      "existing_editor_adoption",
      String(this._activeRecordOwnership.category || "") + " index=" + String(this._activeRecordOwnership.index) + " via=" + String(this._activeRecordOwnership.acquisition),
      "matched"
    );
    return adopted.scope;
  };

  ExperienceHandler.prototype.clearActiveEditorScope = function () {
    this._activeEditorScope = null;
    this._activeRecordOwnership = null;
  };

  // ---------- locateAndPrepareCard (源码行11469-11497) ----------
  ExperienceHandler.prototype.locateAndPrepareCard = async function (container, index) {
    var cards = this.getCardElements(container);
    if (index >= cards.length) return null;
    var card = cards[index];
    try {
      card.scrollIntoView({ block: "center", behavior: "auto" });
      await AF.Utils.sleep(80);
    } catch (e) {}
    this.clearActiveEditorScope();
    var mokaInlineCard = isMokaPage(this) && this.configAdapter.usesInlinePersistence();
    if (!mokaInlineCard) {
      var adopted = this.adoptExistingEditorScope(container, card, null, this._activeCategory, index);
      if (!adopted) {
        await this.ensureCardEditMode(card);
        // Capture the newly opened inline/configured editor for save-scope reuse.
        this.adoptExistingEditorScope(container, card, null, this._activeCategory, index);
      }
    }
    return card;
  };

  ExperienceHandler.prototype.locateCompositeFamilyCard = function (container) {
    try {
      var cards = this.getCardElements(container);
      if (!cards.length && container) cards = [container];
      for (var i = 0; i < cards.length; i++) {
        var labels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(cards[i]));
        var texts = labels.map(function (label) {
          return AF.LabelUtils.getLabelText(label);
        }).join(" ");
        if (/父亲姓名|父亲/.test(texts) && /母亲姓名|母亲/.test(texts)) return cards[i];
      }
      return null;
    } catch (e) {
      return null;
    }
  };

  // ---------- ensureCardEditMode (源码行11500-11546) ----------
  ExperienceHandler.prototype.ensureCardEditMode = async function (card) {
    var guard = this.configAdapter.getEditModeGuardSelector();
    if (this.isInEditMode(card, guard)) return true;
    var btn = await this.findElementByPriority(
      card,
      this.configAdapter.getCardEditButtonSelector(),
      this.configAdapter.getCardEditButtonText()
    );
    if (!btn) return false;
    try {
      await AF.DomUtils.safeClickElement(btn);
      await AF.Utils.sleep(this.configAdapter.getEditTimeoutMs());
      return this.isInEditMode(card, guard);
    } catch (e) {
      return false;
    }
  };

  // ---------- fillSingleCard (源码行11549-11667) ----------
  // resolveCardFn: 每次填字段前重新定位当前卡 (应对填写触发的 DOM 重渲染)。
  ExperienceHandler.prototype.fillSingleCard = async function (card, rowData, category, resolveCardFn) {
    try {
      var recordCard = card;
      var 示例资料Scope = this;
      function currentFillScope() {
        var mokaInlineCard = isMokaPage(示例资料Scope) && 示例资料Scope.configAdapter.usesInlinePersistence();
        if (mokaInlineCard) {
          // React may replace the whole card after school/major/degree selection.
          // The bound-card resolver is the owner; stale editor scopes are forbidden.
          return resolveCardFn ? (resolveCardFn() || recordCard) : recordCard;
        }
        if (示例资料Scope._activeEditorScope && 示例资料Scope._activeEditorScope.isConnected !== false) {
          try {
            if (AF.DomUtils.isElementVisible(示例资料Scope._activeEditorScope)) return 示例资料Scope._activeEditorScope;
          } catch (eVisible) { return 示例资料Scope._activeEditorScope; }
        }
        return resolveCardFn ? (resolveCardFn() || recordCard) : recordCard;
      }
      card = currentFillScope() || card;
      if (isPhoenixPage(this) && !await ensurePhoenixPublicationType(card, category)) return false;
      if (isPhoenixPage(this) && !await ensurePhoenixCardGate(card)) return false;
      // 北森 Phoenix 某些经历卡片先显示“开始添加”选择器，选中后才挂载真实字段。
      // 新企业站按控件语义触发；人保旧页面保留原有域名兼容，避免破坏已验证流程。
      var phoenixSelects = Array.from(card.querySelectorAll(".phoenix-select"));
      var phoenixSelect = phoenixSelects.find(function (node) {
        var input = node.querySelector("input");
        var hint = [
          node.textContent,
          node.getAttribute && node.getAttribute("title"),
          input && input.value,
          input && input.getAttribute("placeholder"),
        ].filter(Boolean).join(" ");
        return /开始添加/.test(hint);
      });
      if (!phoenixSelect && window.location.href.includes("picc.zhiye.com")) {
        phoenixSelect = phoenixSelects[0] || null;
      }
      if (phoenixSelect) {
        AF.FormHandler.fillFormElement(phoenixSelect, "开始添加", "select");
        await AF.Utils.sleep(1000);
      }

      // 有些普通站点新增经历后只渲染“是否有XX经历”。只有先选“是”，
      // 项目名称、时间、描述等真实字段才会挂载。仅在对应简历数组确有当前记录、
      // 前置单选尚未作答时触发；普通卡片和已经展开的卡片保持原流程不变。
      card = await this.ensureConditionalExperienceExpanded(card, rowData, category, resolveCardFn) || card;

      var labels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(card));
      var occurrence = new Map();
      var labelInfos = labels.map(function (label) {
        var text = AF.LabelUtils.getLabelText(label);
        var seen = occurrence.get(text) || 0;
        occurrence.set(text, seen + 1);
        return { labelText: text, occurrence: seen, originalLabel: label };
      });
      var 示例资料 = this;
      var gateSpecial = this.configAdapter.siteConfig && this.configAdapter.siteConfig.experience &&
        this.configAdapter.siteConfig.experience.special || {};
      for (var i = 0; i < labelInfos.length; i++) {
        if (this.shouldStop && this.shouldStop()) break;
        var info = labelInfos[i];
        try {
          // “是否有XX经历”只负责展开条件式卡片，绝不能再按普通字段匹配。
          // 否则“是否有个人专利/发明”会被 示例资料Name 的别名命中，随后把
          // 专利标题写进是/否下拉。显式文案和通用兜底文案都在这里跳过。
          if (
            matchesCategoryScopedConditionalGate(category, info.labelText, gateSpecial, Number.MAX_SAFE_INTEGER) ||
            isRememberedConditionalExperienceGate(示例资料, category, info.labelText)
          ) continue;
          var targetLabel = info.originalLabel;
          // 重新定位当前卡 (源码行11594-11603): 卡片可能因填写而重渲染，
          // 按 labelText + occurrence 在最新 DOM 里找回对应的 label 元素
          var currentCard = currentFillScope();
          if (currentCard) {
            var freshLabels = 示例资料.filterValidLabels(示例资料.elementMatcher.findLabelsByCard(currentCard));
            var sameText = freshLabels.filter(function (l) {
              return AF.LabelUtils.getLabelText(l) === info.labelText;
            });
            targetLabel = sameText[info.occurrence] || null;
          }
          // 当前卡重渲染后若已找不到这个字段，不能继续使用旧卡或其他卡上的
          // label 引用。宁可本字段失败，也绝不把本科学制写进硕士卡。
          if (!targetLabel || !targetLabel.isConnected || (currentCard && !currentCard.contains(targetLabel))) continue;
          await 示例资料.fillSingleField(targetLabel, rowData, category);
        } catch (e) {
          // 单字段失败不影响后续字段 (源码 case 9 的 catch)
        }
        await AF.Utils.sleep(示例资料.operationDelay);

        // Moka 的学校和专业都是 React 受控搜索框。第一次点击候选项后可能整卡重建，
        // 旧节点上的瞬时 value 会消失；在最新卡片上复核真实展示值，失败则补填一次。
        try {
          var semanticKey = 示例资料.dataMatcher.findFieldByCategory(category, info.labelText);
          if (isMokaPage(示例资料) && category === "示例资料" && /^(school|major)$/.test(String(semanticKey || ""))) {
            var verificationCard = currentFillScope();
            var verificationLabels = verificationCard
              ? 示例资料.filterValidLabels(示例资料.elementMatcher.findLabelsByCard(verificationCard)).filter(function (label) {
                  return AF.LabelUtils.getLabelText(label) === info.labelText;
                })
              : [];
            var verificationLabel = verificationLabels[info.occurrence];
            var verificationFound = verificationLabel && 示例资料.elementMatcher.findElementAndTypeByLabel(verificationLabel);
            var actualValue = verificationFound && verificationFound.element && AF.FillTrace && AF.FillTrace.readElementValue
              ? AF.FillTrace.readElementValue(verificationFound.element)
              : "";
            if (!experienceValueMatches(rowData[semanticKey], actualValue) && verificationLabel) {
              await 示例资料.fillSingleField(verificationLabel, rowData, category);
              await AF.Utils.sleep(260);
            }
          }
        } catch (e2) {}
      }

      // ChinaHR 的旧页面有时不会把 div.aply-field-label 纳入通用标签结果，
      // 导致“学位”整行完全没有进入上面的循环。只对中国银行示例资料做一次
      // 空值复核，直接使用该行真实 label；已有学位时不重复操作。
      if (/^applyjob\.chinahr\.com$/i.test(String(location.hostname || "")) && category === "示例资料") {
        var latestChinaHrCard = currentFillScope();
        var chinaHrDegreeRows = latestChinaHrCard
          ? Array.from(latestChinaHrCard.querySelectorAll(".aply-field-li.edit"))
          : [];
        var chinaHrDegreeRow = chinaHrDegreeRows.find(function (row) {
          var rowLabel = row.querySelector(".aply-field-label");
          return String(rowLabel && rowLabel.textContent || "").replace(/[\s：:*]/g, "") === "学位";
        });
        var chinaHrDegreeLabel = chinaHrDegreeRow && chinaHrDegreeRow.querySelector(".aply-field-label");
        var chinaHrDegreePicker = chinaHrDegreeRow && chinaHrDegreeRow.querySelector(".ant-cascader-picker");
        var chinaHrDegreeDisplay = chinaHrDegreePicker && chinaHrDegreePicker.querySelector(".ant-cascader-picker-label");
        if (chinaHrDegreeLabel && chinaHrDegreePicker && !String(chinaHrDegreeDisplay && chinaHrDegreeDisplay.textContent || "").trim()) {
          await 示例资料.fillSingleField(chinaHrDegreeLabel, rowData, "示例资料");
        }
      }
      return true;
    } catch (e) {
      return false;
    }
  };

  ExperienceHandler.prototype.ensureConditionalExperienceExpanded = async function (card, rowData, category, resolveCardFn) {
    try {
      if (!card || !rowData) return card;
      var pattern = conditionalExperienceGatePattern(category);
      if (!pattern) return card;

      var gateSpecial = this.configAdapter.siteConfig && this.configAdapter.siteConfig.experience &&
        this.configAdapter.siteConfig.experience.special || {};

      var labels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(card));
      var gateLabel = labels.find(function (label) {
        var text = String(AF.LabelUtils.getLabelText(label) || "").replace(/\s+/g, "");
        return matchesCategoryScopedConditionalGate(category, text, gateSpecial, labels.length);
      });
      if (!gateLabel) return card;
      rememberConditionalExperienceGate(this, category, AF.LabelUtils.getLabelText(gateLabel));

      var found = this.elementMatcher.findElementAndTypeByLabel(gateLabel);
      var gateElement = found && found.element;
      if (!gateElement) return card;
      var gateScopeElement = Array.isArray(gateElement) ? gateElement[0] : gateElement;
      var fieldRoot = gateScopeElement && gateScopeElement.closest && gateScopeElement.closest(
        ".ant-form-item, .el-form-item, .form-item, [class*='form-item'], [role='radiogroup']"
      ) || card;
      var radios = Array.from(fieldRoot.querySelectorAll("input[type='radio'], [role='radio']"));
      var alreadyAnswered = radios.some(function (radio) {
        return Boolean(
          radio.checked ||
          radio.getAttribute && radio.getAttribute("aria-checked") === "true" ||
          radio.closest && radio.closest(".ant-radio-wrapper-checked, .el-radio.is-checked")
        );
      });
      var currentValue = "";
      if (AF.FillTrace && AF.FillTrace.readElementValue) currentValue = AF.FillTrace.readElementValue(gateElement);
      if (!currentValue && "value" in gateElement) currentValue = gateElement.value;
      if (String(currentValue || "").replace(/\s+/g, "") === "是") return card;
      if (alreadyAnswered) return card;

      var beforeLabelCount = labels.length;
      var beforeControlCount = card.querySelectorAll("input, textarea, select, [role='combobox']").length;
      // Phoenix 先走严格的就近门控点击；其余平台仍保持既有 FormHandler 路由。
      var opened = await selectPhoenixConditionalGate(gateLabel, "是");
      if (!opened) opened = await AF.FormHandler.fillFormElement(gateElement, "是", found.type || "select");
      if (!opened) return card;
      if (AF.FillTrace) AF.FillTrace.event("conditional_experience_expand", category + " 前置问题已选择‘是’", "success");

      var latestCard = card;
      for (var attempt = 0; attempt < 18; attempt++) {
        await AF.Utils.sleep(100);
        latestCard = resolveCardFn ? resolveCardFn() : card;
        if (!latestCard) continue;
        var latestLabels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(latestCard));
        var latestControlCount = latestCard.querySelectorAll("input, textarea, select, [role='combobox']").length;
        if (latestLabels.length > beforeLabelCount || latestControlCount > beforeControlCount) return latestCard;
      }
      return latestCard || card;
    } catch (e) {
      return card;
    }
  };

  ExperienceHandler.prototype.fillCompositeFamilyCard = async function (card, data, category, resolveCardFn) {
    try {
      var labels = this.filterValidLabels(this.elementMatcher.findLabelsByCard(card));
      var occurrence = new Map();
      var currentRole = null;
      var labelInfos = labels.map(function (label) {
        var text = AF.LabelUtils.getLabelText(label);
        var explicitRole = 示例资料RoleFromLabel(text);
        if (explicitRole) currentRole = explicitRole;
        var role = currentRole || "father";
        var seenKey = role + "::" + text;
        var seen = occurrence.get(seenKey) || 0;
        occurrence.set(seenKey, seen + 1);
        return { labelText: text, role: role, occurrence: seen, originalLabel: label };
      });

      var 示例资料 = this;
      for (var i = 0; i < labelInfos.length; i++) {
        if (this.shouldStop && this.shouldStop()) break;
        var info = labelInfos[i];
        var rowData = findFamilyRecordByRole(data, info.role);
        if (!rowData) continue;
        try {
          var targetLabel = info.originalLabel;
          var currentCard = resolveCardFn ? resolveCardFn() : card;
          if (currentCard) {
            var freshLabels = 示例资料.filterValidLabels(示例资料.elementMatcher.findLabelsByCard(currentCard));
            var roleCursor = null;
            var sameRoleAndText = [];
            for (var j = 0; j < freshLabels.length; j++) {
              var freshText = AF.LabelUtils.getLabelText(freshLabels[j]);
              var freshRole = 示例资料RoleFromLabel(freshText);
              if (freshRole) roleCursor = freshRole;
              var effectiveRole = roleCursor || "father";
              if (freshText === info.labelText && effectiveRole === info.role) sameRoleAndText.push(freshLabels[j]);
            }
            targetLabel = sameRoleAndText[info.occurrence] || targetLabel;
          }
          await 示例资料.fillSingleField(targetLabel, rowData, category);
        } catch (e) {
          // 单字段失败不影响后续字段。
        }
        await AF.Utils.sleep(示例资料.operationDelay);
      }
      return true;
    } catch (e) {
      return false;
    }
  };

  // ---------- fillSingleField (源码行11670-11740) ----------
  ExperienceHandler.prototype.fillSingleField = async function (labelEl, rowData, category) {
    var text = AF.LabelUtils.getLabelText(labelEl);
    if (!text) return false;

    var rangeValue = linkedTemporalValue(labelEl, text, rowData, this.elementMatcher && this.elementMatcher.config);
    var fieldKey = rangeValue ? "duration" : this.dataMatcher.findFieldByCategory(category, text);
    if (!fieldKey && AF.AIConfigGenerator && typeof AF.AIConfigGenerator.resolveSemanticFieldMapping === "function") {
      fieldKey = AF.AIConfigGenerator.resolveSemanticFieldMapping(this.elementMatcher && this.elementMatcher.config, category, text);
    }
    if (!fieldKey && (text.includes("时间") || text.includes("日期") || text.includes("年月"))) {
      if (rowData.duration) {
        fieldKey = "duration";
      } else if (rowData.startTime && rowData.endTime) {
        fieldKey = text.includes("开始") ? "startTime" : "endTime";
      }
    }
    var isChinaHrDegreeLabel = /^applyjob\.chinahr\.com$/i.test(String(location.hostname || "")) &&
      String(text || "").replace(/[\s：:*]/g, "") === "学位";
    var isChinaHrWorkTypeLabel = /^applyjob\.chinahr\.com$/i.test(String(location.hostname || "")) &&
      String(text || "").replace(/[\s：:*]/g, "") === "工作类别";
    var chinaHrEducationForm = labelEl && labelEl.closest && labelEl.closest(".aply-form");
    var chinaHrEducationTitle = chinaHrEducationForm &&
      String((chinaHrEducationForm.querySelector(".aply-form-tit") || {}).textContent || "").replace(/\s+/g, "").indexOf("示例资料") !== -1;
    var chinaHrDegreeRow = labelEl && labelEl.closest && labelEl.closest(".aply-field-li");
    var chinaHrDegreeField = isChinaHrDegreeLabel && !!chinaHrDegreeRow;
    // 中国银行教育卡的“学位”只能对应 示例资料.degree。即使通用字典
    // 已给出其它 fieldKey，也要在这个精确站点/栏目/标签组合下纠正回来。
    if (chinaHrDegreeField) {
      fieldKey = "degree";
      category = "示例资料";
    }
    if (!fieldKey && isChinaHrWorkTypeLabel) {
      fieldKey = "示例资料Type";
      category = "示例资料Experience";
    }
    if (!fieldKey) {
      if (AF.FillTrace && /^applyjob\.chinahr\.com$/i.test(String(location.hostname || "")) &&
          String(text || "").replace(/[\s：:*]/g, "") === "学位") {
        AF.FillTrace.event("chinahr.degree_skip", "字段匹配阶段未得到 fieldKey，category=" + String(category || ""), "failed");
      }
      return false;
    }

    var value = rangeValue || rowData[fieldKey];
    if (chinaHrDegreeField && !value) {
      value = rowData.degreeName || rowData.degreeType || rowData.academicDegree || rowData.level || rowData.示例资料Level || "";
    }
    if (chinaHrDegreeField) {
      var degreeText = String(value == null ? "" : value).trim();
      value = /博士/.test(degreeText) ? "博士" :
        /硕士|研究生/.test(degreeText) ? "硕士" :
        /学士|本科/.test(degreeText) ? "学士" :
        /无学位|无/.test(degreeText) ? "无" : degreeText;
    }
    if (isChinaHrWorkTypeLabel) {
      value = "实习（未毕业在校生兼职或实习）";
    }
    // 某些页面字段要求使用页面默认值（例如“工作类别”直接选第一项），
    // 简历记录本身不一定有对应数据。字段能力补丁可声明 defaultValue，
    // 这样仍走同一套下拉适配器和校验流程，不需要伪造简历内容。
    if (AF.CapabilityPatch && typeof AF.CapabilityPatch.resolve === "function") {
      var defaultCapability = AF.CapabilityPatch.resolve(
        this.configAdapter && this.configAdapter.siteConfig,
        { category: category, fieldKey: fieldKey, labelText: text, type: "" }
      );
      var valueMissing = value == null || (typeof value === "string" && !value.trim());
      if (defaultCapability && Object.prototype.hasOwnProperty.call(defaultCapability, "defaultValue") &&
          (defaultCapability.useDefaultValue === true || valueMissing)) {
        value = defaultCapability.defaultValue;
      }
    }
    if (category === "示例资料") {
      value = resolveHighestEducationValue(fieldKey, value, rowData);
    }
    if (value == null && fieldKey === "duration" && rowData.startTime && rowData.endTime) {
      value = { startTime: rowData.startTime, endTime: rowData.endTime };
    }
    if (value == null) {
      if (AF.FillTrace && /^applyjob\.chinahr\.com$/i.test(String(location.hostname || "")) &&
          fieldKey === "degree") {
        AF.FillTrace.event("chinahr.degree_skip", "没有拿到 示例资料.degree 值", "failed");
      }
      return false;
    }

    var found = null;
    var elType = "";
    var el = null;
    var isChinaHrDegreeRow = chinaHrDegreeField &&
      labelEl && labelEl.closest && labelEl.closest(".aply-field-li");
    if (isChinaHrDegreeRow) {
      el = isChinaHrDegreeRow.querySelector(".ant-cascader-picker");
      if (el) elType = "select";
    }
    if (!el) {
      found = this.elementMatcher.findElementAndTypeByLabel(labelEl);
      elType = found.type;
      el = found.element;
    }
    if (!el) {
      if (AF.FillTrace && /^applyjob\.chinahr\.com$/i.test(String(location.hostname || "")) &&
          fieldKey === "degree") {
        AF.FillTrace.event("chinahr.degree_skip", "没有找到学位控件", "failed");
      }
      return false;
    }

    // ChinaHR 中国银行的编辑字段都在当前 .aply-field-li 内；
    // 学位是 Ant Cascader，不能依赖通用相邻控件推断，否则会被同卡其他
    // input/隐藏字典节点抢占。按真实 DOM 对当前行做硬定位。
    if (/^applyjob\.chinahr\.com$/i.test(window.location.hostname) &&
        labelEl && labelEl.closest) {
      var chinahrRow = labelEl.closest(".aply-field-li");
      if (chinahrRow) {
        if (category === "示例资料" && fieldKey === "degree") {
          var chinahrDegree = chinahrRow.querySelector(".ant-cascader-picker");
          if (chinahrDegree) {
            el = chinahrDegree;
            elType = "select";
          }
        } else if (category === "示例资料Experience" && fieldKey === "示例资料Type") {
          var chinahrWorkType = chinahrRow.querySelector(
            ".ant-select, .ant-cascader-picker, select, input[placeholder='请选择']"
          );
          if (chinahrWorkType) {
            el = chinahrWorkType;
            elType = "select";
          }
        }
      }
    }

    // 中国电信的每个字段都包在独立 `.mdf-table-cell` 中。通用相邻控件算法
    // 遇到 readonly 日期或隐藏字典 input 时，可能越过当前行命中后面的学历/
    // 学制 select，造成“日期为空但学历 select.value 变成日期”的串位。
    // 该站严格把控件收回到当前字段行内，避免跨字段填写。
    if (isChinaTelecomHotjobPage() && labelEl && labelEl.closest) {
      var hotjobRow = labelEl.closest(".mdf-table-cell");
      if (hotjobRow) {
        if (/^(startTime|endTime|awardTime|publishTime|grantDate|obtainedTime)$/.test(String(fieldKey || ""))) {
          var rowDateInput = hotjobRow.querySelector("input.dayType");
          if (rowDateInput) {
            el = rowDateInput;
            elType = "date";
          }
        } else if (category === "示例资料" && /^(school|major)$/.test(String(fieldKey || ""))) {
          var rowSpecialChoice = hotjobRow.querySelector("dy-form-special");
          if (rowSpecialChoice) {
            el = rowSpecialChoice;
            elType = "search";
          }
        } else if (category === "示例资料" && /^(ccbHighestEducation|isHighestEducation)$/.test(String(fieldKey || ""))) {
          // 该站的“是否最高学历”是 Angular 单选组件。必须限制在当前教育卡片的
          // 当前字段行内，并真实点击与简历值对应的“是/否”，不能沿用页面默认值。
          var rowHighestRadios = hotjobRow.querySelectorAll('input[type="radio"][msg="是否最高学历"]');
          if (rowHighestRadios.length) {
            el = rowHighestRadios[0];
            elType = "radio";
          }
        } else if (/^(level|studyLength|degree|示例资料Type)$/.test(String(fieldKey || ""))) {
          var rowSelect = hotjobRow.querySelector("select");
          if (rowSelect) {
            el = rowSelect;
            elType = "select";
          }
        }
      }
    }

    if (AF.AddressAdapter && await AF.AddressAdapter.fillProvinceCityPair(labelEl, value)) {
      this.filledFieldsCount++;
      return true;
    }

    if (AF.CurrentEndDate && fieldKey === "endTime" && AF.CurrentEndDate.isCurrentValue(value)) {
      var currentResult = await AF.CurrentEndDate.resolve(fieldKey, value, labelEl, el);
      if (currentResult.handled) {
        this.filledFieldsCount++;
        return true;
      }
      value = currentResult.value;
    }

    // 类型二次修正 (源码行11689-11697)。源码判断 f === "input"，rebuild 的
    // ElementMatcher 契约把文本类型统一叫 "text"，故这里用 "text"。
    var resolvedType = elType;
    if (resolvedType === "input") resolvedType = "text";
    if (resolvedType === "contenteditable") resolvedType = "contentEditable";
    if (AF.DomUtils.isDateValue(value) && !/^(radio|checkbox|multiSelect)$/i.test(String(resolvedType || ""))) {
      resolvedType = "date";
    } else if (resolvedType === "text") {
      if (AF.DomUtils.isDatePicker(el) || AF.DomUtils.isDateValue(value)) {
        resolvedType = "date";
      } else if (AF.DomUtils.isNormalSelect(el) || AF.DomUtils.isSearchSelect(el)) {
        resolvedType = "search";
      }
    } else if (resolvedType === "select" && AF.DomUtils.isSearchSelect(el) &&
        !(el && el.closest && el.closest(".ant-cascader-picker, .ant-select.ant-cascader, .ant-cascader"))) {
      resolvedType = "search";
    }

    // Element Cascader 的可编辑 input 只是组件触发器，不是可直接提交的搜索文本框。
    // 尤其国家/籍贯传入层级路径数组时，必须交给 SelectAdapter 逐级点击选项。
    if (el && el.closest && el.closest(".el-cascader")) {
      resolvedType = "select";
    }
    // 北森 Phoenix 的“院校所在城市”外观是 editable select，但语义与籍贯
    // 相同：先选省、再选市。新版经历引擎此前会把它当作 search，导致后两
    // 张教育卡的空城市字段无法打开地址面板。这里强制走 SelectAdapter。
    if (
      category === "示例资料" &&
      fieldKey === "city" &&
      /(就读院校|院校|学校|毕业院校)所在城市|院校城市/.test(text) &&
      el && el.closest && el.closest(".phoenix-select") &&
      AF.DomUtils && typeof AF.DomUtils.resolveEducationLocationPath === "function"
    ) {
      var phoenixEducationLocationPath = AF.DomUtils.resolveEducationLocationPath(rowData);
      if (phoenixEducationLocationPath.length >= 2) value = phoenixEducationLocationPath;
      resolvedType = "select";
    }
    value = buildEducationMajorCascaderValue(category, fieldKey, rowData, value, el);

    // Moka 的学校/专业即使 ElementMatcher 因隐藏 input 误判为 text，
    // 也必须走 SearchInputHandler，输入文字本身并不会提交其字典字段值。
    var choicePlaceholder = String(el && el.getAttribute && el.getAttribute("placeholder") || "");
    if (
      category === "示例资料" &&
      /^(school|major)$/.test(String(fieldKey || "")) &&
      (isMokaPage(this) || isChinaTelecomHotjobPage() || /^请选择/.test(choicePlaceholder))
    ) {
      resolvedType = "search";
    }
    if (isChinaTelecomHotjobPage() && category === "示例资料" && fieldKey === "awardName") {
      resolvedType = "search";
    }

    if (resolvedType === "search") value = buildEducationDialogChoiceValue(category, fieldKey, rowData, value);

    var capabilityContext = AF.CapabilityPatch && AF.CapabilityPatch.createContext
      ? AF.CapabilityPatch.createContext(this.configAdapter && this.configAdapter.siteConfig, {
          category: category,
          fieldKey: fieldKey,
          labelText: text,
          element: el,
          type: resolvedType,
        })
      : null;
    if (AF.FillTrace && /^applyjob\.chinahr\.com$/i.test(String(location.hostname || "")) &&
        category === "示例资料" && fieldKey === "degree") {
      AF.FillTrace.event("chinahr.degree_start", "目标值=" + String(value || ""), "started");
    }
    if (AF.FillTrace) AF.FillTrace.setFieldContext({ category: category, label: text, fieldKey: fieldKey, plannedValue: value });
    var ok = await AF.FormHandler.fillFormElement(el, value, resolvedType, capabilityContext);
    if (AF.FillTrace && /^applyjob\.chinahr\.com$/i.test(String(location.hostname || "")) &&
        category === "示例资料" && fieldKey === "degree") {
      AF.FillTrace.event("chinahr.degree_result", "结果=" + String(!!ok), ok ? "success" : "failed");
    }
    if (ok) {
      this.filledFieldsCount++;
      return true;
    }
    return false;
  };

  // ---------- saveCurrentCard (源码行11743-11810) ----------
  ExperienceHandler.prototype.saveCurrentCard = async function (container, card) {
    if (!this.configAdapter.requiresSaveBeforeNext()) return true;
    // Patch113: some enterprise editors render save buttons in modal/drawer scope
    // instead of inside the original card. Prefer the active editor ownership scope.
    var scopes = [];
    if (this._activeEditorScope && this._activeEditorScope.querySelectorAll) scopes.push(this._activeEditorScope);
    if (card && card.querySelectorAll) scopes.push(card);
    if (container && container.querySelectorAll) scopes.push(container);
    var btn = null;
    for (var i = 0; i < scopes.length && !btn; i++) {
      btn = await this.findElementByPriority(scopes[i], this.configAdapter.getSaveButtonSelector(), this.configAdapter.getSaveButtonText());
    }
    if (!btn) {
      if (AF.FillTrace) AF.FillTrace.event("save_card", "未找到保存按钮", "failed");
      return false;
    }
    try {
      if (AF.FillTrace) AF.FillTrace.event("save_card", "点击经历卡片保存", "started");
      await AF.DomUtils.safeClickElement(btn);
      if (/^applyjob\.chinahr\.com$/i.test(String(location.hostname || ""))) {
        await AF.Utils.sleep(180);
        var stillEditing = card && card.querySelector && card.querySelector(".aply-field-li.edit");
        if (AF.FillTrace) AF.FillTrace.event("chinahr.示例资料_save_state",
          "点击后编辑字段数=" + (card && card.querySelectorAll ? card.querySelectorAll(".aply-field-li.edit").length : -1) +
          " 按钮禁用=" + (!!btn.disabled), stillEditing ? "pending" : "success");
        if (stillEditing && AF.DomUtils.isElementVisible(btn)) {
          try { btn.click(); } catch (eChinaHrSaveClick) {}
        }
      }
      var waitSelector = this.configAdapter.getSaveWaitForSelector();
      if (waitSelector) {
        await this.waitForElement(container, waitSelector, this.configAdapter.getSaveTimeoutMs());
      } else {
        await AF.Utils.sleep(this.configAdapter.getSaveTimeoutMs());
      }
      if (/^applyjob\.chinahr\.com$/i.test(String(location.hostname || "")) &&
          card && card.querySelector && card.querySelector(".aply-field-li.edit")) {
        if (AF.FillTrace) AF.FillTrace.event("save_card", "中国银行保存后仍处于编辑态", "failed");
        return false;
      }
      if (AF.FillTrace) AF.FillTrace.event("save_card", "经历卡片保存完成", "success");
      return true;
    } catch (e) {
      if (AF.FillTrace) AF.FillTrace.event("save_card", String(e), "failed");
      return false;
    }
  };

  // ---------- findElementByPriority (源码行11813-11851): 选择器优先, 文字兜底 ----------
  ExperienceHandler.prototype.findElementByPriority = async function (scope, selector, textArr) {
    if (selector) {
      var nodes = scope.querySelectorAll(selector);
      var btn = AF.DomUtils.findVisibleButton(Array.from(nodes));
      if (btn) return btn;
    }
    if (textArr && textArr.length > 0) {
      var byText = this.findElementByText(scope, textArr);
      if (byText) return byText;
    }
    return null;
  };

  // ---------- findElementByText (源码行11854-11895) ----------
  ExperienceHandler.prototype.findElementByText = function (scope, textArr) {
    var nodes = scope.querySelectorAll(
      ["button", 'a[href]', "[onclick]", ".btn", ".button", '[role="button"]'].join(", ")
    );
    for (var i = 0; i < textArr.length; i++) {
      var target = textArr[i].toLowerCase();
      for (var j = 0; j < nodes.length; j++) {
        var el = nodes[j];
        if (AF.DomUtils.isElementVisible(el)) {
          var txt = (el.textContent ? el.textContent.trim().toLowerCase() : "") || "";
          if (txt === target) return el;
          if (txt.includes(target)) return el;
        }
      }
    }
    return null;
  };

  // ---------- isInEditMode (源码行11898-11906) ----------
  ExperienceHandler.prototype.isInEditMode = function (scope, guardSelector) {
    if (!guardSelector) return true; // 没配 guard 就认为始终在编辑态
    return Boolean(scope.querySelector(guardSelector));
  };

  // ---------- waitForElement (源码行11909-11945) ----------
  ExperienceHandler.prototype.waitForElement = async function (scope, selector, timeout) {
    timeout = timeout === undefined ? 3000 : timeout;
    var start = Date.now();
    while (Date.now() - start < timeout) {
      if (scope.querySelector(selector)) return true;
      await AF.Utils.sleep(100);
    }
    return false;
  };

  // ---------- filterValidLabels (源码行11948-11958) ----------
  ExperienceHandler.prototype.filterValidLabels = function (labels) {
    if (labels && labels.length) {
      return Array.from(labels).filter(function (l) {
        var t = AF.LabelUtils.getLabelText(l);
        return t && t.length > 0 && AF.DomUtils.isElementVisible(l);
      });
    }
    return [];
  };

  // ---------- handleSingleCardMode (源码行11960-12046) ----------
  // 一次只显示一张卡片的站点 (如智联校园): 按 dataIndexByCardCount 决定当前该填第几条数据。
  ExperienceHandler.prototype.handleSingleCardMode = async function (container, data, category, existingCount) {
    try {
      var dataIndex = 0;
      if (this.configAdapter.isDataIndexByCardCount()) {
        dataIndex = existingCount - 1;
        if (dataIndex < 0) dataIndex = 0;
      } else {
        dataIndex = 0;
      }
      if (dataIndex >= data.length) return true;

      if (existingCount === 0) {
        var added = await this.addNewCard(container, 0);
        if (!added) return false;
      }

      var card = await this.locateAndPrepareCard(container, 0);
      if (!card) return false;

      var rowData = data[dataIndex];
      var 示例资料 = this;
      var cardBinding = this.captureCardBinding(card, 0, rowData, category);
      var filled = await this.fillSingleCard(card, rowData, category, function () {
        return 示例资料.resolveBoundCard(container, cardBinding);
      });
      if (!filled) return false;

      if (this.configAdapter.requiresSaveBeforeNext()) {
        var latestCard = this.resolveBoundCard(container, cardBinding);
        if (!latestCard) return false;
        var saved = await this.saveCurrentCard(container, latestCard);
        this.clearActiveEditorScope();
        if (!saved) return false;
      }
      return true;
    } catch (e) {
      return false;
    }
  };

  AF.ExperienceHandler = ExperienceHandler;
  AF.ConfigAdapter = ConfigAdapter;
})();
