// 私有特殊站点统一配置中心。
//
// 约束：
//   1. 所有需要“依次点击大类再填写”的特殊站点，只允许写在本文件。
//   2. 不得把这里的配置复制到 SITE_TEMPLATES、远程站点配置或运行包发布列表。
//   3. 每个站点同时维护 config（字段/经历定位）和 示例资料flow（栏目切换顺序）。
//
// 注意：Chrome 扩展本地代码无法真正加密。本文件提供的是代码、管理和发布边界隔离，
// 避免特殊规则被误发布到服务器或与通用站点模板混用。
(function () {
  "use strict";

  var AF = (window.AF = window.AF || {});

  function deepFreeze(value) {
    if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
    // RegExp.test() 可能更新 lastIndex；冻结正则会导致严格模式下匹配失败。
    if (value instanceof RegExp) return value;
    Object.getOwnPropertyNames(value).forEach(function (key) { deepFreeze(value[key]); });
    return Object.freeze(value);
  }

  function matchesRule(rule, value) {
    if (!rule) return true;
    if (rule instanceof RegExp) {
      if (rule.global || rule.sticky) rule.lastIndex = 0;
      return rule.test(value);
    }
    if (Array.isArray(rule)) return rule.indexOf(value) !== -1;
    return String(rule).toLowerCase() === String(value).toLowerCase();
  }

  function matchesBrandDomain(brandDomain, hostname) {
    var brand = String(brandDomain || "").toLowerCase().replace(/^\.+|\.+$/g, "");
    var host = String(hostname || "").toLowerCase().replace(/^\.+|\.+$/g, "");
    if (!brand || !host) return false;
    // 只接受品牌根域本身或其真实子域，不能使用简单 includes；否则
    // fake-pingan.com、pingan-example.net 之类的网址也会被错误命中。
    return host === brand || host.endsWith("." + brand);
  }

  function hasResumeUrlHint(parsed) {
    var route = String((parsed && parsed.pathname) || "") + String((parsed && parsed.hash) || "") + String((parsed && parsed.search) || "");
    // 已经通过品牌根域校验后，路径关键词可以适当放宽，以兼容
    // resumeCenter、myResume、resumeEdit 等连续或驼峰写法。
    return /resume|personalcenter|profile|(?:^|[\/_#?=&.-])cv(?:$|[\/_#?=&.-])/i.test(route);
  }

  function hasResumePageFingerprint() {
    try {
      if (typeof document === "undefined" || !document.body) return false;
      var body = document.body;
      var text = String(body.innerText || body.textContent || "").replace(/\s+/g, "");
      var labelGroups = [
        ["示例资料", "个人信息", "个人示例资料"],
        ["示例资料", "教育背景"],
        ["示例资料", "示例资料", "工作/示例资料"],
        ["联系信息", "联系方式"],
        ["项目经历", "项目经验"],
      ];
      var matchedGroups = labelGroups.filter(function (group) {
        return group.some(function (label) { return text.indexOf(label) !== -1; });
      }).length;
      var controlCount = body.querySelectorAll(
        "input:not([type='hidden']), textarea, select, [role='combobox'], .el-select, .el-cascader, .ant-select, .ant-picker"
      ).length;
      // 至少同时出现三组简历栏目和三个真实控件，避免品牌官网首页、岗位
      // 列表或普通个人中心仅因出现“个人信息”等单个词语而误命中。
      return matchedGroups >= 3 && controlCount >= 3;
    } catch (e) {
      return false;
    }
  }

  function icbcStep(index, name, category, options) {
    return Object.assign({
      name: name,
      category: category,
      triggerSelector: "[class*='menu___'] > [class*='menu__item___']:nth-of-type(" + index + ")",
      triggerText: [name],
      readySelector: "[class*='content__right']",
      scopeSelector: "[class*='content__right']",
      fillMode: "full",
      waitAfterClickMs: 700,
      timeoutMs: 6000,
      skipClickWhenReady: false,
    }, options || {});
  }

  // 工行字段定位仍按原菜单序号进行；仅将示例资料的执行任务排到最后，
  // 便于前面栏目完成后停留在教育页检查并处理保存结果。
  function icbcExecutionSteps(steps) {
    var result = Array.isArray(steps) ? steps.slice() : [];
    var 示例资料Index = result.findIndex(function (step) { return step && step.name === "示例资料"; });
    if (示例资料Index >= 0) result.push(result.splice(示例资料Index, 1)[0]);
    return result;
  }

  function icbcLocationPath(value, fallback) {
    var source = value || fallback || [];
    if (Array.isArray(source)) return source.filter(Boolean).slice(0, 3);
    if (source && typeof source === "object") {
      source = [source.province || source.provinceName, source.city || source.cityName, source.district || source.districtName || source.area || source.areaName].filter(Boolean);
      return source.slice(0, 3);
    }
    return String(source || "").split(/\s*\/\s*|\s*>\s*|\s*,\s*|\s+/, 3).filter(Boolean);
  }

  // 工行 2026 新版个人示例资料把省/市/区拆成相互依赖的 Ant Select，并将
  // 合规声明保留在示例资料页。站点派生字段只服务于该页面，不回写用户简历。
  function enrichIcbcBasicInfo(data, resume) {
    var 示例资料 = Object.assign({}, resume && resume.示例资料Info || {}, data || {});
    var 示例资料 = resume && resume.示例资料Info || {};
    示例资料.icbcNativePlacePath = icbcLocationPath(示例资料.nativePlacePath, 示例资料.nativePlace);
    示例资料.icbcBirthOriginPath = icbcLocationPath(示例资料.birthOriginPath, 示例资料.birthOrigin);
    示例资料.icbcHukouLocationPath = icbcLocationPath(示例资料.hukouLocationPath, 示例资料.hukouLocation);
    示例资料.icbcFamilyAddressPath = icbcLocationPath(示例资料.示例资料LocationPath, 示例资料.示例资料Location);
    // 简历标准字段通常把家庭地址拆成“家庭所在地 + 现居住地详细地址”；
    // 工行页面则把详细地址放在同一表单项的 textarea 中，统一准备一个可填值。
    示例资料.示例资料Address = 示例资料.示例资料Address || 示例资料.示例资料AddressDetail ||
      示例资料.示例资料LocationDetail || 示例资料.currentAddressDetail || 示例资料.currentAddress || "";
    示例资料.icbcForeignResidencePermit = 示例资料.hasForeignResidencePermit || "";
    示例资料.icbcSeriousDisease = 示例资料.hasSeriousDisease || 示例资料.hasSeriousDisease || "";
    return 示例资料;
  }

  function icbcEducationLevel(row) {
    var text = String(row && (row.level || row.示例资料Level || "")).trim();
    if (/博士/.test(text)) return "博士研究生";
    if (/硕士|研究生|MBA|EMBA/i.test(text)) return /MBA/i.test(text) ? "MBA" : "硕士研究生";
    if (/本科|学士|大学/.test(text)) return "大学本科";
    if (/专科|大专/.test(text)) return "大学专科";
    if (/中专|职高|技校|高中/.test(text)) return "高中";
    return text;
  }

  function isIcbcHighSchoolRow(row) {
    return /高中|中专|职高|技校/.test(String(row && (row.level || row.示例资料Level || "")));
  }

  function icbcDegreeSelection(row) {
    var result = row || {};
    var type = String(result.degreeType || result.academicType || "").trim();
    var degree = String(result.degree || result.degreeName || "").trim();
    if (/专业硕士|专业学位/.test(type)) return "专业硕士";
    if (/学术硕士|学术学位/.test(type)) return "学术硕士";
    if (/无|未取得/.test(type) || /无|未取得/.test(degree)) return "无学位";
    if (/博士/.test(type)) return "博士";
    if (/学士/.test(type)) return "学士";
    // 旧简历把“学历学位”作为学位类型；工商银行这里仍需选择
    // “学术硕士”，但博士/学士按学位本身的层次填写。
    if (/学历学位/.test(type)) {
      if (/博士/.test(degree)) return "博士";
      if (/学士|本科/.test(degree)) return "学士";
      return "学术硕士";
    }
    return degree || type;
  }

  function icbcAcademicDegreeName(row) {
    var result = row || {};
    var degree = String(result.degree || result.degreeName || "").replace(/\s*学位$/g, "").trim();
    var type = String(result.degreeType || result.academicType || "").trim();
    var explicit = (degree + " " + type).match(/(?:哲学|经济学|法学|教育学|文学|历史学|理学|工学|农学|医学|军事学|管理学|建筑学|艺术学|交叉学)(?:博士|硕士|学士)/);
    if (explicit) return explicit[0];
    if (/^(?:无|未取得)$/.test(degree)) return "";
    var suffix = /博士/.test(degree) || /博士/.test(type) ? "博士" :
      (/硕士|研究生/.test(degree) || /硕士/.test(type) ? "硕士" :
        (/学士|本科/.test(degree) || /学士/.test(type) ? "学士" : ""));
    var categoryText = String(result.majorCategory || result.majorSubcategory || "");
    var categories = ["哲学", "经济学", "法学", "教育学", "文学", "历史学", "理学", "工学", "农学", "医学", "军事学", "管理学", "建筑学", "艺术学", "交叉学"];
    var category = categories.find(function (entry) { return categoryText.indexOf(entry) !== -1; });
    return suffix && category ? category + suffix : degree;
  }

  // 工行资格认证页使用固定的下拉选项，简历中的证书名称可能带有“证书”、
  // 英文全称或不同括号写法。统一映射到页面显示文案，交给 Ant Select 选择。
  function icbcCertificateName(row) {
    var text = typeof row === "string"
      ? row.trim()
      : String(row && (row.certificateName || row.certificate || row.name || "") || "").trim();
    var compact = text.replace(/[（）()【】\[\]\s]/g, "").toUpperCase();
    if (/CFA|特许金融分析师/.test(compact)) return "特许金融分析师（CFA）";
    if (/CFP|国际金融理财师|金融理财师|高级理财策划师/.test(compact)) return "高级理财策划师（CFP）";
    if (/ACCA|特许公认会计师|国际注册会计师/.test(compact)) return "特许公认会计师（ACCA）";
    if (/CPA|注册会计师/.test(compact)) return "注册会计师（CPA）";
    if (/FRM|金融风险管理师/.test(compact)) return "金融风险管理师（FRM）";
    if (/公司律师/.test(compact)) return "公司律师";
    if (/法律职业资格/.test(compact)) return "法律职业资格";
    if (/律师资格|律师/.test(compact)) return "律师";
    return text;
  }

  function enrichIcbcCertificateRow(row) {
    var result = Object.assign({}, row || {});
    result.icbcCertificateName = icbcCertificateName(result);
    return result;
  }

  function icbcEducationRows(rows) {
    var sorted = (Array.isArray(rows) ? rows.slice() : []).sort(function (a, b) {
      var rank = function (row) {
        if (isIcbcHighSchoolRow(row)) return 0;
        var text = String(row && (row.level || row.示例资料Level || ""));
        if (/专科|大专/.test(text)) return 1;
        if (/本科|学士|大学/.test(text)) return 2;
        if (/硕士|研究生|MBA|EMBA/i.test(text)) return 3;
        if (/博士/.test(text)) return 4;
        return 2;
      };
      return rank(b) - rank(a) || String(b && b.startTime || "").localeCompare(String(a && a.startTime || ""));
    });
    // 页面按“最高学历、高校经历、高中经历”顺序固定渲染卡片，第一条数据
    // 对应最高学历卡，后续数据对应可重复卡。
    return sorted;
  }

  function enrichIcbcEducationSummary(data, resume) {
    var rows = resume && Array.isArray(resume.示例资料) ? resume.示例资料.slice() : [];
    rows.sort(function (a, b) {
      return (isIcbcHighSchoolRow(a) ? -1 : 1) - (isIcbcHighSchoolRow(b) ? -1 : 1) ||
        String(b && b.startTime || "").localeCompare(String(a && a.startTime || ""));
    });
    var highest = rows.filter(function (row) { return !isIcbcHighSchoolRow(row); })[0] || rows[0] || data || {};
    return Object.assign({}, highest, data || {}, { icbcHighestEducation: icbcEducationLevel(highest) });
  }

  function enrichIcbcEducationRow(row) {
    var result = Object.assign({}, row || {});
    result.icbcEducationLevel = icbcEducationLevel(result);
    result.icbcSchoolPlace = result.schoolLocation || result.city || "";
    result.icbcMajorPath = Array.isArray(result.majorPath) ? result.majorPath.filter(Boolean).slice(0, 3) :
      (result.majorPath ? String(result.majorPath).split(/\s*\/\s*|\s*>\s*|\s*,\s*/).filter(Boolean).slice(0, 3) :
        [result.majorCategory, result.majorSubcategory, result.major].filter(Boolean).slice(0, 3));
    result.schoolLocationPath = Array.isArray(result.schoolLocationPath) ? result.schoolLocationPath.filter(Boolean).slice(0, 2) :
      (result.schoolLocationPath ? String(result.schoolLocationPath).split(/\s*\/\s*|\s*>\s*|\s*,\s*/).filter(Boolean).slice(0, 2) : []);
    // 工行教育页允许只填关键字段；未单独维护“是否主要经历”时按用户约定默认“是”。
    result.icbcIsMajor = "是";
    // 页面第一个学历类型是全日制长文案，用“全日制”做包含匹配即可选中它。
    result.icbcEducationType = "全日制";
    // 工行“学位”下拉对应简历的学位类型（学术硕士/专业硕士）。
    result.icbcDegree = icbcDegreeSelection(result);
    // 工行“学位类型”下拉对应学科门类 + 学位（如“工学硕士”）。
    result.icbcDegreeType = icbcAcademicDegreeName(result);
    // 工行“班级排名”对应简历示例资料中的“排名”（classRank）。
    // 兼容旧简历曾使用的 rank 键，但不修改原始简历数据。
    var rank = result.classRank || result.rank || result.ranking || result.classRanking || result.gradeRank || "";
    // 兼容导入数据中的“排名前10% / TOP10% / 10％”写法，统一成工行
    // 下拉常见的“前10%”文案；下拉适配器仍负责最终选项匹配。
    result.icbcClassRank = String(rank || "").trim()
      .replace(/％/g, "%")
      .replace(/\s+/g, "")
      .replace(/^排名前|^TOP/i, "前") || rank;
    // 这三个单选是工行教育页必填项，先给出可修改的默认值。
    result.icbcIsDoubleDegree = "否";
    result.icbcIsAssociateToBachelor = "否";
    // 默认不声明学生干部，避免页面继续展开“担任职务”等必填字段；用户仍可手动改为“是”。
    result.icbcIsCadre = "否";
    return result;
  }

  function zhaopinInlineStep(name, category, options) {
    options = options || {};
    var result = Object.assign({
      name: name,
      category: category,
      cardTitle: name,
      fillMode: "full",
      waitAfterClickMs: 220,
      timeoutMs: 6000,
      skipClickWhenReady: false,
      // 智联的编辑入口多数要先激活卡片才显示，重复模块则是
      // 在当前栏目中再解析“添加/编辑”。不能在 activateStep 之前因
      // 暂时找不到可见 trigger 而跳过，否则会直接得到 0/0。
      skipWhenUnavailable: false,
      saveText: ["保存并更新"],
      waitAfterSaveMs: 350,
      saveTimeoutMs: 6000,
      continueOnError: true,
      stopOnSaveError: true,
    }, options);
    return result;
  }

  function zhaopinEducationRank(row) {
    var level = String(row && (row.level || row.示例资料Level) || "").trim();
    // 博士研究生同时包含“研究生”，必须先判断博士。
    if (/博士/.test(level)) return 4;
    if (/硕士|研究生|MBA|EMBA/i.test(level)) return 3;
    if (/本科|学士|大学|双学位/.test(level)) return 2;
    if (/专科|大专/.test(level)) return 1;
    return 0;
  }

  function isZhaopinSupportedEducationRow(row) {
    // 智联承建的特殊站点不填高中/中专，从大专开始。
    return zhaopinEducationRank(row) > 0;
  }

  function compareZhaopinEducationRows(left, right) {
    var rankDiff = zhaopinEducationRank(left) - zhaopinEducationRank(right);
    if (rankDiff) return rankDiff;
    return String(left && left.startTime || "").localeCompare(String(right && right.startTime || ""));
  }

  function normalizeZhaopinEducationLevel(value) {
    var level = String(value || "").trim();
    if (/博士/.test(level)) return "博士";
    if (/MBA|EMBA/i.test(level)) return "MBA/EMBA";
    if (/硕士|研究生/.test(level)) return "硕士";
    if (/本科|学士|大学|双学位/.test(level)) return "本科";
    if (/专科|大专/.test(level)) return "大专";
    return level;
  }

  function enrichZhaopinEducationRow(row, index) {
    var result = Object.assign({}, row || {});
    var unifiedValue = result.isUnifiedAdmission || result.isUnified || result.fullTime;
    if (unifiedValue !== undefined && unifiedValue !== null && String(unifiedValue).trim() !== "") {
      result.zhaopinUnified = (isAffirmative(unifiedValue) || /^(?:统招|全日制)$/i.test(String(unifiedValue).trim())) ? "统招" : "非统招";
    } else {
      // 网页简历的通用字段是 示例资料Type，没有单独的
      // isUnifiedAdmission。智联页面需要把“全日制”转成“统招”。
      result.zhaopinUnified = /^(?:全日制|统招)$/i.test(String(result.示例资料Type || "").trim()) ? "统招" : "非统招";
    }
    result.zhaopinDegreeCertificate = result.degree && !/^无$/.test(String(result.degree)) ? "有" : "无";
    result.zhaopinOverseas = isAffirmative(result.isOverseas) ? "是" : "否";
    result.zhaopinLevel = normalizeZhaopinEducationLevel(result.level || result.示例资料Level);
    result.zhaopinEducationIndex = index;
    return result;
  }

  function enrichZhaopinWorkRow(row) {
    var result = Object.assign({}, row || {});
    result.zhaopinInternship = result.__afCategory === "示例资料Experience" ? "是" : "否";
    result.zhaopinWorkDescription = [
      result.responsibilities || result.detailedContent || result.description,
      result.achievements || result.contribution,
      result.result,
    ].filter(Boolean).join("\n");
    return enrichZhaopinTaxonomyFields(result);
  }

  function enrichZhaopinProjectRow(row) {
    var result = Object.assign({}, row || {});
    // 该页面把“项目、社会实践、校内活动”合并在同一个
    // 项目经历容器。campusActivities 的主字段是 activityName，
    // 必须转成该表单所需的 name，否则会新增空表单后因
    // “项目名称必填”停止。
    result.name = result.name || result.activityName || result.示例资料Name || "";
    var activityContext = [];
    if (result.__afCategory === "campusActivities") {
      if (result.practiceMode) activityContext.push("活动类型：" + result.practiceMode);
      if (result.role) activityContext.push("担任角色：" + result.role);
    }
    result.zhaopinProjectDescription = [
      activityContext.join("\n"),
      result.details || result.description || result.示例资料Description || result.background,
      result.responsibilities || result.duty || result.contribution,
      result.achievements || result.result,
    ].filter(Boolean).join("\n");
    return result;
  }

  function normalizeZhaopinLanguageProficiency(value) {
    var text = String(value || "").trim();
    if (/精通|母语/.test(text)) return "精通";
    if (/熟练|流利|高级/.test(text)) return "熟练";
    if (/良好|日常沟通|工作交流|中等|中级/.test(text)) return "良好";
    if (/一般|基础|入门|初级/.test(text)) return "一般";
    return "良好";
  }

  function enrichZhaopinLanguageRow(row) {
    var result = Object.assign({}, row || {});
    result.zhaopinLanguage = result.name || result.示例资料 || "";
    result.zhaopinSpeaking = normalizeZhaopinLanguageProficiency(
      result.speakingListening || result.speakingLevel || result.listeningSpeaking ||
      result.level || result.proficiency
    );
    result.zhaopinReading = normalizeZhaopinLanguageProficiency(
      result.readingWriting || result.readingWritingLevel || result.writingReading ||
      result.level || result.proficiency
    );
    return result;
  }

  // 智联校园企业模板的“语言情况”并不是通用的“语言种类 + 熟练度”
  // 重复行，而是一张固定英语考试汇总表。保持 canonical 示例资料Skills
  // 不变，只在站点适配层把 CET4/CET6/示例资料 拆到页面对应字段。
  function normalizeZhaopinCampusOtherEnglishExam(value) {
    var text = String(value || "").trim();
    if (/雅思|示例资料/i.test(text)) return "示例资料";
    if (/托福|TOEFL/i.test(text)) return "TOEFL";
    return text;
  }

  function enrichZhaopinCampusLanguageRow(row) {
    var result = enrichZhaopinLanguageRow(row);
    result.zhaopinCampusCet4Score = result.cet4Score || result.CET4Score || result.cet4 || "";
    result.zhaopinCampusCet6Score = result.cet6Score || result.CET6Score || result.cet6 || "";
    result.zhaopinCampusOtherEnglishExam = normalizeZhaopinCampusOtherEnglishExam(
      result.示例资料EnglishExam || result.certificateName || result.certificate
    );
    result.zhaopinCampusOtherEnglishScore =
      result.示例资料EnglishScore || result.ieltsScore ||
      (/示例资料/i.test(String(result.zhaopinCampusOtherEnglishExam || "")) ? result.score : "");
    return result;
  }

  function mergeZhaopinCertificateRows(rows) {
    var seen = {};
    return (rows || []).filter(function (row) {
      var name = String(row && (row.certificateName || row.certificate) || "").trim();
      if (!name) return false;
      var key = name.replace(/\s+/g, "").toLowerCase();
      if (seen[key]) return false;
      seen[key] = true;
      row.certificateName = name;
      return true;
    });
  }

  function enrichZhaopinBasicInfo(data) {
    var result = Object.assign({}, data || {});
    var identityText = String(
      result.currentIdentity || result.identity || result.currentStatus || result.jobStatus || ""
    ).trim();
    if (/学生|应届|在校/.test(identityText) || result.isFreshGraduate === "是") {
      result.zhaopinIdentity = "学生";
    } else if (/职场|社会|在职|离职|待业|工作/.test(identityText) || result.isFreshGraduate === "否") {
      result.zhaopinIdentity = "职场人";
    } else {
      result.zhaopinIdentity = "";
    }
    var birthMatch = String(result.birthDate || "").match(/(\d{4})[^\d]?(\d{1,2})/);
    result.zhaopinBirthMonth = birthMatch
      ? birthMatch[1] + "-" + String(Number(birthMatch[2])).padStart(2, "0")
      : "";
    result.zhaopinHukouPath = splitStoredAddressPath(result.hukouLocationPath) ||
      bankcommResidencePath(result.hukouLocation || result.birthOrigin || result.nativePlace);
    result.zhaopinCurrentAddressPath = splitStoredAddressPath(result.currentAddressPath) ||
      bankcommResidencePath(result.currentAddress || result.currentCity || result.city);
    var politicalText = String(result.politicalStatus || "").trim();
    result.zhaopinPoliticalStatus = /中共党员|预备党员/.test(politicalText)
      ? "中共党员（含预备党员）"
      : politicalText;
    return result;
  }

  // 保留旧版拼音转换函数供其它兼容字段使用；中国联通“姓名全拼”
  // 当前按需求固定复用中文姓名，实际映射见 zhaopinUnicomBasicFieldSequence。
  function zhaopinUnicomNamePinyin(value) {
    var text = String(value || "").trim();
    if (!text) return "";
    if (/^[A-Za-z][A-Za-z .'-]*$/.test(text)) return text.replace(/\s+/g, " ").trim();
    var map = { 小:"xiao", 李:"li", 王:"wang", 张:"zhang", 刘:"liu", 陈:"chen", 杨:"yang", 黄:"huang", 赵:"zhao", 吴:"wu", 周:"zhou", 徐:"xu", 孙:"sun", 胡:"hu", 朱:"zhu", 高:"gao", 林:"lin", 何:"he", 郭:"guo", 马:"ma", 罗:"luo", 梁:"liang", 宋:"song", 郑:"zheng", 谢:"xie", 韩:"han", 唐:"tang", 冯:"feng", 于:"yu", 董:"dong", 程:"cheng", 曹:"cao", 袁:"yuan", 邓:"deng", 许:"xu", 沈:"shen", 曾:"zeng", 彭:"peng", 吕:"lv", 苏:"su", 卢:"lu", 蒋:"jiang", 蔡:"cai", 贾:"jia", 丁:"ding", 魏:"wei", 薛:"xue", 叶:"ye", 阎:"yan", 余:"yu", 潘:"pan", 杜:"du", 戴:"dai", 夏:"xia", 钟:"zhong", 汪:"wang", 田:"tian", 任:"ren", 姜:"jiang", 范:"fan", 方:"fang", 石:"shi", 姚:"yao", 谭:"tan", 廖:"liao", 邹:"zou", 熊:"xiong", 金:"jin", 陆:"lu", 郝:"hao", 孔:"kong", 白:"bai", 崔:"cui", 康:"kang", 毛:"mao", 邱:"qiu", 秦:"qin", 江:"jiang", 史:"shi", 顾:"gu", 侯:"hou", 邵:"shao", 孟:"meng", 龙:"long", 万:"wan", 段:"duan", 雷:"lei", 钱:"qian", 汤:"tang", 尹:"yin", 黎:"li", 易:"yi", 常:"chang", 武:"wu", 乔:"qiao", 贺:"he", 赖:"lai", 龚:"gong", 文:"wen", 伟:"wei", 芳:"fang", 娜:"na", 静:"jing", 婷:"ting", 佳:"jia", 杰:"jie", 明:"ming", 超:"chao", 强:"qiang", 磊:"lei", 鹏:"peng", 鑫:"xin", 瑞:"rui", 莉:"li", 欣:"xin", 宇:"yu", 俊:"jun", 凯:"kai", 玲:"ling", 丹:"dan", 雪:"xue", 璐:"lu", 婷:"ting", 倩:"qian", 洋:"yang", 博:"bo", 诚:"cheng", 睿:"rui", 涛:"tao", 华:"hua", 成:"cheng", 斌:"bin", 宁:"ning", 敏:"min", 琳:"lin", 欣:"xin", 莹:"ying", 颖:"ying" };
    var chars = Array.from(text);
    var converted = chars.map(function (char) { return map[char] || (/^[A-Za-z0-9 -]$/.test(char) ? char : ""); });
    if (converted.some(function (part) { return !part; })) return "";
    return converted.join(" ").replace(/\s+/g, " ").trim();
  }

  function enrichZhaopinUnicomBasic(data) {
    var result = Object.assign({}, data || {});
    result.namePinyin = result.namePinyin || result.nameEnglish || zhaopinUnicomNamePinyin(result.name);
    var currentAddressPath = splitStoredAddressPath(result.currentAddressPath);
    result.zhaopinUnicomCurrentAddressPath = currentAddressPath && currentAddressPath.length >= 3
      ? currentAddressPath.slice(0, 3)
      : bankcommResidencePath(result.currentAddress || result.currentCity || result.city);
    var idNumber = String(result.idNumber || "").replace(/\s+/g, "");
    if (/^(?:\d{15}|\d{17}[\dXx])$/.test(idNumber)) result.idType = "身份证";
    return result;
  }

  function zhaopinUnicomBasicFieldSequence() {
    return [
      { label: "姓名", field: "name", type: "text" },
      { label: "证件号码类型", field: "idType", type: "zhaopinChoice" },
      { label: "证件号码", field: "idNumber", type: "text" },
      { label: "出生日期", field: "birthDate", type: "text" },
      { label: "性别", field: "gender", type: "zhaopinChoice" },
      // 中国联通页面该字段实际按姓名填写，固定复用中文姓名，不做拼音转换。
      { label: "姓名全拼", field: "name", type: "text" },
      { label: "民族", field: "ethnicity", type: "zhaopinChoice", optional: true },
      { label: "健康状况", field: "healthStatus", type: "zhaopinChoice", optional: true },
      { label: "婚姻状况", field: "maritalStatus", type: "zhaopinChoice", optional: true },
      { label: "政治面貌", field: "politicalStatus", type: "zhaopinChoice" },
      { label: "加入党团时间", field: "partyJoinDate", type: "text", optional: true },
      { label: "现居住城市", field: "zhaopinUnicomCurrentAddressPath", type: "zhaopinAdministrativeArea", triggerSelector: "#nowlocated_city", defaultFirstOnMissing: true },
      { label: "籍贯", field: "nativePlace", type: "zhaopinAdministrativeArea", triggerSelector: "#FIELD1002_city" },
      { label: "入学前户口所在地", field: "hukouLocation", type: "zhaopinAdministrativeArea", triggerSelector: "#hukou_city" },
      { label: "身高(cm)", field: "height", type: "text", optional: true },
      { label: "体重(kg)", field: "weight", type: "text", optional: true },
      { label: "手机号码", field: "phone", type: "zhaopinPhone" },
      { label: "电子邮箱", field: "email", type: "text" },
      { label: "通信地址", field: "currentAddress", type: "text", optional: true },
      { label: "紧急联系电话", field: "emergencyPhone", type: "text", optional: true },
    ];
  }

  function normalizeZhaopinPsbcPoliticalStatus(value) {
    var text = String(value || "").trim();
    if (/示例资料|^团员$/.test(text)) return "团员";
    if (/预备党员/.test(text)) return "中共预备党员";
    if (/中共党员|正式党员|中国共产党党员/.test(text)) return "中共正式党员";
    if (/民主党派|民革|民盟|民建|民进|农工党|致公党|九三学社|台盟/.test(text)) return "民主党派";
    if (/无党派/.test(text)) return "无党派人士";
    return text;
  }

  function normalizeZhaopinPsbcHealthStatus(value) {
    var text = String(value || "").trim();
    if (/^健康$/.test(text)) return "健康";
    if (/^良好$/.test(text)) return "良好";
    if (/病史|疾病|一般|较差/.test(text)) return "有病史";
    return text;
  }

  function normalizeZhaopinPsbcYesNo(value) {
    if (value === true || value === 1 || value === "1") return "是";
    if (value === false || value === 0 || value === "0") return "否";
    var text = String(value || "").trim();
    if (/^(?:是|有|接受|愿意)$/.test(text)) return "是";
    if (/^(?:否|无|不接受|不愿意)$/.test(text)) return "否";
    return text;
  }

  function zhaopinPsbcAddressPath(pathValue, displayValue) {
    return splitStoredAddressPath(pathValue) || bankcommResidencePath(displayValue);
  }

  function zhaopinPsbcFullAddress(pathValue, displayValue, detailValue) {
    var path = zhaopinPsbcAddressPath(pathValue, displayValue);
    var prefix = Array.isArray(path) ? path.join("") : "";
    var display = String(displayValue || "").replace(/\s*\/\s*/g, "").trim();
    var detail = String(detailValue || "").trim();
    if (detail && ((prefix && detail.indexOf(prefix) === 0) || (display && detail.indexOf(display) === 0))) return detail;
    return [prefix || display, detail].filter(Boolean).join("");
  }

  function enrichZhaopinPsbcBasic(data) {
    var result = Object.assign({}, data || {});
    var idNumber = String(result.idNumber || "").replace(/\s+/g, "");
    var idType = String(result.idType || "").trim();
    result.zhaopinPsbcIdType = /身份证/.test(idType) || /^(?:\d{15}|\d{17}[\dXx])$/.test(idNumber) ? "身份证" : idType;
    result.zhaopinPsbcPoliticalStatus = normalizeZhaopinPsbcPoliticalStatus(result.politicalStatus);
    result.zhaopinPsbcHealthStatus = normalizeZhaopinPsbcHealthStatus(result.healthStatus);
    result.zhaopinPsbcCountry = /中国|中华人民共和国/.test(String(result.country || ""))
      ? "中国"
      : (result.country ? "其他国籍" : "");
    result.zhaopinPsbcCurrentAddressPath = zhaopinPsbcAddressPath(result.currentAddressPath, result.currentAddress);
    result.zhaopinPsbcNativePlacePath = zhaopinPsbcAddressPath(result.nativePlacePath, result.nativePlace);
    result.zhaopinPsbcBirthOriginPath = zhaopinPsbcAddressPath(result.birthOriginPath, result.birthOrigin || result.hukouLocation);
    result.zhaopinPsbcAcceptAdjustment = normalizeZhaopinPsbcYesNo(result.acceptPositionAdjustment);
    result.zhaopinPsbcPoorStudent = normalizeZhaopinPsbcYesNo(result.isPoorStudent);
    result.zhaopinPsbcCommunicationAddress = zhaopinPsbcFullAddress(result.currentAddressPath, result.currentAddress, result.currentAddressDetail);
    result.zhaopinPsbcFamilyAddress = result.示例资料Address || zhaopinPsbcFullAddress(
      result.示例资料LocationPath,
      result.示例资料Location,
      result.示例资料LocationDetail
    );
    return result;
  }

  function zhaopinPsbcBasicFieldSequence() {
    return [
      { label: "姓名", field: "name", type: "text" },
      { label: "证件号码类型", field: "zhaopinPsbcIdType", type: "zhaopinChoice" },
      { label: "证件号码", field: "idNumber", type: "text" },
      { label: "出生日期", field: "birthDate", type: "elementDate" },
      { label: "性别", field: "gender", type: "zhaopinChoice" },
      { label: "民族", field: "ethnicity", type: "zhaopinChoice" },
      { label: "健康状况", field: "zhaopinPsbcHealthStatus", type: "zhaopinChoice" },
      { label: "婚姻状况", field: "maritalStatus", type: "zhaopinChoice" },
      { label: "政治面貌", field: "zhaopinPsbcPoliticalStatus", type: "zhaopinChoice" },
      { label: "现居住城市", field: "zhaopinPsbcCurrentAddressPath", type: "zhaopinAdministrativeArea", triggerSelector: "#nowlocated_city" },
      { label: "籍贯", field: "zhaopinPsbcNativePlacePath", type: "zhaopinAdministrativeArea", triggerSelector: "#FIELD1000_city" },
      { label: "国籍", field: "zhaopinPsbcCountry", type: "zhaopinChoice" },
      { label: "高考前户口所在地（生源地）", field: "zhaopinPsbcBirthOriginPath", type: "zhaopinAdministrativeArea", triggerSelector: "#hukou_city" },
      { label: "最高学历预计毕业时间", field: "graduationDate", type: "elementDate" },
      { label: "身高(cm）", field: "height", type: "text" },
      { label: "体重（kg）", field: "weight", type: "text" },
      { label: "是否接受岗位调剂", field: "zhaopinPsbcAcceptAdjustment", type: "zhaopinChoice" },
      { label: "请选择您的笔试意向城市", field: "writtenExamCity", type: "zhaopinChoice" },
      { label: "是否贫困生", field: "zhaopinPsbcPoorStudent", type: "zhaopinChoice" },
      { label: "手机号码", field: "phone", type: "zhaopinPhone" },
      { label: "电子邮箱", field: "email", type: "text" },
      { label: "邮政编码", field: "postalCode", type: "text", optional: true },
      { label: "通信地址", field: "zhaopinPsbcCommunicationAddress", type: "text" },
      { label: "家庭地址", field: "zhaopinPsbcFamilyAddress", type: "text" },
      { label: "紧急联系人", field: "emergencyContactName", type: "text" },
      { label: "紧急联系人与本人关系", field: "emergencyContactRelation", type: "text" },
      { label: "紧急联系电话", field: "emergencyPhone", type: "text" },
    ];
  }

  function zhaopinPsbcParent(rows, relationship) {
    var list = Array.isArray(rows) ? rows : [];
    var pattern = relationship === "父亲" ? /^(?:父亲|父|爸爸)$/ : /^(?:母亲|母|妈妈)$/;
    return list.find(function (row) {
      return pattern.test(String(row && (row.relationship || row.relation || row.relationshipCategory) || "").trim());
    }) || {};
  }

  function normalizeZhaopinPsbcFamilyPoliticalStatus(value) {
    var normalized = normalizeZhaopinPsbcPoliticalStatus(value);
    return normalized === "中共正式党员" ? "中共党员" : normalized;
  }

  // 邮储“家庭关系”把父母字段固定铺在一张表里，不能按常规家庭成员数组
  // 逐条新增。这里仅生成站点派生字段，不修改用户保存的家庭成员数据。
  function enrichZhaopinPsbcFamily(data, resume) {
    var rows = resume && Array.isArray(resume.示例资料Members) ? resume.示例资料Members : [];
    var father = zhaopinPsbcParent(rows, "父亲");
    var m示例资料 = zhaopinPsbcParent(rows, "母亲");
    return {
      zhaopinPsbcFatherName: father.name || "",
      zhaopinPsbcFatherAge: father.age || "",
      zhaopinPsbcFatherCompany: father.company || father.organization || "",
      zhaopinPsbcFatherPosition: father.position || father.title || "",
      zhaopinPsbcFatherPhone: father.phone || father.mobile || "",
      zhaopinPsbcFatherPoliticalStatus: normalizeZhaopinPsbcFamilyPoliticalStatus(father.politicalStatus),
      zhaopinPsbcFatherBankEmployee: "否",
      zhaopinPsbcFatherPostEmployee: "否",
      zhaopinPsbcM示例资料Name: m示例资料.name || "",
      zhaopinPsbcM示例资料Age: m示例资料.age || "",
      zhaopinPsbcM示例资料Company: m示例资料.company || m示例资料.organization || "",
      zhaopinPsbcM示例资料Position: m示例资料.position || m示例资料.title || "",
      zhaopinPsbcM示例资料Phone: m示例资料.phone || m示例资料.mobile || "",
      zhaopinPsbcM示例资料PoliticalStatus: normalizeZhaopinPsbcFamilyPoliticalStatus(m示例资料.politicalStatus),
      zhaopinPsbcM示例资料BankEmployee: "否",
      zhaopinPsbcM示例资料PostEmployee: "否",
    };
  }

  function zhaopinPsbcFamilyFieldSequence() {
    return [
      { label: "姓名-父亲", field: "zhaopinPsbcFatherName", type: "text" },
      { label: "年龄-父亲", field: "zhaopinPsbcFatherAge", type: "text" },
      { label: "工作单位-父亲", field: "zhaopinPsbcFatherCompany", type: "text" },
      { label: "职位-父亲", field: "zhaopinPsbcFatherPosition", type: "text" },
      { label: "联系电话-父亲", field: "zhaopinPsbcFatherPhone", type: "text" },
      { label: "政治面貌-父亲", field: "zhaopinPsbcFatherPoliticalStatus", type: "zhaopinChoice" },
      { label: "父亲是否为邮储银行体系内单位员工", field: "zhaopinPsbcFatherBankEmployee", type: "zhaopinChoice", labelExact: true, verifySelection: true, retryCount: 2 },
      { label: "父亲是否为邮政体系内（不含邮储银行）单位员工", field: "zhaopinPsbcFatherPostEmployee", type: "zhaopinChoice", labelExact: true, verifySelection: true, retryCount: 2 },
      { label: "姓名-母亲", field: "zhaopinPsbcM示例资料Name", type: "text" },
      { label: "年龄-母亲", field: "zhaopinPsbcM示例资料Age", type: "text" },
      { label: "工作单位-母亲", field: "zhaopinPsbcM示例资料Company", type: "text" },
      { label: "职务-母亲", field: "zhaopinPsbcM示例资料Position", type: "text" },
      { label: "联系电话-母亲", field: "zhaopinPsbcM示例资料Phone", type: "text" },
      { label: "政治面貌-母亲", field: "zhaopinPsbcM示例资料PoliticalStatus", type: "zhaopinChoice" },
      { label: "母亲是否为邮储银行体系内单位员工", field: "zhaopinPsbcM示例资料BankEmployee", type: "zhaopinChoice", labelExact: true, verifySelection: true, retryCount: 2 },
      { label: "母亲是否为邮政体系内（不含邮储银行）单位员工", field: "zhaopinPsbcM示例资料PostEmployee", type: "zhaopinChoice", labelExact: true, verifySelection: true, retryCount: 3, waitAfterSelectMs: 300, commitTimeoutMs: 1600, waitAfterMs: 300 },
    ];
  }

  function isZhaopinPsbcEducationRow(row) {
    var level = String(row && (row.level || row.示例资料Level) || "").trim();
    return zhaopinEducationRank(row) > 0 || /高中|中专|职高|技校/.test(level);
  }

  function compareZhaopinPsbcEducationRows(left, right) {
    var rankDiff = zhaopinEducationRank(right) - zhaopinEducationRank(left);
    if (rankDiff) return rankDiff;
    return String(right && right.startTime || "").localeCompare(String(left && left.startTime || ""));
  }

  function normalizeZhaopinPsbcStudyLength(value, startTime, endTime) {
    var text = String(value || "").trim();
    var numberMatch = text.match(/([1-5一二三四五])\s*年/);
    var numberMap = { "1": "一", "2": "二", "3": "三", "4": "四", "5": "五" };
    if (numberMatch) return (numberMap[numberMatch[1]] || numberMatch[1]) + "年制";
    var startYear = Number(String(startTime || "").match(/\d{4}/));
    var endYear = Number(String(endTime || "").match(/\d{4}/));
    var years = endYear > startYear ? endYear - startYear : 0;
    return years >= 1 && years <= 5 ? numberMap[String(years)] + "年制" : "其他";
  }

  function normalizeZhaopinPsbcEducationType(row) {
    var text = [row && row.示例资料Type, row && row.studyMode, row && row.isOverseas].filter(Boolean).join(" ");
    if (/海外|留学|境外/.test(text) || isAffirmative(row && row.isOverseas)) return "海外留学";
    if (/非全日制|非统招|成人|自考|函授|在职/.test(text)) return "非全日制统分统招";
    if (/全日制|统招/.test(text)) return "全日制统分统招";
    return "其他";
  }

  function normalizeZhaopinPsbcSecondDegree(row) {
    var explicit = String(row && row.secondDegreeOrMinor || "").trim();
    if (/辅修/.test(explicit)) return "辅修";
    if (/第二学位|双学位/.test(explicit)) return "第二学位";
    return isAffirmative(row && row.isDoubleDegree) ? "第二学位" : "无";
  }

  function normalizeZhaopinPsbcOverseasStudy(row) {
    var value = row && row.hasOverseasStudy;
    if (value !== undefined && value !== null && String(value).trim() !== "") {
      return isAffirmative(value) ? "有" : "无";
    }
    return isAffirmative(row && row.isOverseas) ? "有" : "无";
  }

  function isZhaopinPsbcHigherEducation(row) {
    return !/高中|中专|职高|技校/.test(String(row && (row.zhaopinPsbcEducationLevel || row.level || row.示例资料Level || "")));
  }

  function isZhaopinPsbcBachelorEducation(row) {
    return String(row && row.zhaopinPsbcEducationLevel || "").trim() === "本科";
  }

  function isZhaopinPsbcHighSchoolRow(row) {
    return /高中|中专|职高|技校/.test(String(row && (row.zhaopinPsbcEducationLevel || row.level || row.示例资料Level || "")));
  }

  function enrichZhaopinPsbcEducation(row) {
    var result = Object.assign({}, row || {});
    var level = String(result.level || result.示例资料Level || "");
    result.zhaopinPsbcEducationLevel = /博士/.test(level) ? "博士研究生"
      : /MBA|EMBA/i.test(level) ? "硕士研究生"
      : /硕士|研究生/.test(level) ? "硕士研究生"
      : /本科|学士|大学|双学位/.test(level) ? "本科"
      : /专科|大专/.test(level) ? "大专"
      : /高中|中专|职高|技校/.test(level) ? "高中" : level;
    result.zhaopinPsbcDegree = /高中|中专|职高|技校|专科|大专/.test(level)
      ? "无"
      : (/MBA|EMBA/i.test([result.degree, level].filter(Boolean).join(" "))
        ? "硕士"
        : normalizeZhaopinUnicomDegree(result.degree, level));
    result.zhaopinPsbcDiscipline = normalizeZhaopinUnicomDiscipline(result);
    result.zhaopinPsbcStudyLength = normalizeZhaopinPsbcStudyLength(result.studyLength, result.startTime, result.endTime);
    result.zhaopinPsbcEducationType = normalizeZhaopinPsbcEducationType(result);
    var upgradedValue = [result.isAssociateUpgrade, result.isUpgraded, result.associateUpgrade].find(function (value) {
      return value !== undefined && value !== null && String(value).trim() !== "";
    });
    result.zhaopinPsbcAssociateUpgrade = upgradedValue !== undefined
      ? (isAffirmative(upgradedValue) ? "是" : "否")
      : (/专升本/.test([level, result.示例资料Type, result.studyMode, result.description].filter(Boolean).join(" ")) ? "是" : "否");
    result.zhaopinPsbcDepartment = result.department || result.college || result.faculty || result.academy || result.schoolDepartment || "无";
    result.zhaopinPsbcMajor = result.major || result.majorName || result.speciality || "";
    result.zhaopinPsbcMajorCourses = result.majorCourses || result.mainCourses || result.coreCourses || "";
    result.zhaopinPsbcHasOverseasStudy = normalizeZhaopinPsbcOverseasStudy(result);
    result.zhaopinPsbcSecondDegree = normalizeZhaopinPsbcSecondDegree(result);
    return result;
  }

  function zhaopinPsbcEducationFieldSequence() {
    return [
      { label: "学历", field: "zhaopinPsbcEducationLevel", type: "zhaopinChoice", useElementChoiceFirst: true, verifySelection: true, retryCount: 2, waitAfterSelectMs: 300, requireLabel: true },
      { label: "研究方向", field: "researchDirection", type: "text", optional: true },
      { label: "是否专升本", field: "zhaopinPsbcAssociateUpgrade", type: "zhaopinChoice", useElementChoiceFirst: true, verifySelection: true, retryCount: 2, requireLabel: true, when: isZhaopinPsbcBachelorEducation },
      { label: "院系", field: "zhaopinPsbcDepartment", type: "text", requireLabel: true, when: isZhaopinPsbcHigherEducation },
      { label: "专业", field: "zhaopinPsbcMajor", type: "zhaopinSearchSelect", inputSelector: "input[placeholder='请填写专业名称']", openBeforeInput: true, waitForEditableInputMs: 1600, searchWaitMs: 520, optionTimeoutMs: 5000, waitAfterSelectMs: 300, fallbackToFirstOption: true, requireLabel: true, when: isZhaopinPsbcHigherEducation },
      { label: "专业课程", field: "zhaopinPsbcMajorCourses", type: "text", optional: true, when: isZhaopinPsbcHigherEducation },
      { label: "学位", field: "zhaopinPsbcDegree", type: "zhaopinChoice", useElementChoiceFirst: true, verifySelection: true, retryCount: 2, requireLabel: true },
      { label: "请选择该段示例资料学位所属学科门类", field: "zhaopinPsbcDiscipline", type: "zhaopinChoice", useElementChoiceFirst: true, verifySelection: true, retryCount: 2, requireLabel: true },
      { label: "学制", field: "zhaopinPsbcStudyLength", type: "zhaopinChoice", useElementChoiceFirst: true, verifySelection: true, retryCount: 2, requireLabel: true },
      { label: "受教育类型", field: "zhaopinPsbcEducationType", type: "zhaopinChoice", useElementChoiceFirst: true, verifySelection: true, retryCount: 2, requireLabel: true },
      // 邮储智联当前示例资料使用 readonly 的 Element month picker。
      // 直接写 input.value 会被组件忽略，因此允许走真实月份面板：
      // 打开面板 -> 选年份 -> 选月份 -> 读取 input 回填值验证。
      { label: "入学时间", field: "startTime", type: "elementDate", requireLabel: true, allowElementMonthPanel: true, forceElementMonthPanel: true, panelTimeoutMs: 3500, yearPanelTimeoutMs: 1200, monthPanelTimeoutMs: 1200, monthTimeoutMs: 2200, monthCommitTimeoutMs: 1400, waitAfterSelectMs: 420 },
      { label: "毕业时间", field: "endTime", type: "elementDate", requireLabel: true, allowElementMonthPanel: true, forceElementMonthPanel: true, panelTimeoutMs: 3500, yearPanelTimeoutMs: 1200, monthPanelTimeoutMs: 1200, monthTimeoutMs: 2200, monthCommitTimeoutMs: 1400, waitAfterSelectMs: 420 },
      { label: "该段示例资料内是否有国外、港澳台地区学习经历", field: "zhaopinPsbcHasOverseasStudy", type: "zhaopinChoice", useElementChoiceFirst: true, verifySelection: true, retryCount: 2, requireLabel: true },
      { label: "该段学历是否有第二学位或辅修专业", field: "zhaopinPsbcSecondDegree", type: "zhaopinChoice", useElementChoiceFirst: true, verifySelection: true, retryCount: 2, requireLabel: true },
      // 学校名称是邮储远程 el-select；高中还可能进入“手动添加”弹窗。
      // 放在本条示例资料末尾，避免学校库搜索失败/弹层残留挡住后续必填下拉。
      { label: "学校名称", field: "school", type: "zhaopinSchoolSelect", exactSchoolMatch: true, requireLabel: true, optional: true, when: isZhaopinPsbcHigherEducation },
      { label: "学校名称", field: "school", type: "zhaopinPsbcHighSchoolSelect", selector: ".apply-form-school .el-select .el-input__inner", fallbackToFirstOption: true, waitAfterSelectMs: 300, requireLabel: true, optional: true, when: isZhaopinPsbcHighSchoolRow },
    ];
  }

  function zhaopinPsbcEducationBeforeSaveFields() {
    return zhaopinPsbcEducationFieldSequence().filter(function (item) {
      return item.optional !== true;
    });
  }

  function zhaopinPsbcCompactText(value) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
  }

  function zhaopinPsbcCampusDate(startTime, endTime) {
    var start = zhaopinPsbcCompactText(startTime);
    var end = zhaopinPsbcCompactText(endTime);
    if (start && end) return start + "至" + end;
    return start || end || "无";
  }

  function zhaopinPsbcCampusSummary(rows, formatter) {
    var entries = (Array.isArray(rows) ? rows : []).map(function (row, index) {
      var item = formatter(row || {});
      var name = zhaopinPsbcCompactText(item.name) || "未填写名称";
      var time = zhaopinPsbcCompactText(item.time) || "无";
      var content = (Array.isArray(item.content) ? item.content : [item.content])
        .map(zhaopinPsbcCompactText).filter(Boolean).join("；") || "无";
      return (index + 1) + ". 名称：" + name + "；时间：" + time + "；主要内容：" + content;
    }).filter(Boolean);
    if (!entries.length) return "无";
    var result = entries.join("\n");
    return result.length <= 500 ? result : result.slice(0, 499) + "…";
  }

  function isZhaopinPsbcCompetition(row) {
    return /竞赛获奖|学科竞赛|产品竞赛|创新创业|大赛|竞赛|比赛/.test([
      row && row.awardClass, row && row.awardCategory, row && row.awardName,
      row && row.competitionExperience,
    ].filter(Boolean).join(" "));
  }

  function enrichZhaopinPsbcCampusExperience(_, resume) {
    resume = resume || {};
    var activities = Array.isArray(resume.campusActivities) ? resume.campusActivities : [];
    var competitions = (Array.isArray(resume.示例资料) ? resume.示例资料 : []).filter(isZhaopinPsbcCompetition);
    var 示例资料s = Array.isArray(resume.示例资料Experience) ? resume.示例资料Experience : [];
    var publications = (Array.isArray(resume.publications) ? resume.publications : []).map(function (row) {
      return Object.assign({ zhaopinPsbcResultType: "论文/著作" }, row || {});
    });
    var 示例资料s = (Array.isArray(resume.示例资料s) ? resume.示例资料s : []).map(function (row) {
      return Object.assign({ zhaopinPsbcResultType: "专利" }, row || {});
    });

    return {
      zhaopinPsbcCampusWork: zhaopinPsbcCampusSummary(activities, function (row) {
        return {
          name: row.activityName || row.name || row.示例资料Name,
          time: zhaopinPsbcCampusDate(row.startTime, row.endTime),
          content: [row.role, row.practiceMode, row.description || row.details],
        };
      }),
      zhaopinPsbcCampusCompetition: zhaopinPsbcCampusSummary(competitions, function (row) {
        return {
          name: row.awardName || row.name || row.competitionExperience,
          time: row.awardTime || row.time,
          content: [row.awardLevel, row.awardGrade, row.awardIssuer, row.awardDescription || row.competitionExperience],
        };
      }),
      zhaopinPsbcResearchProject: zhaopinPsbcCampusSummary(示例资料s, function (row) {
        return {
          name: row.name || row.示例资料Name,
          time: zhaopinPsbcCampusDate(row.startTime, row.endTime),
          content: [row.role, row.company, row.details || row.description, row.contributions || row.responsibilities, row.result, row.techStack],
        };
      }),
      zhaopinPsbcPublicationPatent: zhaopinPsbcCampusSummary(publications.concat(示例资料s), function (row) {
        var isPatent = row.zhaopinPsbcResultType === "专利";
        return {
          name: "[" + row.zhaopinPsbcResultType + "] " + (isPatent
            ? (row.示例资料Name || row.name || "")
            : (row.paperTitle || row.articleTitle || row.publicationTitle || row.name || "")),
          time: isPatent
            ? zhaopinPsbcCampusDate(row.applicationDate, row.authorizationDate || row.grantDate)
            : (row.publishTime || row.publishYear),
          content: isPatent
            ? [row.示例资料Type, row.示例资料Number, row.description]
            : [row.journal, row.publicationLevel, row.contribution, row.paperLink],
        };
      }),
    };
  }

  function zhaopinPsbcCampusExperienceFieldSequence() {
    return [
      { label: "校园示例资料（学生干部经历、学生会工作、社团骨干等）", field: "zhaopinPsbcCampusWork", type: "text", labelExact: true },
      { label: "校园大赛经历", field: "zhaopinPsbcCampusCompetition", type: "text", labelExact: true },
      { label: "科研项目经历", field: "zhaopinPsbcResearchProject", type: "text", labelExact: true },
      { label: "出版论著、专利设计经历", field: "zhaopinPsbcPublicationPatent", type: "text", labelExact: true },
    ];
  }

  function enrichZhaopinPsbcWork(row) {
    var result = enrichZhaopinWorkRow(row);
    var 示例资料Type = String(result.示例资料Type || result.employmentType || result.jobNature || "");
    result.zhaopinPsbcWorkType = result.__afCategory === "示例资料Experience" || /实习/.test(示例资料Type)
      ? "实习"
      : (/兼职/.test(示例资料Type) ? "兼职" : "全职");
    result.zhaopinPsbcWorkDescription = zhaopinPsbcCompactText(result.zhaopinWorkDescription);
    if (result.zhaopinPsbcWorkDescription.length > 500) {
      result.zhaopinPsbcWorkDescription = result.zhaopinPsbcWorkDescription.slice(0, 499) + "…";
    }
    result.zhaopinPsbcSalary = result.currentSalary || result.monthlySalary || result.salary || result.custom_income || "";
    result.zhaopinPsbcHasReference = "否";
    return result;
  }

  function compareZhaopinPsbcWorkRows(left, right) {
    return String(right && right.startTime || "").localeCompare(String(left && left.startTime || ""));
  }

  function zhaopinPsbcWorkFieldSequence() {
    return [
      { label: "工作类型", field: "zhaopinPsbcWorkType", type: "zhaopinChoice", verifySelection: true, retryCount: 2 },
      { label: "工作单位", field: "company", type: "text" },
      { label: "职务", field: "position", type: "text" },
      { label: "入职时间", field: "startTime", type: "elementDate" },
      { label: "离职时间", field: "endTime", type: "elementDate" },
      { label: "主要工作职责和业绩", field: "zhaopinPsbcWorkDescription", type: "text" },
      { label: "职位月薪(税前)", field: "zhaopinPsbcSalary", type: "text", optional: true },
      { label: "是否有证明人", field: "zhaopinPsbcHasReference", type: "zhaopinChoice", verifySelection: true, retryCount: 2, optional: true },
    ];
  }

  function zhaopinPsbcNumberedDetailLines(rows, nameFields, dateFields, descriptionFields) {
    var lines = (Array.isArray(rows) ? rows : []).map(function (row, index) {
      row = row || {};
      var name = (nameFields || []).map(function (field) { return zhaopinPsbcCompactText(row[field]); }).find(Boolean) || "未填写名称";
      var date = (dateFields || []).map(function (field) { return zhaopinPsbcCompactText(row[field]); }).find(Boolean) || "无";
      var description = (descriptionFields || []).map(function (field) { return zhaopinPsbcCompactText(row[field]); }).find(Boolean) || "无";
      return (index + 1) + ". 名称：" + name + "；时间：" + date + "；描述：" + description;
    });
    if (!lines.length) return "无";
    var result = lines.join("\n");
    return result.length <= 1000 ? result : result.slice(0, 999) + "…";
  }

  function enrichZhaopinPsbcRewards(_, resume) {
    resume = resume || {};
    return {
      zhaopinPsbcAwards: zhaopinPsbcNumberedDetailLines(
        resume.示例资料,
        ["awardName", "award", "honorName", "name", "title"],
        ["awardTime", "awardDate", "obtainedTime", "time", "date"],
        ["awardDescription", "description", "content", "detail", "result"]
      ),
      zhaopinPsbcCertificates: zhaopinPsbcNumberedDetailLines(
        resume.示例资料,
        ["certificateName", "certificate", "name", "title"],
        ["obtainedTime", "certificateTime", "issueDate", "time", "date"],
        ["certificateDescription", "description", "content", "detail"]
      ),
    };
  }

  function zhaopinPsbcRewardFieldSequence() {
    return [
      { label: "受到奖励", field: "zhaopinPsbcAwards", type: "text", labelExact: true },
      { label: "专业资格证书", field: "zhaopinPsbcCertificates", type: "text", labelExact: true },
    ];
  }

  function zhaopinPsbcCetScore(rows, level) {
    var 示例资料s = Array.isArray(rows) ? rows : [];
    var record = 示例资料s.find(function (row) {
      row = row || {};
      var certificate = [row.certificate, row.certificateName, row.certificateLevel, row.level]
        .map(zhaopinPsbcCompactText).filter(Boolean).join(" ");
      var 示例资料 = zhaopinPsbcCompactText(row.name || row.示例资料);
      if (level === 6) {
        return /CET\s*[-－]?\s*6|大学英语六级|英语六级/i.test(certificate) ||
          (/英语/i.test(示例资料) && /^(?:六级|6级)$/i.test(certificate));
      }
      return /CET\s*[-－]?\s*4|大学英语四级|英语四级/i.test(certificate) ||
        (/英语/i.test(示例资料) && /^(?:四级|4级)$/i.test(certificate));
    });
    var score = zhaopinPsbcCompactText(record && record.score);
    return score ? score.slice(0, 5) : "无";
  }

  function enrichZhaopinPsbcSkills(_, resume) {
    resume = resume || {};
    return {
      zhaopinPsbcCet4: zhaopinPsbcCetScore(resume.示例资料Skills, 4),
      zhaopinPsbcCet6: zhaopinPsbcCetScore(resume.示例资料Skills, 6),
      zhaopinPsbcTem4: "无",
      zhaopinPsbcTem8: "无",
      zhaopinPsbcToeflIelts: "无",
      zhaopinPsbcOtherLanguageCertificate: "无",
      zhaopinPsbcComputerSkill: "无",
      zhaopinPsbcOtherSkill: "无",
      zhaopinPsbcHobby: "无",
    };
  }

  function zhaopinPsbcSkillFieldSequence() {
    return [
      { label: "CET-4成绩", field: "zhaopinPsbcCet4", type: "text", labelExact: true },
      { label: "CET-6成绩", field: "zhaopinPsbcCet6", type: "text", labelExact: true },
      { label: "TEM-4成绩", field: "zhaopinPsbcTem4", type: "text", labelExact: true },
      { label: "TEM-8成绩", field: "zhaopinPsbcTem8", type: "text", labelExact: true },
      { label: "TOEFL iBT/示例资料成绩", field: "zhaopinPsbcToeflIelts", type: "text", labelExact: true },
      { label: "其他语言证书", field: "zhaopinPsbcOtherLanguageCertificate", type: "zhaopinChoice", labelExact: true, verifySelection: true, retryCount: 2 },
      { label: "计算机技能", field: "zhaopinPsbcComputerSkill", type: "text", labelExact: true },
      { label: "其他技能", field: "zhaopinPsbcOtherSkill", type: "text", labelExact: true },
      { label: "个人爱好", field: "zhaopinPsbcHobby", type: "text", labelExact: true },
    ];
  }

  function enrichZhaopinPsbcSelfEvaluation(data, resume) {
    var intro = resume && resume.示例资料Introduction;
    var value = intro && typeof intro === "object" && !Array.isArray(intro)
      ? (intro.示例资料Introduction || intro.示例资料Evaluation || intro.summary || intro.description || intro.content)
      : (typeof intro === "string" ? intro : "");
    value = zhaopinPsbcCompactText(value || data && (
      data.示例资料Introduction || data.示例资料Evaluation || data.summary || data.description || data.content
    ));
    return {
      zhaopinPsbcSelfEvaluation: value.length <= 1000 ? value : value.slice(0, 999) + "…",
    };
  }

  function zhaopinPsbcSelfEvaluationFieldSequence() {
    return [
      { label: "内容", field: "zhaopinPsbcSelfEvaluation", type: "text", labelExact: true },
    ];
  }

  function zhaopinMobileBasicFieldSequence() {
    return [
      { label: "姓名", field: "name", type: "text" },
      { label: "证件号码类型", field: "idType", type: "zhaopinChoice" },
      { label: "证件号码", field: "idNumber", type: "text" },
      { label: "出生日期", field: "birthDate", type: "text" },
      { label: "性别", field: "gender", type: "zhaopinChoice" },
      { label: "民族", field: "ethnicity", type: "zhaopinChoice" },
      { label: "年龄", field: "age", type: "text", optional: true },
      { label: "出生地", field: "birthOrigin", type: "text", optional: true },
      { label: "身高(cm)", field: "height", type: "text", optional: true },
      { label: "体重(kg)", field: "weight", type: "text", optional: true },
      { label: "籍贯", field: "nativePlace", type: "zhaopinAdministrativeArea", optional: true },
      { label: "是否北京户口", field: "mobileBeijingHukou", type: "zhaopinChoice", optional: true },
      { label: "健康状况", field: "healthStatus", type: "zhaopinChoice", optional: true },
      { label: "婚姻状况", field: "maritalStatus", type: "zhaopinChoice", optional: true },
      { label: "入党团时间", field: "partyJoinDate", type: "text", optional: true },
      { label: "政治面貌", field: "politicalStatus", type: "zhaopinChoice" },
      { label: "高考生源地", field: "birthOrigin", type: "zhaopinAdministrativeArea", optional: true },
      { label: "户口所在地", field: "hukouLocation", type: "zhaopinAdministrativeArea", optional: true },
      { label: "现居住城市", field: "currentAddress", type: "zhaopinAdministrativeArea", optional: true },
      { label: "拟取得学位时间", field: "graduationDate", type: "text", optional: true },
      { label: "全日制最高学历", field: "highestEducation", type: "zhaopinChoice", optional: true },
      { label: "期望薪资范围（税前月薪）", field: "expectedSalary", type: "zhaopinChoice", optional: true },
      { label: "手机号码", field: "phone", type: "zhaopinPhone" },
      { label: "电子邮箱", field: "email", type: "text" },
      { label: "通信地址", field: "currentAddress", type: "text", optional: true },
      { label: "紧急联系电话", field: "emergencyPhone", type: "text", optional: true },
      { label: "紧急联系人关系", field: "emergencyContactRelation", type: "zhaopinChoice", optional: true },
      { label: "紧急联系人姓名", field: "emergencyContactName", type: "text", optional: true },
    ];
  }

  function normalizeZhaopinUnicomRank(value) {
    var text = String(value || "").replace(/\s+/g, "");
    var exact = ["前10%", "10%-20%", "20%-30%", "30%-40%", "40%-50%", "50%-60%", "60%-70%", "70%-80%", "后20%"];
    if (exact.indexOf(text) !== -1) return text;
    var match = text.match(/前(\d+(?:\.\d+)?)%/);
    if (!match) return text;
    var percent = Number(match[1]);
    if (percent <= 10) return "前10%";
    if (percent <= 20) return "10%-20%";
    if (percent <= 30) return "20%-30%";
    if (percent <= 40) return "30%-40%";
    if (percent <= 50) return "40%-50%";
    if (percent <= 60) return "50%-60%";
    if (percent <= 70) return "60%-70%";
    if (percent <= 80) return "70%-80%";
    return "后20%";
  }

  function normalizeZhaopinUnicomDegree(value, level) {
    var text = String(value || "") + " " + String(level || "");
    if (/博士/.test(text)) return "博士";
    if (/MBA|EMBA/i.test(text)) return "MBA";
    if (/硕士|研究生/.test(text)) return "硕士";
    if (/双学士|双学位/.test(text)) return "双学士";
    if (/学士|本科/.test(text)) return "学士";
    if (/无学位|未取得|^\s*$/.test(text)) return "无";
    return "其他";
  }

  function normalizeZhaopinUnicomDiscipline(row) {
    // 联通页面名为“学位类型”，实际枚举是学科门类，不能使用简历中
    // 表示“学术硕士/专业硕士”的 degreeType。
    var text = [row && row.majorCategory, row && row.degree].filter(Boolean).join(" ");
    // “管理学”包含“理学”两个字，必须先匹配长词/完整学科，避免误选理学。
    var disciplines = ["管理学", "经济学", "教育学", "历史学", "军事学", "哲学", "法学", "文学", "理学", "工学", "农学", "医学"];
    return disciplines.find(function (item) { return text.indexOf(item) !== -1; }) || "其他";
  }

  function enrichZhaopinUnicomEducation(row) {
    var result = Object.assign({}, row || {});
    var level = String(result.level || result.示例资料Level || "");
    result.zhaopinUnicomLevel = /博士/.test(level) ? "博士研究生"
      : /MBA|EMBA/i.test(level) ? "MBA/EMBA"
      : /硕士|研究生/.test(level) ? "硕士研究生"
      : /本科|学士|大学/.test(level) ? "本科"
      : /专科|大专/.test(level) ? "大专" : level;
    result.zhaopinUnicomRank = normalizeZhaopinUnicomRank(result.classRank);
    result.zhaopinUnicomDegree = normalizeZhaopinUnicomDegree(result.degree, level);
    result.zhaopinUnicomDiscipline = normalizeZhaopinUnicomDiscipline(result);
    var upgradedValue = [result.isAssociateUpgrade, result.isUpgraded, result.associateUpgrade].find(function (value) {
      return value !== undefined && value !== null && String(value).trim() !== "";
    });
    result.zhaopinUnicomUpgraded = upgradedValue !== undefined
      ? (isAffirmative(upgradedValue) ? "是" : "否")
      : (/专升本/.test([level, result.示例资料Type, result.studyMode, result.description].filter(Boolean).join(" ")) ? "是" : "否");
    var 示例资料Type = String(result.示例资料Type || "");
    result.zhaopinUnicomEducationType = /全日制|统招/.test(示例资料Type) ? "全日制统分统招"
      : /海外|留学/.test(示例资料Type) ? "海外留学"
      : /成人/.test(示例资料Type) ? "成人教育"
      : /非定向/.test(示例资料Type) ? "非定向"
      : /定向/.test(示例资料Type) ? "定向"
      : /委培/.test(示例资料Type) ? "委培"
      : /自费/.test(示例资料Type) ? "自费" : "其他";
    result.zhaopinUnicomOverseas = isAffirmative(result.isOverseas) ? "是" : "否";
    return result;
  }

  function zhaopinUnicomEducationFieldSequence() {
    return [
      { label: "学校名称", field: "school", type: "text" },
      { label: "入学时间", field: "startTime", type: "elementDate" },
      { label: "毕业时间", field: "endTime", type: "elementDate" },
      { label: "学历", field: "zhaopinUnicomLevel", type: "zhaopinChoice" },
      { label: "是否专升本", field: "zhaopinUnicomUpgraded", type: "zhaopinChoice", when: function (row) { return row.zhaopinUnicomLevel === "本科"; } },
      { label: "研究方向", field: "researchDirection", type: "text" },
      { label: "院系", field: "department", type: "text" },
      { label: "专业", field: "major", type: "text" },
      { label: "专业课程", field: "majorCourses", type: "text", optional: true },
      { label: "成绩院系中排名", field: "zhaopinUnicomRank", type: "zhaopinChoice" },
      { label: "学位", field: "zhaopinUnicomDegree", type: "zhaopinChoice" },
      { label: "学位类型", field: "zhaopinUnicomDiscipline", type: "zhaopinChoice" },
      { label: "受教育类型", field: "zhaopinUnicomEducationType", type: "zhaopinChoice" },
      { label: "是否在海外学习", field: "zhaopinUnicomOverseas", type: "zhaopinChoice" },
    ];
  }

  // 智联校园公共模板的“高等示例资料”与联通的“示例资料”是两套不同
  // 字段枚举。只复用已验证的学历/学位/学科归一化，不能复用“全日制统分
  // 统招”等联通受教育类型转换。
  function enrichZhaopinHigherEducation(row) {
    var result = enrichZhaopinUnicomEducation(row);
    result.zhaopinHigherSchoolLocation = result.schoolAffiliation || "国内高校";
    result.zhaopinHigherLevel = result.zhaopinUnicomLevel;
    result.zhaopinHigherDiscipline = result.zhaopinUnicomDiscipline;
    result.zhaopinHigherDegree = result.zhaopinUnicomDegree;
    result.zhaopinHigherResearchDirection = result.researchDirection || "";
    result.zhaopinHigherDepartment = result.department || "";
    result.zhaopinHigherMajor = result.major || "";
    result.zhaopinHigherCourses = Array.isArray(result.courses)
      ? result.courses.join("、")
      : (result.majorCourses || result.courses || "");
    result.zhaopinHigherStudyMode = result.studyMode || result.示例资料Type || "";
    result.zhaopinHigherStudyLength = result.studyLength || "";
    result.zhaopinHigherHasOverseasStudy = result.hasOverseasStudy || "";
    result.zhaopinHigherIntegratedTraining = result.integratedTraining || "";
    // 学习形式和培养方式是独立概念：全日制属于学习形式，示例资料等
    // canonical 示例资料Mode 才能进入培养方式。
    result.zhaopinHigherTrainingMode = result.示例资料Mode || "";
    result.zhaopinHigherGpa = result.gpa || "";
    // 年级排名和班级排名是两个独立字段。不要再从“专业排名”借值。
    result.zhaopinHigherRank = result.rank || result.gradeRank || "";
    result.zhaopinHigherClassRank = result.cohortRank || "";
    return result;
  }

  function zhaopinHigherEducationFieldSequence() {
    var generic = { coreMatcherFirst: true, higherEducationField: true };
    return [
      Object.assign({ label: ["学校名称", "院校名称"], field: "school", type: "text" }, generic),
      Object.assign({ label: ["办学属地", "院校属性"], field: "zhaopinHigherSchoolLocation", type: "select" }, generic),
      Object.assign({ label: ["该段示例资料内是否有国外、港澳台地区学习经历", "该段示例资料是否有境外学习经历", "是否有境外学习经历"], field: "zhaopinHigherHasOverseasStudy", type: "select" }, generic),
      Object.assign({ label: "学历", field: "zhaopinHigherLevel", type: "select" }, generic),
      Object.assign({ label: "学科属性", field: "zhaopinHigherDiscipline", type: "select" }, generic),
      Object.assign({ label: "学位", field: "zhaopinHigherDegree", type: "select" }, generic),
      Object.assign({ label: "培养方式", field: "zhaopinHigherTrainingMode", type: "select", waitAfterMs: 350 }, generic),
      Object.assign({ label: "研究方向", field: "zhaopinHigherResearchDirection", type: "text", optional: true }, generic),
      Object.assign({ label: ["院系", "学院"], field: "zhaopinHigherDepartment", type: "text", optional: true }, generic),
      Object.assign({ label: ["专业", "专业名称"], field: "zhaopinHigherMajor", type: "text" }, generic),
      Object.assign({ label: ["专业课程", "主修课程"], field: "zhaopinHigherCourses", type: "text", optional: true }, generic),
      Object.assign({ label: "学习形式", field: "zhaopinHigherStudyMode", type: "select", optional: true }, generic),
      Object.assign({ label: ["学制", "学习年限", "修业年限", "培养年限"], field: "zhaopinHigherStudyLength", type: "select" }, generic),
      Object.assign({ label: ["是否贯通式培养", "是否贯通培养", "是否本硕连读"], field: "zhaopinHigherIntegratedTraining", type: "select", optional: true }, generic),
      Object.assign({ label: "个人绩点", field: "zhaopinHigherGpa", type: "text", optional: true }, generic),
      Object.assign({ label: "年级排名", field: "zhaopinHigherRank", type: "select", requirePersistentSelectCommit: true, panelTimeoutMs: 3600, optionTimeoutMs: 3600, commitTimeoutMs: 3000, persistVerifyMs: 650 }, generic),
      Object.assign({ label: ["班级排名", "所在班级排名", "班级成绩排名"], field: "zhaopinHigherClassRank", type: "select", optional: true }, generic),
      Object.assign({ label: "入学时间", field: "startTime", type: "date" }, generic),
      Object.assign({ label: "毕业时间", field: "endTime", type: "date" }, generic),
    ];
  }

  function zhaopinHigherEducationBeforeSaveFields() {
    return [
      {
        label: "年级排名",
        field: "zhaopinHigherRank",
        type: "select",
        coreMatcherFirst: true,
        higherEducationField: true,
        requirePersistentSelectCommit: true,
        // 如果年级排名已经以 Element Plus 的真实 selected-item 形式稳定展示，
        // 保存前只读校验即可，不要再次打开下拉重选。二次重选会让站点在
        // Vue 重绘时把已经正确的值清掉。
        alwaysRefillBeforeSave: false,
        panelTimeoutMs: 3600,
        optionTimeoutMs: 3600,
        commitTimeoutMs: 3000,
        persistVerifyMs: 650
      }
    ];
  }

  function enrichZhaopinUnicomWork(row) {
    var result = enrichZhaopinWorkRow(row);
    var 示例资料Type = String(result.示例资料Type || result.employmentType || result.jobNature || "");
    result.zhaopinUnicomWorkType = result.__afCategory === "示例资料Experience" || /实习/.test(示例资料Type)
      ? "实习"
      : /兼职/.test(示例资料Type) ? "兼职" : "全职";
    result.zhaopinUnicomSalary = result.currentSalary || result.monthlySalary || result.salary || "";
    result.zhaopinUnicomHasReference = result.referenceName || result.referencePhone || result.refereeName || result.refereePhone ? "是" : "否";
    return result;
  }

  // 智联校园公共模板的经历日期有的站点是按“月”，有的企业模板却要求
  // 精确到“日”。资料库保留 startTime/endTime（月）和 startDate/endDate（日）
  // 两套精度；站点层只挑已有事实，不推断日期。真正写控件时再根据控件类型
  // 决定使用 YYYY-MM 还是 YYYY-MM-DD。
  function enrichZhaopinCampusWorkRow(row) {
    var result = enrichZhaopinUnicomWork(row);
    result.zhaopinCampusStartDate = result.startDate || result.startTime || "";
    result.zhaopinCampusEndDate = result.endDate || result.endTime || "";
    return result;
  }

  function enrichZhaopinCampusProjectRow(row) {
    var result = enrichZhaopinProjectRow(row);
    result.zhaopinCampusStartDate = result.startDate || result.startTime || "";
    result.zhaopinCampusEndDate = result.endDate || result.endTime || "";
    return result;
  }

  function enrichZhaopinCampusLeadershipRow(row) {
    var result = Object.assign({}, row || {});
    result.zhaopinCampusStartDate = result.startDate || result.startTime || "";
    result.zhaopinCampusEndDate = result.endDate || result.endTime || "";
    return result;
  }

  function enrichZhaopinCampusAwardRow(row) {
    var result = Object.assign({}, row || {});
    result.zhaopinCampusAwardDate = result.awardDate || result.awardTime || "";
    return result;
  }

  function zhaopinUnicomWorkFieldSequence() {
    return [
      { label: "公司名称", field: "company", type: "text" },
      { label: "在职开始时间", field: "startTime", type: "elementDate" },
      { label: "在职结束时间", field: "endTime", type: "elementDate" },
      { label: "工作类型", field: "zhaopinUnicomWorkType", type: "zhaopinChoice" },
      { label: "当前月薪", field: "zhaopinUnicomSalary", type: "text", optional: true },
      { label: "职位名称", field: "position", type: "text" },
      { label: "工作描述", field: "zhaopinWorkDescription", type: "text", optional: true },
      { label: "是否有证明人", field: "zhaopinUnicomHasReference", type: "zhaopinChoice", optional: true },
    ];
  }


  // 智联校园公共模板各企业会微调标签文案，但控件语义仍是同一组
  // Element 表单字段。这里给“实习工作 / 全职示例资料”使用较窄的
  // 语义别名，并让共享 Core matcher 优先绑定真实控件；不引入企业 cid
  // 或 DOM 序号硬编码。
  function zhaopinCampusWorkFieldSequence() {
    // 国开行公共模板的重复经历编辑器会保留同类 label/控件的历史节点。
    // 这里必须优先在当前 label 最近的字段组内绑定控件，不能让全局 Core
    // matcher 抢到其它记录或 stale editor 中的同名控件。
    var generic = { coreMatcherFirst: false, zhaopinRepeatLocalBinding: true, requireLabel: true };
    return [
      Object.assign({ label: ["公司名称", "单位名称", "实习单位", "实习单位名称"], field: "company", type: "text" }, generic),
      Object.assign({ label: ["在职开始时间", "开始时间", "开始日期", "实习开始时间", "实习开始日期"], field: "zhaopinCampusStartDate", type: "zhaopinCampusDate" }, generic),
      Object.assign({ label: ["在职结束时间", "结束时间", "结束日期", "实习结束时间", "实习结束日期"], field: "zhaopinCampusEndDate", type: "zhaopinCampusDate" }, generic),
      { label: ["工作类型", "经历类型"], field: "zhaopinUnicomWorkType", type: "zhaopinChoice", optional: true },
      Object.assign({ label: ["当前月薪", "月薪", "实习薪资"], field: "zhaopinUnicomSalary", type: "text", optional: true }, generic),
      Object.assign({ label: ["职位名称", "职位", "岗位名称", "实习岗位", "实习职位"], field: "position", type: "text" }, generic),
      Object.assign({ label: ["工作描述", "工作内容", "主要职责", "实习工作描述", "实习内容"], field: "zhaopinWorkDescription", type: "text", optional: true }, generic),
      { label: ["是否有证明人", "是否有实习证明人"], field: "zhaopinUnicomHasReference", type: "zhaopinChoice", optional: true },
    ];
  }

  function zhaopinCampusProjectFieldSequence() {
    var generic = { coreMatcherFirst: false, zhaopinRepeatLocalBinding: true, requireLabel: true };
    return [
      Object.assign({ label: ["项目名称", "项目/课题名称", "项目课题名称"], field: "name", type: "text" }, generic),
      Object.assign({ label: ["项目开始时间", "开始时间", "开始日期", "起始时间"], field: "zhaopinCampusStartDate", type: "zhaopinCampusDate" }, generic),
      Object.assign({ label: ["项目结束时间", "结束时间", "结束日期", "截止时间", "截止日期"], field: "zhaopinCampusEndDate", type: "zhaopinCampusDate" }, generic),
      Object.assign({ label: ["项目职责", "担任角色", "职责", "本人职责", "个人职责"], field: "role", type: "text", optional: true }, generic),
      Object.assign({ label: ["项目描述", "项目内容", "项目内容简述", "项目经验及研究成果", "研究成果"], field: "zhaopinProjectDescription", type: "text", optional: true }, generic),
    ];
  }


  function zhaopinCampusLanguageFieldSequence() {
    var generic = { coreMatcherFirst: true };
    return [
      Object.assign({
        label: ["大学英语四级考试成绩", "大学英语四级成绩", "CET-4成绩", "CET4成绩"],
        field: "zhaopinCampusCet4Score",
        type: "text"
      }, generic),
      Object.assign({
        label: ["大学英语六级考试成绩", "大学英语六级成绩", "CET-6成绩", "CET6成绩"],
        field: "zhaopinCampusCet6Score",
        type: "text"
      }, generic),
      {
        label: ["其他英语等级考试", "其他英语考试", "其他英语等级"],
        field: "zhaopinCampusOtherEnglishExam",
        type: "zhaopinChoice",
        verifySelection: true,
        verifyDisplayedSelection: true,
        retryCount: 2,
        waitAfterSelectMs: 500
      },
      // 示例资料/TOEFL 分数是普通文本输入框。这里不能让 Core matcher 的
      // 启发式类型覆盖显式的 text 类型：Element 表单在相邻的“其他英语等级考试”
      // 下拉仍挂载时，matcher 可能把成绩输入框误判成同一个 el-select，造成
      // “目标=6.5、当前=6.5，但仍按下拉失败”的 false negative。
      {
        label: [
          "其他英语等级考试成绩",
          "其他英语等级考试分数",
          "其他英语考试成绩",
          "雅思成绩",
          "示例资料成绩",
          "TOEFL/示例资料成绩",
          "托福/雅思成绩"
        ],
        field: "zhaopinCampusOtherEnglishScore",
        type: "text",
        coreMatcherFirst: false,
        when: function (row) { return !!String(row && row.zhaopinCampusOtherEnglishExam || "").trim(); }
      },
    ];
  }

  function zhaopinCampusLeadershipFieldSequence() {
    var generic = { coreMatcherFirst: true };
    return [
      // 国开行当前模板的只读卡片并不展示“组织名称”，不能把这一字段
      // 当作阻断保存的必填项；若企业模板实际存在则仍会填写。
      Object.assign({ label: ["组织名称", "学生组织", "所在组织", "社团名称", "组织/社团名称"], field: "示例资料Name", type: "text", optional: true }, generic),
      Object.assign({ label: ["职务", "职位", "担任职务", "任职名称"], field: "title", type: "text" }, generic),
      Object.assign({ label: ["开始时间", "开始日期", "任职开始时间", "任职开始日期"], field: "zhaopinCampusStartDate", type: "zhaopinCampusDate" }, generic),
      Object.assign({ label: ["结束时间", "结束日期", "任职结束时间", "任职结束日期"], field: "zhaopinCampusEndDate", type: "zhaopinCampusDate" }, generic),
      Object.assign({
        label: ["工作内容", "经历描述", "职责描述", "主要职责", "职务描述", "任职描述"],
        field: "description",
        type: "text",
        optional: true,
        // 国开行该字段真实上限为 50 字。只对用户已明确确认的示例资料旧文案
        // 使用批准后的 46 字版本；其他经历不做自动截断或改写。
        valueTransform: function (value, row) {
          var text = String(value || "").trim();
          var role = String(row && row.title || "").trim();
          if (role === "示例资料" && text === "筹备学习经验交流活动，协调师兄师姐与班级同学；示例资料") return "示例资料";
          var roleDescription = String(row && row.roleDescription || "").trim();
          if (text.length > 50 && roleDescription && roleDescription.length <= 50) return roleDescription;
          return text;
        }
      }, generic),
    ];
  }

  function zhaopinCampusAwardFieldSequence() {
    var generic = { coreMatcherFirst: true };
    return [
      Object.assign({ label: ["奖励名称", "奖项名称", "获奖名称", "奖惩名称", "荣誉名称"], field: "awardName", type: "text" }, generic),
      Object.assign({ label: ["奖励时间", "获奖时间", "奖惩时间", "奖励日期", "获奖日期"], field: "zhaopinCampusAwardDate", type: "zhaopinCampusDate", optional: true }, generic),
      Object.assign({ label: ["奖励等级", "奖项等级", "奖励级别", "获奖等级", "奖项级别"], field: "awardLevel", type: "select", optional: true }, generic),
      Object.assign({ label: ["颁奖单位", "授予单位", "奖励单位", "颁发单位", "授奖单位"], field: "awardIssuer", type: "text", optional: true }, generic),
      Object.assign({ label: ["奖励描述", "获奖描述", "奖惩描述", "奖励内容", "获奖情况说明"], field: "awardDescription", type: "text", optional: true }, generic),
    ];
  }

  function zhaopinCampusFamilyFieldSequence() {
    var generic = { coreMatcherFirst: true };
    return [
      Object.assign({ label: ["姓名", "家庭成员姓名"], field: "name", type: "text" }, generic),
      Object.assign({ label: ["关系", "与本人关系", "称谓"], field: "relationship", type: "select" }, generic),
      Object.assign({ label: ["出生日期", "出生年月"], field: "birthDate", type: "elementDate", optional: true }, generic),
      Object.assign({ label: ["政治面貌"], field: "politicalStatus", type: "select", optional: true }, generic),
      Object.assign({ label: ["工作单位", "公司", "单位名称"], field: "company", type: "text", optional: true }, generic),
      Object.assign({ label: ["职位", "职务"], field: "position", type: "text", optional: true }, generic),
      Object.assign({ label: ["联系电话", "电话", "手机号码"], field: "phone", type: "text", optional: true }, generic),
    ];
  }

  function normalizeZhaopinUnicomScholarshipLevel(value) {
    var text = String(value || "");
    if (/国家/.test(text)) return "国家级";
    if (/省|市/.test(text)) return "省市级";
    if (/校|院/.test(text)) return "院校级";
    return "";
  }

  function normalizeZhaopinUnicomScholarshipGrade(value) {
    var text = String(value || "");
    if (/一等|一等奖/.test(text)) return "一等奖";
    if (/二等|二等奖/.test(text)) return "二等奖";
    if (/三等|三等奖/.test(text)) return "三等奖";
    return text ? "其他" : "";
  }

  function normalizeZhaopinUnicomCadreLevel(row) {
    var text = [row && row.示例资料Name, row && row.organization, row && row.leadershipLevel].filter(Boolean).join(" ");
    if (/团委/.test(text)) return "团委";
    if (/院|学院|系/.test(text) && /学生会|研究生会/.test(text)) return "院学生会";
    if (/校学生会|校级学生会/.test(text)) return "校学生会";
    if (/班/.test(text)) return "班级";
    if (/社团|协会|学社|社$/.test(text)) return "学生社团";
    return "学生社团";
  }

  function normalizeZhaopinUnicomCadreName(value) {
    var text = String(value || "");
    if (/副主席/.test(text)) return "副主席";
    if (/主席助理/.test(text)) return "主席助理";
    if (/主席/.test(text)) return "主席";
    if (/秘书长/.test(text)) return "秘书长";
    if (/书记/.test(text)) return "书记";
    if (/会长|社长/.test(text)) return "社长";
    if (/部长/.test(text)) return "部长";
    if (/班长/.test(text)) return "班长";
    if (/干事/.test(text)) return "干事";
    return text ? "其他" : "";
  }

  function formatZhaopinUnicomRewardText(row, kind) {
    if (!row) return "";
    if (kind === "certificate") {
      return [row.certificateName || row.certificateType, row.description].filter(Boolean).join("：");
    }
    return [row.activityName || row.name, row.role, row.description].filter(Boolean).join("；");
  }

  function buildZhaopinUnicomRewardRows(rows, resume) {
    resume = resume || {};
    var 示例资料 = Array.isArray(resume.示例资料) ? resume.示例资料 : [];
    var scholarships = 示例资料.filter(function (row) {
      return /奖学金/.test([row && row.awardClass, row && row.awardCategory, row && row.awardName].filter(Boolean).join(" "));
    });
    var 示例资料Awards = 示例资料.filter(function (row) { return scholarships.indexOf(row) === -1; });
    var leaders = Array.isArray(resume.campusLeadership) ? resume.campusLeadership : [];
    var 示例资料 = Array.isArray(resume.示例资料) ? resume.示例资料 : [];
    var activities = Array.isArray(resume.campusActivities) ? resume.campusActivities : [];
    var socialPractices = activities.filter(function (row) {
      return /社会实践/.test(String(row && row.practiceMode || ""));
    });
    var campusActivities = activities.filter(function (row) { return socialPractices.indexOf(row) === -1; });
    var total = Math.max(
      scholarships.length, leaders.length, 示例资料.length,
      campusActivities.length, socialPractices.length
    );
    var result = [];
    for (var index = 0; index < total; index += 1) {
      var scholarship = scholarships[index];
      var leader = leaders[index];
      var receivedAward = leader && 示例资料Awards[index];
      result.push({
        __afCategory: "示例资料",
        zhaopinUnicomHasScholarship: scholarship ? "有" : "无",
        zhaopinUnicomScholarshipLevel: normalizeZhaopinUnicomScholarshipLevel(scholarship && scholarship.awardLevel),
        zhaopinUnicomScholarshipGrade: normalizeZhaopinUnicomScholarshipGrade(scholarship && scholarship.awardGrade),
        zhaopinUnicomIsCadre: leader ? "是" : "否",
        zhaopinUnicomCadreLevel: normalizeZhaopinUnicomCadreLevel(leader),
        zhaopinUnicomCadreName: normalizeZhaopinUnicomCadreName(leader && leader.title),
        zhaopinUnicomCadreStartTime: leader && leader.startTime || "",
        zhaopinUnicomCadreEndTime: leader && leader.endTime || "",
        zhaopinUnicomReceivedAward: receivedAward && receivedAward.awardName || "",
        zhaopinUnicomCertificate: formatZhaopinUnicomRewardText(示例资料[index], "certificate"),
        zhaopinUnicomCampusActivity: formatZhaopinUnicomRewardText(campusActivities[index], "activity"),
        zhaopinUnicomSocialPractice: formatZhaopinUnicomRewardText(socialPractices[index], "activity"),
      });
    }
    return result;
  }

  function zhaopinUnicomRewardFieldSequence() {
    return [
      { label: "奖学金", field: "zhaopinUnicomHasScholarship", type: "zhaopinChoice" },
      { label: "奖学金级别", field: "zhaopinUnicomScholarshipLevel", type: "zhaopinChoice", when: function (row) { return row.zhaopinUnicomHasScholarship === "有"; } },
      { label: "奖学金等级", field: "zhaopinUnicomScholarshipGrade", type: "zhaopinChoice", when: function (row) { return row.zhaopinUnicomHasScholarship === "有"; } },
      { label: "是否学生干部", field: "zhaopinUnicomIsCadre", type: "zhaopinChoice" },
      { label: "干部级别", field: "zhaopinUnicomCadreLevel", type: "zhaopinChoice", when: function (row) { return row.zhaopinUnicomIsCadre === "是"; } },
      { label: "干部名称", field: "zhaopinUnicomCadreName", type: "zhaopinChoice", when: function (row) { return row.zhaopinUnicomIsCadre === "是"; } },
      { label: "开始时间", field: "zhaopinUnicomCadreStartTime", type: "elementDate", when: function (row) { return row.zhaopinUnicomIsCadre === "是"; } },
      { label: "结束时间", field: "zhaopinUnicomCadreEndTime", type: "elementDate", when: function (row) { return row.zhaopinUnicomIsCadre === "是"; } },
      { label: "受到奖励", field: "zhaopinUnicomReceivedAward", type: "text", optional: true, when: function (row) { return row.zhaopinUnicomIsCadre === "是"; } },
      { label: "专业资格证书", field: "zhaopinUnicomCertificate", type: "text", optional: true },
      { label: "校内活动", field: "zhaopinUnicomCampusActivity", type: "text", optional: true },
      { label: "社会实践", field: "zhaopinUnicomSocialPractice", type: "text", optional: true },
    ];
  }

  function zhaopinUnicomSkillFieldSequence() {
    return [
      { label: "英语等级", field: "certificate", type: "zhaopinChoice" },
      { label: "英语分数", field: "score", type: "text", optional: true },
      { label: "英语证书", field: "certificateName", type: "zhaopinChoice", optional: true },
      { label: "获得时间", field: "obtainedTime", type: "text", optional: true },
      { label: "听说能力", field: "speakingListening", type: "zhaopinChoice", optional: true },
      { label: "读写能力", field: "readingWriting", type: "zhaopinChoice", optional: true },
      { label: "个人爱好", field: "hobbies", type: "text", optional: true },
    ];
  }

  function detectZhaopinCampusEnterpriseModules() {
    var titles = [];
    try {
      titles = Array.from(document.querySelectorAll(".resume-menu-item__title")).map(function (node) {
        return String(node.textContent || "").replace(/\s+/g, "").trim();
      }).filter(Boolean);
    } catch (e) {}
    var seen = {};
    return titles.map(function (title) {
      var module = null;
      if (/^个人信息$/.test(title)) module = { title: title, category: "示例资料Info", kind: "示例资料" };
      else if (/^示例资料$/.test(title)) module = { title: title, category: "示例资料", kind: "示例资料" };
      // 高中资料没有进入 resume.示例资料。明确跳过“高中示例资料”，避免
      // 把本科/硕士记录错误写入高中表单；高等教育使用其独立的字段变体。
      else if (/^高等示例资料$/.test(title)) module = { title: title, category: "示例资料", kind: "示例资料", variant: "higherEducation" };
      else if (/^(?:投递信息|示例资料)$/.test(title)) module = { title: title, category: "jobIntention", kind: "jobIntention" };
      // 公共模板会把“实习工作”和“全职示例资料”拆成两个独立栏目。
      // 不能再把两个栏目都绑定到 示例资料Experience + 示例资料Experience，
      // 否则三条实习会被重复写进“全职示例资料”。只有标题本身就是
      // 合并语义时，才继续使用两个 category。
      else if (/^(?:实习工作|实习示例资料|示例资料)$/.test(title)) module = { title: title, category: "示例资料Experience", kind: "示例资料", variant: "publicRepeat" };
      else if (/^(?:全职示例资料|正式示例资料|示例资料)$/.test(title)) module = { title: title, category: "示例资料Experience", kind: "示例资料", variant: "publicRepeat" };
      else if (/实习\s*[\/／]\s*示例资料|工作\s*[\/／]\s*示例资料/.test(title)) module = { title: title, category: ["示例资料Experience", "示例资料Experience"], kind: "示例资料" };
      else if (/项目经历|项目经验/.test(title)) module = { title: title, category: "示例资料Experience", kind: "示例资料", variant: "publicRepeat" };
      else if (/^(?:学生工作|学生示例资料|学生干部经历)$/.test(title)) module = { title: title, category: "campusLeadership", kind: "campusLeadership", variant: "publicRepeat" };
      else if (/^(?:奖励情况|奖励荣誉|荣誉奖励|获奖经历)$/.test(title)) module = { title: title, category: "示例资料", kind: "示例资料", variant: "publicRepeat" };
      else if (/^(?:语言情况|语言能力|语言技能)$/.test(title)) module = { title: title, category: "示例资料Skills", kind: "示例资料", variant: "publicRepeat" };
      else if (/^(?:家庭信息|示例资料|家庭关系)$/.test(title)) module = { title: title, category: "示例资料Members", kind: "示例资料", variant: "publicRepeat" };
      else if (/专业技能|资格证书/.test(title)) module = { title: title, category: "示例资料", kind: "示例资料" };
      else if (/^个人特长$/.test(title)) module = { title: title, category: "示例资料Info", kind: "personalSpecialty", variant: "publicSingle", options: { fieldSequence: [{ label: ["个人特长", "特长", "爱好及专长"], field: "hobbies", type: "text", optional: true, coreMatcherFirst: true }] } };
      else if (/^是否服从调剂$/.test(title)) module = { title: title, category: "jobIntention", kind: "jobIntention", variant: "publicSingle", options: { fieldSequence: [{ label: ["是否服从调剂", "是否接受调剂"], field: "acceptAdjustment", type: "select", coreMatcherFirst: true }] } };
      else if (/自我评价|示例资料|其他说明/.test(title)) module = { title: title, category: ["示例资料Introduction", "示例资料Info"], kind: "示例资料" };
      if (!module || seen[title]) return null;
      seen[title] = true;
      return module;
    }).filter(Boolean);
  }

  function zhaopinCampusEnterpriseStep(module, profileStepOptions) {
    var kind = module.kind || "generic";
    var 示例资料 = /^(?:示例资料|示例资料|示例资料|示例资料|campusLeadership|示例资料|示例资料|示例资料)$/.test(kind);
    var commonDataTransform = kind === "示例资料"
      ? enrichZhaopinUnicomBasic
      : (kind === "jobIntention"
        ? enrichZhaopinJobIntention
        : (kind === "示例资料" ? enrichZhaopinSummary : undefined));
    var commonRowTransform = kind === "示例资料"
      ? (module.variant === "higherEducation" ? enrichZhaopinHigherEducation : enrichZhaopinUnicomEducation)
      : (kind === "示例资料"
        ? (module.variant === "publicRepeat" ? enrichZhaopinCampusWorkRow : enrichZhaopinUnicomWork)
        : (kind === "示例资料"
          ? (module.variant === "publicRepeat" ? enrichZhaopinCampusProjectRow : enrichZhaopinProjectRow)
          : (kind === "示例资料"
            ? (module.variant === "publicRepeat" ? enrichZhaopinCampusLanguageRow : enrichZhaopinLanguageRow)
            : (kind === "campusLeadership" && module.variant === "publicRepeat"
              ? enrichZhaopinCampusLeadershipRow
              : (kind === "示例资料" && module.variant === "publicRepeat" ? enrichZhaopinCampusAwardRow : undefined)))));
    var commonFieldSequence = kind === "示例资料"
      ? zhaopinUnicomBasicFieldSequence()
      : (kind === "示例资料"
        ? (module.variant === "higherEducation" ? zhaopinHigherEducationFieldSequence() : zhaopinUnicomEducationFieldSequence())
        : (kind === "示例资料"
          ? (module.variant === "publicRepeat" ? zhaopinCampusWorkFieldSequence() : zhaopinUnicomWorkFieldSequence())
          : (kind === "示例资料" && module.variant === "publicRepeat"
            ? zhaopinCampusProjectFieldSequence()
            : (kind === "campusLeadership" && module.variant === "publicRepeat"
              ? zhaopinCampusLeadershipFieldSequence()
              : (kind === "示例资料" && module.variant === "publicRepeat"
                ? zhaopinCampusAwardFieldSequence()
                : (kind === "示例资料" && module.variant === "publicRepeat"
                  ? zhaopinCampusFamilyFieldSequence()
                  : (kind === "示例资料" && module.variant === "publicRepeat" ? zhaopinCampusLanguageFieldSequence() : undefined)))))));
    var step = zhaopinInlineStep(module.title, module.category, {
      preferNavigationTrigger: true,
      directMenuNavigation: true,
      handleNavigationSavePrompt: true,
      navigationPromptTimeoutMs: 1800,
      triggerText: [module.title],
      navigationTriggerCandidateSelector: ".resume-menu-item, .resume-menu-item__title, h6",
      cardTitle: module.title,
      cardTitleSelector: ".form-content--title",
      sectionRootSelector: ".apply-module",
      sectionByTitle: true,
      // 智联校园企业页共用表单控件和大类流程；企业 profile 只覆盖
      // 特有字段或枚举。奖励模块差异较大，仍由企业 profile 单独声明。
      dataTransform: commonDataTransform,
      rowTransform: commonRowTransform,
      rowsTransform: kind === "示例资料" ? mergeZhaopinCertificateRows : undefined,
      fieldSequence: commonFieldSequence,
      rowFilter: kind === "示例资料" ? isZhaopinSupportedEducationRow : undefined,
      示例资料ForCategoryData: 示例资料,
      saveEachRepeatStep: true,
      示例资料AddSelector: ".form-content--title-box .icon-box",
      示例资料AddSelectors: [".form-content--title-box .icon-box.icon-box-only", ".form-content--title-box .icon-box", ".no-data .add-now"],
      示例资料AddText: ["添加"],
      示例资料AddCandidateSelector: "button, a, span, i, div",
      示例资料AddRootSelector: "",
      示例资料AddNativeClick: true,
      forceAddFirstRepeatWhenNoExisting: true,
      示例资料ReadySelector: ".apply-module__form form.scrd-web--form-edit",
      editExistingSectionWhenClosed: true,
      afterClickActionText: ["编辑", "添加", "立即添加"],
      afterClickActionRootSelector: "",
      afterClickActionCandidateSelector: "button, a, [role='button'], span",
      readySelector: ".apply-module__form",
      scopeSelector: ".apply-module__form",
      readyEditableSelector: "input, textarea, select",
      strictReadyWithinCard: true,
      skipClickWhenReady: false,
      saveSelector: ".apply-module__form button.el-button--primary",
      saveText: ["保 存", "保存", "保存并更新"],
      示例资料SubmitSelector: ".apply-module__form form.scrd-web--form-edit .btn-box button.el-button--primary",
      示例资料SubmitText: ["添 加", "添加"],
      useVisibleRepeatEditorAsScope: 示例资料,
      waitForCloseSelector: ".apply-form--edit, form.scrd-web--form-edit",
      waitForCloseTimeoutMs: 7000,
      waitAfterClickMs: 450,
      waitAfterActionMs: 150,
      waitAfterSaveMs: 500,
      saveTimeoutMs: 7000,
      waitForSaveSuccess: true,
      saveSuccessTimeoutMs: 5000,
      saveSuccessOptional: true,
      waitBeforeNextMs: 示例资料 ? 450 : 1200,
      stopOnSaveError: true,
    });
    // 公共模板有时已将高等教育编辑器展开。优先以该可见 scope 填写，只有
    // 编辑器不存在时才让重复经历引擎触发“添加”。该覆盖仅作用于此变体。
    var variantOptions = module.variant === "higherEducation" ? {
      higherEducationNavigationAdapter: true,
      beforeSaveEnsureFields: zhaopinHigherEducationBeforeSaveFields(),
      autoOpenEducationEditor: true,
      repairExistingEducationRecords: true,
      handleNavigationSavePrompt: false,
      currentVisibleEditorMode: false,
      skipClickWhenReady: true,
      forceAddFirstRepeatWhenNoExisting: false,
      useVisibleRepeatEditorAsScope: true,
      sharedRepeatScope: true,
      saveEachRepeatStep: true,
      skipSave: false,
      keepEditorOnError: true,
      continueOnError: false,
      editExistingSectionWhenClosed: false,
      afterClickActionText: [],
    } : (module.variant === "publicRepeat" ? {
      // 与高等教育相同，先完成“左侧栏目事务导航 → 当前栏目内找 Add →
      // 等待 Vue 编辑器出现”，再把真实 editor scope 交回共享字段执行器。
      zhaopinRepeatNavigationAdapter: true,
      handleNavigationSavePrompt: false,
      skipClickWhenReady: true,
      forceAddFirstRepeatWhenNoExisting: false,
      useVisibleRepeatEditorAsScope: true,
      saveEachRepeatStep: true,
      skipSave: false,
      keepEditorOnError: true,
      skipRemainingRepeatsOnError: true,
      // 若上一版留下“只填了一部分”的卡片，优先编辑现有卡片修复，
      // 而不是继续追加重复记录。页面记录数超过资料库计划数时禁止
      // 自动覆盖/删除，明确停在 needs_review。
      zhaopinRepairExistingRecords: true,
      zhaopinRepairExistingByPosition: true,
      zhaopinBlockOnExcessExistingRecords: true,
      // 仅当网页现有卡片存在明显重复签名时，允许修复资料库计划范围内的
      // 前 N 条记录，同时保留多出的卡片供用户人工复核。不会自动删除。
      zhaopinRepairCorruptedExcessDuplicates: true,
      // 编辑已有记录时，某一条字段修复失败不能让后两条永远得不到检查。
      // 仅在可以点击“取消”并确认当前编辑器已关闭后，才继续下一条；
      // 本条未保存修改会被丢弃，不会把半成品覆盖到页面。
      zhaopinContinueExistingRepairAfterRowError: true,
      cancelFailedRepairTimeoutMs: 3500,
      // 智联重复经历保存后真正消失的是编辑 form；外层 apply-form--edit
      // 在部分模板中会继续存在，不能把它当作“仍处于编辑态”。
      waitForCloseSelector: "form.scrd-web--form-edit",
      // 保存后先用实际可见性判断编辑 form 是否真的还在；若没有站点校验
      // 且编辑器仍真实可见，只重试一次当前记录保存，不跨模块、不触碰最终投递。
      zhaopinRepeatRetrySaveWhenStillEditing: true,
      saveRetryTimeoutMs: 7000,
      editExistingSectionWhenClosed: false,
      afterClickActionText: [],
    } : {});
    return Object.assign(step, profileStepOptions || {}, variantOptions, module.options || {});
  }

  function zhaopinCampusEnterpriseEntry(profile) {
    var modules = Array.isArray(profile.modules) ? profile.modules : detectZhaopinCampusEnterpriseModules();
    if (!modules.length) {
      modules = [
        { title: "个人信息", category: "示例资料Info", kind: "示例资料" },
        { title: "投递信息", category: "jobIntention", kind: "jobIntention" },
        { title: "示例资料", category: "示例资料", kind: "示例资料" },
        { title: "实习/示例资料", category: ["示例资料Experience", "示例资料Experience"], kind: "示例资料" },
        { title: "项目经历", category: "示例资料Experience", kind: "示例资料" },
        { title: "奖励活动", category: ["示例资料", "campusLeadership", "示例资料", "campusActivities"], kind: "示例资料" },
        { title: "自我评价", category: "示例资料Introduction", kind: "示例资料" },
        { title: "技能&爱好", category: ["示例资料Skills", "示例资料Skills", "professionalSkills"], kind: "示例资料" },
        { title: "家庭关系", category: "示例资料Members", kind: "示例资料" },
        { title: "其他说明", category: "示例资料Introduction", kind: "示例资料" },
      ];
    }
    return {
      id: profile.id,
      brandDomain: "zhaopin.com",
      hostname: "xiaoyuan.zhaopin.com",
      urlPattern: profile.urlPattern,
      // 中国移动栏目 DOM 异步渲染，URL 中的 cid 已足够区分企业。
      pageGuardSelector: "body",
      config: {
        name: profile.configName || "xiaoyuan.zhaopin.com/scrd/resume2",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: profile.urlPattern,
        selectors: {
          container: { class: ".apply-module" }, section: ".apply-module",
          title: { class: ".form-content--title" },
          labels: { class: ".el-form-item__label, .form-item__label, label" },
          radio: { class: ".el-radio, .el-radio-group, input[type='radio']" },
          checkbox: { class: ".el-checkbox, input[type='checkbox']" },
          select: { class: ".el-select, .el-input, select" },
          datePicker: { class: ".el-date-editor input, input[placeholder*='日期']" },
          address: { class: ".el-cascader, .el-input" }, upload: { class: "input[type='file']" },
          buttons: { add: {}, edit: { class: ".apply-module button" }, save: { class: ".apply-module button" } },
        },
      },
      示例资料flow: {
        id: profile.id,
        name: profile.name || "智联校园企业网申",
        enabled: true,
        privateSpecialSite: true,
        hostname: "xiaoyuan.zhaopin.com",
        urlPattern: profile.urlPattern,
        pageGuardSelector: "body",
        continueOnError: true,
        autoContinueAcrossPages: profile.autoContinueAcrossPages === true,
        orderedContinuation: profile.orderedContinuation === true,
        clearContinuationOnComplete: profile.clearContinuationOnComplete === true,
        notices: ["智联校园企业表单按左侧真实大类依次填写；附件不自动上传。"],
        steps: modules.map(function (module) {
          return zhaopinCampusEnterpriseStep(module, profile.stepOptions);
        }),
      },
    };
  }

  function zhaopinFirstValue(value) {
    if (Array.isArray(value)) return String(value[0] || "").trim();
    return String(value || "").split(/[,，、;；|]/)[0].trim();
  }

  function zhaopinTaxonomyTree(kind) {
    return kind === "industry"
      ? (Array.isArray(window.AF_PRIVATE_ZHAOPIN_INDUSTRY_TREE) ? window.AF_PRIVATE_ZHAOPIN_INDUSTRY_TREE : [])
      : (Array.isArray(window.AF_PRIVATE_ZHAOPIN_POSITION_TREE) ? window.AF_PRIVATE_ZHAOPIN_POSITION_TREE : []);
  }

  function zhaopinTaxonomyPath(value, storedPath, kind) {
    var path = String(storedPath || "").split(/\s+\/\s+/).filter(Boolean);
    var expectedLength = kind === "industry" ? 2 : 3;
    if (kind === "position" && path.length === 3) {
      if (path[0] === "金融/保险") path[0] = "金融";
      if (path[1] === "银行及金融服务") path[1] = "银行/金融服务";
    }
    var wanted = zhaopinFirstValue(value || path[path.length - 1]);
    var tree = zhaopinTaxonomyTree(kind);
    if (path.length === expectedLength) {
      var storedCategory = tree.find(function (item) { return item.name === path[0]; });
      if (kind === "industry") {
        if (storedCategory && storedCategory.children.indexOf(path[1]) !== -1) return path;
      } else if (storedCategory) {
        var storedGroup = storedCategory.children.find(function (item) { return item.name === path[1]; });
        if (storedGroup && storedGroup.children.indexOf(path[2]) !== -1) return path;
      }
    }
    if (!wanted) return [];
    for (var i = 0; i < tree.length; i++) {
      var children = Array.isArray(tree[i].children) ? tree[i].children : [];
      if (kind === "industry") {
        if (children.indexOf(wanted) !== -1) return [tree[i].name, wanted];
        continue;
      }
      for (var j = 0; j < children.length; j++) {
        if (Array.isArray(children[j].children) && children[j].children.indexOf(wanted) !== -1) {
          return [tree[i].name, children[j].name, wanted];
        }
      }
    }
    return [];
  }

  function enrichZhaopinTaxonomyFields(result) {
    var industryValue = zhaopinFirstValue(result.zhaopinIndustry || result.industry);
    var industryPath = zhaopinTaxonomyPath(industryValue, result.zhaopinIndustryPath, "industry");
    result.zhaopinIndustry = industryPath[industryPath.length - 1] || industryValue;
    result.zhaopinIndustryPath = industryPath.length ? industryPath.join(" / ") : result.zhaopinIndustry;

    var positionValue = zhaopinFirstValue(result.zhaopinPosition || result.job51Position || result.position || result.expectedPosition);
    var positionPath = zhaopinTaxonomyPath(positionValue, result.zhaopinPositionPath, "position");
    result.zhaopinPosition = positionPath[positionPath.length - 1] || positionValue;
    result.zhaopinPositionPath = positionPath.length ? positionPath.join(" / ") : result.zhaopinPosition;
    return result;
  }


  function zhaopinSalaryOption(value) {
    var amount = Number(value);
    if (!isFinite(amount) || amount <= 0) return "";
    if (amount >= 1000) amount = amount / 1000;
    if (amount < 10) return String(Math.round(amount * 10) / 10).replace(/\.0$/, "") + "千";
    return String(Math.round(amount / 10 * 10) / 10).replace(/\.0$/, "") + "万";
  }

  function enrichZhaopinJobIntention(data) {
    var result = Object.assign({}, data || {});
    enrichZhaopinTaxonomyFields(result);
    result.zhaopinCity = zhaopinFirstValue(result.city || result.expectedLocation);
    var salaryText = String(result.salary || result.expectedSalary || "");
    var salaryNumbers = salaryText.match(/\d+(?:\.\d+)?/g) || [];
    result.zhaopinSalaryMin = zhaopinSalaryOption(salaryNumbers[0]);
    result.zhaopinSalaryMax = zhaopinSalaryOption(salaryNumbers[1] || salaryNumbers[0]);
    result.zhaopinEmploymentType = zhaopinFirstValue(result.employmentType) || "全职";
    return result;
  }

  function enrichZhaopinJobStatus(data, resume) {
    var result = Object.assign({}, data || {}, resume && resume.示例资料Info || {});
    var text = String(result.jobStatus || result.currentStatus || result.zhaopinIdentity || "");
    if (/在校/.test(text) && /暂不|不找/.test(text)) result.zhaopinJobStatus = "在校-暂不找工作";
    else if (/在校/.test(text) && /看看|机会/.test(text)) result.zhaopinJobStatus = "在校-看看机会";
    else if (/在校|学生|应届/.test(text)) result.zhaopinJobStatus = "在校-正在找工作";
    else result.zhaopinJobStatus = "离校-正在找工作";
    return result;
  }

  function enrichZhaopinSummary(data) {
    var result = Object.assign({}, data || {});
    result.zhaopinSummary = result.示例资料Introduction || result.summary || result.description || result.content || "";
    return result;
  }

  function abcModalStep(cardTitle, category, actionText, options) {
    options = options || {};
    return Object.assign({
      name: cardTitle,
      category: category,
      cardTitle: cardTitle,
      cardSelector: ".ant-card",
      cardTitleSelector: ".ant-card-head-title",
      cardActionSelector: ".ant-card-extra",
      triggerActionText: actionText,
      readySelector: ".ant-modal-wrap",
      readyText: options.readyText || cardTitle,
      scopeSelector: ".ant-modal-wrap",
      scopeByReadyText: true,
      fillMode: "full",
      waitAfterClickMs: 350,
      timeoutMs: 7000,
      skipClickWhenReady: false,
      skipWhenUnavailable: true,
      saveText: ["保存"],
      saveEachRepeatStep: true,
      示例资料AddText: actionText ? [actionText] : undefined,
      示例资料AddCandidateSelector: "button, a, [role='button'], span",
      waitBeforeActivateCloseSelector: ".ant-modal-wrap",
      waitBeforeActivateCloseTimeoutMs: 3500,
      waitAfterSaveMs: 350,
      postSaveConfirmSelector: ".ant-modal-confirm, .ant-modal-confirm-body-wrapper",
      postSaveConfirmText: ["OK", "确定", "确 定"],
      postSaveConfirmButtonSelector: "button, a, [role='button']",
      postSaveConfirmTimeoutMs: 5000,
      waitAfterConfirmMs: 300,
      waitForCloseSelector: ".ant-modal-wrap",
      saveTimeoutMs: 7000,
      diagnosticCloseSelector: ".ant-modal-close",
    }, options);
  }

  function ccbInlineStep(sectionTitle, category, actionText, options) {
    options = options || {};
    return Object.assign({
      name: sectionTitle,
      category: category,
      cardTitle: sectionTitle,
      cardSelector: ".floor_view",
      cardTitleSelector: ".floor_view_title h3",
      cardActionSelector: ".floor_view_title .Nright",
      cardActionClickSelector: "a.edit, a.add",
      triggerActionText: actionText,
      readySelector: ".floor_view_editor",
      scopeSelector: ".floor_view_editor",
      fillMode: "full",
      waitAfterClickMs: 250,
      timeoutMs: 6000,
      skipClickWhenReady: false,
      skipWhenUnavailable: true,
      preferEditExistingRecords: true,
      saveText: ["保存"],
      waitAfterSaveMs: 450,
      waitForCloseSelector: ".floor_view_editor",
      saveTimeoutMs: 7000,
      diagnosticCloseSelector: ".btn_center .btn a:first-child",
    }, options);
  }

  function isAffirmative(value) {
    return /^(是|有|true|yes|y|1)$/i.test(String(value == null ? "" : value).trim());
  }

  function isEnglishLanguage(row) {
    return /^(English|英语|大学英语)$/i.test(String(row && (row.name || row.示例资料) || "").trim());
  }

  function enrichCcbBasicInfo(data) {
    var result = Object.assign({}, data || {});
    result.currentResidence = result.currentCity || result.city || result.nativePlace || result.hukouLocation || "";
    return result;
  }

  function enrichCcbEnglish(data, resume) {
    var english = resume && Array.isArray(resume.示例资料Skills)
      ? resume.示例资料Skills.find(isEnglishLanguage)
      : null;
    var result = Object.assign({}, english || data || {});
    var certificate = String(result.certificate || result.certificateName || result.level || "").trim();
    if (/CET[- ]?6|六级/i.test(certificate)) result.ccbEnglishLevel = "CET-6(大学英语六级)";
    else if (/CET[- ]?4|四级/i.test(certificate)) result.ccbEnglishLevel = "CET-4(大学英语四级)";
    else result.ccbEnglishLevel = certificate;
    return result;
  }

  function enrichCcbEducationRow(row, index) {
    var result = Object.assign({}, row || {});
    var levelMap = { "硕士": "硕士研究生", "本科": "大学本科", "博士": "博士研究生" };
    result.ccbLevel = levelMap[result.level] || result.level;
    result.ccbSchoolType = isAffirmative(result.isOverseas) ? "境外院校" : "境内院校";
    result.ccbHighestEducation = index === 0 ? "是" : "否";
    result.ccbHighestDegree = index === 0 ? "是" : "否";
    result.ccbOtherSchool = result.示例资料School || result.school || "";
    result.ccbOtherMajor = result.示例资料Major || result.major || "";
    result.ccbTrainingMode = result.示例资料Mode || result.studyMode || "统招统分";
    result.ccbClassRank = result.classRank || result.rank || result.ranking || "其他";
    result.ccbDegree = ccbDegreeOption(result.degree);
    return result;
  }

  function ccbDegreeOption(value) {
    var text = String(value || "").replace(/\s*学位$/, "").trim();
    if (!text) return "";
    if (/无|未取得/.test(text)) return "无学位（仅有学历）";
    var category = ["哲学", "经济学", "法学", "教育学", "文学", "历史学", "理学", "工学", "农学", "医学", "军事学", "管理学", "建筑学", "艺术学"]
      .find(function (name) { return text.indexOf(name) !== -1; });
    if (/博士/.test(text)) return "博士类-" + (category ? category + "博士" : "其它博士");
    if (/硕士/.test(text)) return "硕士类-" + (category ? category + "硕士" : "其它硕士");
    if (/学士/.test(text)) return "学士类-" + (category ? category + "学士" : "其它学士");
    return text;
  }

  function enrichCcbFamilyRow(row) {
    var result = Object.assign({}, row || {});
    if (!result.gender) {
      if (/母亲|妻子|女儿|姐|妹|奶奶|外婆/.test(String(result.relationship || ""))) result.gender = "女";
      else if (/父亲|丈夫|儿子|兄|弟|爷爷|外公/.test(String(result.relationship || ""))) result.gender = "男";
    }
    return result;
  }

  function enrichCcbWorkRow(row) {
    var result = Object.assign({}, row || {});
    result.ccbWorkType = result.__afCategory === "示例资料Experience" ? "实习" : "全职";
    result.ccbDepartmentPosition = [result.department, result.position].filter(Boolean).join(" / ");
    result.ccbDescription = [
      result.responsibilities || result.detailedContent,
      result.achievements || result.contribution,
      result.result,
    ].filter(Boolean).join("\n");
    return result;
  }

  function enrichCcbProjectRow(row) {
    var result = Object.assign({}, row || {});
    // 建行字段名与简历项目经历字段保持兼容，优先使用站点专用别名。
    result.company = result.company || result.organization || result.unit || "";
    result.name = result.name || result.示例资料Name || "";
    result.description = result.description || result.示例资料Description || result.detailedContent || result.details ||
      [result.background, Array.isArray(result.contributions) ? result.contributions.join("\n") : result.contributions, result.result]
        .filter(Boolean).join("\n");
    return result;
  }

  function enrichCcbAwardRow(row) {
    var result = Object.assign({}, row || {});
    var level = String(result.awardLevel || result.level || "").trim();
    result.ccbAwardLevel = /省级|部级/.test(level) ? "省部级" : level;
    return result;
  }

  function enrichCcbAwardRow(row) {
    var result = Object.assign({}, row || {});
    var level = String(result.awardLevel || result.level || "").trim();
    result.ccbAwardLevel = /省级|部级/.test(level) ? "省部级" : level;
    return result;
  }

  function enrichCcbOtherInfo(data, resume) {
    return Object.assign({}, resume && resume.示例资料Info || {}, data || {});
  }

  var ABC_SCHOOL_PROVINCE = {
    "上海交通大学": "上海市",
    "浙江大学": "浙江省",
  };

  var ABC_CITY_PROVINCE = {
    "上海市": "上海市",
    "杭州市": "浙江省",
  };

  var ABC_MAJOR_PATH = {
    "管理科学与工程": ["管理学", "管理科学与工程类", "管理科学与工程"],
    "信息管理与信息系统": ["管理学", "管理科学与工程类", "管理科学与工程"],
    "软件工程": ["工学", "计算机类", "软件工程"],
  };

  var ABC_MAJOR_SUBCATEGORY_ALIASES = {
    "地理科学类": "地理学类",
    "生物科学类": "生物学类",
    "系统理论类": "系统科学类",
    "艺术学理论类": "艺术学类",
  };

  function normalizeAbcMajorSubcategory(value) {
    var text = String(value || "").trim();
    return ABC_MAJOR_SUBCATEGORY_ALIASES[text] || text;
  }

  function inferAbcMajorCategoryFromSubcategory(value) {
    var text = normalizeAbcMajorSubcategory(value);
    if (!text) return "";
    if (/哲学/.test(text)) return "哲学";
    if (/经济|财政|金融|贸易/.test(text)) return "经济学";
    if (/法学|政治|社会|民族|马克思|公安学/.test(text)) return "法学";
    if (/教育|心理|体育/.test(text)) return "教育学";
    if (/语言|文学|新闻|传播/.test(text)) return "文学";
    if (/历史/.test(text)) return "历史学";
    if (/数学|物理|化学|天文|地理|大气|海洋|地球物理|地质|生物|系统|统计/.test(text)) return "理学";
    if (/力学|工程|机械|仪器|材料|能源|电气|电子|信息|自动化|计算机|土木|水利|测绘|化工|制药|矿业|纺织|轻工|交通|航空|航天|兵器|核|建筑|安全|生物医学|食品|环境|公安技术/.test(text)) return "工学";
    if (/植物|自然保护|动物|林学|水产|草学|农业/.test(text)) return "农学";
    if (/医学|临床|口腔|公共卫生|中医|药学|护理|法医/.test(text)) return "医学";
    if (/管理|工商|农林经济|公共管理|图书情报|档案|物流|电子商务|工业工程|旅游/.test(text)) return "管理学";
    if (/艺术|音乐|舞蹈|戏剧|影视|美术|设计/.test(text)) return "艺术";
    if (/交叉/.test(text)) return "其他";
    return "其他";
  }

  function findAbcMajorPathFromBankcommTree(major, subcategory) {
    var tree = (typeof window !== "undefined" && Array.isArray(window.AF_BANKCOMM_MAJOR_TREE))
      ? window.AF_BANKCOMM_MAJOR_TREE
      : [];
    var wanted = String(major || "").trim();
    var preferred = normalizeAbcMajorSubcategory(subcategory);
    if (!wanted) return null;
    for (var i = 0; i < tree.length; i++) {
      var groupName = normalizeAbcMajorSubcategory(tree[i] && tree[i].name);
      if (preferred && groupName !== preferred) continue;
      var children = Array.isArray(tree[i] && tree[i].children) ? tree[i].children : [];
      if (children.indexOf(wanted) !== -1) {
        return [inferAbcMajorCategoryFromSubcategory(groupName), groupName, wanted];
      }
    }
    for (var j = 0; j < tree.length; j++) {
      var fallbackGroup = normalizeAbcMajorSubcategory(tree[j] && tree[j].name);
      var fallbackChildren = Array.isArray(tree[j] && tree[j].children) ? tree[j].children : [];
      if (fallbackChildren.indexOf(wanted) !== -1) {
        return [inferAbcMajorCategoryFromSubcategory(fallbackGroup), fallbackGroup, wanted];
      }
    }
    return null;
  }

  function enrichAbcEducationRow(row) {
    var result = Object.assign({}, row || {});
    if (isPreHigherEducation(result)) {
      if (!result.degree) result.degree = "无";
      if (!result.department) result.department = "无";
      if (!result.示例资料Type) result.示例资料Type = "全日制";
    }
    if (!result.schoolProvince) {
      var schoolKey = Object.keys(ABC_SCHOOL_PROVINCE).find(function (name) {
        return String(result.school || "").indexOf(name) !== -1;
      });
      result.schoolProvince = schoolKey ? ABC_SCHOOL_PROVINCE[schoolKey] : ABC_CITY_PROVINCE[result.city];
    }
    var majorKey = Object.keys(ABC_MAJOR_PATH).find(function (name) {
      return String(result.major || "").indexOf(name) !== -1;
    });
    var majorPath = majorKey && ABC_MAJOR_PATH[majorKey];
    if (!majorPath && result.majorPath) {
      var storedMajorPath = String(result.majorPath || "").split(/\s+\/\s+/).filter(Boolean);
      if (storedMajorPath.length === 3) majorPath = storedMajorPath;
      else if (storedMajorPath.length === 2) majorPath = [
        inferAbcMajorCategoryFromSubcategory(storedMajorPath[0]),
        normalizeAbcMajorSubcategory(storedMajorPath[0]),
        storedMajorPath[1],
      ];
    }
    if (!majorPath) majorPath = findAbcMajorPathFromBankcommTree(result.major, result.majorSubcategory);
    if (majorPath) {
      if (!result.majorCategory) result.majorCategory = majorPath[0];
      if (!result.majorSubcategory) result.majorSubcategory = normalizeAbcMajorSubcategory(majorPath[1]);
      result.major = majorPath[2];
    }
    if (result.majorSubcategory) result.majorSubcategory = normalizeAbcMajorSubcategory(result.majorSubcategory);
    if (!result.majorCategory && result.majorSubcategory) result.majorCategory = inferAbcMajorCategoryFromSubcategory(result.majorSubcategory);
    return result;
  }

  function enrichAbcBasicInfo(data, resume) {
    var result = Object.assign({}, data || {});
    var resumeBasic = resume && resume.示例资料Info && typeof resume.示例资料Info === "object" ? resume.示例资料Info : {};
    if (!result.hukouLocationPath && resumeBasic.hukouLocationPath) result.hukouLocationPath = resumeBasic.hukouLocationPath;
    if (!result.hukouLocation && resumeBasic.hukouLocation) result.hukouLocation = resumeBasic.hukouLocation;
    var hukouPath = splitStoredAddressPath(result.hukouLocationPath) ||
      bankcommResidencePath(result.hukouLocation || result.birthOrigin || result.nativePlace);
    result.abcHukouProvince = hukouPath && hukouPath[0] || "";
    result.abcHukouCity = hukouPath && hukouPath[1] || "";
    result.abcHukouDistrict = hukouPath && hukouPath[2] || "";
    return result;
  }

  function enrichAbcSelfIntroduction(data, resume) {
    var source = data;
    if (source && typeof source === "object") {
      source = source.示例资料Introduction || source.示例资料Evaluation || source.summary ||
        source.description || source.content || "";
    }
    if (!source && resume && resume.示例资料Info && typeof resume.示例资料Info === "object") {
      source = resume.示例资料Info.示例资料Introduction || resume.示例资料Info.summary || "";
    }
    return { 示例资料Introduction: String(source || "").trim() };
  }

  function enrichAbcFamilyRow(row) {
    var result = Object.assign({}, row || {});
    var relation = String(result.relationship || result.relationshipCategory || "").trim();
    if (/父/.test(relation)) {
      result.abcRelationshipCategory = "三代以内直系";
      result.abcRelationship = "父亲";
    } else if (/母/.test(relation)) {
      result.abcRelationshipCategory = "三代以内直系";
      result.abcRelationship = "母亲";
    } else if (/祖父|爷爷/.test(relation)) {
      result.abcRelationshipCategory = "三代以内直系";
      result.abcRelationship = "祖父";
    } else if (/祖母|奶奶/.test(relation)) {
      result.abcRelationshipCategory = "三代以内直系";
      result.abcRelationship = "祖母";
    } else if (/外祖父|外公/.test(relation)) {
      result.abcRelationshipCategory = "三代以内直系";
      result.abcRelationship = "外祖父";
    } else if (/外祖母|外婆/.test(relation)) {
      result.abcRelationshipCategory = "三代以内直系";
      result.abcRelationship = "外祖母";
    } else if (/兄/.test(relation)) {
      result.abcRelationshipCategory = "三代以内旁系";
      result.abcRelationship = "兄弟";
    } else if (/姐|妹/.test(relation)) {
      result.abcRelationshipCategory = "三代以内旁系";
      result.abcRelationship = "姐妹";
    } else if (/儿/.test(relation)) {
      result.abcRelationshipCategory = "子女";
      result.abcRelationship = "儿子";
    } else if (/女/.test(relation)) {
      result.abcRelationshipCategory = "子女";
      result.abcRelationship = "女儿";
    } else if (/配偶|妻|夫|丈夫|太太|老婆|爱人/.test(relation)) {
      result.abcRelationshipCategory = "近姻亲";
      result.abcRelationship = "配偶";
    } else {
      result.abcRelationshipCategory = "其他";
      result.abcRelationship = "其他";
    }
    if (!result.示例资料Status) {
      result.示例资料Status = result.company ? "有工作" : "无工作";
    }
    if (!result.isBankEmployee) result.isBankEmployee = "否";
    return result;
  }

  function abcHasExistingFamilyRecords(doc) {
    doc = doc || document;
    function clean(text) {
      return String(text || "")
        .replace(/\s+/g, "")
        .replace(/亲属关系|添加|编辑|删除|保存|取消|必填|选填/g, "");
    }
    var cards = Array.from(doc.querySelectorAll(".ant-card")).filter(function (card) {
      var title = card.querySelector(".ant-card-head-title");
      return title && clean(title.textContent).indexOf("亲属关系") !== -1;
    });
    return cards.some(function (card) {
      var body = card.querySelector(".ant-card-body") || card;
      var text = clean(body.textContent);
      if (!text || /^(暂无|暂无数据|暂未添加|未填写|无数据)$/.test(text)) return false;
      return /父亲|母亲|配偶|儿子|女儿|兄弟|姐妹|祖父|祖母|外祖父|外祖母|有工作|无工作|已退休|已辞世|农行员工|工作单位|担任职务/.test(text);
    });
  }

  function abcEducationRank(row) {
    var text = String(row && row.level || "");
    if (/博士/.test(text)) return 5;
    if (/硕士|研究生/.test(text)) return 4;
    if (/双学位/.test(text)) return 3;
    if (/本科|学士|大学/.test(text)) return 3;
    if (/专科|大专/.test(text)) return 2;
    if (/高中|中专|职高|技校/.test(text)) return 1;
    return 0;
  }

  function compareAbcEducationRows(left, right) {
    var rankDiff = abcEducationRank(right) - abcEducationRank(left);
    if (rankDiff) return rankDiff;
    return compareEducationByStartTimeDesc(left, right);
  }

  function validateAbcEducationRows(rows) {
    rows = Array.isArray(rows) ? rows : [];
    var hasPreHigher = rows.some(isPreHigherEducation);
    if (!hasPreHigher) return "农业银行要求教育背景从最高学历填写直到高中，但当前简历没有高中/中专示例资料";
    return "";
  }

  function enrichAbcCampusLeadershipRow(row) {
    var result = Object.assign({}, row || {});
    var levelMap = {
      "院级": "学院级",
      "学院": "学院级",
      "班级": "系级",
      "社团": "系级",
      "其他": "系级",
    };
    result.abcLeadershipLevel = levelMap[result.leadershipLevel] || result.leadershipLevel;
    return result;
  }

  function enrichAbcSocialPracticeRow(row) {
    var result = Object.assign({}, row || {});
    result.abcPracticeName = result.activityName || result.company || result.name || result.示例资料Name;
    result.abcPracticeDescription = result.description || result.detailedContent || result.responsibilities || result.details;
    result.abcPracticeDuty = result.role || result.contribution || result.position || result.result;
    return result;
  }

  function hasCompleteAbcPublicationRow(row) {
    row = enrichAbcPublicationRow(row);
    return !!(
      String(row.paperTitle || row.title || row.name || "").trim() &&
      String(row.journal || row.publisher || "").trim() &&
      String(row.publishTime || row.publishYear || "").trim()
    );
  }

  function enrichAbcPublicationRow(row) {
    var result = Object.assign({}, row || {});
    result.paperTitle = result.paperTitle || result.title || result.name ||
      result.articleTitle || result.publicationTitle || result["文章/专著名称"] ||
      result["文章/著作名称"] || result["论文/专著名称"] || result["论文/著作名称"] ||
      result["论文标题"] || result["论文名称"] || result["专著名称"] || result["著作名称"];
    result.journal = result.journal || result.publisher || result.venue ||
      result.conference || result["刊物/出版社"] || result["期刊/会议"] ||
      result["期刊名称"] || result["出版社"];
    result.publicationLevel = result.publicationLevel || result.level ||
      result.journalLevel || result["刊物级别"] || result["期刊级别"];
    result.contribution = result.contribution || result.authorRole ||
      result.authorRank || result["文章贡献"] || result["作者身份"] || result["作者位次"];
    result.publishTime = result.publishTime || result.publishDate ||
      result.publicationDate || result["刊载/出版时间"] || result["发表日期"];
    if (!result.publishTime && result.publishYear) result.publishTime = result.publishYear + "-01-01";
    if (/核心/.test(String(result.publicationLevel || ""))) result.publicationLevel = "核心期刊";
    else if (/SCI/i.test(String(result.publicationLevel || ""))) result.publicationLevel = "SCI";
    else if (/SSCI/i.test(String(result.publicationLevel || ""))) result.publicationLevel = "SSCI";
    else if (/CSSCI/i.test(String(result.publicationLevel || ""))) result.publicationLevel = "CSSCI";
    else if (/EI/i.test(String(result.publicationLevel || ""))) result.publicationLevel = "EI";
    else if (/国际/.test(String(result.publicationLevel || ""))) result.publicationLevel = "国际会议";
    else if (/会议/.test(String(result.publicationLevel || ""))) result.publicationLevel = "国内会议";
    if (!result.publicationLevel) result.publicationLevel = "其他";
    if (/共同.*一|共一/.test(String(result.contribution || ""))) result.contribution = "共同第一作者";
    else if (/第一|1/.test(String(result.contribution || ""))) result.contribution = "第一作者";
    else if (/第二|2/.test(String(result.contribution || ""))) result.contribution = "第二作者";
    else if (/通讯/.test(String(result.contribution || ""))) result.contribution = "通讯作者";
    else if (/参与|其他/.test(String(result.contribution || ""))) result.contribution = "参与作者";
    if (!result.contribution) result.contribution = "参与作者";
    return result;
  }

  function cmbcWizardStep(title, category, options) {
    options = options || {};
    return Object.assign({
      name: title,
      category: category,
      wizardSectionTitle: title,
      wizardHeadingSelector: "h5",
      wizardNavigateWhenNoData: true,
      wizardAllowPartialFill: true,
      wizardRetryNextWhenStayed: true,
      fillMode: "full",
      waitAfterClickMs: 300,
      timeoutMs: 6000,
      skipClickWhenReady: true,
      saveText: ["下一节"],
      waitAfterSaveMs: 900,
    }, options);
  }

  function enrichCmbcBasicInfo(data) {
    var result = Object.assign({}, data || {});
    var 示例资料Map = { "硕士": "硕士研究生", "本科": "大学本科", "博士": "博士研究生" };
    result.cmbcHighestEducation = 示例资料Map[result.highestEducation] || result.highestEducation;
    result.cmbcAssociateUpgrade = "否";
    result.cmbcPhoneArea = "+86";
    result.cmbcPostalCode = result.postalCode || result.zipCode || "";
    result.cmbcFamilyAddress = result.示例资料Address || result.currentAddress;
    function splitProvince(value) {
      var text = String(value || "").trim();
      var match = text.match(/^(北京市|上海市|天津市|重庆市|[^省]+省|广西壮族自治区|内蒙古自治区|宁夏回族自治区|新疆维吾尔自治区|西藏自治区|香港特别行政区|澳门特别行政区)(.*)$/);
      return match ? { province: match[1], detail: match[2] } : { province: "", detail: text };
    }
    var hukou = splitProvince(result.hukouLocation);
    var current = splitProvince(result.currentAddress);
    result.cmbcHukouProvince = hukou.province;
    result.cmbcHukouDetail = hukou.detail;
    result.cmbcCurrentProvince = current.province;
    result.cmbcCurrentDetail = current.detail;
    var politicalMap = {
      "中共党员": "中国共产党党员",
      "中共预备党员": "中国共产党预备党员",
    };
    result.cmbcPoliticalStatus = politicalMap[result.politicalStatus] || result.politicalStatus;
    return result;
  }

  function enrichCmbcEducationRow(row) {
    var result = Object.assign({}, row || {});
    var levelMap = { "硕士": "硕士研究生", "本科": "大学本科", "博士": "博士研究生" };
    result.cmbcLevel = levelMap[result.level] || result.level;
    // 民生教育背景的“院校类别”为必填下拉。优先使用简历中的境外标记，
    // 同时兼容已解析成“学校/院校类别”的字段；没有该信息时按境内院校处理。
    var schoolTypeText = String(result.schoolType || result.schoolCategory || result.institutionType || "");
    var isOverseasSchool = isAffirmative(result.isOverseas) || /境外|国外|海外/.test(schoolTypeText);
    result.cmbcSchoolType = isOverseasSchool ? "境外院校" : "境内院校";
    result.cmbcFullTime = /全日制/.test(String(result.示例资料Type || "")) ? "是" : "否";
    return result;
  }

  function isCmbcHigherEducationRow(row) {
    var level = String(row && (row.level || row.示例资料Level || row.degreeLevel) || "").trim();
    // 民生银行教育背景只要求高等教育；没有学历值的记录暂不拦截，交给必填校验处理。
    return !level || !/高中|中专|中技|职高|技校|初中|小学/.test(level);
  }

  function enrichCmbcInternshipRow(row) {
    var result = Object.assign({}, row || {});
    result.cmbcDepartment = result.department || "业务部门";
    result.cmbcDuty = [
      result.detailedContent,
      result.responsibilities,
      result.description,
      result.content,
      result.contribution,
      result.result,
    ].filter(Boolean).join("\n");
    return result;
  }

  function enrichCmbcPublicationRow(row) {
    var result = Object.assign({}, row || {});
    result.cmbcPublicationName = result.paperTitle || result.title || result.name;
    result.cmbcJournal = result.journal || result.publisher;
    result.cmbcPublicationLevel = result.publicationLevel || result.level || "公开发表";
    result.cmbcPublishTime = result.publishTime || (result.publishYear ? result.publishYear + "-01-01" : "");
    return result;
  }

  function enrichCmbcAwardRow(row) {
    var result = Object.assign({}, row || {});
    result.cmbcAwardName = result.awardName || result.name;
    result.cmbcAwardTime = result.awardTime || result.time;
    if (!result.grantor) {
      if (/上海交通大学/.test(String(result.cmbcAwardName || ""))) result.grantor = "上海交通大学";
      else if (/互联网\+/.test(String(result.cmbcAwardName || ""))) result.grantor = "中国国际大学生创新大赛组委会";
      else if (/产品设计创新大赛/.test(String(result.cmbcAwardName || ""))) result.grantor = "全国大学生产品设计创新大赛组委会";
    }
    return result;
  }

  function enrichCmbcSkills(data, resume) {
    var 示例资料s = resume && Array.isArray(resume.示例资料Skills) ? resume.示例资料Skills : [];
    var english = 示例资料s.find(isEnglishLanguage) || {};
    var 示例资料 = resume && Array.isArray(resume.示例资料) ? resume.示例资料 : [];
    var 示例资料 = resume && resume.示例资料Info || {};
    var result = Object.assign({}, data || {});
    if (/CET[- ]?6|六级/i.test(String(english.certificate || english.certificateName || ""))) result.cmbcCet6 = english.score;
    else if (/CET[- ]?4|四级/i.test(String(english.certificate || english.certificateName || ""))) result.cmbcCet4 = english.score;
    result.cmbcComputerLevel = 示例资料.示例资料Level || "熟练使用Office、SQL及常用办公软件";
    result.cmbcHobbies = 示例资料.hobbies || "";
    result.cmbcStrengths = 示例资料.strengths || 示例资料.specialty || "";
    result.cmbcCertificateNames = 示例资料.map(function (row) { return row && row.certificateName; }).filter(Boolean);
    return result;
  }

  function enrichCmbcJobIntention(data) {
    var result = Object.assign({}, data || {});
    result.cmbcLocation = result.city || result.expectedLocation;
    var salaryText = String(result.salary || result.expectedSalary || "");
    var salaryNumbers = salaryText.match(/\d+(?:\.\d+)?/g) || [];
    if (salaryNumbers.length) {
      var monthly = salaryNumbers.map(Number).reduce(function (sum, value) { return sum + value; }, 0) / salaryNumbers.length;
      result.cmbcAnnualSalary = String(Math.round(monthly * 12 / 10));
    }
    result.cmbcInternalAdjustment = result.obeyAssignment === false ? "否" : "是";
    result.cmbcCrossAdjustment = result.cityFlexible === false ? "否" : "是";
    result.cmbcAvailability = /周|月/.test(String(result.availability || "")) ? "1个月内" : "面谈";
    return result;
  }

  function czbankInlineStep(componentId, name, category, options) {
    options = options || {};
    return Object.assign({
      name: name,
      category: category,
      triggerSelector: componentId + " button.el-button--primary",
      readySelector: componentId + " form.el-form input, " + componentId + " form.el-form textarea",
      scopeSelector: componentId,
      fillMode: "full",
      waitAfterClickMs: 350,
      timeoutMs: 7000,
      skipClickWhenReady: true,
      skipWhenUnavailable: true,
      saveOnPartialFill: true,
      keepEditorOnError: true,
      saveText: ["保存"],
      waitAfterSaveMs: 450,
      waitForCloseSelector: "form.el-form input, form.el-form textarea",
      saveTimeoutMs: 7000,
      diagnosticCloseSelector: "button.el-button--default, .submit-btn button:last-child",
    }, options);
  }

  function job51ResumeStep(sectionSelector, name, category, actionText, options) {
    options = options || {};
    return Object.assign({
      name: name,
      category: category,
      cardAsScope: true,
      triggerSelector: sectionSelector,
      readySelector: sectionSelector + " form.el-form input, " + sectionSelector + " form.el-form textarea",
      scopeSelector: sectionSelector,
      fillMode: "full",
      waitAfterClickMs: 250,
      timeoutMs: 5000,
      skipClickWhenReady: true,
      skipWhenUnavailable: true,
      saveOnPartialFill: true,
      keepEditorOnError: true,
      afterClickActionText: actionText || ["编辑", "新增"],
      afterClickActionCandidateSelector: "button, a, [role='button'], div, span",
      afterClickActionTimeoutMs: 2200,
      afterClickActionAllowHidden: true,
      hoverBeforeAction: true,
      hoverBeforeActionWaitMs: 350,
      saveText: ["完成"],
      waitAfterSaveMs: 350,
      waitForCloseSelector: "form.el-form input, form.el-form textarea",
      saveTimeoutMs: 5000,
      continueOnError: true,
      stopOnSaveError: true,
      postSaveConfirmSelector: ".el-dialog__wrapper, .el-message-box__wrapper",
      postSaveConfirmText: ["同意", "确定", "我知道了"],
      postSaveConfirmRejectText: "退出编辑|不会自动保存",
      postSaveConfirmOptional: true,
      waitAfterConfirmMs: 350,
      diagnosticCloseSelector: "button.el-button--default, .dialog_button.cancel",
    }, options);
  }

  function job51ConsumerStep(cardTitle, name, category, options) {
    options = options || {};
    return Object.assign({
      name: name,
      category: category,
      cardTitle: cardTitle,
      cardSelector: ".resume-content > .resume-module:not(.jobs-wrapper)",
      cardTitleSelector: ":scope > .resume-module-header .left > .title",
      cardActionSelector: ":scope > .resume-module-header > .right",
      cardActionClickSelector: ".custom-button",
      triggerActionText: ["编辑", "添加"],
      cardAsScope: true,
      readySelector: "form.el-form input:not([type='hidden']), form.el-form textarea, form.el-form .el-select, form.el-form .el-date-editor",
      示例资料ReadySelector: "form.el-form",
      fillMode: "full",
      waitAfterClickMs: 350,
      timeoutMs: 7000,
      skipClickWhenReady: true,
      skipWhenUnavailable: true,
      saveText: ["保存"],
      waitAfterSaveMs: 450,
      waitForCloseSelector: "form.el-form input:not([type='hidden']), form.el-form textarea",
      saveTimeoutMs: 7000,
      saveOnPartialFill: true,
      continueOnError: true,
      stopOnSaveError: false,
    }, options);
  }

  function job51YearMonth(value) {
    return yearMonthValue(value);
  }

  function job51CityText(value) {
    var text = String(value || "").trim();
    if (!text) return "";
    text = text.replace(/^中国/, "");
    var direct = text.match(/^(北京市|上海市|天津市|重庆市)/);
    if (direct) return direct[1].replace(/市$/, "");
    var city = text.match(/(?:省|自治区|特别行政区)?([^省市区县]+市)/);
    if (city) return city[1].replace(/市$/, "");
    return text.replace(/(省|市|区|县)$/g, "");
  }

  function job51Arrival(value) {
    var text = String(value || "").trim();
    if (!text) return "";
    if (/随时|立即|一周|周内|7天|两周|2周/.test(text)) return "周内到岗";
    if (/月|30天|一个月|1个月/.test(text)) return "月内到岗";
    return "观望机会";
  }

  function job51Identity(value, data) {
    var text = String(value || data && (data.currentIdentity || data.currentStatus || data.isFreshGraduate) || "").trim();
    if (/应届|学生|在校|毕业生|是/.test(text)) return "在校生";
    return "职场人";
  }

  function job51WorkType(value, row) {
    var text = String(value || row && (row.示例资料Mode || row.employmentType || row.__afCategory) || "").trim();
    if (/实习|示例资料/i.test(text)) return "实习";
    if (/兼职/.test(text)) return "兼职";
    return "全职";
  }

  function job51SalaryOption(value) {
    var amount = Number(value);
    if (!isFinite(amount) || amount <= 0) return "";
    if (amount < 10) return String(Math.round(amount * 10) / 10).replace(/\.0$/, "") + "千";
    var wan = amount / 10;
    return String(Math.round(wan * 10) / 10).replace(/\.0$/, "") + "万";
  }

  function job51SalaryRange(value) {
    var text = String(value || "");
    var numbers = text.match(/\d+(?:\.\d+)?/g) || [];
    if (!numbers.length) return { min: "", max: "", months: "12月" };
    var min = Number(numbers[0]);
    var max = Number(numbers[1] || numbers[0]);
    if (/元/.test(text) && !/千|k/i.test(text)) {
      if (/万/.test(text)) { min *= 10; max *= 10; }
      else { min /= 1000; max /= 1000; }
    }
    var months = (text.match(/(1[2-9]|2[0-4])\s*(?:薪|月)/) || [])[1] || "12";
    return { min: job51SalaryOption(min), max: job51SalaryOption(max), months: months + "月" };
  }

  function job51PoliticalStatus(value) {
    var text = String(value || "").trim();
    if (!text) return "";
    if (/预备党员/.test(text)) return "中共预备党员";
    if (/党员/.test(text)) return "中共党员";
    if (/团员/.test(text)) return "示例资料";
    if (/民主党派/.test(text)) return "民主党派人士";
    if (/无党派/.test(text)) return "无党派民主人士";
    if (/群众|公民/.test(text)) return "普通公民";
    return text;
  }

  function job51EducationLevel(value) {
    var text = String(value || "").trim();
    if (/博士/.test(text)) return "博士";
    if (/MBA|EMBA/i.test(text)) return "MBA/EMBA";
    if (/硕士|研究生/.test(text)) return "硕士";
    if (/本科|学士|大学/.test(text)) return "本科";
    if (/专科|大专/.test(text)) return "大专";
    if (/中技|中专/.test(text)) return "中技/中专";
    if (/高中/.test(text)) return "高中";
    if (/初中|小学/.test(text)) return "初中及以下";
    return text;
  }

  function job51LanguageLevel(value) {
    var text = String(value || "").trim();
    if (/母语|精通|流利|听说读写/.test(text)) return "听说读写流利";
    if (/熟练|良好|读写/.test(text)) return "读写熟练";
    return "简单沟通/读写";
  }

  function enrichJob51Basic(data, resume) {
    var result = Object.assign({}, resume && resume.示例资料Info || {}, data || {});
    var 示例资料 = resume && resume.jobIntention || {};
    result.job51Arrival = job51Arrival(result.availability || result.jobStatus || 示例资料.availability || result.currentStatus);
    result.job51Identity = job51Identity(result.currentIdentity || result.currentStatus || result.isFreshGraduate, result);
    result.job51BirthMonth = job51YearMonth(result.birthDate);
    result.job51WorkStart = /应届|在校|无/.test(String(result.currentIdentity || result.示例资料ExperienceYears || result.示例资料Years || ""))
      ? ""
      : job51YearMonth(result.示例资料StartDate || result.firstWorkDate);
    result.job51CurrentCity = job51CityText(result.currentCity || result.city || result.currentAddress || result.expectedLocation || 示例资料.city);
    result.job51HukouCity = job51CityText(result.hukouLocation || result.nativePlace || result.birthOrigin);
    result.job51PoliticalStatus = job51PoliticalStatus(result.politicalStatus);
    return result;
  }

  function job51ExternalDurationMonths(rows) {
    return (rows || []).reduce(function (total, row) {
      var start = new Date(String(row && row.startTime || "").replace(/\./g, "-") + "T00:00:00");
      var endText = String(row && row.endTime || "");
      var end = /至今|目前|现在/.test(endText) ? new Date() : new Date(endText.replace(/\./g, "-") + "T00:00:00");
      if (isNaN(start.getTime()) || isNaN(end.getTime()) || end < start) return total;
      return total + Math.max(1, (end.getFullYear() - start.getFullYear()) * 12 + end.getMonth() - start.getMonth() + 1);
    }, 0);
  }

  function enrichJob51ExternalBasic(data, resume) {
    var result = Object.assign({}, resume && resume.示例资料Info || {}, data || {});
    var 示例资料 = resume && resume.jobIntention || {};
    var 示例资料Rows = resume && Array.isArray(resume.示例资料Experience) ? resume.示例资料Experience : [];
    var 示例资料Rows = resume && Array.isArray(resume.示例资料Experience) ? resume.示例资料Experience : [];
    var country = String(result.country || result.nationality || "").trim();
    result.job51ExternalCountry = /^(中国|中华人民共和国|中国内地|大陆)$/.test(country) ? "中国大陆" : country;
    result.job51ExternalHukouPath = splitStoredAddressPath(result.hukouLocationPath) ||
      bankcommResidencePath(result.hukouLocation || result.birthOrigin || result.nativePlace);
    result.job51ExternalCurrentPath = splitStoredAddressPath(result.currentAddressPath) ||
      bankcommResidencePath(result.currentAddress || result.currentCity || result.city);
    result.job51ExternalExpectedPath = splitStoredAddressPath(示例资料.expectedLocationPath || result.expectedLocationPath) ||
      bankcommResidencePath(示例资料.expectedLocation || 示例资料.city || result.expectedLocation || result.city);
    result.job51ExternalCommunicationPath = result.job51ExternalCurrentPath;
    result.job51ExternalAddress = result.currentAddressDetail || result.currentAddress || "";
    result.job51ExternalHasRelative = result.hasRelativeInCompany == null
      ? "否"
      : (isAffirmative(result.hasRelativeInCompany) ? "是" : "否");
    result.job51ExternalHasWork = 示例资料Rows.length ? "是" : "否";
    var 示例资料Months = job51ExternalDurationMonths(示例资料Rows);
    result.job51ExternalWorkYears = 示例资料Months ? String(Math.max(1, Math.round(示例资料Months / 12))) : "";
    var financeInternRows = 示例资料Rows.filter(function (row) {
      return /金融|银行|证券|期货|保险|基金|信托/.test(String([
        row && row.industry, row && row.company, row && row.department, row && row.position,
      ].filter(Boolean).join(" ")));
    });
    result.job51ExternalHasFinanceIntern = financeInternRows.length ? "是" : "否";
    var internMonths = job51ExternalDurationMonths(financeInternRows);
    result.job51ExternalInternMonths = internMonths ? String(internMonths) : "";
    return result;
  }

  function job51ExternalStudyForm(row) {
    return /非全|在职|函授|业余|成人/.test(String(row && (row.示例资料Type || row.studyMode) || ""))
      ? "非全日制教育"
      : "全日制教育";
  }

  function job51ExternalDegree(row) {
    var text = String(row && (row.degree || row.degreeType || row.level) || "");
    if (/博士/.test(text)) return "博士";
    if (/硕士|研究生|MBA|EMBA/i.test(text)) return "硕士";
    return "学士";
  }

  function job51ExternalEducationRank(row) {
    var text = String(row && (row.level || row.degree || row.degreeType) || "");
    if (/博士/.test(text)) return 4;
    if (/硕士|研究生|MBA|EMBA/i.test(text)) return 3;
    if (/本科|学士|大学/.test(text)) return 2;
    if (/专科|大专/.test(text)) return 1;
    return 0;
  }

  function enrichJob51ExternalEducation(data, resume) {
    var rows = resume && Array.isArray(resume.示例资料) ? resume.示例资料.filter(function (row) {
      return row && job51ExternalEducationRank(row) > 0;
    }) : [];
    var highest = rows.slice().sort(function (left, right) {
      return job51ExternalEducationRank(right) - job51ExternalEducationRank(left);
    })[0] || {};
    var bachelor = rows.find(function (row) { return /本科|学士|大学/.test(String(row.level || row.degree || "")); }) || {};
    var master = rows.find(function (row) { return /硕士|研究生|MBA|EMBA/i.test(String(row.level || row.degree || row.degreeType || "")); }) || {};
    var doctor = rows.find(function (row) { return /博士/.test(String(row.level || row.degree || "")); }) || {};
    var result = Object.assign({}, data || {});
    result.job51ExternalHighestLevel = job51EducationLevel(highest.level || highest.degree).replace("MBA/EMBA", "硕士");
    result.job51ExternalHighestStudyForm = job51ExternalStudyForm(highest);
    result.job51ExternalHighestIsMba = /MBA|EMBA/i.test(String(highest.level || highest.degreeType || highest.major || "")) ? "是" : "否";
    result.job51ExternalHighestDegree = job51ExternalDegree(highest);
    result.job51ExternalHighestStart = highest.startTime || "";
    result.job51ExternalHighestEnd = highest.endTime || "";
    result.job51ExternalHighestSchool = highest.school || "";
    result.job51ExternalHighestMajor = highest.major || "";
    result.job51ExternalBachelorStart = bachelor.startTime || "";
    result.job51ExternalBachelorEnd = bachelor.endTime || "";
    result.job51ExternalBachelorSchool = bachelor.school || "";
    result.job51ExternalBachelorMajor = bachelor.major || "";
    result.job51ExternalBachelorStudyForm = job51ExternalStudyForm(bachelor);
    result.job51ExternalBachelorUpgrade = /专升本/.test(String([
      bachelor.level, bachelor.示例资料Type, bachelor.studyMode, bachelor.description,
    ].filter(Boolean).join(" "))) ? "是" : "否";
    result.job51ExternalMasterStart = master.startTime || "";
    result.job51ExternalMasterEnd = master.endTime || "";
    result.job51ExternalMasterSchool = master.school || "";
    result.job51ExternalMasterMajor = master.major || "";
    result.job51ExternalMasterStudyForm = job51ExternalStudyForm(master);
    result.job51ExternalDoctorStart = doctor.startTime || "";
    result.job51ExternalDoctorEnd = doctor.endTime || "";
    result.job51ExternalDoctorSchool = doctor.school || "";
    result.job51ExternalDoctorMajor = doctor.major || "";
    result.job51ExternalDoctorStudyForm = job51ExternalStudyForm(doctor);
    result.job51ExternalDoctorCombined = /硕博连读/.test(String([
      doctor.level, doctor.degreeType, doctor.description,
    ].filter(Boolean).join(" "))) ? "是" : "否";
    return result;
  }

  function enrichJob51ExternalLanguage(data, resume) {
    var rows = resume && Array.isArray(resume.示例资料Skills) ? resume.示例资料Skills : [];
    var english = rows.find(function (row) {
      return /英语|CET|TEM|示例资料|TOEFL|雅思|托福/i.test(String([
        row && row.name, row && row.certificate, row && row.certificateName,
      ].filter(Boolean).join(" ")));
    }) || {};
    var certificate = String(english.certificateName || english.certificate || english.level || "");
    var score = Number(String(english.score || "").match(/\d+(?:\.\d+)?/) || 0);
    var result = Object.assign({}, data || {});
    if (/六级|CET.?6/i.test(certificate)) {
      result.job51ExternalEnglishCertificate = "大学英语6级（CET6）";
      result.job51ExternalEnglishScore = score >= 550 ? "CET6 550分以上" : "CET6 425-550分";
    } else if (/四级|CET.?4/i.test(certificate)) {
      result.job51ExternalEnglishCertificate = "大学英语4级（CET4）";
      result.job51ExternalEnglishScore = score >= 550 ? "CET4 550分以上" : "CET4 425-550分";
    } else {
      result.job51ExternalEnglishCertificate = certificate;
      result.job51ExternalEnglishScore = english.score || "";
    }
    result.job51ExternalOtherEnglish = rows.filter(function (row) { return row !== english && /英语|示例资料|TOEFL|雅思|托福/i.test(String(row.name || row.certificateName || row.certificate || "")); })
      .map(function (row) { return [row.certificateName || row.certificate || row.name, row.score].filter(Boolean).join(" "); }).join("；");
    result.job51ExternalOtherLanguage = rows.filter(function (row) { return row !== english && !/英语|示例资料|TOEFL|雅思|托福/i.test(String(row.name || row.certificateName || row.certificate || "")); })
      .map(function (row) { return [row.name, row.certificateName || row.certificate, row.score].filter(Boolean).join(" "); }).join("；");
    return result;
  }

  function enrichJob51ExternalIt(data, resume) {
    var rows = [];
    ["示例资料Experience", "示例资料Experience", "示例资料Experience"].forEach(function (category) {
      (resume && Array.isArray(resume[category]) ? resume[category] : []).forEach(function (row) {
        String(row && row.techStack || "").split(/[,，、;/|]+/).forEach(function (skill) {
          skill = String(skill || "").trim();
          if (skill && rows.indexOf(skill) === -1) rows.push(skill);
        });
      });
    });
    var preferred = rows.find(function (skill) { return /Python/i.test(skill); }) ||
      rows.find(function (skill) { return /Java|C\+\+|C#|JavaScript|SQL|React|Vue|Node/i.test(skill); }) || rows[0] || "";
    return Object.assign({}, data || {}, {
      job51ExternalItCategory: /Python|Java|C\+\+|C#|JavaScript|React|Vue|Node/i.test(preferred) ? "开发编程类" : "办公应用类",
      job51ExternalItSkill: preferred,
      job51ExternalItLevel: preferred ? "熟练" : "",
    });
  }

  function enrichJob51ExternalWorkRow(row) {
    return Object.assign({}, row || {}, {
      job51ExternalWorkContent: [row && row.responsibilities, row && row.achievements].filter(Boolean).join("\n"),
    });
  }

  function enrichJob51ExternalInternRow(row) {
    return Object.assign({}, row || {}, {
      job51ExternalInternContent: [row && row.detailedContent, row && row.contribution, row && row.result].filter(Boolean).join("\n"),
    });
  }

  function enrichJob51ExternalPracticeRow(row) {
    return Object.assign({}, row || {}, {
      job51ExternalPracticeName: row && (row.activityName || row.示例资料Name || row.name || row.title) || "",
      job51ExternalPracticeRole: row && (row.role || row.title) || "",
      job51ExternalPracticeDescription: row && row.description || "",
    });
  }

  function enrichJob51ExternalFamilyRow(row) {
    var relationship = String(row && (row.relationship || row.relationshipCategory) || "");
    var supported = /^(父亲|母亲|配偶|子女|兄弟姐妹)$/.test(relationship) ? relationship : "其他";
    return Object.assign({}, row || {}, {
      job51ExternalFamilyRelationship: supported,
      job51ExternalFamilyOtherRelationship: supported === "其他" ? relationship : "",
      job51ExternalFamilyCompany: row && (row.company || row.示例资料Status) || "无",
      job51ExternalFamilyPosition: row && (row.position || row.示例资料Status) || "无",
    });
  }

  function enrichJob51ExternalOther(data, resume) {
    var result = Object.assign({}, resume && resume.示例资料Info || {}, data || {});
    var 示例资料 = resume && resume.jobIntention || {};
    var 示例资料 = resume && Array.isArray(resume.示例资料) ? resume.示例资料 : [];
    var 示例资料 = resume && Array.isArray(resume.示例资料) ? resume.示例资料 : [];
    function awardLevelText(row) {
      return String([row && row.awardLevel, row && row.awardName, row && row.awardGrade].filter(Boolean).join(" "));
    }
    var highestAward = 示例资料.find(function (row) { return /国家|全国/.test(awardLevelText(row)); }) ||
      示例资料.find(function (row) { return /省|市/.test(awardLevelText(row)); }) || 示例资料[0];
    var positionText = String(示例资料.position || 示例资料.expectedPosition || "");
    result.job51ExternalWillingAssign = result.willingAssign == null ? "是" : (isAffirmative(result.willingAssign) ? "是" : "否");
    result.job51ExternalWillingSales = /销售|市场|客户/.test(positionText) ? "是" : "否";
    result.job51ExternalExpectedRole = /技术|开发|算法|数据/.test(positionText) ? "金融科技类" :
      (/销售|市场|客户/.test(positionText) ? "市场开发类" : (/运营|管理/.test(positionText) ? "运营管理类" : "投研交易类"));
    result.job51ExternalHonorLevel = !highestAward ? "无" : (/国家|全国/.test(awardLevelText(highestAward)) ? "国家级" :
      (/省|市/.test(awardLevelText(highestAward)) ? "省市级" : "院校级"));
    result.job51ExternalHonorName = 示例资料.map(function (row) { return row && row.awardName; }).filter(Boolean).join("；");
    result.job51ExternalCertificates = 示例资料.map(function (row) { return String(row && row.certificateName || ""); }).filter(function (name) {
      return /期货从业|证券从业|基金从业/.test(name);
    });
    if (!result.job51ExternalCertificates.length) result.job51ExternalCertificates = ["无"];
    result.job51ExternalOtherCertificates = 示例资料.map(function (row) { return String(row && row.certificateName || ""); }).filter(function (name) {
      return name && !/期货从业|证券从业|基金从业/.test(name);
    }).join("；");
    result.job51ExternalSourceChannels = ["前程无忧"];
    result.job51ExternalDeclaration = "是";
    return result;
  }

  function enrichJob51Intention(data, resume) {
    var result = Object.assign({}, resume && resume.jobIntention || {}, data || {});
    var 示例资料 = resume && resume.示例资料Info || {};
    result.job51WorkType = job51WorkType(result.employmentType || 示例资料.employmentType, result);
    result.job51ExpectedCity = job51CityText(result.city || 示例资料.expectedLocation || 示例资料.city);
    result.position = result.position || 示例资料.expectedPosition || 示例资料.position;
    // 用户在简历编辑器中选择的标准岗位优先。
    // 原始职位名称仍保留给其他站点，不再为当前站点盲猜近似项。
    result.job51Position = result.job51Position || result.position;
    result.industry = result.industry || 示例资料.industry;
    var salary = job51SalaryRange(result.salary || result.expectedSalary || 示例资料.expectedSalary);
    result.job51SalaryMin = salary.min;
    result.job51SalaryMax = salary.max;
    result.job51SalaryMonths = salary.months;
    return result;
  }

  function enrichJob51Education(data) {
    var result = Object.assign({}, data || {});
    result.job51EducationStart = job51YearMonth(result.startTime);
    result.job51EducationEnd = job51YearMonth(result.endTime);
    result.job51Level = job51EducationLevel(result.level);
    result.示例资料Type = /非全|在职|函授/.test(String(result.示例资料Type || result.studyMode || "")) ? "非全日制" : "全日制";
    return result;
  }

  function prepareJob51NewestFirstRows(rows) {
    return (Array.isArray(rows) ? rows.slice() : []).sort(function (left, right) {
      var startDiff = String(right && right.startTime || "").localeCompare(String(left && left.startTime || ""));
      if (startDiff) return startDiff;
      return String(right && right.endTime || "").localeCompare(String(left && left.endTime || ""));
    });
  }

  function enrichJob51Work(data) {
    var result = Object.assign({}, data || {});
    result.job51WorkType = job51WorkType(result.示例资料Mode || result.employmentType, result);
    result.job51Position = result.job51Position || result.position;
    result.job51WorkStart = job51YearMonth(result.startTime);
    // 该站的结束时间不是“空值代表至今”。月份浮层底部有真正的
    // “至今”快捷按钮；必须保留这个语义，让时间驱动器打开结束时间并点击它。
    result.job51WorkEnd = isAffirmative(result.isCurrent) || /至今|目前|现在/.test(String(result.endTime || ""))
      ? "至今"
      : job51YearMonth(result.endTime);
    result.job51WorkDescription = [
      result.responsibilities || result.detailedContent,
      result.achievements || result.contribution,
      result.result,
    ].filter(Boolean).join("\n");
    return result;
  }

  function enrichJob51Advantage(data, resume) {
    var result = Object.assign({}, data || {});
    var candidates = [
      result.示例资料Introduction,
      resume && resume.示例资料Introduction && resume.示例资料Introduction.示例资料Introduction,
      resume && typeof resume.示例资料Introduction === "string" ? resume.示例资料Introduction : "",
      resume && resume.示例资料Info && resume.示例资料Info.示例资料Introduction,
    ].map(function (value) { return String(value || "").trim(); }).filter(Boolean);
    // 同一份简历可能同时保留基础信息版和独立模块版自我介绍。优先使用
    // 内容更完整的一份，避免旧残留值“1”覆盖页面里原本有效的个人优势。
    candidates.sort(function (left, right) { return right.length - left.length; });
    result.job51Advantage = candidates[0] || "";
    return result;
  }

  function enrichJob51Project(data) {
    var result = Object.assign({}, data || {});
    result.job51ProjectStart = job51YearMonth(result.startTime);
    // 和示例资料一致：结束日期控件是必填项，当前项目必须实际打开
    // 结束月份控件并选择“至今”，不能用空字符串跳过。
    result.job51ProjectEnd = isAffirmative(result.isCurrent) || /至今|目前|现在/.test(String(result.endTime || "")) ? "" : job51YearMonth(result.endTime);
    result.job51ProjectDescription = [
      result.description || result.details || result.detailedContent,
      result.responsibilities || result.contributions,
      result.achievements || result.result,
    ].filter(Boolean).join("\n");
    // 该下拉只能关联站内已保存的工作公司，无法凭简历文本创建新公司。
    // 项目关联公司又是选填，固定选“无”才能保证新用户流程稳定保存。
    result.job51ProjectCompany = "无";
    return result;
  }

  function job51SavedMonth(value) {
    return job51YearMonth(value).replace("-", ".");
  }

  function job51MatchText(value) {
    return String(value == null ? "" : value).replace(/\s+/g, "").trim();
  }

  function job51SavedEndMonth(row) {
    if (isAffirmative(row && row.isCurrent) || /至今|目前|现在/.test(String(row && row.endTime || ""))) return "至今";
    return job51SavedMonth(row && row.endTime);
  }

  // 该站的职位会被站内职能库归一（例如“B端产品经理”
  // 保存后可能显示为“产品经理/主管”），所以已有工作记录用
  // “公司+开始时间+结束时间”识别，不强制比较职位文案。
  function job51ExistingWorkRowMatcher(row, root) {
    root = root || document;
    var company = job51MatchText(row && row.company);
    var start = job51SavedMonth(row && row.startTime);
    var end = job51SavedEndMonth(row);
    if (!company || !start || !end) return false;
    var cards = [];
    try { cards = Array.from(root.querySelectorAll("#示例资料Experience .示例资料Experience_card")); } catch (e) {}
    return cards.some(function (card) {
      var savedCompany = job51MatchText(card.querySelector(".示例资料Experience_headerTitle") && card.querySelector(".示例资料Experience_headerTitle").textContent);
      var savedRange = job51MatchText(card.querySelector(".示例资料Experience_time") && card.querySelector(".示例资料Experience_time").textContent);
      return savedCompany === company && savedRange.indexOf(start) !== -1 && savedRange.indexOf(end) !== -1;
    });
  }

  function job51ExistingProjectRowMatcher(row, root) {
    root = root || document;
    var name = job51MatchText(row && (row.name || row.示例资料Name));
    var start = job51SavedMonth(row && row.startTime);
    var end = job51SavedEndMonth(row);
    if (!name || !start || !end) return false;
    var cards = [];
    try { cards = Array.from(root.querySelectorAll("#ProjectExperience .示例资料Content")); } catch (e) {}
    return cards.some(function (card) {
      var savedName = job51MatchText(card.querySelector(".示例资料NameDes") && card.querySelector(".示例资料NameDes").textContent);
      var savedRange = job51MatchText(card.querySelector(".示例资料Times") && card.querySelector(".示例资料Times").textContent);
      return savedName === name && savedRange.indexOf(start) !== -1 && savedRange.indexOf(end) !== -1;
    });
  }

  function enrichJob51Campus(data) {
    var result = Object.assign({}, data || {});
    if (result.__afCategory === "示例资料") {
      result.job51CampusType = "校内荣誉";
      result.job51CampusName = result.awardName || result.name;
      result.job51CampusDate = job51YearMonth(result.awardTime || result.obtainedTime);
    } else {
      result.job51CampusType = "校内职务";
      result.job51CampusName = result.title || result.position || result.role;
      result.job51CampusStart = job51YearMonth(result.startTime);
      result.job51CampusEnd = isAffirmative(result.isCurrent) || /至今|目前|现在/.test(String(result.endTime || "")) ? "" : job51YearMonth(result.endTime);
      result.job51CampusDescription = result.description || result.detailedContent || "";
    }
    return result;
  }

  function enrichJob51Language(data) {
    var result = Object.assign({}, data || {});
    result.job51LanguageName = result.name || result.示例资料;
    result.job51LanguageLevel = job51LanguageLevel(result.proficiency || result.level || result.readingWriting || result.speakingListening);
    return result;
  }

  function pinganSectionStep(sectionTitle, category, options) {
    options = options || {};
    var pinganSectionRoots = {
      "示例资料": ".示例资料-module",
      "联系信息": ".contact-module",
      "平安亲属": ".lan-modules",
      "示例资料": ".apply-module",
      "薪酬信息": ".item-module",
      "示例资料": ".示例资料-modules",
      "外部兼岗": ".示例资料-modules",
      "示例资料": ".edu-modules",
      "项目经历": ".pro-modules",
      "示例资料": ".train-modules",
      "专业技能": ".skill-modules",
      "证书": ".cert-modules",
      "语言技能": ".lan-modules",
      "综合能力简述": ".示例资料-module",
      "特长兴趣": ".示例资料-module",
    };
    return Object.assign({
      name: sectionTitle,
      category: category,
      cardTitle: sectionTitle,
      sectionByTitle: true,
      sectionRootSelector: pinganSectionRoots[sectionTitle] || "",
      cardAsScope: true,
      triggerText: [sectionTitle],
      preferNavigationTrigger: true,
      // 平安的右侧目录是稳定入口。限制在 anchor-nav 内，严格按照 steps
      // （即侧边栏）顺序点击，避免同名模块标题/保存表单被误认为导航入口。
      triggerRootSelector: ".anchor-nav",
      navigationTriggerCandidateSelector: "li, .icon-title, .icon-title span",
      triggerCandidateSelector: "button, a, [role='button'], li, span, div",
      readySelector: "input:not([type='hidden']), textarea, select, [role='combobox'], [role='textbox'], .el-select, .el-cascader, .ant-select, .ant-cascader-picker",
      fillMode: "full",
      waitAfterClickMs: 350,
      timeoutMs: 7000,
      skipClickWhenReady: false,
      // 保存态的单模块只在没有可见表单时才悬停并点击“编辑”；首次进入的空白
      // 简历通常已经展开表单，因此不会触发这条二次填写分支。
      editExistingSectionWhenClosed: true,
      existingEditActionSelector: ".edit.right, .edit.edit-btn, .edit-btn, [class*='edit']",
      skipWhenUnavailable: true,
      saveOnPartialFill: true,
      keepEditorOnError: true,
      reuseDirtyRepeatEditor: false,
      skipRemainingRepeatsOnError: true,
      // 平安每个栏目保存成功后都会退出 edit-mode。若仍能看到表单，说明有
      // 必填项没有进入 Vue model；此时停在当前栏目，不能继续打开后续栏目。
      waitForCloseSelector: "form.el-form.resume",
      // 平安各大类彼此相对独立；某个栏目保存失败时先记录失败并继续后续栏目，
      // 争取把能填的模块尽量填完。
      stopOnSaveError: false,
      saveText: ["保存"],
      waitAfterSaveMs: 550,
      saveTimeoutMs: 7000,
      postSaveConfirmSelector: ".el-message-box__wrapper, .el-dialog__wrapper, .ant-modal-confirm, [role='dialog']",
      postSaveConfirmText: ["确定", "OK", "我知道了"],
      postSaveConfirmButtonSelector: "button, a, [role='button']",
      postSaveConfirmOptional: true,
      waitAfterConfirmMs: 250,
    }, options);
  }

  function pinganCampusSectionStep(sectionTitle, category, options) {
    var 示例资料VerifyFieldsByTitle = {
      "示例资料": ["school"],
      "英语能力": ["pinganLanguageCertificate", "pinganLanguageName"],
      "其他示例资料": ["pinganLanguageName"],
      "工作/示例资料": ["pinganWorkUnitName", "company"],
      "项目经历": ["name", "示例资料Name"],
      "证书": ["pinganCertificateName", "certificateName", "name"],
      "奖励信息": ["pinganAwardName", "awardName", "name"],
      "校园活动经历": ["activityName", "name"],
    };
    var campusStep = Object.assign(pinganSectionStep(sectionTitle, category, {
      sectionRootSelector: ".cv-module",
      cardTitleSelector: ".title-wrapper .title, .modules-title .title, .title, [class*='title']",
      // 校招重复模块的真实 DOM 统一为
      // .cv-module > .content > .item > (.display-mode + .edit-mode)。
      // 复用社招稳定的“已有卡片按位置覆盖，保存后再新增”流程。
      updateExistingWhenPresent: true,
      overwriteExistingByPosition: true,
      // 空白简历的第一条也直接走当前栏目内的重复新增流程：若栏目已经留下
      // 一个可见空编辑器就复用，否则点击该栏目的隐藏添加按钮。
      forceAddFirstRepeatWhenNoExisting: true,
      // 校招真实结构在 .content 内还有 item-module 包装层，卡片本身稳定为
      // .item > .item-module > .display-mode。编辑入口只能取 .edit.edit-btn；泛化的
      // [class*='edit'] 会把 edit-mode 和 el-date-editor 都误算成卡片入口。
      existingCardSelector: ".item > .item-module > .display-mode",
      existingRecordSelector: ".item",
      existingEditActionSelector: ".edit.edit-btn",
      preferDirectExistingCards: true,
      requireMeaningfulExistingCard: true,
      // 二次填写把已有卡片视为空白槽位：逐张打开、清掉旧文本值、完整覆盖并保存。
      // 新增出来的卡片没有 updateExistingIndex，不会执行清空。
      clearBeforeFillExisting: true,
      existingEditHoverSelector: ".display-mode",
      afterClickActionText: ["添加" + sectionTitle, "新增" + sectionTitle],
      afterClickActionSelector: ".title-wrapper > .add.right",
      afterClickActionCandidateSelector: "button, a, [role='button'], div, span",
      示例资料AddText: ["添加" + sectionTitle, "新增" + sectionTitle, "添加", "新增"],
      示例资料AddSelector: ".title-wrapper > .add.right",
      示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
      示例资料AddHoverSelector: ".title-wrapper",
      // 复用社招的栏目内 示例资料-add 流程。校招按钮常驻 DOM、仅视觉隐藏，
      // 因此允许取到隐藏节点后仍由现有 safeClick 直接触发 Vue 的新增处理器。
      示例资料AddAllowHidden: true,
      示例资料AddNativeClick: true,
      示例资料AddUsePinganCampusBridge: true,
      strictRepeatAddRoot: true,
      示例资料ReadySelector: ".item-module .edit-mode form.el-form.resume, .item-module .edit-mode input:not([type='hidden']), form.el-form.resume",
      useVisibleRepeatEditorAsScope: true,
      activeRepeatEditorSelector: ".item > .item-module > .edit-mode",
      verifyRepeatCountAfterLast: true,
    }), options || {});
    // 可信悬停点击和重复卡片保存范围只服务“多条经历”。示例资料、联系
    // 信息及其它单卡模块继续沿用原来的容器激活、字段填写和保存流程。
    if (campusStep.示例资料ForCategoryData === true) {
      campusStep.saveOnPartialFill = false;
      campusStep.verifyRepeatSavedContent = true;
      campusStep.示例资料VerifyFields = 示例资料VerifyFieldsByTitle[sectionTitle] || [];
      // 示例资料的现有保存判定已经稳定，保持不动。其后的校招重复栏目会在
      // 保存成功后保留一份仍有尺寸的旧 form DOM，页面虽然已经显示新卡片，
      // 通用“等待 form 消失”仍会误报失败并跳过本类目后续条目。改由下方的
      // 主字段卡片核验判定保存成功；若网站真实未保存，找不到对应卡片仍会
      // 停止当前类目，不会继续制造重复数据。
      if (sectionTitle !== "示例资料") campusStep.waitForCloseSelector = "";
      campusStep.strictReadyWithinCard = true;
      campusStep.afterClickActionAllowHidden = true;
      campusStep.afterClickActionNativeClick = true;
      campusStep.afterClickActionUsePinganCampusBridge = true;
      campusStep.afterClickActionHoverSelector = ".title-wrapper";
      campusStep.saveSelector = ".btns button.ensure, .btns .el-button--primary";
    }
    return campusStep;
  }

  function normalizePinganEducationLevel(value) {
    var text = String(value || "").trim();
    if (/博士/.test(text)) return "博士研究生";
    if (/硕士|研究生/.test(text)) return "硕士研究生";
    if (/本科|学士|大学/.test(text)) return "本科";
    if (/专科|大专/.test(text)) return "大专";
    if (/高中|中专|职高|技校/.test(text)) return "高中";
    return text;
  }

  function preparePinganEducationRows(rows) {
    rows = Array.isArray(rows) ? rows.slice() : [];
    // 平安页面建议从高中开始填写；按时间升序保留高中、本科、硕士等完整经历。
    return rows.sort(compareEducationByStartTime);
  }

  function pinganCityCascaderPath(value) {
    var text = String(value || "").trim();
    if (!text) return [];
    text = text.replace(/^中国/, "");
    text = text.split(/[、,，/]/).map(function (part) { return part.trim(); }).filter(Boolean)[0] || text;
    var direct = text.match(/^(北京市|上海市|天津市|重庆市)/);
    if (direct) return [direct[1].replace(/市$/, ""), direct[1]];
    var province = text.match(/^(.*?(?:省|自治区|特别行政区))/);
    var provinceText = province && province[1] || "";
    var restText = provinceText ? text.slice(provinceText.length) : text;
    var city = restText.match(/^(.+?市)/) || restText.match(/^(.+?(?:地区|自治州|盟|州))/);
    var cityText = city && city[1] || "";
    if (provinceText && cityText) return [provinceText, cityText];
    if (/杭州/.test(text)) return ["浙江省", "杭州市"];
    if (/上海/.test(text)) return ["上海", "上海市"];
    if (/北京/.test(text)) return ["北京", "北京市"];
    if (/深圳|广州/.test(text)) return ["广东省", /深圳/.test(text) ? "深圳市" : "广州市"];
    return [text];
  }

  function enrichPinganBasic(data, resume) {
    var result = Object.assign({}, resume && resume.示例资料Info || {}, data || {});
    var 示例资料 = resume && resume.jobIntention || {};
    result.pinganHighestEducation = normalizePinganEducationLevel(result.highestEducation || result.level);
    result.pinganWorkYears = firstNumber(result.示例资料Years || result.示例资料ExperienceYears) || "0";
    result.pinganNativePlace = pinganCityCascaderPath(
      result.nativePlacePath || result.nativePlace || result.birthOriginPath || result.birthOrigin
    );
    result.pinganCurrentLocation = pinganCityCascaderPath(result.currentCity || result.city || result.currentAddress || 示例资料.city);
    result.pinganExpectedLocation = pinganCityCascaderPath(result.expectedLocation || 示例资料.city || result.city);
    return result;
  }

  function enrichPinganCampusBasic(data, resume) {
    var result = enrichPinganBasic(data, resume);
    result.pinganOverseasEducation = result.overseasEducation || result.hasOverseasEducation || "否";
    return result;
  }

  function enrichPinganJobIntention(data, resume) {
    var 示例资料 = resume && resume.示例资料Info || {};
    var result = Object.assign({}, 示例资料, resume && resume.jobIntention || {}, data || {});
    result.pinganCurrentLocation = pinganCityCascaderPath(result.currentLocation || result.currentCity || 示例资料.currentResidence || 示例资料.currentAddress || 示例资料.city);
    result.pinganExpectedLocation = pinganCityCascaderPath(result.expectedLocation || 示例资料.expectedLocation || result.city || 示例资料.city);
    result.pinganAvailability = result.availability || 示例资料.availability || "两周内到岗";
    return result;
  }

  function enrichPinganSalary(data, resume) {
    var 示例资料 = resume && resume.示例资料Info || {};
    var 示例资料 = resume && resume.jobIntention || {};
    var firstWork = resume && Array.isArray(resume.示例资料Experience) ? resume.示例资料Experience[0] || {} : {};
    var result = Object.assign({}, 示例资料, 示例资料, data || {});
    result.pinganCurrentSalary = annualSalaryWan(
      result.currentAnnualSalary || result.currentSalary || firstWork.annualSalary || firstWork.custom_income || 示例资料.currentSalary,
      !result.currentAnnualSalary && !result.currentSalary && !firstWork.annualSalary && !firstWork.custom_income && !!示例资料.currentSalary
    );
    result.pinganExpectedSalary = annualSalaryWan(
      result.expectedAnnualSalary || result.expectedSalary || 示例资料.expectedAnnualSalary || 示例资料.annualSalary || 示例资料.salary || 示例资料.expectedSalary,
      !result.expectedAnnualSalary && !result.expectedSalary && !示例资料.expectedAnnualSalary && !示例资料.annualSalary
    );
    result.pinganSalaryNote = result.salaryNote || "";
    return result;
  }

  function enrichPinganWorkRow(row, index, resume) {
    var result = Object.assign({}, row || {});
    result.pinganOverseasExperience = result.overseasExperience || result.hasOverseasExperience || "否";
    result.pinganJobLevel = result.jobLevel || result.rank || result.level || "专员";
    result.pinganWorkDescription = [
      result.responsibilities || result.detailedContent,
      result.achievements || result.contribution,
      result.result,
    ].filter(Boolean).join("\n");
    result.witnessName = result.witnessName || result.custom_referencePerson || "";
    result.witnessPhone = result.witnessPhone || result.custom_referencePersonPhone || "";
    return result;
  }

  function pinganWorkYearMonth(value) {
    var text = String(value == null ? "" : value).trim();
    if (/至今|目前|现在|仍在职|在职/.test(text)) return "至今";
    var match = text.match(/(\d{4})[-/.年](\d{1,2})/);
    return match ? match[1] + "." + String(Number(match[2])).padStart(2, "0") : text;
  }

  function pinganExistingWorkRowMatcher(row, root) {
    root = root || document;
    var company = String(row && row.company || "").replace(/\s+/g, "").trim();
    var position = String(row && row.position || "").replace(/\s+/g, "").trim();
    var start = pinganWorkYearMonth(row && row.startTime);
    var end = pinganWorkYearMonth(row && row.endTime);
    if (!company || !position || !start || !end) return false;
    var cards = [];
    try {
      cards = Array.from(root.querySelectorAll(".示例资料-modules .示例资料-module .display-mode"));
    } catch (e) {}
    return cards.some(function (card) {
      var savedCompany = String(card.querySelector(".companyName") && card.querySelector(".companyName").textContent || "").replace(/\s+/g, "").trim();
      var savedPosition = String(card.querySelector(".top-wrapper .title") && card.querySelector(".top-wrapper .title").textContent || "").replace(/\s+/g, "").trim();
      var savedRange = String(card.querySelector(".data-range") && card.querySelector(".data-range").textContent || "").replace(/\s+/g, "").trim();
      return savedCompany === company && savedPosition === position &&
        savedRange.indexOf(start) !== -1 && savedRange.indexOf(end) !== -1;
    });
  }

  function pinganExistingEducationRowMatcher(row, root) {
    root = root || document;
    var school = String(row && row.school || "").replace(/\s+/g, "").trim();
    var major = String(row && row.major || "").replace(/\s+/g, "").trim();
    var start = pinganWorkYearMonth(row && row.startTime);
    var end = pinganWorkYearMonth(row && row.endTime);
    if (!school || !start || !end) return false;
    var cards = [];
    try {
      cards = Array.from(root.querySelectorAll(".edu-modules .edu-module .display-mode"));
    } catch (e) {}
    return cards.some(function (card) {
      var savedSchool = String(card.querySelector(".school-name") && card.querySelector(".school-name").textContent || "").replace(/\s+/g, "").trim();
      var savedMajor = String(card.querySelector(".top-wrapper .major") && card.querySelector(".top-wrapper .major").textContent || "").replace(/\s+/g, "").trim();
      var savedRange = String(card.querySelector(".data-range") && card.querySelector(".data-range").textContent || "").replace(/\s+/g, "").trim();
      return savedSchool === school && (!major || savedMajor === major) &&
        savedRange.indexOf(start) !== -1 && savedRange.indexOf(end) !== -1;
    });
  }

  function pinganExistingProjectRowMatcher(row, root) {
    root = root || document;
    var name = String(row && row.name || "").replace(/\s+/g, "").trim();
    var start = pinganWorkYearMonth(row && row.startTime);
    var end = pinganWorkYearMonth(row && row.endTime);
    if (!name || !start || !end) return false;
    var cards = [];
    try {
      cards = Array.from(root.querySelectorAll(".pro-modules .pro-module .display-mode"));
    } catch (e) {}
    return cards.some(function (card) {
      var titleSpans = Array.from(card.querySelectorAll(".mode-title span"));
      var savedRange = String(titleSpans[0] && titleSpans[0].textContent || "").replace(/\s+/g, "").trim();
      var savedName = String(titleSpans[1] && titleSpans[1].textContent || "").replace(/\s+/g, "").trim();
      return savedName === name && savedRange.indexOf(start) !== -1 && savedRange.indexOf(end) !== -1;
    });
  }

  function pinganExistingCertificateRowMatcher(row, root) {
    root = root || document;
    var name = String(row && (row.pinganCertificateName || row.certificateName || row.name || row.certificate) || "")
      .replace(/\s+/g, "").trim();
    var type = String(row && (row.pinganCertificateType || row.certificateType) || "")
      .replace(/\s+/g, "").trim();
    var date = String(row && (row.pinganCertificateTime || row.obtainedTime || row.issueDate || row.time) || "")
      .replace(/[./年月]/g, "-").replace(/日/g, "").replace(/-+/g, "-").replace(/^-|-$/g, "").trim();
    if (!name) return false;

    var moduleRoot;
    try { moduleRoot = root.querySelector(".cert-modules") || root; } catch (e) { moduleRoot = root; }
    var cards = [];
    try {
      cards = Array.from(moduleRoot.querySelectorAll(".cert-module .display-mode, .display-mode"));
    } catch (e) {}
    // 某些页面版本没有 display-mode 类，退回到证书模块的已保存展示块；
    // 排除编辑表单，防止当前空白表单的标签文字被误判为已有记录。
    if (!cards.length) {
      try {
        cards = Array.from(moduleRoot.children || []).filter(function (node) {
          return node && !node.matches("form, .edit-mode") && !node.querySelector("form.el-form.resume");
        });
      } catch (e) {}
    }
    return cards.some(function (card) {
      var text = String(card && card.textContent || "").replace(/\s+/g, "");
      if (!text || text.indexOf(name) === -1) return false;
      if (type && text.indexOf(type) === -1) return false;
      if (!date) return true;
      var normalizedText = text.replace(/[./年月]/g, "-").replace(/日/g, "").replace(/-+/g, "-");
      return normalizedText.indexOf(date) !== -1;
    });
  }

  function pinganExistingLanguageRowMatcher(row, root) {
    root = root || document;
    var name = String(row && (row.pinganLanguageName || row.name || row.示例资料) || "")
      .replace(/\s+/g, "").trim();
    var level = String(row && (row.pinganLanguageLevel || row.level || row.proficiency) || "")
      .replace(/\s+/g, "").trim();
    var certificate = String(row && (row.pinganLanguageCertificate || row.certificateName || row.certificate) || "")
      .replace(/\s+/g, "").trim();
    if (!name) return false;
    var cards = [];
    try { cards = Array.from(root.querySelectorAll(".lan-modules .lan-module .display-mode")); } catch (e) {}
    return cards.some(function (card) {
      var text = String(card && card.textContent || "").replace(/\s+/g, "");
      if (!text || text.indexOf(name) === -1) return false;
      if (level && text.indexOf(level) === -1) return false;
      if (certificate && text.indexOf(certificate) === -1) return false;
      return true;
    });
  }

  function enrichPinganEducationRow(row) {
    var result = Object.assign({}, row || {});
    result.pinganLevel = normalizePinganEducationLevel(result.level);
    var isHighSchool = /高中|中专|职高|技校/.test(String(result.level || ""));
    var majorCategory = result.majorSubcategory || result.majorCategory || result.czbankMajorCategory || "";
    result.pinganMajor = isHighSchool
      ? ["其他", "其他"]
      : result.major
      ? (majorCategory ? [majorCategory, result.major] : result.major)
      : "";
    result.pinganDegree = isHighSchool ? "无" : result.degree;
    result.pinganStudyMode = isHighSchool ? "全国统招" : result.示例资料Type || "全日制";
    return result;
  }

  function normalizePinganCampusRank(value) {
    var text = String(value || "").trim();
    if (/前?5%|5%以内/.test(text)) return "前5%";
    if (/前?25%|25%以内/.test(text)) return "前25%";
    if (/前?50%|50%以内|中上/.test(text)) return "前50%";
    if (/50%以后|后50%|其他|一般/.test(text)) return "50%以后";
    return text || "前50%";
  }

  function enrichPinganCampusEducationRow(row) {
    var result = enrichPinganEducationRow(row);
    result.pinganFullTime = result.fullTime || result.isFullTime || result.isUnifiedAdmission || "是";
    result.pinganStudyRank = normalizePinganCampusRank(
      result.ranking || result.studyRanking || result.classRanking || result.gradeRanking
    );
    result.pinganOverseasExperience = result.overseasExperience || result.hasOverseasExperience || "否";
    return result;
  }

  function enrichPinganProjectRow(row) {
    var result = Object.assign({}, row || {});
    result.pinganProjectDescription = [
      result.details || result.description,
      result.contributions,
      result.result,
    ].filter(Boolean).join("\n");
    result.pinganProjectDuty = result.pinganProjectDescription;
    result.pinganProjectRole = result.role || result.position || "项目成员";
    return result;
  }

  function enrichPinganCampusActivityRow(row) {
    var result = Object.assign({}, row || {});
    result.activityName = result.activityName || result.name || result.示例资料Name || result.organization || "";
    result.role = result.role || result.title || result.position || "";
    result.description = result.description || result.duty || result.responsibility || result.details || "";
    return result;
  }

  function pinganCertificateType(value) {
    var text = String(value || "").trim();
    if (/软件设计师/.test(text)) return "软件设计师";
    if (/网络工程师/.test(text)) return "网络工程师";
    if (/系统分析师/.test(text)) return "系统分析师";
    if (/程序员/.test(text)) return "程序员";
    if (/PMP|项目管理专业人士/i.test(text)) return "项目管理专业人士资格认证（PMP）";
    if (/证券/.test(text)) return "证券从业资格证书";
    if (/基金/.test(text)) return "基金销售人员从业资格";
    if (/期货/.test(text)) return "期货从业人员资格证书";
    if (/银行从业/.test(text)) return "银行从业资格证书";
    return text ? "其他证书" : "";
  }

  function preparePinganCertificateRows(rows) {
    rows = Array.isArray(rows) ? rows.slice() : [];
    return rows.map(function (row) {
      return Object.assign({}, row, {
        pinganCertificateType: row && row.certificateType ||
          pinganCertificateType(row && (row.certificateName || row.name || row.certificate)),
      });
    }).filter(function (row) {
      return !!row.pinganCertificateType;
    });
  }

  function enrichPinganCertificateRow(row) {
    var result = Object.assign({}, row || {});
    result.pinganCertificateType = result.certificateType || result.pinganCertificateType ||
      pinganCertificateType(result.certificateName || result.name || result.certificate);
    result.pinganCertificateName = result.certificateName || result.name || result.certificate;
    result.pinganCertificateTime = result.obtainedTime || result.issueDate || result.time;
    result.pinganCertificateDescription = result.description || "";
    return result;
  }

  function enrichPinganLanguageRow(row) {
    var result = Object.assign({}, row || {});
    result.pinganLanguageName = result.name || result.示例资料 || "英语";
    var level = result.level || result.proficiency || "熟练";
    if (/精通/.test(level)) level = "精通";
    else if (/熟练|流利|CET[- ]?6|六级|TEM[- ]?8|专八/i.test(level)) level = "熟练";
    else if (/良好|日常|沟通|CET[- ]?4|四级|N2|N1/i.test(level)) level = "良好";
    else if (/普通|一般|基础|初级/.test(level)) level = "普通";
    result.pinganLanguageLevel = level;
    result.pinganLanguageCertificate = result.certificateName || result.certificate || "";
    result.pinganLanguageScore = result.score || "";
    result.pinganLanguageObtainedTime = result.obtainedTime || result.issueDate || result.time;
    result.pinganListeningSpeaking = normalizePinganLanguageAbility(result.speakingListening || result.listeningSpeaking || result.proficiency || result.level);
    result.pinganReadingWriting = normalizePinganLanguageAbility(result.readingWriting || result.proficiency || result.level);
    return result;
  }

  function normalizePinganLanguageAbility(value) {
    var text = String(value || "").trim();
    if (/精通/.test(text)) return "精通";
    if (/熟练|流利|高级|六级|专八|N1/i.test(text)) return "熟练";
    if (/良好|日常|沟通|中级|四级|N2/i.test(text)) return "良好";
    if (/普通|一般|基础|初级/.test(text)) return "普通";
    return text || "良好";
  }

  function isPinganEnglishRow(row) {
    var text = String(row && (row.name || row.示例资料 || row.certificateName || row.certificate) || "");
    return /英语|CET|TEM|托福|TOEFL|雅思|示例资料|四级|六级|专四|专八/i.test(text);
  }

  function enrichPinganCampusWorkRow(row, index, resume) {
    var result = enrichPinganWorkRow(row, index, resume);
    result.pinganWorkUnitName = result.company || result.unitName || result.organization;
    return result;
  }

  function enrichPinganCampusAwardRow(row) {
    var result = Object.assign({}, row || {});
    result.pinganAwardName = result.awardName || result.name || result.title;
    result.pinganAwardTime = result.awardTime || result.obtainedTime || result.time;
    result.pinganAwardLevel = result.awardLevel || result.level || result.awardGrade || result.grade;
    result.pinganAwardDescription = result.awardDescription || result.description || "";
    result.pinganAwardIssuer = result.issuingUnit || result.awardIssuer || result.issuer ||
      result.organizer || result.grantingUnit || result.awardOrganization || "学校/组委会";
    return result;
  }

  function enrichPinganSummary(data, resume) {
    var intro = resume && resume.示例资料Introduction;
    var 示例资料 = resume && resume.示例资料Info || {};
    // 网页简历编辑器当前唯一正式字段是 示例资料Introduction.示例资料Introduction。
    // 平安必须优先读取当前激活简历里这份最新保存值，不能被 示例资料Info 中
    // 历史遗留的同名字段覆盖。其余字段只在正式字段完全不存在时兼容旧数据。
    var canonicalIntro = intro && typeof intro === "object" && !Array.isArray(intro)
      ? String(intro.示例资料Introduction || "").trim()
      : "";
    var legacyIntro = typeof intro === "string" ? intro : intro && (
      intro.示例资料Evaluation || intro.summary || intro.description || intro.content
    );
    var introText = canonicalIntro || legacyIntro;
    return Object.assign({}, data || {}, {
      // 平安“综合能力简述”直接复用简历编辑器里的“自我介绍”。后面的字段
      // 仅用于兼容早期数据结构，不会覆盖用户已经填写的自我介绍。
      pinganSummary: introText || 示例资料.示例资料Introduction || 示例资料.strengths || 示例资料.specialty,
      pinganHobbies: 示例资料.hobbies || 示例资料.specialty || "阅读、跑步、产品设计",
      pinganProfessionalSkills: 示例资料.professionalSkills || 示例资料.示例资料Skills ||
        "产品规划、需求分析、数据分析、SQL、原型设计、项目推进、跨团队协作",
    });
  }

  function joinResumeRows(rows, fields) {
    return (Array.isArray(rows) ? rows : []).map(function (row) {
      return (fields || []).map(function (field) { return row && row[field]; }).filter(Boolean).join(" / ");
    }).filter(Boolean).join("\n");
  }

  function firstNumber(value) {
    var match = String(value == null ? "" : value).match(/\d+(?:\.\d+)?/);
    return match ? String(Number(match[0])) : "";
  }

  function annualSalaryWan(value, monthlyKFallback) {
    var text = String(value == null ? "" : value).trim();
    var numbers = text.match(/\d+(?:\.\d+)?/g) || [];
    if (!numbers.length) return "";
    var average = numbers.map(Number).reduce(function (sum, number) { return sum + number; }, 0) / numbers.length;
    if (/k/i.test(text) || monthlyKFallback === true) average = average * 12 / 10;
    if (average > 1000) average = average / 10000;
    return String(Math.max(0, Math.round(average)));
  }

  function normalizeCzbankEnglishLevel(value) {
    var text = String(value || "").trim();
    if (!text) return "";
    if (/CET[- ]?6|六级|大学英语六/i.test(text)) return "CET-6";
    if (/CET[- ]?4|四级|大学英语四/i.test(text)) return "CET-4";
    if (/TEM[- ]?8|专八|专业八/i.test(text)) return "专业英语八级";
    if (/TEM[- ]?4|专四|专业四/i.test(text)) return "专业英语四级";
    return text;
  }

  function normalizeCzbankIndustry(value) {
    var text = String(value || "").trim();
    if (!text) return "";
    if (/互联网|计算机|通信|高科技|软件|人工智能|金融科技/i.test(text)) return "互联网/计算机/通信/高科技企业等";
    if (/证券|基金|保险|信托|资管|租赁|财务公司|消费金融|非银/.test(text)) return "非银金融机构（证券、基金、保险、信托、资管、租赁、财务公司、消费金融公司等）";
    if (/银行/.test(text)) return "全国性股份制商业银行";
    if (/会计|律师|审计|咨询/.test(text)) return "会计师事务所、律师事务所、审计师事务所及咨询公司等";
    return text;
  }

  function normalizeCzbankCertificateNames(rows) {
    // 浙商把“职业资格证书”放在示例资料里，但控件值域是本站固定枚举，
    // 和用户简历里的自由证书名称不完全等价。为保证示例资料模块可保存、
    // 后续模块能继续执行，默认选择“无”，并在工作流提示中提醒用户复核。
    return "无";
  }

  function czbankHomepageName(value) {
    var text = String(value || "").trim();
    if (!text) return "";
    if (/github\.com/i.test(text)) return "GitHub";
    if (/linkedin\.com/i.test(text)) return "LinkedIn";
    if (/gitee\.com/i.test(text)) return "Gitee";
    if (/zhihu\.com/i.test(text)) return "知乎";
    return "个人主页";
  }

  function normalizeCzbankCurrentStatus(value) {
    var text = String(value || "").trim();
    if (!text) return "";
    if (/应届|在校/.test(text)) return "应届毕业生";
    if (/离职|待业/.test(text)) return "已离职";
    if (/在职/.test(text)) return "在职";
    return text;
  }

  function countryCascaderPath(country) {
    var value = String(country || "").trim();
    if (!value) return [];
    if (/中国|香港|澳门|台湾/.test(value)) return ["亚洲", value];
    return [value];
  }

  function yearMonthValue(value) {
    var text = String(value || "").trim();
    var match = text.match(/(\d{4})[-/.年](\d{1,2})/);
    if (!match) return text;
    return match[1] + "-" + String(Number(match[2])).padStart(2, "0");
  }

  function nativePlaceCascaderPath(value) {
    var text = String(value || "").trim();
    if (!text) return [];
    var direct = text.match(/^(北京市|上海市|天津市|重庆市)/);
    if (direct) {
      var directRest = text.slice(direct[1].length);
      var directDistrict = directRest.match(/^(.+?(?:区|县|市))/);
      return [direct[1], directDistrict ? direct[1] + directDistrict[1] : ""].filter(Boolean);
    }
    var province = text.match(/^(.*?(?:省|自治区|特别行政区|北京市|上海市|天津市|重庆市))/);
    var provinceText = province && province[1] || "";
    var rest = provinceText ? text.slice(provinceText.length) : text;
    var city = rest.match(/^(.+?市)/) || rest.match(/^(.+?(?:地区|自治州|盟|州))/);
    var cityText = city && city[1] || "";
    var districtRest = cityText ? rest.slice(cityText.length) : "";
    var district = districtRest.match(/^(.+?(?:区|县|市))/);
    var districtText = district && district[1] || "";
    var provinceShort = provinceText.replace(/省$/, "").replace(/自治区$/, "").replace(/特别行政区$/, "");
    if (provinceText && /省$/.test(provinceText) && cityText && cityText.indexOf(provinceText.replace(/省$/, "")) !== 0) {
      cityText = provinceShort + cityText;
    }
    if (provinceText && /省$/.test(provinceText) && districtText && cityText) {
      var bareCity = cityText.replace(provinceShort, "").replace(/市$/, "");
      districtText = provinceShort + bareCity + districtText;
    }
    return [provinceText, cityText, districtText].filter(Boolean);
  }

  function cityCascaderPath(value) {
    var text = String(value || "").trim();
    if (!text) return [];
    var direct = text.match(/^(北京市|上海市|天津市|重庆市)/);
    if (direct) {
      var rest = text.slice(direct[1].length);
      var district = rest.match(/^(.+?(?:区|县|市))/);
      if (district) return [direct[1], direct[1] + district[1]].filter(Boolean);
      return { path: [direct[1], "__FIRST__"], firstToken: "__FIRST__" };
    }
    var province = text.match(/^(.*?(?:省|自治区|特别行政区))/);
    var provinceText = province && province[1] || "";
    var restText = provinceText ? text.slice(provinceText.length) : text;
    var city = restText.match(/^(.+?市)/) || restText.match(/^(.+?(?:地区|自治州|盟|州))/);
    var cityText = city && city[1] || "";
    var districtRest = cityText ? restText.slice(cityText.length) : "";
    var district = districtRest.match(/^(.+?(?:区|县|市))/);
    if (district) return nativePlaceCascaderPath(text);
    if (provinceText && cityText) {
      var provinceShort = provinceText.replace(/省$/, "").replace(/自治区$/, "").replace(/特别行政区$/, "");
      var normalizedCity = /省$/.test(provinceText) && cityText.indexOf(provinceShort) !== 0
        ? provinceShort + cityText
        : cityText;
      return { path: [provinceText, normalizedCity, "__FIRST__"], firstToken: "__FIRST__" };
    }
    if (cityText) return { text: cityText, fallbackFirst: true };
    return { text: text, fallbackFirst: true };
  }

  function enrichCzbankBasic(data, resume) {
    var result = Object.assign({}, data || {});
    var 示例资料Rows = [];
    if (resume && Array.isArray(resume.示例资料Experience)) 示例资料Rows = 示例资料Rows.concat(resume.示例资料Experience);
    if (resume && Array.isArray(resume.示例资料Experience)) 示例资料Rows = 示例资料Rows.concat(resume.示例资料Experience);
    var latestWork = 示例资料Rows[0] || {};
    var 示例资料s = resume && Array.isArray(resume.示例资料Skills) ? resume.示例资料Skills : [];
    var english = 示例资料s.find(isEnglishLanguage) || {};
    var 示例资料 = resume && Array.isArray(resume.示例资料) ? resume.示例资料 : [];
    var 示例资料 = resume && resume.jobIntention || {};
    var isFresh = result.isFreshGraduate === "是" || result.currentStatus === "应届毕业生" || result.currentIdentity === "应届毕业生";

    result.czbankApplicationType = result.specificRecruitmentType ||
      (isFresh ? "校招" : "社招");
    result.czbankCurrentStatus = normalizeCzbankCurrentStatus(
      isFresh ? "应届毕业生" : (result.currentStatus || result.currentIdentity || result.jobStatus)
    );
    result.czbankResidence = countryCascaderPath(result.currentResidenceCountry || result.currentCountry || result.country || result.currentResidence);
    result.czbankResidenceCity = cityCascaderPath(result.currentResidenceCity || result.currentCity || result.currentAddress || result.city || result.expectedLocation);
    result.czbankNativePlace = nativePlaceCascaderPath(
      result.nativePlacePath || result.nativePlace || result.birthOriginPath || result.birthOrigin
    );
    result.czbankEnglishLevel = normalizeCzbankEnglishLevel(english.certificateName || english.certificate || english.level);
    result.czbankEnglishNote = english.description || (english.score ? "成绩：" + english.score : "");
    result.czbankOtherLanguages = 示例资料s.filter(function (row) { return !isEnglishLanguage(row); }).map(function (row) {
      return row && (row.name || row.示例资料);
    }).filter(Boolean);
    result.czbankComputerLevel = result.示例资料Level || result.示例资料Skills;
    result.czbankCertificates = normalizeCzbankCertificateNames(示例资料);
    // 浙商社交主页名称/地址是联动字段：有地址时名称也要有。
    // 有主页就补齐一组；没有主页则整组跳过。
    result.czbankHomepage = result.homepage || "";
    result.czbankHomepageName = result.czbankHomepage ? (result.homepageName || czbankHomepageName(result.czbankHomepage)) : "";
    result.czbankAwards = joinResumeRows(resume && resume.示例资料, ["awardName", "awardTime", "grantor"]) || "无";
    result.czbankTraining = joinResumeRows(resume && resume.示例资料Experience, ["name", "organization", "description"]) || "无";
    result.czbankHobbies = result.hobbies || result.strengths || result.specialty || "阅读、跑步、产品设计";
    result.czbankWorkStart = isFresh ? "" : (result.示例资料StartDate || latestWork.startTime);
    result.czbankWorkYears = isFresh ? "0" : firstNumber(result.示例资料Years || result.示例资料ExperienceYears);
    result.czbankBankWorkYears = firstNumber(result.bankWorkYears || result.financialWorkYears) || "0";
    result.czbankCurrentIndustry = isFresh ? "" : normalizeCzbankIndustry(result.currentIndustry || result.industry || latestWork.industry);
    result.czbankCurrentCompany = isFresh ? "" : (result.currentCompany || latestWork.company);
    result.czbankDepartmentPosition = isFresh ? "" : (result.currentDepartmentPosition || [latestWork.department, latestWork.position].filter(Boolean).join(" / "));
    result.czbankCurrentAnnualSalary = annualSalaryWan(
      isFresh ? "0" : (result.currentAnnualSalary || result.currentSalary || latestWork.annualSalary || latestWork.custom_income || 示例资料.currentSalary),
      !result.currentAnnualSalary && !result.currentSalary && !latestWork.annualSalary && !latestWork.custom_income && !!示例资料.currentSalary
    );
    result.czbankExpectedAnnualSalary = annualSalaryWan(
      result.expectedAnnualSalary || result.expectedSalary || 示例资料.expectedAnnualSalary || 示例资料.annualSalary || 示例资料.salary,
      !result.expectedAnnualSalary && !result.expectedSalary && !示例资料.expectedAnnualSalary && !示例资料.annualSalary
    );
    return result;
  }

  function compareEducationByStartTime(left, right) {
    return String(left && left.startTime || "").localeCompare(String(right && right.startTime || ""));
  }

  function compareEducationByStartTimeDesc(left, right) {
    return String(right && right.startTime || "").localeCompare(String(left && left.startTime || ""));
  }

  function inferBankcommEducationLevel(row) {
    row = row || {};
    var level = String(row.level || "").trim();
    // 学历和学位是两个独立字段：学历只读取 level，绝不能再根据
    // degree / degreeType 推断或覆盖。网页简历里选什么学历，交行就填什么。
    if (/博士/.test(level)) return "博士研究生";
    if (/硕士|研究生/.test(level)) return "硕士研究生";
    if (/双学位/.test(level)) return "双学位";
    if (/本科|学士|大学/.test(level)) return "本科";
    if (/专科|大专/.test(level)) return "大专";
    if (/^高中$/.test(level)) return "高中";
    if (/中等专科|中专|职业高中|职高|技工学校|技校/.test(level)) return "中专";
    if (/^(无|其他)$/.test(level)) return "无";
    return level;
  }

  function prepareBankcommEducationRows(rows) {
    return (Array.isArray(rows) ? rows : []).map(function (row) {
      var result = Object.assign({}, row || {});
      result.level = inferBankcommEducationLevel(result);
      return result;
    }).sort(compareBankcommEducationRows);
  }

  function compareBankcommEducationRows(left, right) {
    var rank = function (row) {
      var level = inferBankcommEducationLevel(row);
      if (/高中|中专|职高|技校/.test(level)) return 0;
      if (/专科|大专/.test(level)) return 1;
      if (/双学位/.test(level)) return 2;
      if (/本科|学士|大学/.test(level)) return 2;
      // “博士研究生”同时包含“研究生”，必须先判断博士。
      if (/博士/.test(level)) return 4;
      if (/硕士|研究生/.test(level)) return 3;
      return 5;
    };
    var diff = rank(left) - rank(right);
    if (diff) return diff;
    return compareEducationByStartTime(left, right);
  }

  // Bankcomm checkpoint probing lives in the private-site module and must not
  // depend on text helpers from the generic 示例资料flow bundle. Build117
  // accidentally called an out-of-scope `normalizeText()`. Those calls were
  // wrapped in defensive try/catch blocks, so the failure looked like “no
  // saved high-school card found” instead of a JavaScript exception. Keep a
  // local normalizer here so saved-card probing remains 示例资料-contained.
  function bankcommNormalizeText(value) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
  }

  function bankcommIsVisibleElement(element) {
    if (!element || element.nodeType !== 1) return false;
    if (element.isConnected === false) return false;
    try {
      var style = window.getComputedStyle ? window.getComputedStyle(element) : null;
      if (style && (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse")) return false;
    } catch (eStyle) {}
    try {
      var rect = element.getBoundingClientRect ? element.getBoundingClientRect() : null;
      if (rect && Number(rect.width || 0) === 0 && Number(rect.height || 0) === 0 && element.getClientRects && element.getClientRects().length === 0) {
        return false;
      }
    } catch (eRect) {}
    return true;
  }

  function bankcommEducationCandidateSignals(candidate, source) {
    var signal = {
      source: String(source || "compact_readonly"),
      hasPreHigherKeyword: false,
      dateCount: 0,
      hasSchoolLikeText: false,
      excludedBecauseEditor: false,
    };
    if (!candidate || candidate.nodeType !== 1 || !bankcommIsVisibleElement(candidate)) return signal;
    try {
      if (candidate.matches && candidate.matches("form, input, select, option, textarea, [role='listbox'], [role='option'], .ant-select-dropdown, .ant-cascader-menus")) {
        signal.excludedBecauseEditor = true;
      }
    } catch (eCandidateMatches) {}
    if (!signal.excludedBecauseEditor) {
      try {
        signal.excludedBecauseEditor = Array.from(candidate.querySelectorAll(
          "input:not([type='hidden']):not([disabled]), textarea:not([disabled]), select:not([disabled]), [contenteditable='true'], [role='textbox'], [role='combobox']"
        )).some(bankcommIsVisibleElement);
      } catch (eEditorControls) {}
    }
    var clone = null;
    try { clone = candidate.cloneNode(true); } catch (eClone) {}
    if (!clone) return signal;
    try {
      Array.from(clone.querySelectorAll(
        "form, select, option, input, textarea, button, [role='listbox'], [role='option'], .ant-select-dropdown, .ant-cascader-menus"
      )).forEach(function (node) {
        try { node.remove(); } catch (eRemove) {}
      });
    } catch (eSanitize) {}
    var text = bankcommNormalizeText(clone.textContent);
    signal.hasPreHigherKeyword = /高中|中专|职高|技校/.test(text);
    signal.dateCount = (text.match(/(?:19|20)\d{2}[-/.年]\d{1,2}(?:[-/.月]\d{1,2}日?)?/g) || []).length;
    signal.hasSchoolLikeText = /学校|中学|高中|中专|职高|技校|学院|大学|院校/.test(text);
    return signal;
  }

  function bankcommEvaluateEducationCheckpointCandidateSignals(signals) {
    signals = Array.isArray(signals) ? signals : [];
    return signals.some(function (signal) {
      return !!(
        signal &&
        signal.excludedBecauseEditor !== true &&
        signal.hasPreHigherKeyword === true &&
        Number(signal.dateCount || 0) >= 2 &&
        signal.hasSchoolLikeText === true
      );
    });
  }

  function bankcommCollectEducationReadOnlyCandidates(root) {
    var found = [];
    var sources = [];
    function add(candidate, source) {
      if (!candidate || candidate === root || found.indexOf(candidate) !== -1) return;
      found.push(candidate);
      sources.push(String(source || "compact_readonly"));
    }

    // Historical Bankcomm revisions used listStyle/listStyle2. Keep them as one
    // signal, but do not require either class for current revisions.
    try {
      Array.from(root.querySelectorAll(".listStyle, .listStyle2")).forEach(function (node) {
        add(node, "legacy_card");
      });
    } catch (eLegacy) {}

    // A titled Edit action is still a strong record boundary when available.
    try {
      var editSelector = ".anticon-form[title='编辑'], span[title='编辑'], [title='编辑'], [aria-label='编辑'], [aria-label='修改']";
      Array.from(root.querySelectorAll(editSelector)).filter(bankcommIsVisibleElement).forEach(function (action) {
        var current = action.parentElement || action;
        var best = current;
        for (var depth = 0; current && current !== root && depth < 7; depth += 1) {
          var text = bankcommNormalizeText(current.textContent);
          if (text && text.length <= 360) best = current;
          var parent = current.parentElement;
          if (!parent || parent === root) break;
          current = parent;
        }
        add(best, "edit_action_scope");
      });
    } catch (eEditActions) {}

    // Current Bankcomm can render an unlabelled pencil icon. Anchor on exact
    // pre-higher level text, then walk upward to a compact record block. This
    // cannot be satisfied by the section hint alone because that hint has no
    // two-date record structure.
    try {
      var walker = document.createTreeWalker(root, 4 /* NodeFilter.SHOW_TEXT */);
      var textNode = null;
      while ((textNode = walker.nextNode())) {
        var levelText = bankcommNormalizeText(textNode.nodeValue);
        if (!/^(高中|中专|职高|技校)$/.test(levelText)) continue;
        var currentNode = textNode.parentElement;
        for (var levelDepth = 0; currentNode && currentNode !== root && levelDepth < 7; levelDepth += 1, currentNode = currentNode.parentElement) {
          var compactText = bankcommNormalizeText(currentNode.textContent);
          if (compactText && compactText.length <= 360) add(currentNode, "level_text_scope");
        }
      }
    } catch (eTreeWalker) {}

    // Final record-scoped fallback: inspect descendants. Some current Bankcomm
    // layouts wrap a saved card together with hidden action/padding nodes, so a
    // strict compact-text limit can miss a real saved record. The evaluator
    // below still rejects editor controls; therefore widening collection here
    // does not turn the blank editor into a saved card.
    try {
      Array.from(root.querySelectorAll("div, li, section, article")).forEach(function (node) {
        if (!bankcommIsVisibleElement(node)) return;
        var text = bankcommNormalizeText(node.textContent);
        if (!text) return;
        if (!/高中|中专|职高|技校/.test(text) && !/(?:19|20)\d{2}[-/.年]\d{1,2}/.test(text)) return;
        add(node, "descendant_record_candidate");
      });
    } catch (eCompact) {}

    // Build89: some React/Ant layouts render the saved card outside the exact
    // #示例资料 descendant tree while keeping the section marker in place.
    // Probe a small ancestor neighborhood instead of assuming the root is the
    // complete record container. The evaluator remains the final safety gate.
    try {
      if (found.length === 0) {
        var scope = root;
        for (var ancestorDepth = 0; scope && ancestorDepth < 4; ancestorDepth += 1, scope = scope.parentElement) {
          Array.from(scope.querySelectorAll("div, li, section, article")).forEach(function (node) {
            if (!bankcommIsVisibleElement(node)) return;
            var text = bankcommNormalizeText(node.textContent);
            if (!text) return;
            if (!/高中|中专|职高|技校/.test(text)) return;
            if (!/(?:19|20)\d{2}[-/.年]\d{1,2}/.test(text)) return;
            add(node, "ancestor_record_candidate");
          });
        }
      }
    } catch (eAncestorFallback) {}

    return found.map(function (node, index) {
      return { node: node, source: sources[index] || "compact_readonly" };
    });
  }

  function bankcommWriteEducationCheckpointProbe(probe) {
    try {
      document.documentElement.setAttribute("data-af-bankcomm-示例资料-checkpoint-probe", JSON.stringify(probe || {}));
    } catch (eProbeWrite) {}
  }

  function bankcommResolveEducationScope(root, probe) {
    var scopes = [];
    function add(node, source) {
      if (!node || scopes.some(function (x) { return x.node === node; })) return;
      scopes.push({ node: node, source: source });
    }
    add(root, "示例资料_root");
    try {
      var current = root;
      for (var depth = 1; current && depth <= 3; depth += 1) {
        current = current.parentElement;
        add(current, "ancestor_" + depth);
      }
    } catch (eParent) {}
    try {
      var parent = root.parentElement;
      if (parent) Array.from(parent.children || []).forEach(function (child) { add(child, "sibling"); });
    } catch (eSibling) {}
    var best = scopes[0] || { node: root, source: "fallback" };
    var bestScore = -1;
    scopes.forEach(function (item) {
      try {
        var text = bankcommNormalizeText(item.node.textContent);
        var score = 0;
        if (/高中|中专|职高|技校/.test(text)) score += 2;
        score += Math.min(2, (text.match(/(?:19|20)\d{2}[-/.年]\d{1,2}/g) || []).length);
        if (/学校|中学|学院|大学|院校/.test(text)) score += 2;
        if (score > bestScore) { bestScore = score; best = item; }
      } catch (eScore) {}
    });
    if (probe) probe.scopeProbe = { selectedSource: best.source, candidateScopeCount: scopes.length, selectedScore: bestScore };
    return best.node || root;
  }

  function bankcommProbeEducationCheckpoint() {
    var probe = {
      示例资料RootFound: false,
      savedRecordCandidateCount: 0,
      candidateSignals: [],
      domProbe: {
        rootTag: "",
        descendantCount: 0,
        visibleBlockCount: 0,
        keywordNodeCount: 0,
        dateLikeNodeCount: 0
      },
      preHigherRecordConfirmed: false,
      checkpointResolved: false,
    };
    try {
      var root = document.querySelector("#示例资料");
      probe.示例资料RootFound = !!root;
      if (root) root = bankcommResolveEducationScope(root, probe);
      if (!root) {
        bankcommWriteEducationCheckpointProbe(probe);
        return probe;
      }
      try {
        probe.domProbe.rootTag = String(root.tagName || "").toLowerCase();
        probe.domProbe.descendantCount = root.querySelectorAll("*").length;
        var visibleBlocks = 0;
        var keywordNodes = 0;
        var dateNodes = 0;
        Array.from(root.querySelectorAll("div,li,section,article,span" )).forEach(function(node){
          if (!bankcommIsVisibleElement(node)) return;
          visibleBlocks += 1;
          var t = bankcommNormalizeText(node.textContent);
          if (/高中|中专|职高|技校/.test(t)) keywordNodes += 1;
          if (/(?:19|20)\d{2}[-/.年]\d{1,2}/.test(t)) dateNodes += 1;
        });
        probe.domProbe.visibleBlockCount = visibleBlocks;
        probe.domProbe.keywordNodeCount = keywordNodes;
        probe.domProbe.dateLikeNodeCount = dateNodes;
      } catch (eDomProbe) {}
      var candidates = bankcommCollectEducationReadOnlyCandidates(root);
      var signals = candidates.map(function (entry) {
        return bankcommEducationCandidateSignals(entry.node, entry.source);
      });
      probe.savedRecordCandidateCount = signals.filter(function (signal) {
        return signal && signal.excludedBecauseEditor !== true && Number(signal.dateCount || 0) >= 2 && signal.hasSchoolLikeText === true;
      }).length;
      probe.candidateSignals = signals.slice(0, 24).map(function (signal) {
        return {
          source: signal.source,
          hasPreHigherKeyword: signal.hasPreHigherKeyword === true,
          dateCount: Number(signal.dateCount || 0),
          hasSchoolLikeText: signal.hasSchoolLikeText === true,
          excludedBecauseEditor: signal.excludedBecauseEditor === true,
        };
      });
      probe.preHigherRecordConfirmed = bankcommEvaluateEducationCheckpointCandidateSignals(signals);
      probe.checkpointResolved = probe.preHigherRecordConfirmed;
      bankcommWriteEducationCheckpointProbe(probe);
      return probe;
    } catch (eProbe) {
      bankcommWriteEducationCheckpointProbe(probe);
      return probe;
    }
  }

  function bankcommHasSavedPreHigherEducation() {
    return bankcommProbeEducationCheckpoint().preHigherRecordConfirmed === true;
  }

  function bankcommEducationManualCheckpointReason() {
    // Bankcomm renders pre-higher 示例资料 with the same editor shell as
    // university records but asks for several fields whose semantics do not
    // cleanly match a high-school record. Even when the canonical profile has
    // a high-school row, do not force university-oriented mappings into it.
    // Once the user has manually saved a real high-school / secondary-school
    // card, the normal higher-示例资料 示例资料 示例资料flow may resume safely.
    if (!bankcommHasSavedPreHigherEducation()) {
      return "交通银行的高中/中专教育字段与高等教育字段结构不完全一致，请手动填写并保存第一条高中/中专示例资料";
    }
    return "";
  }

  function validateBankcommEducationRows(rows) {
    rows = Array.isArray(rows) ? rows : [];
    var levels = rows.map(inferBankcommEducationLevel);
    var hasHighSchool = levels.some(function (level) { return /高中|中专|职高|技校/.test(level); });
    var hasBachelor = rows.some(function (row) {
      var level = inferBankcommEducationLevel(row);
      return /本科|大学|双学位/.test(level);
    });
    var hasPostgraduate = levels.some(function (level) { return /硕士|博士|研究生/.test(level); });
    // Bankcomm requires 示例资料 starting from high school, but our canonical
    // profile 示例资料ally does not invent missing high-school data. If the
    // user has already completed and saved that card manually on the page,
    // regard the prerequisite as satisfied and continue with the canonical
    // higher-示例资料 rows on the next one-click run.
    if (!hasHighSchool && !bankcommHasSavedPreHigherEducation()) {
      return "交通银行要求从高中填写，但当前简历没有高中/中专示例资料";
    }
    if (hasPostgraduate && !hasBachelor) return "当前简历包含硕士/博士，但缺少本科示例资料";
    return "";
  }

  function compareBankcommExperienceRows(left, right) {
    var startDiff = String(left && left.startTime || "").localeCompare(String(right && right.startTime || ""));
    if (startDiff) return startDiff;
    return String(left && left.endTime || "").localeCompare(String(right && right.endTime || ""));
  }

  function bankcommCollectRepeatCardsForStep(root, step) {
    root = root || document;
    var section = step && step.示例资料AddRootSelector ? root.querySelector(step.示例资料AddRootSelector) : root;
    section = section || root;
    var cards = [];
    try {
      // 每张交行已保存卡片都有自己的编辑图标。从图标向上寻找“只包含当前
      // 一个编辑入口”的最小祖先，父级一旦包含多个编辑入口就停止。这样既不
      // 依赖 .listStyle/.listStyle2 的层级，也不会把整个列表当成一张卡。
      var editSelector = step.existingEditActionSelector || "[title='编辑']";
      cards = Array.from(section.querySelectorAll(editSelector)).map(function (action) {
        var current = action;
        var best = action.parentElement || action;
        while (current && current !== section) {
          var actionCount = 0;
          try { actionCount = current.querySelectorAll(editSelector).length; } catch (eCount) {}
          if (actionCount === 1) best = current;
          var parent = current.parentElement;
          if (!parent || parent === section) break;
          var parentActionCount = 0;
          try { parentActionCount = parent.querySelectorAll(editSelector).length; } catch (eParentCount) {}
          if (parentActionCount > 1) break;
          current = parent;
        }
        return best;
      }).filter(Boolean).filter(function (card, index, foundCards) {
        return foundCards.indexOf(card) === index;
      });
      if (!cards.length && step && step.existingCardSelector) {
        cards = Array.from(section.querySelectorAll(step.existingCardSelector)).filter(function (node, index, matches) {
          return !matches.some(function (candidate) {
            return candidate !== node && node.contains && node.contains(candidate);
          });
        });
      }
    } catch (e) {}
    return cards;
  }

  function bankcommCardIndexByText(row, root, step, fieldNames) {
    var cards = bankcommCollectRepeatCardsForStep(root, step);
    var wanted = (fieldNames || []).map(function (field) {
      return String(row && row[field] || "").replace(/\s+/g, "").trim();
    }).filter(Boolean);
    if (!wanted.length) return -1;
    return cards.findIndex(function (card) {
      var text = String(card && card.textContent || "").replace(/\s+/g, "").trim();
      return wanted.some(function (value) { return text.indexOf(value) !== -1; });
    });
  }

  function bankcommEducationMonthKey(value) {
    var match = String(value || "").match(/((?:19|20)\d{2})\D{0,3}(\d{1,2})/);
    if (!match) return "";
    return match[1] + String(Number(match[2])).padStart(2, "0");
  }

  function bankcommEducationLevelKey(value) {
    var text = String(value || "");
    if (/博士/.test(text)) return "博士";
    if (/硕士|研究生/.test(text)) return "硕士";
    if (/本科|学士|双学位/.test(text)) return "本科";
    if (/大专|专科/.test(text)) return "大专";
    if (/高中/.test(text)) return "高中";
    if (/中专|职高|技校/.test(text)) return "中专";
    return "";
  }

  // 同一用户的本科与硕士完全可能来自同一所学校。Build124 仍只用 school
  // 作为交行教育卡片 identity，因此本科保存后，硕士步骤会把刚保存的本科
  // 误认成“硕士已有卡片”，再打开并覆盖。教育 ownership 必须至少联合
  // 学校 + 学历；页面有日期时再用起止年月做强校验。
  function bankcommEducationCardTextMatchesRow(row, cardText) {
    var compactText = String(cardText || "").replace(/\s+/g, "").trim();
    if (!compactText) return false;
    var school = String(row && row.school || "").replace(/\s+/g, "").trim();
    if (school && compactText.indexOf(school) === -1) return false;

    var expectedLevel = bankcommEducationLevelKey(inferBankcommEducationLevel(row || {}));
    var actualLevel = bankcommEducationLevelKey(compactText);
    if (expectedLevel && actualLevel && expectedLevel !== actualLevel) return false;

    var startKey = bankcommEducationMonthKey(row && row.startTime);
    var endKey = bankcommEducationMonthKey(row && row.endTime);
    var cardDateMatches = String(cardText || "").match(/(?:19|20)\d{2}[-/.年]\d{1,2}(?:[-/.月]\d{1,2}日?)?/g) || [];
    var cardDateKeys = cardDateMatches.map(bankcommEducationMonthKey).filter(Boolean);
    if (startKey && cardDateKeys.length && cardDateKeys.indexOf(startKey) === -1) return false;
    if (endKey && cardDateKeys.length >= 2 && cardDateKeys.indexOf(endKey) === -1) return false;

    // 若卡片能读出学历，则学校+学历已经足够区分同校本科/硕士；若学历文本
    // 缺失，则至少要求起止年月同时命中，禁止退回到“只看学校”的危险匹配。
    if (expectedLevel && actualLevel) return true;
    if (startKey && endKey && cardDateKeys.indexOf(startKey) !== -1 && cardDateKeys.indexOf(endKey) !== -1) return true;
    return !expectedLevel && !!school;
  }

  function bankcommEducationCardIndex(row, root, step) {
    var cards = bankcommCollectRepeatCardsForStep(root, step);
    return cards.findIndex(function (card) {
      return bankcommEducationCardTextMatchesRow(row, card && card.textContent || "");
    });
  }

  function bankcommEducationRowExists(row, root, step) {
    try {
      var sectionRoot = root || document;
      var 示例资料Root = step && step.示例资料AddRootSelector ? sectionRoot.querySelector(step.示例资料AddRootSelector) : sectionRoot.querySelector && sectionRoot.querySelector("#示例资料");
      示例资料Root = 示例资料Root || sectionRoot;
      var robustCards = bankcommCollectEducationReadOnlyCandidates(示例资料Root).filter(function (entry) {
        var signal = bankcommEducationCandidateSignals(entry.node, entry.source);
        return signal.excludedBecauseEditor !== true && Number(signal.dateCount || 0) >= 2 && signal.hasSchoolLikeText === true;
      });
      if (robustCards.some(function (entry) {
        return bankcommEducationCardTextMatchesRow(row, entry.node && entry.node.textContent || "");
      })) return true;
    } catch (eRobustEducationIdentity) {}
    return bankcommEducationCardIndex(row, root, step) >= 0;
  }

  function bankcommWorkCardIndex(row, root, step) {
    return bankcommCardIndexByText(row, root, step, ["company"]);
  }

  function bankcommWorkRowExists(row, root, step) {
    return bankcommWorkCardIndex(row, root, step) >= 0;
  }

  function isPreHigherEducation(row) {
    return /高中|中专|职高|技校/.test(String(row && row.level || ""));
  }

  function prepareCzbankEducationRows(rows) {
    rows = Array.isArray(rows) ? rows.slice() : [];
    // 浙商教育背景页面要求从最高学历往下填：硕士/博士、本科、专科，
    // 最后再填高中/中专等高中同等学历。第一学历则仍按最早高等教育计算。
    var higherRows = rows.filter(function (row) { return !isPreHigherEducation(row); }).sort(compareEducationByStartTimeDesc);
    var preHigherRows = rows.filter(isPreHigherEducation).sort(compareEducationByStartTime);
    var sortedRows = higherRows.concat(preHigherRows);
    var firstHigherEducationStartTime = higherRows
      .slice()
      .sort(compareEducationByStartTime)
      .map(function (row) { return String(row && row.startTime || ""); })[0] || "";
    var highestHigherEducationIndex = sortedRows.findIndex(function (row) { return !isPreHigherEducation(row); });
    return sortedRows.map(function (row, index) {
      var isHighSchool = isPreHigherEducation(row);
      var isFirstHigherEducation = !isHighSchool && String(row && row.startTime || "") === firstHigherEducationStartTime;
      return Object.assign({}, row, {
        __afTotalRows: sortedRows.length,
        __afCzbankFirstEducation: isFirstHigherEducation ? "是" : "否",
        __afCzbankHighestEducation: !isHighSchool && index === highestHigherEducationIndex ? "是" : "否",
      });
    });
  }

  function enrichCzbankEducationRow(row, index, resume) {
    var result = Object.assign({}, row || {});
    var total = Number(result.__afTotalRows) || (resume && Array.isArray(resume.示例资料) ? resume.示例资料.length : 0);
    result.isHighestEducation = result.isHighestEducation || (index === Math.max(0, total - 1) ? "是" : "否");
    result.isFirstEducation = result.isFirstEducation || (index === 0 ? "是" : "否");
    result.czbankFirstEducation = result.__afCzbankFirstEducation || (index === 0 ? "是" : "否");
    result.czbankHighestEducation = result.__afCzbankHighestEducation || result.isHighestEducation || (index === Math.max(0, total - 1) ? "是" : "否");
    var levelText = String(result.level || "");
    var degreeText = String(result.degree || "");
    var majorTextForDegree = String(result.major || result.majorCategory || result.majorSubcategory || "");
    result.czbankLevel = /硕士研究生/.test(levelText) ? "硕士研究生" :
      /博士研究生/.test(levelText) ? "博士研究生" :
      /大学本科/.test(levelText) ? "大学本科" :
      /大学专科/.test(levelText) ? "大学专科" :
      /硕士/.test(levelText) ? "硕士研究生" :
      /博士/.test(levelText) ? "博士研究生" :
      /本科|学士/.test(levelText) ? "大学本科" :
      /专科|大专/.test(levelText) ? "大学专科" :
      result.level;
    if (/高中|中专|职高|技校/.test(levelText)) result.czbankDegree = "";
    else if (/管理学硕士学位/.test(degreeText)) result.czbankDegree = ["硕士学位", "管理学硕士学位"];
    else if (/工学硕士学位/.test(degreeText)) result.czbankDegree = ["硕士学位", "工学硕士学位"];
    else if (/示例资料学位/.test(degreeText)) result.czbankDegree = ["硕士学位", "示例资料学位"];
    else if (/法学硕士学位/.test(degreeText)) result.czbankDegree = ["硕士学位", "法学硕士学位"];
    else if (/博士学位/.test(degreeText)) result.czbankDegree = ["博士学位", degreeText];
    else if (/硕士/.test(degreeText) && /管理|工商|会计|财务|市场营销|电子商务/.test(majorTextForDegree)) result.czbankDegree = ["硕士学位", "管理学硕士学位"];
    else if (/硕士/.test(degreeText) && /计算机|软件|人工智能|通信|电子|自动化|工程/.test(majorTextForDegree)) result.czbankDegree = ["硕士学位", "工学硕士学位"];
    else if (/硕士/.test(degreeText)) result.czbankDegree = ["硕士学位"];
    else if (/学士/.test(degreeText) && /管理|工商|会计|财务|市场营销|电子商务/.test(majorTextForDegree)) result.czbankDegree = ["学士学位", "管理学学士学位"];
    else if (/学士/.test(degreeText) && /计算机|软件|人工智能|通信|电子|自动化|工程/.test(majorTextForDegree)) result.czbankDegree = ["学士学位", "工学学士学位"];
    else if (/学士|本科/.test(degreeText)) result.czbankDegree = ["学士学位"];
    else result.czbankDegree = result.degree;
    var majorText = String(result.major || result.majorCategory || "");
    var majorCategory = /管理学类/.test(majorText) ? "管理学类" :
      /工学类/.test(majorText) ? "工学类" :
      /经济学类/.test(majorText) ? "经济学类" :
      /法学类/.test(majorText) ? "法学类" :
      /管理|工商|会计|财务|市场营销|电子商务/.test(majorText) ? "管理学类" :
      /计算机|软件|人工智能|通信|电子|自动化|工程/.test(majorText) ? "工学类" :
      /经济|金融|财政|国贸|统计/.test(majorText) ? "经济学类" :
      /法学|法律/.test(majorText) ? "法学类" :
      (result.majorCategory ? (String(result.majorCategory).replace(/类$/, "") + "类") : "");
    // 浙商“专业类别”是可搜索的 Element Cascader。完整树很长，逐级点
    // 工学类/管理学类容易受滚动和父子级展开影响；现场验证可直接输入
    // 专业关键词并从候选中选择，成功率更高。
    var explicitCzbankMajorCategory = String(result.czbankMajorCategory || "").trim();
    result.czbankMajorCategory = explicitCzbankMajorCategory || (/软件工程/.test(majorText) ? "计算机软件" :
      /信息管理与信息系统|管理科学与工程/.test(majorText) ? "管理科学与工程" :
      /计算机|人工智能|通信|电子|自动化/.test(majorText) ? "计算机" :
      /会计|财务|工商|市场营销|电子商务/.test(majorText) ? "管理科学" :
      String(result.majorSubcategory || majorCategory || "").replace(/类$/, ""));
    result.czbankHighestDegree = result.czbankHighestEducation;
    result.ccbHighestDegree = result.isHighestEducation;
    return result;
  }

  function enrichCzbankWorkRow(row, index, resume) {
    var result = Object.assign({}, row || {});
    result.示例资料Mode = result.__afCategory === "示例资料Experience" ? "示例资料或社团活动" : "示例资料";
    result.country = countryCascaderPath(result.country || resume && resume.示例资料Info && resume.示例资料Info.country || "中国");
    var 示例资料CityText = result.city || result.location || result.示例资料Location || "";
    var companyText = String(result.company || "");
    if (!示例资料CityText && /杭州|蚂蚁/.test(companyText)) 示例资料CityText = "浙江省杭州市";
    else if (!示例资料CityText && /上海/.test(companyText)) 示例资料CityText = "上海市浦东新区";
    else if (!示例资料CityText && /北京|字节/.test(companyText)) 示例资料CityText = "北京市海淀区";
    result.czbankWorkCity = cityCascaderPath(示例资料CityText || resume && resume.示例资料Info && resume.示例资料Info.currentAddress || "");
    result.示例资料Location = result.czbankWorkCity || result.示例资料Location;
    result.achievements = [
      result.responsibilities || result.detailedContent,
      result.achievements || result.contribution,
      result.result,
    ].filter(Boolean).join("\n");
    return result;
  }

  function enrichCzbankFamilyRow(row, index, resume) {
    var result = Object.assign({}, row || {});
    result.czbankCompanyPosition = [result.company, result.position].filter(Boolean).join(" / ");
    result.gender = result.gender || (/父亲|丈夫|儿子|哥哥|弟弟/.test(String(result.relationship || "")) ? "男" :
      /母亲|妻子|女儿|姐姐|妹妹/.test(String(result.relationship || "")) ? "女" : "");
    var 示例资料CityText = result.city || result.currentCity || result.示例资料Location || result.address || "";
    var 示例资料CompanyText = String(result.company || "");
    if (!示例资料CityText && /杭州|浙江|城建集团|浙江省人民医院/.test(示例资料CompanyText)) 示例资料CityText = "浙江省杭州市";
    else if (!示例资料CityText && /上海/.test(示例资料CompanyText)) 示例资料CityText = "上海市浦东新区";
    else if (!示例资料CityText && /北京/.test(示例资料CompanyText)) 示例资料CityText = "北京市海淀区";
    result.country = countryCascaderPath(
      result.country || result.currentCountry || result.示例资料Location || resume && resume.示例资料Info && resume.示例资料Info.country || "中国"
    );
    result.示例资料Location = cityCascaderPath(
      示例资料CityText || resume && resume.示例资料Info && resume.示例资料Info.currentAddress || ""
    );
    result.czbankBirthMonth = yearMonthValue(result.birthDate);
    return result;
  }

  function enrichCzbankCompliance(data, resume) {
    var 示例资料 = resume && resume.示例资料Info || {};
    var intro = resume && resume.示例资料Introduction || {};
    return Object.assign({}, data || {}, {
      czbankProfessionalExpertise: 示例资料.professionalSkills || 示例资料.strengths || 示例资料.specialty || intro.示例资料Introduction,
      hasRelativeInCompany: (data && data.hasRelativeInCompany) || 示例资料.hasRelativeInCompany,
      hasSeriousDisease: (data && data.hasSeriousDisease) || 示例资料.hasSeriousDisease,
    });
  }

  function bankcommBasicBeforeSaveManualCheckpoint(scope) {
    var root = scope || document.querySelector("#示例资料") || document;
    var issues = [];
    function visible(el) {
      if (!el) return false;
      var r = el.getBoundingClientRect();
      var s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.display !== "none" && s.visibility !== "hidden";
    }
    function compact(value) { return String(value || "").replace(/\s+/g, "").replace(/[:：]/g, "").trim(); }
    function hasUploadedAsset(container) {
      if (!container) return false;
      try {
        var fileInputs = Array.from(container.querySelectorAll("input[type='file']"));
        if (fileInputs.some(function (input) { return input.files && input.files.length > 0; })) return true;
      } catch (eFiles) {}
      try {
        if (container.querySelector(
          ".ant-upload-list-item-done, .ant-upload-list-item-thumbnail img, .ant-upload-list-picture-card-container img, " +
          ".ant-upload-list-item-name, [class*='upload-list-item'], [class*='uploadList'] img, [class*='uploaded'] img"
        )) return true;
      } catch (eUploadList) {}
      try {
        var images = Array.from(container.querySelectorAll("img[src]"));
        if (images.some(function (img) {
          var src = String(img.getAttribute("src") || "");
          if (!src || /^data:image\/svg\+xml/i.test(src)) return false;
          var rect = img.getBoundingClientRect();
          return (rect.width >= 20 && rect.height >= 20) || Number(img.naturalWidth || 0) >= 20;
        })) return true;
      } catch (eImages) {}
      try {
        var nodes = Array.from(container.querySelectorAll("*"));
        if (nodes.some(function (node) {
          var style = getComputedStyle(node);
          return style && /url\(/i.test(String(style.backgroundImage || "")) && style.backgroundImage !== "none";
        })) return true;
      } catch (eBackground) {}
      try {
        var actionText = compact(container.textContent);
        if (/重新上传|更换图片|更换照片|预览|删除图片|删除照片/.test(actionText)) return true;
        if (/\.(?:jpg|jpeg|png|heic|pdf)(?:$|[^a-z])/i.test(String(container.textContent || ""))) return true;
      } catch (eText) {}
      return false;
    }
    var items = [];
    try { items = Array.from(root.querySelectorAll(".ant-form-item")).filter(visible); } catch (eItems) {}
    items.forEach(function (item) {
      var labelNode = item.querySelector(".ant-form-item-label > label, .ant-form-item-label");
      var label = compact(labelNode && labelNode.textContent);
      var context = compact(item.textContent).slice(0, 300);
      var requiredByLabel = !!(labelNode && /ant-form-item-required/.test(String(labelNode.className || "")));
      var photoRequired = /近期一寸免冠照|一寸免冠照/.test(label + context) && !/生活照.*选填/.test(label + context);
      var required = requiredByLabel || photoRequired;
      if (!required) return;
      var fileInputs = Array.from(item.querySelectorAll("input[type='file']"));
      var uploadLike = fileInputs.length > 0 || !!item.querySelector(".ant-upload, [class*='upload']");
      if (uploadLike) {
        var uploaded = hasUploadedAsset(item);
        // Bankcomm clears the native file input immediately after the server
        // accepts a photo. The rendered thumbnail may live in a sibling upload
        // shell instead of the ant-form-item it示例资料, so use a small local parent
        // fallback for the required one-inch portrait. Do not scan the whole page.
        if (!uploaded && photoRequired) {
          var localUploadShell = item.parentElement;
          for (var uploadDepth = 0; localUploadShell && uploadDepth < 3 && localUploadShell !== root; uploadDepth++) {
            if (hasUploadedAsset(localUploadShell)) { uploaded = true; break; }
            localUploadShell = localUploadShell.parentElement;
          }
        }
        if (!uploaded) issues.push({ label: label || "上传材料", reason: "required_file" });
        return;
      }
      var select = item.querySelector(".ant-select:not(.ant-select-disabled)");
      if (select) {
        var selected = compact((select.querySelector(".ant-select-selection-item, .ant-select-selection-selected-value") || {}).textContent);
        if (!selected || /^请选择/.test(selected)) issues.push({ label: label || "下拉字段", reason: "required_empty" });
        return;
      }
      var pickerInput = item.querySelector(".ant-picker input");
      if (pickerInput) {
        if (!String(pickerInput.value || "").trim()) issues.push({ label: label || "日期", reason: "required_empty" });
        return;
      }
      var checked = item.querySelector("input[type='radio']:checked, input[type='checkbox']:checked");
      if (item.querySelector("input[type='radio'], input[type='checkbox']") && !checked) {
        issues.push({ label: label || "选项", reason: "required_empty" });
        return;
      }
      var input = item.querySelector("textarea, input:not([type='hidden']):not([type='file']):not([type='radio']):not([type='checkbox'])");
      if (input && !String(input.value || "").trim()) issues.push({ label: label || "输入字段", reason: "required_empty" });
    });
    // Visible Ant validation messages are authoritative even for custom controls
    // that do not expose a conventional required attribute.
    try {
      Array.from(root.querySelectorAll(".ant-form-item-explain-error, .ant-form-item-has-error .ant-form-item-explain, .ant-form-item-has-error .ant-form-item-extra"))
        .filter(visible).forEach(function (node) {
          var msg = String(node.textContent || "").trim();
          if (!msg) return;
          var item = node.closest(".ant-form-item");
          var labelNode = item && item.querySelector(".ant-form-item-label > label, .ant-form-item-label");
          var label = compact(labelNode && labelNode.textContent) || msg.slice(0, 40);
          if (!issues.some(function (issue) { return compact(issue.label) === compact(label); })) {
            issues.push({ label: label, reason: "validation_message", message: msg.slice(0, 120) });
          }
        });
    } catch (eValidation) {}
    if (!issues.length) return null;
    var photoIssue = issues.some(function (issue) { return /免冠照|照片/.test(issue.label + " " + (issue.message || "")); });
    return {
      reason: photoIssue
        ? "示例资料仍需手动上传近期一寸免冠照，并补全页面尚未满足的必填项"
        : "示例资料仍有页面必填项需要人工补充或修正",
      issues: issues.slice(0, 20)
    };
  }

  function bankcommStep(moduleId, name, category, options) {
    options = options || {};
    return Object.assign({
      name: name,
      category: category,
      triggerSelector: moduleId,
      readySelector: ".resumeForm form",
      scopeSelector: moduleId,
      cardAsScope: true,
      fillMode: "full",
      waitAfterClickMs: 250,
      timeoutMs: 5000,
      skipClickWhenReady: true,
      skipWhenUnavailable: true,
      saveText: ["保存", "保 存"],
      waitAfterSaveMs: 500,
      waitForCloseSelector: ".resumeForm form",
      saveTimeoutMs: 7000,
      diagnosticCloseSelector: "button.ant-btn:not(.ant-btn-primary)",
      stopOnSaveError: true,
      // 交行所有“添加第 N 条”按钮均由 React 事件驱动。content script
      // 的普通合成 click 偶尔不会触发，表现为第一条能保存、第二条点了却
      // 没有表单，随后整个工作流停止。统一走已验证的 MAIN world 桥接；
      // 该默认值只存在于 bankcommStep，不影响任何其他站点。
      示例资料AddUseAntMainBridge: true,
    }, options);
  }

  function normalizeBankcommLevel(value) {
    var text = String(value || "").trim();
    if (/双学位/.test(text)) return "双学位";
    if (/博士/.test(text)) return "博士研究生";
    if (/硕士|研究生/.test(text)) return "硕士研究生";
    if (/本科|学士/.test(text)) return "本科";
    if (/大专|专科/.test(text)) return "大专";
    if (/高中/.test(text)) return "高中";
    if (/中专|职高|技校/.test(text)) return "中专";
    if (/^(无|其他)$/.test(text)) return "无";
    return text;
  }

  function normalizeBankcommDegree(value, level) {
    var text = String(value || "").trim();
    var levelText = String(level || "").trim();
    if (/高中|中专|职高|技校/.test(levelText)) return "";
    if (/博士/.test(text)) return "博士";
    if (/硕士/.test(text)) return "硕士";
    if (/学士|本科/.test(text)) return "学士";
    return text;
  }

  function normalizeBankcommLooseChinaLocationText(value) {
    var text = String(value || "").replace(/^中国/, "").replace(/\s+/g, "").trim();
    if (!text) return "";
    var municipalityAliases = { "北京": "北京市", "上海": "上海市", "天津": "天津市", "重庆": "重庆市" };
    if (municipalityAliases[text]) return municipalityAliases[text];
    Object.keys(municipalityAliases).some(function (alias) {
      if (text.indexOf(alias) === 0 && text.indexOf(municipalityAliases[alias]) !== 0) {
        text = municipalityAliases[alias] + text.slice(alias.length);
        return true;
      }
      return false;
    });
    var provinceAliases = {
      "河北": "河北省", "山西": "山西省", "辽宁": "辽宁省", "吉林": "吉林省", "黑龙江": "黑龙江省",
      "江苏": "江苏省", "浙江": "浙江省", "安徽": "安徽省", "福建": "福建省", "江西": "江西省",
      "山东": "山东省", "河南": "河南省", "湖北": "湖北省", "湖南": "湖南省", "广东": "广东省",
      "海南": "海南省", "四川": "四川省", "贵州": "贵州省", "云南": "云南省", "陕西": "陕西省",
      "甘肃": "甘肃省", "青海": "青海省", "台湾": "台湾省",
      "内蒙古": "内蒙古自治区", "广西": "广西壮族自治区", "西藏": "西藏自治区",
      "宁夏": "宁夏回族自治区", "新疆": "新疆维吾尔自治区",
      "香港": "香港特别行政区", "澳门": "澳门特别行政区"
    };
    Object.keys(provinceAliases).some(function (alias) {
      if (text.indexOf(alias) === 0 && text.indexOf(provinceAliases[alias]) !== 0) {
        text = provinceAliases[alias] + text.slice(alias.length);
        return true;
      }
      return false;
    });
    var provinceMatch = text.match(/^(.*?(?:省|自治区|特别行政区))(.*)$/);
    if (provinceMatch) {
      var rest = provinceMatch[2] || "";
      // Canonical profiles often store compact city text such as “示例资料”.
      // Expanding the omitted administrative suffix does not invent a location;
      // it only converts the same explicit city name to the option wording used
      // by cascaders.
      if (rest && !/(?:市|地区|自治州|盟|州|区|县)/.test(rest) && /^[\u4e00-\u9fff]{2,8}$/.test(rest)) {
        text = provinceMatch[1] + rest + "市";
      }
    }
    return text;
  }

  function bankcommNativePlacePath(value) {
    // 网页简历与户口所在地统一保存省/市/区县三级。这里只适配交行籍贯
    // 控件自身的层级：普通省份取省/市，直辖市取直辖市/区县。
    var storedPath = splitStoredAddressPath(value);
    if (storedPath) {
      if (/^(北京市|上海市|天津市|重庆市)$/.test(storedPath[0])) {
        return [storedPath[0], storedPath[2] || storedPath[1]].filter(Boolean);
      }
      return storedPath.slice(0, 2);
    }
    var text = normalizeBankcommLooseChinaLocationText(value);
    if (!text) return [];
    var municipality = text.match(/^(北京市|上海市|天津市|重庆市)/);
    if (municipality) {
      var municipalityRest = text.slice(municipality[1].length);
      var municipalityDistrict = municipalityRest.match(/^(.+?(?:区|县|市))/);
      return [municipality[1], municipalityDistrict ? municipalityDistrict[1] : "市辖区"];
    }
    var provinceMatch = text.match(/^(.*?(?:省|自治区|特别行政区))/);
    var province = provinceMatch && provinceMatch[1] || "";
    var rest = province ? text.slice(province.length) : text;
    var cityMatch = rest.match(/^(.+?(?:市|地区|自治州|盟|州))/);
    var city = cityMatch && cityMatch[1] || "";
    // 交行“籍贯”实际只有省/市两级。即使网页简历保存了西湖区等区县，
    // 这里也必须截断，否则自动化会等待不存在的第三级并判定整项失败。
    return [province, city].filter(Boolean);
  }

  function bankcommResidencePath(value) {
    var storedPath = splitStoredAddressPath(value);
    if (storedPath) return storedPath.slice(0, 3);
    var text = normalizeBankcommLooseChinaLocationText(value);
    if (!text) return [];
    var municipality = text.match(/^(北京市|上海市|天津市|重庆市)/);
    if (municipality) {
      var municipalityRest = text.slice(municipality[1].length);
      var municipalityDistrict = municipalityRest.match(/^(.+?(?:区|县|市))/);
      if (!municipalityDistrict) return [municipality[1]];
      return [
        municipality[1],
        /县$/.test(municipalityDistrict[1]) ? "县" : "市辖区",
        municipalityDistrict[1],
      ];
    }
    var provinceMatch = text.match(/^(.*?(?:省|自治区|特别行政区))/);
    var province = provinceMatch && provinceMatch[1] || "";
    var rest = province ? text.slice(province.length) : text;
    var cityMatch = rest.match(/^(.+?(?:市|地区|自治州|盟|州))/);
    var city = cityMatch && cityMatch[1] || "";
    var districtRest = city ? rest.slice(city.length) : "";
    var districtMatch = districtRest.match(/^(.+?(?:区|县|市))/);
    var district = districtMatch && districtMatch[1] || "";
    return [province, city, district].filter(Boolean);
  }

  function splitStoredAddressPath(value) {
    var path = Array.isArray(value) ? value.filter(Boolean) : String(value || "").split(/\s*\/\s*/).filter(Boolean);
    return path.length > 1 ? path : null;
  }

  function bankcommMajorPath(value, storedPath, subcategory) {
    var savedPath = Array.isArray(storedPath)
      ? storedPath.filter(Boolean)
      : String(storedPath || "").split(/\s+\/\s+/).filter(Boolean);
    if (savedPath.length === 2) return savedPath;
    var text = String(value || "").trim();
    var category = String(subcategory || "").trim();
    if (category && text) return [category, text];
    if (/软件工程/.test(text)) return ["计算机类", "软件工程"];
    if (/计算机科学与技术/.test(text)) return ["计算机类", "计算机科学与技术"];
    if (/计算机/.test(text)) return ["计算机类", "计算机科学与技术"];
    if (/信息管理与信息系统/.test(text)) return ["管理科学与工程类", "信息管理与信息系统"];
    if (/管理科学与工程/.test(text)) return ["管理科学与工程类", "管理科学"];
    // 交行专业名称是两级级联。财政学属于“财政学类 → 财政学”，
    // 不能只把叶子“财政学”当作一级路径交给 Cascader。
    if (/财政学|财政/.test(text)) return ["财政学类", "财政学"];
    if (/金融/.test(text)) return ["金融学类", "金融学"];
    if (/会计/.test(text)) return ["工商管理类", "会计学"];
    if (/工商管理/.test(text)) return ["工商管理类", "工商管理"];
    if (/市场营销/.test(text)) return ["工商管理类", "市场营销"];
    if (/电子商务/.test(text)) return ["电子商务类", "电子商务"];
    return text ? [text] : [];
  }

  function bankcommResearchPath(row) {
    var storedPath = String(row && row.researchDirectionPath || "").split(/\s+\/\s+/).filter(Boolean);
    if (storedPath.length === 3) return storedPath;

    // 研究方向只能在交行自己的三级字典里做“确定映射”。旧实现会在
    // “示例资料”等搜索不到的文本上，根据专业/财经关键词
    // 猜成“金融类 → 研究类金融 → 行业研究”。这会把真实资料改写成另一个
    // 研究方向。现在未知值返回空路径，由页面官方“若未找到”入口承接。
    var text = String(row && row.researchDirection || "").trim();
    if (!text) return [];
    var leafPathMap = {
      "通用软件研发": ["应用技术类", "信息技术", "通用软件研发"],
      "大数据技术研发": ["应用技术类", "信息技术", "大数据技术研发"],
      "云计算技术": ["应用技术类", "信息技术", "云计算技术"],
      "区块链技术研发": ["应用技术类", "信息技术", "区块链技术研发"],
      "人工智能应用金融": ["金融类", "金融科技类", "人工智能应用金融"],
      "大数据挖掘应用金融": ["金融类", "金融科技类", "大数据挖掘应用金融"],
      "金融信息基础设施开发与运营": ["金融类", "金融科技类", "金融信息基础设施开发与运营"],
      "行业研究": ["金融类", "研究类金融", "行业研究"]
    };
    if (leafPathMap[text]) return leafPathMap[text];
    var branchMap = {
      "监管类金融": "金融类", "管理类金融": "金融类", "研究类金融": "金融类", "业务类金融": "金融类",
      "专业服务类金融": "金融类", "金融科技类": "金融类",
      "数学": "基础研究类", "物理学": "基础研究类", "化学": "基础研究类", "空间科学": "基础研究类",
      "材料科学": "基础研究类", "生命科学": "基础研究类", "能源科学": "基础研究类", "环境科学": "基础研究类", "交叉科学": "基础研究类",
      "集成电路": "应用技术类", "生物医药": "应用技术类", "人工智能": "应用技术类", "信息技术": "应用技术类", "先进制造与应用": "应用技术类",
      "实验操作与分析": "实验技术类", "实验与仪器应用": "实验技术类",
      "技术转移管理": "成果转化类", "技术转移应用": "成果转化类", "技术推广和专业领域服务": "成果转化类",
      "科技资源条件与基础设施": "科技支撑类", "科技发展研究": "科技支撑类", "科技管理": "科技支撑类", "科技服务": "科技支撑类"
    };
    if (branchMap[text]) {
      var groupDefaultLeaf = {
        "监管类金融": "金融机构监管", "管理类金融": "金融高层次管理", "研究类金融": "行业研究",
        "业务类金融": "金融产品研发", "专业服务类金融": "风险控制与管理", "金融科技类": "金融信息基础设施开发与运营",
        "数学": "统计学研究", "物理学": "数学物理学研究", "化学": "分析化学研究", "空间科学": "空间环境建模与仿真研究",
        "材料科学": "材料化学研究", "生命科学": "分子生物学研究", "能源科学": "智慧能源研究与转化",
        "环境科学": "环境材料研究", "交叉科学": "计算摄像学研究",
        "集成电路": "芯片架构", "生物医药": "生物分析研究", "人工智能": "自主学习算法研究",
        "信息技术": /信息管理|数据/.test(String(row && row.major || "")) ? "大数据技术研发" : "通用软件研发",
        "先进制造与应用": "纳米与微纳制造研发",
        "实验操作与分析": "硬件测试技术", "实验与仪器应用": "高端科学仪器研发",
        "技术转移管理": "专业领域技术转移", "技术转移应用": "科技成果评估",
        "技术推广和专业领域服务": "知识产权法务",
        "科技资源条件与基础设施": "科技资源数据管理", "科技发展研究": "科技规划战略研究",
        "科技管理": "科技项目管理", "科技服务": "科技咨询"
      };
      return [branchMap[text], text, groupDefaultLeaf[text]];
    }
    return [];
  }

  function normalizeBankcommRank(value) {
    var text = String(value || "").trim();
    var match = text.match(/(\d+(?:\.\d+)?)\s*%/);
    if (!match) return /前10|前20|前30|前50|其他/.test(text) ? text : "其他";
    var percent = Number(match[1]);
    if (percent <= 10) return "前10%";
    if (percent <= 20) return "前20%";
    if (percent <= 30) return "前30%";
    if (percent <= 50) return "前50%";
    return "其他";
  }

  function bankcommSchoolPath(row) {
    var school = String(row && row.school || "").trim();
    if (!school) return [];
    if (isPreHigherEducation(row)) return school;
    var city = String(row && (row.city || row.schoolCity || row.location) || "");
    var overseas = isAffirmative(row && row.isOverseas) || /国外|境外|海外/.test(String(row && row.schoolType || ""));
    if (overseas) return ["国外", school];
    if (/浙江大学/.test(school)) return ["国内", "浙江", "浙江大学"];
    if (/上海交通大学/.test(school)) return ["国内", "上海", "上海交通大学"];
    if (/上海/.test(city)) return ["国内", "上海", school];
    if (/杭州|浙江/.test(city)) return ["国内", "浙江", school];
    if (/合肥|安徽/.test(city)) return ["国内", "安徽", school];
    if (/北京/.test(city)) return ["国内", "北京", school];
    return ["国内", school];
  }

  function enrichBankcommEducationRow(row) {
    var result = Object.assign({}, row || {});
    result.level = inferBankcommEducationLevel(result);
    result.bankcommLevel = result.level;
    result.bankcommDegree = normalizeBankcommDegree(result.degree, result.bankcommLevel);
    result.bankcommStudyType = result.示例资料Type || "全日制";
    result.bankcommIsJob = result.isWorkStudy || result.isOnJobEducation || result.示例资料Study || "否";
    result.bankcommSchool = bankcommSchoolPath(result);
    result.bankcommMajor = bankcommMajorPath(result.major, result.majorPath, result.majorSubcategory);
    result.bankcommResearch = bankcommResearchPath(result);
    // 交行提供官方“若未找到，请填写研究方向”入口。只有无法确定映射时
    // 才使用它；优先保留简历里明确写出的研究方向文本。若本科记录本身
    // 没有研究方向，则按当前资料要求填写“无”，而不是猜一个相近分类。
    // 这样本科会填“无”，硕士则会保留“示例资料”。
    result.bankcommResearchCustom = result.bankcommResearch.length
      ? ""
      : (String(result.researchDirection || "").trim() || "无");
    result.bankcommRank = normalizeBankcommRank(result.classRank || result.rank || "前30%");
    var gpaParts = String(result.gpa || "").split("/");
    result.bankcommGpa = gpaParts[0] || result.gpaScore || "";
    result.bankcommGpaTotal = gpaParts[1] || result.gpaTotal || result.gpaBase || "4.0";
    return result;
  }

  function bankcommIsHigherEducationRow(row) {
    return !isPreHigherEducation(row);
  }

  function bankcommIsPreHigherEducationRow(row) {
    return isPreHigherEducation(row);
  }

  function enrichBankcommWorkRow(row) {
    var result = Object.assign({}, row || {});
    var explicitType = String(result.示例资料Type || "").trim();
    result.bankcommWorkType = /实习/.test(explicitType) || result.__afCategory === "示例资料Experience"
      ? "实习生"
      : "正式员工";

    // 交行“工作、实习情况”要求精确到日。通用简历同时保留 startTime/endTime
    // （月份）与 startDate/endDate（日）；这里必须优先采用精确日期，不能把
    // 示例资料 这样的月份值直接交给 bankcommDate，否则日期控件会拒绝。
    if (String(result.startDate || "").trim()) result.startTime = String(result.startDate).trim();
    if (String(result.endDate || "").trim() && !/至今|目前|现在/.test(String(result.endTime || ""))) {
      result.endTime = String(result.endDate).trim();
    }

    var start = String(result.startTime || "").trim();
    var end = String(result.endTime || "").trim();
    // 交通银行会立即校验结束日期必须晚于起始日期。若简历源数据误把两者
    // 写反，在进入日期控件前纠正，避免生成截图中的倒置日期。
    if (start && end && !/至今|目前|现在/.test(end) && end < start) {
      result.startTime = end;
      result.endTime = start;
    }
    return result;
  }

  function enrichBankcommLanguageRow(row) {
    var result = Object.assign({}, row || {});
    result.bankcommLanguage = result.name || result.示例资料 || "英语";
    result.bankcommLanguageCert = result.certificateName || result.certificate || result.level || "";
    result.bankcommLanguageScore = result.score || "";
    return result;
  }

  function normalizeBankcommAwardClass(row) {
    var explicit = String(row && (row.awardClass || row.awardType) || "");
    if (/奖学金/.test(explicit)) return "奖学金";
    if (/荣誉/.test(explicit)) return "荣誉称号";
    if (/竞赛|比赛/.test(explicit)) return "竞赛获奖";
    var text = String(row && (row.awardCategory || row.category || row.awardName || row.name) || "");
    if (/奖学金/.test(text)) return "奖学金";
    if (/荣誉|三好学生|优秀学生|优秀毕业生|优秀学生干部/.test(text)) return "荣誉称号";
    return "竞赛获奖";
  }

  function bankcommAwardPhase(row, resume) {
    var explicit = String(row && (row.phase || row.levelStage) || "");
    if (/博士/.test(explicit)) return "博士研究生阶段";
    if (/硕士|研究生/.test(explicit)) return "硕士研究生阶段";
    if (/本科|大学/.test(explicit)) return "大学本科阶段";
    var awardDate = String(row && (row.awardTime || row.time || row.date) || "");
    var 示例资料 = resume && Array.isArray(resume.示例资料) ? resume.示例资料 : [];
    var matched = 示例资料.filter(function (item) {
      var start = String(item && item.startTime || "");
      var end = String(item && item.endTime || "");
      return awardDate && start && awardDate >= start && (!end || awardDate <= end);
    }).sort(compareBankcommEducationRows).pop();
    // 获奖日期若落在本科毕业与硕士入学之间，归到最近结束的上一阶段。
    if (!matched && awardDate) {
      matched = 示例资料.filter(function (item) {
        return String(item && item.endTime || "") <= awardDate;
      }).sort(function (left, right) {
        return String(right && right.endTime || "").localeCompare(String(left && left.endTime || ""));
      })[0];
    }
    var level = inferBankcommEducationLevel(matched || {});
    if (/博士/.test(level)) return "博士研究生阶段";
    if (/硕士/.test(level)) return "硕士研究生阶段";
    return "大学本科阶段";
  }

  function bankcommAwardLevel(row, awardClass) {
    var level = String(row && (row.awardLevel || row.level) || "");
    var grade = String(row && row.awardGrade || "");
    // 历史资料里“示例资料”可能整体存放在 awardLevel，而 awardGrade 为空。
    // 级别与等次必须联合解析，否则会被误判成“其他（如企业赞助奖学金等）”。
    var gradeSource = [level, grade].filter(Boolean).join(" ");
    var gradeText = /一等|金奖|冠军/.test(gradeSource) ? "一等奖" :
      /二等|银奖|亚军/.test(gradeSource) ? "二等奖" :
      /三等|铜奖|季军/.test(gradeSource) ? "三等奖" : "";
    if (awardClass === "奖学金") {
      if (/国家/.test(level)) return "国家级";
      if (/省|市|区/.test(level)) return "省市区级";
      if (/校|院/.test(level) && gradeText) return "校级-" + gradeText;
      return "其他（如企业赞助奖学金等）";
    }
    if (awardClass === "荣誉称号") {
      if (/国家|国际/.test(level)) return "国家级";
      if (/省|市|区/.test(level)) return "省（自治区、直辖市）级";
      return "学校级";
    }
    var prefix = /国家|全国|国际/.test(level) ? "全国性-" : "地方赛区-";
    return prefix + (gradeText || "一等奖");
  }

  function bankcommAwardName(row, awardClass) {
    var text = String(row && (row.awardName || row.name || row.title) || "");
    if (awardClass === "奖学金") return "";
    if (awardClass === "荣誉称号") {
      if (/优秀毕业生/.test(text)) return "优秀毕业生";
      if (/优秀学生干部/.test(text)) return "优秀学生干部";
      if (/三好学生/.test(text)) return "三好学生";
      if (/优秀学生/.test(text)) return "优秀学生";
      return "其他";
    }
    if (/互联网\+/.test(text)) return "全国“互联网+”大学生创新创业大赛";
    if (/数学建模/.test(text)) return "全国大学生（研究生）数学建模竞赛";
    if (/研究生电子设计/.test(text)) return "中国研究生电子设计竞赛";
    if (/大学生电子设计/.test(text)) return "全国大学生电子设计竞赛";
    if (/研究生创芯/.test(text)) return "中国研究生创芯大赛";
    if (/大学生英语竞赛/.test(text)) return "全国大学生英语竞赛";
    if (/挑战杯.*创业|创业计划.*挑战杯/.test(text)) return "“挑战杯”中国大学生创业计划竞赛";
    if (/挑战杯/.test(text)) return "“挑战杯”全国大学生课外学术科技作品竞赛";
    if (/创青春.*创业/.test(text)) return "“创青春”全国大学生创业大赛";
    if (/创青春/.test(text)) return "“创青春”全国大学生课外学术科技作品竞赛";
    return "";
  }

  function bankcommAwardSupported(row) {
    var awardClass = normalizeBankcommAwardClass(row);
    return awardClass === "奖学金" || awardClass === "荣誉称号" || !!bankcommAwardName(row, awardClass);
  }

  function bankcommCampusAwardSupported(row) {
    // 交通银行栏目明确是“在校期间获奖情况”，只接收简历中标记为
    // “校内”的获奖。校外竞赛即使名称能映射到交行字典，也不能在这里
    // 生成新增任务；它们仍完整保留在通用简历中供其他站点使用。
    var scope = String(row && (row.awardScope || row.scope || row.awardRange) || "").trim();
    if (/校外/.test(scope)) return false;
    if (/校内/.test(scope)) return bankcommAwardSupported(row);

    // 兼容尚未打开新版网页简历迁移的历史数据。只有级别明确为校/院级
    // 时才认定为校内；模糊记录不猜，防止把国家级、省级竞赛冒填进交行。
    var level = String(row && (row.awardLevel || row.level) || "");
    return /校级|院级/.test(level) && bankcommAwardSupported(row);
  }

  function bankcommAwardHasName(row) {
    return !!String(row && row.bankcommAwardName || "").trim();
  }

  function enrichBankcommAwardRow(row, index, resume) {
    var result = Object.assign({}, row || {});
    result.bankcommAwardDate = result.awardTime || result.time || result.date;
    result.bankcommAwardPhase = bankcommAwardPhase(result, resume);
    result.bankcommAwardClass = normalizeBankcommAwardClass(result);
    result.bankcommAwardLevel = bankcommAwardLevel(result, result.bankcommAwardClass);
    result.bankcommAwardName = bankcommAwardName(result, result.bankcommAwardClass);
    return result;
  }

  function enrichBankcommComputerCertificate(row) {
    var result = Object.assign({}, row || {});
    result.bankcommComputerCert = result.certificateName || result.name || result.certificate || "";
    result.bankcommComputerLevel = result.level || result.certificateLevel || "合格";
    return result;
  }

  function bankcommAnnualSalaryWan(value, monthlyFallback) {
    var text = String(value == null ? "" : value).trim();
    if (!text) return "";
    var numbers = text.match(/\d+(?:\.\d+)?/g);
    if (!numbers || !numbers.length) return "";
    var amount = Number(numbers[0]);
    if (!Number.isFinite(amount)) return "";
    if (/万\s*\/\s*年|万元?\s*\/\s*年|年薪/.test(text)) return String(amount);
    if (/K/i.test(text) || monthlyFallback) return String(Math.round(amount * 12 / 10 * 10) / 10);
    if (/元\s*\/\s*月|月薪/.test(text)) return String(Math.round(amount * 12 / 10000 * 10) / 10);
    return String(amount);
  }

  function enrichBankcommBasicInfo(data, resume) {
    var 示例资料 = resume && resume.示例资料Info || {};
    var 示例资料 = resume && resume.jobIntention || {};
    var result = Object.assign({}, 示例资料, data || {});
    // 交行“生源类型”使用应届生/社会经验人士语义。
    // 优先尊重 profile 明确值；当前用户已确认缺省应为“应届生”。
    var 示例资料Type = String(result.示例资料Type || result.sourceType || "").trim();
    if (!示例资料Type) {
      var currentStatus = String(result.currentStatus || result.currentIdentity || "").trim();
      if (/应届|在校/.test(currentStatus) || result.isFreshGraduate === "是") 示例资料Type = "应届生";
      else if (/社会|在职|离职|待业/.test(currentStatus) || result.isFreshGraduate === "否") 示例资料Type = "社会经验人士";
    }
    if (/应届|在校/.test(示例资料Type)) result.示例资料Type = "应届生";
    else if (/社会|在职|离职|待业/.test(示例资料Type)) result.示例资料Type = "社会经验人士";
    else result.示例资料Type = "应届生";
    var salarySource = result.currentAnnualSalary != null && String(result.currentAnnualSalary).trim() !== ""
      ? result.currentAnnualSalary
      : (result.annualSalary != null && String(result.annualSalary).trim() !== ""
        ? result.annualSalary
        : (result.currentSalary != null && String(result.currentSalary).trim() !== ""
          ? result.currentSalary
          : 示例资料.currentSalary));
    result.bankcommSalary = bankcommAnnualSalaryWan(
      salarySource,
      !result.currentAnnualSalary && !result.annualSalary
    );
    if (!result.bankcommSalary && result.示例资料Type === "应届生") result.bankcommSalary = "0";
    result.bankcommSocialApplicant = result.socialApplicant || result.isSocialApplicant || "否";
    result.bankcommNativePlace = bankcommNativePlacePath(
      result.nativePlacePath || result.nativePlace || result.birthOriginPath || result.birthOrigin
    );
    result.bankcommHukouLocation = splitStoredAddressPath(result.hukouLocationPath) || bankcommResidencePath(result.hukouLocation || result.birthOrigin || result.nativePlace);
    result.bankcommCurrentAddress = splitStoredAddressPath(result.currentAddressPath) || bankcommResidencePath(result.currentAddressDetail || result.currentAddress || result.currentCity || result.city);
    result.bankcommBocmCloseRelative = result.bocmCloseRelative || result.hasBocmCloseRelative || "否";
    result.bankcommBocmOtherRelative = result.bocmOtherRelative || result.hasBocmOtherRelative || "否";
    // 交银集团亲属关系页有两处独立“本人承诺”复选框。用户已明确
    // 要求在该招聘流程中自动确认；仅限 #bocm 当前模块，不泛化到其它
    // 站点或其它法律/隐私声明。
    result.bankcommBocmCommitment = true;
    result.bankcommForeignResidence = result.foreignResidence || result.hasForeignResidence || "否";
    result.bankcommPunished = result.punished || result.hasPunishment || "否";
    result.bankcommAgreeStandard = result.agreeBankcommStandard || result.agreeStandard || "是";
    result.bankcommInfoSource = result.infoSource || result.recruitmentSource || 示例资料.infoSource || 示例资料.recruitmentSource || "招聘官网";
    result.bankcommExpectedSalary = bankcommAnnualSalaryWan(
      result.expectedAnnualSalary || result.expectedSalary || 示例资料.expectedAnnualSalary || 示例资料.expectedSalary || 示例资料.salary,
      !result.expectedAnnualSalary && !示例资料.expectedAnnualSalary
    ) || result.bankcommSalary;
    return result;
  }

  function hsbankInlineStep(sectionSelector, name, category, options) {
    options = options || {};
    return Object.assign({
      name: name,
      category: category,
      triggerSelector: sectionSelector + " button.cancel",
      readySelector: sectionSelector + " button.save",
      scopeSelector: sectionSelector,
      fillMode: "full",
      waitAfterClickMs: 260,
      timeoutMs: 6000,
      skipClickWhenReady: true,
      skipWhenUnavailable: true,
      saveOnPartialFill: true,
      keepEditorOnError: true,
      saveSelector: sectionSelector + " button.save",
      saveText: ["保存"],
      waitAfterSaveMs: 350,
      waitForCloseSelector: sectionSelector + " button.save",
      saveTimeoutMs: 6000,
      diagnosticCloseSelector: sectionSelector + " button.cancel",
    }, options);
  }

  function hsbankAddressParts(pathValue, textValue) {
    var parts = splitStoredAddressPath(pathValue) || bankcommResidencePath(textValue) || [];
    parts = parts.slice(0, 3);
    if (/^(北京市|上海市|天津市|重庆市)$/.test(String(parts[0] || "")) && /市辖区|县/.test(String(parts[1] || ""))) {
      parts[1] = parts[0];
    }
    return { province: parts[0] || "", city: parts[1] || "", district: parts[2] || "" };
  }

  function hsbankAddressDetail(value, parts) {
    var detail = String(value || "").trim();
    if (!detail) return "";
    [parts.province, parts.city, parts.district, "市辖区", "县"].filter(Boolean).forEach(function (part) {
      detail = detail.replace(new RegExp("^" + String(part).replace(/[.*+?^${}()|[\]\\]/g, "\\$&")), "");
    });
    return detail.trim();
  }

  function normalizeHsbankPoliticalStatus(value) {
    var text = String(value || "").trim();
    if (/中共预备党员/.test(text)) return "中国共产党预备党员";
    if (/中共党员|中国共产党党员/.test(text)) return "中国共产党党员";
    if (/示例资料|青年团员/.test(text)) return "中国共产主义青年团团员";
    return text;
  }

  function enrichHsbankBasicInfo(data) {
    var result = Object.assign({}, data || {});
    var hukou = hsbankAddressParts(result.hukouLocationPath, result.hukouLocation || result.birthOrigin);
    var 示例资料 = hsbankAddressParts(result.示例资料LocationPath, result.示例资料Location || result.currentAddress);
    var nativePlace = hsbankAddressParts(result.nativePlacePath, result.nativePlace);
    result.hsbankPoliticalStatus = normalizeHsbankPoliticalStatus(result.politicalStatus);
    result.hsbankHukouProvince = hukou.province;
    result.hsbankHukouCity = hukou.city;
    result.hsbankHukouDistrict = hukou.district;
    result.hsbankFamilyProvince = 示例资料.province;
    result.hsbankFamilyCity = 示例资料.city;
    result.hsbankFamilyDistrict = 示例资料.district;
    result.hsbankFamilyDetail = result.示例资料AddressDetail || result.示例资料LocationDetail || result.currentAddressDetail ||
      hsbankAddressDetail(result.示例资料Location || result.currentAddress, 示例资料);
    result.hsbankNativeProvince = nativePlace.province;
    result.hsbankNativeCity = nativePlace.city;
    result.hsbankNativeDistrict = nativePlace.district;
    result.hsbankSpecialty = result.strengths || result.specialty || result.hobbies || "";
    return result;
  }

  function normalizeHsbankEducationLevel(value) {
    var text = String(value || "").trim();
    if (/博士/.test(text)) return "博士研究生";
    if (/硕士|研究生/.test(text)) return "硕士研究生";
    if (/本科|学士|大学/.test(text)) return "本科";
    if (/大专|专科/.test(text)) return "大专";
    if (/中专|职高|技校/.test(text)) return "中专";
    if (/高中/.test(text)) return "高中";
    return text;
  }

  function normalizeHsbankDegree(value, level) {
    var text = String(value || "").trim();
    if (/博士/.test(text)) return "博士学位";
    if (/硕士/.test(text)) return "硕士学位";
    if (/学士|本科/.test(text)) return "学士学位";
    if (/高中|中专|大专|专科/.test(String(level || "")) || /^无$/.test(text)) return "无";
    return text;
  }

  function normalizeHsbankMajorCategory(value, majorPath, major) {
    var valid = ["专业学位", "哲学", "经济学", "法学", "教育学", "文学", "历史学", "理学", "工学", "农学", "医学", "军事学", "管理学", "艺术学", "交叉学科"];
    var pathParts = String(majorPath || "").split(/\s*\/\s*/).filter(Boolean);
    var candidates = [value].concat(pathParts).filter(Boolean);
    for (var i = 0; i < candidates.length; i++) {
      var text = String(candidates[i] || "").trim();
      if (valid.indexOf(text) !== -1) return text;
      var withoutClass = text.replace(/类$/, "");
      if (valid.indexOf(withoutClass) !== -1) return withoutClass;
      var inferred = inferAbcMajorCategoryFromSubcategory(text);
      if (inferred === "艺术") inferred = "艺术学";
      if (inferred === "历史") inferred = "历史学";
      if (valid.indexOf(inferred) !== -1) return inferred;
    }
    var inferredFromMajor = inferAbcMajorCategoryFromSubcategory(major);
    if (inferredFromMajor === "艺术") inferredFromMajor = "艺术学";
    if (inferredFromMajor === "历史") inferredFromMajor = "历史学";
    return valid.indexOf(inferredFromMajor) !== -1 ? inferredFromMajor : "";
  }

  function normalizeHsbankMajorPrimary(row, level) {
    row = row || {};
    var isGraduate = /硕士|博士/.test(String(level || ""));
    if (!isGraduate) return row.major || "";
    var inferredPath = bankcommMajorPath(row.major, row.majorPath, row.majorSubcategory);
    var text = String(row.majorSubcategory || row.czbankMajorCategory || inferredPath[0] || row.major || "").trim();
    var aliases = {
      "管理科学与工程类": "管理科学与工程",
      "计算机类": "计算机科学与技术",
      "工商管理类": "工商管理学",
      "金融学类": "应用经济学",
      "电子信息类": "电子科学与技术",
    };
    return aliases[text] || text.replace(/类$/, "");
  }

  function enrichHsbankEducationRow(row, index) {
    var result = Object.assign({}, row || {});
    result.hsbankLevel = normalizeHsbankEducationLevel(result.level || result.示例资料Level);
    result.hsbankDegree = normalizeHsbankDegree(result.degree || result.degreeType, result.hsbankLevel);
    result.hsbankHighestEducation = index === 0 ? "是" : "否";
    result.hsbankHighestDegree = index === 0 && result.hsbankDegree !== "无" ? "是" : "否";
    var schoolPath = splitStoredAddressPath(result.schoolLocationPath) || bankcommResidencePath(result.schoolLocation || result.city) || [];
    result.hsbankSchoolProvince = result.schoolProvince || schoolPath[0] || "其他";
    result.hsbankMajorCategory = normalizeHsbankMajorCategory(result.majorCategory, result.majorPath, result.major);
    result.hsbankMajorPrimary = normalizeHsbankMajorPrimary(result, result.hsbankLevel);
    result.hsbankMajorSecondary = /硕士|博士/.test(result.hsbankLevel) && result.major !== result.hsbankMajorPrimary
      ? result.major || ""
      : "";
    result.hsbankEducationCategory = /非全日制|在职|函授|自考|成教/.test(String(result.示例资料Type || "")) ? "非全日制" : "全日制";
    result.hsbankEducationMethod = result.hsbankEducationCategory === "全日制" ? "正规全日制" : "其他";
    return result;
  }

  function enrichHsbankLanguageRow(row) {
    var result = Object.assign({}, row || {});
    result.hsbankLanguage = result.name || result.示例资料 || "";
    result.hsbankLanguageLevel = result.certificate || result.certificateName || result.level || result.proficiency || "";
    result.hsbankCertificateNo = result.certificateNo || result.number || "";
    return result;
  }

  function enrichHsbankCertificateRow(row) {
    var result = Object.assign({}, row || {});
    result.hsbankCertificateName = result.certificateName || result.certificateType || result.name || "";
    if (/PMP|项目管理专业人士资格认证|项目管理专业人员资格认证/i.test(result.hsbankCertificateName)) {
      result.hsbankCertificateName = "项目管理专业人员资格认证（PMP）";
    }
    result.hsbankCertificateTime = result.obtainedTime || result.issueDate || result.acquisitionDate || result.date || "";
    result.hsbankCertificateIssuer = result.issuer || result.organization || result.certificationBody || "";
    result.hsbankCertificateNo = result.certificateNo || result.number || "";
    return result;
  }

  function enrichHsbankAwardRow(row) {
    var result = Object.assign({}, row || {});
    result.hsbankAwardName = result.awardName || result.name || "";
    result.hsbankAwardContent = result.awardDescription || result.description || result.awardGrade || "";
    result.hsbankAwardIssuer = result.awardIssuer || result.grantor || result.issuer || "";
    return result;
  }

  function enrichHsbankFamilyRow(row) {
    var result = Object.assign({}, row || {});
    result.hsbankBankEmployee = isAffirmative(result.isBankEmployee) ? "是" : "否";
    result.hsbankCompanyPosition = [result.company, result.position].filter(Boolean).join(" / ") || "无";
    return result;
  }

  function enrichHsbankWorkRow(row) {
    var result = Object.assign({}, row || {});
    result.hsbankCompany = result.company || result.organization || "";
    result.hsbankReferencePerson = result.custom_referencePerson || result.referencePerson || result.proofPerson || "暂无";
    result.hsbankReferencePhone = result.custom_referencePersonPhone || result.referencePhone || result.proofPhone || "无";
    result.hsbankDescription = [
      result.responsibilities || result.detailedContent || result.description,
      result.achievements || result.contribution,
      result.result,
    ].filter(Boolean).join("\n");
    return result;
  }

  function enrichHsbankExtra(data, resume) {
    var source = data && typeof data === "object" ? data : {};
    var result = Object.assign({}, source);
    var 示例资料 = resume && resume.示例资料Info || {};
    var resumeIntro = resume && resume.示例资料Introduction;
    result.hsbankExtra = String(
      source.示例资料Introduction || source.description ||
      resumeIntro && (resumeIntro.示例资料Introduction || resumeIntro.description) ||
      typeof resumeIntro === "string" && resumeIntro ||
      示例资料.示例资料Introduction || ""
    ).slice(0, 150);
    return result;
  }

  function huaweiLocationParts(value) {
    var parts = Array.isArray(value)
      ? value.filter(Boolean)
      : String(value || "").split(/\s*\/\s*|\s*>\s*|\s+/).filter(Boolean);
    var text = parts.join("") || String(value || "").trim();
    var provinceMatch = text.match(/^(北京市|上海市|天津市|重庆市|[^省]+省|广西壮族自治区|内蒙古自治区|宁夏回族自治区|新疆维吾尔自治区|西藏自治区|香港特别行政区|澳门特别行政区)/);
    var province = parts[0] || provinceMatch && provinceMatch[1] || "";
    var rest = provinceMatch ? text.slice(provinceMatch[1].length) : text;
    var cityMatch = rest.match(/^(.+?(?:市|地区|自治州|盟|州))/);
    var city = parts[1] || cityMatch && cityMatch[1] || "";
    function clean(item) {
      return String(item || "").replace(/(省|市|自治区|特别行政区)$/g, "").trim();
    }
    var cleanProvince = clean(province);
    var cleanCity = clean(city);
    if (/^(北京|上海|天津|重庆)$/.test(cleanProvince) && !cleanCity) cleanCity = cleanProvince;
    return { province: cleanProvince, city: cleanCity };
  }

  function normalizeHuaweiIdType(value) {
    var text = String(value || "").trim();
    if (/身份证|居民身份证/.test(text)) return "中国居民身份证";
    return text;
  }

  function normalizeHuaweiEducationLevel(value) {
    var text = String(value || "").trim();
    if (/博士/.test(text)) return "博士研究生";
    if (/硕士|研究生/.test(text)) return "硕士研究生";
    if (/本科|学士|大学/.test(text)) return "本科";
    if (/大专|专科/.test(text)) return "大专";
    return text;
  }

  function isHuaweiEducationRow(row) {
    return /博士|硕士|研究生|本科|学士|大学|大专|专科/.test(String(row && row.level || ""));
  }

  function normalizeHuaweiRank(value, row) {
    var text = String(value || "").trim().toUpperCase();
    if (/TOP\s*5|前\s*5%/.test(text)) return "TOP5%";
    if (/TOP\s*10|前\s*10%/.test(text)) return "TOP10%";
    if (/TOP\s*20|前\s*20%/.test(text)) return "TOP20%";
    if (/TOP\s*25|前\s*25%/.test(text)) return "TOP25%";
    if (/TOP\s*50|前\s*50%/.test(text)) return "TOP50%";
    var rank = Number(String(value || "").match(/\d+/) && String(value || "").match(/\d+/)[0]);
    var size = Number(row && row.classSize);
    if (rank > 0 && size > 0) {
      var percent = rank / size * 100;
      if (percent <= 5) return "TOP5%";
      if (percent <= 10) return "TOP10%";
      if (percent <= 20) return "TOP20%";
      if (percent <= 25) return "TOP25%";
      if (percent <= 50) return "TOP50%";
    }
    return text ? "其他" : "";
  }

  function huaweiAchievementSummary(resume) {
    var lines = [];
    (resume && resume.示例资料 || []).slice(0, 4).forEach(function (row) {
      var text = [row.awardName, row.awardGrade || row.awardLevel, row.awardTime].filter(Boolean).join("，");
      if (text) lines.push(text);
    });
    (resume && resume.publications || []).slice(0, 2).forEach(function (row) {
      var text = [row.paperTitle, row.journal, row.publishTime || row.publishYear].filter(Boolean).join("，");
      if (text) lines.push(text);
    });
    (resume && resume.示例资料s || []).slice(0, 2).forEach(function (row) {
      var text = [row.示例资料Name, row.示例资料Number].filter(Boolean).join("，");
      if (text) lines.push(text);
    });
    return lines.join("\n").slice(0, 1800);
  }

  function enrichHuaweiBasic(data, resume) {
    var result = Object.assign({}, data || {});
    var 示例资料 = resume && resume.jobIntention || {};
    var 示例资料 = resume && Array.isArray(resume.示例资料) ? resume.示例资料.filter(isHuaweiEducationRow) : [];
    var currentEducation = 示例资料.slice().sort(compareEducationByStartTimeDesc)[0] || {};
    var schoolLocation = huaweiLocationParts(
      result.schoolCity || currentEducation.schoolLocationPath || currentEducation.schoolLocation || currentEducation.city
    );
    var nativeLocation = huaweiLocationParts(result.nativePlacePath || result.nativePlace);
    var countryText = String(result.country || "").trim();
    result.huaweiNationality = /中国|大陆|中华人民共和国/.test(countryText) || !countryText ? "中国大陆" : countryText;
    result.huaweiNativePlace = nativeLocation.province || String(result.nativePlace || "").replace(/[省市]$/g, "");
    result.huaweiIdType = normalizeHuaweiIdType(result.idType);
    result.huaweiPhoneArea = /中国|\+?86/.test(String(result.phoneAreaCode || result.countryCode || "")) || result.phone
      ? "中国(+86)" : "";
    result.huaweiSchoolCountry = isAffirmative(currentEducation.isOverseas)
      ? String(currentEducation.country || currentEducation.schoolCountry || "")
      : "中国";
    result.huaweiSchoolProvince = schoolLocation.province;
    result.huaweiSchoolCity = schoolLocation.city;
    result.huaweiRemoteInterview = result.remoteInterview === undefined ? "" : (isAffirmative(result.remoteInterview) ? "是" : "否");
    result.huaweiResearchDirection = currentEducation.researchDirection || result.researchDirection || "";
    result.huaweiAchievement = result.personalAchievement || result.achievements || huaweiAchievementSummary(resume);
    result.huaweiObeyAssignment = 示例资料.obeyAssignment === undefined && 示例资料.acceptAdjustment === undefined
      ? "" : (isAffirmative(示例资料.obeyAssignment) || isAffirmative(示例资料.acceptAdjustment) ? "是" : "否");
    var desired = 示例资料.expectedLocation || 示例资料.expectedLocationPath || 示例资料.city || "";
    var desiredParts = Array.isArray(desired) ? desired.filter(Boolean) : String(desired).split(/[、,，/\s]+/).filter(Boolean);
    result.huaweiFirstLocation = desiredParts[0] || "";
    result.huaweiSecondLocation = desiredParts[1] || desiredParts[0] || "";
    result.huaweiAcceptChange = 示例资料.cityFlexible === undefined
      ? "" : (isAffirmative(示例资料.cityFlexible) ? "是" : "否");
    result.huaweiAcceptableArea = isAffirmative(示例资料.cityFlexible) ? "中国国内各地" :
      (示例资料.cityFlexible === undefined ? "" : "中国国内某些城市");
    var 示例资料Info = resume && resume.示例资料Info || {};
    var relativeValue = 示例资料Info.hasRelativeInCompany;
    if (relativeValue === undefined) relativeValue = result.hasRelativeInCompany;
    result.huaweiHasRelative = isAffirmative(relativeValue) ? "是" : "否";
    return result;
  }

  function enrichHuaweiEducationRow(row, index, resume) {
    var result = Object.assign({}, row || {});
    var location = huaweiLocationParts(result.schoolLocationPath || result.schoolLocation || result.city);
    result.huaweiEducationLevel = normalizeHuaweiEducationLevel(result.level);
    result.huaweiSchoolCountry = isAffirmative(result.isOverseas)
      ? String(result.country || result.schoolCountry || "")
      : "中国";
    result.huaweiRank = normalizeHuaweiRank(result.classRank, result);
    result.huaweiGpa = result.gpa || (result.gpaScore && result.gpaTotal ? result.gpaScore + "/" + result.gpaTotal : result.gpaScore || "");
    result.huaweiMentor = result.mentorName || result.teacherName || "";
    result.huaweiKeyLab = result.isNationalKeyLaboratory === undefined ? "" : (isAffirmative(result.isNationalKeyLaboratory) ? "是" : "否");
    result.huaweiStudentCadre = (resume && Array.isArray(resume.campusLeadership) && resume.campusLeadership.length) || result.campusExperience
      ? "是" : "否";
    result.huaweiSchoolProvince = location.province;
    return result;
  }

  function enrichHuaweiLanguageRow(row) {
    var result = Object.assign({}, row || {});
    result.huaweiLanguage = result.name || result.示例资料 || "";
    var certificate = String(result.certificate || result.certificateName || result.level || "");
    if (/CET[- ]?6|六级/i.test(certificate)) result.huaweiCertificate = "六级";
    else if (/CET[- ]?4|四级/i.test(certificate)) result.huaweiCertificate = "四级";
    else if (/雅思|示例资料/i.test(certificate)) result.huaweiCertificate = "雅思";
    else if (/托福|TOEFL/i.test(certificate)) result.huaweiCertificate = "托福";
    else if (/托业|TOEIC/i.test(certificate)) result.huaweiCertificate = "托业";
    else result.huaweiCertificate = certificate || "无";
    return result;
  }

  function enrichHuaweiInternshipRow(row) {
    var result = Object.assign({}, row || {});
    result.huaweiWorkDescription = [result.detailedContent, result.contribution, result.result].filter(Boolean).join("\n");
    return result;
  }

  function enrichHuaweiProjectRow(row) {
    var result = Object.assign({}, row || {});
    result.huaweiProjectDescription = [result.details, result.contributions, result.result, result.techStack].filter(Boolean).join("\n");
    return result;
  }

  function isHuaweiMeetingRow(row) {
    return /会议|conference|symposium|论坛/i.test(String(row && (row.journal || row.venue || row.conference) || ""));
  }

  function enrichHuaweiPaperRow(row) {
    var result = Object.assign({}, row || {});
    result.huaweiPaperName = result.paperTitle || result.title || "";
    result.huaweiPaperTime = result.publishTime || (result.publishYear ? result.publishYear + "-01-01" : "");
    result.huaweiPaperDetails = [result.journal, result.publicationLevel, result.contribution, result.paperLink].filter(Boolean).join("；");
    return result;
  }

  function enrichHuaweiMeetingRow(row) {
    var result = Object.assign({}, row || {});
    result.huaweiMeetingName = result.journal || result.venue || result.conference || result.paperTitle || "";
    result.huaweiMeetingTime = result.publishTime || (result.publishYear ? result.publishYear + "-01-01" : "");
    result.huaweiMeetingDuty = [result.paperTitle, result.contribution, result.publicationLevel].filter(Boolean).join("；");
    return result;
  }

  function enrichHuaweiPatentRow(row) {
    var result = Object.assign({}, row || {});
    result.huaweiPatentNo = result.示例资料Number || result.number || "";
    result.huaweiPatentTime = result.authorizationDate || result.grantDate || result.applicationDate || "";
    result.huaweiPatentValue = result.description || result.示例资料Type || "";
    return result;
  }

  function enrichHuaweiAwardRow(row) {
    var result = Object.assign({}, row || {});
    var text = [result.awardCategory, result.awardClass, result.awardName].filter(Boolean).join(" ");
    result.huaweiAwardType = /奖学金/.test(text) ? "奖学金" : "竞赛奖项";
    var level = String(result.awardLevel || result.awardScope || "");
    if (/国际/.test(level)) result.huaweiAwardScope = "国际级";
    else if (/国家/.test(level)) result.huaweiAwardScope = "国家级";
    else if (/省|市/.test(level)) result.huaweiAwardScope = "省市级";
    else if (/院|系/.test(level)) result.huaweiAwardScope = "院系级";
    else if (/企业/.test(level)) result.huaweiAwardScope = "企业级";
    else result.huaweiAwardScope = "校级";
    result.huaweiAwardName = result.awardName || result.name || "";
    result.huaweiAwardGrade = result.awardGrade || result.awardLevel || "";
    result.huaweiAwardDescription = result.awardDescription || result.description || "";
    return result;
  }

  function huaweiPageStep(pageIndex, name, category, options) {
    options = options || {};
    var sectionIds = ["#baseinfo", "#示例资料", "#示例资料-exp", "#示例资料s"];
    return Object.assign({
      name: name,
      category: category,
      triggerSelector: ".step li:nth-child(" + pageIndex + ") a",
      readySelector: sectionIds[pageIndex - 1] + ".current",
      scopeSelector: sectionIds[pageIndex - 1] + ".current",
      fillMode: "full",
      waitAfterClickMs: 220,
      timeoutMs: 5000,
      skipClickWhenReady: true,
      skipWhenUnavailable: false,
      continueOnError: true,
    }, options);
  }

  function cmbchinaSectionStep(title, category, options) {
    options = options || {};
    return Object.assign({
      name: title,
      category: category,
      cardTitle: title,
      sectionRootSelector: ".item-box",
      cardTitleSelector: ".item-name",
      sectionByTitle: true,
      sectionRequiresSave: false,
      cardAsScope: true,
      readySelector: "input:not([type='hidden']), textarea, .ant-select, .ant-picker",
      strictReadyWithinCard: true,
      wizardAddUseAntMainBridge: true,
      fillMode: "full",
      waitAfterClickMs: 180,
      timeoutMs: 6000,
      skipClickWhenReady: true,
      skipWhenUnavailable: true,
      skipSave: true,
      continueOnError: true,
    }, options);
  }

  function cmbchinaAddressPath(pathValue, textValue) {
    var parts = splitStoredAddressPath(pathValue);
    if (!parts || !parts.length) {
      var text = String(textValue || "").trim();
      var match = text.match(/^(北京市|上海市|天津市|重庆市|[^省]+省|广西壮族自治区|内蒙古自治区|宁夏回族自治区|新疆维吾尔自治区|西藏自治区|香港特别行政区|澳门特别行政区)(.*?市)?/);
      parts = match ? [match[1], match[2] || match[1]] : [text];
    }
    return (parts || []).filter(Boolean).slice(0, 2);
  }

  function enrichCmbchinaBasicInfo(data, resume) {
    var result = Object.assign({}, data || {});
    var 示例资料 = resume && resume.jobIntention || {};
    var sourcePlace = cmbchinaAddressPath(result.birthOriginPath || result.nativePlacePath, result.birthOrigin || result.nativePlace);
    var birthPlace = cmbchinaAddressPath(result.birthPlacePath || result.nativePlacePath, result.birthPlace || result.nativePlace || result.birthOrigin);
    result.cmbchinaIdType = /身份证/.test(String(result.idType || result.documentType || "")) ? "身份证" : (result.idType || result.documentType);
    result.cmbchinaSourceProvince = sourcePlace[0] || "";
    result.cmbchinaSourceCity = sourcePlace[1] || "";
    result.cmbchinaBirthProvince = birthPlace[0] || "";
    result.cmbchinaBirthCity = birthPlace[1] || "";
    result.cmbchinaInterviewCity = 示例资料.city || 示例资料.expectedLocation || result.expectedInterviewCity || "";
    result.cmbchinaCurrentResidence = result.currentAddress || result.currentResidence || result.currentCity || "";
    result.cmbchinaHasFormalWork = resume && Array.isArray(resume.示例资料Experience) && resume.示例资料Experience.length ? "是" : "否";
    var intro = resume && resume.示例资料Introduction;
    result.cmbchinaSelfAssessment = typeof intro === "string"
      ? intro
      : intro && (intro.示例资料Introduction || intro.summary || intro.description) || result.示例资料Introduction || "";
    if (/^中共党员$/.test(String(result.politicalStatus || ""))) result.cmbchinaPoliticalStatus = "中国共产党党员";
    else if (/^中共预备党员$/.test(String(result.politicalStatus || ""))) result.cmbchinaPoliticalStatus = "中国共产党预备党员";
    else if (/示例资料/.test(String(result.politicalStatus || ""))) result.cmbchinaPoliticalStatus = "中国共产主义青年团团员";
    else result.cmbchinaPoliticalStatus = result.politicalStatus;
    return result;
  }

  function isCmbchinaHighSchool(row) {
    return /高中|中专|中技|技校|职高/.test(String(row && (row.level || row.示例资料Level) || ""));
  }

  function normalizeCmbchinaLevel(value) {
    var text = String(value || "").trim();
    if (/博士后/.test(text)) return "博士后";
    if (/博士/.test(text)) return "博士研究生";
    if (/MBA/i.test(text)) return "MBA";
    if (/硕士|研究生/.test(text)) return "硕士研究生";
    if (/本科|学士|大学/.test(text)) return "本科";
    if (/大专|专科/.test(text)) return "大专";
    if (/中专|中技|技校|职高/.test(text)) return "中技（中专/技校/职高）";
    if (/高中/.test(text)) return "高中";
    return text;
  }

  function cmbchinaEducationRank(row) {
    var level = normalizeCmbchinaLevel(row && (row.level || row.示例资料Level));
    var ranks = {
      "中技（中专/技校/职高）": 1,
      "高中": 2,
      "大专": 3,
      "本科": 4,
      "硕士研究生": 5,
      "MBA": 5,
      "博士研究生": 6,
      "博士后": 7,
    };
    return ranks[level] || 99;
  }

  function enrichCmbchinaEducationRow(row) {
    var result = Object.assign({}, row || {});
    result.cmbchinaLevel = normalizeCmbchinaLevel(result.level || result.示例资料Level);
    result.cmbchinaDuration = { startTime: result.startTime, endTime: result.endTime };
    result.cmbchinaFullTime = /全日制|统招/.test(String(result.示例资料Type || result.isUnifiedAdmission || "")) ? "是" : "否";
    result.cmbchinaExchange = isAffirmative(result.isExchangeStudent || result.exchangeStudent || result.cooperateExchange) ? "是" : "否";
    var rank = String(result.classRank || result.majorRank || "").trim();
    var percent = rank.match(/(\d+)\s*%/);
    result.cmbchinaMajorRank = percent && Number(percent[1]) <= 20 ? "前20%" : (/中下/.test(rank) ? "中下等" : "中等");
    return result;
  }

  function enrichCmbchinaFamilyRow(row, index, resume) {
    var result = Object.assign({}, row || {});
    result.cmbchinaInGroup = isAffirmative(result.isBankEmployee || result.示例资料InMerchantsGroup) ? "是" : "否";
    var 示例资料 = resume && resume.示例资料Info || {};
    result.cmbchinaHasRelative = 示例资料.hasRelativeInCompany == null ? "否" : (isAffirmative(示例资料.hasRelativeInCompany) ? "是" : "否");
    return result;
  }

  function cmbchinaFamilyRows(rows, resume) {
    var output = (rows || []).map(function (row) { return Object.assign({}, row); });
    var hasEmergency = output.some(function (row) { return /紧急/.test(String(row && row.relationship || "")); });
    if (!hasEmergency) {
      var 示例资料 = resume && resume.示例资料Info || {};
      var source = output[0] || {};
      output.push(Object.assign({}, source, {
        relationship: "紧急联络人",
        name: 示例资料.emergencyContactName || source.name || "",
        phone: 示例资料.emergencyPhone || source.phone || "",
      }));
    }
    return output;
  }

  function enrichCmbchinaPracticeRow(row) {
    var result = Object.assign({}, row || {});
    result.cmbchinaDuration = { startTime: result.startTime, endTime: result.endTime };
    result.cmbchinaFormal = result.__afCategory === "示例资料Experience" ? "是" : "否";
    result.cmbchinaCity = result.city || result.location || result.示例资料Location || "";
    result.cmbchinaRole = result.position || result.role || result.jobTitle || "";
    result.cmbchinaContent = [result.responsibilities || result.detailedContent || result.description, result.achievements || result.contribution, result.result].filter(Boolean).join("\n");
    return result;
  }

  function enrichCmbchinaAwardRow(row) {
    var result = Object.assign({}, row || {});
    result.cmbchinaAwardType = "奖项";
    var level = String(result.awardLevel || result.level || "");
    if (/国际/.test(level)) result.cmbchinaAwardLevel = "国际级";
    else if (/国家|全国/.test(level)) result.cmbchinaAwardLevel = "国家级";
    else if (/省|自治区/.test(level)) result.cmbchinaAwardLevel = "省区级";
    else if (/市|县/.test(level)) result.cmbchinaAwardLevel = "县市级";
    else result.cmbchinaAwardLevel = "院校级";
    result.cmbchinaAwardDate = result.awardTime || result.time || result.obtainedTime;
    return result;
  }

  function enrichCmbchinaClubRow(row) {
    var result = Object.assign({}, row || {});
    result.cmbchinaClubName = result.activityName || result.organization || result.name || "";
    result.cmbchinaClubRole = result.role || result.position || result.title || "";
    result.cmbchinaDuration = { startTime: result.startTime, endTime: result.endTime };
    result.cmbchinaClubDescription = result.description || result.detailedContent || result.details || "";
    return result;
  }

  function enrichCmbchinaSkills(data, resume) {
    var result = Object.assign({}, data || {});
    var 示例资料s = resume && Array.isArray(resume.示例资料Skills) ? resume.示例资料Skills : [];
    var english = 示例资料s.find(isEnglishLanguage) || {};
    var cert = String(english.certificate || english.certificateName || english.level || "");
    if (/六级|CET[- ]?6/i.test(cert)) result.cmbchinaEnglishLevel = "CET-6";
    else if (/四级|CET[- ]?4/i.test(cert)) result.cmbchinaEnglishLevel = "CET-4";
    else if (/示例资料|雅思/i.test(cert)) result.cmbchinaEnglishLevel = "示例资料";
    else if (/TOEFL|托福/i.test(cert)) result.cmbchinaEnglishLevel = "TOEFL";
    else if (/GRE/i.test(cert)) result.cmbchinaEnglishLevel = "GRE";
    else if (/GMAT/i.test(cert)) result.cmbchinaEnglishLevel = "GMAT";
    else if (cert) result.cmbchinaEnglishLevel = "其他";
    result.cmbchinaEnglishScore = english.score || "";
    var 示例资料 = resume && resume.示例资料Info || {};
    result.cmbchinaComputerSkill = 示例资料.示例资料Level || 示例资料.示例资料Skills || "";
    result.cmbchinaOtherSkill = [示例资料.hobbies, 示例资料.strengths || 示例资料.specialty].filter(Boolean).join("；");
    return result;
  }

  function cibSectionStep(sectionSelector, name, category, options) {
    options = options || {};
    return Object.assign({
      name: name,
      category: category,
      triggerSelector: sectionSelector,
      readySelector: sectionSelector + " form",
      scopeSelector: sectionSelector,
      fillMode: "full",
      waitAfterClickMs: 120,
      timeoutMs: 5000,
      skipClickWhenReady: true,
      skipWhenUnavailable: true,
      skipSave: true,
      continueOnError: true,
    }, options);
  }

  function enrichCibBasicInfo(data, resume) {
    var result = Object.assign({}, data || {});
    var 示例资料 = resume && resume.示例资料Info || {};
    var 示例资料 = resume && resume.jobIntention || {};
    var intro = resume && resume.示例资料Introduction;
    if (intro && typeof intro === "object") intro = intro.content || intro.description || intro.示例资料Introduction;
    result.cibNativePlace = cibNativePlaceValue(result.nativePlacePath, result.nativePlace || result.birthOrigin);
    result.cibHukouLocation = cibNativePlaceValue(result.hukouLocationPath, result.hukouLocation || result.registeredResidence || result.birthOrigin);
    result.cibWorkStartDate = result.示例资料StartDate || result.firstWorkDate || "";
    result.cibEmergencyName = result.emergencyContactName || result.emergencyContact || "";
    result.cibEmergencyPhone = result.emergencyPhone || result.emergencyContactPhone || "";
    result.cibAddress = result.currentAddress || result.mailingAddress || result.address || "";
    result.cibHobbies = [result.hobbies, result.strengths || result.specialty].filter(Boolean).join("；");
    result.cibApplicationReason = result.applicationReason || result.jobMotivation || 示例资料.applicationReason ||
      [示例资料.position || 示例资料.expectedPosition, intro].filter(Boolean).join("；");
    result.cibSelfIntroduction = typeof intro === "string" ? intro : (result.示例资料Introduction || "");
    return Object.assign(result, 示例资料);
  }

  function cibSearchLocation(pathValue, textValue) {
    var parts = splitStoredAddressPath(pathValue);
    if (parts && parts.length) return parts[parts.length - 1];
    var text = String(textValue || "").trim();
    if (!text) return "";
    var matches = text.match(/[^省市区县]+(?:省|自治区|特别行政区|市|自治州|地区|盟|区|县)/g);
    return matches && matches.length ? matches[matches.length - 1] : text;
  }

  function cibNativePlaceValue(pathValue, textValue) {
    var parts = splitStoredAddressPath(pathValue);
    if (parts && parts.length) return parts.slice(0, 2).join("");
    var text = String(textValue || "").trim();
    if (!text) return "";
    var matches = text.match(/[^省市区县]+(?:省|自治区|特别行政区|市|自治州|地区|盟|区|县)/g);
    return matches && matches.length ? matches.slice(0, 2).join("") : text;
  }

  function enrichCibEducationRow(row) {
    var result = Object.assign({}, row || {});
    result.cibCountry = result.country || result.countryRegion || result.schoolCountry || "中国";
    result.cibDegree = result.degree || result.degreeName || "";
    result.cibRank = result.gradeRank || result.classRank || result.majorRank || result.ranking || "";
    var studyForm = String(result.示例资料Type || result.studyForm || result.enrollmentType || result.isUnifiedAdmission || "");
    result.cibStudyForm = /非全日制|非统招|自考|函授|成人/.test(studyForm) ? "非全日制" : "全日制";
    return result;
  }

  function isCibHigherEducation(row) {
    var level = String(row && (row.level || row.示例资料Level || row.degreeLevel) || "");
    return /本科|硕士|研究生|博士/.test(level) && !/高中|中专|大专|专科/.test(level);
  }

  function enrichCibWorkRow(row) {
    var result = Object.assign({}, row || {});
    result.cibDepartment = result.department || result.division || "";
    result.cibPosition = result.position || result.jobTitle || result.role || "";
    result.cibDescription = [
      result.responsibilities || result.detailedContent || result.description,
      result.achievements || result.contribution || result.result,
    ].filter(Boolean).join("\n");
    result.cibLeaveReason = result.leaveReason || result.reasonForLeaving ||
      (result.__afCategory === "示例资料Experience" ? "实习期结束" : "职业发展");
    return result;
  }

  function enrichCibFamilyRow(row) {
    var result = Object.assign({}, row || {});
    result.cibCompanyPosition = [result.company || result.organization, result.position || result.jobTitle].filter(Boolean).join(" / ");
    return result;
  }

  function enrichCibCertificateRow(row) {
    var result = Object.assign({}, row || {});
    result.cibObtainedTime = result.obtainedTime || result.obtainTime || result.issueDate || "";
    result.cibExpiryTime = result.expiryTime || result.expirationDate || result.expiryDate || "";
    result.cibCertificateNo = result.certificateNo || result.certificateNumber || result.number || "";
    result.cibIssuer = result.issuingAuthority || result.issuer || result.organization || "";
    return result;
  }

  function enrichCibAwards(data, resume) {
    var result = Object.assign({}, data || {});
    var rows = resume && Array.isArray(resume.示例资料) ? resume.示例资料 : [];
    result.cibAwardsText = rows.map(function (row) {
      return [row && (row.awardName || row.name || row.title), row && (row.awardTime || row.time), row && (row.awardLevel || row.level), row && (row.description || row.awardDescription)]
        .filter(Boolean).join(" / ");
    }).filter(Boolean).join("\n");
    return result;
  }

  function cibDateFromAvailability(value) {
    var text = String(value || "").trim();
    if (/^\d{4}[-/.]\d{1,2}[-/.]\d{1,2}$/.test(text)) return text.replace(/[/.]/g, "-");
    if (!text) return "";
    var days = /三个月|3个月/.test(text) ? 90 :
      /两个月|2个月/.test(text) ? 60 :
      /一个月|1个月/.test(text) ? 30 :
      /两周|2周/.test(text) ? 14 :
      /一周|1周/.test(text) ? 7 :
      /随时|立即/.test(text) ? 0 : null;
    if (days == null) return "";
    var date = new Date();
    date.setDate(date.getDate() + days);
    return date.getFullYear() + "-" + String(date.getMonth() + 1).padStart(2, "0") + "-" + String(date.getDate()).padStart(2, "0");
  }

  function enrichCibJobIntention(data, resume) {
    var result = Object.assign({}, data || {});
    var 示例资料 = resume && resume.示例资料Info || {};
    var locationPath = splitStoredAddressPath(result.expectedLocationPath);
    var expectedText = result.expectedLocation || result.city || (locationPath && locationPath[locationPath.length - 1]) || "";
    result.cibExpectedLocation = String(expectedText).split(/[、,，;；/|]/).map(function (item) {
      return cibSearchLocation(null, item);
    }).filter(Boolean).slice(0, 3);
    result.cibAcceptAdjustment = result.acceptAdjustment || result.obeyAssignment || 示例资料.cityFlexible || "";
    result.cibCurrentAnnualSalary = bankcommAnnualSalaryWan(result.currentAnnualSalary || result.currentSalary || 示例资料.currentAnnualSalary || 示例资料.currentSalary, true);
    result.cibExpectedAnnualSalary = bankcommAnnualSalaryWan(result.expectedAnnualSalary || result.expectedSalary || result.salary || 示例资料.expectedSalary, true);
    result.cibAvailabilityDate = cibDateFromAvailability(result.availability || result.onboardDate || result.arrivalDate);
    var channel = String(result.recruitmentChannel || 示例资料.recruitmentChannel || "").trim();
    if (/兴业|银行招聘官网|官网/.test(channel)) result.cibRecruitmentChannel = "兴业官网";
    else if (/智联/.test(channel)) result.cibRecruitmentChannel = "智联招聘";
    else if (/前程|51job/i.test(channel)) result.cibRecruitmentChannel = "前程无忧";
    else if (/BOSS/i.test(channel)) result.cibRecruitmentChannel = "BOSS直聘";
    else if (/猎聘/.test(channel)) result.cibRecruitmentChannel = "猎聘";
    else result.cibRecruitmentChannel = channel ? "其他" : "兴业官网";
    return result;
  }

  function normalizeCibDeclaration(value) {
    var text = String(value == null ? "" : value).trim();
    if (!text) return "";
    if (/^(否|无|没有|未|不|N|NO|FALSE|0)/i.test(text)) return "否";
    if (/^(是|有|Y|YES|TRUE|1)/i.test(text)) return "是";
    return "是";
  }

  function enrichCibOtherInfo(data, resume) {
    var result = Object.assign({}, data || {});
    var 示例资料 = resume && resume.示例资料Info || {};
    result.cibMisconduct = normalizeCibDeclaration(result.hasMisconduct || result.hasDisciplinaryRecord || 示例资料.hasBadRecord);
    result.cibNonCompete = normalizeCibDeclaration(result.hasNonCompete || result.hasOtherEmploymentAgreement || 示例资料.hasNonCompete);
    result.cibBusinessOrPartTime = normalizeCibDeclaration(result.hasBusinessOrPartTime);
    result.cibForeignResidence = normalizeCibDeclaration(result.hasForeignResidence || result.foreignResidence || 示例资料.hasForeignResidence || 示例资料.overseasMigration);
    return result;
  }

  function sfExpressCampusWorkflow() {
    function sfSkillData(resume) {
      var 示例资料s = resume && Array.isArray(resume.示例资料Skills) ? resume.示例资料Skills : [];
      var 示例资料 = resume && Array.isArray(resume.示例资料) ? resume.示例资料 : [];
      var first = 示例资料s[0] || {};
      return {
        sfEnglishLevel: first.level || first.certificate || first.certificateName || "",
        sfEnglishScore: first.score || "",
        sfOtherLanguage: 示例资料s.slice(1).map(function (r) { return [r.name, r.level || r.certificate || r.certificateName, r.score].filter(Boolean).join(" "); }).filter(Boolean).join("；"),
        sfMajorCert: 示例资料.map(function (r) { return [r.certificateName || r.name, r.obtainedTime].filter(Boolean).join(" "); }).filter(Boolean).join("；")
      };
    }
    function normalizeSfIndustry(value) {
      var text = String(value || "").replace(/\s+/g, "");
      if (!text) return "";
      if (/交通|贸易|物流/.test(text)) return "交通.贸易.物流";
      if (/互联网|游戏|软件|计算机|信息技术/.test(text)) return "互联网.游戏.软件";
      if (/电子|通信|硬件/.test(text)) return "电子.通信.硬件";
      if (/房地产|建筑|物业/.test(text)) return "房地产.建筑.物业";
      if (/金融|银行|证券|基金/.test(text)) return "金融";
      if (/消费|零售|快消/.test(text)) return "消费品";
      if (/汽车|机械|制造/.test(text)) return "汽车.机械.制造";
      if (/服务|外包|中介/.test(text)) return "服务.外包.中介";
      if (/广告|传媒|教育|文化/.test(text)) return "广告.传媒.教育.文化";
      if (/制药|医疗|医药/.test(text)) return "制药.医疗";
      if (/能源|化工|环保/.test(text)) return "能源.化工.环保";
      if (/政府|农林|牧渔/.test(text)) return "政府.农林牧渔";
      return text;
    }
    var step = function (name, category, triggerSelector, readySelector, scopeSelector) {
      return {
        name: name,
        category: category,
        triggerSelector: triggerSelector,
        readySelector: readySelector,
        scopeSelector: scopeSelector || readySelector,
        fillMode: "full",
        waitAfterClickMs: 350,
        timeoutMs: 7000,
        // 顺丰展示态也包含 resume-noedit-form，不能据此跳过下一类目的入口点击。
        skipClickWhenReady: false,
        // 顺丰本轮不自动保存；填写完当前模块后直接切换下一个类别。
        skipSave: true,
        skipWhenUnavailable: true,
        continueOnError: true,
      };
    };
    return {
      id: "sf-express-campus-resume",
      name: "顺丰校园招聘简历",
      enabled: true,
      privateSpecialSite: true,
      hostname: "campus.sf-express.com",
      urlPattern: /^https?:\/\/campus\.sf-express\.com\/#\/personalCenter/i,
      pageGuardSelector: ".tab-block.re-block",
      continueOnError: true,
      steps: [
        Object.assign(step("个人信息", "示例资料Info", "#personalInfo a[href^='javascript:void']", "#personalInfo .resume-form", "#personalInfo"), {
          // 顺丰城市字段点击后打开“城市选择”弹窗（省/市原生下拉 + 确定），不是文本框。
          fieldSequence: [
            { label: "姓名", field: "name" }, { label: "性别", field: "gender" },
            { label: "出生日期", field: "birthDate" }, { label: "证件类型", field: "idType", type: "sfIdType" },
            { label: "证件号码", field: "idNumber" }, { label: "民族", field: "ethnicity", optional: true },
            { label: "政治面貌", field: "politicalStatus", optional: true },
            { label: "现居住城市", field: "currentLocation", type: "sfCityPicker", skip: true },
            { label: "期望城市", field: "expectedLocation", type: "sfCityPicker", skip: true },
            { label: "籍贯", field: "nativePlace", type: "sfCityPicker", skip: true }, { label: "手机号码", field: "phone" },
            { label: "邮箱", field: "email" }
          ]
        }),
        step("投递意向", "jobIntention", "#deliveryIntention a[href^='javascript:void']", "#deliveryIntention .resume-form", "#deliveryIntention"),
        // 添加按钮位于编辑表单外层；重复经历必须以整个模块为作用域，
        // 否则第一张能打开但后续找不到“添加教育背景”。
        Object.assign(step("教育信息", "示例资料", "#示例资料List a.new-one-btn", "#示例资料List .resume-form2", "#示例资料List"), {
          // 已有教育卡片时直接填写；空状态才点击一次“添加教育背景”。
          skipClickWhenReady: true,
          示例资料ForCategoryData: true,
          rowScopeSelector: ".示例资料-edit-item__wrapper",
          rowAddSelector: "a.new-one-btn",
          示例资料AddSelector: "a.new-one-btn",
          示例资料AddRootSelector: "#示例资料List",
          示例资料AddNativeClick: false,
          forceAddFirstRepeatWhenNoExisting: false,
          // 选择硕士后顺丰才异步生成本科卡片，必须先填第一张再取第二张。
          rowAddAfterEach: true,
          rowAddOnlyWhenNoExisting: true,
          useRepeatRowScopeByIndex: true,
          waitForRepeatRowByIndex: true,
          示例资料RowIndexTimeoutMs: 7000,
          // 顺丰教育模块只接收本科及以上，简历中的高中/中专记录不创建卡片。
          rowFilter: function (row) {
            var level = String(row && (row.level || row.示例资料Level || row.示例资料 || row.degree) || "");
            return !/高中|中专|中技|技校|职高/.test(level);
          },
          // 顺丰允许多张教育卡片同时保持编辑态，不自动保存。
          skipSave: true,
          rowSort: function (a, b) {
            var rank = function (row) { var t = String(row && (row.示例资料Level || row.level || row.示例资料 || row.degree) || ""); if (/博士/.test(t)) return 4; if (/硕士|研究生/.test(t)) return 3; if (/本科|学士/.test(t)) return 2; if (/专科|大专/.test(t)) return 1; return 0; };
            return rank(b) - rank(a);
          },
          rowTransform: function (row) {
            var copy = Object.assign({}, row || {});
            if (!String(copy.classRank || copy.ranking || copy.gradeRank || "").trim()) copy.classRank = "前10%";
            return copy;
          },
          rowFieldSequence: [
            { label: "学校全称", field: "school", type: "elementSelect" },
            { label: "学历", field: "level", type: "elementSelect",
              // 最高学历为硕士时，顺丰自动生成的本科卡片已锁定“大学本科”。
              // 只有第一张最高学历卡片需要主动选择学历。
              when: function (_, __, step) { return !step || !Number.isInteger(step.示例资料Index) || step.示例资料Index === 0; } },
            { label: "入学时间", field: "startTime", type: "elementDate" },
            { label: "毕业时间", field: "endTime", type: "elementDate" },
            { label: "院系", field: "department", type: "text" },
            { label: "专业名称", field: "major", type: "text" },
            { label: "年级排名", field: "classRank", type: "elementSelect", optional: true,
              // 顺丰未提供排名时按业务约定选择“前10%”。
              valueTransform: function (value) { return String(value || "").trim() || "前10%"; } },
            { label: "受教育类型", field: "示例资料Type", type: "elementSelect", optional: true }
          ]
        }),
        Object.assign(step("技能信息", "示例资料Skills", "#skill a[href^='javascript:void']", "#skill .resume-form", "#skill"), {
          dataTransform: function (_, resume) { return sfSkillData(resume); },
          fieldSequence: [
            { label: "外语等级", field: "sfEnglishLevel", type: "elementSelect" },
            { label: "外语等级-成绩", field: "sfEnglishScore", type: "text" },
            { label: "其他语言水平/证书", field: "sfOtherLanguage", type: "text", optional: true },
            { label: "专业技能证书", field: "sfMajorCert", type: "text", optional: true }
          ]
        }),
        step("校园经历", ["campusLeadership", "campusActivities", "示例资料"], "#honor a[href^='javascript:void']", "#honor", "#honor"),
        Object.assign(step("示例资料", "示例资料Experience", "#示例资料List a.new-one-btn", "#示例资料List .resume-form", "#示例资料List"), {
          示例资料ForCategoryData: true,
          rowScopeSelector: ".示例资料-edit-item__wrapper",
          rowAddSelector: "a.new-one-btn",
          示例资料AddSelector: "a.new-one-btn",
          示例资料AddRootSelector: "#示例资料List",
          示例资料AddNativeClick: true,
          forceAddFirstRepeatWhenNoExisting: true,
          useRepeatRowScopeByIndex: true,
          skipSave: true,
          rowTransform: function (row) {
            var copy = Object.assign({}, row || {});
            copy.industry = normalizeSfIndustry(copy.industry || copy.zhaopinIndustry || copy.companyIndustry);
            return copy;
          },
          rowFieldSequence: [
            { label: "工作单位", field: "company", type: "text" },
            { label: "职务", field: "position", type: "text" },
            { label: "行业", field: "industry", type: "elementSelect" },
            { label: "开始时间", field: "startTime", type: "elementDate" },
            { label: "结束时间", field: "endTime", type: "elementDate" },
            { label: "实习描述", field: "detailedContent", type: "text", optional: true }
          ]
        }),
        Object.assign(step("项目经验", "示例资料Experience", "#示例资料List a.new-one-btn", "#示例资料List .resume-form", "#示例资料List"), {
          示例资料ForCategoryData: true,
          rowScopeSelector: ".示例资料-edit-item__wrapper",
          rowAddSelector: "a.new-one-btn",
          示例资料AddSelector: "a.new-one-btn",
          示例资料AddRootSelector: "#示例资料List",
          示例资料AddNativeClick: true,
          forceAddFirstRepeatWhenNoExisting: true,
          useRepeatRowScopeByIndex: true,
          skipSave: true,
          rowFieldSequence: [
            { label: "项目名称", field: "name", type: "text" },
            { label: "职务", field: "role", type: "text", optional: true },
            { label: "开始时间", field: "startTime", type: "elementDate", optional: true },
            { label: "结束时间", field: "endTime", type: "elementDate", optional: true },
            { label: "项目职责", field: "contributions", type: "text", optional: true },
            { label: "项目简述", field: "details", type: "text", optional: true }
          ]
        }),
        step("自我评价", "示例资料Introduction", "#示例资料Eval a[href^='javascript:void']", "#示例资料Eval .resume-form", "#示例资料Eval .resume-form"),
      ],
    };
  }

  function citicFormStep(formSelector, name, category, options) {
    options = options || {};
    // 中信页面允许直接切换下一个模块；个别受控字段未命中时不应让整轮填写停住。
    // 中信把所有大类表单同时留在页面 DOM 中，不能以“控件已存在”判断当前
    // 栏目已打开；每一步都必须通过左侧锚点定位到正确模块。
    var result = Object.assign({ name: name, category: category, triggerSelector: options.triggerSelector || formSelector, readySelector: formSelector + " input, " + formSelector + " select, " + formSelector + " textarea", scopeSelector: formSelector, fillMode: "full", skipClickWhenReady: true, skipWhenUnavailable: false, waitAfterClickMs: 120, timeoutMs: 6000, saveSelector: formSelector + " .saveBtnClass", waitAfterSaveMs: 450, saveTimeoutMs: 7000, skipSave: true, saveOnPartialFill: true, continueOnError: true, stopOnSaveError: false }, options);
    result.forceTriggerClick = true;
    if (["示例资料", "在校经历", "示例资料", "项目经历"].indexOf(name) !== -1) result.useRepeatRowScopeByIndex = true;
    // 只有这四类同页经历的空卡片需要“新增后卡片数增加”的确认。教育、语言、
    // 证书有各自已验证的多条填写路径，不能继承这层规则。
    var 示例资料CardCountGuard = ["示例资料", "在校经历", "示例资料", "项目经历"].indexOf(name) !== -1;
    if (示例资料CardCountGuard && !result.示例资料AddSelector && result.rowAddSelector) result.示例资料AddSelector = result.rowAddSelector;
    if (示例资料CardCountGuard && !result.示例资料AddRootSelector) result.示例资料AddRootSelector = formSelector;
    if (示例资料CardCountGuard && result.rowAddNativeClick && result.示例资料AddNativeClick == null) result.示例资料AddNativeClick = true;
    if (示例资料CardCountGuard && result.示例资料AddWaitForRowCount == null) result.示例资料AddWaitForRowCount = true;
    if (name === "示例资料") { result.runRepeatPrerequisiteWhenNoData = true; result.emptyDataTransform = enrichCiticFirstEmployment; result.示例资料PrerequisiteScopeSelector = "#gzjlDivId"; }
    return result;
  }

  function citicDescription(row) { return [row && (row.detailedContent || row.responsibilities || row.description), row && (row.result || row.achievements || row.contribution)].filter(Boolean).join("\n"); }
  function enrichCiticInternRow(row) { var result = Object.assign({}, row || {}); result.citicDescription = citicDescription(result); return result; }
  function enrichCiticCampusRow(row) { var result = Object.assign({}, row || {}); result.citicOrganization = result.activityName || result.示例资料Name || result.title || ""; result.citicRole = result.role || result.title || ""; result.citicDescription = result.description || ""; return result; }
  function enrichCiticWorkRow(row) { var result = Object.assign({}, row || {}); result.citicFirstEmployment = "是"; result.citicEmploymentType = result.employmentType || result.employmentNature || result.示例资料Type || ""; result.citicJobLevel = result.jobLevel || result.rank || ""; result.citicJobTitle = result.jobTitle || result.administrativeTitle || "无"; result.citicLeaveReason = result.leaveReason || ""; result.citicDescription = citicDescription(result); return result; }
  function enrichCiticFirstEmployment(data, resume) { var result = Object.assign({}, data || {}); result.citicFirstEmployment = resume && Array.isArray(resume.示例资料Experience) && resume.示例资料Experience.length ? "否" : "是"; return result; }
  function enrichCiticProjectRow(row) { var result = Object.assign({}, row || {}); result.citicProjectDescription = result.details || result.description || ""; result.citicProjectResponsibilities = result.contributions || result.responsibilities || result.role || ""; result.citicProjectResult = result.result || result.achievements || ""; return result; }
  function enrichCiticTrainingRow(row) { var result = Object.assign({}, row || {}); result.citicTrainingDescription = result.description || ""; return result; }
  function enrichCiticLanguageRow(row) { var result = Object.assign({}, row || {}); result.citicLanguage = result.name || result.示例资料 || ""; result.citicTestType = result.certificate || result.certificateName || result.level || ""; result.citicScore = result.score || ""; result.citicIssuer = result.issuingAuthority || result.issuer || result.organization || ""; return result; }
  function enrichCiticCertificateRow(row) { var result = Object.assign({}, row || {}); result.citicCertificateName = result.certificateName || result.name || result.certificate || ""; result.citicCertificateType = result.certificateType || result.citicCertificateName; result.citicCertificateIssuer = result.issuingAuthority || result.issuer || result.organization || ""; result.citicCertificateScore = result.score || ""; result.citicCertificateDescription = result.description || ""; return result; }
  function enrichCiticFamilyRow(row) { var result = Object.assign({}, row || {}); result.citicForeignIdentity = "无"; return result; }
  function enrichCiticSelfIntroduction(data, resume) { var result = Object.assign({}, data || {}); var source = data && (data.示例资料Introduction || data.content || data.description) || resume && resume.示例资料Info && (resume.示例资料Info.示例资料Introduction || resume.示例资料Info.summary) || ""; result.citicSelfIntroduction = source; return result; }
  function citicEducationRank(row) { var level = String(row && (row.level || row.示例资料Level || row.degreeLevel) || ""); if (/博士/.test(level)) return 5; if (/硕士|研究生|MBA|EMBA/i.test(level)) return 4; if (/本科|学士|大学/.test(level)) return 3; if (/专科|大专/.test(level)) return 2; if (/高中|中专|职高|技校/.test(level)) return 1; return 0; }
  function normalizeCiticEducationLevel(value) { var text = String(value || "").trim(); if (/博士/.test(text)) return "博士研究生"; if (/硕士|研究生|MBA|EMBA/i.test(text)) return "硕士研究生"; if (/本科|学士|大学/.test(text)) return "本科"; if (/专科|大专/.test(text)) return "大专"; if (/高中|中专|职高|技校/.test(text)) return "高中及以下"; return text; }
  function prepareCiticEducationRows(rows) {
    rows = Array.isArray(rows) ? rows.slice() : [];
    return rows.sort(function (left, right) {
      var rankDiff = citicEducationRank(left) - citicEducationRank(right);
      if (rankDiff) return rankDiff;
      return String(left && left.startTime || "").localeCompare(String(right && right.startTime || ""));
    }).map(function (row, index, allRows) {
      var result = Object.assign({}, row || {});
      result.citicEducationLevel = normalizeCiticEducationLevel(result.level || result.示例资料Level || result.degreeLevel);
      result.citicHighest = index === allRows.length - 1 ? "是" : "否";
      return result;
    });
  }
  function citicDegreeGroup(row) { var degreeText = [row && row.degree, row && row.degreeType].filter(Boolean).join(" "); if (!degreeText) return ""; if (/^(?:无|未取得)$/.test(String(row && row.degree || ""))) return "无"; return /专业学位|专业硕士|MBA|EMBA/.test(degreeText) ? "专业学位" : "学术学位"; }
  function citicAcademicDegreeName(row) { var result = row || {}; var degreeText = [result.degree, result.degreeType].filter(Boolean).join(" "); if (!degreeText) return ""; var text = [degreeText, result.level].filter(Boolean).join(" "); var rawDegree = String(result.degree || "").replace(/学位$/g, "").trim(); if (/^(?:无|未取得)$/.test(rawDegree)) return ""; var exact = rawDegree.match(/(?:哲学|经济学|法学|教育学|文学|历史学|理学|工学|农学|医学|军事学|管理学|建筑学|艺术学|交叉学)?(?:博士|硕士|学士)$/); if (exact && exact[0] !== "博士" && exact[0] !== "硕士" && exact[0] !== "学士") return exact[0]; if (/专业学位|专业硕士|MBA|EMBA/.test(text)) return exact ? exact[0] : ""; var degreeSuffix = /博士/.test(text) ? "博士" : /硕士|研究生/.test(text) ? "硕士" : /学士|本科/.test(text) ? "学士" : ""; var categories = ["哲学", "经济学", "法学", "教育学", "文学", "历史学", "理学", "工学", "农学", "医学", "军事学", "管理学", "建筑学", "艺术学", "交叉学"]; var category = categories.find(function (entry) { return String(result.majorCategory || "").indexOf(entry) !== -1; }) || ""; return degreeSuffix && category ? category + degreeSuffix : ""; }
  function enrichCiticEducationRow(row) { var result = Object.assign({}, row || {}); var isPreHigher = citicEducationRank(result) <= 1; if (isPreHigher) result.citicGraduationMode = "毕业"; if (!isPreHigher) { result.citicDegreeGroup = citicDegreeGroup(result); result.citicDegreeName = citicAcademicDegreeName(result); result.citicSecondDegree = result.isDoubleDegree === "是" || result.isDoubleDegree === "否" ? result.isDoubleDegree : ""; result.citicMajorCategory = result.majorCategory || ""; } return result; }
  function citicAwardLevel(value) { var text = String(value || ""); if (/国家|全国|国际/.test(text)) return "国家级"; if (/省|市/.test(text)) return "省市级"; if (/校|院/.test(text)) return "院校级"; return "其他"; }
  function enrichCiticAwardRow(row) { var result = Object.assign({}, row || {}); result.citicAwardCategory = "奖励"; result.citicAwardLevel = citicAwardLevel(result.awardLevel || result.awardScope || result.awardName); result.citicAwardReason = result.awardDescription || ""; return result; }
  function citicTextAddressPath(value) { var text = String(value || "").replace(/\s+/g, "").trim(); if (!text) return []; var municipality = text.match(/^(北京市|上海市|天津市|重庆市)/); if (municipality) { var municipalityDistrict = text.slice(municipality[1].length).match(/^(.+?(?:区|县|市))/); return municipalityDistrict ? [municipality[1], /县$/.test(municipalityDistrict[1]) ? "县" : "市辖区", municipalityDistrict[1]] : [municipality[1]]; } var provinceMatch = text.match(/^(.*?(?:省|自治区|特别行政区))/); var province = provinceMatch && provinceMatch[1] || ""; var rest = province ? text.slice(province.length) : text; var cityMatch = rest.match(/^(.+?(?:自治州|地区|盟|市))/); var city = cityMatch && cityMatch[1] || ""; var districtMatch = (city ? rest.slice(city.length) : "").match(/^(.+?(?:区|县|市))/); return [province, city, districtMatch && districtMatch[1] || ""].filter(Boolean); }
  function citicAddressPath(pathValue, textValue) { var stored = splitStoredAddressPath(pathValue) || []; var textPath = citicTextAddressPath(textValue); if (textPath.length > stored.length && stored.every(function (part, index) { return part === textPath[index]; })) return textPath; return stored.length ? stored : textPath; }
  function enrichCiticBasicInfo(data) { var result = Object.assign({}, data || {}); result.citicPhoneRegion = /^(?:86)?1\d{10}$/.test(String(result.phone || "").replace(/\D/g, "")) ? "中国大陆" : "中国港澳台或海外"; result.citicIdType = /护照/.test(String(result.idType || "")) ? "护照" : /港澳|台湾/.test(String(result.idType || "")) ? "港澳台身份证" : "身份证"; result.citicMaritalStatus = String(result.maritalStatus || "").replace("离异", "离婚"); var health = String(result.healthStatus || ""); result.citicHealthStatus = /良好/.test(health) ? "健康或良好" : /一般/.test(health) ? "一般或较弱" : ""; result.citicBirthOriginPath = citicAddressPath(result.birthOriginPath, result.birthOrigin); result.citicHukouPath = citicAddressPath(result.hukouLocationPath, result.hukouLocation); result.citicNativePlacePath = citicAddressPath(result.nativePlacePath, result.nativePlace); result.citicCurrentAddressPath = citicAddressPath(result.currentAddressPath, result.currentAddress); result.fertilityStatus = result.fertilityStatus || "未育"; result.emergencyContactRelation = result.emergencyContactRelation || "父亲"; return result; }

  function spdbFormStep(name, category, options) {
    options = options || {};
    var result = Object.assign({
      name: name,
      category: category,
      triggerText: [name],
      preferNavigationTrigger: true,
      navigationTriggerCandidateSelector: "a, button, [role='button'], li",
      readySelector: ".fromcontainer",
      scopeSelector: ".fromcontainer",
      fillMode: "full",
      skipClickWhenReady: true,
      waitAfterClickMs: 450,
      timeoutMs: 7000,
      saveSelector: ".formsavebtn",
      waitAfterSaveMs: 500,
      saveTimeoutMs: 7000,
      postSaveConfirmSelector: "body",
      postSaveConfirmText: ["确定", "确认"],
      postSaveConfirmButtonSelector: "button, a, input[type='button'], input[type='submit'], [role='button']",
      waitAfterConfirmMs: 1200,
      wizardAllowPartialFill: true,
      continueOnError: false,
      stopOnSaveError: true,
      postbackAutoContinueWorkflowId: "spdb-recruitment",
    }, options);
    if (name === "教育情况" && !result.rowsTransform) result.rowsTransform = function (rows) { return Array.isArray(rows) ? rows.slice().sort(compareEducationByStartTime) : []; };
    return result;
  }

  // 兼容旧版浦发工作流引用；未声明转换时保持简历数据原样传递。
  function enrichSpdbBasic(data) { return Object.assign({}, data || {}); }
  function normalizeSpdbDegree(value) {
    var text = String(value == null ? "" : value).trim();
    if (!text) return "";
    if (/^(?:无|无学位|未取得|未获得)/.test(text)) return "无学位";
    if (/博士/.test(text)) return "博士";
    if (/硕士|研究生|MBA|EMBA/i.test(text)) return "硕士";
    if (/学士|本科|大学/i.test(text)) return "学士";
    if (/专科|大专|专科学历/i.test(text)) return "大专";
    return text;
  }

  // 国聘 v1：仅匹配个人中心简历页，所有字段限定在当前模块编辑器。
  function iguopinField(label, field, id, kind, options) {
    return Object.assign({ label: label, field: field, type: "iguopinField", kind: kind || "text",
      controlSelector: '[id="' + id + '"]', optional: false }, options || {});
  }
  function iguopinStep(module, name, category, fields, 示例资料, options) {
    var root = module === "示例资料_info" ? "#示例资料_info" : "." + module + "-section";
    var editor = "." + module + "-edit-section";
    return Object.assign({ name: name, category: category,
      triggerSelector: root + " .section-title button", triggerText: [name],
      triggerCandidateSelector: ".示例资料-section-menu p",
      readySelector: editor + " form.ant-form", scopeSelector: editor + " form.ant-form",
      skipClickWhenReady: true, skipWhenUnavailable: false, fillMode: "full",
      waitAfterClickMs: 300, timeoutMs: 7000,
      fieldSequence: fields, 示例资料ForCategoryData: !!示例资料, saveEachRepeatStep: true,
      示例资料AddRootSelector: root, strictRepeatAddRoot: true,
      示例资料AddSelector: ".section-title button", 示例资料AddText: ["添加"],
      示例资料ReadySelector: editor + " form.ant-form",
      updateExistingWhenPresent: !!示例资料, overwriteExistingByPosition: !!示例资料,
      existingCardSelector: "button:has(.anticon-form):not(.section-title button)",
      existingEditActionSelector: "button:has(.anticon-form):not(.section-title button)",
      rowsValidator: function () {
        var section = document.querySelector(root);
        if (!示例资料 || !section || section.querySelector(editor)) return "";
        if (section.querySelector("button:has(.anticon-form):not(.section-title button)")) return "";
        if (/填写[\s\S]*相关信息/.test(section.textContent || "")) return "";
        return "国聘当前模块已有内容但未识别编辑入口，已停止以避免重复新增";
      },
      saveSelector: editor + " .submit-btn", waitForCloseSelector: editor,
      waitAfterSaveMs: 350, saveTimeoutMs: 7000,
      minimumFilledFields: 1, saveOnPartialFill: false, keepEditorOnError: true,
      continueOnError: false, stopOnSaveError: true,
      diagnosticCloseSelector: editor + " .cancel-btn"
    }, options || {});
  }
  function iguopinFirst(row, keys) {
    for (var i = 0; row && i < keys.length; i++) {
      var value = row[keys[i]];
      if (value !== undefined && value !== null && value !== "") return value;
    }
    return "";
  }
  function iguopinYesNo(value, yes, no) {
    if (value === true || /^(是|有|yes|true)$/i.test(String(value))) return yes;
    if (value === false || /^(否|无|no|false)$/i.test(String(value))) return no;
    return value || "";
  }
  function iguopinEnrich(row) {
    var result = Object.assign({}, row || {});
    result.iguopinPeriod = { startTime: result.startTime || "", endTime: result.endTime || "" };
    return result;
  }
  function iguopinEducation(row) {
    var r = iguopinEnrich(row);
    var level = String(r.level || "");
    r.iguopinLevel = /博士/.test(level) ? "博士" : /硕士|研究生/.test(level) ? "硕士" : /本科|学士/.test(level) ? "本科" : /专科|大专/.test(level) ? "专科" : level;
    r.iguopinRegular = iguopinYesNo(iguopinFirst(r, ["isRegular", "isUnifiedEnrollment"]), "统招", "非统招");
    r.iguopinFulltime = /非全日制/.test(r.示例资料Type || "") ? "非全日制" : /^全日制$/.test(r.示例资料Type || "") ? "全日制" : iguopinYesNo(r.isFulltime, "全日制", "非全日制");
    r.iguopinHasDegree = iguopinYesNo(r.hasDegree, "有学位证", "无学位证");
    r.iguopinOverseas = iguopinYesNo(r.isOverseas, "海外留学经历", "非海外留学经历");
    r.iguopinExperience = iguopinFirst(r, ["experience", "majorDescription", "majorCourses"]);
    r.iguopinStudyLength = r.studyLength ? String(r.studyLength).replace(/年$/, "") + "年" : "";
    return r;
  }
  function iguopinWork(row) {
    var r = iguopinEnrich(row);
    r.iguopinWorkType = r.__afCategory === "示例资料Experience" ? "实习" : iguopinFirst(r, ["示例资料Type", "employmentType", "示例资料Mode"]);
    if (/^(正式|全职工作)$/.test(r.iguopinWorkType)) r.iguopinWorkType = "全职";
    r.iguopinContent = [r.detailedContent || r.responsibilities || r.description || r.content, r.result || r.achievements, r.contribution].filter(Boolean).join("\n");
    r.iguopinOverseas = iguopinYesNo(r.isOverseas, "海外示例资料", "非海外示例资料");
    // 数字薪资不猜单位。仅明确标注元/千元/K时转换，或使用专用千元值。
    r.iguopinSalaryK = iguopinFirst(r, ["monthlySalaryK"]);
    var salary = String(r.monthlySalary || r.salary || "").trim();
    if (/^\d+(\.\d+)?\s*(K|千元)$/i.test(salary)) r.iguopinSalaryK = salary.replace(/\s*(K|千元)$/i, "");
    if (/^\d+(\.\d+)?\s*元$/.test(salary)) r.iguopinSalaryK = String(parseFloat(salary) / 1000);
    return r;
  }
  function iguopinBasic(row) {
    var r = Object.assign({}, row || {});
    r.iguopinNation = String(r.ethnicity || "").replace(/族$/, "");
    r.iguopinCurrentAddress = iguopinFirst(r, ["currentAddressPath", "currentAddress"]);
    r.iguopinHukou = iguopinFirst(r, ["hukouLocationPath", "hukouLocation"]);
    r.iguopinNativePlace = iguopinFirst(r, ["nativePlacePath", "nativePlace"]);
    r.iguopinBirthOrigin = iguopinFirst(r, ["birthOriginPath", "birthOrigin"]);
    return r;
  }
  function iguopinJob(row) {
    var r = Object.assign({}, row || {});
    r.iguopinPosition = iguopinFirst(r, ["positionPath", "position"]);
    r.iguopinLocation = iguopinFirst(r, ["cityPath", "city"]);
    r.iguopinIndustry = iguopinFirst(r, ["industryPath", "industry"]);
    var salary = String(r.salary || "").trim();
    var range = salary.match(/^(\d+(?:\.\d+)?)\s*[-~～至]\s*(\d+(?:\.\d+)?)\s*(K|千元|元)?(?:\/月)?$/i);
    if (range) {
      var divisor = range[3] === "元" || (!range[3] && +range[1] >= 1000) ? 1000 : 1;
      r.iguopinSalaryMin = String(+range[1] / divisor) + "K";
      r.iguopinSalaryMax = String(+range[2] / divisor) + "K";
    }
    if (salary === "面议") r.iguopinSalaryMin = r.iguopinSalaryMax = "面议";
    return r;
  }
  function iguopinFields() {
    var f = iguopinField;
    var optional = { optional: true };
    var higher = { when: function (row) { return !/高中|中专|中技|初中|小学/.test(row.iguopinLevel || ""); } };
    var 示例资料 = [
      f("姓名", "name", "full_name"), f("性别", "gender", "gender", "radio"),
      f("出生日期", "birthDate", "birthdate", "date", { precision: "day" }),
      f("微信号", "weixin", "weixin", "text", optional), f("QQ号", "qq", "qq", "text", optional),
      f("现居住地", "iguopinCurrentAddress", "location-fe-1601-customization", "popup", { popupKind: "region" }),
      f("户口所在地", "iguopinHukou", "hukou-fe-1601-customization", "popup", { popupKind: "region" }),
      f("籍贯", "iguopinNativePlace", "示例资料_home-fe-1601-customization", "popup", { popupKind: "region" }),
      f("生源地", "iguopinBirthOrigin", "place_of_exam-fe-1601-customization", "popup", { optional: true, popupKind: "region" }),
      f("民族", "iguopinNation", "nation", "select"), f("政治面貌", "politicalStatus", "political", "select"),
      f("婚姻状况", "maritalStatus", "marriage", "select", optional),
      f("未参加工作", "hasNotWorked", "示例资料_starts_on_none", "checkbox", optional),
      f("参加工作时间", "示例资料StartDate", "示例资料_starts_on", "date"),
      f("工作经验", "示例资料ExperienceYears", "示例资料_years"),
      f("目前行业", "currentIndustry", "industry-fe-1601-customization", "popup", optional),
      f("薪资", "currentMonthlySalaryK", "salary_monthly", "text", optional),
      f("发薪月数", "salaryTimes", "salary_times", "text", optional),
      f("薪资保密", "salaryConfidential", "salary_none", "checkbox", optional),
      f("紧急联系人姓名", "emergencyContactName", "contact_name", "text", optional),
      f("紧急联系人电话", "emergencyPhone", "contact_telephone", "text", optional),
      f("身高", "height", "height", "text", optional), f("体重", "weight", "weight", "text", optional),
      f("兴趣爱好", "hobbies", "hobby", "text", optional),
      f("通信地址", "contactAddress", "contact_address", "text", optional),
      f("招聘信息获取来源", "recruitmentChannel", "source", "select", optional)
    ];
    var 示例资料 = [
      f("学历", "iguopinLevel", "示例资料", "select"),
      f("统招", "iguopinRegular", "is_regular", "radio", higher),
      f("全日制", "iguopinFulltime", "is_fulltime", "radio", higher),
      f("学位证", "iguopinHasDegree", "has_degree", "radio", Object.assign({}, higher, optional)),
      f("学位细分", "degreePath", "degree-fe-1601-customization", "popup", Object.assign({}, higher, optional)),
      f("就读年月", "iguopinPeriod", "period", "range"),
      f("学校名称", "school", "school-fe-1601-customization", "remote", { proxyId: "school", proxyName: "school_cn" }),
      f("专业分类", "majorCategory", "major_category", "select", higher),
      f("专业名称", "major", "major-fe-1601-customization", "remote", Object.assign({}, higher, { proxyId: "major", proxyName: "major_cn" })),
      f("专业排名", "classRank", "grade_ranking", "select", Object.assign({}, higher, optional)),
      f("海外留学", "iguopinOverseas", "has_overseas", "radio", optional),
      f("在校经历", "iguopinExperience", "experience", "text", optional),
      f("学制", "iguopinStudyLength", "school_system", "select"),
      f("学历证书编号", "示例资料CertificateNo", "edu_cert_no", "text", Object.assign({}, higher, optional)),
      f("学位证书编号", "degreeCertificateNo", "degree_cert_no", "text", Object.assign({}, higher, optional))
    ];
    function splitDates() { return [f("开始时间", "startTime", "period_start", "date"),
      f("结束时间", "endTime", "period_end_picker-fe-1601-customization", "currentDate", { displaySelector: '[id="period_end_input-fe-1601-customization"]' })]; }
    var 示例资料 = [f("单位名称", "company", "company_name"), f("单位性质", "companyNature", "company_nature", "select"),
      f("职位名称", "position", "job_name"), f("工作性质", "iguopinWorkType", "employee_type", "select")].concat(splitDates(), [
      f("工作内容", "iguopinContent", "introduction"), f("所属行业", "industry", "industry-fe-1601-customization", "popup", optional),
      f("单位规模", "companySize", "company_scale", "select", optional), f("工作地区", "示例资料Location", "location-fe-1601-customization", "popup", { popupKind: "region" }),
      f("部门", "department", "department", "text", optional), f("汇报对象", "manager", "manager", "text", optional),
      f("下属人数", "subordinateCount", "teams_num", "text", optional),
      f("薪资保密", "salaryConfidential", "monthly_salary_none", "checkbox", optional),
      f("税前月薪（千元）", "iguopinSalaryK", "monthly_salary"),
      f("海外工作", "iguopinOverseas", "has_overseas", "radio", optional)]);
    return [
      iguopinStep("job_expectation", "示例资料", "jobIntention", [
        f("期望职位", "iguopinPosition", "position-fe-1601-customization", "popup"),
        f("工作地区", "iguopinLocation", "location-fe-1601-customization", "popup", { popupKind: "region" }),
        f("期望行业", "iguopinIndustry", "industry-fe-1601-customization", "popup", { multi: true }),
        f("薪资下限", "iguopinSalaryMin", "salary_requirement_min", "select"), f("薪资上限", "iguopinSalaryMax", "salary_requirement_max", "select")
      ], false, { dataTransform: iguopinJob }),
      iguopinStep("示例资料_experience", "工作/示例资料", ["示例资料Experience", "示例资料Experience"], 示例资料, true, { dataTransform: iguopinWork }),
      iguopinStep("示例资料", "项目经历", "示例资料Experience", [f("项目名称", "name", "示例资料_name")].concat(splitDates(), [
        f("项目角色", "role", "role"), f("所在单位", "company", "company_name", "text", optional),
        f("团队规模", "teamSize", "teams_scale", "select", optional), f("项目介绍", "details", "introduction"),
        f("项目职责", "contributions", "duty"), f("项目成果", "result", "achievement")]), true,
        { dataTransform: function (row) { var r = iguopinEnrich(row); r.name = iguopinFirst(r, ["name", "示例资料Name"]); r.role = iguopinFirst(r, ["role", "position"]); return r; } }),
      iguopinStep("示例资料", "语言能力", "示例资料Skills", [f("语种", "name", "category", "select"),
        f("读写能力", "readingWriting", "writing_ability", "select"), f("听说能力", "speakingListening", "speaking_ability", "select"),
        f("成绩", "score", "score", "text", optional)], true),
      iguopinStep("示例资料", "示例资料", "示例资料Experience", [f("培训时间", "iguopinPeriod", "period", "range"),
        f("培训机构", "organization", "school_name"), f("培训课程", "name", "course"), f("培训内容", "description", "description")], true, { dataTransform: iguopinEnrich }),
      iguopinStep("award", "荣誉奖励", "示例资料", [f("奖励名称", "awardName", "name"), f("获得时间", "awardTime", "issued_on", "date"),
        f("奖励级别", "awardLevel", "level", "select"), f("获奖等级", "awardGrade", "grade", "select", optional),
        f("颁发机构", "awardIssuer", "authority", "text", optional), f("描述", "awardDescription", "description", "text", optional)], true),
      iguopinStep("示例资料", "家庭成员", "示例资料Members", [f("关系", "relationship", "relation", "select"), f("姓名", "name", "name"),
        f("出生日期", "birthDate", "birthdate", "date"), f("政治面貌", "politicalStatus", "political", "select"),
        f("工作单位/就读院校", "company", "company_name"), f("职务", "position", "position")], true),
      iguopinStep("campus_activity", "实践活动", "campusActivities", [f("活动名称", "activityName", "title")].concat(splitDates(), [
        f("担任职务", "role", "duty"), f("活动描述", "description", "description")]), true),
      iguopinStep("campus_duty", "校内职务", "campusLeadership", [f("职务名称", "title", "title"), f("起止时间", "iguopinPeriod", "period", "range"),
        f("所在学校", "school", "school-fe-1601-customization", "remote", { proxyId: "school", proxyName: "school_cn" }),
        f("职责和业绩", "description", "achievement")], true, { dataTransform: iguopinEnrich }),
      iguopinStep("assessment", "自我评价", "示例资料Introduction", [f("自我评价", "示例资料Introduction", "assessment"),
        f("关键词", "tags", "tags", "tags", { optional: true, controlSelector: 'input[placeholder="请输入关键词"]' })], false),
      iguopinStep("示例资料", "示例资料", "示例资料", 示例资料, true, { dataTransform: iguopinEducation })
    ];
  }

  var entries = [
    {
      id: "iguopin-resume-v1", brandDomain: "", hostname: "c.iguopin.com",
      urlPattern: /^https?:\/\/c\.iguopin\.com\/resume\/?(?:[?#]|$)/i,
      pageGuardSelector: ".resume-left-content .item-section",
      config: {
        name: "国聘网个人简历", version: 1, type: "structured", privateSpecialSite: true,
        preferBuiltIn: true, blockManualCandidates: true,
        urlPattern: /^https?:\/\/c\.iguopin\.com\/resume\/?(?:[?#]|$)/i,
        selectors: {
          container: { class: ".edit-section form.ant-form" }, section: ".item-section",
          title: { class: ".section-title h2" }, labels: { class: ".ant-form-item-label label" },
          select: { class: ".ant-select" }, datePicker: { class: ".ant-picker" },
          buttons: { add: { class: ".section-title button" }, save: { class: ".edit-section .submit-btn" } }
        }
      },
      示例资料flow: {
        id: "iguopin-resume-v1", version: 1, name: "国聘网个人简历", enabled: true,
        privateSpecialSite: true, hostname: "c.iguopin.com",
        urlPattern: /^https?:\/\/c\.iguopin\.com\/resume\/?(?:[?#]|$)/i,
        pageGuardSelector: ".resume-left-content .item-section",
        continueOnError: false, autoContinueAcrossPages: false,
        notices: ["国聘：账号绑定手机、邮箱及照片/附件由本人维护。", "资格证书包含证书分类和成绩档位，请在网站手动选择。", "专业分类无候选、资料缺失或保存失败时保留编辑器，补齐后可重新填写。"],
        steps: iguopinFields()
      }
    },

    {
      id: "chinahr-bank-recruitment", brandDomain: "chinahr.com", hostname: "applyjob.chinahr.com",
      urlPattern: /^https?:\/\/applyjob\.chinahr\.com\/apply\/form\/job/i,
      brandFallbackGuardSelectors: ["#6a82a4e4f6bf3d0ac213d654", ".aply-form"],
      config: {
        name: "中国银行招聘申请表", type: "structured", privateSpecialSite: true,
        preferBuiltIn: true, blockManualCandidates: true,
        urlPattern: /^https?:\/\/applyjob\.chinahr\.com\/apply\/form\/job/i,
        selectors: {
          container: { class: ".aply-form" }, section: ".aply-form", row: ".aply-field-li",
          title: { class: ".aply-form-tit" }, labels: { class: ".aply-field-label" },
          select: { class: ".ant-cascader-picker, .ant-select, input[placeholder='请选择']" },
          datePicker: { class: ".ant-calendar-picker input" },
          buttons: { add: { class: ".aply-form-empty, .aply-form-opt.add" }, edit: { class: ".aply-group-edit:not(.del)" }, save: { class: ".aply-form-btn.act" } },
        },
        allowAutoSaveExperienceCards: true,
        experience: {
          container: { containerSelector: ".aply-form" },
          card: { cardSelector: ".aply-group" },
          add: {
            addButtonSelector: ".aply-form-empty, .aply-form-top .aply-form-opt.add",
            addButtonText: ["添加示例资料", "添加实习示例资料", "添加"],
          },
          save: {
            requiresSaveBeforeNext: true,
            allowAutoSave: true,
            saveButtonSelector: ".aply-form-btn.act",
            saveButtonText: ["保存"],
            saveTimeoutMs: 800,
          },
        },
        _capabilityPatch: {
          fields: [
            {
              category: "示例资料",
              fieldKey: "degree",
              labels: ["学位"],
              adapter: "ant-cascader",
              forceAdapter: true,
              valueAliases: {
                "管理学硕士": "硕士",
                "工学硕士": "硕士",
                "管理学学士": "学士",
                "工学学士": "学士",
                "硕士研究生": "硕士",
                "本科": "学士",
                "无学位": "无",
              },
              fallback: "firstFilteredOption",
            },
            {
              category: "示例资料Experience",
              fieldKey: "示例资料Type",
              labels: ["工作类别"],
              adapter: "ant-cascader",
              forceAdapter: true,
              valueAliases: {
                "实习生": "实习（未毕业在校生兼职或实习）",
                "实习": "实习（未毕业在校生兼职或实习）",
              },
              defaultValue: "实习（未毕业在校生兼职或实习）",
              useDefaultValue: true,
            },
          ],
        },
      },
      示例资料flow: {
        id: "chinahr-bank-recruitment",
        name: "中国银行招聘申请表",
        enabled: true,
        privateSpecialSite: true,
        hostname: "applyjob.chinahr.com",
        urlPattern: /^https?:\/\/applyjob\.chinahr\.com\/apply\/form\/job/i,
        continueOnError: true,
        genericAutofill: true,
        // 不在站点配置里另起一套栏目编排；沿用通用填写/多经历引擎。
        // 这里只声明中国银行需要跳过的栏目和记录。
        skipRules: {
          示例资料Levels: ["高中", "中专"],
          categories: ["示例资料Experience", "fullTimeWorkExperience", "itSkills", "doubleDegreeMinor", "minor"]
        },
        steps: [{ name: "中国银行简历", category: "示例资料Info" }],
        genericFieldSequence: [
          { label: "姓名", field: "name", type: "text", labelExact: true, preserveExisting: true },
          { label: "性别", field: "gender", type: "elementSelect", labelExact: true },
          { label: "出生日期", field: "birthDate", type: "elementDate", labelExact: true, preserveExisting: true },
          { label: "证件号码", field: "idNumber", type: "chinahrIdNumber", labelExact: true, preserveExisting: true },
          { label: "户口所在地", field: "hukouLocation", type: "text", labelExact: true, optional: true },
          { label: "所在城市", field: "currentAddress", type: "text", labelExact: true, optional: true },
          { label: "紧急联系电话", field: "emergencyPhone", type: "text", labelExact: true, optional: true },
          { label: "个人评价", field: "示例资料Introduction", type: "text", labelExact: true, optional: true },
        ],
        示例资料InfoFieldSequence: [
          { label: "所获专业技术资格证书", field: "professionalCertificates", type: "text", labelExact: true, optional: true },
          { label: "项目经验", field: "示例资料ExperienceSummary", type: "text", labelExact: true, optional: true },
          { label: "研究成果", field: "researchResults", type: "text", labelExact: true, optional: true },
          { label: "示例资料", field: "示例资料Summary", type: "text", labelExact: true, optional: true },
        ],
      },
    },
    {
      id: "spdb-recruitment", brandDomain: "spdb.com.cn", hostname: "job.spdb.com.cn",
      urlPattern: /^https?:\/\/job\.spdb\.com\.cn\//i,
      pageGuardSelector: ".fromcontainer",
      config: {
        name: "浦发银行招聘简历", type: "structured", privateSpecialSite: true,
        preferBuiltIn: true, blockManualCandidates: true,
        urlPattern: /^https?:\/\/job\.spdb\.com\.cn\//i,
        selectors: {
          container: { class: ".fromcontainer" },
          title: { class: ".titlename, .titleblock" },
          labels: { class: "lable, label" },
          select: { class: "select.sel_min, select.sel_menu2" },
          datePicker: { class: "input.Wdate" },
          address: { class: ".provinceSchool, input.schoolSelect" },
          buttons: { add: { class: ".titletoolbar a" }, edit: { class: ".formsavebtn" } },
        },
        experience: {
          container: { containerSelector: ".fromcontainer" },
          card: { cardSelector: ".infoline" },
          add: { addButtonSelector: ".titletoolbar a[onclick*='plusonefrom']", addTimeoutMs: 4000 },
          save: { requiresSaveBeforeNext: true, allowAutoSave: false },
        },
      },
      示例资料flow: {
        id: "spdb-recruitment", name: "浦发银行招聘简历", enabled: true,
        privateSpecialSite: true, hostname: "job.spdb.com.cn",
        urlPattern: /^https?:\/\/job\.spdb\.com\.cn\//i,
        continueOnError: false,
        currentPageOnly: true,
        pageSequence: [
          { name: "示例资料", urlPattern: /\/mySchoolBase(?:[?#]|$)/i, url: "/mySchoolBase", nextSelector: ".formstepbtn[_href='mySchoolLink']", nextDelayMs: 1200 },
          { name: "联系地址", urlPattern: /\/mySchoolLink(?:[?#]|$)/i, url: "/mySchoolLink", nextSelector: ".titletoolbar a[_href='mySchoolEdu']", nextDelayMs: 1200 },
          { name: "教育情况", urlPattern: /\/mySchoolEdu(?:[?#]|$)/i, url: "/mySchoolEdu" },
        ],
        steps: [
          spdbFormStep("示例资料", "示例资料Info", { dataTransform: enrichSpdbBasic,
            pageUrlPattern: /\/mySchoolBase(?:[?#]|$)/i,
            readySelector: "#cgPersonProfileAction, .fromcontainer:has(.frombtnblock)",
            scopeSelector: "#cgPersonProfileAction, .fromcontainer:has(.frombtnblock)",
            skipClickWhenReady: true,
            saveSelector: ".frombtnblock .formsavebtn",
            fieldSequence: [
              { label: "政治面貌", field: "politicalStatus", type: "select", optional: true },
              { label: "入党/团日期", field: "partyJoinDate", type: "text", optional: true },
              { label: "身高(cm)", field: "height", type: "text", optional: true },
              { label: "体重(kg)", field: "weight", type: "text", optional: true },
              { label: "健康状况", field: "healthStatus", type: "select", optional: true },
              { label: "婚姻状况", field: "maritalStatus", type: "select", optional: true },
              { label: "生源所在地", field: "birthOrigin", type: "spdbCityPicker", optional: true },
              { label: "户籍所在地", field: "hukouLocation", type: "spdbCityPicker", optional: true },
              { label: "期望税前年薪(万元)", field: "expectedSalary", type: "text", optional: true },
              { label: "在校期间及最高学历毕业后是否有社保缴纳记录", field: "isSocialSecurity", type: "select", optional: true },
              { label: "是否为专升本", field: "isRise", type: "select", optional: true },
              { label: "是否接受岗位调剂", field: "acceptsPositionAdjustment", type: "select", optional: true },
              { label: "是否曾为我行(集团)正式员工(并已离职)", field: "previousBankEmployee", type: "select", optional: true },
              { label: "联系电话(家庭)", field: "homePhone", type: "text", optional: true },
              { label: "联系电话(学校)", field: "schoolPhone", type: "text", optional: true },
            ],
          }),
          spdbFormStep("联系地址", "示例资料Info", { pageUrlPattern: /\/mySchoolLink(?:[?#]|$)/i, dataTransform: enrichSpdbBasic, preferNavigationTrigger: false, triggerSelector: ".infoline:has(input[name='addType'][value='家庭住址']) .toedit", triggerText: ["编辑"], triggerCandidateSelector: ".toedit", readySelector: ".infoline:has(input[name='addType'][value='家庭住址']) form.formData", scopeSelector: ".infoline:has(input[name='addType'][value='家庭住址']) form.formData", skipClickWhenReady: true, saveSelector: ".formsavebtn", fieldSequence: [
            { label: "家庭住址", field: "spdbFamilyAddress", type: "spdbFamilyAddress" },
          ] }),
          spdbFormStep("教育情况", "示例资料", {
            pageUrlPattern: /\/mySchoolEdu(?:[?#]|$)/i,
            forceNativeEditClick: true,
            示例资料ForCategoryData: true,
            sectionRootSelector: ".fromcontainer.formblocksolid",
            rowScopeSelector: ".infoline, .示例资料formtemplate",
            existingCardSelector: ".infoline",
            preferDirectExistingCards: true,
            existingEditActionSelector: ".toedit, [class*='toedit']",
            existingRecordSelector: ".infoline",
            示例资料ReadySelector: ".formblock.formedit",
            示例资料AddSelector: ".titletoolbar a[onclick*='plusonefrom']",
            示例资料AddRootSelector: ".fromcontainer.formblocksolid",
            示例资料AddNativeClick: true,
            示例资料AddOnlyWhenMissing: true,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            useRepeatRowScopeByIndex: true,
            saveEachRepeatStep: true,
            rowTransform: function (row) {
              var result = Object.assign({}, row || {});
              result.degree = normalizeSpdbDegree(result.degree || result.degreeType || result.level || result.示例资料Level);
              return result;
            },
            rowFieldSequence: [
              { label: "开始日期", field: "startTime", type: "date", selector: "input[name='startDt']" },
              { label: "结束日期", field: "endTime", type: "date", selector: "input[name='endDt']" },
              { label: "教育类别", field: "level", type: "select", when: function (row, category, step) { return !Number.isInteger(step.updateExistingIndex); } },
              { label: "学位", field: "degree", type: "select", defaultValue: "无学位", optional: true, valueTransform: function (value) { return normalizeSpdbDegree(value); }, matchMode: "exactOrContains" },
              { label: "学习形式", field: "示例资料Type", type: "select", defaultValue: "全日制", optional: true },
              { label: "学制", field: "studyPeriod", type: "select", optional: true },
              { label: "学校", field: "school", type: "spdbSchoolPicker" },
              { label: "专业", field: "major", type: "text", optional: true },
              { label: "是否为学生干部", field: "isStudentLeader", type: "select", optional: true },
              { label: "平均绩点", field: "gpa", type: "text", optional: true },
              { label: "班级排名", field: "classRank", type: "select", optional: true },
            ],
          }),
        ],
      },
    },
    {
      id: "citicbank-recruitment", brandDomain: "citicbank.com", hostname: "job.citicbank.com",
      urlPattern: /^https?:\/\/job\.citicbank\.com\//i,
      delegateUrlPattern: /^https?:\/\/job\.citicbank\.com\/CustStyle\/zpmhys\/addSchoolResume4\.html/i,
      pageGuardSelector: "#myFram, #jbxxform",
      config: { name: "中信银行招聘简历", type: "structured", privateSpecialSite: true, preferBuiltIn: true, blockManualCandidates: true, urlPattern: /^https?:\/\/job\.citicbank\.com\//i,
        selectors: { container: { class: "form[id$='form']" }, title: { class: ".subtitle_title, .needClass > tr > td > div" }, labels: { class: ".needClass > tr > td > div" }, select: { class: "select, .selectpicker" }, datePicker: { class: ".bs-datetime, input[placeholder*='yyyy-mm-dd']" }, buttons: { add: { class: ".addFontClass" }, edit: { class: ".saveBtnClass" } } }
      },
      示例资料flow: {
        id: "citicbank-recruitment", name: "中信银行招聘简历", enabled: true, delegateToChildFrame: true, privateSpecialSite: true, hostname: "job.citicbank.com", urlPattern: /^https?:\/\/job\.citicbank\.com\//i, pageGuardSelector: "#jbxxform", continueOnError: true,
        notices: ["中信银行：受控字段未匹配时会记录为待人工复核，但不会中断后续模块；不会猜填个人信息。"],
        steps: [
          citicFormStep("#jbxxform", "个人示例资料", "示例资料Info", { triggerSelector: "#11_a", dataTransform: enrichCiticBasicInfo, fieldSequence: [
            { label: "姓名", field: "name", type: "citicText", selector: "#a0101" }, { label: "国籍/地区", field: "country", type: "citicSelect", selector: "#nationality" }, { label: "身高", field: "height", type: "citicText", selector: "#a0213" }, { label: "移动电话地区", field: "citicPhoneRegion", type: "citicSelect", selector: "#a0188cate" }, { label: "移动电话", field: "phone", type: "citicText", selector: "#a0118" }, { label: "性别", field: "gender", type: "citicSelect", selector: "select[name='a0102']" }, { label: "生源地", field: "citicBirthOriginPath", type: "citicLinkedSelect", selectors: ["#grjbxx_origin_0_01", "#grjbxx_origin_0_02"] }, { label: "出生日期", field: "birthDate", type: "citicDate", selector: "#a0103" }, { label: "体重", field: "weight", type: "citicText", selector: "#weight" }, { label: "电子邮箱", field: "email", type: "citicText", selector: "#email" }, { label: "证件类型", field: "citicIdType", type: "citicSelect", selector: "#yxsfzjlx" }, { label: "证件号码", field: "idNumber", type: "citicText", selector: "#a5015" }, { label: "户口所在地", field: "citicHukouPath", type: "citicLinkedSelect", selectors: ["#grjbxx_a0111_0_01", "#grjbxx_a0111_0_02"] }, { label: "健康状况", field: "citicHealthStatus", type: "citicSelect", selector: "#healthStatus" }, { label: "紧急联系人姓名", field: "emergencyContactName", type: "citicText", selector: "#urgentConcatName" }, { label: "民族", field: "ethnicity", type: "citicSelect", selector: "#nation" }, { label: "籍贯", field: "citicNativePlacePath", type: "citicLinkedSelect", selectors: ["#grjbxx_originplace_0_01", "#grjbxx_originplace_0_02", "#grjbxx_originplace_0_03"], forceNative: true, bootstrapPickerCommit: true, areaFuzzy: true, waitAfterEachMs: 500, optionTimeoutMs: 5000 }, { label: "婚姻状况", field: "citicMaritalStatus", type: "citicSelect", selector: "#a0105" }, { label: "紧急联系人手机号", field: "emergencyPhone", type: "citicText", selector: "#urgentPhone" }, { label: "政治面貌", field: "politicalStatus", type: "citicSelect", selector: "#a0210" }, { label: "目前所在地", field: "citicCurrentAddressPath", type: "citicLinkedSelect", selectors: ["#grjbxx_a0112_0_01", "#grjbxx_a0112_0_02"] }, { label: "生育状况", field: "fertilityStatus", type: "citicSelect", selector: "#fertilityStatus" }, { label: "紧急联系人关系", field: "emergencyContactRelation", type: "citicText", selector: "#urgentRelation" }, { label: "爱好", field: "hobbies", type: "citicText", selector: "#a0207", optional: true }, { label: "特长", field: "specialty", type: "citicText", selector: "#specialty", optional: true }, { label: "获取信息渠道", field: "recruitmentChannel", type: "citicSelect", selector: "#jobInfoSource", defaultFirst: true, forceNative: true, bootstrapPickerCommit: true }
          ] }),
          citicFormStep("#jyjlform", "示例资料", "示例资料", { triggerSelector: "#14_a", 示例资料ForCategoryData: true, rowScopeSelector: "[way-示例资料-wrapper] > div[way-scope]", rowAddSelector: "#jyjlAddId", rowAddNativeClick: true, 示例资料AddSelector: "#jyjlAddId", 示例资料AddNativeClick: true, useRepeatRowScopeByIndex: true, prepareRepeatRowsBeforeFirstFill: true, 示例资料AddOnlyWhenMissing: true, rowAddAfterEach: false, rowsTransform: prepareCiticEducationRows, rowTransform: enrichCiticEducationRow, rowFieldSequence: [
            // 首条学历控件只提供“高中及以下/中专”；后续新增记录才会展示本科、硕士、博士。
            { label: "学历", field: "citicEducationLevel", type: "citicSelect", selector: "select[name='xl']", waitAfterMs: 450 },
            { label: "学校名称", field: "school", type: "citicText", selector: "input[name='byyxqt']", when: function (row) { return citicEducationRank(row) <= 1; } },
            { label: "学校", field: "school", type: "citicSchoolSelect", selector: "select[name='byyx']", optionLoadTimeoutMs: 3500, when: function (row) { return citicEducationRank(row) > 1; } },
            { label: "开始时间", field: "startTime", type: "citicDate", selector: "input[name='rxsj']" },
            { label: "结束时间", field: "endTime", type: "citicDate", selector: "input[name='bysj']" },
            { label: "是否最高学历", field: "citicHighest", type: "citicSelect", selector: "select[name^='highested']" },
            { label: "所在院系", field: "department", type: "citicText", selector: "input[name='department']", optional: true, when: function (row) { return citicEducationRank(row) > 1; } },
            { label: "专业", field: "major", type: "citicText", selector: "input[name='sxzy']", optional: true, when: function (row) { return citicEducationRank(row) > 1; } },
            { label: "专业类别", field: "citicMajorCategory", type: "citicSelect", selector: "select[name='tradeCategory1']", optional: true, when: function (row) { return citicEducationRank(row) > 1; } },
            { label: "学位类型", field: "citicDegreeGroup", type: "citicSelect", selector: "select[name='xw1']", waitAfterMs: 400, optional: true, when: function (row) { return citicEducationRank(row) > 1 && !!row.citicDegreeGroup; } },
            { label: "学位", field: "citicDegreeName", type: "citicSelect", selector: "select[name='xw2']", optional: true, when: function (row) { return citicEducationRank(row) > 1 && !!row.citicDegreeName; } },
            { label: "是否取得第二学位", field: "citicSecondDegree", type: "citicSelect", selector: "select[name^='secondDegree']", optional: true, when: function (row) { return citicEducationRank(row) > 1 && !!row.citicSecondDegree; } },
            { label: "学习形式", field: "示例资料Type", type: "citicSelect", selector: "select[name='xxxs']", optional: true },
            { label: "学习方式", field: "studyMode", type: "citicSelect", selector: "select[name='learnMode']", optional: true },
            { label: "毕业方式", field: "citicGraduationMode", type: "citicSelect", selector: "select[name='graduteMode']", optional: true }
          ] }),
          citicFormStep("#sxjlform", "示例资料", "示例资料Experience", { triggerSelector: "#123_a", activateTriggerBeforeRepeatAction: true, 示例资料ForCategoryData: true, rowScopeSelector: "[way-示例资料-wrapper] > div[way-scope]", rowAddSelector: "#sxjlAddId", rowAddNativeClick: true, updateExistingWhenPresent: true, existingCardSelector: "[way-示例资料-wrapper] > div[way-scope]", forceAddFirstRepeatWhenNoExisting: true, rowAddAfterEach: false, rowTransform: enrichCiticInternRow, rowFieldSequence: [
            { label: "开始时间", field: "startTime", type: "citicDate", selector: "input[name='rzsj']" }, { label: "结束时间", field: "endTime", type: "citicDate", selector: "input[name='lzsj']" }, { label: "单位名称", field: "company", type: "citicText", selector: "input[name='gzdw']" }, { label: "所在部门", field: "department", type: "citicText", selector: "input[name='rzbm']", optional: true }, { label: "岗位/职务", field: "position", type: "citicText", selector: "input[name='rzgw']", optional: true }, { label: "工作描述", field: "citicDescription", type: "citicText", selector: "textarea[name='gzms']", optional: true }
          ] }),
          citicFormStep("#zxjlform", "在校经历", ["campusLeadership", "campusActivities"], { triggerSelector: "#123_a_zxjl", activateTriggerBeforeRepeatAction: true, 示例资料ForCategoryData: true, rowScopeSelector: "[way-示例资料-wrapper] > div[way-scope]", rowAddSelector: "#zxjlAddId", rowAddNativeClick: true, updateExistingWhenPresent: true, existingCardSelector: "[way-示例资料-wrapper] > div[way-scope]", forceAddFirstRepeatWhenNoExisting: true, rowAddAfterEach: false, rowTransform: enrichCiticCampusRow, rowFieldSequence: [
            { label: "开始时间", field: "startTime", type: "citicDate", selector: "input[name='start_time']", optional: true }, { label: "结束时间", field: "endTime", type: "citicCurrentOrDate", selector: "input[name='end_tme']", currentSelector: "input[value='至今']" }, { label: "学生会/社团名称", field: "citicOrganization", type: "citicText", selector: "input[name='dept_name']" }, { label: "岗位/职务", field: "citicRole", type: "citicText", selector: "input[name='jobs']", optional: true }, { label: "工作描述", field: "citicDescription", type: "citicText", selector: "textarea[name='job_description']", optional: true }
          ] }),
          citicFormStep("#gzjlform", "示例资料", "示例资料Experience", { triggerSelector: "#19_a", activateTriggerBeforeRepeatAction: true, 示例资料ForCategoryData: true, rowScopeSelector: "[way-示例资料-wrapper] > div[way-scope]", rowAddSelector: "#gzjlAddId", rowAddNativeClick: true, 示例资料AddSelector: "#gzjlAddId", 示例资料AddRootSelector: "#gzjlform", 示例资料AddPrerequisite: { type: "citicSelect", label: "是否初次就业", field: "citicFirstEmployment", selector: "#getJob", forceNative: true, bootstrapPickerCommit: true, waitAfterMs: 300 }, updateExistingWhenPresent: true, existingCardSelector: "[way-示例资料-wrapper] > div[way-scope]", forceAddFirstRepeatWhenNoExisting: true, rowAddAfterEach: false, rowTransform: enrichCiticWorkRow, rowFieldSequence: [
            { label: "开始时间", field: "startTime", type: "citicDate", selector: "input[name='rzsj']" }, { label: "结束时间", field: "endTime", type: "citicDate", selector: "input[name='lzsj']" }, { label: "工作单位", field: "company", type: "citicText", selector: "input[name='gzdw']" }, { label: "用工形式", field: "citicEmploymentType", type: "citicSelect", selector: "select[name='ygxs']", optional: true }, { label: "任职部门", field: "department", type: "citicText", selector: "input[name='rzbm']" }, { label: "岗位", field: "position", type: "citicText", selector: "input[name='rzgw']" }, { label: "职级", field: "citicJobLevel", type: "citicText", selector: "input[name='zj']", optional: true }, { label: "职务", field: "citicJobTitle", type: "citicText", selector: "input[name='zw']" }, { label: "离职原因", field: "citicLeaveReason", type: "citicText", selector: "input[name='lzyy']", optional: true }, { label: "工作描述", field: "citicDescription", type: "citicText", selector: "textarea[name='gzms']", optional: true }
          ] }),
          citicFormStep("#xmjlform", "项目经历", "示例资料Experience", { triggerSelector: "#123_a_xmjl", activateTriggerBeforeRepeatAction: true, 示例资料ForCategoryData: true, rowScopeSelector: "[way-示例资料-wrapper] > div[way-scope]", rowAddSelector: "#xmjlAddId", rowAddNativeClick: true, updateExistingWhenPresent: true, existingCardSelector: "[way-示例资料-wrapper] > div[way-scope]", forceAddFirstRepeatWhenNoExisting: true, rowAddAfterEach: false, rowTransform: enrichCiticProjectRow, rowFieldSequence: [
            { label: "开始时间", field: "startTime", type: "citicDate", selector: "input[name='startDate']", optional: true }, { label: "结束时间", field: "endTime", type: "citicCurrentOrDate", selector: "input[name='endDate']", currentSelector: "input[value='至今']" }, { label: "项目名称", field: "name", type: "citicText", selector: "input[name='projName']" }, { label: "项目描述", field: "citicProjectDescription", type: "citicText", selector: "textarea[name='contents']", optional: true }, { label: "项目职责", field: "citicProjectResponsibilities", type: "citicText", selector: "textarea[name='resp']", optional: true }, { label: "项目成果", field: "citicProjectResult", type: "citicText", selector: "textarea[name='示例资料Result']", optional: true }
          ] }),
          citicFormStep("#yynlform", "语言能力", "示例资料Skills", { triggerSelector: "#43_a", 示例资料ForCategoryData: true, rowScopeSelector: "[way-示例资料-wrapper] > div[way-scope]", rowAddSelector: "#yynlAddId", rowAddNativeClick: true, 示例资料AddSelector: "#yynlAddId", 示例资料AddRootSelector: "#yynlform", useRepeatRowScopeByIndex: true, rowAddAfterEach: false, rowTransform: enrichCiticLanguageRow, rowFieldSequence: [
            { label: "语种", field: "citicLanguage", type: "citicSelect", selector: "select[name='示例资料s']", waitAfterMs: 350 }, { label: "考试种类", field: "citicTestType", type: "citicSelect", selector: "select[name='test_type']", waitAfterMs: 260 }, { label: "成绩", field: "citicScore", type: "citicText", selector: "input[name='results']", optional: true }, { label: "证书颁发机构", field: "citicIssuer", type: "citicText", selector: "input[name='issuing_authority']", optional: true }
          ] }),
          citicFormStep("#zyzgrzform", "职业资格认证", "示例资料", { triggerSelector: "#100302_a", 示例资料ForCategoryData: true, rowScopeSelector: "[way-示例资料-wrapper] > div[way-scope]", rowAddSelector: "#zyzgrzAddId", rowAddNativeClick: true, 示例资料AddSelector: "#zyzgrzAddId", 示例资料AddRootSelector: "#zyzgrzform", useRepeatRowScopeByIndex: true, forceAddFirstRepeatWhenNoExisting: true, rowAddAfterEach: false, rowTransform: enrichCiticCertificateRow, rowFieldSequence: [
            { label: "职业资格证书", field: "citicCertificateType", type: "citicSelectWithOther", selector: "select[name='zyzgzs']", 示例资料Selector: "input[name^='QTZYZGZS']", 示例资料OptionText: "其他" }, { label: "获得时间", field: "obtainedTime", type: "citicDate", selector: "input[name='getTime']", optional: true }, { label: "证书颁发机构", field: "citicCertificateIssuer", type: "citicText", selector: "input[name='zsbfjg']", optional: true }, { label: "成绩", field: "citicCertificateScore", type: "citicText", selector: "input[name='cj']", optional: true }, { label: "详细描述", field: "citicCertificateDescription", type: "citicText", selector: "textarea[name='xxms']", optional: true }
          ] }),
          citicFormStep("#pxjlform", "示例资料", "示例资料Experience", { triggerSelector: "#15_a", 示例资料ForCategoryData: true, rowScopeSelector: "[way-示例资料-wrapper] > div[way-scope]", rowAddSelector: "#pxjlAddId", rowAddNativeClick: true, updateExistingWhenPresent: true, existingCardSelector: "[way-示例资料-wrapper] > div[way-scope]", forceAddFirstRepeatWhenNoExisting: true, rowAddAfterEach: false, rowTransform: enrichCiticTrainingRow, rowFieldSequence: [
            { label: "培训名称", field: "name", type: "citicText", selector: "input[name='示例资料_name']" }, { label: "开始时间", field: "startTime", type: "citicDate", selector: "input[name='startTime']", optional: true }, { label: "结束时间", field: "endTime", type: "citicDate", selector: "input[name='endTime']", optional: true }, { label: "培训机构", field: "organization", type: "citicText", selector: "input[name='pxjg']", optional: true }, { label: "详细描述", field: "citicTrainingDescription", type: "citicText", selector: "textarea[name='xxms']", optional: true }
          ] }),
          citicFormStep("#jcqkform", "示例资料", "示例资料", { triggerSelector: "#100204_a", activateTriggerBeforeRepeatAction: true, 示例资料ForCategoryData: true, rowScopeSelector: "[way-示例资料-wrapper] > div[way-scope]", rowAddSelector: "#jcqkAddId", rowAddNativeClick: true, 示例资料AddSelector: "#jcqkAddId", 示例资料AddRootSelector: "#jcqkform", 示例资料AddNativeClick: true, 示例资料AddWaitForRowCount: true, useRepeatRowScopeByIndex: true, updateExistingWhenPresent: true, existingCardSelector: "[way-示例资料-wrapper] > div[way-scope]", forceAddFirstRepeatWhenNoExisting: true, rowAddAfterEach: false, rowTransform: enrichCiticAwardRow, rowFieldSequence: [
            { label: "奖惩类别", field: "citicAwardCategory", type: "citicSelect", selector: "select[way-data='jcqk.a85006']", forceNative: true, bootstrapPickerCommit: true }, { label: "奖惩级别", field: "citicAwardLevel", type: "citicSelect", selector: "select[way-data='jcqk.a813007']", forceNative: true, bootstrapPickerCommit: true }, { label: "奖惩名称", field: "awardName", type: "citicText", selector: "input[way-data='jcqk.a85005']" }, { label: "奖惩时间", field: "awardTime", type: "citicDate", selector: "input[way-data='jcqk.a85007']", optional: true }, { label: "奖惩单位", field: "awardIssuer", type: "citicText", selector: "input[way-data='jcqk.a813010']", optional: true }, { label: "奖惩原因", field: "citicAwardReason", type: "citicText", selector: "textarea[way-data='jcqk.a813014']", optional: true }
          ] }),
          citicFormStep("#jtgxform", "家庭关系", "示例资料Members", { triggerSelector: "#21_a", activateTriggerBeforeRepeatAction: true, 示例资料ForCategoryData: true, rowScopeSelector: "[way-示例资料-wrapper] > div[way-scope]", rowAddSelector: "#jtgxAddId", rowAddNativeClick: true, 示例资料AddSelector: "#jtgxAddId", 示例资料AddRootSelector: "#jtgxform", 示例资料AddNativeClick: true, 示例资料AddWaitForRowCount: true, useRepeatRowScopeByIndex: true, forceAddFirstRepeatWhenNoExisting: true, rowAddAfterEach: false, rowTransform: enrichCiticFamilyRow, rowFieldSequence: [
            { label: "称谓", field: "relationship", type: "citicSelect", selector: "select[way-data='jtgx.ybrgx']", forceNative: true, bootstrapPickerCommit: true }, { label: "姓名", field: "name", type: "citicText", selector: "input[way-data='jtgx.cyxm']" }, { label: "联系电话", field: "phone", type: "citicText", selector: "input[way-data='jtgx.phoneNumber']" }, { label: "有无国（境）外身份", field: "citicForeignIdentity", type: "citicSelect", selector: "select[way-data='jtgx.ywjwsf']", forceNative: true, bootstrapPickerCommit: true }, { label: "工作单位", field: "示例资料place", type: "citicText", selector: "input[way-data='jtgx.gzdw']" }, { label: "部门", field: "department", type: "citicText", selector: "input[way-data='jtgx.gzbm']", optional: true }, { label: "岗位/职务", field: "occupation", type: "citicText", selector: "input[way-data='jtgx.gzzw']" }
          ] }),
          citicFormStep("#zwpjform", "自我评价", "示例资料Introduction", { triggerSelector: "#12_a", dataTransform: enrichCiticSelfIntroduction, fieldSequence: [
            { label: "自我评价", field: "citicSelfIntroduction", type: "citicText", selector: "#a0209" }
          ] })
        ]
      }
    },
    {
      id: "sf-express-campus-resume",
      brandDomain: "sf-express.com",
      hostname: "campus.sf-express.com",
      urlPattern: /^https?:\/\/campus\.sf-express\.com\/#\/personalCenter/i,
      pageGuardSelector: ".tab-block.re-block, .resume-form",
      config: {
        name: "campus.sf-express.com/personalCenter",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/campus\.sf-express\.com\/#\/personalCenter/i,
        selectors: {
          container: { class: ".tab-block.re-block" },
          section: ".tab-block.re-block",
          title: { class: ".tag-title" },
          labels: { class: ".el-form-item__label" },
          radio: { class: ".el-radio, .el-radio-group, input[type='radio']" },
          checkbox: { class: ".el-checkbox, input[type='checkbox']" },
          select: { class: ".el-select, select" },
          datePicker: { class: ".el-date-editor, .el-date-picker" },
          address: { class: ".el-cascader, .el-autocomplete" },
          upload: { class: "input[type='file'], .el-upload" },
          buttons: {
            add: { class: "a[href='javascript:void(0)']" },
            edit: { class: "a[href='javascript:void']" },
            save: { class: ".el-button--primary" },
          },
        },
        experience: {
          container: { containerSelector: ".tab-block.re-block" },
          card: { cardSelector: ".block" },
          add: {
            addButtonSelector: "a[href='javascript:void(0)']",
            addButtonText: ["添加教育背景", "添加示例资料", "添加项目经验", "添加"],
          },
          editor: { editModeGuardSelector: ".resume-form, .resume-form2", editTimeoutMs: 400 },
          save: { requiresSaveBeforeNext: false, allowAutoSave: false },
        },
      },
      示例资料flow: sfExpressCampusWorkflow(),
    },
    {
      id: "huawei-campus-resume",
      // 华为新版 /cn/personal-center 是同页长表单，直接走通用一键填充。
      // 旧版特殊流程只能严格匹配下方 legacy URL，禁止品牌根域兜底误拦新版。
      brandDomain: "",
      hostname: "career.huawei.com",
      urlPattern: /^https?:\/\/career\.huawei\.com\/reccampportal\/campus5\/resume2\/index\.html/i,
      pageGuardSelector: ".step, #baseinfo, #示例资料, #示例资料-exp, #示例资料s",
      config: {
        name: "career.huawei.com/reccampportal/campus5/resume2",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/career\.huawei\.com\/reccampportal\/campus5\/resume2\/index\.html/i,
        selectors: {
          container: { class: ".content-wrap > .section" },
          title: { class: ".sub-title h5" },
          labels: { class: ".layui-form-label, .sub-title h5" },
          radio: { class: ".layui-form-radio, input[type='radio']" },
          checkbox: { class: ".layui-form-checkbox, input[type='checkbox']" },
          select: { class: ".layui-form-select, select" },
          datePicker: { class: "input.date-item[lay-key]" },
          upload: { class: "input[type='file'], .resume-upload" },
          buttons: {
            add: { class: ".btn-add" },
            edit: {},
            save: { class: "input.layui-btn-danger[type='button']" },
          },
        },
        experience: {
          container: { containerSelector: "#示例资料, #示例资料-exp, #示例资料s" },
          card: { cardSelector: "form.layui-form" },
          add: { addButtonSelector: ".btn-add", addButtonText: ["添加"] },
          save: { requiresSaveBeforeNext: false, allowAutoSave: false },
          editor: { editModeGuardSelector: "form.layui-form", editTimeoutMs: 250 },
        },
      },
      示例资料flow: {
        id: "huawei-campus-resume",
        name: "华为校园招聘简历",
        enabled: true,
        privateSpecialSite: true,
        hostname: "career.huawei.com",
        urlPattern: /^https?:\/\/career\.huawei\.com\/reccampportal\/campus5\/resume2\/index\.html/i,
        pageGuardSelector: ".step, #baseinfo, #示例资料, #示例资料-exp, #示例资料s",
        continueOnError: true,
        notices: [
          "华为校园招聘：每页先清空可编辑旧值，再按当前简历重新填写；多余的历史经历卡片会删除。",
          "华为校园招聘：每页填写后尝试点击底部保存；若当前页仍有网站必填校验，流程继续通过顶部步骤进入下一页。",
          "华为校园招聘：照片、附件简历及隐私承诺仍需用户人工检查。",
        ],
        steps: [
          huaweiPageStep(1, "基本资料与示例资料", "示例资料Info", {
            clearHuaweiPageKey: "baseinfo",
            dataTransform: enrichHuaweiBasic,
            fieldSequence: [
              { label: "姓名", field: "name", type: "huaweiText", controlName: "name" },
              { label: "性别", field: "gender", type: "huaweiRadio", controlName: "title" },
              { label: "国家/地区", field: "huaweiNationality", type: "huaweiSelect", controlName: "nationality" },
              { label: ["国家/地区", "籍贯"], field: "huaweiNativePlace", type: "huaweiSelect", controlName: "nativePlace" },
              { label: "证件", field: "huaweiIdType", type: "huaweiSelect", controlName: "indentifiedType" },
              { label: "证件", field: "idNumber", type: "huaweiText", controlName: "indentifiedId" },
              { label: "电子邮箱", field: "email", type: "huaweiText", controlName: "email" },
              { label: "联系电话", field: "huaweiPhoneArea", type: "huaweiSelect", controlName: "telephoneTitle" },
              { label: "联系电话", field: "phone", type: "huaweiText", controlName: "mobilePhone" },
              { label: "当前学校所在国家/地区", field: "huaweiSchoolCountry", type: "huaweiSelect", controlName: "countryOfSchool" },
              { label: "当前学校所在城市", field: "huaweiSchoolProvince", type: "huaweiSelect", controlName: "schoolOrInterviewLocus" },
              { label: "当前学校所在城市", field: "huaweiSchoolCity", type: "huaweiSelect", controlName: "schoolOrInterviewCity" },
              { label: "是否参加远程面试", field: "huaweiRemoteInterview", type: "huaweiRadio", controlName: "remoteInterview", optional: true },
              { label: "研究方向", field: "huaweiResearchDirection", type: "huaweiText", controlName: "researchWay", optional: true },
              { label: "个人成就", field: "huaweiAchievement", type: "huaweiText", controlName: "effort", optional: true },
              { label: "是否服从调配", field: "huaweiObeyAssignment", type: "huaweiRadio", controlName: "obedienceToAllocation" },
              { label: "第一意向工作地", field: "huaweiFirstLocation", type: "huaweiSelect", controlName: "示例资料PlaceOne" },
              { label: "第二意向工作地", field: "huaweiSecondLocation", type: "huaweiSelect", controlName: "示例资料PlaceTwo" },
              { label: "接受工作地点变更", field: "huaweiAcceptChange", type: "huaweiRadio", controlName: "isChangeWorkSite" },
              { label: "可接受工作地", field: "huaweiAcceptableArea", type: "huaweiSelect", controlName: "acceptabilityWorkSite" },
            ],
          }),
          huaweiPageStep(1, "保存基本资料", "示例资料Info", {
            navigationOnly: true,
            skipIfNoResumeData: false,
            saveSelector: '#baseinfo input[type="button"].layui-btn-danger',
            waitAfterSaveMs: 500,
            waitForSaveSuccess: true,
            saveSuccessTimeoutMs: 8000,
            waitBeforeNextMs: 2000,
          }),
          huaweiPageStep(2, "清理教育背景页", "示例资料Info", {
            navigationOnly: true,
            skipIfNoResumeData: false,
            clearHuaweiPageKey: "示例资料",
          }),
          huaweiPageStep(2, "示例资料", "示例资料", {
            replaceExistingRows: true,
            rowMinimumCount: 1,
            rowDeleteSelector: ".btn-delete",
            rowFilter: isHuaweiEducationRow,
            rowSort: compareEducationByStartTime,
            rowTransform: enrichHuaweiEducationRow,
            rowScopeSelector: 'form[lay-filter="示例资料"]',
            rowAddSelector: 'form[lay-filter="示例资料"] .js_qualification',
            rowAddNativeClick: true,
            rowFieldSequence: [
              { label: "在校时间", field: "startTime", type: "huaweiDate", controlName: "示例资料StartDateStr" },
              { label: "在校时间", field: "endTime", type: "huaweiDate", controlName: "示例资料EndDateStr" },
              { label: "学校所在国家/地区", field: "huaweiSchoolCountry", type: "huaweiSelect", controlName: "countryOfSchool" },
              { label: "学校名称", field: "school", type: "huaweiSearchSelect", controlName: "establishmentId", fallbackToFirstOption: true, optionTimeoutMs: 5000 },
              { label: "就读院系", field: "department", type: "huaweiText", controlName: "graduationCourtyardId" },
              { label: "专业", field: "major", type: "huaweiText", controlName: "firstMajorId" },
              { label: "学历", field: "huaweiEducationLevel", type: "huaweiSelect", controlName: "qualification" },
              { label: "学习成绩排名", field: "huaweiRank", type: "huaweiSelect", controlName: "scoreRanking", optional: true },
              { label: "学习成绩排名", field: "huaweiGpa", type: "huaweiText", controlName: "cgpa", optional: true },
              { label: "导师姓名", field: "huaweiMentor", type: "huaweiText", controlName: "model.teacherName", optional: true },
              { label: "是否国家/地区重点实验室", field: "huaweiKeyLab", type: "huaweiRadio", controlName: "isAttrValue", optional: true },
              { label: "是否为学生干部", field: "huaweiStudentCadre", type: "huaweiRadio", controlName: "isStudentCadre" },
            ],
          }),
          huaweiPageStep(2, "语言情况", "示例资料Skills", {
            replaceExistingRows: true,
            rowMinimumCount: 1,
            rowDeleteSelector: ".btn-delete",
            rowTransform: enrichHuaweiLanguageRow,
            rowScopeSelector: 'form[lay-filter="示例资料"]',
            rowAddSelector: 'form[lay-filter="示例资料"] .js_示例资料',
            rowAddNativeClick: true,
            rowFieldSequence: [
              { label: "语言语种", field: "huaweiLanguage", type: "huaweiSelect", controlName: "示例资料Name" },
              { label: "证书", field: "huaweiCertificate", type: "huaweiSelect", controlName: "certificat" },
              { label: "成绩", field: "score", type: "huaweiText", controlName: "grade" },
            ],
          }),
          huaweiPageStep(2, "保存教育背景", "示例资料Info", {
            navigationOnly: true,
            skipIfNoResumeData: false,
            saveSelector: '#示例资料 input[type="button"].layui-btn-danger',
            waitAfterSaveMs: 500,
          }),
          huaweiPageStep(3, "清理示例资料页", "示例资料Info", {
            navigationOnly: true,
            skipIfNoResumeData: false,
            clearHuaweiPageKey: "示例资料-exp",
          }),
          huaweiPageStep(3, "示例资料", "示例资料Experience", {
            replaceExistingRows: true,
            rowDeleteSelector: ".btn-delete",
            rowTransform: enrichHuaweiInternshipRow,
            rowScopeSelector: 'form[lay-filter="示例资料Exp"]',
            rowAddSelector: '#示例资料-exp > .item > .layui-form:first-child .btn-add',
            rowAddNativeClick: true,
            rowFieldSequence: [
              { label: "起止日期", field: "startTime", type: "huaweiDate", controlName: "startDateStr" },
              { label: "起止日期", field: "endTime", type: "huaweiDate", controlName: "endDateStr" },
              { label: "单位名称", field: "company", type: "huaweiText", controlName: "employerName" },
              { label: "任职部门", field: "department", type: "huaweiText", controlName: "jobDept" },
              { label: "担任职位", field: "position", type: "huaweiText", controlName: "jobName" },
              { label: "主要职责与业绩", field: "huaweiWorkDescription", type: "huaweiText", controlName: "desc" },
            ],
          }),
          huaweiPageStep(3, "在校项目经历", "示例资料Experience", {
            replaceExistingRows: true,
            rowDeleteSelector: ".btn-delete",
            rowTransform: enrichHuaweiProjectRow,
            rowScopeSelector: 'form[lay-filter="示例资料"]',
            rowAddSelector: '#示例资料-exp > .item > .layui-form:nth-last-child(2) .btn-add',
            rowAddNativeClick: true,
            rowFieldSequence: [
              { label: "起止日期", field: "startTime", type: "huaweiDate", controlName: "startDateStr" },
              { label: "起止日期", field: "endTime", type: "huaweiDate", controlName: "endDateStr" },
              { label: "项目名称", field: "name", type: "huaweiText", controlName: "示例资料Name" },
              { label: "项目角色", field: "role", type: "huaweiText", controlName: "示例资料Part", optional: true },
              { label: "主要职责与业绩", field: "huaweiProjectDescription", type: "huaweiText", controlName: "achievement", optional: true },
            ],
          }),
          huaweiPageStep(3, "保存示例资料", "示例资料Info", {
            navigationOnly: true,
            skipIfNoResumeData: false,
            saveSelector: '#示例资料-exp input[type="button"].layui-btn-danger',
            waitAfterSaveMs: 500,
          }),
          huaweiPageStep(4, "清理示例资料页", "示例资料Info", {
            navigationOnly: true,
            skipIfNoResumeData: false,
            clearHuaweiPageKey: "示例资料s",
          }),
          huaweiPageStep(4, "论文", "publications", {
            enabled: false,
            replaceExistingRows: true,
            rowDeleteSelector: ".btn-delete",
            rowFilter: function (row) { return !isHuaweiMeetingRow(row); },
            rowTransform: enrichHuaweiPaperRow,
            rowScopeSelector: 'form[lay-filter="paper"]',
            rowAddSelector: '#示例资料s > .item > .layui-form:nth-child(1) .btn-add',
            rowAddNativeClick: true,
            rowFieldSequence: [
              { label: "论文名称", field: "huaweiPaperName", type: "huaweiText", controlName: "paperName" },
              { label: "发表时间", field: "huaweiPaperTime", type: "huaweiDate", controlName: "paperTimeStr" },
              { label: "论文详情", field: "huaweiPaperDetails", type: "huaweiText", controlName: "paperParticulars" },
            ],
          }),
          huaweiPageStep(4, "发明专利", "示例资料s", {
            replaceExistingRows: true,
            rowDeleteSelector: ".btn-delete",
            rowTransform: enrichHuaweiPatentRow,
            rowScopeSelector: 'form[lay-filter="示例资料"]',
            rowAddSelector: '#示例资料s > .item > .layui-form:nth-child(2) .btn-add',
            rowAddNativeClick: true,
            rowFieldSequence: [
              { label: "专利编号", field: "huaweiPatentNo", type: "huaweiText", controlName: "示例资料No" },
              { label: "专利名称", field: "示例资料Name", type: "huaweiText", controlName: "示例资料Name" },
              { label: "发布时间", field: "huaweiPatentTime", type: "huaweiDate", controlName: "示例资料TimeStr" },
              { label: "专利价值", field: "huaweiPatentValue", type: "huaweiText", controlName: "示例资料Value" },
            ],
          }),
          huaweiPageStep(4, "参加学术会议", "publications", {
            replaceExistingRows: true,
            rowDeleteSelector: ".btn-delete",
            rowFilter: isHuaweiMeetingRow,
            rowTransform: enrichHuaweiMeetingRow,
            rowScopeSelector: 'form[lay-filter="meeting"]',
            rowAddSelector: '#示例资料s > .item > .layui-form:nth-child(3) .btn-add',
            rowAddNativeClick: true,
            rowFieldSequence: [
              { label: "会议名称", field: "huaweiMeetingName", type: "huaweiText", controlName: "meetingName" },
              { label: "会议时间", field: "huaweiMeetingTime", type: "huaweiDate", controlName: "meetingTimeStr" },
              { label: "会议职责", field: "huaweiMeetingDuty", type: "huaweiText", controlName: "meetingResponsibility" },
            ],
          }),
          huaweiPageStep(4, "获奖经历", "示例资料", {
            replaceExistingRows: true,
            rowDeleteSelector: ".btn-delete",
            rowTransform: enrichHuaweiAwardRow,
            rowScopeSelector: 'form[lay-filter="prize"]',
            rowAddSelector: '#示例资料s > .item > .layui-form:nth-child(4) .btn-add',
            rowAddNativeClick: true,
            rowFieldSequence: [
              { label: "奖项类型", field: "huaweiAwardType", type: "huaweiSelect", controlName: "prizeType" },
              { label: ["奖项级别", "奖学金级别"], field: "huaweiAwardScope", type: "huaweiSelect", controlName: "prizeGrade" },
              { label: ["竞赛名称", "奖学金名称"], field: "huaweiAwardName", type: "huaweiText", controlName: "prizeName" },
              { label: "奖项等级", field: "huaweiAwardGrade", type: "huaweiText", controlName: "prizeLevel" },
              { label: "获奖时间", field: "awardTime", type: "huaweiDate", controlName: "prizeTimeStr" },
              { label: "获奖情况", field: "huaweiAwardDescription", type: "huaweiText", controlName: "prizeParticulars", optional: true },
            ],
          }),
          huaweiPageStep(4, "华为亲属及统一保存", "示例资料Info", {
            dataTransform: enrichHuaweiBasic,
            fieldSequence: [
              { label: ["是否有亲属在华为工作（包含曾经）", "是否有亲属在华为"], field: "huaweiHasRelative", type: "huaweiRadio", controlName: "isFamilyHuawei" },
            ],
            saveSelector: '#示例资料s input[type="button"].layui-btn-danger',
            waitAfterSaveMs: 700,
            saveTimeoutMs: 6000,
          }),
        ],
      },
    },
    {
      id: "hsbank-recruitment",
      brandDomain: "hsbank.com.cn",
      hostname: "rczp.hsbank.com.cn",
      urlPattern: /^https?:\/\/rczp\.hsbank\.com\.cn\/#\/center/i,
      pageGuardSelector: "#resumes > .d_jump, .示例资料.d_jump",
      config: {
        name: "rczp.hsbank.com.cn",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/rczp\.hsbank\.com\.cn\/#\/center/i,
        selectors: {
          container: { class: "#resumes > .d_jump" },
          title: { class: ".htitle .title" },
          labels: { class: ".el-form-item__label" },
          radio: { class: ".el-radio-group, .el-radio" },
          select: { class: ".el-select, .el-autocomplete" },
          datePicker: { class: ".el-date-editor" },
          upload: { class: "input[type='file'], .el-upload" },
          buttons: {
            add: { class: "span.add.redcolor" },
            edit: { class: "button.cancel" },
          },
        },
        experience: {
          container: { containerSelector: "#resumes > .d_jump" },
          card: { cardSelector: "form.info_form" },
          add: {
            addButtonSelector: "span.add.redcolor",
            addButtonText: [
              "新增示例资料",
              "新增外语语种",
              "新增主要证书",
              "新增奖励情况",
              "新增亲属关系",
              "新增示例资料",
              "新增示例资料",
            ],
          },
          save: { requiresSaveBeforeNext: false, allowAutoSave: false },
          editor: { editModeGuardSelector: "button.save", editTimeoutMs: 300 },
        },
      },
      示例资料flow: {
        id: "hsbank-recruitment",
        name: "徽商银行招聘简历",
        enabled: true,
        privateSpecialSite: true,
        hostname: "rczp.hsbank.com.cn",
        urlPattern: /^https?:\/\/rczp\.hsbank\.com\.cn\/#\/center/i,
        pageGuardSelector: "#resumes > .d_jump, .示例资料.d_jump",
        continueOnError: true,
        notices: [
          "徽商银行：证件照、生活照等附件及本人承诺需人工检查和确认。",
        ],
        steps: [
          hsbankInlineStep(".information", "个人信息", "示例资料Info", {
            dataTransform: enrichHsbankBasicInfo,
            fieldSequence: [
              { label: "政治面貌", field: "hsbankPoliticalStatus", type: "elementSelect" },
              { label: "民族", field: "ethnicity", type: "elementSelect" },
              { label: "身体状况", field: "healthStatus", type: "elementSelect" },
              { label: "婚姻状态", field: "maritalStatus", type: "elementSelect" },
              { label: "身高", field: "height", type: "text" },
              { label: "户口所在地", type: "elementSelectGroup", dataFields: ["hsbankHukouProvince", "hsbankHukouCity", "hsbankHukouDistrict"], strictCurrentControl: true, waitAfterLevelMs: 420 },
              { label: "家庭住址", type: "elementSelectGroup", dataFields: ["hsbankFamilyProvince", "hsbankFamilyCity", "hsbankFamilyDistrict"], strictCurrentControl: true, waitAfterLevelMs: 420 },
              { label: "家庭住址", field: "hsbankFamilyDetail", type: "text", optional: true },
              { label: "籍贯", type: "elementSelectGroup", dataFields: ["hsbankNativeProvince", "hsbankNativeCity", "hsbankNativeDistrict"], strictCurrentControl: true, waitAfterLevelMs: 420 },
              { label: "特长", field: "hsbankSpecialty", type: "text", optional: true },
              { label: "紧急联系人姓名", field: "emergencyContactName", type: "text" },
              { label: "联系人电话", field: "emergencyPhone", type: "text" },
            ],
          }),
          hsbankInlineStep(".示例资料", "示例资料", "示例资料", {
            transformCategoryRows: true,
            rowSort: compareEducationByStartTimeDesc,
            rowTransform: enrichHsbankEducationRow,
            rowScopeSelector: "form.info_form",
            rowAddText: "新增示例资料",
            rowAddAfterEach: false,
            rowFieldSequence: [
              { label: "开始时间", field: "startTime", type: "elementDate" },
              { label: "结束时间", field: "endTime", type: "elementDate" },
              { label: "学历", field: "hsbankLevel", type: "elementSelect" },
              { label: "是否最高学历", field: "hsbankHighestEducation", type: "radio" },
              { label: "学位", field: "hsbankDegree", type: "elementSelect" },
              { label: "是否最高学位", field: "hsbankHighestDegree", type: "radio" },
              { label: "专业", type: "elementSelectAutocompleteGroup", dataFields: ["hsbankMajorCategory", "hsbankMajorPrimary", "hsbankMajorSecondary"], selectFirstOption: true, trustedAutocomplete: true, trustedAutocompleteRequired: true, pretypeBeforeTrusted: true, fallbackToFirstOption: true, autocompletePanelSelector: ".el-autocomplete-suggestion.el-popper", autocompleteOptionSelector: "li", optionTimeoutMs: 6000, waitAfterInputMs: 700, waitAfterSelectMs: 350, waitAfterLevelMs: 460, optional: true },
              { label: "学校名称", type: "elementSelectAutocompleteGroup", dataFields: ["hsbankSchoolProvince", "school"], selectFirstOption: true, trustedAutocomplete: true, trustedAutocompleteRequired: true, pretypeBeforeTrusted: true, fallbackToFirstOption: true, autocompletePanelSelector: ".el-autocomplete-suggestion.el-popper", autocompleteOptionSelector: "li", optionTimeoutMs: 6000, waitAfterInputMs: 700, waitAfterSelectMs: 350, waitAfterLevelMs: 460 },
              { label: "类别", field: "hsbankEducationCategory", type: "elementSelect" },
              { label: "方式", field: "hsbankEducationMethod", type: "elementSelect" },
            ],
          }),
          hsbankInlineStep(".示例资料", "外语语种", "示例资料Skills", {
            transformCategoryRows: true,
            rowTransform: enrichHsbankLanguageRow,
            rowScopeSelector: "form.info_form",
            rowAddText: "新增外语语种",
            rowAddAfterEach: false,
            rowFieldSequence: [
              { label: "语种", field: "hsbankLanguage", type: "elementSelect" },
              { label: "等级", field: "hsbankLanguageLevel", type: "elementSelect" },
              { label: "证书号", field: "hsbankCertificateNo", type: "text", optional: true },
              { label: "分数", field: "score", type: "text", optional: true },
            ],
          }),
          hsbankInlineStep(".cert", "主要证书", "示例资料", {
            transformCategoryRows: true,
            rowTransform: enrichHsbankCertificateRow,
            rowScopeSelector: "form.info_form",
            rowAddText: "新增主要证书",
            triggerNativeClick: true,
            rowAddNativeClick: true,
            rowAddAfterEach: false,
            rowFieldSequence: [
              { label: "证书名称", field: "hsbankCertificateName", type: "text" },
              { label: "取得时间", field: "hsbankCertificateTime", type: "elementDate" },
              { label: "认证机构", field: "hsbankCertificateIssuer", type: "text", optional: true },
              { label: "证书编号", field: "hsbankCertificateNo", type: "text", optional: true },
            ],
          }),
          hsbankInlineStep(".award", "奖励情况", "示例资料", {
            transformCategoryRows: true,
            rowTransform: enrichHsbankAwardRow,
            rowScopeSelector: "form.info_form",
            rowAddText: "新增奖励情况",
            rowAddAfterEach: false,
            rowFieldSequence: [
              { label: "奖励名称", field: "hsbankAwardName", type: "text" },
              { label: "奖励时间", field: "awardTime", type: "elementDate" },
              { label: "奖励内容", field: "hsbankAwardContent", type: "text", optional: true },
              { label: "奖励机构", field: "hsbankAwardIssuer", type: "text", optional: true },
            ],
          }),
          hsbankInlineStep(".示例资料", "亲属关系", "示例资料Members", {
            transformCategoryRows: true,
            rowTransform: enrichHsbankFamilyRow,
            rowScopeSelector: "form.info_form",
            rowAddText: "新增亲属关系",
            rowAddAfterEach: false,
            rowFieldSequence: [
              { label: "关系", field: "relationship", type: "elementSelect" },
              { label: "姓名", field: "name", type: "text" },
              { label: "是否本行员工", field: "hsbankBankEmployee", type: "radio" },
              { label: "工作单位及职务", field: "hsbankCompanyPosition", type: "text" },
            ],
          }),
          hsbankInlineStep(".addjob", "示例资料", "示例资料Experience", {
            transformCategoryRows: true,
            rowTransform: enrichHsbankWorkRow,
            rowScopeSelector: "form.info_form",
            rowAddText: "新增示例资料",
            triggerNativeClick: true,
            rowAddNativeClick: true,
            rowAddAfterEach: false,
            rowFieldSequence: [
              { label: "开始时间", field: "startTime", type: "elementDate" },
              { label: "结束时间", field: "endTime", type: "hsbankEndDate" },
              { label: "工作单位", field: "hsbankCompany", type: "text" },
              { label: "部门", field: "department", type: "text" },
              { label: "职务/岗位", field: "position", type: "text" },
              { label: "证明人", field: "hsbankReferencePerson", type: "text" },
              { label: "证明人联系方式", field: "hsbankReferencePhone", type: "text" },
              { label: "工作描述", field: "hsbankDescription", type: "text" },
            ],
          }),
          hsbankInlineStep(".addinter", "示例资料", "示例资料Experience", {
            transformCategoryRows: true,
            rowTransform: enrichHsbankWorkRow,
            rowScopeSelector: "form.info_form",
            rowAddText: "新增示例资料",
            triggerNativeClick: true,
            rowAddNativeClick: true,
            rowAddAfterEach: false,
            rowFieldSequence: [
              { label: "开始时间", field: "startTime", type: "elementDate" },
              { label: "结束时间", field: "endTime", type: "hsbankEndDate" },
              { label: "实习单位", field: "hsbankCompany", type: "text" },
              { label: "部门", field: "department", type: "text" },
              { label: "职务/岗位", field: "position", type: "text" },
              { label: "证明人", field: "hsbankReferencePerson", type: "text" },
              { label: "证明人联系方式", field: "hsbankReferencePhone", type: "text" },
              { label: "工作描述", field: "hsbankDescription", type: "text" },
            ],
          }),
          hsbankInlineStep(".extra", "附加信息", "示例资料Introduction", {
            dataTransform: enrichHsbankExtra,
            fieldSequence: [
              { label: ["请填写所取得的工作业绩 或您认为有助于我们了解您的其他情况 (请在150字以内概括描述)", "附加信息"], field: "hsbankExtra", type: "scopedText", useScopeWhenLabelMissing: true, controlSelector: "textarea.el-textarea__inner", optional: true },
            ],
          }),
        ],
      },
    },
    {
      id: "bankcomm-recruitment",
      brandDomain: "bankcomm.com",
      hostname: "job.bankcomm.com",
      urlPattern: /^https?:\/\/job\.bankcomm\.com\/#\/personal\/resume/i,
      pageGuardSelector: ".resumeContent #示例资料, .resumeContent #示例资料, .resumeContent #示例资料",
      config: {
        name: "job.bankcomm.com",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/job\.bankcomm\.com\/#\/personal\/resume/i,
        selectors: {
          container: { class: ".resumeForm, .ant-form, [id]" },
          title: { class: ".componentTitle .title, .ant-divider + .title" },
          labels: { class: ".ant-form-item-label > label" },
          radio: { class: ".ant-radio-wrapper, .ant-radio-group, input[type='radio']" },
          checkbox: { class: ".ant-checkbox-wrapper, input[type='checkbox']" },
          select: { class: ".ant-select, [role='combobox']" },
          datePicker: { class: ".ant-picker" },
          address: { class: ".ant-select.ant-cascader, .ant-cascader-picker, [class*='cascader']" },
          upload: { class: ".ant-upload, input[type='file']" },
          buttons: {
            add: { class: "button.ant-btn-link, .anticon-file-add" },
            edit: { class: ".anticon-form, button.ant-btn-link" },
          },
        },
      },
      示例资料flow: {
        id: "bankcomm-recruitment",
        name: "交通银行招聘简历",
        enabled: true,
        privateSpecialSite: true,
        hostname: "job.bankcomm.com",
        urlPattern: /^https?:\/\/job\.bankcomm\.com\/#\/personal\/resume/i,
        pageGuardSelector: ".resumeContent #示例资料, .resumeContent #示例资料, .resumeContent #示例资料",
        continueOnError: true,
        notices: [
          "交通银行：填写前请先手动上传近期一寸免冠照、生活照及附件材料。",
          "交通银行：教育信息按页面要求从高中填写至最高学历。",
          "交通银行：照片、手机号、邮箱、证件号等注册或上传阶段已锁定字段会自动跳过。",
        ],
        steps: [
          bankcommStep("#示例资料", "示例资料", "示例资料Info", {
            scopeSelector: "#示例资料",
            readySelector: ".resumeForm form.ant-form",
            readyEditableSelector: "form.ant-form input:not([disabled]):not([readonly]):not([type='hidden']), form.ant-form textarea:not([disabled]):not([readonly]), form.ant-form .ant-select:not(.ant-select-disabled), form.ant-form .ant-picker:not(.ant-picker-disabled)",
            waitForCloseSelector: ".resumeForm form.ant-form",
            diagnosticCloseSelector: "",
            afterClickActionSelectors: [
              "#示例资料 .anticon-form[title='编辑']",
              "#示例资料 span[title='编辑']",
            ],
            afterClickActionAllowHidden: true,
            hoverBeforeAction: true,
            hoverBeforeActionSelector: "#示例资料 .info_div, #示例资料 .personName, #示例资料",
            waitAfterActionMs: 350,
            dataTransform: enrichBankcommBasicInfo,
            beforeSaveManualCheckpoint: bankcommBasicBeforeSaveManualCheckpoint,
            fieldSequence: [
              { label: "姓名", field: "name", type: "text", selector: "#name", preserveExisting: true },
              { label: "性别", field: "gender", type: "elementSelect", preserveExisting: true },
              { label: "出生日期", field: "birthDate", type: "elementDate", selector: "#birthday", preserveExisting: true },
              { label: "户口所在地", field: "bankcommHukouLocation", type: "bankcommAddressCascader", optional: true, inputId: "home", preserveExisting: true, optionTimeoutMs: 2500 },
              { label: "现居住地", field: "bankcommCurrentAddress", type: "bankcommAddressCascader", optional: true, inputId: "live", preserveExisting: true, optionTimeoutMs: 2500 },
              { label: "籍贯", field: "bankcommNativePlace", type: "bankcommAddressCascader", optional: true, inputId: "示例资料County", preserveExisting: true, optionTimeoutMs: 2500 },
              { label: "民族", field: "ethnicity", type: "elementSelect", optional: true, preserveExisting: true },
              { label: "婚姻状况", field: "maritalStatus", type: "elementSelect", optional: true, preserveExisting: true },
              { label: "政治面貌", field: "politicalStatus", type: "elementSelect", optional: true, preserveExisting: true },
              { label: "生源类型", field: "示例资料Type", type: "elementSelect", optional: true, preserveExisting: true },
              { label: "紧急联系电话", field: "emergencyPhone", type: "text", optional: true },
              { label: "当前薪资（年薪）", field: "bankcommSalary", type: "text", optional: true },
            ],
          }),
          bankcommStep("#示例资料", "教育信息", "示例资料", {
            manualCheckpointWhen: bankcommEducationManualCheckpointReason,
            manualCheckpointResolvedWhen: bankcommHasSavedPreHigherEducation,
            // 新用户页面中 #示例资料 的表单始终常驻，而教育栏目初始只有
            // “添加教育信息”按钮。首条记录必须直接点击本栏目按钮，并且
            // 只把 #示例资料 内出现的 form 当作教育编辑器。
            triggerSelector: "#示例资料 button.ant-btn",
            readySelector: "#示例资料 form.ant-form",
            skipClickWhenReady: true,
            skipWhenUnavailable: false,
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            // 交行 Ant 受控下拉偶尔会出现“适配器回报失败、页面实际已写入并
            // 显示绿色校验”的情况。此时仍应尝试点击当前卡片的保存；若页面
            // 真有必填项缺失，saveStepIfNeeded 会根据表单未关闭和校验文案拦住，
            // 不会继续新增下一条示例资料。
            saveOnPartialFill: true,
            // 任意一条教育未填完都必须停在当前条，不能跳过本科继续填写硕士。
            continueOnError: false,
            keepEditorOnError: true,
            // 每条教育必须真正退出当前编辑器后才能进入下一条。若 React 仍保留
            // 上一张表单，禁止复用它填写下一学历，避免本科被硕士覆盖。
            waitForRepeatEditorCloseInRoot: true,
            reuseDirtyRepeatEditor: false,
            waitBeforeNextMs: 260,
            verifyCurrentRepeatAfterSave: true,
            verifyRepeatCountAfterLast: true,
            updateExistingWhenPresent: true,
            // 交行已保存卡片的 DOM 顺序不等于学历顺序，不能按第 N 张覆盖。
            // 必须按学校定位：已有高中/硕士分别编辑原卡，缺少的本科单独新增。
            // 否则第一张 DOM 若实际是硕士，会被改成高中并与原高中日期重叠。
            overwriteExistingByPosition: false,
            existingRowIndexResolver: bankcommEducationCardIndex,
            // 当前页面可能只有“高中 + 硕士”。先跳过已存在学校，只为缺失的
            // 浙江大学生成新增任务，避免前后编辑动作干扰中间本科新增。
            existingRowMatcher: bankcommEducationRowExists,
            clearBeforeFillExisting: true,
            waitAfterClearMs: 260,
            rowSort: compareBankcommEducationRows,
            rowsTransform: prepareBankcommEducationRows,
            rowsValidator: validateBankcommEducationRows,
            // Missing high-school data is a real manual-review requirement, but
            // it must not abort the whole one-click run before 示例资料 info and
            // 示例资料 independent sections are processed.
            rowsValidationFailureMode: "manual_checkpoint",
            existingCardSelector: ".listStyle, .listStyle2",
            existingRecordSelector: ".listStyle, .listStyle2",
            existingEditHoverSelector: ".listStyle, .listStyle2",
            existingEditActionSelector: ".anticon-form[title='编辑'], span[title='编辑']",
            示例资料ReadySelector: ".resumeForm form.ant-form",
            rowTransform: enrichBankcommEducationRow,
            rowAddText: ["添加教育信息"],
            示例资料AddText: ["添加教育信息"],
            示例资料AddRootSelector: "#示例资料",
            示例资料AddUseAntMainBridge: true,
            afterClickActionText: ["添加教育信息"],
            afterClickActionRootSelector: "#示例资料",
            rowAddWaitMs: 450,
            rowAddTimeoutMs: 2500,
            rowScopeSelector: ".resumeForm form.ant-form",
            saveErrorDialogSelector: ".ant-modal-wrap, .ant-modal-confirm, [role='dialog']",
            saveErrorDialogPattern: "结束日期与已存在记录日期重叠|日期填写不合法|温馨提示",
            saveErrorDialogButtonText: ["确定", "确 定"],
            rowFieldSequence: [
              // 交行日期是 React 受控 Ant Picker。教育也必须走交行专用路径，
              // 否则通用日期逻辑可能复用上一张卡片的弹层，页面看似有值，
              // 实际 Form model 却保留旧日期，保存时被后台判定为教育时间重叠。
              { label: "起始日期", field: "startTime", type: "bankcommDate" },
              { label: "结束日期", field: "endTime", type: "bankcommDate" },
              // 交行当前是旧版 Ant Select，复用已验证可点击的通用适配器。
              // bankcommLevel 已严格映射成页面真实文字（如“本科”），通用适配器
              // 会优先精确匹配，因此不会再把“大学本科”模糊选成硕士。
              { label: "学历", field: "bankcommLevel", type: "elementSelect", waitAfterMs: 750 },
              {
                label: "是否在职期间获取",
                field: "bankcommIsJob",
                type: "elementSelect",
                postSelectConfirmText: "是否在职期间获取",
                postSelectConfirmButtonText: ["确定", "确 定"],
                postSelectConfirmSelector: ".ant-modal-confirm.resumeModal",
                postSelectConfirmTimeoutMs: 2500,
              },
              { label: "学习形式", field: "bankcommStudyType", type: "elementSelect" },
              { label: "学校名称", field: "school", type: "text", when: bankcommIsPreHigherEducationRow, waitAfterMs: 180 },
              {
                label: "学校名称",
                field: "bankcommSchool",
                type: "bankcommSchoolSearch",
                when: bankcommIsHigherEducationRow,
                // 学校库是远程搜索，不能套用研究方向的短等待。
                waitAfterMs: 250,
                searchInputTimeoutMs: 1800,
                optionTimeoutMs: 5000,
                writebackTimeoutMs: 2500,
              },
              {
                label: "专业名称",
                field: "bankcommMajor",
                type: "bankcommMajorSearch",
                optional: true,
                when: bankcommIsHigherEducationRow,
                waitAfterMs: 180,
                searchInputTimeoutMs: 1200,
                searchOptionTimeoutMs: 2200,
                writebackTimeoutMs: 1200,
                bridgeTimeoutMs: 5000,
                cascaderOptionTimeoutMs: 1800,
              },
              { label: "学位", field: "bankcommDegree", type: "elementSelect", optional: true, when: bankcommIsHigherEducationRow },
              { label: "在校期间成绩排名", field: "bankcommRank", type: "elementSelect", optional: true, when: bankcommIsHigherEducationRow },
              {
                label: "平均绩点（示例：3.7/4.0）",
                type: "bankcommGpa",
                gpaField: "bankcommGpa",
                totalField: "bankcommGpaTotal",
                optional: true,
                when: bankcommIsHigherEducationRow,
              },
              {
                label: "研究方向",
                field: "bankcommResearch",
                type: "bankcommResearchSearch",
                fallbackField: "bankcommResearchCustom",
                fallbackCheckboxText: "若未找到，请填写研究方向",
                fallbackSubmitButtonText: "提交",
                fallbackSubmitTimeoutMs: 1800,
                fallbackSubmitClickTimeoutMs: 3500,
                fallbackWritebackTimeoutMs: 2200,
                optional: false,
                when: bankcommIsHigherEducationRow,
                waitAfterMs: 120,
                searchInputTimeoutMs: 900,
                searchOptionTimeoutMs: 1800,
                writebackTimeoutMs: 1000,
                bridgeTimeoutMs: 3200,
                cascaderOptionTimeoutMs: 1200,
              },
            ],
          }),
          bankcommStep("#示例资料", "在校期间获奖情况", "示例资料", {
            triggerSelector: "#示例资料 button.ant-btn",
            readySelector: "form.ant-form",
            skipClickWhenReady: false,
            skipWhenUnavailable: false,
            示例资料ForCategoryData: true,
            // 交行“竞赛获奖”的名称只能从固定字典选择，不能自由输入。
            // 无对应名称的奖项不冒填成另一项赛事；保留可真实映射的记录。
            // 先在生成重复步骤前筛出校内获奖。示例资料Total 因而就是交行真正
            // 需要的卡片数；页面已有卡片数足够时走覆盖/复用，不再点击新增。
            rowFilter: bankcommCampusAwardSupported,
            saveEachRepeatStep: true,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            existingCardSelector: ".listStyle, .listStyle2",
            existingRecordSelector: ".listStyle, .listStyle2",
            existingEditHoverSelector: ".listStyle, .listStyle2",
            existingEditActionSelector: ".anticon-form[title='编辑'], span[title='编辑']",
            示例资料ReadySelector: ".resumeForm form.ant-form",
            rowTransform: enrichBankcommAwardRow,
            rowAddText: ["添加获奖情况"],
            示例资料AddText: ["添加获奖情况"],
            示例资料AddRootSelector: "#示例资料",
            afterClickActionText: ["添加获奖情况"],
            afterClickActionRootSelector: "#示例资料",
            rowScopeSelector: ".resumeForm form.ant-form",
            rowFieldSequence: [
              { label: "获奖时间", field: "bankcommAwardDate", type: "elementDate" },
              { label: "获奖阶段", field: "bankcommAwardPhase", type: "elementSelect" },
              { label: "获奖类别", field: "bankcommAwardClass", type: "elementSelect" },
              { label: "获奖级别", field: "bankcommAwardLevel", type: "elementSelect" },
              // 奖学金类别选定后页面会隐藏“获奖名称”，其余类别才填写。
              { label: "获奖名称", field: "bankcommAwardName", type: "elementSelect", optional: true, when: bankcommAwardHasName },
            ],
          }),
          bankcommStep("#示例资料", "工作、实习情况", ["示例资料Experience", "示例资料Experience"], {
            triggerSelector: "#示例资料 button.ant-btn",
            readySelector: "form.ant-form",
            skipClickWhenReady: false,
            skipWhenUnavailable: false,
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            continueOnError: false,
            keepEditorOnError: true,
            verifyCurrentRepeatAfterSave: true,
            verifyRepeatCountAfterLast: true,
            rowSort: compareBankcommExperienceRows,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: false,
            existingRowIndexResolver: bankcommWorkCardIndex,
            existingRowMatcher: bankcommWorkRowExists,
            clearBeforeFillExisting: true,
            waitAfterClearMs: 260,
            existingCardSelector: ".listStyle, .listStyle2",
            existingRecordSelector: ".listStyle, .listStyle2",
            existingEditHoverSelector: ".listStyle, .listStyle2",
            existingEditActionSelector: ".anticon-form[title='编辑'], span[title='编辑']",
            示例资料ReadySelector: ".resumeForm form.ant-form",
            rowTransform: enrichBankcommWorkRow,
            rowAddText: ["添加工作、实习情况"],
            示例资料AddText: ["添加工作、实习情况"],
            示例资料AddRootSelector: "#示例资料",
            afterClickActionText: ["添加工作、实习情况"],
            afterClickActionRootSelector: "#示例资料",
            rowScopeSelector: ".resumeForm form.ant-form",
            saveErrorDialogSelector: ".ant-modal-wrap, .ant-modal-confirm, [role='dialog']",
            saveErrorDialogPattern: "日期重叠|日期填写不合法|温馨提示",
            saveErrorDialogButtonText: ["确定", "确 定"],
            rowFieldSequence: [
              { label: "起始日期", field: "startTime", type: "bankcommDate" },
              { label: "结束日期", field: "endTime", type: "bankcommCurrentEndOrDate" },
              { label: "工作类型", field: "bankcommWorkType", type: "elementSelect" },
              { label: "单位名称", field: "company", type: "text" },
              { label: "所在部门", field: "department", type: "text", optional: true },
              { label: "职位", field: "position", type: "text" },
            ],
          }),
          // 当前校园招聘流程明确不触碰“社招额外填写情况”。
          // 该模块不加入执行计划，避免误改社招口径或触发无关保存事务。
          bankcommStep("#示例资料", "语言水平", "示例资料Skills", {
            triggerSelector: "#示例资料 button.ant-btn",
            readySelector: "form.ant-form",
            skipClickWhenReady: false,
            skipWhenUnavailable: false,
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            existingCardSelector: ".listStyle, .listStyle2",
            existingRecordSelector: ".listStyle, .listStyle2",
            existingEditHoverSelector: ".listStyle, .listStyle2",
            existingEditActionSelector: ".anticon-form[title='编辑'], span[title='编辑']",
            示例资料ReadySelector: ".resumeForm form.ant-form",
            rowTransform: enrichBankcommLanguageRow,
            rowAddText: ["添加语言水平"],
            示例资料AddText: ["添加语言水平"],
            示例资料AddRootSelector: "#示例资料",
            afterClickActionText: ["添加语言水平"],
            afterClickActionRootSelector: "#示例资料",
            rowScopeSelector: ".resumeForm form.ant-form",
            rowFieldSequence: [
              { label: "语种", field: "bankcommLanguage", type: "elementSelect" },
              { label: "证书名称", field: "bankcommLanguageCert", type: "elementSelect", optional: true },
              { label: "成绩", field: "bankcommLanguageScore", type: "text", optional: true },
            ],
          }),
          bankcommStep("#professional", "其他职业资格证书", "示例资料", {
            triggerSelector: "#professional button.ant-btn",
            readySelector: "form.ant-form",
            skipClickWhenReady: false,
            skipWhenUnavailable: false,
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            existingCardSelector: ".listStyle, .listStyle2",
            existingRecordSelector: ".listStyle, .listStyle2",
            existingEditHoverSelector: ".listStyle, .listStyle2",
            existingEditActionSelector: ".anticon-form[title='编辑'], span[title='编辑']",
            示例资料ReadySelector: ".resumeForm form.ant-form",
            rowFilter: function (row) {
              return !/计算机|Office|软件|数据库|SQL|Python|Java/i.test(String(row && (row.certificateName || row.name || row.certificate) || ""));
            },
            rowAddText: ["添加职业资格证书"],
            示例资料AddText: ["添加职业资格证书"],
            示例资料AddRootSelector: "#professional",
            afterClickActionText: ["添加职业资格证书"],
            afterClickActionRootSelector: "#professional",
            rowScopeSelector: ".resumeForm form.ant-form",
            rowFieldSequence: [
              { label: "类别", field: "certificateType", type: "elementSelect", optional: true },
              { label: "资格证书", field: "certificateName", type: "elementSelect" },
            ],
          }),
          bankcommStep("#示例资料", "计算机证书", "示例资料", {
            triggerSelector: "#示例资料 button.ant-btn",
            readySelector: "form.ant-form",
            skipClickWhenReady: false,
            skipWhenUnavailable: false,
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            existingCardSelector: ".listStyle, .listStyle2",
            existingRecordSelector: ".listStyle, .listStyle2",
            existingEditHoverSelector: ".listStyle, .listStyle2",
            existingEditActionSelector: ".anticon-form[title='编辑'], span[title='编辑']",
            示例资料ReadySelector: ".resumeForm form.ant-form",
            rowFilter: function (row) {
              return /计算机|Office|软件|数据库|SQL|Python|Java/i.test(String(row && (row.certificateName || row.name || row.certificate) || ""));
            },
            rowTransform: enrichBankcommComputerCertificate,
            rowAddText: ["添加计算机证书"],
            示例资料AddText: ["添加计算机证书"],
            示例资料AddRootSelector: "#示例资料",
            afterClickActionText: ["添加计算机证书"],
            afterClickActionRootSelector: "#示例资料",
            rowScopeSelector: ".resumeForm form.ant-form",
            rowFieldSequence: [
              { label: "证书名称", field: "bankcommComputerCert", type: "elementSelect" },
              { label: "证书级别", field: "bankcommComputerLevel", type: "elementSelect", optional: true },
            ],
          }),
          bankcommStep("#homeSituation", "家庭关系", "示例资料Members", {
            triggerSelector: "#homeSituation button.ant-btn",
            readySelector: "form.ant-form",
            skipClickWhenReady: false,
            skipWhenUnavailable: false,
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            existingCardSelector: ".listStyle, .listStyle2",
            existingRecordSelector: ".listStyle, .listStyle2",
            existingEditHoverSelector: ".listStyle, .listStyle2",
            existingEditActionSelector: ".anticon-form[title='编辑'], span[title='编辑']",
            示例资料ReadySelector: ".resumeForm form.ant-form",
            rowAddText: ["添加家庭关系"],
            示例资料AddText: ["添加家庭关系"],
            示例资料AddRootSelector: "#homeSituation",
            afterClickActionText: ["添加家庭关系"],
            afterClickActionRootSelector: "#homeSituation",
            rowScopeSelector: ".resumeForm form.ant-form",
            rowFieldSequence: [
              { label: "关系类型", field: "relationship", type: "elementSelect" },
              { label: "姓名", field: "name", type: "text" },
              { label: "工作单位", field: "company", type: "text", optional: true },
              { label: "职位", field: "position", type: "text", optional: true },
            ],
          }),
          bankcommStep("#bocm", "交银集团亲属关系", "示例资料Info", {
            scopeSelector: "#bocm",
            readySelector: "form.ant-form",
            waitForCloseSelector: "",
            skipSave: true,
            dataTransform: enrichBankcommBasicInfo,
            fieldSequence: [
              { label: "是否有近亲属在交银集团工作", field: "bankcommBocmCloseRelative", type: "radio", optional: true },
              { label: "是否有其他亲属在交银集团工作", field: "bankcommBocmOtherRelative", type: "radio", optional: true },
              { label: "本人承诺", field: "bankcommBocmCommitment", type: "bankcommCommitmentCheckboxes", requiredCount: 2 },
            ],
          }),
          bankcommStep("#示例资料", "示例资料", "示例资料Info", {
            scopeSelector: "#示例资料",
            readySelector: "form.ant-form",
            waitForCloseSelector: "",
            continueOnError: false,
            dataTransform: enrichBankcommBasicInfo,
            fieldSequence: [
              { label: "是否拥有外国国籍、国（境）外永久居留权或常住许可", field: "bankcommForeignResidence", type: "radio" },
              { label: "是否曾受过处罚或处分", field: "bankcommPunished", type: "radio" },
              { label: "是否愿意按照交行应聘职位标准执行", field: "bankcommAgreeStandard", type: "radio" },
              { label: "招聘信息来源", field: "bankcommInfoSource", type: "text", optional: true },
              { label: "个人年薪期望值 (税前含福利)", field: "bankcommExpectedSalary", type: "text" },
            ],
          }),
        ],
      },
    },
    {
      id: "pingan-talent-resume",
      brandDomain: "pingan.com",
      hostname: "talent.pingan.com",
      urlPattern: /^https?:\/\/talent\.pingan\.com\/recruit\/personalcenter\.html#\/resume/i,
      pageGuardSelector: "body",
      config: {
        name: "平安银行社会招聘简历",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/talent\.pingan\.com\/recruit\/personalcenter\.html#\/resume/i,
        selectors: {
          container: { class: "form, .el-form, .ant-form, [class*='resume'], [class*='module'], body" },
          title: { class: "h1, h2, h3, h4, h5, h6, [class*='title'], [class*='header'], [class*='name']" },
          labels: { class: ".el-form-item__label, .ant-form-item-label, label, [class*='label']" },
          radio: { class: ".el-radio-group, .el-radio, .ant-radio-group, .ant-radio-wrapper, input[type='radio'], [role='radio']" },
          checkbox: { class: ".el-checkbox, .ant-checkbox-wrapper, input[type='checkbox'], [role='checkbox']" },
          select: { class: ".el-select, .ant-select, [role='combobox']" },
          datePicker: { class: ".el-date-editor, .ant-picker, input[placeholder*='日期'], input[placeholder*='时间']" },
          address: { class: ".el-cascader, .ant-cascader-picker, [class*='cascader']" },
          upload: { class: "input[type='file'], [class*='upload']" },
          buttons: {
            add: { class: "button, a, [role='button']" },
            edit: { class: "button, a, [role='button']" },
          },
        },
      },
      示例资料flow: {
        id: "pingan-talent-resume",
        name: "平安银行社会招聘简历",
        enabled: true,
        privateSpecialSite: true,
        hostname: "talent.pingan.com",
        urlPattern: /^https?:\/\/talent\.pingan\.com\/recruit\/personalcenter\.html#\/resume/i,
        pageGuardSelector: "body",
        continueOnError: true,
        notices: [
          "平安：填写前请先手动上传证件照、生活照、附件简历、成绩单等附件。",
          "平安：工作/教育等经历卡片按“填写一条→保存→新增下一条”的方式执行。",
          "平安：最终投递/确认承诺不会自动点击。",
        ],
        steps: [
          {
            name: "展开更多模块",
            triggerText: ["展开更多模块"],
            triggerCandidateSelector: "button, a, [role='button'], div, span",
            readySelector: "body",
            navigationOnly: true,
            skipIfNoResumeData: false,
            skipSave: true,
            skipClickWhenReady: false,
            waitAfterClickMs: 250,
            timeoutMs: 3000,
            skipWhenUnavailable: true,
          },
          pinganSectionStep("示例资料", "示例资料Info", {
            dataTransform: enrichPinganBasic,
            fieldSequence: [
              { label: "姓名", field: "name", type: "text" },
              { label: "性别", field: "gender", type: "radio" },
              { label: "出生日期", field: "birthDate", type: "elementDate" },
              { label: "最高学历", field: "pinganHighestEducation", type: "elementSelect" },
              { label: "工作年限", field: "pinganWorkYears", type: "text" },
              // campus.pingan.com 的新版表单把现居地放在“示例资料”中，
              // 字段名为“现居住地”；旧 talent 站仍可能在“示例资料”中使用
              // “现居地点”，因此这里只增量补充，不删除下方旧步骤。
              { label: ["现居住地", "现居地点"], field: "pinganCurrentLocation", type: "elementCascader", waitAfterMs: 220, optionTimeoutMs: 2200 },
              { label: "国籍/地区", field: "country", type: "elementSelect", optional: true },
              { label: "籍贯", field: "pinganNativePlace", type: "elementCascader", optional: true, waitAfterMs: 220, optionTimeoutMs: 1800 },
              { label: "证件类型", field: "idType", type: "elementSelect", optional: true },
              { label: "民族", field: "ethnicity", type: "elementSelect", optional: true },
              { label: "政治面貌", field: "politicalStatus", type: "elementSelect", optional: true },
              { label: "身高", field: "height", type: "text", optional: true },
            ],
          }),
          pinganSectionStep("联系信息", "示例资料Info", {
            fieldSequence: [
              { label: "手机号", type: "pinganPhone", phoneField: "phone" },
              { label: "邮箱", field: "email", type: "text" },
            ],
          }),
          pinganSectionStep("示例资料", "jobIntention", {
            dataTransform: enrichPinganJobIntention,
            fieldSequence: [
              { label: "现居地点", field: "pinganCurrentLocation", type: "elementCascader", waitAfterMs: 220, optionTimeoutMs: 2200 },
              { label: "意向地点", field: "pinganExpectedLocation", type: "elementCascader", waitAfterMs: 220, optionTimeoutMs: 2200 },
              { label: "到岗时间", field: "pinganAvailability", type: "elementSelect", optional: true },
            ],
          }),
          pinganSectionStep("薪酬信息", "jobIntention", {
            dataTransform: enrichPinganSalary,
            fieldSequence: [
              { label: "当前薪资", field: "pinganCurrentSalary", type: "text", optional: true },
              { label: "期望薪资", field: "pinganExpectedSalary", type: "text", optional: true },
              { label: "备注", field: "pinganSalaryNote", type: "text", optional: true },
            ],
          }),
          pinganSectionStep("示例资料", ["示例资料Experience", "示例资料Experience"], {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            existingRowMatcher: pinganExistingWorkRowMatcher,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            existingCardSelector: ".示例资料-module .display-mode",
            existingRecordSelector: ".示例资料-module",
            existingEditActionSelector: ".edit.edit-btn",
            示例资料AddRootSelector: ".示例资料-modules",
            示例资料AddText: ["添加示例资料", "新增示例资料", "添加", "新增"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            rowTransform: enrichPinganWorkRow,
            fieldSequence: [
              { label: "工作单位", field: "company", type: "text" },
              { label: "部门", field: "department", type: "text", optional: true },
              { label: "职位", field: "position", type: "text" },
              { label: "岗位级别", field: "pinganJobLevel", type: "text", optional: true },
              { label: "境外经历", field: "pinganOverseasExperience", type: "elementSelect" },
              { label: "开始时间", field: "startTime", type: "elementDate" },
              { label: "结束时间", field: "endTime", type: "pinganCurrentEnd" },
              { label: "证明人", field: "witnessName", type: "text", optional: true },
              { label: "联系方式", field: "witnessPhone", type: "text", optional: true },
              { label: "工作描述", field: "pinganWorkDescription", type: "text", optional: true },
            ],
          }),
          pinganSectionStep("示例资料", "示例资料", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            existingRowMatcher: pinganExistingEducationRowMatcher,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            existingCardSelector: ".edu-module .display-mode",
            existingRecordSelector: ".edu-module",
            existingEditActionSelector: ".edit.edit-btn",
            示例资料AddRootSelector: ".edu-modules",
            示例资料AddText: ["添加示例资料", "新增示例资料"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            rowsTransform: preparePinganEducationRows,
            rowTransform: enrichPinganEducationRow,
            fieldSequence: [
              { label: "毕业院校", field: "school", type: "elementSelectOrText" },
              { label: "专业", field: "pinganMajor", type: "elementCascader" },
              { label: "学位", field: "pinganDegree", type: "elementSelect" },
              { label: "学历", field: "pinganLevel", type: "elementSelect" },
              { label: "学习形式", field: "pinganStudyMode", type: "elementSelect" },
              { label: "开始时间", field: "startTime", type: "elementDate" },
              { label: "结束时间", field: "endTime", type: "elementDate" },
            ],
          }),
          pinganSectionStep("项目经历", "示例资料Experience", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            existingRowMatcher: pinganExistingProjectRowMatcher,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            existingCardSelector: ".pro-module .display-mode",
            existingRecordSelector: ".pro-module",
            existingEditActionSelector: ".edit.edit-btn",
            示例资料AddRootSelector: ".pro-modules",
            afterClickActionText: ["添加项目经历", "新增项目经历", "添加", "新增"],
            afterClickActionCandidateSelector: "button, a, [role='button'], div, span",
            示例资料AddText: ["添加项目经历", "新增项目经历", "添加", "新增"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            verifyCurrentRepeatAfterSave: true,
            verifyRepeatCountAfterLast: true,
            rowTransform: enrichPinganProjectRow,
            fieldSequence: [
              { label: "项目名称", field: "name", type: "text" },
              { label: "项目角色", field: "pinganProjectRole", type: "text", optional: true },
              { label: "开始时间", field: "startTime", type: "elementDate", optional: true },
              { label: "结束时间", field: "endTime", type: "elementDate", optional: true },
              { label: "项目描述", field: "pinganProjectDescription", type: "text", optional: true },
              { label: "职责描述", field: "pinganProjectDuty", type: "text" },
              { label: "项目链接", field: "link", type: "text", optional: true },
            ],
          }),
          pinganSectionStep("证书", "示例资料", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            existingRowMatcher: pinganExistingCertificateRowMatcher,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            existingCardSelector: ".cert-module .display-mode",
            existingRecordSelector: ".cert-module",
            existingEditActionSelector: ".edit.edit-btn",
            示例资料AddRootSelector: ".cert-modules",
            rowsTransform: preparePinganCertificateRows,
            afterClickActionText: ["添加证书", "新增证书", "添加", "新增"],
            afterClickActionCandidateSelector: "button, a, [role='button'], div, span",
            示例资料AddText: ["添加证书", "新增证书", "添加", "新增"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            rowTransform: enrichPinganCertificateRow,
            fieldSequence: [
              { label: "证书类型", field: "pinganCertificateType", type: "pinganInlineSelect" },
              { label: "证书名称", field: "pinganCertificateName", type: "text" },
              { label: "生效日期", field: "pinganCertificateTime", type: "elementDate" },
              { label: "说明", field: "pinganCertificateDescription", type: "text", optional: true },
            ],
          }),
          pinganSectionStep("语言技能", "示例资料Skills", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            existingRowMatcher: pinganExistingLanguageRowMatcher,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            existingCardSelector: ".lan-module .display-mode",
            existingRecordSelector: ".lan-module",
            existingEditActionSelector: ".edit.edit-btn",
            示例资料AddRootSelector: ".lan-modules",
            afterClickActionText: ["添加语言技能", "新增语言技能", "添加", "新增"],
            afterClickActionCandidateSelector: "button, a, [role='button'], div, span",
            示例资料AddText: ["添加语言技能", "新增语言技能", "添加", "新增"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            rowTransform: enrichPinganLanguageRow,
            fieldSequence: [
              { label: "语种", field: "pinganLanguageName", type: "pinganInlineSelect" },
              { label: "掌握程度", field: "pinganLanguageLevel", type: "pinganInlineSelect", optionTimeoutMs: 2600, waitAfterSelectMs: 260 },
              { label: "证书", field: "pinganLanguageCertificate", type: "text", optional: true },
              { label: "成绩", field: "pinganLanguageScore", type: "text", optional: true },
            ],
          }),
          pinganSectionStep("综合能力简述", "示例资料Introduction", {
            dataTransform: enrichPinganSummary,
            // 真实 DOM 无字段 label：.示例资料-module > .edit-mode 内只有 textarea。
            // 保存后必须等 textarea 消失，才能确认新文案真正进入 Vue model。
            waitForCloseSelector: ".edit-mode textarea.el-textarea__inner",
            fieldSequence: [
              // 平安该字段是 Vue 受控 textarea。普通 text 只可能改到 DOM value，
              // 二次编辑时 Vue model 仍保留旧文案，保存后就会恢复。必须走平安
              // 专用文本写入，清空旧值后触发 input/change 并校验新值。
              {
                label: "综合能力简述",
                field: "pinganSummary",
                type: "pinganText",
                useScopeWhenLabelMissing: true,
                waitAfterInputMs: 260,
              },
            ],
          }),
          pinganSectionStep("特长兴趣", "示例资料Info", {
            dataTransform: enrichPinganSummary,
            afterClickActionText: ["添加特长兴趣", "新增特长兴趣", "添加", "新增"],
            afterClickActionCandidateSelector: "button, a, [role='button'], div, span",
            fieldSequence: [
              { label: "特长兴趣", field: "pinganHobbies", type: "text" },
            ],
          }),
          // 平安亲属、外部兼岗、示例资料：没有数据时跳过；
          // 文件/照片上传继续要求用户提前手动完成，最终投递不自动点击。
        ],
      },
    },
    {
      id: "pingan-campus-resume",
      brandDomain: "pingan.com",
      hostname: "campus.pingan.com",
      urlPattern: /^https?:\/\/campus\.pingan\.com\/personalcenter\/resume/i,
      pageGuardSelector: "body",
      config: {
        name: "平安银行校园招聘简历",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/campus\.pingan\.com\/personalcenter\/resume/i,
        selectors: {
          container: { class: ".cv-module, .item-module, form, .el-form, [class*='resume'], body" },
          title: { class: ".title-wrapper .title, .modules-title .title, .title, h1, h2, h3, h4, h5, h6, [class*='title']" },
          labels: { class: ".el-form-item__label, label, [class*='label']" },
          radio: { class: ".el-radio-group, .el-radio, input[type='radio'], [role='radio']" },
          checkbox: { class: ".el-checkbox, input[type='checkbox'], [role='checkbox']" },
          select: { class: ".el-select, [role='combobox']" },
          datePicker: { class: ".el-date-editor, input[placeholder*='日期'], input[placeholder*='时间']" },
          address: { class: ".el-cascader, [class*='cascader']" },
          upload: { class: "input[type='file'], [class*='upload']" },
          buttons: {
            add: { class: "button, a, [role='button'], div, span" },
            edit: { class: "button, a, [role='button'], div, span" },
          },
        },
      },
      示例资料flow: {
        id: "pingan-campus-resume",
        name: "平安银行校园招聘简历",
        enabled: true,
        privateSpecialSite: true,
        hostname: "campus.pingan.com",
        urlPattern: /^https?:\/\/campus\.pingan\.com\/personalcenter\/resume/i,
        pageGuardSelector: "body",
        continueOnError: true,
        notices: [
          "平安校园招聘：填写前请先手动上传生活照、附件简历、成绩单等附件。",
          "平安校园招聘：教育、经历等卡片按“填写一条→保存→新增下一条”的方式执行。",
          "平安校园招聘：最终投递/确认承诺不会自动点击。",
        ],
        steps: [
          {
            name: "展开更多模块",
            triggerText: ["展开更多模块"],
            triggerCandidateSelector: "button, a, [role='button'], div, span",
            readySelector: "body",
            navigationOnly: true,
            skipIfNoResumeData: false,
            skipSave: true,
            skipClickWhenReady: false,
            waitAfterClickMs: 450,
            timeoutMs: 3000,
            skipWhenUnavailable: true,
          },
          pinganCampusSectionStep("示例资料", "示例资料Info", {
            dataTransform: enrichPinganCampusBasic,
            fieldSequence: [
              { label: "姓名", field: "name", type: "text" },
              { label: "性别", field: "gender", type: "radio" },
              { label: "出生日期", field: "birthDate", type: "elementDate" },
              { label: "最高学历", field: "pinganHighestEducation", type: "elementSelect", optional: true },
              { label: "现居住地", field: "pinganCurrentLocation", type: "elementCascader", waitAfterMs: 220, optionTimeoutMs: 2200 },
              { label: "籍贯", field: "pinganNativePlace", type: "elementCascader", optional: true, waitAfterMs: 220, optionTimeoutMs: 1800 },
              { label: "国籍/地区", field: "country", type: "elementSelect", optional: true },
              { label: "证件类型", field: "idType", type: "elementSelect", optional: true },
              { label: "民族", field: "ethnicity", type: "elementSelect", optional: true },
              { label: "政治面貌", field: "politicalStatus", type: "elementSelect", optional: true },
              { label: "身高", field: "height", type: "text", optional: true },
              { label: "境外示例资料", field: "pinganOverseasEducation", type: "elementSelect" },
            ],
          }),
          pinganCampusSectionStep("联系信息", "示例资料Info", {
            fieldSequence: [
              { label: "手机号", type: "pinganPhone", phoneField: "phone" },
              { label: "邮箱", field: "email", type: "text" },
            ],
          }),
          pinganCampusSectionStep("示例资料", "示例资料", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            rowFilter: function (row) { return !isPreHigherEducation(row); },
            示例资料AddText: ["添加示例资料", "新增示例资料"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            rowsTransform: preparePinganEducationRows,
            rowTransform: enrichPinganCampusEducationRow,
            beforeSaveEnsureFields: [
              { label: ["学校名称", "毕业院校"], field: "school", type: "elementSelectOrText", selectFirstOption: true, useSelectAdapterFirst: true, trustedAutocomplete: true, trustedAutocompleteRequired: true, preserveExistingInput: true, requireBlurAfterSelect: true, typeIntervalMs: 120, autocompletePanelSelector: ".el-autocomplete-suggestion.el-popper.my-autocomplete", autocompleteOptionSelector: "li[role='option']", enableTimeoutMs: 3200, optionTimeoutMs: 7000, waitAfterInputMs: 900, waitAfterSelectMs: 500 },
            ],
            fieldSequence: [
              { label: "是否境外经历", field: "pinganOverseasExperience", type: "elementSelect", optional: true },
              { label: "学历", field: "pinganLevel", type: "elementSelect", waitAfterMs: 650 },
              { label: ["学校名称", "毕业院校"], field: "school", type: "elementSelectOrText", selectFirstOption: true, useSelectAdapterFirst: true, trustedAutocomplete: true, trustedAutocompleteRequired: true, preserveExistingInput: true, requireBlurAfterSelect: true, typeIntervalMs: 120, autocompletePanelSelector: ".el-autocomplete-suggestion.el-popper.my-autocomplete", autocompleteOptionSelector: "li[role='option']", enableTimeoutMs: 3200, optionTimeoutMs: 7000, waitAfterInputMs: 900, waitAfterSelectMs: 500 },
              { label: "全日制", field: "pinganFullTime", type: "elementSelect" },
              { label: "开始时间", field: "startTime", type: "elementDate" },
              { label: "结束时间", field: "endTime", type: "elementDate" },
              { label: "专业", field: "pinganMajor", type: "elementCascader" },
              { label: "学位", field: "pinganDegree", type: "elementSelect" },
              { label: "学习形式", field: "pinganStudyMode", type: "elementSelect" },
              { label: "学习排名", field: "pinganStudyRank", type: "elementSelect" },
            ],
          }),
          pinganCampusSectionStep("英语能力", "示例资料Skills", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            rowFilter: function (row) { return isPinganEnglishRow(row); },
            示例资料AddText: ["添加英语能力", "新增英语能力"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            rowTransform: enrichPinganLanguageRow,
            fieldSequence: [
              { label: ["考试类型", "证书"], field: "pinganLanguageCertificate", type: "pinganInlineSelect", optional: true },
              { label: ["分数", "成绩"], field: "pinganLanguageScore", type: "text", optional: true },
              { label: ["获得时间", "获取时间", "获得日期"], field: "pinganLanguageObtainedTime", type: "elementDate" },
            ],
          }),
          pinganCampusSectionStep("其他示例资料", "示例资料Skills", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            rowFilter: function (row) { return !isPinganEnglishRow(row); },
            示例资料AddText: ["添加其他示例资料", "新增其他示例资料"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            rowTransform: enrichPinganLanguageRow,
            fieldSequence: [
              { label: "语种", field: "pinganLanguageName", type: "pinganInlineSelect" },
              { label: "听说能力", field: "pinganListeningSpeaking", type: "pinganInlineSelect" },
              { label: "读写能力", field: "pinganReadingWriting", type: "pinganInlineSelect" },
              { label: ["掌握程度", "熟练程度"], field: "pinganLanguageLevel", type: "pinganInlineSelect", optional: true },
              { label: ["证书", "证书名称"], field: "pinganLanguageCertificate", type: "text", optional: true },
              { label: ["成绩", "分数"], field: "pinganLanguageScore", type: "text", optional: true },
            ],
          }),
          pinganCampusSectionStep("工作/示例资料", ["示例资料Experience", "示例资料Experience"], {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            示例资料AddText: ["添加工作/示例资料", "新增工作/示例资料"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            rowTransform: enrichPinganCampusWorkRow,
            fieldSequence: [
              { label: ["单位名称", "工作单位", "实习单位", "公司名称"], field: "pinganWorkUnitName", type: "text" },
              { label: "部门", field: "department", type: "text", optional: true },
              { label: ["职位", "岗位"], field: "position", type: "text" },
              { label: "开始时间", field: "startTime", type: "elementDate" },
              { label: "结束时间", field: "endTime", type: "pinganCurrentEnd" },
              { label: ["工作描述", "经历描述", "职责描述"], field: "pinganWorkDescription", type: "text", optional: true },
            ],
          }),
          pinganCampusSectionStep("项目经历", "示例资料Experience", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            示例资料AddText: ["添加项目经历", "新增项目经历"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            rowTransform: enrichPinganProjectRow,
            fieldSequence: [
              { label: "项目名称", field: "name", type: "text" },
              { label: ["项目角色", "担任角色"], field: "pinganProjectRole", type: "text", optional: true },
              { label: "开始时间", field: "startTime", type: "elementDate", optional: true },
              { label: "结束时间", field: "endTime", type: "elementDate", optional: true },
              { label: ["项目描述", "项目介绍"], field: "pinganProjectDescription", type: "text", optional: true },
              { label: ["职责描述", "项目职责"], field: "pinganProjectDuty", type: "text" },
              { label: "项目链接", field: "link", type: "text", optional: true },
            ],
          }),
          pinganCampusSectionStep("证书", "示例资料", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            rowsTransform: preparePinganCertificateRows,
            示例资料AddText: ["添加证书", "新增证书"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            rowTransform: enrichPinganCertificateRow,
            fieldSequence: [
              { label: "证书类型", field: "pinganCertificateType", type: "pinganInlineSelect" },
              { label: "证书名称", field: "pinganCertificateName", type: "text" },
              { label: ["生效时间", "生效日期", "获得日期", "获得时间"], field: "pinganCertificateTime", type: "elementDate" },
              { label: "说明", field: "pinganCertificateDescription", type: "text", optional: true },
            ],
          }),
          pinganCampusSectionStep("奖励信息", "示例资料", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            // 奖励栏目偶尔会在最后一条保存后自动展开一张空新增卡。
            // 只在已保存卡片达到简历目标数量后关闭这张空卡。
            closeEmptyRepeatEditorAfterLast: true,
            示例资料AddText: ["添加奖励信息", "新增奖励信息"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            rowTransform: enrichPinganCampusAwardRow,
            fieldSequence: [
              { label: ["奖励名称", "奖项名称"], field: "pinganAwardName", type: "text" },
              { label: ["获奖时间", "获得时间"], field: "pinganAwardTime", type: "elementDate", optional: true },
              { label: "授予单位", field: "pinganAwardIssuer", type: "text" },
              { label: ["证明人", "证明人姓名"], field: "witnessName", type: "text", optional: true },
              { label: ["奖励级别", "奖项级别"], field: "pinganAwardLevel", type: "elementSelect", optional: true },
              { label: ["奖励描述", "描述"], field: "pinganAwardDescription", type: "text", optional: true },
            ],
          }),
          pinganCampusSectionStep("特长及兴趣", "示例资料Info", {
            dataTransform: enrichPinganSummary,
            fieldSequence: [
              { label: ["特长及兴趣", "特长兴趣"], field: "pinganHobbies", type: "text" },
            ],
          }),
          pinganCampusSectionStep("综合能力简述", "示例资料Introduction", {
            dataTransform: enrichPinganSummary,
            fieldSequence: [
              { label: "综合能力简述", field: "pinganSummary", type: "pinganText", useScopeWhenLabelMissing: true, waitAfterInputMs: 260 },
            ],
          }),
          pinganCampusSectionStep("校园活动经历", ["campusActivities", "campusLeadership"], {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            示例资料AddText: ["添加校园活动经历", "新增校园活动经历"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            rowTransform: enrichPinganCampusActivityRow,
            fieldSequence: [
              { label: ["活动名称", "项目/活动名称", "名称"], field: "activityName", type: "text" },
              { label: ["担任职务", "角色", "职务名称", "职位"], field: "role", type: "text", optional: true },
              { label: "开始时间", field: "startTime", type: "elementDate", optional: true },
              { label: "结束时间", field: "endTime", type: "elementDate", optional: true },
              { label: ["活动内容", "职务描述", "描述"], field: "description", type: "text", optional: true },
            ],
          }),
        ],
      },
    },
    {
      id: "51job-consumer-card-resume",
      hostname: "xyz.51job.com",
      urlPattern: /^https?:\/\/xyz\.51job\.com\/consumer\/pc\/resume\/index(?:[?#]|$)/i,
      pageGuardSelector: ".resume-content > .resume-module:not(.jobs-wrapper) > .resume-module-header .title",
      config: {
        name: "51job-consumer-card-resume",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        selectors: {
          container: { class: ".resume-content" },
          section: ".resume-content > .resume-module:not(.jobs-wrapper)",
          title: { class: ".resume-module-header .left > .title" },
          labels: { class: "form.el-form .el-form-item__label" },
          select: { class: "form.el-form .el-select" },
          datePicker: { class: "form.el-form .el-date-editor" },
          upload: { class: "form.el-form input[type='file'], form.el-form .el-upload" },
          buttons: { add: { class: ".resume-module-header .custom-button" }, edit: { class: ".resume-module-header .custom-button" }, save: { class: "form.el-form .btn-save" } },
        },
      },
      示例资料flow: {
        id: "51job-consumer-card-resume",
        name: "前程无忧企业卡片简历",
        enabled: true,
        privateSpecialSite: true,
        hostname: "xyz.51job.com",
        urlPattern: /^https?:\/\/xyz\.51job\.com\/consumer\/pc\/resume\/index(?:[?#]|$)/i,
        continueOnError: true,
        notices: ["已进入前程无忧企业卡片简历专用流程；不会点击添加志愿、立即投递或上传附件。"],
        steps: [
          job51ConsumerStep("示例资料", "示例资料", "示例资料Info"),
          job51ConsumerStep("最高学历示例资料", "最高学历示例资料", "示例资料", {
            示例资料ForCategoryData: true,
            rowsTransform: function (rows) { return rows.slice().sort(function (a, b) { return job51ExternalEducationRank(b) - job51ExternalEducationRank(a); }).slice(0, 1); },
            示例资料AddText: ["添加"],
            示例资料AddCandidateSelector: ".resume-module-header .custom-button",
          }),
          job51ConsumerStep("IT技能", "IT技能", "professionalSkills"),
          job51ConsumerStep("实践项目", "实践项目", ["campusActivities", "campusLeadership", "示例资料Experience"]),
          job51ConsumerStep("实习/项目经历", "实习/项目经历", ["示例资料Experience", "示例资料Experience"]),
          job51ConsumerStep("荣誉奖项", "荣誉奖项", "示例资料"),
          job51ConsumerStep("其他", "其他", "示例资料Info", { skipIfNoResumeData: false }),
        ],
      },
    },
    {
      id: "51job-external-webforms",
      // 前程无忧为企业提供的 ASP.NET WebForms 定制简历平台。这里按平台
      // 结构识别，不绑定某一家企业或某个 CtmID；企业独有字段以后再叠加
      // hostname + pathname + CtmID 补丁。填写当前可见页面后只尝试点击
      // “下一步”；照片等必填项缺失时由网页自身校验阻止跳转。绝不点击最终提交。
      hostname: /^(?:[^.]+\.)*51job\.com$/i,
      urlPattern: /^https?:\/\/[^/]*51job\.com\/External\/MyResume\/FillInResume\.aspx(?:[?#]|$)/i,
      pageGuardSelector: "form#form1 input[name='__VIEWSTATE']",
      config: {
        name: "51job-external-webforms",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/[^/]*51job\.com\/External\/MyResume\/FillInResume\.aspx(?:[?#]|$)/i,
        selectors: {
          // dlcolname / inputcolname 是这套平台跨企业、跨页面最稳定的字段边界；
          // cc_*_*_* 等 id 会随页码和记录序号改变，不作为主定位依据。
          container: { class: "form#form1" },
          title: { class: "li.leftli2 .lispan, li.leftli2" },
          labels: { class: "dl[dlcolname] > dt" },
          radio: { class: "input[type='radio'], label" },
          checkbox: { class: "input[type='checkbox'], label" },
          select: { class: "select[inputcolname], dl[editstyle] select" },
          datePicker: { class: "dl[dlcolname*='Date'] select, dl[dlcolname*='Time'] select" },
          buttons: {
            add: { class: "input.btnAppend[title='添加'], input#btnAppend" },
          },
        },
      },
      示例资料flow: {
        id: "51job-external-webforms",
        name: "前程无忧企业定制简历",
        enabled: true,
        privateSpecialSite: true,
        hostname: /^(?:[^.]+\.)*51job\.com$/i,
        urlPattern: /^https?:\/\/[^/]*51job\.com\/External\/MyResume\/FillInResume\.aspx(?:[?#]|$)/i,
        continueOnError: true,
        autoNextAfterFill: true,
        autoContinueAcrossPages: true,
        autoNextPageHeadings: ["全职示例资料", "语言能力", "IT技能", "在校实践经验"],
        nextButtonSelector: "#imgbtnNext",
        nextButtonDelayMs: 180,
        notices: [
          "该平台必须完成当前页全部必填项才能进入下一页；插件填写后会尝试点击下一步，缺少照片等内容时网页会停留并提示。",
          "示例资料页的照片是网站必填项，插件不会替用户选择或上传本地照片，需要手动完成。",
          "不会自动上传照片和附件，也不会点击最终提交。",
        ],
        steps: [
          {
            name: "示例资料",
            category: "示例资料Info",
            pageHeadingText: "示例资料",
            triggerSelector: "dl[dlcolname='Cname']",
            readySelector: "dl[dlcolname='Cname']",
            scopeSelector: ".ci",
            skipClickWhenReady: true,
            skipWhenUnavailable: true,
            skipSave: true,
            continueOnError: true,
            stopOnSaveError: false,
            handleNavigationSavePrompt: true,
            dataTransform: enrichJob51ExternalBasic,
            fieldSequence: [
              { label: "姓名", field: "name", type: "webformsText", inputSelector: 'input[inputcolname="Cname"]' },
              { label: "国籍（国家或地区）", field: "job51ExternalCountry" },
              { label: "性别", field: "gender" },
              { label: "民族", field: "ethnicity" },
              { label: "出生日期", field: "birthDate", type: "webformsYearMonth" },
              { label: "婚姻状况", field: "maritalStatus", optional: true },
              { label: "身份证号", field: "idNumber", type: "webformsText", inputSelector: 'input[inputcolname="IDCard"]', optional: true },
              { label: "政治面貌", field: "politicalStatus" },
              { label: "身高", field: "height", type: "text", optional: true },
              { label: "体重", field: "weight", type: "text", optional: true },
              { label: "入学前户口所在地", field: "job51ExternalHukouPath", type: "webformsLinkedSelect" },
              { label: "目前居住地", field: "job51ExternalCurrentPath", type: "webformsLinkedSelect" },
              { label: "期望工作地点", field: "job51ExternalExpectedPath", type: "webformsLinkedSelect" },
              { label: "电子邮件", field: "email", type: "webformsText", inputSelector: 'input[inputcolname="Email"]' },
              { label: "手机号码", field: "phone", type: "webformsText", inputSelector: 'input[inputcolname="MobilePhone"]' },
              { label: "通信地址", field: "job51ExternalCommunicationPath", type: "webformsLinkedSelect" },
              { label: "详细通信地址", field: "job51ExternalAddress", type: "text" },
              { label: "是否有亲属在中信集团及其他子公司任职", field: "job51ExternalHasRelative" },
              { label: "是否有全职示例资料", field: "job51ExternalHasWork" },
              { label: "工作累计时长（年）", field: "job51ExternalWorkYears", type: "text", optional: true,
                when: function (row) { return row && row.job51ExternalHasWork === "是"; } },
              { label: "是否有金融行业示例资料", field: "job51ExternalHasFinanceIntern" },
              { label: "实习累计时长（月）", field: "job51ExternalInternMonths", type: "text", optional: true,
                when: function (row) { return row && row.job51ExternalHasFinanceIntern === "是"; } },
            ],
          },
          {
            name: "示例资料",
            category: "示例资料",
            pageHeadingText: "示例资料",
            triggerSelector: "dl[dlcolname='Degree']",
            readySelector: "dl[dlcolname='Degree']",
            scopeSelector: ".ci",
            skipClickWhenReady: true,
            skipWhenUnavailable: true,
            skipSave: true,
            continueOnError: true,
            dataTransform: enrichJob51ExternalEducation,
            fieldSequence: [
              { label: "最高学历", field: "job51ExternalHighestLevel", type: "webformsSelect" },
              { label: "最高学历学习形式", field: "job51ExternalHighestStudyForm", type: "webformsSelect" },
              { label: "最高学历是否为MBA", field: "job51ExternalHighestIsMba", type: "webformsSelect" },
              { label: "最高学位", field: "job51ExternalHighestDegree", type: "webformsSelect" },
              { label: "最高学历入学时间", field: "job51ExternalHighestStart", type: "webformsDateText" },
              { label: "最高学历毕业时间", field: "job51ExternalHighestEnd", type: "webformsDateText" },
              { label: "最高学历毕业学校", field: "job51ExternalHighestSchool", type: "webformsDictionary", 示例资料InputSelector: 'input[inputcolname="CCA20"]' },
              { label: "最高学历专业", field: "job51ExternalHighestMajor", type: "webformsDictionary", 示例资料InputSelector: 'input[inputcolname="CCA22"]' },
              { label: "本科入学时间", field: "job51ExternalBachelorStart", type: "webformsDateText" },
              { label: "本科毕业时间", field: "job51ExternalBachelorEnd", type: "webformsDateText" },
              { label: "本科毕业学校", field: "job51ExternalBachelorSchool", type: "webformsDictionary", 示例资料InputSelector: 'input[inputcolname="CCA24"]' },
              { label: "本科学习形式", field: "job51ExternalBachelorStudyForm", type: "webformsSelect" },
              { label: "本科专业", field: "job51ExternalBachelorMajor", type: "webformsDictionary", 示例资料InputSelector: 'input[inputcolname="CCA25"]' },
              { label: "本学历是否为专升本学历", field: "job51ExternalBachelorUpgrade", type: "webformsSelect" },
              { label: "硕士入学时间", field: "job51ExternalMasterStart", type: "webformsDateText", optional: true },
              { label: "硕士毕业时间", field: "job51ExternalMasterEnd", type: "webformsDateText", optional: true },
              { label: "硕士毕业学校", field: "job51ExternalMasterSchool", type: "webformsDictionary", 示例资料InputSelector: 'input[inputcolname="CCF24"]', optional: true },
              { label: "硕士学习形式", field: "job51ExternalMasterStudyForm", type: "webformsSelect", optional: true },
              { label: "硕士专业", field: "job51ExternalMasterMajor", type: "webformsDictionary", 示例资料InputSelector: 'input[inputcolname="CCF14"]', optional: true },
              { label: "博士入学时间", field: "job51ExternalDoctorStart", type: "webformsDateText", optional: true },
              { label: "博士毕业时间", field: "job51ExternalDoctorEnd", type: "webformsDateText", optional: true },
              { label: "博士毕业学校", field: "job51ExternalDoctorSchool", type: "webformsDictionary", 示例资料InputSelector: 'input[inputcolname="CCF13"]', optional: true },
              { label: "博士学习形式", field: "job51ExternalDoctorStudyForm", type: "webformsSelect", optional: true },
              { label: "是否为硕博连读", field: "job51ExternalDoctorCombined", type: "webformsSelect", optional: true },
              { label: "博士专业", field: "job51ExternalDoctorMajor", type: "webformsDictionary", 示例资料InputSelector: 'input[inputcolname="CCF23"]', optional: true },
            ],
          },
          {
            name: "语言能力",
            category: "示例资料Skills",
            pageHeadingText: "语言能力",
            triggerSelector: "form#form1",
            readySelector: "form#form1",
            scopeSelector: ".ci",
            skipClickWhenReady: true,
            skipWhenUnavailable: true,
            skipSave: true,
            continueOnError: true,
            dataTransform: enrichJob51ExternalLanguage,
            fieldSequence: [
              { label: "英语水平", field: "job51ExternalEnglishPath", type: "webformsLinkedSelect", valueFields: ["job51ExternalEnglishCertificate", "job51ExternalEnglishScore"] },
              { label: "其他英语证书", field: "job51ExternalOtherEnglish", type: "webformsText", optional: true },
              { label: "其他外语", field: "job51ExternalOtherLanguage", type: "webformsText", optional: true },
            ],
          },
          {
            name: "IT技能",
            category: "示例资料Info",
            pageHeadingText: "IT技能",
            triggerSelector: "form#form1",
            readySelector: "form#form1",
            scopeSelector: ".ci",
            skipClickWhenReady: true,
            skipWhenUnavailable: true,
            skipSave: true,
            continueOnError: true,
            dataTransform: enrichJob51ExternalIt,
            fieldSequence: [
              { label: "技能", field: "job51ExternalItPath", type: "webformsLinkedSelect", valueFields: ["job51ExternalItCategory", "job51ExternalItSkill"] },
              { label: "掌握程度", field: "job51ExternalItLevel", type: "webformsSelect" },
            ],
          },
          {
            name: "全职示例资料",
            category: "示例资料Experience",
            pageHeadingText: "全职示例资料",
            triggerSelector: "form#form1",
            readySelector: "form#form1",
            scopeSelector: "form#form1",
            skipClickWhenReady: true,
            skipWhenUnavailable: true,
            skipSave: true,
            continueOnError: true,
            rowScopeSelector: ".ci",
            rowAddSelector: "#btnAppend",
            rowAddAfterEach: true,
            postbackAutoContinueWorkflowId: "51job-external-webforms",
            rowTransform: enrichJob51ExternalWorkRow,
            rowFieldSequence: [
              { label: "工作开始日期", field: "startTime", type: "webformsDateText" },
              { label: "工作结束日期", field: "endTime", type: "webformsDateText" },
              { label: "工作单位", field: "company", type: "webformsText" },
              { label: "工作部门及岗位", field: "job51ExternalDepartmentPosition", type: "webformsText", valueFields: ["department", "position"] },
              { label: "工作内容", field: "job51ExternalWorkContent", type: "webformsText" },
            ],
          },
          {
            name: "示例资料",
            category: "示例资料Experience",
            pageHeadingText: "示例资料",
            triggerSelector: "form#form1",
            readySelector: "form#form1",
            scopeSelector: "form#form1",
            skipClickWhenReady: true,
            skipWhenUnavailable: true,
            skipSave: true,
            continueOnError: true,
            rowScopeSelector: ".ci",
            rowAddSelector: "#btnAppend",
            rowAddAfterEach: true,
            postbackAutoContinueWorkflowId: "51job-external-webforms",
            rowTransform: enrichJob51ExternalInternRow,
            rowFieldSequence: [
              { label: "开始日期", field: "startTime", type: "webformsDateText" },
              { label: "结束日期", field: "endTime", type: "webformsDateText" },
              { label: "实习公司", field: "company", type: "webformsText" },
              { label: "实习部门", field: "department", type: "webformsText" },
              { label: "实习岗位", field: "position", type: "webformsText" },
              { label: "实习内容", field: "job51ExternalInternContent", type: "webformsText" },
            ],
          },
          {
            name: "在校实践经验",
            category: ["campusActivities", "campusLeadership"],
            pageHeadingText: "在校实践经验",
            triggerSelector: "form#form1",
            readySelector: "form#form1",
            scopeSelector: "form#form1",
            skipClickWhenReady: true,
            skipWhenUnavailable: true,
            skipSave: true,
            continueOnError: true,
            rowScopeSelector: ".ci",
            rowAddSelector: "#btnAppend",
            rowAddAfterEach: true,
            postbackAutoContinueWorkflowId: "51job-external-webforms",
            rowTransform: enrichJob51ExternalPracticeRow,
            rowFieldSequence: [
              { label: "开始日期", field: "startTime", type: "webformsDateText" },
              { label: "结束日期", field: "endTime", type: "webformsDateText" },
              { label: "实践项目", field: "job51ExternalPracticeName", type: "webformsText" },
              { label: "实践岗位", field: "job51ExternalPracticeRole", type: "webformsText" },
              { label: "项目描述", field: "job51ExternalPracticeDescription", type: "webformsText" },
            ],
          },
          {
            name: "家庭关系",
            category: "示例资料Members",
            pageHeadingText: "家庭关系",
            triggerSelector: "form#form1",
            readySelector: "form#form1",
            scopeSelector: "form#form1",
            skipClickWhenReady: true,
            skipWhenUnavailable: true,
            skipSave: true,
            continueOnError: true,
            rowScopeSelector: ".ci",
            rowAddSelector: "#btnAppend",
            rowAddAfterEach: true,
            postbackAutoContinueWorkflowId: "51job-external-webforms",
            rowTransform: enrichJob51ExternalFamilyRow,
            rowFieldSequence: [
              { label: "姓名", field: "name", type: "webformsText" },
              { label: "关系", field: "job51ExternalFamilyRelationship", type: "webformsSelect" },
              { label: "其他关系", field: "job51ExternalFamilyOtherRelationship", type: "webformsText", optional: true },
              { label: "工作单位", field: "job51ExternalFamilyCompany", type: "webformsText" },
              { label: "职位", field: "job51ExternalFamilyPosition", type: "webformsText" },
            ],
          },
          {
            name: "其他",
            category: "示例资料Info",
            pageHeadingText: "其他",
            triggerSelector: "form#form1",
            readySelector: "form#form1",
            scopeSelector: "form#form1",
            skipClickWhenReady: true,
            skipWhenUnavailable: true,
            skipIfNoResumeData: false,
            skipSave: true,
            continueOnError: true,
            dataTransform: enrichJob51ExternalOther,
            fieldSequence: [
              { label: "是否愿意服从公司分配", field: "job51ExternalWillingAssign", type: "webformsSelect" },
              { label: "是否愿意从事销售相关工作", field: "job51ExternalWillingSales", type: "webformsSelect" },
              { label: "期望岗位类型", field: "job51ExternalExpectedRole", type: "webformsSelect" },
              { label: "获得荣誉", field: "job51ExternalHonorLevel", type: "webformsSelect",
                waitForSelectorAfterSelect: 'dl[dlcolname="CCA19"] input[inputcolname="CCA19"]',
                optionTimeoutMs: 5000, postbackAutoContinueWorkflowId: "51job-external-webforms",
                when: function (row) { return row && row.job51ExternalHonorLevel !== "无"; } },
              { label: "获得荣誉", field: "job51ExternalHonorLevel", type: "webformsSelect",
                when: function (row) { return row && row.job51ExternalHonorLevel === "无"; } },
              { label: "荣誉名称", field: "job51ExternalHonorName", type: "webformsText",
                inputSelector: 'input[inputcolname="CCA19"]', optional: true,
                when: function (row) { return row && row.job51ExternalHonorLevel !== "无"; } },
              { label: "获得证书", field: "job51ExternalCertificates", type: "webformsCheckboxGroup", defaultValue: "无" },
              { label: "其他证书", field: "job51ExternalOtherCertificates", type: "webformsText", optional: true },
              { label: "招聘信息来源渠道", field: "job51ExternalSourceChannels", type: "webformsCheckboxGroup", defaultValue: "前程无忧" },
              { label: "本人郑重声明", field: "job51ExternalDeclaration", type: "webformsSelect" },
            ],
          },
          {
            name: "当前页面",
            fillMode: "visible",
            skipIfNoResumeData: false,
            pageHeadingText: "__never_use_generic_fallback__",
            triggerSelector: "form#form1:not(:has(dl[dlcolname='Cname'])):not(:has(dl[dlcolname='Degree']))",
            readySelector: "form#form1:not(:has(dl[dlcolname='Cname'])):not(:has(dl[dlcolname='Degree']))",
            scopeSelector: "form#form1",
            skipClickWhenReady: true,
            skipWhenUnavailable: false,
            timeoutMs: 3000,
            continueOnError: true,
            skipSave: true,
          },
        ],
      },
    },
    {
      id: "job51-resume-center",
      // www.51job.com/resume/center 继续严格命中；若官网以后更换子域或路径，
      // 只有同时出现三个官网简历模块指纹才允许品牌兜底。External/MyResume
      // 企业定制 WebForms 不具备这些结构，因此会进入上面的独立平台流程。
      brandDomain: "51job.com",
      brandFallbackGuardSelectors: ["#BaseInfo", "#CareerObjective", "#EducationalExperience"],
      hostname: "www.51job.com",
      urlPattern: /^https?:\/\/www\.51job\.com\/resume\/center/i,
      pageGuardSelector: "#BaseInfo, #CareerObjective, #EducationalExperience",
      config: {
        name: "www.51job.com/resume/center",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/www\.51job\.com\/resume\/center/i,
        selectors: {
          container: { class: ".moduleRight-content, .mb22" },
          title: { class: ".mb22, .el-form, .careerObjective_newAdd, .示例资料alExperienceIcon" },
          labels: { class: ".el-form-item__label" },
          radio: { class: ".el-radio-group, .el-radio-button, input[type='radio']" },
          checkbox: { class: ".el-checkbox-group, .el-checkbox, .el-switch, input[type='checkbox']" },
          select: { class: ".el-select, .select_Content" },
          datePicker: { class: ".el-date-editor" },
          address: { class: ".el-cascader, .m-area-input" },
          upload: { class: ".upload_btn, input[type='file']" },
          buttons: {
            add: { class: ".CertificateAdd, [class*='newAdd'], [class*='Add']" },
            edit: { class: ".el-button, [class*='edit'], [class*='Icon']" },
          },
        },
      },
      示例资料flow: {
        id: "job51-resume-center",
        name: "招聘网站在线简历",
        enabled: true,
        privateSpecialSite: true,
        notices: [
          "招聘网站：附件简历、作品集上传仍需用户先手动完成。",
          "招聘网站：资格证书是自定义大弹窗选择器，第一版先不自动选择证书，后续单独优化。",
        ],
        hostname: "www.51job.com",
        urlPattern: /^https?:\/\/www\.51job\.com\/resume\/center/i,
        continueOnError: true,
        steps: [
          job51ResumeStep("#BaseInfo", "示例资料", "示例资料Info", ["编辑"], {
            triggerSelector: "#BaseInfo .baseInfo, #BaseInfo .view_info, #BaseInfo",
            afterClickActionSelectors: ["#BaseInfo .editBtn"],
            hoverBeforeActionSelector: ".baseInfo",
            readySelector: "#BaseInfo .baseInfo_edit form.el-form",
            dataTransform: enrichJob51Basic,
            fieldSequence: [
              { label: "姓名", field: "name", type: "text" },
              { label: "当前求职状态", field: "job51Arrival", type: "elementSelect", optional: true },
              { label: "性别", field: "gender", type: "radio", optional: true },
              { label: "你的身份", field: "job51Identity", type: "elementSelect", optional: true },
              { label: "出生年月", field: "job51BirthMonth", type: "elementDate", optional: true },
              { label: "参加工作时间", field: "job51WorkStart", type: "elementDate", optional: true },
              { label: "居住地", field: "job51CurrentCity", type: "elementCascader", optional: true },
              { label: "政治面貌(选填)", field: "job51PoliticalStatus", type: "elementSelect", optional: true },
              { label: "微信号(选填)", field: "wechat", type: "text", optional: true },
              { label: "户口所在地(选填)", field: "job51HukouCity", type: "elementCascader", optional: true },
            ],
          }),
          job51ResumeStep("#PersonalAdvantage", "个人优势", "示例资料Introduction", ["编辑", "新增"], {
            afterClickActionSelectors: [
              "#PersonalAdvantage .editBtn",
              "#PersonalAdvantage .careerObjective_link .careerObjective_edit",
              "#PersonalAdvantage .careerObjective_content_hover .content_editclick"
            ],
            hoverBeforeActionSelector: ".advantage_desc, .careerObjective_newAdd",
            readySelector: "#PersonalAdvantage .edit_Content form.el-form, #PersonalAdvantage .edit_Content textarea",
            dataTransform: enrichJob51Advantage,
            waitForCloseSelector: ".edit_Content textarea",
            fieldSequence: [
              {
                label: "个人优势",
                field: "job51Advantage",
                type: "scopedText",
                useScopeWhenLabelMissing: true,
                controlSelector: ".edit_Content textarea, textarea.el-textarea__inner",
              },
            ],
          }),
          job51ResumeStep("#CareerObjective", "示例资料", "jobIntention", ["编辑"], {
            enabled: false,
            afterClickActionSelectors: [
              "#CareerObjective .careerObjective_content_hover .content_editclick",
              "#CareerObjective .careerObjectiveSet .content_editclick.content_editMar",
              "#CareerObjective .careerObjectiveSet .content_title_content",
              "#CareerObjective .careerObjective_header_hover .content_editclick",
              "#CareerObjective .careerObjective_content_hover"
            ],
            afterClickActionAllowHidden: true,
            afterClickActionNativeClick: true,
            hoverBeforeActionSelector: ".careerObjectiveSet, .careerObjective_newAdd",
            dataTransform: enrichJob51Intention,
            fieldSequence: [
              { label: "工作类型", field: "job51WorkType", type: "radio", optional: true, preserveExisting: true },
              { label: "期望工作城市", field: "job51ExpectedCity", type: "job51CitySearch", selectFirstResult: true },
              {
                label: "期望职位",
                field: "job51Position",
                type: "customSelect",
                customTriggerSelector: "input.el-input__inner",
                customSelectors: {
                  jbs: true,
                  container: ".el-form-item",
                  trigger: "input.el-input__inner",
                  searchInput: ".jbs_suggest input, input[placeholder*='搜索'], input[placeholder*='请输入']",
                  option: ".el-autocomplete-suggestion li, .el-autocomplete-suggestion [role='option'], .jbs_cascader_dialog .cascader_panel_item .func-item, .jbs_cascader_dialog .cascader_panel_item",
                  confirm: "button.el-button--primary, .confirm_button",
                  selectFirstAfterSearch: true,
                  maxLevels: 5,
                  waitAfterSearchMs: 900,
                },
              },
              { label: "期望月薪", type: "job51Salary", minField: "job51SalaryMin", maxField: "job51SalaryMax", monthsField: "job51SalaryMonths" },
            ],
            saveSelector: "#CareerObjective .dialog_button.el-button--primary",
          }),
          job51ResumeStep("#示例资料Experience", "示例资料", ["示例资料Experience", "示例资料Experience"], ["新增", "编辑"], {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            existingRowMatcher: job51ExistingWorkRowMatcher,
            示例资料AddRootSelector: "#示例资料Experience",
            示例资料AddSelectors: [
              "#示例资料Experience .示例资料Experience_edit",
              "#示例资料Experience .示例资料Experience_edit .edit_name"
            ],
            示例资料AddText: ["新增"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            示例资料AddHoverSelector: ".示例资料Experience_add",
            示例资料AddAllowHidden: true,
            示例资料ReadySelector: ".editWorkExperience form.el-form, form.el-form.el-form--label-top",
            afterClickActionSelectors: [
              "#示例资料Experience .示例资料Experience_edit",
              "#示例资料Experience .示例资料Experience_edit .edit_name",
              "#示例资料Experience .示例资料Experience_add"
            ],
            hoverBeforeActionSelector: ".示例资料Experience_add",
            dataTransform: enrichJob51Work,
            fieldSequence: [
              { label: "公司名称", field: "company", type: "text" },
              { label: "在职时间", type: "monthRange", startField: "job51WorkStart", endField: "job51WorkEnd", allowElementMonthPanel: true },
              {
                label: "职位",
                field: "job51Position",
                type: "customSelect",
                optional: true,
                customTriggerSelector: "input.el-input__inner",
                customSelectors: {
                  jbs: true,
                  container: ".el-form-item",
                  trigger: "input.el-input__inner",
                  searchInput: ".jbs_suggest input, input[placeholder*='搜索'], input[placeholder*='请输入']",
                  option: ".el-autocomplete-suggestion li, .el-autocomplete-suggestion [role='option'], .jbs_cascader_dialog .cascader_panel_item .func-item, .jbs_cascader_dialog .cascader_panel_item",
                  confirm: "button.el-button--primary, .confirm_button",
                  selectFirstAfterSearch: true,
                  maxLevels: 5,
                  waitAfterSearchMs: 900,
                },
              },
              { label: "工作类型", field: "job51WorkType", type: "radio", optional: true },
              { label: "工作描述", field: "job51WorkDescription", type: "text" },
              { label: "公司规模(选填)", field: "custom_companySize", type: "elementSelect", optional: true, preserveExisting: true },
              { label: "公司性质(选填)", field: "companyNature", type: "elementSelect", optional: true, preserveExisting: true },
            ],
          }),
          job51ResumeStep("#ProjectExperience", "项目经历", "示例资料Experience", ["新增", "编辑"], {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            existingRowMatcher: job51ExistingProjectRowMatcher,
            示例资料AddRootSelector: "#ProjectExperience",
            示例资料AddSelectors: [
              "#ProjectExperience .示例资料Operate",
              "#ProjectExperience .示例资料Operate .示例资料Edit"
            ],
            示例资料AddText: ["新增"],
            示例资料AddCandidateSelector: "button, a, [role='button'], div, span",
            示例资料AddHoverSelector: ".示例资料ContinerHeader",
            示例资料AddAllowHidden: true,
            示例资料ReadySelector: ".示例资料_edit form.el-form, form.el-form.el-form--label-top",
            afterClickActionSelectors: [
              "#ProjectExperience .示例资料Operate",
              "#ProjectExperience .示例资料Operate .示例资料Edit",
              "#ProjectExperience .示例资料ContinerHeader"
            ],
            hoverBeforeActionSelector: ".示例资料ContinerHeader",
            dataTransform: enrichJob51Project,
            fieldSequence: [
              { label: "项目名称", field: "name", type: "text" },
              { label: "项目时间", type: "monthRange", startField: "job51ProjectStart", endField: "job51ProjectEnd", allowElementMonthPanel: true },
              { label: "所属公司(选填)", field: "job51ProjectCompany", type: "elementSelect", optional: true, preserveExisting: true },
              { label: "项目描述", field: "job51ProjectDescription", type: "text" },
            ],
          }),
          job51ResumeStep("#EducationalExperience", "示例资料", "示例资料", ["编辑"], {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            rowsTransform: prepareJob51NewestFirstRows,
            示例资料VerifyFields: ["school", "major"],
            verifyRepeatSavedContent: true,
            示例资料AddRootSelector: "#EducationalExperience",
            示例资料AddSelectors: ["#EducationalExperience .示例资料ContinerImg"],
            示例资料AddText: ["新增"],
            示例资料AddHoverSelector: ".示例资料alExperienceIcon, .el-card__header",
            示例资料AddAllowHidden: true,
            示例资料AddNativeClick: true,
            示例资料ReadySelector: ".careerObjective_editTitle form.el-form, form.demo-ruleForm",
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            existingCardSelector: ".示例资料alExperienceHover",
            existingRecordSelector: ".示例资料alExperienceHover",
            existingEditHoverSelector: ".示例资料alExperienceHover",
            existingEditActionSelector: ".示例资料alExperienceRtEdit",
            afterClickActionSelectors: [
              "#EducationalExperience .示例资料ContinerImg",
              "#EducationalExperience .示例资料ContinerImg .示例资料ContinerImgtrans"
            ],
            saveSelector: "#EducationalExperience button.el-button--primary",
            dataTransform: enrichJob51Education,
            fieldSequence: [
              { label: "学历", field: "job51Level", type: "elementSelect" },
              { label: "学校名称", field: "school", type: "text" },
              {
                label: "专业",
                field: "major",
                type: "customSelect",
                // 51Job 选择高中/中专后会动态移除“专业”控件。
                when: function (row) { return !/高中|中技|中专|初中|小学/.test(String(row && (row.job51Level || row.level) || "")); },
                customTriggerSelector: "input.el-input__inner",
                customSelectors: {
                  jbs: true,
                  container: ".el-form-item",
                  trigger: "input.el-input__inner",
                  searchInput: ".jbs_suggest input, input[placeholder*='请输入'], input[placeholder*='搜索']",
                  option: ".el-autocomplete-suggestion li, .el-autocomplete-suggestion [role='option'], .jbs_cascader_dialog .cascader_panel_item .func-item, .jbs_cascader_dialog .cascader_panel_item",
                  confirm: "button.el-button--primary, .confirm_button",
                  selectFirstAfterSearch: true,
                  maxLevels: 5,
                  waitAfterSearchMs: 900,
                },
              },
              {
                label: "学制类型",
                field: "示例资料Type",
                type: "elementSelect",
                // 高中及以下页面没有该字段，不能因找不到动态隐藏控件阻止保存。
                when: function (row) { return !/高中|中技|中专|初中|小学/.test(String(row && (row.job51Level || row.level) || "")); },
              },
              { label: "在校时间", type: "monthRange", startField: "job51EducationStart", endField: "job51EducationEnd", allowElementMonthPanel: true },
            ],
          }),
          job51ResumeStep("#Schoolstatus", "在校荣誉/职务", ["示例资料", "campusLeadership"], ["新增"], {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            示例资料VerifyFields: ["job51CampusName"],
            verifyRepeatSavedContent: true,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            preferDirectExistingCards: true,
            existingCardSelector: ".campus-item",
            existingRecordSelector: ".campus-item",
            existingEditHoverSelector: ".item-content.el-popover__reference",
            existingEditActionRootSelector: "body",
            existingEditActionSelector: ".el-popover[aria-hidden='false'] .actionList > div:first-child",
            示例资料AddRootSelector: "#Schoolstatus",
            示例资料AddSelectors: ["#Schoolstatus .campusheader-right"],
            示例资料AddText: ["新增"],
            示例资料AddHoverSelector: ".campusheader",
            示例资料AddAllowHidden: true,
            示例资料AddNativeClick: true,
            示例资料ReadySelector: ".addOrEditWrap form.el-form",
            afterClickActionSelectors: ["#Schoolstatus .campusheader-right"],
            saveSelector: "#Schoolstatus button.el-button--primary",
            dataTransform: enrichJob51Campus,
            fieldSequence: [
              {
                label: "类别",
                field: "job51CampusType",
                type: "elementSelect",
                afterSelectReadyLabel: ["奖项名称", "职务名称"],
                waitAfterMs: 280,
              },
              { label: "奖项名称", field: "job51CampusName", type: "text", optional: true },
              { label: "获得时间", field: "job51CampusDate", type: "elementDate", optional: true, allowElementMonthPanel: true },
              { label: "职务名称", field: "job51CampusName", type: "text", optional: true },
              { label: "任职时间", type: "monthRange", startField: "job51CampusStart", endField: "job51CampusEnd", optional: true, allowElementMonthPanel: true },
              { label: "职务描述(选填)", field: "job51CampusDescription", type: "text", optional: true },
            ],
          }),
          job51ResumeStep("#LanguageAbility", "语言能力", "示例资料Skills", ["新增"], {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            示例资料VerifyFields: ["job51LanguageName"],
            verifyRepeatSavedContent: true,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            preferDirectExistingCards: true,
            existingCardSelector: ".示例资料-ability-item",
            existingRecordSelector: ".示例资料-ability-item",
            existingEditHoverSelector: ".item-content.el-popover__reference",
            existingEditActionRootSelector: "body",
            existingEditActionSelector: ".el-popover[aria-hidden='false'] .actionList > div:first-child",
            示例资料AddRootSelector: "#LanguageAbility",
            示例资料AddSelectors: ["#LanguageAbility .title-right"],
            示例资料AddText: ["新增"],
            示例资料AddHoverSelector: ".示例资料-ability-title",
            示例资料AddAllowHidden: true,
            示例资料AddNativeClick: true,
            示例资料ReadySelector: ".form-add-or-edit form.el-form",
            afterClickActionSelectors: ["#LanguageAbility .title-right"],
            saveSelector: "#LanguageAbility button.el-button--primary",
            dataTransform: enrichJob51Language,
            fieldSequence: [
              { label: "语种", field: "job51LanguageName", type: "elementSelect" },
              { label: "熟练程度", field: "job51LanguageLevel", type: "elementSelect" },
            ],
          }),
          // 51job 当前只自动维护：示例资料、个人优势、示例资料、项目经历、
          // 示例资料、在校荣誉/职务、语言能力。技能经验、示例资料、个人作品、
          // 附件上传不自动处理；资格证书是自定义大弹窗选择器，后续单独优化。
        ],
      },
    },
    {
      id: "czbank-recruitment",
      brandDomain: "czbank.com.cn",
      hostname: "zp.czbank.com.cn",
      urlPattern: /^https?:\/\/zp\.czbank\.com\.cn\//i,
      delegateUrlPattern: /^https?:\/\/zp\.czbank\.com\.cn\/zpweb\/planController\/gotoIndex\.mvc/i,
      pageGuardSelector: "#comp-1",
      config: {
        name: "zp.czbank.com.cn",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/zp\.czbank\.com\.cn\//i,
        selectors: {
          container: { class: ".comp" },
          title: { class: "h2, .示例资料-back, .title-container, .header" },
          labels: { class: ".el-form-item__label" },
          radio: { class: ".el-radio-group, .el-radio" },
          checkbox: { class: ".el-checkbox-group, .el-checkbox" },
          select: { class: ".el-select" },
          datePicker: { class: ".el-date-editor" },
          address: { class: ".el-cascader" },
          upload: { class: ".el-upload, input[type='file']" },
          buttons: {
            add: { class: ".add-btn, button.el-button--info.is-plain" },
            edit: { class: "button.el-button--primary" },
          },
        },
        experience: {
          container: { containerSelector: ".comp" },
          card: { cardSelector: ".示例资料-item, #comp-3 form.el-form, #comp-4 form.el-form" },
          add: {
            addButtonSelector: ".add-btn, button.el-button--info.is-plain",
            addButtonText: ["添加教育背景", "添加工作/示例资料", "添加家庭成员"],
            addTimeoutMs: 3500,
          },
          save: { requiresSaveBeforeNext: false, allowAutoSave: false },
          editor: { editModeGuardSelector: "form.el-form", editTimeoutMs: 350 },
        },
      },
      示例资料flow: {
        id: "czbank-recruitment",
        name: "浙商银行招聘简历",
        enabled: true,
        privateSpecialSite: true,
        notices: [
          "浙商银行：职业资格证书已默认选择“无”，请保存后人工检查该项是否需要改成真实证书。",
        ],
        hostname: "zp.czbank.com.cn",
        urlPattern: /^https?:\/\/zp\.czbank\.com\.cn\//i,
        continueOnError: true,
        steps: [
          czbankInlineStep("#comp-1", "示例资料", "示例资料Info", {
            dataTransform: enrichCzbankBasic,
            fieldSequence: [
              { label: "应聘类型", field: "czbankApplicationType", type: "elementSelect" },
              { label: "目前状态", field: "czbankCurrentStatus", type: "elementSelect" },
              { label: "婚姻状态", field: "maritalStatus", type: "elementSelect" },
              { label: "民族", field: "ethnicity", type: "elementSelect" },
              { label: "政治面貌", field: "politicalStatus", type: "elementSelect" },
              { label: "身高(cm)", field: "height", type: "text" },
              { label: "目前居住国家", field: "czbankResidence", type: "elementCascader", waitAfterMs: 220 },
              { label: "目前居住城市", field: "czbankResidenceCity", type: "elementCascader", waitAfterMs: 220 },
              { label: "籍贯", field: "czbankNativePlace", type: "elementCascader", waitAfterMs: 220 },
              { label: "紧急联系电话", field: "emergencyPhone", type: "text", optional: true },
              { label: "英语水平", field: "czbankEnglishLevel", type: "elementSelect" },
              { label: "英语水平补充说明", field: "czbankEnglishNote", type: "text", optional: true },
              { label: "其他语言水平", field: "czbankOtherLanguages", type: "elementCascader", optional: true },
              { label: "计算机水平", field: "czbankComputerLevel", type: "elementCascader", optional: true },
              { label: "职业资格证书", field: "czbankCertificates", type: "elementCascaderCheckbox", forceValue: "无", waitAfterMs: 220 },
              { label: "社交主页名称", field: "czbankHomepageName", type: "text", optional: true },
              { label: "社交主页地址", field: "czbankHomepage", type: "text", optional: true },
              { label: "示例资料", field: "czbankAwards", type: "text", optional: true },
              { label: "培训情况", field: "czbankTraining", type: "text", optional: true },
              { label: "特长及爱好", field: "czbankHobbies", type: "text", optional: true },
              { label: "参加工作日期", field: "czbankWorkStart", type: "elementDate", optional: true },
              { label: "实际工作年限", field: "czbankWorkYears", type: "text", optional: true },
              { label: "金融工作从业年限", field: "czbankBankWorkYears", type: "text", optional: true },
              { label: "现工作单位所属行业", field: "czbankCurrentIndustry", type: "elementSelect", optional: true },
              { label: "现工作单位", field: "czbankCurrentCompany", type: "text", optional: true },
              { label: "所在部门及岗位(职务)", field: "czbankDepartmentPosition", type: "text", optional: true },
              { label: "目前税前年薪(万元)", field: "czbankCurrentAnnualSalary", type: "text", optional: true },
              { label: "期望税前年薪(万元)", field: "czbankExpectedAnnualSalary", type: "text", optional: true },
            ],
          }),
          czbankInlineStep("#comp-2", "教育背景", "示例资料", {
            transformCategoryRows: true,
            rowsTransform: prepareCzbankEducationRows,
            rowSort: compareEducationByStartTime,
            rowTransform: enrichCzbankEducationRow,
            rowScopeSelector: "form.el-form",
            rowAddText: ["+ 添加教育背景", "添加教育背景"],
            rowAddAfterEach: false,
            rowAddWaitMs: 250,
            rowAddTimeoutMs: 1600,
            rowFieldSequence: [
              { label: "学历", field: "czbankLevel", type: "elementSelect", panelTimeoutMs: 1400 },
              { label: "教育类型", field: "示例资料Type", type: "elementSelect", panelTimeoutMs: 1400 },
              { label: "学校名称", field: "school", type: "elementSelect", waitAfterMs: 260, panelTimeoutMs: 3200 },
              { label: "入学时间", field: "startTime", type: "elementDate" },
              { label: "毕业时间", field: "endTime", type: "elementDate" },
              { label: "学位", field: "czbankDegree", type: "elementCascader", optional: true, panelTimeoutMs: 1400, nextOptionTimeoutMs: 1800 },
              { label: "是否最高学位", field: "czbankHighestDegree", type: "elementSelect", optional: true, panelTimeoutMs: 1400 },
              { label: "是否最高学历", field: "czbankHighestEducation", type: "elementSelect", panelTimeoutMs: 1400 },
              { label: "专业类别", field: "czbankMajorCategory", type: "elementCascader", optional: true, panelTimeoutMs: 1400, nextOptionTimeoutMs: 1800 },
              { label: "专业及方向", field: "major", type: "text", optional: true },
              { label: "是否第一学历", field: "czbankFirstEducation", type: "elementSelect", optional: true, panelTimeoutMs: 1400 },
              { label: "最高学历近期综合排名", field: "classRank", type: "elementSelect", optional: true, panelTimeoutMs: 1400 },
            ],
          }),
          czbankInlineStep("#comp-3", "工作/示例资料", ["示例资料Experience", "示例资料Experience"], {
            transformCategoryRows: true,
            rowTransform: enrichCzbankWorkRow,
            rowScopeSelector: "form.el-form",
            rowAddText: "添加工作/示例资料",
            rowAddAfterEach: true,
            rowFieldSequence: [
              { label: "工作类型", field: "示例资料Mode", type: "elementSelect" },
              { label: "单位名称", field: "company", type: "text" },
              { label: "部门", field: "department", type: "text" },
              { label: "职位名称", field: "position", type: "text" },
              { label: "起始时间", field: "startTime", type: "elementDate" },
              { label: "终止时间", field: "endTime", type: "currentEndOrDate" },
              { label: "所在国家", field: "country", type: "elementCascader", waitAfterMs: 220 },
              { label: "所在城市", field: "czbankWorkCity", type: "elementCascader", optional: true, waitAfterMs: 220 },
              { label: "工作描述", field: "achievements", type: "text" },
            ],
          }),
          czbankInlineStep("#comp-4", "示例资料", "示例资料Members", {
            transformCategoryRows: true,
            rowTransform: enrichCzbankFamilyRow,
            rowScopeSelector: "form.el-form",
            rowAddText: ["+ 添加家庭成员", "添加家庭成员", "添加"],
            rowAddAfterEach: false,
            rowFieldSequence: [
              { label: "与本人关系", field: "relationship", type: "elementSelect" },
              { label: "姓名", field: "name", type: "text" },
              { label: "性别", field: "gender", type: "elementSelect" },
              { label: "出生年月", field: "czbankBirthMonth", type: "elementDate" },
              { label: "工作单位及职务", field: "czbankCompanyPosition", type: "text" },
              { label: "政治面貌", field: "politicalStatus", type: "elementSelect" },
              { label: "目前居住国家", field: "country", type: "elementCascader", waitAfterMs: 220 },
              { label: "目前居住城市", field: "示例资料Location", type: "elementCascader", waitAfterMs: 220 },
              { label: "备注", field: "remark", type: "text", optional: true },
            ],
          }),
          czbankInlineStep("#comp-5", "业务专长及承诺", ["示例资料Info", "示例资料Info", "示例资料Introduction"], {
            dataTransform: enrichCzbankCompliance,
            skipSave: true,
            fieldSequence: [
              { label: "专业能力及业务专长，适合从事何种工作", field: "czbankProfessionalExpertise", optional: true },
              { label: "1.是否受过处分或曾被惩诫、开除、辞退？", field: "hasDisciplinaryRecord" },
              { label: "2.是否曾有违法、违规、违纪、涉黑、涉恶或其他不良行为？", field: "hasMisconduct" },
              { label: "3.是否与浙商银行（含总行及辖内各分支机构、子公司）在职员工有近亲属关系？", field: "hasRelativeInCompany" },
              { label: "4.是否患有精神病、传染病及其他严重疾病？", field: "hasSeriousDisease" },
              { label: "5.除了当前应聘志愿，当前发布职位中是否还有其他意向？", field: "hasOtherJobIntention" },
              { label: "6.是否与现单位签订竞业限制或脱密协议？", field: "hasNonCompete" },
              { label: "7.是否有经商办企业或在其他单位兼职？", field: "hasBusinessOrPartTime" },
            ],
          }),
          // 附件上传与“本人承诺”由用户人工完成，不自动上传、勾选或保存。
        ],
      },
    },
    {
      id: "zhaopin-campus-resume",
      brandDomain: "zhaopin.com",
      hostname: "i.zhaopin.com",
      urlPattern: /^https?:\/\/i\.zhaopin\.com\/resume/i,
      pageGuardSelector: ".zp-left-container .示例资料",
      config: {
        name: "i.zhaopin.com",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/i\.zhaopin\.com\/resume/i,
        selectors: {
          container: { class: ".示例资料" },
          title: { class: ".profile-edit-title, .edu-edit-title, .job-target-edit__lab, .示例资料-title, .professional-skills-container" },
          labels: { class: ".profile-edit-title, .profileLib__item-label, .profile-edit-item-label, .edu-edit-title, .job-target-edit__lab, .示例资料-exp-edit-label, .示例资料-edit-title, .示例资料-edit-title, .zp-certificate-edit-status label, .edit-panel-wrap-item-label, label.ivu-checkbox-wrapper" },
          radio: { class: ".zp-radio__item, .ivu-radio-wrapper" },
          checkbox: { class: ".ivu-checkbox-wrapper, input[type='checkbox']" },
          select: { class: ".ivu-select, .select-input" },
          datePicker: { class: ".ivu-date-picker input" },
          upload: { class: "input[type='file']" },
          buttons: {
            add: { class: "[class*='-add'], [class*='addFirst'], [class*='add-null']" },
            edit: { class: ".profile-pre-edit, [class*='__edit'], .zp-edit-icon" },
            save: { class: "button, .save-btn" },
          },
        },
      },
      示例资料flow: {
        id: "zhaopin-campus-resume",
        name: "智联招聘在线简历",
        enabled: true,
        privateSpecialSite: true,
        hostname: "i.zhaopin.com",
        urlPattern: /^https?:\/\/i\.zhaopin\.com\/resume/i,
        pageGuardSelector: ".zp-left-container .示例资料",
        continueOnError: true,
        steps: [
          zhaopinInlineStep("个人优势", "示例资料Introduction", {
            // 个人优势不是 Ant Card。若按通用 cardTitle 分支解析，会在检查
            // .ant-card 时提前返回，永远走不到下面真实存在的新增按钮。
            sectionRootSelector: ".zp-evalution",
            cardTitleSelector: ".zp-evalution-title-text",
            sectionByTitle: true,
            timeoutMs: 3500,
            strictReadyWithinCard: true,
            triggerSelector: ".zp-evalution-edit-icon, .zp-evalution-addFirst",
            triggerText: ["编辑", "添加个人优势"],
            readySelector: ".zp-evalution-edit textarea",
            scopeSelector: ".zp-evalution-edit",
            dataTransform: enrichZhaopinSummary,
            fieldSequence: [
              { label: "优势内容", field: "zhaopinSummary", type: "scopedText", useScopeWhenLabelMissing: true },
            ],
          }),
          zhaopinInlineStep("示例资料", "示例资料", {
            cardSelector: ".resume-job-exp-wrapper",
            cardTitleSelector: ".edu-title-container",
            示例资料ForCategoryData: true,
            rowFilter: isZhaopinSupportedEducationRow,
            rowSort: compareZhaopinEducationRows,
            saveEachRepeatStep: true,
            // 智联承建页面必须严格执行“填一条 -> 保存并更新 -> 再新增”。
            // 部分特殊字段即使已经写入，填充器仍可能把结果标记为 partial。
            // 若不允许 partial 后保存，流程会在点击“保存并更新”之前退出。
            saveOnPartialFill: true,
            // 每次页面只保留一个可见教育编辑器。重复索引代表简历第几条，
            // 不能用它去索引当前唯一的 .edu-edit-panel。
            cardAsScope: true,
            useVisibleRepeatEditorAsScope: true,
            activeRepeatEditorSelector: ".edu-edit-panel",
            waitForCloseSelector: ".edu-edit-panel",
            waitAfterSaveMs: 500,
            saveTimeoutMs: 7000,
            waitForCloseSelector: ".apply-form--edit, form.scrd-web--form-edit",
            waitForCloseTimeoutMs: 8000,
            saveTimeoutMs: 8000,
            wizardAllowPartialFill: true,
            continueOnError: true,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            preferDirectExistingCards: true,
            clearBeforeFillExisting: true,
            removeExtraExistingCardsAfterLast: true,
            existingDeleteActionSelector: ".icon-resume-delete",
            // 智联默认保留的“高中”卡只有 .edu-ul-title，没有高等教育详情列。
            // 它不能占用本科/硕士/博士的位置，否则硕士会被误判为已有第2条。
            existingCardSelector: "li.clearfix:has(.edu-ul-title):has(.edu-ul-txt)",
            existingRecordSelector: "li.clearfix",
            existingEditActionSelector: ".zp-edit-icon",
            existingEditHoverSelector: ".edu-ul-title",
            示例资料AddText: ["添加示例资料"],
            示例资料AddSelector: ".edu-experience-add-right",
            示例资料AddCandidateSelector: "span, div, button, a",
            forceAddFirstRepeatWhenNoExisting: true,
            continueOnError: false,
            keepEditorOnError: true,
            示例资料ReadySelector: ".edu-edit-panel",
            readySelector: ".edu-edit-panel",
            scopeSelector: ".edu-edit-panel",
            rowTransform: enrichZhaopinEducationRow,
            fieldSequence: [
              // 智联的教育表单是分阶段渲染：初始只有学历，选中高中/本科/硕士后
              // 才生成该学历对应的学校、专业和时间字段。必须先选学历并等待新 DOM。
              {
                label: "学历",
                field: "zhaopinLevel",
                type: "zhaopinEducationLevel",
                afterSelectReadySelector: "input[placeholder='请输入学校名称'], input[placeholder='入学时间'], input[placeholder='毕业时间']",
                afterSelectTimeoutMs: 3500,
                waitAfterMs: 300,
              },
              // 学历切换并渲染 MonthPicker 后立即填写时间，
              // 避免学校/专业远程搜索未收口时阻断后续日期。
              { label: "在校时间", field: "startTime", type: "zhaopinEducationDate", inputSelector: "input[placeholder='入学时间']" },
              { label: "在校时间", field: "endTime", type: "zhaopinEducationDate", inputSelector: "input[placeholder='毕业时间']" },
              { label: "学校名称", field: "school", type: "zhaopinSearchSelect", inputSelector: "input[placeholder='请输入学校名称']", optional: true },
              { label: "是否统招", field: "zhaopinUnified", type: "zhaopinChoice", optional: true },
              { label: "学位证书", field: "zhaopinDegreeCertificate", type: "zhaopinChoice", optional: true },
              { label: "所学专业", field: "major", type: "zhaopinSearchSelect", inputSelector: "input[placeholder='请输入专业名称']", optional: true },
              { label: "海外学习经历", field: "zhaopinOverseas", type: "zhaopinCheckbox", optional: true },
            ],
          }),
          zhaopinInlineStep("工作／示例资料", ["示例资料Experience", "示例资料Experience"], {
            cardSelector: ".resume-job-exp-wrapper",
            cardTitleSelector: ".job-exp-title",
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            saveOnPartialFill: true,
            partialSaveBlockedFields: ["company"],
            keepEditorOnError: true,
            cardAsScope: true,
            useVisibleRepeatEditorAsScope: true,
            activeRepeatEditorSelector: ".job-exp-edit-wrapper",
            示例资料ReadyGlobalFallback: true,
            continueNextGroupAfterClosedSaveError: true,
            waitForCloseSelector: ".job-exp-edit-wrapper",
            waitAfterSaveMs: 500,
            saveTimeoutMs: 7000,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            preferDirectExistingCards: true,
            clearBeforeFillExisting: true,
            removeExtraExistingCardsAfterLast: true,
            existingCardSelector: ".job-exp-pre-item",
            existingRecordSelector: ".job-exp-pre-item",
            existingEditActionSelector: ".job-exp-pre-item-edit",
            existingEditHoverSelector: ".job-exp-pre-item",
            existingDeleteActionSelector: ".icon-resume-delete",
            skipRemainingRepeatsOnError: true,
            forceAddFirstRepeatWhenNoExisting: true,
            示例资料AddText: ["添加工作经验"],
            示例资料AddCandidateSelector: "span, div, button, a",
            示例资料ReadySelector: ".job-exp-edit-wrapper input, .job-exp-edit-wrapper textarea",
            readySelector: ".job-exp-edit-wrapper input, .job-exp-edit-wrapper textarea",
            scopeSelector: ".job-exp-edit-wrapper",
            rowTransform: enrichZhaopinWorkRow,
            fieldSequence: [
              { label: "公司名称", field: "company", type: "zhaopinSearchSelect", inputSelector: "input[placeholder='请输入公司名称']", optionSelector: ".s-options__content > li.s-option", fallbackToFirstOption: true, searchWaitMs: 520, optionTimeoutMs: 4200 },
              { label: "所属行业", field: "zhaopinIndustryPath", type: "zhaopinIndustryCascader", triggerSelector: ".job-target-edit__item:nth-of-type(2) .select-input", optional: true },
              { label: "职位名称", field: "zhaopinPositionPath", type: "zhaopinPositionCascader", triggerSelector: ".job-title .select-input" },
              { label: "拥有技能", field: "zhaopinSkillGroups", type: "zhaopinSkillGroups", triggerSelector: ".job-exp-edit-item__skill-labels", replaceExisting: true, optional: true },
              { label: "在职时间", field: "startTime", type: "zhaopinEducationDate", inputSelector: "input[placeholder='入职时间']" },
              { label: "在职时间", field: "endTime", type: "zhaopinWorkEndDate", inputSelector: "input[placeholder='离职时间']" },
              { label: "工作描述", field: "zhaopinWorkDescription", type: "zhaopinText", inputSelector: "textarea[placeholder*='请输入工作内容']" },
              { label: "本经历是示例资料", field: "zhaopinInternship", type: "zhaopinCheckbox" },
            ],
          }),
          zhaopinInlineStep("项目经历", ["示例资料Experience", "campusActivities"], {
            cardSelector: ".resume-示例资料-exp-wrapper",
            cardTitleSelector: ".示例资料-exp-title",
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            saveOnPartialFill: true,
            partialSaveBlockedFields: ["name"],
            keepEditorOnError: true,
            cardAsScope: true,
            useVisibleRepeatEditorAsScope: true,
            activeRepeatEditorSelector: ".示例资料-exp-edit-wrapper",
            示例资料ReadyGlobalFallback: true,
            continueNextGroupAfterClosedSaveError: true,
            waitForCloseSelector: ".示例资料-exp-edit-wrapper",
            waitAfterSaveMs: 500,
            saveTimeoutMs: 7000,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            preferDirectExistingCards: true,
            clearBeforeFillExisting: true,
            removeExtraExistingCardsAfterLast: true,
            existingCardSelector: ".示例资料-exp-pre-item",
            existingRecordSelector: ".示例资料-exp-pre-item",
            existingEditActionSelector: ".示例资料-exp-pre-item-edit",
            existingEditHoverSelector: ".示例资料-exp-pre-item",
            existingDeleteActionSelector: ".icon-resume-delete",
            skipRemainingRepeatsOnError: true,
            forceAddFirstRepeatWhenNoExisting: true,
            示例资料AddText: ["添加项目经历"],
            示例资料AddCandidateSelector: "span, div, button, a",
            示例资料ReadySelector: ".示例资料-exp-edit-wrapper input, .示例资料-exp-edit-wrapper textarea",
            readySelector: ".示例资料-exp-edit-wrapper input, .示例资料-exp-edit-wrapper textarea",
            scopeSelector: ".示例资料-exp-edit-wrapper",
            rowTransform: enrichZhaopinProjectRow,
            fieldSequence: [
              { label: "项目名称", field: "name", type: "zhaopinText", inputSelector: "input[placeholder='必填']" },
              { label: "项目时间", field: "startTime", type: "zhaopinEducationDate", inputSelector: "input[placeholder='选择开始时间']" },
              { label: "项目时间", field: "endTime", type: "zhaopinWorkEndDate", inputSelector: "input[placeholder='选择结束时间']" },
              { label: "项目描述", field: "zhaopinProjectDescription", type: "zhaopinText", inputSelector: "textarea[placeholder*='更完善的项目信息']" },
            ],
          }),
          zhaopinInlineStep("示例资料", "示例资料Experience", {
            cardSelector: ".resume-示例资料-exp-wrapper",
            cardTitleSelector: ".示例资料-title",
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            forceAddFirstRepeatWhenNoExisting: true,
            示例资料AddText: ["添加示例资料"],
            示例资料AddCandidateSelector: "div, span, button, a",
            示例资料ReadySelector: ".resume-示例资料-exp-wrapper input",
            readySelector: ".resume-示例资料-exp-wrapper input",
            scopeSelector: ".resume-示例资料-exp-wrapper",
            fieldSequence: [
              { label: "开始时间", field: "startTime", type: "yearMonth" },
              { label: "结束时间", field: "endTime", type: "currentEndOrDate" },
              { label: "培训机构", field: "organization", type: "text" },
              { label: "培训课程", field: "name", type: "text" },
            ],
          }),
          zhaopinInlineStep("语言能力", "示例资料Skills", {
            cardSelector: ".zp-wrap",
            sectionRootSelector: ".zp-wrap:has(.zp-示例资料)",
            cardTitleSelector: ".zp-示例资料",
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            cardAsScope: true,
            useVisibleRepeatEditorAsScope: true,
            activeRepeatEditorSelector: ".示例资料-edit-panel",
            示例资料ReadyGlobalFallback: true,
            waitForCloseSelector: ".示例资料-edit-panel",
            waitAfterSaveMs: 400,
            saveTimeoutMs: 6000,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            preferDirectExistingCards: true,
            clearBeforeFillExisting: true,
            removeExtraExistingCardsAfterLast: true,
            existingDeleteActionSelector: ".icon-resume-delete",
            existingCardSelector: ".zp-示例资料-list > ul > li.clearfix",
            existingRecordSelector: "li.clearfix",
            existingEditActionSelector: ".zp-edit-icon",
            existingEditHoverSelector: ".zp-示例资料-name",
            forceAddFirstRepeatWhenNoExisting: true,
            示例资料AddText: ["添加语言能力"],
            示例资料AddSelector: ".zp-示例资料-add-right",
            示例资料AddCandidateSelector: "div, span, button, a",
            示例资料ReadySelector: ".示例资料-edit-panel .ivu-select",
            readySelector: ".示例资料-edit-panel .ivu-select",
            scopeSelector: ".示例资料-edit-panel",
            skipRemainingRepeatsOnError: true,
            keepEditorOnError: true,
            rowTransform: enrichZhaopinLanguageRow,
            fieldSequence: [
              { label: "语种", field: "zhaopinLanguage", type: "customSelect" },
              { label: "听说能力", field: "zhaopinSpeaking", type: "customSelect" },
              { label: "读写能力", field: "zhaopinReading", type: "customSelect" },
            ],
          }),
          zhaopinInlineStep("证书", ["示例资料", "示例资料Skills"], {
            cardSelector: ".zp-certificate",
            sectionRootSelector: ".zp-certificate",
            示例资料ForCategoryData: true,
            rowsTransform: mergeZhaopinCertificateRows,
            saveEachRepeatStep: true,
            saveOnPartialFill: true,
            partialSaveBlockedFields: ["certificateName"],
            cardAsScope: true,
            useVisibleRepeatEditorAsScope: true,
            activeRepeatEditorSelector: ".zp-certificate-edit-status",
            示例资料ReadyGlobalFallback: true,
            waitForCloseSelector: ".zp-certificate-edit-status",
            waitAfterSaveMs: 400,
            saveTimeoutMs: 6000,
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            preferDirectExistingCards: true,
            clearBeforeFillExisting: true,
            removeExtraExistingCardsAfterLast: true,
            existingCardSelector: ".zp-certificate-list-item",
            existingRecordSelector: ".zp-certificate-list-item",
            existingEditActionSelector: ".certificate-edit",
            existingEditHoverSelector: ".zp-certificate-list-item",
            existingDeleteActionSelector: ".icon-resume-delete",
            forceAddFirstRepeatWhenNoExisting: true,
            示例资料AddText: ["添加证书"],
            示例资料AddCandidateSelector: "div, span, button, a",
            示例资料ReadySelector: ".zp-certificate-edit-status input[placeholder='必填']",
            readySelector: ".zp-certificate-edit-status input[placeholder='必填']",
            scopeSelector: ".zp-certificate-edit-status",
            skipRemainingRepeatsOnError: true,
            keepEditorOnError: true,
            continueNextGroupAfterClosedSaveError: true,
            fieldSequence: [
              {
                label: "证书名称",
                field: "certificateName",
                type: "zhaopinSearchSelect",
                inputSelector: "input[placeholder='必填']",
                autocompletePanelSelector: ".ivu-select-dropdown",
                optionSelector: ".ivu-select-dropdown .ivu-select-item",
                allowPlainText: true,
                searchWaitMs: 420,
                optionTimeoutMs: 2200,
              },
            ],
          }),
          zhaopinInlineStep("学生干部经历", "campusLeadership", {
            cardSelector: ".示例资料-cadre-index",
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            forceAddFirstRepeatWhenNoExisting: true,
            示例资料AddText: ["添加学生干部经历"],
            示例资料AddCandidateSelector: "div, span, button, a",
            示例资料ReadySelector: ".示例资料-cadre-index input, .示例资料-cadre-index textarea",
            readySelector: ".示例资料-cadre-index input, .示例资料-cadre-index textarea",
            scopeSelector: ".示例资料-cadre-index",
            fieldSequence: [
              { label: "开始时间", field: "startTime", type: "yearMonth" },
              { label: "结束时间", field: "endTime", type: "currentEndOrDate" },
              { label: "组织名称", field: "organization", type: "text" },
              { label: "担任职务", field: "position", type: "text" },
              { label: "经历描述", field: "description", type: "text", optional: true },
            ],
          }),
          // 联系方式、电子邮箱和头像属于账号级资料，不由自动填写处理。
          // 学生身份下的参加工作时间也保持站点原状。
          zhaopinInlineStep("示例资料", "示例资料Info", {
            sectionRootSelector: ".profile-pre",
            triggerSelector: ".profile-pre-edit",
            readySelector: ".profile-edit-wrapper",
            scopeSelector: ".profile-edit-wrapper",
            waitForCloseSelector: ".profile-edit-wrapper",
            dataTransform: enrichZhaopinBasicInfo,
            fieldSequence: [
              { label: "姓名", field: "name", type: "text" },
              { label: "性别", field: "gender", type: "zhaopinChoice" },
              { label: "当前身份", field: "zhaopinIdentity", type: "zhaopinChoice", optional: true },
              { label: "出生年月", field: "zhaopinBirthMonth", type: "zhaopinEducationDate", inputSelector: "input[placeholder='请选择生日，用于投递简历']" },
              { label: "户口所在地", field: "zhaopinHukouPath", type: "zhaopinAdministrativeArea", triggerSelector: ".job-target-edit__item:nth-of-type(1) .select-input", optional: true },
              { label: "现居住城市", field: "zhaopinCurrentAddressPath", type: "zhaopinAdministrativeArea", triggerSelector: ".job-target-edit__item:nth-of-type(2) .select-input", optional: true },
              { label: "政治面貌", field: "zhaopinPoliticalStatus", type: "customSelect", optional: true },
            ],
          }),
        ],
      },
    },
    zhaopinCampusEnterpriseEntry({
      id: "zhaopin-psbc-campus-resume-v1",
      name: "智联校园企业表单（中国邮政储蓄银行）",
      configName: "xiaoyuan.zhaopin.com/scrd/resume2/psbc",
      urlPattern: /^https?:\/\/xiaoyuan\.zhaopin\.com\/scrd\/resume2(?=[?#]|$)(?=[^#]*[?&]cid=(?:10134769|10134773|10138584)(?:&|#|$))/i,
      autoContinueAcrossPages: true,
      orderedContinuation: true,
      clearContinuationOnComplete: true,
      stepOptions: {
        triggerRootSelector: ".resume-right",
        navigationTriggerCandidateSelector: ".resume-menu-item, .resume-menu-item__title",
        navigateWhenNoData: true,
        postbackAutoContinueWorkflowId: "zhaopin-psbc-campus-resume-v1",
      },
      modules: [
        {
          title: "个人信息",
          category: "示例资料Info",
          kind: "示例资料",
          options: {
            dataTransform: enrichZhaopinPsbcBasic,
            fieldSequence: zhaopinPsbcBasicFieldSequence(),
          },
        },
        {
          title: "家庭关系",
          category: "示例资料Members",
          kind: "示例资料",
          options: {
            示例资料ForCategoryData: false,
            useVisibleRepeatEditorAsScope: false,
            dataTransform: enrichZhaopinPsbcFamily,
            fieldSequence: zhaopinPsbcFamilyFieldSequence(),
          },
        },
        {
          title: "校园经历",
          category: ["campusActivities", "示例资料", "示例资料Experience", "publications", "示例资料s"],
          kind: "campusSummary",
          options: {
            示例资料ForCategoryData: false,
            skipIfNoResumeData: false,
            useVisibleRepeatEditorAsScope: false,
            dataTransform: enrichZhaopinPsbcCampusExperience,
            fieldSequence: zhaopinPsbcCampusExperienceFieldSequence(),
            minimumFilledFields: 4,
          },
        },
        {
          title: "实习/示例资料",
          category: ["示例资料Experience"],
          kind: "示例资料",
          options: {
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            preferDirectExistingCards: true,
            existingCardSelector: ".apply-module__form > .apply-form:has(.icon-box)",
            existingRecordSelector: ".apply-form",
            existingEditActionSelector: ".icon-box",
            rowSort: compareZhaopinPsbcWorkRows,
            rowTransform: enrichZhaopinPsbcWork,
            fieldSequence: zhaopinPsbcWorkFieldSequence(),
          },
        },
        {
          title: "奖励活动",
          category: ["示例资料", "示例资料"],
          kind: "rewardSummary",
          options: {
            示例资料ForCategoryData: false,
            skipIfNoResumeData: false,
            useVisibleRepeatEditorAsScope: false,
            dataTransform: enrichZhaopinPsbcRewards,
            fieldSequence: zhaopinPsbcRewardFieldSequence(),
            minimumFilledFields: 2,
          },
        },
        {
          title: "技能/爱好",
          category: "示例资料Skills",
          kind: "skillSummary",
          options: {
            示例资料ForCategoryData: false,
            skipIfNoResumeData: false,
            useVisibleRepeatEditorAsScope: false,
            dataTransform: enrichZhaopinPsbcSkills,
            fieldSequence: zhaopinPsbcSkillFieldSequence(),
            minimumFilledFields: 9,
          },
        },
        {
          title: "自我评价",
          category: "示例资料Introduction",
          kind: "示例资料Evaluation",
          options: {
            示例资料ForCategoryData: false,
            useVisibleRepeatEditorAsScope: false,
            dataTransform: enrichZhaopinPsbcSelfEvaluation,
            fieldSequence: zhaopinPsbcSelfEvaluationFieldSequence(),
            minimumFilledFields: 1,
          },
        },
        {
          title: "示例资料",
          category: "示例资料",
          kind: "示例资料",
          options: {
            updateExistingWhenPresent: true,
            overwriteExistingByPosition: true,
            preferDirectExistingCards: true,
            existingCardSelector: ".apply-module__form > .apply-form:has(.icon-box)",
            existingRecordSelector: ".apply-form",
            existingEditActionSelector: ".icon-box",
            rowFilter: isZhaopinPsbcEducationRow,
            rowSort: compareZhaopinPsbcEducationRows,
            rowTransform: enrichZhaopinPsbcEducation,
            fieldSequence: zhaopinPsbcEducationFieldSequence(),
            beforeSaveEnsureFields: zhaopinPsbcEducationBeforeSaveFields(),
            blockSaveUntilField: "zhaopinPsbcSecondDegree",
            failOnMissingRequiredValue: true,
            wizardAllowPartialFill: true,
          },
        },
      ],
    }),
    {
      id: "zhaopin-unicom-campus-resume-v1",
      brandDomain: "zhaopin.com",
      hostname: "xiaoyuan.zhaopin.com",
      urlPattern: /^https?:\/\/xiaoyuan\.zhaopin\.com\/scrd\/resume2(?=[?#]|$)(?=[^#]*[?&]cid=10128896(?:&|#|$))/i,
      pageGuardSelector: "body",
      config: {
        name: "xiaoyuan.zhaopin.com/scrd/resume2",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/xiaoyuan\.zhaopin\.com\/scrd\/resume2(?=[?#]|$)(?=[^#]*[?&]cid=10128896(?:&|#|$))/i,
        selectors: {
          container: { class: ".apply-module" },
          section: ".apply-module",
          title: { class: ".form-content--title" },
          labels: { class: ".el-form-item__label, .form-item__label, label" },
          radio: { class: ".el-radio, .el-radio-group, input[type='radio']" },
          checkbox: { class: ".el-checkbox, input[type='checkbox']" },
          select: { class: ".el-select, .el-input, select" },
          datePicker: { class: ".el-date-editor input, input[placeholder*='日期']" },
          address: { class: ".el-cascader, .el-input" },
          upload: { class: "input[type='file']" },
          buttons: { add: {}, edit: { class: ".apply-module button" }, save: { class: ".apply-module button" } },
        },
      },
      示例资料flow: {
        id: "zhaopin-unicom-campus-resume-v1",
        name: "智联校园企业表单（中国联通）",
        enabled: true,
        privateSpecialSite: true,
        hostname: "xiaoyuan.zhaopin.com",
        urlPattern: /^https?:\/\/xiaoyuan\.zhaopin\.com\/scrd\/resume2(?=[?#]|$)(?=[^#]*[?&]cid=10128896(?:&|#|$))/i,
        pageGuardSelector: "body",
        continueOnError: true,
        notices: ["中国联通表单按左侧大类逐项进入：先打开编辑，完成后点击保存，再进入下一类。附件不自动上传。"],
        steps: [
          ["个人信息", "示例资料Info"],
          ["家庭关系", "示例资料Members"],
          ["校园经历", ["campusLeadership", "campusActivities"]],
          ["实习/示例资料", ["示例资料Experience", "示例资料Experience"]],
          ["奖励活动", ["示例资料", "campusLeadership", "示例资料", "campusActivities"]],
          ["技能/爱好", "示例资料Skills"],
          ["自我评价", "示例资料Introduction"],
          ["示例资料", "示例资料"],
        ].map(function (entry) {
          return zhaopinInlineStep(entry[0], entry[1], {
            preferNavigationTrigger: true,
            directMenuNavigation: true,
            handleNavigationSavePrompt: true,
            navigationPromptTimeoutMs: 1800,
            triggerText: [entry[0]],
            navigationTriggerCandidateSelector: ".resume-menu-item, .resume-menu-item__title, h6",
            cardTitle: entry[0],
            cardTitleSelector: ".form-content--title",
            sectionRootSelector: ".apply-module",
            sectionByTitle: true,
            dataTransform: entry[0] === "个人信息" ? enrichZhaopinUnicomBasic : null,
            rowFilter: entry[0] === "示例资料" ? isZhaopinSupportedEducationRow : undefined,
            rowTransform: entry[0] === "示例资料"
              ? enrichZhaopinUnicomEducation
              : (entry[0] === "实习/示例资料" ? enrichZhaopinUnicomWork : undefined),
            rowsTransform: entry[0] === "奖励活动" ? buildZhaopinUnicomRewardRows : undefined,
            fieldSequence: entry[0] === "个人信息"
              ? zhaopinUnicomBasicFieldSequence()
              : (entry[0] === "示例资料"
                ? zhaopinUnicomEducationFieldSequence()
                : (entry[0] === "实习/示例资料"
                  ? zhaopinUnicomWorkFieldSequence()
                  : (entry[0] === "奖励活动" ? zhaopinUnicomRewardFieldSequence() : undefined))),
            ...(entry[0] === "技能/爱好" ? { fieldSequence: zhaopinUnicomSkillFieldSequence() } : {}),
            示例资料ForCategoryData: /示例资料|校园经历|实习\/示例资料|项目经历|奖励活动|家庭关系/.test(entry[0]),
            saveEachRepeatStep: true,
            minimumFilledFields: entry[0] === "奖励活动" ? 1 : 0,
            示例资料AddSelector: ".form-content--title-box .icon-box",
            示例资料AddSelectors: [".form-content--title-box .icon-box.icon-box-only", ".form-content--title-box .icon-box", ".no-data .add-now"],
            示例资料AddText: ["添加"],
            示例资料AddCandidateSelector: "button, a, span, i, div",
            示例资料AddRootSelector: "",
            示例资料AddNativeClick: true,
            forceAddFirstRepeatWhenNoExisting: true,
            示例资料ReadySelector: ".apply-module__form form.scrd-web--form-edit",
            editExistingSectionWhenClosed: true,
            afterClickActionText: ["编辑", "添加", "立即添加"],
            afterClickActionRootSelector: "",
            afterClickActionCandidateSelector: "button, a, [role='button'], span",
            readySelector: ".apply-module__form",
            scopeSelector: ".apply-module__form",
            readyEditableSelector: "input, textarea, select",
            strictReadyWithinCard: true,
            skipClickWhenReady: false,
            saveSelector: ".apply-module__form button.el-button--primary",
            saveText: ["保 存", "保存", "保存并更新"],
            示例资料SubmitSelector: ".apply-module__form form.scrd-web--form-edit .btn-box button.el-button--primary",
            示例资料SubmitText: ["添 加", "添加"],
            useVisibleRepeatEditorAsScope: /示例资料|校园经历|实习\/示例资料|项目经历|奖励活动|家庭关系/.test(entry[0]),
            waitForCloseSelector: ".apply-form--edit, form.scrd-web--form-edit",
            waitForCloseTimeoutMs: 7000,
            waitAfterClickMs: 450,
            waitAfterActionMs: 150,
            waitAfterSaveMs: 500,
            saveTimeoutMs: 7000,
            waitForSaveSuccess: true,
            saveSuccessTimeoutMs: 5000,
            saveSuccessOptional: true,
            waitBeforeNextMs: /示例资料|校园经历|实习\/示例资料|项目经历|奖励活动|家庭关系/.test(entry[0]) ? 450 : 1200,
            stopOnSaveError: true,
          });
        }),
      },
    },
    zhaopinCampusEnterpriseEntry({
      id: "zhaopin-campus-cetc38-resume-v1",
      name: "智联校园企业网申（中国电科38所）",
      configName: "xiaoyuan.zhaopin.com/scrd/resume2/cetc38",
      urlPattern: /^https?:\/\/xiaoyuan\.zhaopin\.com\/scrd\/resume2(?=[?#]|$)(?=[^#]*[?&]cid=10062826(?:&|#|$))/i,
      modules: [
        { title: "个人信息", category: "示例资料Info", kind: "示例资料" },
        { title: "示例资料", category: "示例资料", kind: "示例资料" },
        { title: "示例资料", category: "jobIntention", kind: "jobIntention" },
        { title: "实习/示例资料", category: ["示例资料Experience", "示例资料Experience"], kind: "示例资料" },
        { title: "项目经验", category: "示例资料Experience", kind: "示例资料" },
        { title: "奖励荣誉", category: "示例资料", kind: "示例资料" },
        { title: "语言能力", category: "示例资料Skills", kind: "示例资料" },
        { title: "专业技能", category: "示例资料", kind: "示例资料" },
        { title: "示例资料", category: ["示例资料Introduction", "示例资料Info"], kind: "示例资料" },
      ],
    }),
    zhaopinCampusEnterpriseEntry({
      id: "zhaopin-campus-enterprise-resume-v1",
      name: "智联校园企业网申（公共模板）",
      urlPattern: /^https?:\/\/xiaoyuan\.zhaopin\.com\/scrd\/resume2(?:[?#]|$)/i,
    }),
    {
      id: "icbc-recruitment",
      brandDomain: "icbc.com.cn",
      hostname: "job.icbc.com.cn",
      urlPattern: /^https?:\/\/job\.icbc\.com\.cn\/pc\/index\.html/,
      pageGuardSelector: "[class*='menu___'] > [class*='menu__item___']",
      config: {
        name: "job.icbc.com.cn",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/job\.icbc\.com\.cn\/pc\/index\.html/,
        selectors: {
          container: { class: "[class*='content__right']" },
          title: { class: "[class*='menu__item--active']" },
          labels: { class: ".ant-form-item-label > label, [class*='picker__label']" },
          radio: { class: ".ant-radio-wrapper, .ant-radio-group" },
          checkbox: { class: ".ant-checkbox-wrapper, input[type='checkbox']" },
          select: { class: ".ant-select, .ant-select-selection" },
          datePicker: { class: ".ant-calendar-picker, .ant-calendar-picker-input" },
          address: { class: ".ant-cascader-picker, .ant-select" },
          upload: { class: ".ant-upload, input[type='file']" },
          buttons: {
            add: { class: "button[class^='add-btn___'], button[class*=' add-btn___']" },
            edit: {},
          },
        },
        experience: {
          container: { containerSelector: "[class*='content__right']" },
          card: { cardSelector: "[class^='form-wrapper___'], [class*=' form-wrapper___']" },
          add: {
            addButtonSelector: "button[class^='add-btn___'], button[class*=' add-btn___']",
            addButtonText: ["添加示例资料", "添加示例资料", "添加示例资料", "添加"],
            addTimeoutMs: 700,
          },
          save: {
            requiresSaveBeforeNext: false,
            allowAutoSave: false,
          },
          editor: {
            cardEditButtonSelector: "",
            cardEditButtonText: [],
            editModeGuardSelector: "form.ant-form",
            editTimeoutMs: 300,
          },
        },
      },
      示例资料flow: {
        id: "icbc-recruitment",
        name: "工商银行招聘简历",
        enabled: true,
        privateSpecialSite: true,
        hostname: "job.icbc.com.cn",
        urlPattern: /^https?:\/\/job\.icbc\.com\.cn\/pc\/index\.html/,
        pageGuardSelector: "[class*='menu___'] > [class*='menu__item___']",
        continueOnError: true,
        steps: icbcExecutionSteps([
          icbcStep(1, "个人示例资料", "示例资料Info", {
            dataTransform: enrichIcbcBasicInfo,
            fieldSequence: [
              // 姓名、电话、邮箱、国籍、证件和出生日期由注册资料锁定，保留页面原值。
              { label: "是否拥有外国国籍、国（境）外永久居留权或长住许可", field: "icbcForeignResidencePermit", type: "radio", optional: true },
              { label: "性别", field: "gender", type: "radio", optional: true },
              { label: "民族", field: "ethnicity", type: "elementSelect", optional: true },
              { label: "籍贯", field: "icbcNativePlacePath", type: "icbcLinkedSelect", optional: true },
              { label: "高考生源地", field: "icbcBirthOriginPath", type: "icbcLinkedSelect", optional: true },
              { label: "户口所在地", field: "icbcHukouLocationPath", type: "icbcLinkedSelect", optional: true },
              { label: "家庭住址", field: "示例资料Address", pathField: "icbcFamilyAddressPath", type: "icbcAddress", dynamicLevels: true, optional: true },
              { label: "身高（厘米）", field: "height", type: "text", optional: true },
              { label: "体重（公斤）", field: "weight", type: "text", optional: true },
              { label: "政治面貌", field: "politicalStatus", type: "elementSelect", optional: true },
              { label: "健康状况", field: "healthStatus", type: "elementSelect", optional: true },
              { label: "是否有精神病、传染病、生理缺陷及其他严重疾病", field: "icbcSeriousDisease", type: "radio", optional: true },
              { label: "应届毕业时间", field: "graduationDate", type: "date", selector: "#graduateYear input", optional: true },
              { label: "紧急联系人", field: "emergencyContactName", type: "text", optional: true },
              { label: "紧急联系人电话", field: "emergencyPhone", type: "text", optional: true },
            ],
          }),
          icbcStep(2, "示例资料", "示例资料", {
            customFill: "icbcEducation",
            // 保存按钮属于 resume-edit 页面顶部操作区，不在教育卡片容器内。
            // 教育字段填完后点击“保 存”，但不点击“下一步”。选填字段未匹配
            // 时仍允许提交，避免页面显示已填却因局部字段失败而完全不落库。
            saveSelector: "[class*='right__action___'] button.ant-btn:not(.ant-btn-primary)",
            saveText: ["保 存", "保存"],
            saveOnPartialFill: true,
            waitAfterSaveMs: 600,
            // 该大类同时包含固定的“最高学历”卡和可重复教育卡，不能让
            // 示例资料ForCategoryData 的空行判断把只有一条最高学历的简历跳过。
            示例资料ForCategoryData: false,
            rowsTransform: icbcEducationRows,
            rowTransform: enrichIcbcEducationRow,
            rowScopeSelector: ".wrapper___mC8a8 > [class*='highest-edu-form___']:has(#highestEdu), .wrapper___mC8a8 > [class*='form-wrapper___']:has([id^='schoolAge#']), .wrapper___mC8a8 > [class*='form-wrapper___']:has([id^='highSchool#'])",
            rowAddSelector: "button[class*='add-btn___']",
            rowAddText: ["+ 添加其他高校示例资料", "+ 添加其他高中示例资料", "添加其他高校示例资料", "添加其他高中示例资料"],
            rowAddAfterEach: false,
            rowAddWaitMs: 500,
            rowFieldSequence: [
              { label: ["最高学历", "学历"], field: "icbcEducationLevel", type: "elementSelect", selector: "#highestEdu, [id^='schoolAge#']", when: function (row) { return !isIcbcHighSchoolRow(row); } },
              { label: "是否主要经历", field: "icbcIsMajor", type: "radio", optional: true },
              { label: "学历类型", field: "icbcEducationType", type: "elementSelect", selector: "[id^='schoolAgeType#']", optional: true, when: function (row) { return !isIcbcHighSchoolRow(row); } },
              { label: "学位", field: "icbcDegree", type: "elementSelect", selector: "[id^='degree#']", optional: true, when: function (row) { return !isIcbcHighSchoolRow(row); } },
              { label: "学位类型", field: "icbcDegreeType", type: "elementSelect", selector: "[id^='degreeType#']", optional: true, when: function (row) { return !isIcbcHighSchoolRow(row); } },
              { label: "是否双学位", field: "icbcIsDoubleDegree", type: "radio", optional: true, when: function (row) { return !isIcbcHighSchoolRow(row); } },
              { label: "是否专升本", field: "icbcIsAssociateToBachelor", type: "radio", optional: true, when: function (row) { return !isIcbcHighSchoolRow(row); } },
              { label: "入学时间", field: "startTime", type: "icbcDate", dateIndex: 0 },
              { label: "毕业时间", field: "endTime", type: "icbcDate", dateIndex: 1 },
              { label: ["学校名称", "高中毕业院校"], field: "school", type: "icbcSchoolSearch", selector: "[id^='schoolName#']", optional: true, when: function (row) { return !isIcbcHighSchoolRow(row); } },
              { label: "高中毕业院校", field: "school", type: "icbcHighSchool", pathField: "schoolLocationPath", optional: true, when: isIcbcHighSchoolRow },
              { label: "学校所在地", field: "icbcSchoolPlace", type: "text", optional: true, when: function (row) { return !isIcbcHighSchoolRow(row); } },
              { label: ["学院（选填）", "学院"], field: "department", type: "text", optional: true, when: function (row) { return !isIcbcHighSchoolRow(row); } },
              { label: "主修专业", field: "major", type: "icbcMajor", pathField: "icbcMajorPath", optional: true, when: function (row) { return !isIcbcHighSchoolRow(row); } },
              // 页面同时渲染了同 id 的占位 span 和真正的 Ant Select，必须
              // 限定 .ant-select，避免拿到占位节点导致排名下拉不触发。
              { label: "班级排名", field: "icbcClassRank", type: "elementSelect", selector: ".ant-select[id^='classRanking#']", optional: true, when: function (row) { return !isIcbcHighSchoolRow(row); } },
              { label: "是否是学生干部", field: "icbcIsCadre", type: "radio", optional: true, when: function (row) { return !isIcbcHighSchoolRow(row); } },
            ],
          }),
          icbcStep(3, "语言能力", "示例资料Skills"),
          icbcStep(4, "荣誉或奖励", "示例资料"),
          icbcStep(5, "学术成果", "publications"),
          icbcStep(6, "资格认证", "示例资料", {
            // 资格认证页只有一个“职业资格认证”Ant Select；用证书数组的
            // 第一条名称填入，后续证书仍保留在简历数据中供其他站点使用。
            dataTransform: enrichIcbcCertificateRow,
            fieldSequence: [
              { label: "职业资格认证", field: "icbcCertificateName", type: "elementSelect", optional: true },
            ],
          }),
          icbcStep(7, "工作（实习）经历", ["示例资料Experience", "示例资料Experience"]),
          icbcStep(8, "自我评价", "示例资料Introduction"),
          icbcStep(9, "家庭关系", "示例资料Members"),
          icbcStep(10, "工作意向", "jobIntention"),
        ]),
      },
    },
    {
      id: "abc-recruitment",
      brandDomain: "abchina.com",
      hostname: "career.abchina.com.cn",
      urlPattern: /^https?:\/\/career\.abchina\.com\.cn\/build\/index\.html#\/MyResume/i,
      pageGuardSelector: ".ant-card .ant-card-head-title",
      config: {
        name: "career.abchina.com.cn",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/career\.abchina\.com\.cn\/build\/index\.html#\/MyResume/i,
        selectors: {
          container: { class: ".ant-modal-content" },
          title: { class: ".ant-modal-title" },
          labels: { class: ".ant-form-item-label > label" },
          radio: { class: ".ant-radio-wrapper, .ant-radio-group" },
          checkbox: { class: ".ant-checkbox-wrapper, input[type='checkbox']" },
          select: { class: ".ant-select, .ant-select-selection" },
          datePicker: { class: ".ant-calendar-picker, .ant-calendar-picker-input" },
          address: { class: ".ant-cascader-picker, .ant-input.ant-cascader-input" },
          upload: { class: ".ant-upload, input[type='file']" },
          buttons: { add: {}, edit: {} },
        },
      },
      示例资料flow: {
        id: "abc-recruitment",
        name: "农业银行招聘简历",
        enabled: true,
        privateSpecialSite: true,
        hostname: "career.abchina.com.cn",
        urlPattern: /^https?:\/\/career\.abchina\.com\/build\/index\.html#\/MyResume/i,
        pageGuardSelector: ".ant-card .ant-card-head-title",
        continueOnError: true,
        steps: [
          abcModalStep("示例资料", "示例资料Info", "编辑", {
            enabled: false,
            dataTransform: enrichAbcBasicInfo,
            preFieldSequence: [
              { label: ["户口所在地", "户籍所在地"], type: "cascader", dataFields: ["abcHukouProvince", "abcHukouCity", "abcHukouDistrict"], optional: true, waitAfterMs: 350, optionTimeoutMs: 5000, waitAfterOpenMs: 350, waitAfterOptionMs: 300 },
            ],
          }),
          abcModalStep("教育背景", "示例资料", "添加", {
            示例资料ForCategoryData: true,
            saveOnPartialFill: true,
            rowSort: compareAbcEducationRows,
            rowsValidator: validateAbcEducationRows,
            // 兼容用户在新增这些级联字段前已经导入到 chrome.storage 的旧简历。
            rowTransform: enrichAbcEducationRow,
            fieldSequence: [
              { label: "取得学历", field: "level", waitAfterMs: 250 },
              { label: "所获学位", field: "degree", waitAfterMs: 200, optional: true },
              { label: "入学时间", field: "startTime" },
              { label: "毕业时间", field: "endTime" },
              { label: "学校名称", type: "cascader", dataFields: ["schoolProvince", "school"], waitAfterMs: 500, when: function (row) { return !isPreHigherEducation(row); } },
              { label: "学校名称", field: "school", waitAfterMs: 250, when: function (row) { return isPreHigherEducation(row); } },
              { label: "院系名称", field: "department", waitAfterMs: 300, optional: true },
              { label: "具体专业", type: "abcMajorWithOther", dataFields: ["majorCategory", "majorSubcategory", "major"], majorField: "major", bridgeTimeoutMs: 12000, optionTimeoutMs: 5000, optional: true, when: function (row) { return !isPreHigherEducation(row); } },
              { label: "教育类型", field: "示例资料Type", when: function (row) { return !isPreHigherEducation(row); } },
            ],
          }),
          abcModalStep("示例资料", "示例资料Skills", "添加", {
            示例资料ForCategoryData: true,
            fieldSequence: [
              { label: "外语类别", field: "name", waitAfterMs: 250 },
              { label: "外语等级", field: "certificateName", targetField: "level", waitAfterMs: 250 },
              { label: "具体成绩", field: "score" },
              { label: "获证日期", field: "obtainedTime" },
              { label: "其他说明", field: "description", optional: true },
            ],
          }),
          abcModalStep("奖励情况", "示例资料", "添加", {
            示例资料ForCategoryData: true,
            // 卡片标题是“奖励情况”，但实际编辑弹窗标题是“奖励信息”。
            // 不显式指定时 readyText 默认取卡片标题，弹窗打开后会一直等待错误标题。
            readyText: "奖励信息",
            // 农行奖励弹窗的标签是“奖励时间/奖励级别/奖励名称/说明”，
            // 与简历模型的“获奖经历”字段名称不完全一致，使用真实控件 ID
            // 避免通用模糊匹配漏掉日期和说明。
            fieldSequence: [
              { label: "奖励时间", field: "awardTime", type: "date", selector: "#rewardDate input" },
              { label: "奖励级别", field: "awardLevel", type: "select", selector: "#rewardLevel" },
              { label: "奖励名称", field: "awardName", type: "text", selector: "#rewardName" },
              { label: "说明", field: "awardDescription", type: "text", selector: "#instructions", optional: true },
            ],
          }),
          abcModalStep("示例资料", "jobIntention", "编辑"),
          abcModalStep("学生干部任职情况", "campusLeadership", "添加", {
            示例资料ForCategoryData: true,
            rowTransform: enrichAbcCampusLeadershipRow,
            fieldSequence: [
              { label: "开始时间", field: "startTime" },
              { label: "结束时间", field: "endTime" },
              { label: "职务级别", field: "abcLeadershipLevel", optional: true },
              { label: "职务名称", field: "title" },
              { label: "具体职责", field: "description" },
            ],
          }),
          abcModalStep("示例资料", "示例资料Experience", "添加", { 示例资料ForCategoryData: true }),
          abcModalStep("社会实践经历", ["campusActivities", "示例资料Experience", "示例资料Experience"], "添加", {
            示例资料ForCategoryData: true,
            rowTransform: enrichAbcSocialPracticeRow,
            fieldSequence: [
              { label: "开始时间", field: "startTime" },
              { label: "结束时间", field: "endTime" },
              { label: "实践名称", field: "abcPracticeName" },
              { label: "经历描述", field: "abcPracticeDescription" },
              { label: "本人职责", field: "abcPracticeDuty", optional: true },
            ],
          }),
          abcModalStep("项目经验", "示例资料Experience", "添加", { 示例资料ForCategoryData: true }),
          abcModalStep("技能及证书", "示例资料", "编辑", {
            aggregateCategoryData: true,
            aggregateField: "certificateName",
            aggregateFields: ["certificateName", "obtainedTime", "description"],
            aggregateSeparator: "\n",
          }),
          abcModalStep("自我评价及其他", "示例资料Introduction", "编辑", {
            readyText: "自我评价",
            dataTransform: enrichAbcSelfIntroduction,
            // 农行自我评价弹窗是单个 textarea；显式绑定后不再依赖通用
            // 标签猜测，并确保填完后点击弹窗底部的橙色“保存”按钮。
            fieldSequence: [
              { label: "自我评价", field: "示例资料Introduction", type: "text", selector: "textarea" },
            ],
            saveSelector: ".ant-modal-footer button.ant-btn-primary",
            saveText: ["保存", "保 存"],
          }),
          abcModalStep("其他", "示例资料Info", "编辑"),
          abcModalStep("发表文章及出版专著", "publications", "添加", {
            示例资料ForCategoryData: true,
            rowFilter: hasCompleteAbcPublicationRow,
            rowTransform: enrichAbcPublicationRow,
            closeOnPartialFill: true,
            saveOnPartialFill: true,
            fieldSequence: [
              { label: ["文章/著作名称", "文章/专著名称", "论文/著作名称", "论文/专著名称", "论文标题", "著作名称", "专著名称"], field: "paperTitle" },
              { label: ["刊物/出版社", "发表刊物", "期刊/会议", "期刊名称", "出版社"], field: "journal" },
              { label: ["刊物级别", "期刊级别", "刊物等级", "期刊等级"], field: "publicationLevel" },
              { label: ["刊载/出版时间", "发表日期", "发表时间", "出版时间"], field: "publishTime" },
              { label: ["文章贡献", "作者贡献", "作者身份", "作者位次"], field: "contribution" },
            ],
          }),
          abcModalStep("亲属关系", "示例资料Members", "添加", {
            示例资料ForCategoryData: true,
            rowTransform: enrichAbcFamilyRow,
            existingRowMatcher: function (row, doc) { return abcHasExistingFamilyRecords(doc); },
            saveOnPartialFill: true,
            fieldSequence: [
              { label: "关系", type: "cascader", dataFields: ["abcRelationshipCategory", "abcRelationship"], optionTimeoutMs: 5000, waitAfterOpenMs: 300, waitAfterOptionMs: 250 },
              { label: "姓名", field: "name" },
              { label: "人员状态", field: "示例资料Status" },
              { label: "是否为农行员工", field: "isBankEmployee" },
              { label: "身份证号", field: "idNumber", optional: true },
              { label: "工作单位", field: "company" },
              { label: "担任职务", field: "position" },
            ],
          }),
        ],
      },
    },
    {
      id: "ccb-recruitment",
      brandDomain: "ccb.com",
      hostname: "job1.ccb.com",
      urlPattern: /^https?:\/\/job1\.ccb\.com\/cn\/job\/resume\.html/i,
      pageGuardSelector: "#floor_views .floor_view",
      config: {
        name: "job1.ccb.com",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/job1\.ccb\.com\/cn\/job\/resume\.html/i,
        selectors: {
          container: { class: ".floor_view_editor" },
          title: { class: ".floor_view_title h3, .index_title" },
          labels: { class: ".floor_view_editor_item .left_text" },
          radio: { class: ".radio_selector .label_radio" },
          checkbox: { class: ".label_checkbox, input[type='checkbox']" },
          select: { class: ".select_box, .multi_select_box" },
          datePicker: { class: ".date_box input, .ym_date .select_box" },
          address: { class: ".multi_select_box" },
          upload: { class: ".file_uploader" },
          buttons: {
            add: { class: ".floor_view_title a.add" },
            edit: { class: ".floor_view_title a.edit, .record_view .Nright a.edit" },
          },
        },
      },
      示例资料flow: {
        id: "ccb-recruitment",
        name: "建设银行招聘简历",
        enabled: true,
        privateSpecialSite: true,
        hostname: "job1.ccb.com",
        urlPattern: /^https?:\/\/job1\.ccb\.com\/cn\/job\/resume\.html/i,
        pageGuardSelector: "#floor_views .floor_view",
        continueOnError: true,
        steps: [
          ccbInlineStep("个人信息", "示例资料Info", "编辑", {
            enabled: false,
            dataTransform: enrichCcbBasicInfo,
            fieldSequence: [
              { label: "国家或地区", field: "country" },
              { label: "民族", field: "ethnicity" },
              { label: "政治面貌", field: "politicalStatus" },
              { label: "婚姻状况", field: "maritalStatus" },
              { label: "身高(cm)", field: "height" },
              { label: "体重(kg)", field: "weight" },
              { label: "现居住地", field: "currentResidence", targetField: "currentAddress" },
              { label: "联系地址", field: "currentAddress" },
              { label: "电子邮箱", field: "email" },
              { label: "手机号码", field: "phone", optional: true },
              { label: "紧急联系人姓名", field: "emergencyContactName" },
              { label: "紧急联系人电话", field: "emergencyPhone" },
              { label: "期望月薪", field: "expectedSalary", optional: true },
            ],
          }),
          ccbInlineStep("英语水平", "示例资料Skills", "编辑", {
            dataTransform: enrichCcbEnglish,
            fieldSequence: [
              { label: "英语水平", field: "ccbEnglishLevel", targetField: "certificate" },
              { label: "英语考试分数", field: "score" },
            ],
          }),
          ccbInlineStep("语言能力", "示例资料Skills", "新增语言能力", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            rowFilter: function (row) { return !isEnglishLanguage(row); },
            fieldSequence: [
              { label: "其他语种", field: "name" },
              { label: "其他语种考试类型", field: "certificate" },
              { label: "其他语种考试分数", field: "score" },
            ],
          }),
          ccbInlineStep("示例资料", "示例资料", "新增示例资料", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            saveSelector: ".floor_view_editor + .btn_center .btn a:last-child",
            // 建行提示要求填写最高学历到高中，但不包含高中本身。
            // 简历仍可保留高中记录供其他站点使用，这里只过滤当前站点不接收的记录。
            rowFilter: function (row) {
              return !/高中|中专|职高|技校/.test(String(row && (row.level || row.示例资料Level) || ""));
            },
            rowTransform: enrichCcbEducationRow,
            fieldSequence: [
              { label: "开始时间", type: "yearMonth", field: "startTime" },
              { label: "结束时间", type: "yearMonth", field: "endTime" },
              { label: "学校", field: "school" },
              { label: "其它学校", field: "ccbOtherSchool", optional: true },
              { label: "学校类别", field: "ccbSchoolType", targetField: "isOverseas" },
              { label: "专业", field: "major" },
              { label: "其它专业", field: "ccbOtherMajor", optional: true },
              { label: "院系", field: "department", selector: "input[name='F201213']" },
              { label: "学历", field: "ccbLevel", targetField: "level" },
              { label: "是否最高学历", field: "ccbHighestEducation", targetField: "isHighestEducation" },
              { label: "学位", field: "ccbDegree" },
              { label: "是否最高学位", field: "ccbHighestDegree", targetField: "isHighestDegree", optional: true },
              { label: "学习形式", field: "示例资料Type" },
              { label: "培养方式", field: "ccbTrainingMode" },
              { label: "学习成绩排名", field: "ccbClassRank" },
            ],
          }),
          ccbInlineStep("亲属关系", "示例资料Members", "新增亲属关系", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            rowTransform: enrichCcbFamilyRow,
            fieldSequence: [
              { label: "与本人关系", field: "relationship" },
              { label: "姓名", field: "name" },
              { label: "性别", field: "gender" },
              { label: "出生年月", field: "birthDate" },
              { label: "是否在建行集团工作", field: "isBankEmployee" },
              { label: "工作单位", field: "company" },
              { label: "职务", field: "position" },
              { label: "政治面貌", field: "politicalStatus" },
            ],
          }),
          ccbInlineStep("工作（实习）经历", ["示例资料Experience", "示例资料Experience"], "新增工作（实习）经历", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            saveSelector: ".floor_view_editor + .btn_center .btn a:last-child",
            rowTransform: enrichCcbWorkRow,
            fieldSequence: [
              { label: "工作类型", field: "ccbWorkType" },
              { label: "开始时间", type: "yearMonth", field: "startTime" },
              { label: "结束时间", type: "yearMonth", field: "endTime" },
              { label: "单位名称", field: "company" },
              { label: "部门及岗位", field: "ccbDepartmentPosition" },
              { label: "工作描述", field: "ccbDescription" },
            ],
          }),
          ccbInlineStep("项目实践经验", "示例资料Experience", "新增项目实践经验", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            rowTransform: enrichCcbProjectRow,
            fieldSequence: [
              { label: "开始时间", type: "yearMonth", field: "startTime" },
              { label: "结束时间", type: "yearMonth", field: "endTime" },
              { label: "所在单位", field: "company" },
              { label: "项目名称", field: "name" },
              { label: "经历描述", field: "description" },
            ],
          }),
          ccbInlineStep("奖励荣誉", "示例资料", "新增奖励荣誉", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            rowTransform: enrichCcbAwardRow,
            fieldSequence: [
              { label: "奖励级别", field: "ccbAwardLevel" },
              { label: "奖励名称", field: "awardName" },
              { label: "获得时间", type: "yearMonth", field: "awardTime" },
            ],
          }),
          ccbInlineStep("示例资料", "示例资料Experience", "新增示例资料", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            fieldSequence: [
              { label: "开始时间", field: "startTime" },
              { label: "结束时间", field: "endTime" },
              { label: "培训名称", field: "name" },
              { label: "培训内容及证书", field: "description" },
            ],
          }),
          ccbInlineStep("职业资格认证", "示例资料", "新增职业资格认证", {
            示例资料ForCategoryData: true,
            saveEachRepeatStep: true,
            fieldSequence: [
              { label: "认证名称", field: "certificateName" },
              { label: "获得时间", type: "yearMonth", field: "obtainedTime" },
              { label: "说明", field: "description", optional: true },
            ],
          }),
          ccbInlineStep("其他", "示例资料Info", "编辑", {
            dataTransform: enrichCcbOtherInfo,
            fieldSequence: [
              { label: "是否曾被其它单位惩戒、开除、辞退", field: "hasDisciplinaryRecord" },
              { label: "是否有违法、违规、违纪、涉黑、涉恶或者其它不良行为", field: "hasMisconduct" },
              { label: "是否与其它单位签订带有“同业回避”、条款或其他可能限制其为建行工作的劳动合同", field: "hasNonCompete" },
            ],
          }),
          // “本人承诺”及页面底部隐私声明属于用户法律确认，不纳入自动填写和自动保存。
        ],
      },
    },
    {
      id: "cmbchina-recruitment",
      brandDomain: "cmbchina.com",
      hostname: "career.cmbchina.com",
      urlPattern: /^https?:\/\/career\.cmbchina\.com\/center\/resume(?:[/?#]|$)/i,
      pageGuardSelector: ".resume-contain .item-box",
      config: {
        name: "career.cmbchina.com",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/career\.cmbchina\.com\/center\/resume(?:[/?#]|$)/i,
        selectors: {
          container: { class: ".item-box" },
          section: ".item-box",
          title: { class: ".item-name" },
          labels: { class: ".ant-form-item-label label" },
          radio: { class: ".ant-radio-wrapper, input[type='radio']" },
          checkbox: { class: ".ant-checkbox-wrapper, input[type='checkbox']" },
          select: { class: ".ant-select" },
          datePicker: { class: ".ant-picker" },
          address: { class: ".ant-cascader" },
          upload: { class: "input[type='file']" },
          buttons: {
            add: { class: ".btn-add-zero, .btn-add" },
            edit: { class: "" },
            save: { class: "button.ant-btn-primary" },
          },
        },
        allowAutoSaveExperienceCards: false,
      },
      示例资料flow: {
        id: "cmbchina-recruitment",
        name: "招商银行招聘简历",
        enabled: true,
        privateSpecialSite: true,
        hostname: "career.cmbchina.com",
        urlPattern: /^https?:\/\/career\.cmbchina\.com\/center\/resume(?:[/?#]|$)/i,
        pageGuardSelector: ".resume-contain .item-box",
        continueOnError: true,
        notices: [
          "招商银行：示例资料要求从高中填写；若当前简历没有高中信息，请手动补充高中学校和时间。",
          "招商银行：实践经历中的单位联系人、单位联系电话若简历未保存，请在填充后手动补充。",
          "招商银行：证件照、生活照、本人承诺和页面底部最终保存必须由本人检查并手动完成。",
        ],
        steps: [
          cmbchinaSectionStep("个人信息", "示例资料Info", {
            dataTransform: enrichCmbchinaBasicInfo,
            fieldSequence: [
              { label: "姓名", field: "name", preserveExisting: true },
              { label: "证件类型", field: "cmbchinaIdType", preserveExisting: true },
              { label: "证件号", field: "idNumber", preserveExisting: true },
              { label: "性别", field: "gender" },
              { label: "出生日期", field: "birthDate" },
              { label: "手机号", field: "phone", preserveExisting: true },
              { label: "邮箱", field: "email", preserveExisting: true },
              { label: "政治面貌", field: "cmbchinaPoliticalStatus" },
              { label: "民族", field: "ethnicity" },
              { label: "体重", field: "weight", optional: true },
              { label: "身高", field: "height", optional: true },
              { label: "生源地", type: "cascader", dataFields: ["cmbchinaSourceProvince", "cmbchinaSourceCity"], optional: true },
              { label: "出生地", type: "cascader", dataFields: ["cmbchinaBirthProvince", "cmbchinaBirthCity"], optional: true },
              { label: "招聘信息来源", field: "recruitmentChannel", optional: true },
              { label: "面试期望城市", field: "cmbchinaInterviewCity", optional: true },
              { label: ["婚姻状况", "婚姻状况（可选）"], field: "maritalStatus", optional: true },
              { label: "现居住地", field: "cmbchinaCurrentResidence" },
              { label: "是否参加过正式工作", field: "cmbchinaHasFormalWork" },
              { label: "自我评价", field: "cmbchinaSelfAssessment" },
            ],
          }),
          cmbchinaSectionStep("高中教育", "示例资料", {
            name: "高中教育",
            cardTitle: "示例资料",
            示例资料ForCategoryData: true,
            rowFilter: isCmbchinaHighSchool,
            rowTransform: enrichCmbchinaEducationRow,
            wizardSectionTitle: "示例资料",
            wizardHeadingSelector: ".item-name",
            scopeSelector: ".item-box > div:has(input[id^='resume_示例资料HistoryList_'][id$='_collegeName'])",
            fieldSequence: [
              { label: "学校名称", field: "school" },
              { label: "时间", type: "cmbchinaDateRange", startField: "startTime", endField: "endTime" },
            ],
          }),
          cmbchinaSectionStep("高等教育", "示例资料", {
            name: "高等教育",
            cardTitle: "示例资料",
            示例资料ForCategoryData: true,
            rowFilter: function (row) { return !isCmbchinaHighSchool(row); },
            rowSort: function (left, right) { return cmbchinaEducationRank(left) - cmbchinaEducationRank(right); },
            rowTransform: enrichCmbchinaEducationRow,
            skipWhenUnavailable: false,
            wizardSectionTitle: "示例资料",
            wizardHeadingSelector: ".item-name",
            wizardSectionRootSelector: ".item-box",
            wizardAddSelector: ".btn-add",
            wizardAddText: "添加",
            scopeSelector: ".item-box > div:has(input[id^='resume_示例资料HistoryList_'][id$='_faculty'])",
            fieldSequence: [
              { label: "学历", field: "cmbchinaLevel" },
              { label: "学校名称", field: "school" },
              { label: "院系", field: "department", optional: true },
              { label: "专业名称", field: "major" },
              { label: "时间", type: "cmbchinaDateRange", startField: "startTime", endField: "endTime" },
              { label: "专业排名", field: "cmbchinaMajorRank" },
              { label: "全日制", field: "cmbchinaFullTime" },
              { label: "合作交流项目", field: "cmbchinaExchange" },
              { label: "毕业设计", field: "graduationDesign", optional: true },
            ],
          }),
          cmbchinaSectionStep("示例资料", "示例资料Members", {
            示例资料ForCategoryData: true,
            rowsTransform: cmbchinaFamilyRows,
            rowTransform: enrichCmbchinaFamilyRow,
            skipWhenUnavailable: false,
            wizardSectionTitle: "示例资料",
            wizardHeadingSelector: ".item-name",
            wizardSectionRootSelector: ".item-box",
            wizardAddSelector: ".btn-add",
            wizardAddText: "添加",
            scopeSelector: ".item-box > div:has(input[id^='resume_示例资料List_'][id$='_relationship'])",
            preFieldSequence: [
              { label: "有近亲属在集团任职", field: "cmbchinaHasRelative", optional: true },
            ],
            fieldSequence: [
              { label: "关系类型", field: "relationship" },
              { label: "姓名", field: "name" },
              { label: "在集团任职", field: "cmbchinaInGroup" },
              { label: "工作单位", type: "cmbchinaCompany", field: "company", optional: true },
              { label: "职位 / 职务", field: "position", optional: true },
              { label: "联系电话", field: "phone" },
            ],
          }),
          cmbchinaSectionStep("技能水平", "示例资料Info", {
            dataTransform: enrichCmbchinaSkills,
            fieldSequence: [
              { label: "最高英语水平", field: "cmbchinaEnglishLevel", optional: true },
              { label: "分数", field: "cmbchinaEnglishScore", optional: true },
              { label: ["计算机水平", "计算机水平（可选）"], field: "cmbchinaComputerSkill", optional: true },
              { label: ["其他", "其他（可选）"], field: "cmbchinaOtherSkill", optional: true },
            ],
          }),
          cmbchinaSectionStep("实践经历", ["示例资料Experience", "示例资料Experience"], {
            示例资料ForCategoryData: true,
            rowTransform: enrichCmbchinaPracticeRow,
            skipWhenUnavailable: false,
            wizardSectionTitle: "实践经历",
            wizardHeadingSelector: ".item-name",
            wizardSectionRootSelector: ".item-box",
            wizardAddSelector: ".btn-add-zero, .btn-add",
            wizardAddText: "添加",
            scopeSelector: ".item-box > div > div:has(input[id^='resume_示例资料ExperienceList_'][id$='_companyName'])",
            fieldSequence: [
              { label: "公司或组织", field: "company" },
              { label: "所在城市", field: "cmbchinaCity" },
              { label: "职位或职责", field: "cmbchinaRole" },
              { label: "时间", type: "cmbchinaDateRange", startField: "startTime", endField: "endTime" },
              { label: "单位联系人", field: "hrContact", optional: true },
              { label: "单位联系电话", field: "hrPhone", optional: true },
              { label: "正式工作", field: "cmbchinaFormal" },
              { label: "内容与收获", field: "cmbchinaContent" },
            ],
          }),
          cmbchinaSectionStep("个人荣誉", "示例资料", {
            示例资料ForCategoryData: true,
            rowTransform: enrichCmbchinaAwardRow,
            skipWhenUnavailable: false,
            wizardSectionTitle: "个人荣誉",
            wizardHeadingSelector: ".item-name",
            wizardSectionRootSelector: ".item-box",
            wizardAddSelector: ".btn-add-zero, .btn-add",
            wizardAddText: "添加",
            scopeSelector: ".item-box > div > div:has(input[id^='resume_awardList_'][id$='_awardName'])",
            fieldSequence: [
              { label: "荣誉类型", field: "cmbchinaAwardType" },
              { label: "奖项名称", field: "awardName" },
              { label: "获奖级别", field: "cmbchinaAwardLevel" },
              { label: "获奖时间", field: "cmbchinaAwardDate", type: "cmbchinaMonthDate", inputSelector: ".ant-picker input[id$='_awardDate']" },
            ],
          }),
          cmbchinaSectionStep("社团活动", ["campusActivities", "campusLeadership"], {
            示例资料ForCategoryData: true,
            rowTransform: enrichCmbchinaClubRow,
            skipWhenUnavailable: false,
            wizardSectionTitle: "社团活动",
            wizardHeadingSelector: ".item-name",
            wizardSectionRootSelector: ".item-box",
            wizardAddSelector: ".btn-add-zero, .btn-add",
            wizardAddText: "添加",
            scopeSelector: ".item-box > div > div:has(input[id^='resume_clubActivityList_'][id$='_communityName'])",
            fieldSequence: [
              { label: "社团名称", field: "cmbchinaClubName" },
              { label: "职务名称", field: "cmbchinaClubRole", optional: true },
              { label: "时间", type: "cmbchinaDateRange", startField: "startTime", endField: "endTime" },
              { label: "活动描述", field: "cmbchinaClubDescription" },
            ],
          }),
          // 页面底部“本人承诺”和“保存”属于用户法律确认及最终提交，本流程明确不自动点击。
        ],
      },
    },
    {
      id: "cib-recruitment",
      brandDomain: "cib.com.cn",
      hostname: "job.cib.com.cn",
      urlPattern: /^https?:\/\/job\.cib\.com\.cn\/portal\/#\/createResume(?:[/?#]|$)/i,
      pageGuardSelector: "#my.createResume-main-inner-box",
      config: {
        name: "job.cib.com.cn/portal/#/createResume",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/job\.cib\.com\.cn\/portal\/#\/createResume(?:[/?#]|$)/i,
        selectors: {
          container: { class: ".createResume-main-inner-box" },
          section: ".createResume-main-inner-box",
          title: { class: ".createResume-main-inner-box-top .title" },
          labels: { class: ".ant-form-item-label label" },
          radio: { class: ".ant-radio-wrapper, input[type='radio']" },
          checkbox: { class: ".ant-checkbox-wrapper, input[type='checkbox']" },
          select: { class: ".ant-select" },
          datePicker: { class: ".ant-calendar-picker" },
          address: { class: ".ant-select" },
          upload: { class: "input[type='file']" },
          buttons: {
            add: { class: ".addBtn" },
            edit: { class: "" },
            save: { class: "" },
          },
        },
        allowAutoSaveExperienceCards: false,
      },
      示例资料flow: {
        id: "cib-recruitment",
        name: "兴业银行招聘简历",
        enabled: true,
        privateSpecialSite: true,
        hostname: "job.cib.com.cn",
        urlPattern: /^https?:\/\/job\.cib\.com\.cn\/portal\/#\/createResume(?:[/?#]|$)/i,
        pageGuardSelector: "#my.createResume-main-inner-box",
        continueOnError: true,
        notices: [
          "兴业银行：照片、家庭成员信息真实性承诺和页面最终保存必须由本人检查并手动完成。",
          "兴业银行：简历未保存签发机构、证书号、离职原因等信息时，请在填充后人工补充。",
        ],
        steps: [
          cibSectionStep("#my", "个人示例资料", "示例资料Info", {
            dataTransform: enrichCibBasicInfo,
            fieldSequence: [
              { label: "姓名", field: "name", preserveExisting: true },
              { label: "性别", field: "gender" },
              { label: "出生日期", field: "birthDate" },
              { label: "民族", field: "ethnicity" },
              { label: "婚姻状况", field: "maritalStatus" },
              { label: "政治面貌", field: "politicalStatus" },
              { label: "籍贯", type: "elementSelect", field: "cibNativePlace", optionTimeoutMs: 3500 },
              { label: "户口所在地", type: "elementSelect", field: "cibHukouLocation", optionTimeoutMs: 3500 },
              { label: "身高", field: "height", optional: true },
              { label: "体重", field: "weight", optional: true },
              { label: "参加工作时间", field: "cibWorkStartDate", optional: true },
              { label: "手机号码", field: "phone", preserveExisting: true },
              { label: "电子邮箱", field: "email", preserveExisting: true },
              { label: "应急联系人", field: "cibEmergencyName" },
              { label: "应急联系方式", field: "cibEmergencyPhone" },
              { label: "通讯地址", field: "cibAddress" },
              { label: "爱好/特长", field: "cibHobbies" },
              { label: "应聘原因", field: "cibApplicationReason" },
              { label: "自我介绍", field: "cibSelfIntroduction", optional: true },
            ],
          }),
          cibSectionStep("#apply", "示例资料", "jobIntention", {
            dataTransform: enrichCibJobIntention,
            fieldSequence: [
              { label: "期望工作地点", type: "elementSelect", field: "cibExpectedLocation", optionTimeoutMs: 3500 },
              { label: "是否接受调剂", field: "cibAcceptAdjustment" },
              { label: "现年薪", field: "cibCurrentAnnualSalary", optional: true },
              { label: "期望年薪", field: "cibExpectedAnnualSalary" },
              { label: "预计到岗时间", field: "cibAvailabilityDate" },
              { label: "招聘信息获取渠道", field: "cibRecruitmentChannel" },
            ],
          }),
          cibSectionStep("#edu", "示例资料", "示例资料", {
            triggerSelector: "#edu button.addBtn",
            triggerNativeClick: true,
            rowScopeSelector: ".示例资料Form",
            rowAddSelector: ".addBtn",
            rowAddText: "添加示例资料",
            rowAddWaitMs: 260,
            rowAddAfterEach: true,
            rowAddNativeClick: true,
            rowAddRetryTimeoutMs: 1800,
            rowFilter: isCibHigherEducation,
            rowSort: function (left, right) {
              return String(left && left.startTime || "").localeCompare(String(right && right.startTime || ""));
            },
            rowTransform: enrichCibEducationRow,
            rowFieldSequence: [
              { label: "起止时间", type: "cmbchinaDateRange", startField: "startTime", endField: "endTime" },
              { label: "国家/地区", type: "elementSelect", field: "cibCountry", optionTimeoutMs: 3500 },
              { label: "学历", field: "level" },
              { label: "学校名称", type: "cibSchool", field: "school", optionTimeoutMs: 5000, waitAfterMs: 300 },
              { label: "专业", field: "major" },
              { label: "学习形式", field: "cibStudyForm" },
              { label: "学位", field: "cibDegree", optional: true },
              { label: "成绩排名", field: "cibRank", optional: true },
            ],
          }),
          cibSectionStep("#示例资料", "工作/示例资料", ["示例资料Experience", "示例资料Experience"], {
            triggerSelector: "#示例资料 button.addBtn",
            triggerNativeClick: true,
            rowScopeSelector: ".awardForm",
            rowAddSelector: ".addBtn",
            rowAddText: "添加示例资料",
            rowAddWaitMs: 260,
            rowAddAfterEach: true,
            rowAddNativeClick: true,
            rowAddRetryTimeoutMs: 1800,
            rowSort: function (left, right) {
              return String(left && left.startTime || "").localeCompare(String(right && right.startTime || ""));
            },
            rowTransform: enrichCibWorkRow,
            rowFieldSequence: [
              { label: "起止时间", type: "cmbchinaDateRange", startField: "startTime", endField: "endTime" },
              { label: "单位名称", field: "company" },
              { label: "部门", field: "cibDepartment", optional: true },
              { label: "职位名称", field: "cibPosition" },
              { label: "工作内容及业绩情况", field: "cibDescription", optional: true },
              { label: "离职原因", field: "cibLeaveReason" },
            ],
          }),
          cibSectionStep("#示例资料", "家庭成员", "示例资料Members", {
            triggerSelector: "#示例资料 button.addBtn",
            triggerNativeClick: true,
            rowScopeSelector: ".示例资料Form",
            rowAddSelector: ".addBtn",
            rowAddText: "添加家庭信息",
            rowAddWaitMs: 260,
            rowAddAfterEach: true,
            rowAddNativeClick: true,
            rowAddRetryTimeoutMs: 1800,
            rowTransform: enrichCibFamilyRow,
            rowFieldSequence: [
              { label: "与本人关系", field: "relationship" },
              { label: "姓名", field: "name" },
              { label: "政治面貌", field: "politicalStatus", optional: true },
              { label: "单位名称及职务", field: "cibCompanyPosition", optional: true },
            ],
          }),
          cibSectionStep("#approve", "专业资格证书", "示例资料", {
            triggerSelector: "#approve button.addBtn",
            triggerNativeClick: true,
            rowScopeSelector: ".approveForm",
            rowAddSelector: ".addBtn",
            rowAddText: "添加证书",
            rowAddWaitMs: 260,
            rowAddAfterEach: true,
            rowAddNativeClick: true,
            rowAddRetryTimeoutMs: 1800,
            rowTransform: enrichCibCertificateRow,
            rowFieldSequence: [
              { label: "获得日期", field: "cibObtainedTime" },
              { label: "到期日期", field: "cibExpiryTime", optional: true },
              { label: "证书名称", field: "certificateName" },
              { label: "证书号", field: "cibCertificateNo", optional: true },
              { label: "签发机构", field: "cibIssuer", optional: true },
            ],
          }),
          cibSectionStep("#award", "奖励情况", "示例资料", {
            dataTransform: enrichCibAwards,
            fieldSequence: [
              { label: "奖励情况", field: "cibAwardsText" },
            ],
          }),
          cibSectionStep("#示例资料", "其他相关信息", "示例资料Info", {
            dataTransform: enrichCibOtherInfo,
            fieldSequence: [
              { label: "是否曾有过不良行为记录", field: "cibMisconduct", optional: true },
              { label: "是否与目前任职公司有服务期、竞业限制等约定", field: "cibNonCompete", optional: true },
              { label: "是否存在在外持股、经商、办企业或者其他经济组织兼职的行为", field: "cibBusinessOrPartTime", optional: true },
              { label: "是否拥有除中国以外国家/地区的国籍或永久居留权", field: "cibForeignResidence", optional: true },
            ],
          }),
          // 家庭信息真实性承诺、照片上传及页面最终保存均由用户本人完成。
        ],
      },
    },
    {
      id: "cmbc-recruitment",
      brandDomain: "cmbc.com.cn",
      hostname: "career.cmbc.com.cn",
      urlPattern: /^https?:\/\/career\.cmbc\.com\.cn\/#\/app\/resumeedit/i,
      pageGuardSelector: "h5",
      config: {
        name: "career.cmbc.com.cn",
        type: "structured",
        privateSpecialSite: true,
        preferBuiltIn: true,
        blockManualCandidates: true,
        urlPattern: /^https?:\/\/career\.cmbc\.com\.cn\/#\/app\/resumeedit/i,
        selectors: {
          container: { class: "body" },
          title: { class: "h5" },
          labels: { class: ".form-group label.control-label, .form-group > label" },
          radio: { class: ".ui-radiobutton, .ui-radiobutton-box, input[type='radio']" },
          checkbox: { class: ".ui-chkbox, input[type='checkbox']" },
          select: { class: ".ui-dropdown, select" },
          datePicker: { class: ".ui-calendar input" },
          address: { class: ".ui-dropdown" },
          upload: { class: "input[type='file']" },
          buttons: { add: { class: "button" }, edit: {} },
        },
      },
      示例资料flow: {
        id: "cmbc-recruitment",
        name: "民生银行招聘简历",
        enabled: true,
        privateSpecialSite: true,
        hostname: "career.cmbc.com.cn",
        urlPattern: /^https?:\/\/career\.cmbc\.com\.cn\/#\/app\/resumeedit/i,
        pageGuardSelector: "h5",
        continueOnError: false,
        steps: [
          cmbcWizardStep("个人信息", "示例资料Info", {
            dataTransform: enrichCmbcBasicInfo,
            fieldSequence: [
              { label: "姓名", field: "name", preserveExisting: true },
              { label: "性别", type: "primeDropdown", field: "gender", preserveExisting: true },
              { label: "出生年月", type: "cmbcDate", field: "birthDate", preserveExisting: true },
              { label: "民族", type: "primeDropdown", field: "ethnicity" },
              { label: "最高学历", type: "primeDropdown", field: "cmbcHighestEducation" },
              { label: ["本科学历是否为专升本", "是否专升本"], field: "cmbcAssociateUpgrade" },
              { label: "婚姻状况", type: "primeDropdown", field: "maritalStatus" },
              { label: "国籍", field: "country" },
              { label: "政治面貌", type: "primeDropdown", field: "cmbcPoliticalStatus", waitAfterMs: 250 },
              { label: "加入时间", type: "cmbcDate", field: "partyJoinDate", optional: true },
              { label: "籍贯", field: "nativePlace" },
              { label: "户口所在地", type: "cmbcProvinceText", dataFields: ["cmbcHukouProvince", "cmbcHukouDetail"] },
              { label: "现居住地", type: "cmbcProvinceText", dataFields: ["cmbcCurrentProvince", "cmbcCurrentDetail"] },
              { label: "电子邮箱", field: "email", optional: true, preserveExisting: true },
              { label: ["移动电话", "手机号码"], type: "cmbcPhone", dataFields: ["cmbcPhoneArea", "phone"], optional: true, preserveExisting: true },
              { label: ["邮政编码", "邮编"], field: "cmbcPostalCode", optional: true },
              { label: "有无民生亲属", field: "hasRelativeInCompany" },
              { label: "家庭地址", field: "cmbcFamilyAddress" },
            ],
          }),
          cmbcWizardStep("教育背景", "示例资料", {
            示例资料ForCategoryData: true,
            示例资料SaveText: ["保存"],
            rowFilter: isCmbcHigherEducationRow,
            rowTransform: enrichCmbcEducationRow,
            scopeSelector: ".section-part",
            wizardSectionRootSelector: "#EducationHistory",
            wizardAddText: "添加教育背景",
            wizardAddSelector: "#EducationHistory > div:first-child button.btn-primary",
            fieldSequence: [
              { label: "开始时间", type: "cmbcDate", field: "startTime" },
              { label: "结束时间", type: "cmbcDate", field: "endTime" },
              { label: "就读院校", type: "cmbcSchool", field: "school", waitAfterMs: 250 },
              { label: "院校类别", type: "primeDropdown", field: "cmbcSchoolType" },
              { label: "院系名称", field: "department" },
              { label: "专业名称", field: "major" },
              { label: "学历", type: "primeDropdown", field: "cmbcLevel" },
              { label: "全日制", field: "cmbcFullTime" },
            ],
          }),
          cmbcWizardStep("示例资料", ["示例资料Experience", "示例资料Experience"], {
            wizardSectionTitle: "实习/示例资料",
            示例资料ForCategoryData: true,
            rowTransform: enrichCmbcInternshipRow,
            scopeSelector: ".section-part",
            wizardSectionRootSelector: "#WorkingExperiences",
            wizardAddText: ["添加实习/示例资料", "添加示例资料"],
            wizardAddSelector: "#WorkingExperiences > div:first-child button.btn-primary",
            fieldSequence: [
              { label: "开始时间", type: "cmbcDate", field: "startTime" },
              { label: "结束时间", type: "cmbcDate", field: "endTime" },
              { label: "公司名称", field: "company" },
              { label: "任职部门", field: "cmbcDepartment" },
              { label: "担任职位", field: "position" },
              { label: "工作职责", field: "cmbcDuty" },
            ],
          }),
          cmbcWizardStep("示例资料", "示例资料Experience", {
            示例资料ForCategoryData: true,
            scopeSelector: ".section-part",
            wizardAddText: "添加示例资料",
            fieldSequence: [
              { label: "开始时间", type: "cmbcDate", field: "startTime" },
              { label: "结束时间", type: "cmbcDate", field: "endTime" },
              { label: "培训类型", field: "name" },
              { label: "培训机构", field: "organization" },
              { label: "收获", field: "description", optional: true },
            ],
          }),
          cmbcWizardStep("论著成果", "publications", {
            示例资料ForCategoryData: true,
            示例资料SaveText: ["保存"],
            rowTransform: enrichCmbcPublicationRow,
            scopeSelector: ".section-part",
            wizardSectionRootSelector: "#ResearchResult",
            wizardAddText: "添加论著成果",
            wizardAddSelector: "#ResearchResult > div:first-child button.btn-primary",
            fieldSequence: [
              { label: "发表时间", type: "cmbcDate", field: "cmbcPublishTime" },
              { label: "论著名称", field: "cmbcPublicationName" },
              { label: "发表刊物", field: "cmbcJournal" },
              { label: "刊物层级", field: "cmbcPublicationLevel" },
            ],
          }),
          cmbcWizardStep("技能爱好", ["示例资料Skills", "示例资料"], {
            dataTransform: enrichCmbcSkills,
            fieldSequence: [
              { label: "CET4", field: "cmbcCet4", optional: true },
              { label: "CET6", field: "cmbcCet6", optional: true },
              { label: "计算机水平", field: "cmbcComputerLevel" },
              { label: "爱好", field: "cmbcHobbies", optional: true },
              { label: "特长", field: "cmbcStrengths", optional: true },
              { type: "cmbcCertificates", addText: "添加证书", optional: true },
            ],
          }),
          cmbcWizardStep("示例资料", "示例资料", {
            示例资料ForCategoryData: true,
            示例资料SaveText: ["保存"],
            rowTransform: enrichCmbcAwardRow,
            scopeSelector: ".section-part",
            wizardSectionRootSelector: "#RewardPunishment",
            wizardAddText: "添加示例资料",
            wizardAddSelector: "#RewardPunishment > div:first-child button.btn-primary",
            fieldSequence: [
              { label: "获奖时间", type: "cmbcDate", field: "cmbcAwardTime" },
              { label: "所获奖项", field: "cmbcAwardName" },
              { label: "授予单位", field: "grantor" },
            ],
          }),
          cmbcWizardStep("家庭成员", "示例资料Members", {
            示例资料ForCategoryData: true,
            示例资料SaveText: ["保存"],
            scopeSelector: ".section-part",
            wizardSectionRootSelector: "#FamilyMember",
            wizardAddText: "添加家庭成员",
            wizardAddSelector: "#FamilyMember > div:first-child button.btn-primary",
            fieldSequence: [
              { label: "姓名", field: "name" },
              { label: "关系", type: "primeDropdown", field: "relationship" },
              { label: "联系方式", field: "phone" },
              { label: "单位", field: "company" },
              { label: "职位/职务", field: "position" },
            ],
          }),
          cmbcWizardStep("自我评价", "示例资料Introduction", {
            fieldSequence: [
              { label: "自我评价内容", field: "示例资料Introduction" },
            ],
          }),
          cmbcWizardStep("示例资料/职业概况", "jobIntention", {
            dataTransform: enrichCmbcJobIntention,
            saveText: ["保存"],
            fieldSequence: [
              { label: "期望工作地点", field: "cmbcLocation" },
              { label: "期望年薪", field: "cmbcAnnualSalary" },
              { label: "是否同意机构内调剂", field: "cmbcInternalAdjustment" },
              { label: "是否同意跨机构调剂", field: "cmbcCrossAdjustment" },
              { label: "到岗时间", type: "primeDropdown", field: "cmbcAvailability", optional: true },
            ],
          }),
        ],
      },
    },
  ];

  deepFreeze(entries);

  function findStrictEntry(url) {
    try {
      var parsed = new URL(url || window.location.href);
      return entries.find(function (entry) {
        return matchesRule(entry.hostname, parsed.hostname) &&
          matchesRule(entry.urlPattern, parsed.href) &&
          (!entry.pageGuardSelector || document.querySelector(entry.pageGuardSelector));
      }) || null;
    } catch (e) {
      return null;
    }
  }

  function findBrandFallbackEntry(url) {
    try {
      var parsed = new URL(url || window.location.href);
      return entries.find(function (entry) {
        if (!matchesBrandDomain(entry.brandDomain, parsed.hostname)) return false;
        // 技术服务商根域会承载大量企业定制表单。配置了页面结构守卫时，
        // 必须全部命中才能启用品牌兜底，不能只凭子域和 resume 关键词判断。
        if (Array.isArray(entry.brandFallbackGuardSelectors) && entry.brandFallbackGuardSelectors.length) {
          var allGuardsPresent = entry.brandFallbackGuardSelectors.every(function (selector) {
            try { return !!document.querySelector(selector); } catch (eGuard) { return false; }
          });
          if (!allGuardsPresent) return false;
        } else if (entry.brandFallbackGuardSelector) {
          try {
            if (!document.querySelector(entry.brandFallbackGuardSelector)) return false;
          } catch (eSingleGuard) {
            return false;
          }
        }
        return hasResumeUrlHint(parsed) || hasResumePageFingerprint();
      }) || null;
    } catch (e) {
      return null;
    }
  }

  function findDirectEntry(url) {
    // 第一层保持原有严格规则；只有全部严格规则都未命中时，才启用品牌
    // 根域 + URL/DOM 指纹兜底。这样不会改变已经验证过的旧站点路径。
    return findStrictEntry(url) || findBrandFallbackEntry(url);
  }

  function findDelegateEntry(url) {
    try {
      var parsed = new URL(url || window.location.href);
      return entries.find(function (entry) {
        return entry.delegateUrlPattern &&
          matchesRule(entry.hostname, parsed.hostname) &&
          matchesRule(entry.delegateUrlPattern, parsed.href);
      }) || null;
    } catch (e) {
      return null;
    }
  }

  AF.PrivateSpecialSites = Object.freeze({
    listEntries: function () {
      return entries.map(function (entry) {
        var 示例资料flow = entry.示例资料flow || {};
        return { 示例资料flowId: 示例资料flow.id || entry.id || "", siteName: 示例资料flow.name || entry.config && entry.config.name || entry.id || "", hostname: entry.hostname || "" };
      });
    },
    getConfigForUrl: function (url) {
      // 顶层页面可能只负责承载深层简历 iframe。站点配置仍应显示为已命中，
      // 但工作流继续通过 delegateToChildFrame 下发到真正包含表单的 frame。
      var entry = findDirectEntry(url) || findDelegateEntry(url);
      return entry ? entry.config : null;
    },
    getWorkflowForUrl: function (url) {
      var directEntry = findDirectEntry(url);
      if (directEntry) return directEntry.示例资料flow;
      var delegateEntry = findDelegateEntry(url);
      return delegateEntry
        ? Object.assign({}, delegateEntry.示例资料flow, { delegateToChildFrame: true })
        : null;
    },
    has: function (url) { return !!(findDirectEntry(url) || findDelegateEntry(url)); },
    _test: Object.freeze({
      bankcommNormalizeText: bankcommNormalizeText,
      bankcommEvaluateEducationCheckpointCandidateSignals: bankcommEvaluateEducationCheckpointCandidateSignals,
      bankcommMajorPath: bankcommMajorPath,
      bankcommResearchPath: bankcommResearchPath,
      enrichBankcommEducationRow: enrichBankcommEducationRow,
      bankcommEducationCardTextMatchesRow: bankcommEducationCardTextMatchesRow,
      enrichBankcommWorkRow: enrichBankcommWorkRow,
      bankcommAwardLevel: bankcommAwardLevel,
    }),
  });
})();
