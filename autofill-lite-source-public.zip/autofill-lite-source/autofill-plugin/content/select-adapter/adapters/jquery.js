// content/select-adapter/adapters/jquery.js — jQuery select2 / chosen (.select2-container/.chosen-container) 适配器
// 源码参考 (webcrack-output/content/deobfuscated.js, 模块3620):
//   JQuerySelectAdapter (混淆名 A, 行14784-14791) 直接继承 GenericSelectAdapter (混淆名 E)，
//   没有覆盖 setValue —— 走 triggerGenericSelect 通用流程 (点击 element 本身 ->
//   全局找可见下拉面板 -> 通用文字匹配点击)，没有 select2/chosen 专属定位逻辑。
// 选择器配置 SA._config.jquery 仅供 detectType 分类使用
// (dropdown: .select2-results__option, .chosen-results li)。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};

  SA._registry["jquery"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        return await SA._helpers.triggerGenericSelect(element, value);
      },
    };
  };
})();
