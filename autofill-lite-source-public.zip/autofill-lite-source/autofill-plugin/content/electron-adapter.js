(function () {
  "use strict";

  var AF = (window.AF = window.AF || {});
  var activeEngine = null;
  var STOP_ATTRIBUTE = "data-offer-autofill-stop-requested";

  function isStopRequested() {
    return window.__OFFER_AUTOFILL_STOP_REQUESTED__ === true ||
      !!(document.documentElement && document.documentElement.hasAttribute(STOP_ATTRIBUTE));
  }

  function clearStopRequested() {
    window.__OFFER_AUTOFILL_STOP_REQUESTED__ = false;
    if (document.documentElement) document.documentElement.removeAttribute(STOP_ATTRIBUTE);
  }

  function normalizeResult(result, startedAt) {
    result = result || {};
    var filled = result.filledCount || result.filled || result.successCount || 0;
    var total = result.totalFieldsFound || result.totalFields || result.total || result.fieldCount || 0;
    var failed = result.failedCount || result.failed || (Array.isArray(result.failedFields) ? result.failedFields.length : 0);
    return Object.assign({}, result, {
      filledCount: filled,
      totalFieldsFound: total,
      failedCount: failed,
      executionTimeMs: result.executionTimeMs || result.elapsedMs || result.duration || (Date.now() - startedAt)
    });
  }

  function lastFocusedElement() {
    var el = window.__OFFER_LAST_FOCUSED__ || document.activeElement;
    if (el && el.shadowRoot && el.shadowRoot.activeElement) return el.shadowRoot.activeElement;
    return el;
  }

  async function run(resumeData, context) {
    var startedAt = Date.now();
    clearStopRequested();
    window.__OFFER_AUTOFILL_PROGRESS__ = {
      status: "running",
      current: 0,
      total: 0,
      filledCount: 0,
      failedCount: 0,
      startedAt: startedAt,
      updatedAt: Date.now()
    };
    if (!resumeData || typeof resumeData !== "object") {
      throw new Error("缺少简历数据");
    }
    if (!AF.SiteLoader || typeof AF.SiteLoader.loadConfig !== "function") {
      throw new Error("站点配置加载器未初始化");
    }
    if (!AF.ElementMatcher || !AF.FillEngine) {
      throw new Error("填充内核未初始化");
    }

    var url = context && context.url || location.href;
    var config = await AF.SiteLoader.loadConfig(url);
    // ChinaHR 中国银行必须按普通站点运行。对该域名在最终执行入口再做一次
    // 幂等补丁，防止旧缓存/旧服务端配置绕过 SiteLoader 的普通补丁层。
    if (/^applyjob\.chinahr\.com$/i.test(location.hostname) &&
        !(AF.PrivateSpecialSites && AF.PrivateSpecialSites.has && AF.PrivateSpecialSites.has(url)) &&
        AF.GeneralSiteConfigPatch && typeof AF.GeneralSiteConfigPatch.apply === "function") {
      try {
        var chinahrPatched = AF.GeneralSiteConfigPatch.apply(config || {}, {
          hostname: location.hostname,
          routeKey: location.pathname,
        });
        if (chinahrPatched && chinahrPatched.config) {
          config = chinahrPatched.config;
          console.info("[OfferAutofill] ChinaHR 普通站点补丁已在执行入口确认", chinahrPatched.appliedPatches || []);
        }
      } catch (eChinaHrPatch) {
        console.warn("[OfferAutofill] ChinaHR 普通站点补丁确认失败", eChinaHrPatch);
      }
    }
    function createEngine(targetConfig) {
      var matcher = new AF.ElementMatcher(targetConfig);
      var created = new AF.FillEngine(resumeData, matcher);
      created.shouldStop = isStopRequested;
      created.onProgress = function (current, total) {
        window.__OFFER_AUTOFILL_PROGRESS__ = {
          status: "running",
          current: current || 0,
          total: total || 0,
          filledCount: created.formHandler && created.formHandler.filledFieldsCount || 0,
          failedCount: created.formHandler && created.formHandler.failedFields && created.formHandler.failedFields.length || 0,
          startedAt: startedAt,
          updatedAt: Date.now()
        };
      };
      return created;
    }

    if (AF.SpecialSiteWorkflow && typeof AF.SpecialSiteWorkflow.match === "function") {
      var specialWorkflow = null;
      try {
        specialWorkflow = typeof AF.SpecialSiteWorkflow.resolve === "function"
          ? await AF.SpecialSiteWorkflow.resolve(url)
          : AF.SpecialSiteWorkflow.match(url);
      } catch (eSpecialResolve) {
        console.warn("[OfferAutofill] 特殊站点流程解析失败，继续普通填充", eSpecialResolve);
      }
      if (specialWorkflow) {
        console.info("[OfferAutofill] 使用特殊站点流程", {
          id: specialWorkflow.id || "",
          name: specialWorkflow.name || "",
          steps: Array.isArray(specialWorkflow.steps) ? specialWorkflow.steps.map(function (step) { return step && (step.cardTitle || step.name || step.category || ""); }).filter(Boolean) : []
        });
        var specialResult = normalizeResult(await AF.SpecialSiteWorkflow.execute({
          workflow: specialWorkflow,
          resume: resumeData,
          config: config,
          onProgress: function (current, total) {
            window.__OFFER_AUTOFILL_PROGRESS__ = {
              status: "running",
              current: current || 0,
              total: total || 0,
              filledCount: 0,
              failedCount: 0,
              startedAt: startedAt,
              updatedAt: Date.now()
            };
          },
        }), startedAt);
        // A verified local workflow remains authoritative. If the user has
        // explicitly produced a validated runtime selector overlay, use only its
        // safe scalar selector mappings as a post-workflow supplement. We do not
        // run generic structured filling here, so AI cannot replace repeat/save/
        // navigation behavior or override the local workflow.
        var aiSupplementResult = null;
        try {
          var runtimePatch = window.AF && window.AF.RuntimeSemanticPatch;
          var hasSelectorSupplement = runtimePatch && Array.isArray(runtimePatch.selectorMappings) && runtimePatch.selectorMappings.length > 0;
          if (hasSelectorSupplement) {
            var supplementEngine = createEngine(config);
            aiSupplementResult = await supplementEngine.executeRuntimeSelectorOverlayFill();
            if (aiSupplementResult && Number(aiSupplementResult.committed || 0) > 0) {
              specialResult = Object.assign({}, specialResult, {
                filledCount: Number(specialResult.filledCount || 0) + Number(aiSupplementResult.committed || 0),
                totalFieldsFound: Math.max(Number(specialResult.totalFieldsFound || specialResult.totalFields || 0), Number(aiSupplementResult.totalFieldsFound || 0)),
                aiSelectorSupplement: {
                  attempted: Number(aiSupplementResult.attempted || 0),
                  committed: Number(aiSupplementResult.committed || 0),
                  failed: Number(aiSupplementResult.failed || 0)
                },
                message: [specialResult.message || "", aiSupplementResult.message || ""].filter(Boolean).join("；")
              });
            }
          }
        } catch (eAiSupplement) {
          console.warn("[OfferAutofill] 本地 workflow 后 AI selector 补充执行失败，保留本地结果", eAiSupplement);
        }
        window.__OFFER_AUTOFILL_PROGRESS__ = {
          status: specialResult.stopped ? "stopped" : "done",
          current: specialResult.totalFieldsFound || specialResult.totalFields || specialResult.total || 0,
          total: specialResult.totalFieldsFound || specialResult.totalFields || specialResult.total || 0,
          filledCount: specialResult.filledCount || 0,
          failedCount: specialResult.failedCount || 0,
          startedAt: startedAt,
          updatedAt: Date.now()
        };
        return specialResult;
      }
    }

    var engine = createEngine(config);
    activeEngine = engine;
    try {
      var result = normalizeResult(await engine.execute(), startedAt);
      var configSource = String(config && config._source || "");
      var canRetryBuiltIn = !result.stopped && !result.manualActionRequired && Number(result.filledCount || 0) === 0 &&
        /^(?:prefetched_server|remote_server)$/.test(configSource) &&
        AF.SiteLoader && typeof AF.SiteLoader.loadBuiltInFallbackConfig === "function";

      if (canRetryBuiltIn) {
        var fallbackConfig = AF.SiteLoader.loadBuiltInFallbackConfig(url);
        if (fallbackConfig) {
          console.warn("[OfferAutofill] 服务器站点配置填写数为0，改用本地内置/DOM模板重试", {
            from: configSource,
            to: fallbackConfig._source || "built_in_fallback"
          });
          var retryEngine = createEngine(fallbackConfig);
          activeEngine = retryEngine;
          var retryResult = normalizeResult(await retryEngine.execute(), startedAt);
          if (Number(retryResult.filledCount || 0) > 0) {
            retryResult.configFallbackUsed = true;
            retryResult.configFallbackFrom = configSource;
            retryResult.configFallbackTo = fallbackConfig._source || "built_in_fallback";
            result = retryResult;
          }
        }
      }

      window.__OFFER_AUTOFILL_PROGRESS__ = {
        status: result.stopped ? "stopped" : "done",
        current: result.totalFieldsFound || result.totalFields || result.total || 0,
        total: result.totalFieldsFound || result.totalFields || result.total || 0,
        filledCount: result.filledCount || 0,
        failedCount: result.failedCount || 0,
        startedAt: startedAt,
        updatedAt: Date.now()
      };
      return result;
    } finally {
      activeEngine = null;
    }
  }

  function stop() {
    window.__OFFER_AUTOFILL_STOP_REQUESTED__ = true;
    if (document.documentElement) document.documentElement.setAttribute(STOP_ATTRIBUTE, "true");
    window.__OFFER_AUTOFILL_PROGRESS__ = Object.assign({}, window.__OFFER_AUTOFILL_PROGRESS__ || {}, {
      status: "stopping",
      updatedAt: Date.now()
    });
    if (activeEngine) activeEngine.cancelRequested = true;
    return { success: true, stopped: true };
  }

  async function fillFocused(value, options) {
    var el = lastFocusedElement();
    if (!el || !(el instanceof Element)) {
      throw new Error("请先点击网页里的输入框");
    }
    var tagName = String(el.tagName || "").toUpperCase();
    var isRichText = !!(
      el.isContentEditable ||
      (el.getAttribute && el.getAttribute("contenteditable") !== null) ||
      (el.getAttribute && el.getAttribute("role") === "textbox" && tagName !== "INPUT")
    );
    var type = options && options.type;
    if (!type) {
      type = tagName === "SELECT" ? "select" : (isRichText ? "contentEditable" : "text");
    }
    // Only resume-tag insertion appends, and only for fields intended for longer text.
    // Regular autofill and one-line inputs continue to replace their value.
    var appendText = !!(
      options && options.source === "offer-electron-tag" &&
      (tagName === "TEXTAREA" || isRichText)
    );
    var ok = await AF.FormHandler.fillFormElement(el, value, type, {
      source: options && options.source,
      appendText: appendText
    });
    return { success: !!ok, filledCount: ok ? 1 : 0, totalFieldsFound: 1, failedCount: ok ? 0 : 1 };
  }

  window.OfferAutofill = {
    run: run,
    stop: stop,
    fillFocused: fillFocused,
    fillLastFocused: fillFocused
  };
  window.__OFFER_AUTOFILL__ = window.OfferAutofill;
})();
