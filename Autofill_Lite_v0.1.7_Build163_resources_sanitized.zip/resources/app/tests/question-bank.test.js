"use strict";
const assert = require("assert");
const { normalizeProfileBackup } = require("../profile-adapter");

const raw = {
  profileV2: {
    sections: { 示例资料: { values: { 姓名: "测试" } } },
    questionBank: [
      { question: "是否接受异地派遣", answer: "否" },
      { question: "空问题", answer: "" }
    ]
  }
};
const data = normalizeProfileBackup(raw);
assert.deepStrictEqual(data.customAnswers, [
  { question: "是否接受异地派遣", answer: "否" },
  { question: "姓名", answer: "测试" }
]);
console.log("question bank tests: PASS");
