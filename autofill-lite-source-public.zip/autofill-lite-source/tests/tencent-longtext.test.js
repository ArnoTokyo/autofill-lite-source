"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const matcher = fs.readFileSync(path.join(root, "autofill-plugin/content/element-matcher.js"), "utf8");
const handler = fs.readFileSync(path.join(root, "autofill-plugin/content/form-handler.js"), "utf8");
const siteTemplates = fs.readFileSync(path.join(root, "autofill-plugin/content/config/site-templates.js"), "utf8");

// Regression contract: the known description fields do not use checkbox/radio
// precedence and instead accept only textarea/contenteditable/role=textbox.
assert(matcher.includes('"detailedContent", "details", "description", "selfIntroduction"'));
assert(matcher.includes("ElementMatcher.prototype.findLongTextElement"));
assert(matcher.includes("record_scope_textarea"));
assert(matcher.includes("textarea, [contenteditable=\"true\"], [role=\"textbox\"]"));
assert(matcher.includes("longtext_control_not_found"));

assert(handler.includes('resolvedType = isLongText ? "longText"'));
assert(handler.includes('case "longText":'));
assert(handler.includes("async function handleLongText"));
assert(handler.includes("control_type_mismatch"));
assert(handler.includes("commit_readback_mismatch"));
assert(handler.includes("HTMLTextAreaElement.prototype"));
assert(handler.includes("await AF.Utils.sleep(320)"));
assert(handler.includes("long text control not found"));
assert(handler.includes("tencentDescriptionValue(rowData)"));

// Keep the verified Tencent join.qq.com experience/project date route intact:
// the site capability declares a day-precision range and FormHandler delegates
// range values to the shared DatePicker adapter rather than a generic setter.
assert(siteTemplates.includes('var tencentConfig = {'));
assert(siteTemplates.includes('\"join.qq.com\": tencentConfig'));
assert(siteTemplates.includes('\"careers.tencent.com\": tencentConfig'));
assert(siteTemplates.includes('{ category: "internshipExperience", fieldKey: "duration", labels: ["起止时间"], fillType: "date", datePrecision: "day", dateFormat: "YYYY-MM-DD", preferAdapter: true }'));
assert(siteTemplates.includes('{ category: "projectExperience", fieldKey: "duration", labels: ["起止时间"], fillType: "date", datePrecision: "day", dateFormat: "YYYY-MM-DD", preferAdapter: true }'));
assert(handler.includes("rowData.startTime && rowData.endTime"));
assert(handler.includes('AF.DatePicker.create(element, "object", capabilityContext).setValue(value)'));

// Controlled-component regression model: a temporary setter value is not a
// commit; only the delayed final DOM value may be considered successful.
const normalize = (v) => String(v || "").replace(/\r\n?/g, "\n").trim();
const target = "line one\nline two";
assert.notStrictEqual(normalize(""), normalize(target), "framework reset must fail readback");
assert.strictEqual(normalize(target), normalize(target), "retained textarea value commits");

console.log("tencent date + long-text tests: PASS");
