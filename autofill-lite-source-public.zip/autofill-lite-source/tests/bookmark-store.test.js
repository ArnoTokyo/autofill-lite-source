"use strict";

const assert = require("assert");
const {
  createEmptyLibrary,
  addFolder,
  addBookmark,
  updateNode,
  moveNode,
  deleteNode,
  folderOptions,
  searchBookmarks,
  findNodeWithParent
} = require("../bookmark-store");

let seq = 0;
const id = () => `id-${++seq}`;
let lib = createEmptyLibrary();

let result = addFolder(lib, "root", "银行", id);
lib = result.library;
const bankId = result.node.id;
result = addFolder(lib, bankId, "总行", id);
lib = result.library;
const hqId = result.node.id;
result = addBookmark(lib, hqId, { name: "农业银行总行财务", url: "https://example.com/jobs?id=123#apply", status: "准备投递" }, id);
lib = result.library;
const bookmarkId = result.node.id;

assert.strictEqual(folderOptions(lib).length, 3, "root + two nested folders expected");
assert(folderOptions(lib).some((x) => x.path === "岗位库 / 银行 / 总行"), "second-level folder path missing");
assert.strictEqual(findNodeWithParent(lib, bookmarkId).node.name, "农业银行总行财务");
assert.strictEqual(findNodeWithParent(lib, bookmarkId).node.status, "准备投递", "free-form status should be stored");
assert.strictEqual(searchBookmarks(lib, "农业银行").length, 1, "bookmark search should match name");
assert.strictEqual(searchBookmarks(lib, "准备投递").length, 1, "bookmark search should match free-form status");
assert(searchBookmarks(lib, "id=123")[0].url.includes("?id=123#apply"), "bookmark must preserve URL query/hash");

result = updateNode(lib, bookmarkId, { name: "农行总行财务岗", status: "已投递，等待笔试" });
lib = result.library;
assert.strictEqual(findNodeWithParent(lib, bookmarkId).node.name, "农行总行财务岗");
assert.strictEqual(findNodeWithParent(lib, bookmarkId).node.status, "已投递，等待笔试", "status should remain free text without preset options");

result = addFolder(lib, "root", "券商", id);
lib = result.library;
const brokerId = result.node.id;
result = moveNode(lib, bookmarkId, brokerId);
lib = result.library;
assert.strictEqual(findNodeWithParent(lib, bookmarkId).parent.id, brokerId, "bookmark move failed");

assert.throws(() => moveNode(lib, bankId, hqId), /子文件夹/, "folder must not move into its descendant");
result = addBookmark(lib, "root", { name: "状态留空岗位", url: "https://example.com/blank-status", status: "" }, id);
lib = result.library;
assert.strictEqual(result.node.status, "", "blank status must be allowed");
assert.throws(() => addBookmark(lib, "root", { name: "bad", url: "javascript:alert(1)" }, id), /http\/https/, "non-http URL must be rejected");

result = deleteNode(lib, bankId);
lib = result.library;
assert.strictEqual(findNodeWithParent(lib, bankId).node, null, "folder deletion failed");
assert.strictEqual(findNodeWithParent(lib, hqId).node, null, "folder deletion should remove descendants");

console.log("bookmark store regression: PASS");
