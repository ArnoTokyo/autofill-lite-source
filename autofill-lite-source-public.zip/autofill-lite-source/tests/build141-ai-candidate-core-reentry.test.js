"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const graphModule = require(path.join(root, "graph-structure-site-candidate.js"));

assert(/const BUILD_ID = "202609\d{2}-.+-1(?:4[1-9]|[5-9]\d|\d{3,})";/.test(main), 'current build must preserve Build141+ core re-entry invariants');
assert(main.includes('const eligibleIds = new Set'));
assert.strictEqual((main.match(/const eligibleIds = new Set/g) || []).length, 1, "eligibleIds must be initialized once before graph/scalar branches");
assert(main.includes('route = "ai_candidate_bridge_error"'));
assert(main.includes('reconcileSemanticMappingsWithGraphStructure'));

const candidate = {
  configTemplate: {
    _aiSemanticPatch: {
      fieldMappings: [
        { fieldId: "f-name", category: "familyMembers", fieldKey: "name", label: "name", confidence: 0.98, source: "ai_semantic_patch" },
        { fieldId: "f-phone", category: "familyMembers", fieldKey: "phone", label: "relativesPhoneNumber", confidence: 0.95, source: "ai_semantic_patch" }
      ],
      sectionMappings: []
    },
    _graphStructure: {
      sections: [{
        title: "家庭成员",
        rows: [
          { fieldId: "f-name", label: "姓名" },
          { fieldId: "f-phone", label: "电话" }
        ]
      }]
    }
  },
  summary: {}
};
const reconciled = graphModule.reconcileSemanticMappingsWithGraphStructure(candidate);
assert.strictEqual(reconciled.configTemplate._aiSemanticPatch.fieldMappings[0].label, "姓名");
assert.strictEqual(reconciled.configTemplate._aiSemanticPatch.fieldMappings[0].aiObservedLabel, "name");
assert.strictEqual(reconciled.configTemplate._aiSemanticPatch.fieldMappings[1].label, "电话");
assert.strictEqual(reconciled.configTemplate._aiSemanticPatch.sectionMappings[0].category, "familyMembers");
assert.strictEqual(reconciled.configTemplate._aiSemanticPatch.sectionMappings[0].label, "家庭成员");
assert.strictEqual(reconciled.summary.graphSemanticRelabeledFieldCount, 2);
console.log("build141-ai-candidate-core-reentry.test.js PASS");
