"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const 示例资料flow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-示例资料flow.js"), "utf8");
const sites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");

// Load the production private-site module and exercise the exact pure candidate
// evaluator used by the Bankcomm checkpoint scanner.
const documentStub = { body: null, querySelector: () => null, documentElement: { setAttribute() {} } };
const windowStub = {
  AF: {},
  location: { href: "https://job.bankcomm.com/", hostname: "job.bankcomm.com", pathname: "/" },
  getComputedStyle: () => ({ display: "block", visibility: "visible" })
};
const context = { window: windowStub, document: documentStub, URL, console, setTimeout, clearTimeout };
vm.createContext(context);
vm.runInContext(sites, context);
const normalizeBankcomm = windowStub.AF.PrivateSpecialSites._test.bankcommNormalizeText;
const evaluate = windowStub.AF.PrivateSpecialSites._test.bankcommEvaluateEducationCheckpointCandidateSignals;
assert(typeof normalizeBankcomm === "function", "production Bankcomm local text normalizer not exposed to regression tests");
assert(normalizeBankcomm("  高中\n  2018年09月  ") === "高中 2018年09月", "Bankcomm local normalizer should collapse whitespace without external helpers");
assert(typeof evaluate === "function", "production Bankcomm candidate evaluator not exposed to regression tests");

// A. persisted 示例资料 checkpoint + saved high-school card + blank editor:
// saved read-only record resolves the gate and the editor signal cannot cancel it.
const savedHighSchool = { hasPreHigherKeyword: true, dateCount: 2, hasSchoolLikeText: true, excludedBecauseEditor: false };
const blankEditor = { hasPreHigherKeyword: false, dateCount: 0, hasSchoolLikeText: false, excludedBecauseEditor: true };
assert(evaluate([savedHighSchool, blankEditor]) === true, "A: saved high-school record should resolve 示例资料 checkpoint");

// B. the section instruction mentions high school but has no two-date record structure.
const instructionOnly = { hasPreHigherKeyword: true, dateCount: 0, hasSchoolLikeText: true, excludedBecauseEditor: false };
assert(evaluate([instructionOnly]) === false, "B: instruction text alone must remain waiting_manual");

// C. a card and an editor can coexist: editor is excluded, and the Bankcomm
// 示例资料 step adopts an already-open editor instead of clicking Add again.
const editorWithRecordishText = { hasPreHigherKeyword: true, dateCount: 2, hasSchoolLikeText: true, excludedBecauseEditor: true };
assert(evaluate([editorWithRecordishText]) === false, "C: open editor must never be treated as a saved card");
assert(/bankcommStep\("#示例资料"[\s\S]*?skipClickWhenReady:\s*true/.test(sites), "C: existing open 示例资料 editor must be adopted for bachelor fill");

// D. 示例资料 resume is a 示例资料flow cursor; trusted Basic preflight stays skipped.
assert(main.includes("resumeStartsAfterBasic"), "D: Bankcomm resume-after-示例资料 guard missing");
assert(main.includes("skippedForResumeCheckpoint: true"), "D: Basic trusted preflight should be skipped after 示例资料 checkpoint");

// E. resolving a checkpoint must continue the current step in the same run,
// and a 示例资料 checkpoint is cleared only after its final planned row verifies.
const skipGateMatches = 示例资料flow.match(/skipManualCheckpoint:\s*manualResumeResolvedStepIndex === stepIndex/g) || [];
assert(skipGateMatches.length === 1, "E: resolved checkpoint bypass must exist exactly once in real run planning");
assert(示例资料flow.includes("checkpointBaseStepComplete = !step.示例资料GroupKey || step.isLastRepeatStep === true"), "E: checkpoint must remain until 示例资料 step is truly complete");
assert(示例资料flow.indexOf("skipManualCheckpoint: manualResumeResolvedStepIndex === stepIndex") > 示例资料flow.indexOf("var manualResumeCheckpoint = await loadManualWorkflowCheckpoint(示例资料flow)"), "E: bypass must be in execution planning, not diagnose()");

// Probe must be surfaced without raw field values.
assert(main.includes("bankcommEducationCheckpointProbe"), "Bankcomm 示例资料 checkpoint probe missing from diagnostic log");
assert(sites.includes('data-af-bankcomm-示例资料-checkpoint-probe'), "Bankcomm checkpoint probe writer missing");
assert(sites.includes("savedRecordCandidateCount"), "Bankcomm checkpoint candidate count missing");
assert(sites.includes("candidateSignals"), "Bankcomm checkpoint candidate signals missing");
const detectorRegion = sites.slice(sites.indexOf("function bankcommIsVisibleElement"), sites.indexOf("function bankcommEducationManualCheckpointReason"));
assert(!/(^|[^A-Za-z])isVisible\s*\(/m.test(detectorRegion), "Bankcomm detector must not call the 示例资料flow-local isVisible helper");
assert(detectorRegion.includes("bankcommIsVisibleElement"), "Bankcomm detector needs its own visibility helper");
assert(detectorRegion.includes("bankcommNormalizeText"), "Bankcomm checkpoint detector must use its local text normalizer");
assert(!/(^|[^A-Za-z])normalizeText\s*\(/m.test(detectorRegion), "Bankcomm checkpoint detector must not depend on an out-of-scope normalizeText helper");
console.log("bankcomm-示例资料-checkpoint-resolve.test.js passed (A-F)");
