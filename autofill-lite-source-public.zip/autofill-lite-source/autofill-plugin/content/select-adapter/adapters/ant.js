// content/select-adapter/adapters/ant.js — Ant Design (.ant-select) 适配器
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   AntSelectAdapter (模块3148):       行 6764-7543
//   triggerAntSelect (混淆名 g/w):     行 7396-7463
//   选择器配置 (源码定位手册 6.5, 与 n.n.ant 一致): container/.ant-select, trigger/.ant-select-selector,
//     dropdown/.ant-select-item-option,.ant-select-dropdown-menu-item
//
// 算法 (对应源码 w() 函数, 行7399-7463):
//   1. container = closest(.ant-select)；trigger = container 内 trigger 选择器命中的元素
//   2. 若 container 内有可用 <input> (过滤态 ant-select 自带的搜索框)，直接输入 value 触发过滤
//   3. 若 container 已经是展开态 (ant-select-open class 或 aria-expanded=true)，直接就近找面板；
//      否则点击 trigger 并等待面板出现 (面板会被 portal 到 body 外层，用 findVisibleDropdownNear 全局搜)
//   4. 面板找到后调用通用 selectMatchingOption 做文字匹配 + 点击
//   注: AntLegacyMajorAdapter (专业字段特殊分支) 不在本次任务范围内，未移植。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};
  var H = SA._helpers;
  var CFG = SA._config.ant;
  var DROPDOWN_PANEL_SELECTOR = ".ant-select-dropdown, .ant-dropdown";
  var antMainBridgePromise = null;

  function traceAnt(action, detail, status) {
    try {
      if (AF.FillTrace && typeof AF.FillTrace.event === "function") {
        AF.FillTrace.event("ant." + action, detail || "", status || "");
      }
    } catch (e) {}
  }

  function ensureAntMainBridge() {
    if (antMainBridgePromise) return antMainBridgePromise;
    antMainBridgePromise = new Promise(function (resolve) {
      try {
        var script = document.createElement("script");
        script.src = chrome.runtime.getURL("content/select-adapter/adapters/ant-main.js");
        script.async = false;
        script.onload = function () {
          script.remove && script.remove();
          resolve(true);
        };
        script.onerror = function () {
          script.remove && script.remove();
          resolve(false);
        };
        (document.documentElement || document.head || document.body).appendChild(script);
        setTimeout(function () {
          resolve(true);
        }, 800);
      } catch (e) {
        resolve(false);
      }
    });
    return antMainBridgePromise;
  }

  async function typeAntSearchInputInPage(input, value) {
    if (!input) return false;
    if (!await ensureAntMainBridge()) return false;
    // 独立学校/专业弹窗的搜索框不属于 .ant-select。它们是 React 受控 input，
    // 逐字符合成事件只能改变表面 value，站点内部搜索状态不会更新；改走
    // execCommand/原生编辑管线的 direct 模式。普通 Ant Select 保持原逻辑。
    var requestType = input.closest && input.closest(".ant-select")
      ? "AF_ANT_TYPE_REQUEST_V2"
      : "AF_ANT_DIRECT_TYPE_REQUEST_V2";
    var token = "af_ant_" + Date.now() + "_" + Math.random().toString(36).slice(2);
    var id = token + "_type";
    input.setAttribute("data-af-ant-token", token);
    return await new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, 5500);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (!data || data.type !== "AF_ANT_TYPE_RESULT_V2" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: requestType,
        id: id,
        token: token,
        value: String(value == null ? "" : value),
      }, "*");
    });
  }

  async function clickAntOptionInPage(option, input, value) {
    await ensureAntMainBridge();
    var token = "";
    if (option) {
      token = "af_ant_option_" + Date.now() + "_" + Math.random().toString(36).slice(2);
      option.setAttribute("data-af-ant-option-token", token);
    }
    var inputToken = input && input.getAttribute && input.getAttribute("data-af-ant-token") || "";
    if (!inputToken && input && input.setAttribute) {
      inputToken = "af_ant_" + Date.now() + "_" + Math.random().toString(36).slice(2);
      input.setAttribute("data-af-ant-token", inputToken);
    }
    var id = (token || inputToken || "af_ant_click") + "_click";
    return await new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, 7000);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (!data || data.type !== "AF_ANT_CLICK_RESULT_V2" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: "AF_ANT_CLICK_REQUEST_V2",
        id: id,
        token: token,
        inputToken: inputToken,
        value: String(value == null ? "" : value),
      }, "*");
    });
  }

  async function clickAntFirstOptionByPointInPage(input, value) {
    await ensureAntMainBridge();
    var inputToken = input && input.getAttribute && input.getAttribute("data-af-ant-token") || "";
    if (!inputToken) return false;
    var id = inputToken + "_point_click";
    return await new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, 3600);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (!data || data.type !== "AF_ANT_POINT_CLICK_RESULT_V2" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: "AF_ANT_POINT_CLICK_REQUEST_V2",
        id: id,
        inputToken: inputToken,
        value: String(value == null ? "" : value),
      }, "*");
    });
  }

  async function clickAntAddSchoolFullNameInPage(input, value) {
    await ensureAntMainBridge();
    var inputToken = input && input.getAttribute && input.getAttribute("data-af-ant-token") || "";
    if (!inputToken) return false;
    var id = inputToken + "_add_school";
    return await new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, 2600);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (!data || data.type !== "AF_ANT_ADD_SCHOOL_RESULT_V2" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: "AF_ANT_ADD_SCHOOL_REQUEST_V2",
        id: id,
        inputToken: inputToken,
        value: String(value == null ? "" : value),
      }, "*");
    });
  }

  async function commitAntActiveOptionInPage(input, value) {
    await ensureAntMainBridge();
    var inputToken = input && input.getAttribute && input.getAttribute("data-af-ant-token") || "";
    if (!inputToken) return false;
    var id = inputToken + "_commit";
    return await new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, 2600);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (!data || data.type !== "AF_ANT_COMMIT_RESULT_V2" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: "AF_ANT_COMMIT_REQUEST_V2",
        id: id,
        inputToken: inputToken,
        value: String(value == null ? "" : value),
      }, "*");
    });
  }

  function antCascaderPath(value) {
    if (Array.isArray(value)) {
      return value.map(function (item) { return String(item == null ? "" : item).trim(); }).filter(Boolean);
    }
    if (value && typeof value === "object") {
      if (value.fallbackFirst || value.pickFirst || value.allowFirstOption) return ["__AF_FIRST_OPTION__"];
      var rawPath = value.path || value.valuePath || value.values;
      if (Array.isArray(rawPath)) return antCascaderPath(rawPath);
      value = value.name != null ? value.name : (value.value != null ? value.value : "");
    }
    var text = String(value == null ? "" : value).trim();
    if (!text) return [];
    var separated = text.split(/\s*(?:\/|>|＞|,|，|\|)\s*/).filter(Boolean);
    if (separated.length > 1) return separated;

    // 地址字段常以“浙江省杭州市”这种无分隔符形式保存。只拆明确的行政区后缀，
    // “工学”“管理学类”等专业类别保持单值，绝不再回退到相邻学校 Select。
    var province = text.match(/^(.+?(?:省|自治区|特别行政区))/);
    if (province) {
      var rest = text.slice(province[1].length);
      var city = rest.match(/^(.+?(?:市|自治州|地区|盟))/);
      var path = [province[1]];
      if (city) {
        path.push(city[1]);
        var district = rest.slice(city[1].length);
        if (district) path.push(district);
      } else if (rest) {
        path.push(rest);
      }
      return path.filter(Boolean);
    }
    var municipality = text.match(/^(北京市|上海市|天津市|重庆市)(.*)$/);
    if (municipality) return [municipality[1]].concat(municipality[2] ? [municipality[2]] : []);
    return [text];
  }

  async function fillAntCascaderInPage(element, value) {
    if (!element || !await ensureAntMainBridge()) return false;
    var wrapper = element.closest && element.closest(".ant-cascader-picker, .ant-select.ant-cascader, .ant-cascader") || element;
    var values = antCascaderPath(value);
    if (!values.length) return false;
    var token = "af_ant_cascader_" + Date.now() + "_" + Math.random().toString(36).slice(2);
    var id = token + "_fill";
    wrapper.setAttribute("data-af-ant-cascader-token", token);
    return await new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, 8000);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (!data || data.type !== "AF_ANT_CASCADER_RESULT_V2" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: "AF_ANT_CASCADER_REQUEST_V2",
        id: id,
        token: token,
        values: values,
      }, "*");
    });
  }

  function isAntOpen(container, trigger) {
    return (
      container.classList.contains("ant-select-open") ||
      container.getAttribute("aria-expanded") === "true" ||
      (trigger && trigger.getAttribute && trigger.getAttribute("aria-expanded") === "true")
    );
  }

  function setAntSearchValue(input, value) {
    var descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    if (descriptor && descriptor.set) descriptor.set.call(input, value);
    else input.value = value;
    input.dispatchEvent(
      new InputEvent("input", {
        bubbles: true,
        cancelable: true,
        composed: true,
        data: value,
        inputType: "insertText",
      })
    );
    input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, key: value.slice(-1) || "", composed: true }));
  }

  function pressEnter(input) {
    if (!input) return;
    ["keydown", "keypress", "keyup"].forEach(function (type) {
      input.dispatchEvent(new KeyboardEvent(type, {
        bubbles: true,
        cancelable: true,
        composed: true,
        key: "Enter",
        code: "Enter",
        keyCode: 13,
        which: 13,
      }));
    });
  }

  function isAntV3Container(container) {
    return Boolean(container && container.querySelector && container.querySelector(".ant-select-selection__rendered"));
  }

  function canTypeIntoAntSearch(container, input, element) {
    if (!input || input.disabled || input.readOnly) return false;
    if (isRemoteSearchField(element)) return true;
    if (container && container.matches && container.matches(".ant-select-show-search, .ant-select-auto-complete")) return true;
    return AF.DomUtils.isElementVisible(input);
  }

  function uniqueValues(values) {
    var seen = {};
    return values.filter(function (v) {
      var key = String(v == null ? "" : v).trim();
      if (!key || seen[key]) return false;
      seen[key] = true;
      return true;
    });
  }

  function expandSelectValueCandidates(value) {
    if (typeof value !== "string") return [value];
    var text = value.trim();
    var candidates = [text];
    if (/博士/.test(text)) candidates.push("博士");
    if (/硕士|研究生/.test(text)) candidates.push("硕士");
    if (/本科|大学/.test(text)) candidates.push("本科");
    if (/学士/.test(text)) candidates.push("学士");
    if (/大专|专科/.test(text)) candidates.push("大专");
    if (/居民身份证|中华人民共和国居民身份证|二代身份证/.test(text)) candidates.push("身份证");
    if (/港澳居民来往内地通行证/.test(text)) candidates.push("港澳通行证");
    if (/台湾居民来往大陆通行证/.test(text)) candidates.push("台胞证");
    return uniqueValues(candidates);
  }

  function expandSchoolSearchTerms(value) {
    if (typeof value !== "string") return [value];
    var text = value.trim();
    var terms = [text];
    if (text.length >= 2) terms.push(text.slice(0, 2));
    if (text.length >= 3) terms.push(text.slice(0, 3));
    return uniqueValues(terms);
  }

  function isHotjobRelatedSite() {
    var host = String(location.hostname || "").toLowerCase();
    var href = String(location.href || "").toLowerCase();
    return host === "hotjob.cn" || host.endsWith(".hotjob.cn") || /zhaopin\.com|\.zhaopin\.cn|zhaopincdn\.com|jobs\.zhaopin\.com/.test(href);
  }

  function labelTextFor(element) {
    try {
      var item = element.closest && element.closest(".ant-form-item, .form-item, [class*='form-item']");
      var label = item && item.querySelector("label, div[class*='label'], span[class*='label']");
      return label ? String(label.textContent || "").replace(/\s+/g, "") : "";
    } catch (e) {
      return "";
    }
  }

  function activeFieldTextFor(element) {
    var text = labelTextFor(element);
    try {
      var trace = AF.FillTrace && AF.FillTrace.getState ? AF.FillTrace.getState() : null;
      var ctx = trace && trace.context || {};
      text += " " + [ctx.category, ctx.label, ctx.fieldKey].filter(Boolean).join(" ");
    } catch (e) {}
    return String(text || "").replace(/\s+/g, "");
  }

  function isLegacySearchField(element) {
    var text = activeFieldTextFor(element);
    return isHotjobRelatedSite() && /(学校|院校|毕业院校|专业|所学专业|专业名称)/.test(text);
  }

  function isRemoteSearchField(element) {
    return /(学校|院校|毕业院校|专业|所学专业|专业名称|school|major|graduationSchool|highestMajor)/i.test(activeFieldTextFor(element));
  }

  function isSchoolSearchField(element) {
    return /(学校|院校|毕业院校|school|graduationSchool)/i.test(activeFieldTextFor(element));
  }

  function resolveAntContainer(element) {
    try {
      var direct = element && element.closest && element.closest(CFG.container);
      if (direct && AF.DomUtils.isElementVisible(direct)) return direct;
      var scopes = [];
      var cur = element;
      var hops = 0;
      while (cur && hops < 10) {
        scopes.push(cur);
        cur = cur.parentElement;
        hops++;
      }
      var fieldScope = element && element.closest && element.closest("[id], .form-cell-inner, .form-cell, .ant-form-item, .form-item, [class*='form-item']");
      if (fieldScope && scopes.indexOf(fieldScope) === -1) scopes.push(fieldScope);
      for (var i = 0; i < scopes.length; i++) {
        var found = Array.from(scopes[i].querySelectorAll ? scopes[i].querySelectorAll(CFG.container) : []).filter(function (node) {
          return AF.DomUtils.isElementVisible(node);
        })[0];
        if (found) return found;
      }
    } catch (e) {}
    return direct || element;
  }

  function normalizeSelectedText(value) {
    return String(value == null ? "" : value)
      .replace(/\s+/g, "")
      .replace(/[：:*?？（）()【】\[\]「」'"“”‘’.,，。;；、]/g, "")
      .toLowerCase();
  }

  function antDisplayedValueMatches(element, container, value) {
    try {
      var target = normalizeSelectedText(value);
      if (!target) return false;
      var texts = [];
      Array.from(container.querySelectorAll(
        ".ant-select-selection-selected-value, .ant-select-selection-item, " +
        ".ant-select-selection-item-content, .ant-select-selection__choice__content"
      )).forEach(function (node) {
        texts.push(node.textContent || "");
        texts.push(node.getAttribute && (node.getAttribute("title") || node.getAttribute("aria-label") || node.getAttribute("value")) || "");
      });
      return texts.some(function (text) {
        var normalized = normalizeSelectedText(text);
        if (!normalized || /^(请选择|请输入|select)$/.test(normalized)) return false;
        if (normalized === target || normalized.indexOf(target) !== -1) return true;
        return normalized.length >= 4 && target.indexOf(normalized) !== -1 && normalized.length / target.length >= 0.5;
      });
    } catch (e) {
      return false;
    }
  }

  async function openAntDropdown(container, trigger) {
    try {
      await AF.DomUtils.safeClickElement(trigger || container);
      await AF.Utils.sleep(isAntV3Container(container) ? 180 : 80);
      return true;
    } catch (e) {
      return false;
    }
  }

  async function waitAndSelectMatchingOption(element, value, timeoutMs) {
    var timeoutAt = Date.now() + (timeoutMs || 1500);
    var panel = null;
    var loops = 0;
    while (Date.now() < timeoutAt) {
      loops++;
      panel = H.findVisibleDropdownNear(element, DROPDOWN_PANEL_SELECTOR, CFG.container) || panel;
      if (panel && await H.selectMatchingOption(panel, value, CFG.dropdown)) return true;
      await AF.Utils.sleep(180);
    }
    traceAnt("wait_option_timeout", "value=" + value + "; panel=" + !!panel + "; loops=" + loops + "; timeout=" + (timeoutMs || 1500), "miss");
    return false;
  }

  async function selectOneAntValue(element, container, trigger, value) {
    var panel = null;
    if (isAntOpen(container, trigger)) {
      panel = H.findVisibleDropdownNear(element, DROPDOWN_PANEL_SELECTOR, CFG.container);
    }
    if (!panel) {
      await openAntDropdown(container, trigger);
      panel = await H.waitForVisibleDropdownNear(element, DROPDOWN_PANEL_SELECTOR, CFG.container, 1500);
    }
    if (!panel) return false;
    var searchInput = container.querySelector(".ant-select-search__field, input");
    var ok = false;
    if (searchInput) {
      // AntD v4/rc-select 的选中状态在 React 里，content-script 普通 click
      // 偶尔只改变 DOM 焦点不触发 onSelect。先交给主页面上下文精确点击当前
      // select 关联 listbox 里的选项，学历/是否/学习形式这类普通 Select 也走它。
      ok = await clickAntOptionInPage(null, searchInput, value);
      await AF.Utils.sleep(260);
      if (ok && antDisplayedValueMatches(element, container, value)) return true;
    }
    if (!ok) ok = await H.selectMatchingOption(panel, value, CFG.dropdown);
    if (ok) {
      await AF.Utils.sleep(220);
      if (antDisplayedValueMatches(element, container, value)) return true;
    }
    if (!ok && isRemoteSearchField(element)) {
      ok = await waitAndSelectMatchingOption(element, value, isAntV3Container(container) ? 3500 : 1800);
    }
    if (!ok && (isLegacySearchField(element) || isRemoteSearchField(element))) {
      var searchInput = container.querySelector("input");
      if (searchInput) {
        pressEnter(searchInput);
        await AF.Utils.sleep(250);
        ok = antDisplayedValueMatches(element, container, value) ||
          String(searchInput.value || "").trim() === String(value || "").trim();
      }
    }
    if (!ok && antDisplayedValueMatches(element, container, value)) return true;
    return ok;
  }

  async function triggerAntSelect(element, value) {
    try {
      var container = resolveAntContainer(element);
      var trigger = container.querySelector(CFG.trigger) || container;
      var searchInput = container.querySelector(".ant-select-search__field, input");
      if (isSchoolSearchField(element)) {
        traceAnt("school_entry", "containerVisible=" + AF.DomUtils.isElementVisible(container) + "; hasInput=" + !!searchInput + "; label=" + labelTextFor(element), "start");
      }

      async function tryOneValue(oneValue) {
        // 若容器内自带过滤输入框 (非只读/禁用)，先输入触发框架过滤
        if (canTypeIntoAntSearch(container, searchInput, element) && typeof oneValue === "string") {
          var waitMs = (isLegacySearchField(element) || isRemoteSearchField(element)) ? (isAntV3Container(container) ? 300 : 900) : 350;
          var candidates = expandSelectValueCandidates(oneValue);
          for (var c = 0; c < candidates.length; c++) {
            await openAntDropdown(container, trigger);
            searchInput = container.querySelector(".ant-select-search__field, input") || searchInput;
            try { searchInput.focus(); } catch (e) {}
            if (isSchoolSearchField(element)) {
              traceAnt("school_open", "open=" + isAntOpen(container, trigger) + "; inputVisible=" + AF.DomUtils.isElementVisible(searchInput), "probe");
              var schoolTerms = expandSchoolSearchTerms(candidates[c]);
              for (var st = 0; st < schoolTerms.length; st++) {
                await openAntDropdown(container, trigger);
                searchInput = container.querySelector(".ant-select-search__field, input") || searchInput;
                try { searchInput.focus(); } catch (e) {}
                setAntSearchValue(searchInput, "");
                await AF.Utils.sleep(120);
                setAntSearchValue(searchInput, schoolTerms[st]);
                if (await waitAndSelectMatchingOption(container, candidates[c], 3000)) return true;
              }
            }
            var mainWorldTyped = false;
            if (isRemoteSearchField(element)) {
              mainWorldTyped = await typeAntSearchInputInPage(searchInput, candidates[c]);
            }
            if (!mainWorldTyped) {
              setAntSearchValue(searchInput, "");
              await AF.Utils.sleep(40);
              setAntSearchValue(searchInput, candidates[c]);
            }
            await AF.Utils.sleep(mainWorldTyped ? Math.max(waitMs, 900) : waitMs);
            if (isAntV3Container(container) && isRemoteSearchField(element)) {
              if (await clickAntOptionInPage(null, searchInput, candidates[c])) {
                await AF.Utils.sleep(450);
                if (antDisplayedValueMatches(element, container, candidates[c])) return true;
              }
              if (await clickAntFirstOptionByPointInPage(searchInput, candidates[c])) {
                await AF.Utils.sleep(450);
                if (antDisplayedValueMatches(element, container, candidates[c])) return true;
              }
              if (isSchoolSearchField(element) && await commitAntActiveOptionInPage(searchInput, candidates[c])) {
                await AF.Utils.sleep(650);
                if (antDisplayedValueMatches(element, container, candidates[c])) return true;
              }
              if (isSchoolSearchField(element) && await clickAntAddSchoolFullNameInPage(searchInput, candidates[c])) {
                await AF.Utils.sleep(650);
                if (antDisplayedValueMatches(element, container, candidates[c])) return true;
              }
              if (await waitAndSelectMatchingOption(element, candidates[c], 3500)) return true;
            }
            if (await selectOneAntValue(element, container, trigger, candidates[c])) return true;
          }
          return antDisplayedValueMatches(element, container, oneValue);
        }
        var directCandidates = expandSelectValueCandidates(oneValue);
        for (var directIndex = 0; directIndex < directCandidates.length; directIndex++) {
          if (await selectOneAntValue(element, container, trigger, directCandidates[directIndex])) return true;
        }
        return false;
      }

      var ok;
      if (Array.isArray(value)) {
        ok = false;
        for (var i = 0; i < value.length; i++) {
          var one = await tryOneValue(value[i]);
          if (one) ok = true;
          await AF.Utils.sleep(150);
        }
      } else {
        ok = await tryOneValue(value);
      }
      H.dispatchChangeEvents(element);
      return ok || antDisplayedValueMatches(element, container, value);
    } catch (e) {
      return false;
    }
  }

  SA._registry["ant"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        return await triggerAntSelect(element, value);
      },
    };
  };
  SA._registry["ant-cascader"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        return await fillAntCascaderInPage(element, value);
      },
    };
  };
  // 独立弹窗中的 Ant/React 搜索框也需要 MAIN world 输入与点击能力。
  // 暴露给 FormHandler 复用，避免在 isolated world 重复维护一套不可靠事件模拟。
  SA.typeSearchInputInPage = typeAntSearchInputInPage;
  SA.clickOptionInPage = clickAntOptionInPage;
})();
