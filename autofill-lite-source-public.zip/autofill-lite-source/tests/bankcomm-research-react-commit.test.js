"use strict";
const fs = require("fs");
const path = require("path");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const workflow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-workflow.js"), "utf8");
const antMain = fs.readFileSync(path.join(root, "autofill-plugin/content/select-adapter/adapters/ant-main.js"), "utf8");

// A. Research custom input must explicitly request React-state synchronization.
assert(workflow.includes("forceReactCommit: true"), "A: research fallback does not request React state commit");
assert(workflow.includes("typeBankcommResearchCustomInputInPage"), "A: controlled research input helper missing");

// B. MAIN-world bridge must turn the visible DOM value into controlled component state.
assert(antMain.includes("data.forceReactCommit === true"), "B: MAIN bridge does not handle forced React commit");
assert(antMain.includes('invokeReactInputHandlers(committedInput, ["onInput", "onChange"]'), "B: React handlers are not invoked after typing");

// C. Failure stages must remain observable in the exported fill failure instead of collapsing to one generic message.
assert(workflow.includes("research_custom_submit_not_found"), "C: missing submit-stage diagnostic");
assert(workflow.includes("research_custom_writeback_not_observed"), "C: missing writeback-stage diagnostic");
assert(workflow.includes("lastBankcommResearchCustomError"), "C: research custom diagnostic state missing");

console.log("bankcomm-research-react-commit.test.js passed (A-C)");
