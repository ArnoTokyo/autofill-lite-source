"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { normalizeProfileBackup } = require("../profile-adapter");

const raw = { profileV2: { sections: {
  示例资料: { key: "示例资料", title: "示例资料", kind: "示例资料", values: { "姓名": "测试用户", "新个人字段": "新值" }, custom: [] },
  示例资料: { key: "示例资料", title: "示例资料", kind: "示例资料", items: [ { title: "本科", values: { "学校": "甲大学", "学历": "本科" }, custom: [] } ] },
  示例资料: { kind: "示例资料", items: [] }, 示例资料: { kind: "示例资料", items: [] }, 示例资料: { kind: "示例资料", items: [] }, 示例资料: { kind: "示例资料", items: [] }, 示例资料: { kind: "示例资料", items: [] }, 示例资料: { kind: "示例资料", items: [] }, 示例资料: { kind: "示例资料", items: [] },
  示例资料: { key: "示例资料", title: "自我评价", kind: "示例资料", values: {}, custom: [] },
  示例资料: { key: "示例资料", title: "其他", kind: "示例资料", values: {}, custom: [] }
}, questionBank: [{ question: "新个人字段", answer: "显式问答优先" }] } };

const normalized = normalizeProfileBackup(raw);
const custom = new Map(normalized.customAnswers.map(x => [x.question, x.answer]));
assert.strictEqual(custom.get("新个人字段"), "显式问答优先", "explicit Q&A must override auto-exposed 示例资料 library field");
assert.strictEqual(custom.get("姓名"), "测试用户", "示例资料 library values should be exposed to exact-label fallback");
assert(!custom.has("学校"), "示例资料-section fields must never be flattened into custom answers");

const main = fs.readFileSync(path.join(__dirname, "../main.js"), "utf8");
const editor = fs.readFileSync(path.join(__dirname, "../profile-editor.js"), "utf8");
const buildMatch = main.match(/const BUILD_ID = "([^"]+)-(\d+)";/);
assert(buildMatch && Number(buildMatch[2]) >= 161, "Build161+ runtime id missing");
assert(main.includes('next.profileV2.updatedAt = new Date().toISOString()'), "save must update profile timestamp");
assert(main.includes('const readBack = readRawProfile()'), "save must read back exact runtime profile");
assert(main.includes('const normalized = loadProfile(PROFILE_FILE)'), "save must validate the same runtime profile used by autofill");
assert(main.includes('profileHash:'), "save result must expose readback hash");
assert(editor.includes('profile = deepClone(await window.lite.getProfileRaw())'), "editor must re-read runtime profile after save");
assert(editor.includes('运行时资料：'), "editor must show actual runtime profile path after save");
console.log("build161-profile-library-runtime-sync.test.js PASS");
