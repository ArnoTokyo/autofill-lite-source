"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
assert(/const BUILD_ID = "202609\d{2}-.+-1(?:4[3-9]|[5-9]\d|\d{3,})";/.test(main), 'current build must preserve Build143+ education graph re-entry invariants');

global.location = {
  href: "https://zhaopin.cnpc.com.cn/web/createResume.html",
  hostname: "zhaopin.cnpc.com.cn",
  pathname: "/web/createResume.html"
};
global.getComputedStyle = () => ({ display: "block", visibility: "visible", opacity: "1" });
global.document = {};
global.window = {
  location: global.location,
  AF: {
    CheckpointCore: {
      recordFingerprint(row) { return [row && row.school, row && row.level, row && row.startTime].join("|"); }
    },
    DomUtils: {
      isElementVisible() { return true; },
      isDateValue() { return false; },
      isDatePicker() { return false; },
      isSearchSelect() { return false; },
      isNormalSelect() { return false; }
    },
    Utils: { async sleep() {} },
    FillTrace: { setFieldContext() {}, event() {} },
    SelectAdapter: { _registry: { custom: true }, detectType() { return null; } }
  }
};

const RecordGraph = require(path.join(root, "autofill-plugin", "content", "record-graph.js"));
window.AF.RecordGraph = RecordGraph;
require(path.join(root, "autofill-plugin", "content", "form-handler.js"));
const AF = window.AF;

function fieldNode(value) {
  return {
    tagName: "INPUT",
    value: value || "",
    isConnected: true,
    getBoundingClientRect() { return { width: 100, height: 24, left: 0, top: 0 }; },
    matches() { return false; },
    querySelector() { return null; }
  };
}
function actionNode(text) {
  return {
    textContent: text,
    innerText: text,
    value: "",
    disabled: false,
    isConnected: true,
    getBoundingClientRect() { return { width: 120, height: 30, left: 0, top: 0 }; },
    getAttribute() { return ""; }
  };
}

const rows = [
  { school: "中国人民大学", level: "硕士研究生", major: "税务", startTime: "2025-09-01" },
  { school: "示例大学", level: "本科", major: "经济学", startTime: "2021-09-01" }
];
const config = {
  _aiSemanticPatch: {
    fieldMappings: [
      { fieldId: "e-school", label: "学校" },
      { fieldId: "e-level", label: "学历" },
      { fieldId: "e-major", label: "专业" }
    ]
  }
};
const dataMatcher = {
  resumeData: { education: rows },
  getCategoryByTitle() { return { category: "education", type: "array", data: rows }; }
};

(async () => {
  AF.RuntimeSemanticPatch = {
    hostname: location.hostname,
    pathname: location.pathname,
    recordSelectorMappings: [
      { fieldId: "e-school", category: "education", fieldKey: "school", selector: "#school", controlType: "search" },
      { fieldId: "e-level", category: "education", fieldKey: "level", selector: "#level", controlType: "native-select" },
      { fieldId: "e-major", category: "education", fieldKey: "major", selector: "#major", controlType: "search" }
    ]
  };

  // CNPC-like blank education editor: school/major are empty, while the page has
  // already seeded the education-level control. Build143 must accept the editor
  // only when that observed value agrees with the next incomplete profile row.
  const school = fieldNode("");
  const level = fieldNode("硕士研究生");
  const major = fieldNode("");
  const save = actionNode("保存教育背景");
  const selectorMap = { "#school": [school], "#level": [level], "#major": [major] };
  const doc = { querySelectorAll(selector) { return selectorMap[selector] || []; } };
  const container = {
    ownerDocument: doc,
    isConnected: true,
    getBoundingClientRect() { return { width: 700, height: 500, left: 0, top: 0 }; },
    contains(candidate) { return [school, level, major, save].includes(candidate); },
    querySelectorAll(selector) { return selector.includes("button") ? [save] : []; }
  };
  [school, level, major, save].forEach((node) => { node.ownerDocument = doc; });

  const handler = new AF.FormHandler({ config, findContainerByTitle() { return container; } }, dataMatcher);
  let pausedRecord = null;
  handler.recordCheckpointRuntime = {
    shouldSkip() { return false; },
    async pause(meta, reason) { pausedRecord = { meta, reason }; return {}; }
  };
  handler.fieldCheckpointRuntime = { async pause() { throw new Error("unexpected FIELD pause"); } };
  handler.fillExperienceLegacy = async function () { throw new Error("education legacy fallback must not run after graph ownership is established"); };
  AF.FormHandler.fillFormElement = async (element, value) => { element.value = String(value); return true; };

  const result = await handler.fillExperience({}, "教育背景", {});
  assert.strictEqual(result, false, "manual Save checkpoint keeps the current run partial");
  assert.strictEqual(handler.lastExperienceResult.mode, "graph_repeat_record");
  assert.strictEqual(handler.lastExperienceResult.recordIndex, 0);
  assert.strictEqual(handler.lastExperienceResult.ownershipMode, "blank_identity_next_record_defaults_consistent");
  assert.strictEqual(handler.lastExperienceResult.manualSavePending, true);
  assert.strictEqual(school.value, "中国人民大学");
  assert.strictEqual(level.value, "硕士研究生");
  assert.strictEqual(major.value, "税务");
  assert(pausedRecord, "education graph bridge must pause at RECORD save boundary");
  assert.strictEqual(pausedRecord.meta.repeatIndex, 0);

  // A non-empty blank-editor default that conflicts with the next record must not
  // be used as permission to overwrite the form.
  const conflictLevel = fieldNode("本科");
  const conflictMap = { "#school": [fieldNode("")], "#level": [conflictLevel], "#major": [fieldNode("")] };
  const conflictNodes = Object.values(conflictMap).flat();
  const conflictDoc = { querySelectorAll(selector) { return conflictMap[selector] || []; } };
  conflictNodes.forEach((node) => { node.ownerDocument = conflictDoc; });
  const conflictContainer = {
    ownerDocument: conflictDoc,
    isConnected: true,
    getBoundingClientRect() { return { width: 700, height: 500, left: 0, top: 0 }; },
    contains(candidate) { return conflictNodes.includes(candidate); },
    querySelectorAll() { return []; }
  };
  const owner = RecordGraph.resolveRuntimeEditorOwnership(conflictContainer, "education", {
    sectionTitle: "教育背景",
    siteConfig: config,
    mappings: AF.RuntimeSemanticPatch.recordSelectorMappings,
    profileRecords: rows,
    isRecordCompleted() { return false; }
  });
  assert.strictEqual(owner.status, "partial_editor_identity_missing");
  assert(owner.conflictingFields.includes("level"));

  // Without graph semantic selectors, preserve the pre-Build143 sequential owner.
  AF.RuntimeSemanticPatch = { hostname: location.hostname, pathname: location.pathname, recordSelectorMappings: [] };
  const fallback = new AF.FormHandler({ config, findContainerByTitle() { return container; } }, dataMatcher);
  let legacyCalled = false;
  fallback.fillExperienceLegacy = async function () {
    legacyCalled = true;
    this.lastExperienceResult = { requestedRows: rows.length, filledRows: 0, mode: "education_sequential" };
    return true;
  };
  const fallbackResult = await fallback.fillExperience({}, "教育背景", {});
  assert.strictEqual(fallbackResult, true);
  assert.strictEqual(legacyCalled, true, "existing education sequential path must remain the fallback owner");

  console.log("build143-graph-education-reentry.test.js PASS");
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
