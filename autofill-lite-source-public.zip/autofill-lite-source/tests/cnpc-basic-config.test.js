"use strict";
// Legacy filename retained intentionally so incremental ZIP overlays neutralize
// the pre-Build57 test that incorrectly required a provisional CNPC adapter.
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const privateSites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");

const targetUrl = "https://zhaopin.cnpc.com.cn/web/createResume.html?ic=test";
global.window = { AF: {}, location: { href: targetUrl } };
global.document = {
  querySelector(selector) { return selector === "body" ? this.body : null; },
  body: { innerText: "", textContent: "", querySelectorAll() { return []; } },
};
new Function(privateSites)();
assert.strictEqual(window.AF.PrivateSpecialSites.getConfigForUrl(targetUrl), null,
  "legacy CNPC regression filename must now enforce no built-in config");
assert.strictEqual(window.AF.PrivateSpecialSites.getWorkflowForUrl(targetUrl), null,
  "legacy CNPC regression filename must now enforce no special workflow");
console.log("CNPC legacy-test compatibility regression: PASS");
