"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { compileSemanticSiteCandidate } = require("../ai-site-config-candidate");
const aiInput = require("../site-analysis-ai-input");

const review = {
  page: { hostname: "example.zhiye.com", pathname: "/form" },
  trustedMappings: [
    {
      fieldId: "t1",
      category: "jobIntention",
      fieldKey: "industry",
      label: "期望从事行业",
      confidence: 1,
      graphSectionTitle: "求职意向",
      graphLinkConfidence: 0.99
    },
    {
      fieldId: "t2",
      category: "jobIntention",
      fieldKey: "currentSalary",
      label: "现月薪(税前)",
      confidence: 1,
      graphSectionTitle: "求职意向",
      graphLinkConfidence: 0.99
    }
  ],
  reviewFields: [
    {
      fieldId: "a1",
      label: "现从事职业",
      graphSectionTitle: "求职意向",
      graphLinkConfidence: 0.99,
      patchTarget: { label: "现从事职业" }
    },
    {
      fieldId: "a2",
      label: "期望从事行业",
      graphSectionTitle: "求职意向",
      graphLinkConfidence: 0.99,
      patchTarget: { label: "期望从事行业" }
    }
  ]
};
const patch = {
  decisions: [
    { fieldId: "a1", decision: "leave_unmapped", category: "", fieldKey: "", confidence: 0.97, reason: "current occupation is not represented" },
    { fieldId: "a2", decision: "map", category: "jobIntention", fieldKey: "position", confidence: 0.95, reason: "intentionally conflicting AI decision" }
  ]
};

const out = compileSemanticSiteCandidate(review, patch, { minConfidence: 0.8 });
assert.strictEqual(out.semanticPatch.fieldMappings.length, 2, "trusted local mappings must form the candidate even when AI contributes no accepted gap mapping");
assert.strictEqual(out.summary.acceptedLocalFieldMappings, 2);
assert.strictEqual(out.summary.acceptedAiFieldMappings, 0);
assert.ok(out.semanticPatch.fieldMappings.some((item) => item.label === "期望从事行业" && item.fieldKey === "industry" && item.source === "local_core_trusted"));
assert.ok(out.semanticPatch.fieldMappings.some((item) => item.label === "现月薪(税前)" && item.fieldKey === "currentSalary" && item.source === "local_core_trusted"));
assert.ok(out.skipped.some((item) => item.fieldId === "a2" && item.reason === "ai_conflicts_with_local_trusted_mapping"), "AI must not override a local trusted mapping");

assert.ok(aiInput.AI_PROFILE_FIELD_KEYS.jobIntention.includes("currentSalary"), "AI contract must expose currentSalary");
assert.ok(aiInput.AI_PROFILE_FIELD_KEYS.basicInfo.includes("workYears"), "AI contract must expose workYears");
assert.strictEqual(aiInput.AI_PROFILE_FIELD_SEMANTICS["jobIntention.position"].includes("desired"), true);
assert.strictEqual(aiInput.AI_PROFILE_FIELD_SEMANTICS["jobIntention.currentSalary"].includes("current"), true);

const dict = fs.readFileSync(path.join(__dirname, "..", "autofill-plugin", "content", "field-dictionary.js"), "utf8");
assert.ok(dict.includes('industry: ["期望行业", "行业倾向", "期望从事行业"]'), "mature semantic exemplar for desired industry missing");
assert.ok(dict.includes('"现月薪(税前)"'), "mature semantic exemplar for current salary missing");

const api = fs.readFileSync(path.join(__dirname, "..", "ai-semantic-api.js"), "utf8");
assert.ok(api.includes("Confidence measures semantic mapping certainty only"), "AI confidence calibration missing");
assert.ok(api.includes("current occupation must not map to desired position"), "current-vs-desired semantic guard missing");

console.log("local-first semantic candidate tests passed");
