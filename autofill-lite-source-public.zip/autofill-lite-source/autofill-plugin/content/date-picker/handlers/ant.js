// content/date-picker/handlers/ant.js — Ant Design 日期选择器 (v3 .ant-calendar-* / v4 .ant-picker-*)
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   工厂分支 Kn.create() case "ant": 行 45985-45994
//     - closest(.ant-calendar-range-picker-input) -> yo (范围, 双输入框各自弹出面板)
//     - closest(.ant-calendar-picker) 或 classList含ant-calendar-picker-input -> ao (v3 单选, 内部还会
//       再判断是否其实是 .ant-calendar-range-picker 组合式范围面板)
//     - closest(.ant-picker-range) -> io (v4 范围, 单次打开双栏面板)
//     - 否则 -> Zn (v3/v4 合并单选兜底, 范围时找兄弟元素)
//   Zn.setValue 单选: 行 46204-46300 (调用 L())
//   L()/O() (v3+v4 合并单选面板打开+导航): 行 29019-29084 — 精确选择器已核实
//   ao.setValue: 行 46888-46984 (单选调用 rr()，组合范围调用 or())
//   rr()/nr() (v3 单选): 行 38152-38243 — 两种变体(有/无独立年份按钮)已核实
//   or()/ir() (v3 组合范围，左右两栏+确定按钮): 行 38244-38354 已核实
//   ar()/cr() (or() 内部逐字段年月日点击): 行 38355+ —— 这里改用通用 _navigatePanel 达到等价效果
//   yo.setValue (v3 范围分离输入框): 行 47495-47557 (调用 Vr())
//   Vr()/Yr() (v3 范围分离输入框): 行 41523-41592 已核实，含 monthPanelSelector 为
//     {nextMonthSelector,prevMonthSelector} 对象的"单月翻页"模式与 refineSelector(位置12) 的用法
//   io.setValue (v4 范围): 行 46838-46887 (调用 Ue())
//   Ue()/We() (v4 范围, 双栏一次性打开): 行 37442-37531 已核实
//
// 简化说明: Ue() 源码里第二栏(结束日期)的调用参数与第一栏不对称——第二栏 headerClickSelector=null 且把
// ".ant-picker-year-btn" 当成"年份格子列表"选择器使用，这是原作者利用"年按钮文案恰好就是年份数字"的
// 取巧写法，在真实 DOM 上跑起来比较脆弱。这里为了稳定性，第二栏改成跟第一栏一样的对称写法
// (headerClickSelector=".ant-picker-year-btn", yearCellSelector=".ant-picker-cell-in-view")，
// 效果等价（都是"点年按钮->从年列表里找目标年"），但更健壮。其余选择器与调用顺序均照抄源码。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  var nav = function (opts) { return AF.DatePicker._navigatePanel(opts); };

  function panelWait(defaultMs) {
    var configured = AF.DatePicker._currentCapability && Number(AF.DatePicker._currentCapability.waitForPanelMs);
    return configured > 0 ? configured : defaultMs;
  }

  // ---- v3+v4 合并单选 (源码 L()/O(), 行29019) ----
  async function antMergedSingle(triggerEl, dateStr, maxRetries) {
    maxRetries = maxRetries || 20;
    var input = (triggerEl.querySelector && triggerEl.querySelector("input")) || triggerEl;
    input.focus();
    await AF.DomUtils.safeClickElement(input);
    var panel = await AF.Utils.waitForElement(function () {
      return document.querySelector(
        '.ant-picker-dropdown:not(.ant-picker-dropdown-hidden):not([style*="display: none"]):not([style*="display:none"]):not([hidden])'
      );
    }, panelWait(1200));
    if (!panel) throw new Error("Ant calendar picker not found or not visible");
    var isAntV4 = !!panel.querySelector(".ant-picker-month-btn");
    var monthBtnSel = isAntV4 ? ".ant-picker-month-btn" : ".ant-calendar-month-select";
    var ok = await nav({
      container: panel,
      dateString: dateStr,
      headerClickSelector: panel.querySelector(".ant-picker-year-btn") ? ".ant-picker-year-btn" : ".ant-calendar-year-select",
      yearCellSelector: isAntV4
        ? ".ant-picker-year-panel .ant-picker-cell-in-view"
        : ".ant-calendar-year-panel-cell:not(.ant-calendar-year-panel-last-decade-cell):not(.ant-calendar-year-panel-next-decade-cell)",
      yearBoundarySelector: ".ant-picker-decade-btn",
      nextYearSelector: panel.querySelector(".ant-picker-header-super-next-btn") ? ".ant-picker-header-super-next-btn" : ".ant-calendar-year-panel-next-decade-btn",
      prevYearSelector: panel.querySelector(".ant-picker-header-super-prev-btn") ? ".ant-picker-header-super-prev-btn" : ".ant-calendar-year-panel-prev-decade-btn",
      monthPanelSelector: monthBtnSel,
      // Ant v4 的年、月、日格子都共用 .ant-picker-cell。若只用这个
      // 通用类，日期视图里的“6日”会被误认成“6月”，月份按钮根本不会
      // 打开，最终把所有 6 月 30 日错误保留成当前月份的 30 日。
      monthCellSelector: isAntV4 ? ".ant-picker-month-panel .ant-picker-cell" : ".ant-calendar-month-panel-month",
      dayCellSelector: isAntV4 ? ".ant-picker-date-panel .ant-picker-cell" : ".ant-calendar-date",
      maxRetries: maxRetries,
    });
    triggerEl.dispatchEvent(new Event("blur"));
    if (!ok) throw new Error("Ant calendar navigation failed");
    return true;
  }

  // ---- v3 单选 (源码 rr()/nr(), 行38152) ----
  async function antV3Single(triggerEl, dateStr, maxRetries) {
    maxRetries = maxRetries || 30;
    var containerSel = ".ant-calendar-picker-container:not(.slide-up-leave)";
    if (!document.querySelector(containerSel)) {
      var input = (triggerEl.querySelector && triggerEl.querySelector("input")) || triggerEl;
      input.dispatchEvent(new Event("focus"));
      input.dispatchEvent(new MouseEvent("click", { bubbles: true }));
      await AF.Utils.waitForElement(function () {
        return document.querySelector(containerSel);
      }, panelWait(1200));
    }
    var panel = document.querySelector(containerSel);
    if (!panel) throw new Error("Ant Calendar操作失败");
    var ok;
    if (panel.querySelector(".ant-calendar-year-select")) {
      ok = await nav({
        container: panel,
        dateString: dateStr,
        headerClickSelector: ".ant-calendar-year-select",
        yearCellSelector: ".ant-calendar-year-panel-cell:not(.ant-calendar-year-panel-last-decade-cell):not(.ant-calendar-year-panel-next-decade-cell)",
        yearBoundarySelector: ".ant-calendar-year-panel-decade-select-content",
        nextYearSelector: ".ant-calendar-year-panel-next-decade-btn",
        prevYearSelector: ".ant-calendar-year-panel-prev-decade-btn",
        monthPanelSelector: ".ant-calendar-month-select",
        monthCellSelector: ".ant-calendar-month-panel-month",
        dayCellSelector: ".ant-calendar-date",
        maxRetries: maxRetries,
      });
    } else {
      ok = await nav({
        container: panel,
        dateString: dateStr,
        yearCellSelector: ".ant-calendar-month-panel-year-select-content",
        disabledClassList: true,
        yearBoundarySelector: ".ant-calendar-year-panel-decade-select-content",
        nextYearSelector: ".ant-calendar-month-panel-next-year-btn",
        prevYearSelector: ".ant-calendar-month-panel-prev-year-btn",
        monthCellSelector: ".ant-calendar-month-panel-month",
        dayCellSelector: ".ant-calendar-date",
        maxRetries: maxRetries,
      });
    }
    if (!ok) throw new Error("Ant Calendar操作失败");
    return true;
  }

  // ---- v3 组合范围: 同一面板左右两栏 + 确定按钮 (源码 or()/ir(), 行38244 及 ar() 逐字段导航) ----
  async function antV3RangeCombined(triggerEl, startStr, endStr) {
    var containerSel = ".ant-calendar-picker-container:not(.slide-up-leave)";
    if (!document.querySelector(containerSel)) {
      triggerEl.dispatchEvent(new Event("focus"));
      triggerEl.dispatchEvent(new MouseEvent("click", { bubbles: true }));
      await AF.Utils.sleep(20);
    }
    var panel = document.querySelector(containerSel);
    if (!panel) return false;
    var left = panel.querySelector(".ant-calendar-range-left");
    var right = panel.querySelector(".ant-calendar-range-right");
    if (!left || !right) return false;
    await navigateRangeSide(panel, startStr, ".ant-calendar-range-left");
    await AF.Utils.sleep(100);
    await navigateRangeSide(panel, endStr, ".ant-calendar-range-right");
    await AF.Utils.sleep(100);
    var okBtn = panel.querySelector(".ant-btn-primary.certain-btn, .ant-btn.ant-btn-primary");
    if (okBtn) {
      await AF.DomUtils.safeClickElement(okBtn);
      await AF.Utils.sleep(50);
    }
    return true;
  }

  function navigateRangeSide(panel, dateStr, sideSelector) {
    return nav({
      container: panel,
      refineSelector: sideSelector,
      dateString: dateStr,
      yearCellSelector: ".ant-calendar-year-panel-year",
      disabledClassList: true,
      yearBoundarySelector: ".ant-calendar-year-panel-decade-select-content",
      nextYearSelector: ".ant-calendar-year-panel-next-decade-btn",
      prevYearSelector: ".ant-calendar-year-panel-prev-decade-btn",
      monthPanelSelector: { nextMonthSelector: ".ant-calendar-next-month-btn", prevMonthSelector: ".ant-calendar-prev-month-btn" },
      monthCellSelector: ".ant-calendar-month-select",
      dayCellSelector: ".ant-calendar-date",
      maxRetries: 20,
    });
  }

  // ---- v3 范围分离输入框 (源码 Vr()/Yr(), 行41523) ----
  async function antV3RangeSeparateInput(triggerEl, startStr, endStr) {
    triggerEl.click();
    var panel = await AF.Utils.waitForElement(function () {
      return document.querySelector('.ant-calendar-picker-container:not([style*="display: none"])');
    }, panelWait(1000));
    if (!panel) return false;
    if (panel.querySelector(".ant-calendar-month-panel")) {
      triggerEl.dispatchEvent(new Event("blur", { bubbles: true, cancelable: true }));
      document.body.click();
      await AF.Utils.sleep(100);
      return antV3RangeCombined(triggerEl, startStr, endStr);
    }
    var dates = [startStr, endStr];
    var sides = [".ant-calendar-range-left", ".ant-calendar-range-right"];
    for (var i = 0; i < 2; i++) {
      await navigateRangeSide(panel, dates[i], sides[i]);
      if (i === 0) await AF.Utils.sleep(50);
    }
    return true;
  }

  // ---- v4 范围 (源码 Ue()/We(), 行37442; 第二栏做了对称化简化, 见文件头注释) ----
  async function antV4Range(element, startStr, endStr) {
    var scopeEl = AF.DomUtils.findClosestAncestorWithClass(element, "ant-picker-range") || element;
    var inputs = scopeEl.querySelectorAll("input");
    if (!inputs.length) return false;
    inputs[0].dispatchEvent(new FocusEvent("focus", { bubbles: true, cancelable: true, view: window }));
    inputs[0].dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
    inputs[0].click();
    var panel = await AF.Utils.waitForElement(function () {
      return document.querySelector(".ant-picker-dropdown:not(.ant-picker-dropdown-hidden)");
    }, panelWait(1000));
    if (!panel) return false;
    var monthBtnSel = panel.querySelector(".ant-picker-month-btn") ? ".ant-picker-month-btn" : null;
    var common = {
      yearBoundarySelector: ".ant-picker-decade-btn",
      nextYearSelector: ".ant-picker-header-super-next-btn",
      prevYearSelector: ".ant-picker-header-super-prev-btn",
      monthPanelSelector: monthBtnSel,
      monthCellSelector: ".ant-picker-month-panel .ant-picker-cell",
      dayCellSelector: ".ant-picker-date-panel .ant-picker-cell",
      maxRetries: 20,
    };
    var ok1 = await nav(Object.assign({
      container: panel,
      refineSelector: ".ant-picker-panel:first-child",
      dateString: startStr,
      headerClickSelector: ".ant-picker-year-btn",
      yearCellSelector: ".ant-picker-year-panel .ant-picker-cell-in-view",
    }, common));
    await AF.Utils.sleep(50);
    var ok2 = await nav(Object.assign({
      container: panel,
      refineSelector: ".ant-picker-panel:last-child",
      dateString: endStr,
      headerClickSelector: ".ant-picker-year-btn",
      yearCellSelector: ".ant-picker-year-panel .ant-picker-cell-in-view",
    }, common));
    element.dispatchEvent(new Event("blur"));
    panel.classList.add("ant-picker-dropdown-hidden");
    return !!(ok1 && ok2);
  }

  // ---- 单选情形下, 用于对象值(startTime/endTime)的"找兄弟元素填结束日期"兜底 ----
  // (源码 Zn/ao 均是这个模式: findSimilarElements -> ho() 打分选最佳 -> 找不到再退回 findSurroundingInputs)
  async function fillEndSibling(element, endValue, singleSetter) {
    var candidates = AF.DomUtils.findSimilarElements(element, 4, { sameTag: true, sameClass: true, sameParent: false });
    if (candidates.length > 0) {
      var best = AF.DatePicker._pickEndDateCandidate(element, candidates);
      if (!best || best === element) return false;
      var ok = await singleSetter(best, endValue);
      await AF.Utils.sleep(500);
      return !!ok;
    }
    var surrounding = AF.DomUtils.findSurroundingInputs(element);
    if (surrounding.length > 0) {
      var target = surrounding.find(function (input) { return input && input !== element; });
      if (!target) return false;
      var okSibling = await singleSetter(target, endValue);
      await AF.Utils.sleep(500);
      return !!okSibling;
    }
    return false;
  }

  AF.DatePicker._registry["ant"] = function (element, valueType) {
    return {
      setValue: async function (value) {
        try {
          if (!value) throw new Error("日期为空");
          var isRangeSeparateInput = !!(element.closest(".ant-calendar-range-picker-input") || element.classList.contains("ant-calendar-range-picker-input"));
          var isV3Wrapped = !!(element.closest(".ant-calendar-picker") || element.classList.contains("ant-calendar-picker-input"));
          var isV4Range = !!element.closest(".ant-picker-range");

          if (typeof value === "string" || valueType === "string") {
            if (isV3Wrapped && !isRangeSeparateInput) return await antV3Single(element, value);
            return await antMergedSingle(element, value);
          }

          if (typeof value !== "object" || !("startTime" in value) || !("endTime" in value)) {
            throw new Error("当option为对象时，dateValue必须包含startTime和endTime属性");
          }

          if (isRangeSeparateInput) return await antV3RangeSeparateInput(element, value.startTime, value.endTime);
          if (isV4Range) return await antV4Range(element, value.startTime, value.endTime);
          if (isV3Wrapped) {
            if (element.closest(".ant-calendar-range-picker") || element.classList.contains("ant-calendar-range-picker")) {
              return await antV3RangeCombined(element, value.startTime, value.endTime);
            }
            await antV3Single(element, value.startTime);
            await AF.Utils.sleep(500);
            return await fillEndSibling(element, value.endTime, antV3Single);
          }
          await antMergedSingle(element, value.startTime);
          await AF.Utils.sleep(500);
          return await fillEndSibling(element, value.endTime, antMergedSingle);
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
