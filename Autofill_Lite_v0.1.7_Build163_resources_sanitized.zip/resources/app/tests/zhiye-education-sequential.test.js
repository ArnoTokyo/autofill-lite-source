"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const handler = fs.readFileSync(path.join(root, "autofill-plugin/content/form-handler.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");

assert(handler.includes("fillEducationSequentially"));
assert(handler.includes("detectEducationRecordCards(container, this.elementMatcher)"));
assert(handler.includes("usedPageIndexes"));
assert(handler.includes("示例资料_record_capacity_shortage"));
assert(handler.includes("duplicate_示例资料_scope"));
assert(handler.includes("field_not_found_in_record_scope"));
assert(handler.includes("record_count_mismatch"));
assert(handler.includes('mode: "示例资料_sequential"'));
assert(handler.includes('if (category === "示例资料")'));
const routeIndex = handler.indexOf('if (routedCategory === "示例资料")');
const genericOwnerIndex = handler.indexOf('if (this.experienceHandler)', routeIndex);
assert(routeIndex >= 0 && genericOwnerIndex > routeIndex, "示例资料 sequential owner must run before ExperienceHandler");
assert(handler.includes("genericPlanActionsCreated: 0"));
assert(handler.includes("genericEducationExecutionCount: 0"));
assert(handler.includes("sequentialExecutorEntered: true"));
assert(main.includes('data-af-示例资料-record-trace'));
assert(main.includes('示例资料RecordTrace: 示例资料RecordTrace'));
assert(main.includes('data-af-execution-route-trace'));
assert(main.includes('executionRouteTrace: executionRouteTrace'));

// Allocation model: a card appearing after row 0 is rescanned and allocated
// to row 1; a used page index can never be selected again.
const used = new Set();
function allocate(cards) {
  const available = cards.filter((_, index) => !used.has(index));
  if (!available.length) return -1;
  const index = cards.indexOf(available[0]);
  used.add(index);
  return index;
}
assert.strictEqual(allocate([{ blank: true }]), 0);
assert.strictEqual(allocate([{ blank: false }, { blank: true }]), 1);
assert.strictEqual(allocate([{ blank: false }, { blank: false }]), -1);
console.log("zhiye 示例资料 sequential tests: PASS");
