"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const sites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
const workflow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-workflow.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const documentStub = { body: null, querySelector: () => null, documentElement: { setAttribute() {} } };
const windowStub = { AF: {}, location: { href: "https://job.bankcomm.com/", hostname: "job.bankcomm.com", pathname: "/" }, getComputedStyle: () => ({ display: "block", visibility: "visible" }) };
const context = { window: windowStub, document: documentStub, URL, console, setTimeout, clearTimeout };
vm.createContext(context);
vm.runInContext(sites, context);
const api = windowStub.AF.PrivateSpecialSites._test;
assert(api && typeof api.enrichBankcommWorkRow === "function", "A: work transform hook missing");
assert(typeof api.bankcommAwardLevel === "function", "A: award level hook missing");
const internship = api.enrichBankcommWorkRow({
  __afCategory: "internshipExperience",
  startTime: "2023-07",
  endTime: "2023-08",
  startDate: "2023-07-31",
  endDate: "2023-08-31"
});
assert(internship.startTime === "2023-07-31", "B: Bankcomm work start must prefer exact startDate");
assert(internship.endTime === "2023-08-31", "B: Bankcomm work end must prefer exact endDate");
assert(internship.bankcommWorkType === "实习生", "B: internship type regression");
assert(api.bankcommAwardLevel({ awardLevel: "校级一等奖" }, "奖学金") === "校级-一等奖", "C: 校级一等奖 scholarship mapping failed");
assert(workflow.includes(".ant-calendar-picker:not(.ant-calendar-picker-disabled)"), "D: Ant v3 date picker support missing");
assert(workflow.includes(".ant-calendar-picker-input:not([disabled])"), "D: Ant v3 date input support missing");
assert(!sites.includes('bankcommStep("#social", "社会招聘应聘者额外填写信息"'), "E: social-recruitment extra section must not enter Bankcomm execution plan");
const buildMatch = main.match(/const BUILD_ID = "([^"]+)"/);
assert(buildMatch && /-\d+$/.test(buildMatch[1]), "F: current numeric Build ID missing");
console.log("bankcomm-work-date-award-social-guard.test.js passed (A-F)");
