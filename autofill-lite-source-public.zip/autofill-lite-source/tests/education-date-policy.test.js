"use strict";

const assert = require("assert");
const { normalizeProfileBackup } = require("../profile-adapter");

const raw = { profileV2: { sections: {
  basic: { values: { "姓名": "示例用户" } }, intention: { items: [] },
  education: { items: [
    { values: { "学校": "示例大学甲", "学历": "本科", "开始时间": "2018-09", "结束时间": "2022-06" } },
    { values: { "学校": "示例大学乙", "学历": "硕士", "开始日期": "2022-09-18", "结束日期": "2024-06-15" } }
  ] },
  internship: { items: [{ values: { "公司": "示例机构", "开始时间": "2023-05", "结束时间": "2023-08" } }] },
  project: { items: [] }, student: { items: [] }, awards: { items: [] }, language: { items: [] }, family: { items: [] }, self: { values: {} }, other: { values: {} }
} } };

const profile = normalizeProfileBackup(raw);
assert.strictEqual(profile.education[0].school, "示例大学乙");
assert.strictEqual(profile.education[0].startTime, "2022-09-01");
assert.strictEqual(profile.education[0].endTime, "2024-06-30");
assert.strictEqual(profile.education[1].startTime, "2018-09-01");
assert.strictEqual(profile.education[1].endTime, "2022-06-30");
assert.strictEqual(profile.basicInfo.graduationDate, "2024-06-30");
assert.strictEqual(profile.internshipExperience[0].startTime, "2023-05");
assert.strictEqual(profile.internshipExperience[0].endTime, "2023-08");
console.log("education-date-policy tests: PASS");
