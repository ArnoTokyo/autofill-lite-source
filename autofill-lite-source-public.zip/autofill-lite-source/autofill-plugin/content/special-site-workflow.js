// 特殊站点分步工作流执行器。
// 只负责：点击大类 -> 等待表单 -> 调用现有 FillEngine -> 可选保存。
// 普通“一键填写”不会进入本模块。
(function () {
  "use strict";

  function spdbLog(event, detail) {
    try {
      if (typeof window === "undefined" || !window.location || String(window.location.hostname || "").toLowerCase() !== "job.spdb.com.cn") return;
      var payload = Object.assign({ url: window.location.href, at: new Date().toISOString() }, detail || {});
      console.info("[spdb-workflow] " + event, payload);
      window.postMessage({ type: "offer-spdb-workflow-log", event: event, detail: payload }, "*");
    } catch (_) {}
  }

  var AF = (window.AF = window.AF || {});
  var DEFAULT_TIMEOUT_MS = 6000;
  var AUTO_WORKFLOW_KEY_PREFIX = "special_site_workflow_auto_";
  var AUTO_WORKFLOW_HOST_KEY_PREFIX = "special_site_workflow_auto_host_";
  var FORBIDDEN_ACTION_TEXT = /提交申请|确认投递|完成并提交|立即申请|删除|移除|放弃申请|submit|apply|delete|remove/i;
  var antCascaderBridgePromise = null;
  var lastCascaderError = "";
  var STOP_ATTRIBUTE = "data-offer-autofill-stop-requested";
  var CATEGORY_ALIASES = [
    { category: "basicInfo", labels: ["基本信息", "个人基本信息", "个人信息", "个人资料", "基础信息"] },
    { category: "jobIntention", labels: ["求职期望", "求职意向", "工作意向", "应聘信息", "职位意向", "职业意向"] },
    { category: "education", labels: ["教育经历", "教育背景", "学历信息"] },
    { category: "workExperience", labels: ["工作经历", "工作经验", "任职经历"] },
    { category: "internshipExperience", labels: ["实习经历", "实习经验"] },
    { category: "projectExperience", labels: ["项目经历", "项目经验"] },
    { category: ["workExperience", "internshipExperience"], labels: ["工作实习经历", "工作（实习）经历", "工作(实习)经历", "工作/实习经历", "工作及实习经历"] },
    { category: "campusLeadership", labels: ["在校职务", "学生干部", "校园任职"] },
    { category: "campusActivities", labels: ["校园活动", "校园经历", "社会实践", "实践经历"] },
    { category: "awards", labels: ["获奖经历", "荣誉或奖励", "荣誉奖励", "奖项荣誉", "获奖情况"] },
    { category: "languageSkills", labels: ["语言能力", "外语能力", "英语能力"] },
    { category: "certificates", labels: ["证书信息", "资格认证", "资格证书", "技能证书"] },
    { category: ["languageSkills", "certificates"], labels: ["语言及证书", "语言证书", "技能及证书"] },
    { category: "familyMembers", labels: ["家庭成员", "家庭关系", "家庭情况", "家庭信息"] },
    { category: "publications", labels: ["论文期刊", "发表文章及出版专著", "发表文章及出版著作", "发表文章", "出版专著", "出版著作", "学术成果", "论文成果", "发表论文"] },
    { category: "patents", labels: ["专利成果", "专利信息"] },
    { category: "selfIntroduction", labels: ["自我介绍", "自我评价", "个人评价"] },
  ];

  function sleep(ms) {
    if (AF.Utils && typeof AF.Utils.sleep === "function") return AF.Utils.sleep(ms);
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  function isStopRequested() {
    return window.__OFFER_AUTOFILL_STOP_REQUESTED__ === true ||
      !!(document.documentElement && document.documentElement.hasAttribute(STOP_ATTRIBUTE));
  }

  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, "").replace(/[：:*＊]/g, "").trim();
  }

  function normalizeSpdbDegree(value) {
    if (AF.DomUtils && typeof AF.DomUtils.normalizeDegreeValue === "function") {
      return AF.DomUtils.normalizeDegreeValue(value);
    }
    var text = String(value == null ? "" : value).trim();
    if (!text) return "";
    if (/^(?:无|无学位|未取得|未获得|未获)/.test(text)) return "无学位";
    if (/博士|博研/.test(text)) return "博士";
    if (/硕士|硕研|研究生|MBA|EMBA/i.test(text)) return "硕士";
    if (/学士|本科|大学/.test(text)) return "学士";
    if (/专科|大专/.test(text)) return "大专";
    return text;
  }

  function storageGet(keys) {
    return new Promise(function (resolve) {
      chrome.storage.local.get(keys, function (result) { resolve(result || {}); });
    });
  }

  function storageSet(payload) {
    return new Promise(function (resolve, reject) {
      chrome.storage.local.set(payload, function () {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve();
      });
    });
  }

  function storageRemove(keys) {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.remove(keys, function () { resolve(); });
      } catch (e) { resolve(); }
    });
  }

  // Build131: checkpoint/failure persistence is shared by Autofill Core.
  // This workflow keeps only site-plan resolution and execution ownership logic.
  var CheckpointCore = AF.CheckpointCore || null;
  function checkpointCore() {
    CheckpointCore = CheckpointCore || AF.CheckpointCore || null;
    if (!CheckpointCore) throw new Error("CheckpointCore 未加载");
    return CheckpointCore;
  }

  async function loadManualWorkflowCheckpoint(workflow) {
    return checkpointCore().loadManualCheckpoint(workflow, window.location);
  }

  async function saveManualWorkflowCheckpoint(workflow, step, phase, detail) {
    return checkpointCore().saveManualCheckpoint(workflow, step, phase, detail, window.location);
  }

  async function clearManualWorkflowCheckpoint() {
    return checkpointCore().clearManualCheckpoint();
  }

  async function getManualWorkflowCheckpointForCurrentPage() {
    try {
      var workflow = await resolveWorkflow(window.location.href);
      if (!workflow) return null;
      return await loadManualWorkflowCheckpoint(workflow);
    } catch (e) { return null; }
  }

  function recoveryCheckpointRouteKey() {
    return checkpointCore().routeKey(window.location);
  }

  function recoveryCheckpointHash(value) {
    return checkpointCore().hash(value);
  }

  function recoveryRecordFingerprint(row) {
    return checkpointCore().recordFingerprint(row);
  }

  function recoveryStepFingerprint(step) {
    return checkpointCore().stepRecordFingerprint(step);
  }

  function legacyRecoveryCheckpointWorkflow(workflow) {
    var id = String(workflow && (workflow.id || workflow.name) || "");
    return id === "bankcomm-recruitment" || id === "zhaopin-campus-enterprise-resume-v1";
  }

  function stepHasDeterministicActionSequence(step) {
    if (!step || step.enabled === false) return false;
    return ["fieldSequence", "rowFieldSequence", "preFieldSequence", "extraFieldSequence"].some(function (key) {
      return Array.isArray(step[key]) && step[key].length > 0;
    });
  }

  // Build152: action-cursor recovery is a capability of deterministic special-workflow
  // field sequences, not a privilege of specific hostnames. This brings all mature
  // private workflows that already declare fieldSequence/rowFieldSequence onto the
  // same checkpoint semantics as BankComm/Zhaopin, while leaving opaque/custom
  // workflows unchanged. A site may explicitly opt out if its sequence has side
  // effects that cannot be replayed safely.
  function workflowHasDeterministicActionSequence(workflow) {
    if (!workflow || workflow.disableActionCursorCheckpoint === true) return false;
    if (workflow.enableActionCursorCheckpoint === true) return true;
    var steps = Array.isArray(workflow.steps) ? workflow.steps : [];
    return steps.some(stepHasDeterministicActionSequence);
  }

  function supportedRecoveryCheckpointWorkflow(workflow) {
    return legacyRecoveryCheckpointWorkflow(workflow) || workflowHasDeterministicActionSequence(workflow);
  }

  function shouldPersistRecoveryCheckpoint(workflow, failureContext) {
    if (!failureContext || failureContext.recoverability === "UNSAFE_STOP") return false;
    // Preserve the two historically validated whole-step recovery paths for old
    // checkpoints. Newly generalized workflows only persist a recovery marker when
    // an action cursor proves exactly where execution may resume.
    return legacyRecoveryCheckpointWorkflow(workflow) || !!failureContext.actionCursor;
  }

  async function loadRecoveryWorkflowCheckpoint(workflow) {
    return checkpointCore().loadRecoveryCheckpoint(workflow, window.location);
  }

  async function clearRecoveryWorkflowCheckpoint() {
    return checkpointCore().clearRecoveryCheckpoint();
  }

  async function getRecoveryWorkflowCheckpointForCurrentPage() {
    try {
      var workflow = await resolveWorkflow(window.location.href);
      if (!workflow) return null;
      return await loadRecoveryWorkflowCheckpoint(workflow);
    } catch (e) { return null; }
  }

  function primaryFailureFromResult(result) {
    return checkpointCore().primaryFailureFromResult(result);
  }

  function classifyRecoverableFailure(step, errorMessage, result) {
    return checkpointCore().classifyRecoverableFailure(step, errorMessage, result);
  }

  function buildFailureContext(workflow, step, errorMessage, result) {
    return checkpointCore().buildFailureContext(workflow, step, errorMessage, result);
  }

  async function saveRecoveryWorkflowCheckpoint(workflow, step, failureContext, completedState) {
    return checkpointCore().saveRecoveryCheckpoint(workflow, step, failureContext, completedState, window.location);
  }

  function recoveryCheckpointStepKey(step) {
    return checkpointCore().stepKey(step);
  }

  // Build151: BankComm and Zhaopin keep their mature site workflows, but
  // checkpoint recovery is action-cursor based. The cursor identifies the
  // first field action that may execute after the user acknowledges a manual
  // field, so the already-completed prefix of a card is never replayed.
  function specialSequenceActionId(item, index) {
    var key = String(item && (item.field || item.label) || "field");
    return "FIELD:" + key + ":" + Number(index || 0);
  }

  function deriveSingleFailureSequenceCursor(step, result) {
    if (!step || step.__afCheckpointActionCursorEnabled !== true || !result || result.sequenceActionCursor) return null;
    var failed = Array.isArray(result.failedFields) ? result.failedFields.filter(function (item) { return item && item.fieldKey; }) : [];
    if (failed.length !== 1) return null;
    var failureKey = String(failed[0].fieldKey || "");
    var phases = [
      { name: "pre", items: step.preFieldSequence },
      { name: "main", items: step.fieldSequence },
      { name: "row", items: step.rowFieldSequence },
      { name: "extra", items: step.extraFieldSequence }
    ].filter(function (phase) { return Array.isArray(phase.items) && phase.items.length; });
    var matches = [];
    phases.forEach(function (phase) {
      phase.items.forEach(function (item, index) {
        if (String(item && item.field || "") === failureKey) matches.push({ phase: phase.name, items: phase.items, index: index, item: item });
      });
    });
    if (matches.length !== 1) return null;
    var match = matches[0];
    // If the executor reached its final summary with exactly one failed field, every
    // other declared action in the step has already been attempted successfully or
    // intentionally skipped. The safe recovery point is therefore SAVE, not replay.
    var completed = [];
    phases.forEach(function (phase) {
      phase.items.forEach(function (item, index) {
        if (!(phase.name === match.phase && index === match.index)) completed.push(specialSequenceActionId(item, index));
      });
    });
    return {
      currentAction: specialSequenceActionId(match.item, match.index),
      nextAction: "SAVE",
      failedFieldIndex: match.index,
      resumeFieldIndex: match.items.length,
      completedActions: completed.slice(0, 200),
      acknowledgeCurrentActionOnRerun: true,
      sequencePhase: match.phase,
      fallbackDerivedFromSingleFailure: true
    };
  }

  function ensureSpecialSequenceCursor(step, result) {
    if (!result || typeof result !== "object") return result;
    if (!result.sequenceActionCursor) {
      var derived = deriveSingleFailureSequenceCursor(step, result);
      if (derived) result.sequenceActionCursor = derived;
    }
    return result;
  }

  function normalizedSpecialSequenceCursor(marker) {
    var cursor = marker && marker.actionCursor;
    if (!cursor || typeof cursor !== "object") return null;
    var resumeFieldIndex = Number(cursor.resumeFieldIndex);
    if (!Number.isInteger(resumeFieldIndex) || resumeFieldIndex < 0) return null;
    return {
      currentAction: String(cursor.currentAction || ""),
      nextAction: String(cursor.nextAction || ""),
      failedFieldIndex: Number.isInteger(Number(cursor.failedFieldIndex)) ? Number(cursor.failedFieldIndex) : -1,
      resumeFieldIndex: resumeFieldIndex,
      completedActions: Array.isArray(cursor.completedActions) ? cursor.completedActions.slice(0, 200) : [],
      acknowledgeCurrentActionOnRerun: cursor.acknowledgeCurrentActionOnRerun !== false,
      sequencePhase: String(cursor.sequencePhase || "main"),
      fallbackDerivedFromSingleFailure: cursor.fallbackDerivedFromSingleFailure === true
    };
  }

  function resolveRecoveryCheckpointPlanPosition(marker, steps, resume) {
    if (!marker || !Array.isArray(steps) || !steps.length) return null;
    var markerName = normalizeSectionTitle(marker.stepName || "");
    var markerCategory = String(marker.category || "");
    var markerKey = String(marker.stepKey || "");
    var candidates = [];
    steps.forEach(function (step, index) {
      if (!step || step.enabled === false) return;
      var title = normalizeSectionTitle(step.cardTitle || step.name || "");
      var category = Array.isArray(step.category)
        ? step.category.join("+")
        : String(step.categoryOverride || step.category || "");
      var key = recoveryCheckpointStepKey(step);
      var keyMatch = !!(markerKey && key === markerKey);
      var nameMatch = !!(markerName && title === markerName);
      var categoryMatch = !markerCategory || markerCategory === category;
      if ((keyMatch || nameMatch) && categoryMatch) candidates.push({ step: step, planIndex: index });
    });
    if (!candidates.length) {
      var legacyIndex = Number(marker.stepIndex);
      if (Number.isInteger(legacyIndex) && legacyIndex >= 0 && legacyIndex < steps.length) {
        candidates.push({ step: steps[legacyIndex], planIndex: legacyIndex });
      }
    }
    for (var i = 0; i < candidates.length; i++) {
      var candidate = candidates[i];
      var repeatIndex = Number(marker.repeatIndex);
      if (Number.isInteger(repeatIndex) && repeatIndex >= 0 && marker.recordFingerprint) {
        var decision = getStepDataDecision(candidate.step, resume, { skipManualCheckpoint: true });
        var rows = Array.isArray(decision && decision.rows) ? decision.rows : [];
        if (!rows[repeatIndex]) continue;
        if (recoveryRecordFingerprint(rows[repeatIndex]) !== String(marker.recordFingerprint)) continue;
      }
      return candidate;
    }
    return null;
  }

  function validateRecoveryCheckpointAgainstPlan(marker, steps, resume) {
    return !!resolveRecoveryCheckpointPlanPosition(marker, steps, resume);
  }

  function isCheckpointStepEditorOpen(step) {
    if (!step) return false;
    var root = null;
    try {
      root = step.scopeSelector ? document.querySelector(step.scopeSelector) : null;
    } catch (eRoot) {}
    root = root || findStepCard(step, document) || document;
    var selectors = [];
    if (step.readySelector) selectors.push(step.readySelector);
    if (step.repeatReadySelector) selectors.push(step.repeatReadySelector);
    selectors.push("form.ant-form", "form.el-form", "form");
    for (var i = 0; i < selectors.length; i++) {
      try {
        if (queryVisibleIncludingRoot(root, selectors[i]).some(isVisible)) return true;
      } catch (e) {}
    }
    return false;
  }

  function autoWorkflowKey(url) {
    var parsed = new URL(url || window.location.href);
    var route = (parsed.pathname || "/").replace(/[^a-zA-Z0-9_-]+/g, "_").slice(0, 120);
    return AUTO_WORKFLOW_KEY_PREFIX + parsed.hostname + "_" + route;
  }

  function autoWorkflowHostKey(url) {
    return AUTO_WORKFLOW_HOST_KEY_PREFIX + new URL(url || window.location.href).hostname;
  }

  function isVisible(element) {
    if (!element) return false;
    if (AF.DomUtils && typeof AF.DomUtils.isElementVisible === "function") {
      return AF.DomUtils.isElementVisible(element);
    }
    return !!(element.offsetWidth || element.offsetHeight || element.getClientRects().length);
  }

  function matchesHostname(rule, hostname) {
    if (!rule) return false;
    if (Array.isArray(rule)) return rule.indexOf(hostname) !== -1;
    if (rule instanceof RegExp) {
      rule.lastIndex = 0;
      return rule.test(hostname);
    }
    return String(rule).toLowerCase() === String(hostname).toLowerCase();
  }

  function matchesUrl(rule, url) {
    if (!rule) return true;
    if (rule instanceof RegExp) {
      rule.lastIndex = 0;
      return rule.test(url);
    }
    if (typeof rule === "function") return rule(url) === true;
    return url.indexOf(String(rule)) !== -1;
  }

  // ChinaHR 只有未命中私有特殊工作流时才按普通站点处理。
  function isChinaHrOrdinaryPage(url) {
    try {
      var targetUrl = url || window.location.href;
      return /^applyjob\.chinahr\.com$/i.test(new URL(targetUrl).hostname) &&
        !(AF.PrivateSpecialSites && AF.PrivateSpecialSites.has && AF.PrivateSpecialSites.has(targetUrl));
    }
    catch (e) { return false; }
  }

  function match(url) {
    var parsed;
    try {
      parsed = new URL(url || window.location.href);
    } catch (e) {
      return null;
    }
    var privateWorkflow = AF.PrivateSpecialSites && AF.PrivateSpecialSites.getWorkflowForUrl
      ? AF.PrivateSpecialSites.getWorkflowForUrl(url || window.location.href)
      : null;
    if (privateWorkflow) return privateWorkflow;
    if (isChinaHrOrdinaryPage(url)) return null;

    var workflows = AF.SPECIAL_SITE_WORKFLOWS || [];
    for (var i = 0; i < workflows.length; i++) {
      var workflow = workflows[i];
      if (!workflow || workflow.enabled === false) continue;
      if (!matchesHostname(workflow.hostname, parsed.hostname)) continue;
      if (!matchesUrl(workflow.urlPattern, parsed.href)) continue;
      if (workflow.pageGuardSelector && !document.querySelector(workflow.pageGuardSelector)) continue;
      return workflow;
    }
    return null;
  }

  async function resolveWorkflow(url) {
    if (isChinaHrOrdinaryPage(url)) return null;
    try {
      var parsedUrl = new URL(url || window.location.href);
    } catch (eGuard) {}
    var configured = match(url);
    if (configured) return configured;
    try {
      var key = autoWorkflowKey(url);
      var hostKey = autoWorkflowHostKey(url);
      var stored = await storageGet([key, hostKey]);
      var candidates = [stored[key] && stored[key].workflow, stored[hostKey] && stored[hostKey].workflow].filter(Boolean);
      for (var i = 0; i < candidates.length; i++) {
        var workflow = candidates[i];
        if (!Array.isArray(workflow.steps) || workflow.steps.length === 0) continue;
        var presentTriggers = workflow.steps.filter(function (step) {
          try { return step.triggerSelector && document.querySelector(step.triggerSelector); } catch (e) { return false; }
        }).length;
        if (presentTriggers >= Math.min(2, workflow.steps.length)) return workflow;
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  function categoryForNavigationText(text) {
    var normalized = normalizeText(text)
      .replace(/[（(](待完善|已完善|未完善|选填|必填)[）)]/g, "")
      .replace(/(待完善|已完善|未完善)$/, "");
    if (!normalized || normalized.length > 20) return null;
    for (var i = 0; i < CATEGORY_ALIASES.length; i++) {
      var entry = CATEGORY_ALIASES[i];
      for (var j = 0; j < entry.labels.length; j++) {
        var alias = normalizeText(entry.labels[j]);
        if (normalized === alias || (normalized.length <= alias.length + 4 && normalized.indexOf(alias) !== -1)) {
          return { category: entry.category, name: entry.labels[j] };
        }
      }
    }
    return null;
  }

  function cssString(value) {
    return String(value || "").replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  }

  function uniqueSelector(element) {
    if (!element || !(element instanceof Element)) return "";
    if (element.id) return "#" + String(element.id).replace(/([^a-zA-Z0-9_-])/g, "\\$1");
    var attrs = ["data-menu-key", "data-key", "data-index", "aria-controls", "name", "href"];
    for (var i = 0; i < attrs.length; i++) {
      var value = element.getAttribute && element.getAttribute(attrs[i]);
      if (!value || value === "#" || /^javascript:/i.test(value)) continue;
      var selector = element.tagName.toLowerCase() + "[" + attrs[i] + '="' + cssString(value) + '"]';
      try {
        if (document.querySelectorAll(selector).length === 1) return selector;
      } catch (e) {}
    }
    var path = [];
    var current = element;
    for (var depth = 0; current && current !== document.body && depth < 5; depth++) {
      var part = current.tagName.toLowerCase();
      var stableClasses = Array.from(current.classList || []).filter(function (name) {
        return name && !/active|selected|current|open|hover|focus|\d{4,}/i.test(name);
      }).slice(0, 2);
      if (stableClasses.length) part += stableClasses.map(function (name) { return "." + name.replace(/([^a-zA-Z0-9_-])/g, "\\$1"); }).join("");
      if (current.parentElement) {
        var siblings = Array.from(current.parentElement.children).filter(function (node) { return node.tagName === current.tagName; });
        if (siblings.length > 1) part += ":nth-of-type(" + (siblings.indexOf(current) + 1) + ")";
      }
      path.unshift(part);
      var candidate = path.join(" > ");
      try {
        if (document.querySelectorAll(candidate).length === 1) return candidate;
      } catch (e) {}
      current = current.parentElement;
    }
    return path.join(" > ");
  }

  function discoverNavigationItems() {
    var selector = [
      "[role='tab']", "[role='menuitem']", ".ant-menu-item", ".el-menu-item", ".ivu-menu-item",
      ".next-menu-item", ".nav-item", ".menu-item", ".tab-item", "aside li", "nav li", "ul li",
      "[class*='sidebar'] li", "[class*='menu'] li", "[class*='menu'] > div", "[class*='nav'] li",
      "[class*='tab'] > div", "[class*='step']"
    ].join(",");
    var nodes = [];
    try { nodes = Array.from(document.querySelectorAll(selector)); } catch (e) {}
    var seen = {};
    var items = [];
    nodes.forEach(function (node) {
      if (!isVisible(node) || node.closest("#autofill-panel-root, #autofill-mini-logo")) return;
      var text = normalizeText(node.textContent || node.value || node.getAttribute("aria-label") || node.getAttribute("title"));
      var mapped = categoryForNavigationText(text);
      if (!mapped) return;
      var key = Array.isArray(mapped.category) ? mapped.category.join("+") : mapped.category;
      if (seen[key]) return;
      var triggerSelector = uniqueSelector(node);
      if (!triggerSelector) return;
      seen[key] = true;
      items.push({
        name: text || mapped.name,
        category: mapped.category,
        triggerSelector: triggerSelector,
        triggerText: [text || mapped.name],
        fillMode: "full",
        waitAfterClickMs: 700,
        timeoutMs: 6000,
        skipClickWhenReady: false,
        autoDiscovered: true,
      });
    });
    return items;
  }

  async function discoverAndSave(url) {
    var parsed = new URL(url || window.location.href);
    var steps = discoverNavigationItems();
    if (steps.length < 2) {
      throw new Error("自动识别到的大类入口不足2个。请确认当前页面已展示侧边栏/顶部大类导航，再重新诊断");
    }
    var workflow = {
      id: "auto_" + parsed.hostname,
      name: parsed.hostname + " 自动识别工作流",
      enabled: true,
      hostname: parsed.hostname,
      urlPattern: parsed.pathname || "/",
      continueOnError: true,
      autoDiscovered: true,
      discoveredAt: new Date().toISOString(),
      steps: steps,
    };
    var key = autoWorkflowKey(parsed.href);
    var hostKey = autoWorkflowHostKey(parsed.href);
    var payload = {};
    payload[key] = { workflow: workflow, savedAt: Date.now(), url: parsed.origin + parsed.pathname };
    payload[hostKey] = payload[key];
    await storageSet(payload);
    return workflow;
  }

  function findByText(root, texts, selector) {
    var wanted = (Array.isArray(texts) ? texts : texts ? [texts] : []).map(normalizeText).filter(Boolean);
    if (!wanted.length) return null;
    var query = selector || "button, a, [role='tab'], [role='menuitem'], li, [data-menu-key], [data-key]";
    var nodes;
    try {
      nodes = Array.from((root || document).querySelectorAll(query));
    } catch (e) {
      return null;
    }
    return nodes.find(function (node) {
      if (!isVisible(node)) return false;
      var text = normalizeText(node.textContent || node.getAttribute("aria-label") || node.getAttribute("title"));
      return wanted.some(function (target) { return text === target; });
    }) || null;
  }

  function findAddButtonByText(root, texts, selector) {
    var wanted = (Array.isArray(texts) ? texts : texts ? [texts] : []).map(normalizeText).filter(Boolean);
    if (!wanted.length) return null;
    var query = selector || "button, a, [role='button'], div, span";
    var nodes;
    try {
      nodes = Array.from((root || document).querySelectorAll(query));
    } catch (e) {
      return null;
    }
    var matches = nodes.filter(function (node) {
      if (!isVisible(node)) return false;
      var text = normalizeText(node.textContent || node.getAttribute("aria-label") || node.getAttribute("title"));
      if (!text) return false;
      return wanted.some(function (target) {
        return text === target || text.indexOf(target) !== -1 || target.indexOf(text) !== -1;
      });
    });
    matches.sort(function (a, b) {
      var at = normalizeText(a.textContent || a.getAttribute("aria-label") || a.getAttribute("title"));
      var bt = normalizeText(b.textContent || b.getAttribute("aria-label") || b.getAttribute("title"));
      var aExact = wanted.indexOf(at) !== -1 ? 0 : 1;
      var bExact = wanted.indexOf(bt) !== -1 ? 0 : 1;
      if (aExact !== bExact) return aExact - bExact;
      var aAdd = /(^|\s)add-btn(\s|$)|el-button|button/i.test(String(a.className || "")) || a.tagName === "BUTTON" ? 0 : 1;
      var bAdd = /(^|\s)add-btn(\s|$)|el-button|button/i.test(String(b.className || "")) || b.tagName === "BUTTON" ? 0 : 1;
      if (aAdd !== bAdd) return aAdd - bAdd;
      return at.length - bt.length;
    });
    return matches[0] || null;
  }

  function findStepCard(step, root) {
    if (!step) return null;
    root = root || document;
    try {
      // 已知特殊站点可以直接声明栏目根节点。优先使用稳定模块容器，避免栏目
      // 标题只出现在侧边栏时向上爬到整个页面，把其他模块的表单/校验红字
      // 错当成当前步骤内容。
      if (step.sectionRootSelector) {
        var explicitSections = Array.from(root.querySelectorAll(step.sectionRootSelector)).filter(isVisible);
        var explicitWanted = step.cardTitle || step.name;
        if (explicitSections.length === 1 && !step.sectionByTitle && !explicitWanted) {
          return explicitSections[0];
        }
        var explicitMatched = explicitSections.find(function (section) {
          var title = section.querySelector(step.cardTitleSelector || ".modules-title .title, .title-wrapper .title, [class*='title']");
          return title && titleMatchesSection(title.textContent, explicitWanted);
        });
        if (explicitMatched) return explicitMatched;
      }
      if (!step.cardTitle && step.scopeSelector) {
        var explicitScopes = Array.from(root.querySelectorAll(step.scopeSelector)).filter(isVisible);
        if (explicitScopes.length) return explicitScopes[0];
      }
      if (!step.cardTitle) return null;
      if (step.sectionByTitle) {
        var sectionCard = findSectionCardByTitle(step, root);
        if (sectionCard) return sectionCard;
      }
      var cards = Array.from(root.querySelectorAll(step.cardSelector || ".ant-card"));
      var wantedTitle = normalizeText(step.cardTitle);
      return cards.find(function (candidate) {
        if (!isVisible(candidate)) return false;
        var title = candidate.querySelector(step.cardTitleSelector || ".ant-card-head-title");
        // 某些经历栏目把“添加工作经验”也放在标题容器内。
        // 若必须与 cardTitle 字节级相等，第一条保存并重绘后就会
        // 找不到栏目根节点，虽然能新增空表单，却无法定位第二条。
        return title && titleMatchesSection(title.textContent, wantedTitle);
      }) || null;
    } catch (e) {
      return null;
    }
  }

  function normalizeSectionTitle(value) {
    return normalizeText(value)
      .replace(/[\uE000-\uF8FF]/g, "")
      .replace(/（必填）|\(必填\)|待完善|已完善|未完善/g, "")
      .replace(/[：:]\s*$/g, "")
      .trim();
  }

  function titleMatchesSection(text, wanted) {
    var actual = normalizeSectionTitle(text);
    var target = normalizeSectionTitle(wanted);
    if (!actual || !target) return false;
    if (actual === target) return true;
    if (actual.length > target.length + 24) return false;
    return actual.indexOf(target) !== -1 || target.indexOf(actual) !== -1;
  }

  function sectionControlCount(root) {
    if (!root) return 0;
    var selector = [
      "input:not([type='hidden'])",
      "textarea",
      "select",
      "[contenteditable='true']",
      "[role='textbox']",
      "[role='combobox']",
      ".el-select",
      ".el-cascader",
      ".ant-select",
      ".ant-cascader-picker"
    ].join(",");
    try {
      return Array.from(root.querySelectorAll(selector)).filter(isVisible).length;
    } catch (e) {
      return 0;
    }
  }

  function findSectionCardByTitle(step, root) {
    root = root || document;
    var wantedTitle = step.cardTitle || step.name;
    if (!wantedTitle) return null;
    var titleSelector = step.cardTitleSelector || [
      "h1", "h2", "h3", "h4", "h5", "h6",
      "[class*='title' i]",
      "[class*='header' i]",
      "[class*='name' i]",
      "label",
      "span"
    ].join(",");
    var titleNodes = [];
    try {
      titleNodes = Array.from(root.querySelectorAll(titleSelector)).filter(function (node) {
        if (!isVisible(node)) return false;
        return titleMatchesSection(node.textContent || node.getAttribute("aria-label") || node.getAttribute("title"), wantedTitle);
      });
    } catch (e) {
      return null;
    }
    titleNodes.sort(function (a, b) {
      var at = normalizeSectionTitle(a.textContent || "");
      var bt = normalizeSectionTitle(b.textContent || "");
      var target = normalizeSectionTitle(wantedTitle);
      var aExact = at === target ? 0 : 1;
      var bExact = bt === target ? 0 : 1;
      if (aExact !== bExact) return aExact - bExact;
      return at.length - bt.length;
    });

    var minFields = step.minSectionFields == null ? 1 : step.minSectionFields;
    for (var i = 0; i < titleNodes.length; i++) {
      var node = titleNodes[i];
      var adjacent = findAdjacentSectionBody(node, step, minFields);
      if (adjacent) return adjacent;
      var current = node;
      for (var depth = 0; current && current !== document && depth < 10; depth++, current = current.parentElement) {
        if (!isVisible(current)) continue;
        var fields = sectionControlCount(current);
        if (fields < minFields) continue;
        if (step.sectionRequiresSave !== false && step.saveText) {
          var save = findByText(current, step.saveText, "button, a, [role='button']");
          if (!save) continue;
        }
        return current;
      }
    }
    return null;
  }

  function sectionHasSave(root, step) {
    if (!root) return false;
    if (step.sectionRequiresSave === false || !step.saveText) return true;
    return !!findByText(root, step.saveText, "button, a, [role='button']");
  }

  function isLikelySectionHeading(node) {
    if (!node || !isVisible(node)) return false;
    var text = normalizeSectionTitle(node.textContent || "");
    if (!text || text.length > 40) return false;
    if (/必填|待完善|经历|信息|能力|证书|特长|亲属|薪酬|意向/.test(node.textContent || "")) return true;
    return !!(node.matches && node.matches("h1,h2,h3,h4,h5,h6,[class*='title' i],[class*='header' i]"));
  }

  function findAdjacentSectionBody(titleNode, step, minFields) {
    var bases = [];
    var current = titleNode;
    for (var depth = 0; current && current !== document && depth < 5; depth++, current = current.parentElement) {
      bases.push(current);
    }
    for (var i = 0; i < bases.length; i++) {
      var sibling = bases[i] && bases[i].nextElementSibling;
      for (var guard = 0; sibling && guard < 5; guard++, sibling = sibling.nextElementSibling) {
        if (!isVisible(sibling)) continue;
        if (sectionControlCount(sibling) >= minFields && sectionHasSave(sibling, step)) return sibling;
        if (isLikelySectionHeading(sibling)) break;
      }
    }
    return null;
  }

  function findTrigger(step) {
    var root = step.triggerRootSelector ? document.querySelector(step.triggerRootSelector) : document;
    if (!root) return null;
    if (step.preferNavigationTrigger) {
      var navigationTrigger = findNavigationTriggerByText(root, step.triggerText || step.name, step);
      if (navigationTrigger) return navigationTrigger;
    }
    if (step.cardTitle && !step.sectionByTitle) {
      try {
        var card = findStepCard(step, root);
        if (!card) return null;
        if (step.preferEditExistingRecords && Number.isInteger(step.repeatIndex)) {
          var existingEditButtons = Array.from(card.querySelectorAll(".record_view > .Nright a.edit, .record_view .Nright a.edit")).filter(isVisible);
          if (existingEditButtons[step.repeatIndex]) return existingEditButtons[step.repeatIndex];
        }
        var action = card.querySelector(step.cardActionSelector || ".ant-card-extra");
        if (!action || !isVisible(action)) return null;
        if (step.triggerActionText) {
          var actionText = normalizeText(action.textContent);
          var wantedActions = (Array.isArray(step.triggerActionText) ? step.triggerActionText : [step.triggerActionText]).map(normalizeText);
          if (!wantedActions.some(function (text) { return actionText === text || actionText.indexOf(text) !== -1; })) return null;
        }
        // Ant Card 的 .ant-card-extra 通常只是布局容器，真正的 React onClick
        // 绑定在内部 a/button/span 上。点击外层时事件不会“向下”触发子节点监听器。
        // 优先返回文本匹配的最内层操作节点，找不到时再退回 extra 容器。
        var actionTarget = findByText(
          action,
          step.triggerActionText || step.name,
          step.cardActionClickSelector || "button, a, [role='button'], span"
        );
        if (!actionTarget) {
          try {
            actionTarget = action.querySelector(step.cardActionClickSelector || "button, a, [role='button'], span");
          } catch (e) {}
        }
        return actionTarget && isVisible(actionTarget) ? actionTarget : action;
      } catch (e) {
        return null;
      }
    }
    if (step.triggerSelector) {
      try {
        var selected = root.querySelector(step.triggerSelector);
        if (selected) return selected;
      } catch (e) {}
    }
    return findByText(root, step.triggerText || step.name, step.triggerCandidateSelector);
  }

  function findNavigationTriggerByText(root, texts, step) {
    var wanted = (Array.isArray(texts) ? texts : texts ? [texts] : []).map(normalizeSectionTitle).filter(Boolean);
    if (!wanted.length) return null;
    var selector = step.navigationTriggerCandidateSelector ||
      "button, a, [role='button'], [role='tab'], [role='menuitem'], li, nav *, aside *, [class*='side' i] *, [class*='menu' i] *, [class*='nav' i] *, [class*='catalog' i] *, div, span";
    var nodes = [];
    try { nodes = Array.from((root || document).querySelectorAll(selector)); } catch (e) { return null; }
    var matches = nodes.filter(function (node) {
      if (!isVisible(node)) return false;
      var text = normalizeSectionTitle(node.textContent || node.getAttribute("aria-label") || node.getAttribute("title"));
      if (!text || text.length > 60) return false;
      return wanted.some(function (target) {
        return text === target || text.indexOf(target) !== -1 || target.indexOf(text) !== -1;
      });
    }).map(function (node) {
      var clickable = node.closest && node.closest("button, a, [role='button'], [role='tab'], [role='menuitem'], li, [class*='item' i], [class*='menu' i]") || node;
      var text = normalizeSectionTitle(clickable.textContent || node.textContent || clickable.getAttribute("aria-label") || clickable.getAttribute("title"));
      var rect = clickable.getBoundingClientRect ? clickable.getBoundingClientRect() : { left: 0, top: 0, width: 0, height: 0 };
      var fieldCount = sectionControlCount(clickable);
      var hasSave = !!findByText(clickable, ["保存"], "button, a, [role='button']");
      var cls = String(clickable.className || "");
      var navish = /(side|menu|nav|catalog|anchor|tab|right|affix|steps|toc)/i.test(cls) ||
        !!(clickable.closest && clickable.closest("nav, aside, [class*='side' i], [class*='menu' i], [class*='nav' i], [class*='catalog' i], [class*='anchor' i]"));
      var exact = wanted.indexOf(text) !== -1 || wanted.some(function (target) { return text === target + "待完善" || text === target + "已完善"; });
      return {
        element: clickable,
        score: (exact ? 0 : 20) +
          (navish ? 0 : 30) +
          (fieldCount === 0 ? 0 : 60 + fieldCount) +
          (hasSave ? 80 : 0) +
          (rect.left > (window.innerWidth || 1200) * 0.55 ? 0 : 12) +
          Math.min(20, Math.max(0, text.length - 4)),
      };
    });
    var seen = [];
    matches = matches.filter(function (item) {
      if (!item.element || seen.indexOf(item.element) !== -1) return false;
      seen.push(item.element);
      return isVisible(item.element);
    });
    matches.sort(function (a, b) { return a.score - b.score; });
    return matches[0] && matches[0].element || null;
  }

  async function safeClick(element) {
    if (!element) return false;
    var actionText = normalizeText(element.textContent || element.getAttribute("aria-label") || element.getAttribute("title"));
    if (FORBIDDEN_ACTION_TEXT.test(actionText)) {
      throw new Error("拒绝点击疑似提交/删除按钮：" + actionText);
    }
    if (AF.DomUtils && AF.DomUtils.isForbiddenAutoClickAction && AF.DomUtils.isForbiddenAutoClickAction(element)) {
      throw new Error("拒绝点击备案/上传等受保护控件：" + actionText);
    }
    if (AF.DomUtils && typeof AF.DomUtils.safeClickElement === "function") {
      var clickedByDomUtils = await AF.DomUtils.safeClickElement(element);
      if (clickedByDomUtils) return true;
    }
    element.scrollIntoView && element.scrollIntoView({ block: "center", inline: "nearest" });
    dispatchMouseEventCompat(element, "mousedown");
    dispatchMouseEventCompat(element, "mouseup");
    dispatchMouseEventCompat(element, "click");
    try { element.click && element.click(); } catch (e) {}
    return true;
  }

  function dispatchMouseEventCompat(element, eventName) {
    if (!element) return false;
    try {
      element.dispatchEvent(new MouseEvent(eventName, { bubbles: true, cancelable: true, composed: true, view: window }));
      return true;
    } catch (e0) {}
    try {
      var legacyEvent = document.createEvent("MouseEvents");
      var rect = element.getBoundingClientRect ? element.getBoundingClientRect() : { left: 0, top: 0, width: 1, height: 1 };
      legacyEvent.initMouseEvent(
        eventName,
        true,
        true,
        window,
        1,
        0,
        0,
        Math.round(rect.left + Math.min(20, Math.max(1, rect.width / 2))),
        Math.round(rect.top + Math.min(20, Math.max(1, rect.height / 2))),
        false,
        false,
        false,
        false,
        0,
        null
      );
      element.dispatchEvent(legacyEvent);
      return true;
    } catch (e1) {}
    try {
      element.dispatchEvent(new Event(eventName, { bubbles: true, cancelable: true, composed: true }));
      return true;
    } catch (e2) {}
    return false;
  }

  async function hoverElementForAction(element, waitMs) {
    if (!element) return false;
    try { element.scrollIntoView && element.scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" }); } catch (e0) {}
    await sleep(60);
    ["pointerover", "mouseover", "mouseenter", "mousemove"].forEach(function (eventName) {
      dispatchMouseEventCompat(element, eventName);
    });
    await sleep(waitMs == null ? 180 : waitMs);
    return true;
  }

  async function clickPinganCampusRepeatAdd(hoverElement, addElement, waitAfterHoverMs) {
    if (!hoverElement || !addElement || !window.chrome || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      return false;
    }
    try {
      var hoverModule = hoverElement.closest && hoverElement.closest(".cv-module");
      var addModule = addElement.closest && addElement.closest(".cv-module");
      if (!hoverModule || hoverModule !== addModule) return false;
    } catch (eModuleGuard) { return false; }
    var marker = Date.now() + "_" + Math.random().toString(16).slice(2);
    var hoverMarker = "hover_" + marker;
    var addMarker = "add_" + marker;
    try {
      hoverElement.setAttribute("data-af-pingan-campus-add-hover", hoverMarker);
      addElement.setAttribute("data-af-pingan-campus-add-button", addMarker);
      var response = await new Promise(function (resolve) {
        chrome.runtime.sendMessage({
          action: "pinganCampusRepeatAdd",
          hoverMarker: hoverMarker,
          addMarker: addMarker,
          waitAfterHoverMs: waitAfterHoverMs == null ? 360 : waitAfterHoverMs,
        }, function (result) {
          resolve(result || { success: false, error: chrome.runtime.lastError && chrome.runtime.lastError.message });
        });
      });
      return !!(response && response.success);
    } catch (e) {
      return false;
    } finally {
      try { hoverElement.removeAttribute("data-af-pingan-campus-add-hover"); } catch (eHoverCleanup) {}
      try { addElement.removeAttribute("data-af-pingan-campus-add-button"); } catch (eAddCleanup) {}
    }
  }

  function findHiddenEditAction(root, selector) {
    if (!root) return null;
    var query = selector || ".edit.right, .edit.edit-btn, .edit-btn, [class*='edit']";
    var nodes = [];
    try { nodes = Array.from(root.querySelectorAll(query)); } catch (e) {}
    var exactEditNodes = nodes.filter(function (node) {
      if (!node || /(^|\s)edit-mode(\s|$)/.test(String(node.className || ""))) return false;
      var text = normalizeText((node.getAttribute && (node.getAttribute("title") || node.getAttribute("aria-label"))) || node.textContent);
      return text === "编辑";
    });
    // 51job 的在校荣誉/语言能力编辑菜单由 Element Popover 临时挂到 body。
    // body 里会同时保留多份 aria-hidden 的旧 popover；若直接取第一个，会
    // 命中隐藏菜单，导致“有数据时找不到编辑”。先取当前 hover 后真正可见
    // 的编辑项；只有平安这类站点确实把编辑按钮隐藏在当前卡片内时，才兜底
    // 返回隐藏节点。
    return exactEditNodes.find(isVisible) || exactEditNodes[0] || null;
  }

  async function openExistingSectionEditor(step) {
    var root = findStepCard(step, document);
    if (!root) return false;
    var hoverTarget = null;
    try {
      hoverTarget = root.querySelector(step.existingEditHoverSelector || ".title-wrapper, .display-mode") || root;
    } catch (e) { hoverTarget = root; }
    await hoverElementForAction(hoverTarget, step.existingEditHoverWaitMs == null ? 260 : step.existingEditHoverWaitMs);
    var edit = await waitUntil(function () {
      return findHiddenEditAction(root, step.existingEditActionSelector);
    }, step.existingEditTimeoutMs || 1600);
    if (!edit) return false;
    if (step.forceNativeEditClick === true) {
      try { edit.scrollIntoView && edit.scrollIntoView({ block: "center", inline: "nearest" }); edit.click(); }
      catch (eNativeEditClick) { await safeClick(edit); }
    } else {
      await safeClick(edit);
    }
    await sleep(step.waitAfterActionMs == null ? 300 : step.waitAfterActionMs);
    return true;
  }

  function queryUniqueRepeatCards(root, selector, editActionSelector) {
    if (!root || !selector) return [];
    // 已保存记录通常每张卡只有一个独立“编辑”入口。优先从编辑图标反向
    // 找最近卡片，比猜 .listStyle / .listStyle2 谁是父谁是子可靠得多。
    if (editActionSelector) {
      try {
        var actionCards = Array.from(root.querySelectorAll(editActionSelector)).map(function (action) {
          var current = action;
          var best = action.parentElement || action;
          while (current && current !== root) {
            var ownCount = current.querySelectorAll(editActionSelector).length;
            if (ownCount === 1) best = current;
            var parent = current.parentElement;
            if (!parent || parent === root) break;
            if (parent.querySelectorAll(editActionSelector).length > 1) break;
            current = parent;
          }
          return best;
        }).filter(Boolean).filter(function (card, index, cards) {
          return cards.indexOf(card) === index;
        });
        if (actionCards.length) return actionCards;
      } catch (eActions) {}
    }
    var matches = [];
    try { matches = Array.from(root.querySelectorAll(selector)); } catch (e) { return []; }
    // 交通银行的 .listStyle 可能是整个列表容器，内部每条记录才是
    // .listStyle2。组合选择器会同时命中父容器和真实卡片；必须保留最内层
    // 记录节点。此前保留最外层会把所有学校合并成“一张卡”，导致流程一直
    // 打开同一个编辑入口，在一张卡里来回覆盖高中、本科、硕士。
    return matches.filter(function (node) {
      return !matches.some(function (candidate) {
        return candidate !== node && node.contains && node.contains(candidate);
      });
    });
  }

  function resolveExistingRepeatCards(step, root) {
    if (!root || !step || !step.existingCardSelector) return [];
    if (step.preferDirectExistingCards === true) {
      var directCards = [];
      try { directCards = Array.from(root.querySelectorAll(step.existingCardSelector)); } catch (e) { return []; }
      directCards = directCards.filter(function (node) {
        return !directCards.some(function (candidate) {
          return candidate !== node && node.contains && node.contains(candidate);
        });
      });
      if (step.requireMeaningfulExistingCard === true) {
        directCards = directCards.filter(function (node) {
          var values = [];
          try {
            values = Array.from(node.querySelectorAll(".preview-template .value, .preview-item .value")).map(function (valueNode) {
              return normalizeText(valueNode.textContent);
            }).filter(function (value) {
              return value && !/^(--+|暂无|未填写)$/.test(value);
            });
          } catch (eValues) {}
          return values.length > 0;
        });
      }
      return directCards;
    }
    return queryUniqueRepeatCards(root, step.existingCardSelector, step.existingEditActionSelector);
  }

  function repeatCardSearchText(card) {
    if (!card) return "";
    var record = card;
    try { record = card.closest(".item") || card; } catch (eRecord) {}
    var parts = [record.textContent || ""];
    try {
      Array.from(record.querySelectorAll("input, textarea, select")).forEach(function (control) {
        if (control.tagName === "SELECT") {
          parts.push(Array.from(control.selectedOptions || []).map(function (option) {
            return option.textContent || option.value || "";
          }).join(" "));
        } else {
          parts.push(control.value || "");
        }
      });
    } catch (eControls) {}
    return normalizeText(parts.join(" "));
  }

  function repeatExpectedValue(step) {
    var row = Array.isArray(step && step.dataOverride) ? step.dataOverride[0] : null;
    var fields = Array.isArray(step && step.repeatVerifyFields) ? step.repeatVerifyFields : [];
    for (var i = 0; i < fields.length; i++) {
      var value = row && row[fields[i]];
      if (hasMeaningfulValue(value)) return String(value).trim();
    }
    return "";
  }

  function repeatCardMatchesExpected(card, expected) {
    var actual = repeatCardSearchText(card);
    var wanted = normalizeText(expected);
    if (!actual || !wanted) return false;
    if (actual.indexOf(wanted) !== -1) return true;
    // 平安展示卡会把较长名称截断为省略号；隐藏编辑表单通常保留完整值，
    // 若页面版本没有保留，则至少用稳定前缀核验，避免三张卡都保存成第一条。
    var prefixLength = Math.min(wanted.length, wanted.length >= 8 ? 8 : wanted.length);
    return prefixLength >= 4 && actual.indexOf(wanted.slice(0, prefixLength)) !== -1;
  }

  async function verifySavedRepeatContent(step) {
    var expected = repeatExpectedValue(step);
    if (!expected) return { success: true, expected: "" };
    var latestCards = [];
    var matchedCard = await waitUntil(function () {
      var root = resolveStrictRepeatAddRoot(step) || findStepCard(step, document);
      // 保存后的内容核验本身已经要求命中当前行的主字段，因此这里必须读取
      // 当前栏目全部 display-mode。不能继续套用“有效旧卡片”过滤器：不同
      // 类目的预览 DOM 不完全相同，工作卡片可能没有教育卡片的 .value 结构，
      // 会把已经保存成功的第一条误判为不存在并跳过本类目剩余经历。
      var verificationStep = Object.assign({}, step, { requireMeaningfulExistingCard: false });
      latestCards = root ? resolveExistingRepeatCards(verificationStep, root) : [];
      return latestCards.find(function (card) {
        return repeatCardMatchesExpected(card, expected);
      }) || null;
    }, step.repeatSavedContentTimeoutMs || 2600);
    return { success: !!matchedCard, expected: expected, cardCount: latestCards.length };
  }

  async function openExistingRepeatEditor(step) {
    if (!step || !Number.isInteger(step.updateExistingIndex) || !step.existingCardSelector) return false;
    var root = findStepCard(step, document) || document;
    if (step.repeatAddRootSelector) {
      try { root = document.querySelector(step.repeatAddRootSelector) || root; } catch (e0) {}
    }
    var cards = [];
    // 已保存卡片的“编辑”入口可能要 hover 才显示，卡片本身也可能处于折叠区。
    // 这里按 DOM 中真实存在的卡片计数，不能先用 isVisible 过滤成 0。
    cards = resolveExistingRepeatCards(step, root);
    var displayCard = cards[step.updateExistingIndex];
    if (!displayCard) return false;
    if (/^job\.spdb\.com\.cn$/i.test(window.location.hostname) && /教育情况/.test(String(step.name || ""))) {
      try {
        var spdbDirectCards = document.querySelectorAll(".fromcontainer.formblocksolid .infoline");
        displayCard = spdbDirectCards[step.updateExistingIndex] || displayCard;
        var spdbEdit = findByText(displayCard, ["编辑"], "span, a, button, [role='button']") || displayCard.querySelector(".toedit");
        if (!spdbEdit) return false;
        spdbEdit.scrollIntoView && spdbEdit.scrollIntoView({ block: "center", inline: "nearest" });
        await safeClick(spdbEdit);
        await sleep(step.waitAfterActionMs == null ? 320 : step.waitAfterActionMs);
        return !!(await waitUntil(function () {
          return Array.from(displayCard.querySelectorAll(step.repeatReadySelector || ".formblock.formedit")).find(function (node) {
            return getComputedStyle(node).display !== "none";
          }) || null;
        }, step.timeoutMs || 3000));
      } catch (eSpdbEducationEdit) { return false; }
    }
    var record = displayCard;
    if (step.existingRecordSelector && displayCard.closest) {
      try { record = displayCard.closest(step.existingRecordSelector) || displayCard; } catch (e2) {}
    } else {
      record = displayCard.parentElement || displayCard;
    }
    var usedDeclaredEditHover = false;
    if (step.existingEditHoverSelector) {
      try {
        var declaredHover = record.querySelector(step.existingEditHoverSelector) || displayCard.querySelector(step.existingEditHoverSelector);
        if (declaredHover) {
          await hoverElementForAction(declaredHover, step.existingEditHoverWaitMs == null ? 300 : step.existingEditHoverWaitMs);
          usedDeclaredEditHover = true;
        }
      } catch (eDeclaredHover) {}
    }
    // 平安最新 DOM：每个 display-mode 内都直接挂着自己的
    // <div class="edit edit-btn">编辑</div>，只是 CSS 默认隐藏。二次覆盖必须
    // 精确点击当前第 N 张卡片内部的 edit-btn；禁止退回全模块搜索，否则可能
    // 编辑第一张旧卡片，也禁止退回点击“添加”造成重复记录。
    var edit = null;
    try {
      edit = step.existingEditActionSelector && displayCard.querySelector(step.existingEditActionSelector) ||
        displayCard.querySelector(":scope > .edit.edit-btn") ||
        displayCard.querySelector(".edit.edit-btn");
    } catch (eDirect) {
      try { edit = displayCard.querySelector(".edit.edit-btn"); } catch (eFallback) {}
    }
    if (!edit) {
      try {
        var localCandidates = Array.from(displayCard.querySelectorAll("a, button, span, div, i"));
        edit = localCandidates.find(function (node) {
          var text = normalizeText(node.textContent || node.getAttribute("title") || node.getAttribute("aria-label"));
          return text === "编辑" || /(^|-)toedit($|-)/i.test(String(node.className || ""));
        }) || null;
      } catch (eLocalEdit) {}
    }
    if (!edit && displayCard.parentElement && displayCard.parentElement !== root) {
      try {
        var siblingCandidates = Array.from(displayCard.parentElement.children || []).filter(function (node) { return node !== displayCard; });
        edit = siblingCandidates.map(function (node) {
          return Array.from(node.querySelectorAll ? node.querySelectorAll("a, button, span, div, i") : []);
        }).reduce(function (all, list) { return all.concat(list); }, []).find(function (node) {
          var text = normalizeText(node.textContent || node.getAttribute("title") || node.getAttribute("aria-label"));
          return text === "编辑" || /(^|-)toedit($|-)/i.test(String(node.className || ""));
        }) || null;
      } catch (eSiblingEdit) {}
    }
    if (!edit) {
      // 前程无忧的荣誉/语言卡片使用 Element Popover：悬停当前条目后，
      // “编辑/删除”菜单会被临时挂到 body，而不是继续留在卡片 DOM 内。
      // 站点显式声明查找根节点时只扩大编辑菜单的搜索范围，悬停对象仍然
      // 严格限定为当前第 N 张卡片，避免误开其它历史记录。
      var editActionRoot = record;
      if (step.existingEditActionRootSelector) {
        try { editActionRoot = document.querySelector(step.existingEditActionRootSelector) || record; } catch (eActionRoot) {}
      }
      if (!usedDeclaredEditHover) {
        await hoverElementForAction(record, step.existingEditHoverWaitMs == null ? 300 : step.existingEditHoverWaitMs);
      }
      edit = await waitUntil(function () {
        return findHiddenEditAction(editActionRoot, step.existingEditActionSelector);
      }, step.existingEditTimeoutMs || 1800);
    } else {
      // 先补齐 hover 事件，兼容组件内部用 hover 状态控制点击区域的页面版本。
      await hoverElementForAction(displayCard, step.existingEditHoverWaitMs == null ? 120 : step.existingEditHoverWaitMs);
    }
    if (!edit) return false;
    await safeClick(edit);
    await sleep(step.waitAfterActionMs == null ? 320 : step.waitAfterActionMs);
    var ready = await waitUntil(function () {
      var currentRoot = findStepCard(step, document) || root;
      try {
        return Array.from(currentRoot.querySelectorAll(
          step.repeatReadySelector || "form.el-form.resume, .edit-mode form, .edit-mode input:not([type='hidden'])"
        )).find(isVisible) || null;
      } catch (e3) { return null; }
    }, step.timeoutMs);
    return !!ready;
  }

  async function clearEditableControlValue(control) {
    if (!control || control.disabled) return false;
    var tag = String(control.tagName || "").toLowerCase();
    if (tag !== "input" && tag !== "textarea") return false;
    var type = String(control.getAttribute("type") || "").toLowerCase();
    if (/^(hidden|file|radio|checkbox|button|submit|reset)$/.test(type)) return false;
    if (control.closest && control.closest(".ant-select, .ant-picker, .el-select, .el-cascader, .el-date-editor")) return false;
    try {
      var proto = tag === "textarea" ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
      var descriptor = Object.getOwnPropertyDescriptor(proto, "value");
      if (descriptor && descriptor.set) descriptor.set.call(control, "");
      else control.value = "";
      control.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: "", inputType: "deleteContentBackward" }));
      control.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      control.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, key: "Backspace", code: "Backspace", keyCode: 8, which: 8 }));
      return true;
    } catch (e) {
      try {
        control.value = "";
        control.dispatchEvent(new Event("input", { bubbles: true }));
        control.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      } catch (e2) {}
    }
    return false;
  }

  async function clearAntChoiceControl(control) {
    if (!control || !control.querySelector) return false;
    if (!isVisible(control) || /ant-select-disabled|ant-picker-disabled/.test(String(control.className || ""))) return false;
    var currentText = normalizeText(control.textContent);
    if (!currentText || /请选择|选择日期|请选择日期/.test(currentText)) return false;
    try { await hoverElementForAction(control, 80); } catch (eHover) {}
    var clear = null;
    try {
      clear = control.querySelector(
        ".ant-select-clear, .ant-picker-clear, .ant-select-selection__clear, .anticon-close-circle, .anticon-close"
      );
    } catch (e) {}
    if (clear) {
      await safeClick(clear);
      await sleep(100);
      return true;
    }
    // 有些旧版 AntD 只有输入节点，没有 clear 图标。用用户式的
    // Ctrl/Cmd+A + Backspace 触发受控组件；若它是不可清空的必选下拉，
    // 后续选择器仍会用新值强制覆盖。
    var input = null;
    try { input = Array.from(control.querySelectorAll("input:not([type='hidden'])")).find(function (node) { return !node.disabled; }); } catch (e2) {}
    if (input) {
      try {
        input.focus && input.focus();
        input.dispatchEvent(new KeyboardEvent("keydown", { key: "a", code: "KeyA", metaKey: true, ctrlKey: true, bubbles: true }));
        input.dispatchEvent(new KeyboardEvent("keydown", { key: "Backspace", code: "Backspace", bubbles: true }));
        var descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
        if (descriptor && descriptor.set) descriptor.set.call(input, "");
        else input.value = "";
        input.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: "", inputType: "deleteContentBackward" }));
        input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
        await sleep(80);
        return true;
      } catch (eInputClear) {}
    }
    return false;
  }

  async function clearExistingEditorBeforeFill(step, readyElement) {
    if (!step || !step.clearBeforeFillExisting) return;
    var root = null;
    try {
      root = readyElement || resolveReadyElement(step) || findStepCard(step, document);
    } catch (e) {}
    if (!root) return;
    if (step.activeRepeatEditorSelector) {
      try {
        var activeOwner = root.closest && root.closest(step.activeRepeatEditorSelector);
        if (!activeOwner) {
          activeOwner = Array.from(document.querySelectorAll(step.activeRepeatEditorSelector)).filter(isVisible).pop() || null;
        }
        if (activeOwner) root = activeOwner;
      } catch (eActiveOwner) {}
    }
    // cardAsScope 返回的可能是整个 #education / #work 栏目。清空必须严格
    // 限定到当前唯一可见编辑表单，不能误清其它已经保存的卡片或相邻模块。
    try {
      var currentForm = Array.from(root.querySelectorAll(
        step.repeatReadySelector || "form.ant-form, form.el-form, .resumeForm form"
      )).find(isVisible);
      if (currentForm && !/^(INPUT|TEXTAREA|SELECT)$/.test(String(currentForm.tagName || ""))) root = currentForm;
    } catch (eCurrentForm) {}
    var cleared = 0;
    try {
      var choiceControls = Array.from(root.querySelectorAll(
        ".ant-select:not(.ant-select-disabled), .ant-picker:not(.ant-picker-disabled)"
      )).filter(isVisible);
      for (var i = 0; i < choiceControls.length; i++) {
        if (await clearAntChoiceControl(choiceControls[i])) cleared += 1;
      }
    } catch (eChoice) {}
    try {
      var textControls = Array.from(root.querySelectorAll(
        "textarea:not([disabled]), input:not([disabled]):not([type='hidden']):not([type='file']):not([type='radio']):not([type='checkbox'])"
      )).filter(isVisible);
      for (var j = 0; j < textControls.length; j++) {
        if (await clearEditableControlValue(textControls[j])) cleared += 1;
      }
    } catch (eText) {}
    // 工作经历旧卡可能勾选“至今”，此时结束日期被禁用。清空阶段先取消
    // 已勾选的“至今”，再按当前简历决定填具体结束日期或重新勾选至今。
    try {
      var checkedBoxes = Array.from(root.querySelectorAll("input[type='checkbox']:checked")).filter(isVisible);
      for (var k = 0; k < checkedBoxes.length; k++) {
        var checkbox = checkedBoxes[k];
        var checkboxOwner = checkbox.closest && checkbox.closest("label, .ant-checkbox-wrapper, [role='checkbox']") || checkbox;
        if (/至今|目前|现在/.test(normalizeText(checkboxOwner.textContent))) {
          await safeClick(checkboxOwner);
          await sleep(80);
          cleared += 1;
        }
      }
    } catch (eCheckbox) {}
    if (cleared) await sleep(step.waitAfterClearMs == null ? 220 : step.waitAfterClearMs);
  }

  function findActionBySelectors(step, root) {
    var selectors = [];
    if (Array.isArray(step.afterClickActionSelectors)) selectors = selectors.concat(step.afterClickActionSelectors);
    if (step.afterClickActionSelector) selectors.push(step.afterClickActionSelector);
    for (var i = 0; i < selectors.length; i++) {
      var selector = selectors[i];
      if (!selector) continue;
      try {
        var scoped = Array.from(root.querySelectorAll(selector));
        var visibleScoped = scoped.filter(isVisible);
        if (visibleScoped[0]) return visibleScoped[0];
        if (step.afterClickActionAllowHidden && scoped[0]) return scoped[0];
        var globalMatches = Array.from(document.querySelectorAll(selector));
        var visibleGlobal = globalMatches.filter(isVisible);
        if (visibleGlobal[0]) return visibleGlobal[0];
        if (step.afterClickActionAllowHidden && globalMatches[0]) return globalMatches[0];
      } catch (e) {}
    }
    return null;
  }

  async function clickActionAfterTrigger(step, trigger) {
    if (!step || (!step.afterClickActionText && !step.afterClickActionSelector && !step.afterClickActionSelectors)) return false;
    var root = null;
    try {
      if (step.afterClickActionRootSelector) root = document.querySelector(step.afterClickActionRootSelector);
    } catch (e0) {}
    if (!root && (step.sectionByTitle || step.cardTitle)) {
      root = findStepCard(step, document);
    }
    if (!root && step.scopeSelector) {
      try { root = document.querySelector(step.scopeSelector); } catch (e1) {}
    }
    // 平安等侧边导航站点的 trigger 位于右侧目录，新增按钮却在正文模块。
    // 优先使用当前步骤的明确栏目根节点，不能在导航栏里寻找“添加”。
    if (!root && step.cardAsScope) {
      root = findStepCard(step, document);
    }
    if (!root && trigger && trigger.closest) {
      root = trigger.closest(".mb22, .module, .ant-card, .el-card, .resume-section, .resume-module, .form-section, .comp");
    }
    root = root || document;
    if (step.hoverBeforeAction) {
      var hoverTarget = root;
      if (step.hoverBeforeActionSelector) {
        try { hoverTarget = root.querySelector(step.hoverBeforeActionSelector) || document.querySelector(step.hoverBeforeActionSelector) || hoverTarget; } catch (e3) {}
      }
      await hoverElementForAction(hoverTarget, step.hoverBeforeActionWaitMs);
    }
    var action = await waitUntil(function () {
      if (step.hoverBeforeAction) {
        try { ["pointerover", "mouseover", "mouseenter", "mousemove"].forEach(function (eventName) { dispatchMouseEventCompat(root, eventName); }); } catch (e4) {}
      }
      var selected = findActionBySelectors(step, root);
      if (selected) return selected;
      return findByText(
        root,
        step.afterClickActionText,
        step.afterClickActionCandidateSelector || "button, a, [role='button'], div, span"
      );
    }, step.afterClickActionTimeoutMs || 1800);
    if (!action) return false;
    var actionClicked = false;
    if (step.afterClickActionUsePinganCampusBridge === true) {
      var campusActionHover = root;
      if (step.afterClickActionHoverSelector) {
        try { campusActionHover = root.querySelector(step.afterClickActionHoverSelector) || campusActionHover; } catch (eCampusActionHover) {}
      }
      actionClicked = await clickPinganCampusRepeatAdd(campusActionHover, action, step.afterClickActionHoverWaitMs);
    }
    if (!actionClicked && step.afterClickActionNativeClick === true && typeof action.click === "function") {
      // 平安校招的“添加”节点由 v-show/CSS 隐藏，但 Vue click 处理器仍挂在
      // 节点自身。直接调用原生 click 激活该处理器，之后继续沿用统一的表单
      // 就绪等待；不修改任何字段填写逻辑。
      action.click();
      actionClicked = true;
    } else {
      if (!actionClicked) await safeClick(action);
    }
    await sleep(step.waitAfterActionMs == null ? 250 : step.waitAfterActionMs);
    return true;
  }

  async function waitUntil(check, timeoutMs) {
    var startedAt = Date.now();
    var timeout = timeoutMs || DEFAULT_TIMEOUT_MS;
    while (Date.now() - startedAt < timeout) {
      var result = null;
      try { result = check(); } catch (e) {}
      if (result) return result;
      await sleep(100);
    }
    return null;
  }

  function queryVisibleIncludingRoot(root, selector) {
    var nodes = [];
    if (!selector) return nodes;
    try {
      if (root && root.matches && root.matches(selector)) nodes.push(root);
    } catch (e0) {}
    try {
      nodes = nodes.concat(Array.from((root || document).querySelectorAll(selector)));
    } catch (e1) {}
    return nodes.filter(function (node, index, array) {
      return node && array.indexOf(node) === index && isVisible(node);
    });
  }

  function elementStackScore(element) {
    var zIndex = 0;
    try {
      var node = element;
      while (node && node !== document) {
        var parsed = parseInt(window.getComputedStyle(node).zIndex, 10);
        if (!isNaN(parsed)) zIndex = Math.max(zIndex, parsed);
        node = node.parentElement;
      }
    } catch (e) {}
    var order = 0;
    try {
      order = Array.prototype.indexOf.call(document.querySelectorAll("body *"), element);
    } catch (e2) {}
    return zIndex * 100000 + order;
  }

  function pickBestVisibleCandidate(candidates, step) {
    var visible = (candidates || []).filter(isVisible);
    var readyText = normalizeText(step && step.readyText);
    if (readyText) {
      var titled = visible.filter(function (node) {
        return normalizeText(node.textContent || node.getAttribute && node.getAttribute("aria-label") || "").indexOf(readyText) !== -1;
      });
      if (titled.length) visible = titled;
    }
    visible.sort(function (a, b) { return elementStackScore(b) - elementStackScore(a); });
    return visible[0] || null;
  }

  function normalizeHigherEducationLabel(value) {
    return normalizeText(value).replace(/必填/g, "").replace(/[＊*：:]/g, "").trim();
  }

  function higherEducationLabelNodes(root) {
    var wanted = ["学校名称", "毕业院校", "院校名称", "学校", "办学属地", "学历", "学历层次", "研究方向", "院系", "专业", "专业名称", "专业课程", "学科属性", "学位", "学位名称", "学习形式", "是否本硕连读", "培养方式", "个人绩点", "年级排名", "入学时间", "开始时间", "起始时间", "毕业时间", "结束时间", "终止时间"];
    var nodes = [];
    try {
      nodes = Array.from((root || document).querySelectorAll("label, .el-form-item__label, [class*='label'], [class*='title'], span, div")).filter(isVisible);
    } catch (e) {}
    return nodes.filter(function (node) {
      var text = normalizeHigherEducationLabel(node.textContent);
      return wanted.indexOf(text) !== -1;
    });
  }

  function isActuallyVisible(element) {
    if (!element || element.isConnected === false) return false;
    var rect = null;
    try { rect = element.getBoundingClientRect(); } catch (eRect) {}
    if (!rect || rect.width <= 0 || rect.height <= 0) return false;
    var node = element;
    while (node && node !== document) {
      try {
        if (node.getAttribute && node.getAttribute("aria-hidden") === "true") return false;
        var style = window.getComputedStyle ? window.getComputedStyle(node) : null;
        if (style && (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse")) return false;
      } catch (eStyle) {}
      node = node.parentElement;
    }
    return true;
  }

  function allHigherEducationLabelNodes(root, labelText) {
    var wanted = normalizeHigherEducationLabel(labelText);
    var nodes = [];
    try { nodes = Array.from((root || document).querySelectorAll("label, .el-form-item__label, [class*='label'], [class*='title'], span, div")); } catch (e) {}
    return nodes.filter(function (node) { return normalizeHigherEducationLabel(node.textContent) === wanted; });
  }

  function enumerateInteractiveControls(root) {
    if (!root) return [];
    var nodes = [];
    var selector = "input, textarea, select, [contenteditable='true'], [role='combobox'], .el-input, .el-input__wrapper, .el-input__inner, .el-select, .el-select__wrapper, .el-cascader, .el-date-editor";
    try {
      nodes = Array.from(root.querySelectorAll(selector));
      Array.from(root.querySelectorAll("*")).forEach(function (host) {
        if (!host.shadowRoot) return;
        try { nodes = nodes.concat(Array.from(host.shadowRoot.querySelectorAll(selector))); } catch (eShadow) {}
      });
    } catch (e) {}
    var seen = [];
    return nodes.filter(function (node) {
      if (seen.indexOf(node) !== -1) return false;
      seen.push(node);
      return true;
    }).map(function (node) {
      var className = String(node.className || "");
      var role = String(node.getAttribute && node.getAttribute("role") || "");
      var inputType = String(node.type || node.getAttribute && node.getAttribute("type") || "").toLowerCase();
      var detectedType = /el-date-editor/.test(className) || inputType === "date" ? "date"
        : /el-select|el-cascader/.test(className) || role === "combobox" || node.tagName === "SELECT" ? "select"
        : node.isContentEditable ? "contentEditable"
        : node.tagName === "TEXTAREA" ? "textarea"
        : /autocomplete|search/.test([className, role, inputType].join(" ")) ? "search" : "text";
      return { element: node, kind: detectedType === "date" ? "date" : (detectedType === "select" ? "choice" : "text"), detectedType: detectedType, visible: isActuallyVisible(node) };
    });
  }

  function normalizeHigherEducationControlHint(value) {
    return String(value == null ? "" : value)
      .replace(/[\s*：:（）()【】\[\]，,。；;·•・_\/\-]+/g, "")
      .toLowerCase();
  }

  function higherEducationExpectedControlType(item) {
    var type = String(item && item.type || "");
    if (/date/i.test(type) || item && /(?:startTime|endTime)$/i.test(String(item.field || ""))) return "date";
    if (/select|choice|cascader/i.test(type)) return "select";
    return "text";
  }

  function higherEducationCanonicalControl(element, expectedType, scope) {
    if (!element || !isActuallyVisible(element)) return null;
    var node = element;
    try {
      if (expectedType === "select") {
        var selectRoot = node.closest && node.closest(".el-select:not(.is-disabled), .el-cascader:not(.is-disabled), [role='combobox']");
        if (selectRoot && (!scope || scope.contains(selectRoot))) return selectRoot;
        if (node.matches && node.matches("select, [role='combobox']")) return node;
        return null;
      }
      if (expectedType === "date") {
        var dateRoot = node.closest && node.closest(".el-date-editor:not(.is-disabled), .el-range-editor:not(.is-disabled)");
        if (dateRoot && (!scope || scope.contains(dateRoot))) return dateRoot;
        if (node.matches && node.matches("input[type='date'], input[type='month']")) return node;
        var dateHint = normalizeHigherEducationControlHint([
          node.getAttribute && node.getAttribute("placeholder"),
          node.getAttribute && node.getAttribute("aria-label"),
          node.getAttribute && node.getAttribute("name")
        ].filter(Boolean).join(" "));
        if (node.matches && node.matches("input") && /(入学|毕业|开始|结束|时间|日期)/.test(dateHint)) return node;
        return null;
      }
      var input = node.matches && node.matches("input, textarea") ? node : null;
      if (!input && node.querySelector) {
        input = Array.from(node.querySelectorAll("input, textarea")).find(function (candidate) {
          return isActuallyVisible(candidate) && !candidate.disabled && !candidate.readOnly &&
            !(candidate.closest && candidate.closest(".el-select, .el-cascader, .el-date-editor"));
        }) || null;
      }
      if (!input || input.disabled || input.readOnly) return null;
      if (input.closest && input.closest(".el-select, .el-cascader, .el-date-editor")) return null;
      return input;
    } catch (e) {
      return null;
    }
  }

  function higherEducationControlHint(element) {
    if (!element) return "";
    var parts = [];
    function pushNode(node) {
      if (!node || !node.getAttribute) return;
      ["placeholder", "aria-label", "name", "title", "data-placeholder"].forEach(function (attr) {
        var value = node.getAttribute(attr);
        if (value) parts.push(value);
      });
    }
    pushNode(element);
    try {
      var inner = element.querySelectorAll ? Array.from(element.querySelectorAll("input, textarea, [role='combobox']")) : [];
      inner.slice(0, 4).forEach(pushNode);
    } catch (e) {}
    return normalizeHigherEducationControlHint(parts.join(" "));
  }

  function higherEducationFieldKeywords(item) {
    var field = String(item && item.field || "");
    var label = item && item.label;
    var labels = Array.isArray(label) ? label : [label];
    var result = labels.filter(Boolean).map(normalizeHigherEducationControlHint);
    var extra = {
      school: ["学校", "院校", "学校全称"],
      zhaopinHigherSchoolLocation: ["办学属地", "院校属性"],
      zhaopinHigherHasOverseasStudy: ["国外港澳台", "境外学习经历", "海外学习"],
      zhaopinHigherLevel: ["学历"],
      zhaopinHigherDiscipline: ["学科属性", "学科"],
      zhaopinHigherDegree: ["学位"],
      zhaopinHigherTrainingMode: ["培养方式", "培养"],
      zhaopinHigherResearchDirection: ["研究方向"],
      zhaopinHigherDepartment: ["院系", "学院"],
      zhaopinHigherMajor: ["专业名称", "专业"],
      zhaopinHigherCourses: ["专业课程", "主修课程", "课程"],
      zhaopinHigherStudyMode: ["学习形式"],
      zhaopinHigherStudyLength: ["学制", "学习年限", "修业年限", "培养年限"],
      zhaopinHigherIntegratedTraining: ["贯通式培养", "贯通培养", "本硕连读"],
      zhaopinHigherGpa: ["个人绩点", "绩点", "3.5"],
      zhaopinHigherRank: ["年级排名"],
      zhaopinHigherClassRank: ["班级排名", "班级成绩排名"],
      startTime: ["入学时间", "入学"],
      endTime: ["毕业时间", "毕业"]
    }[field] || [];
    extra.forEach(function (value) { result.push(normalizeHigherEducationControlHint(value)); });
    return Array.from(new Set(result.filter(Boolean)));
  }

  // Higher Education in the Zhaopin campus template keeps the field label and the
  // interactive Element-UI control visually paired, but some enterprise skins do
  // not keep the control as a descendant of the label's .el-form-item.  The generic
  // matcher therefore sees the label but returns no control.  This resolver stays
  // strictly inside the freshly opened education editor, reuses the shared
  // interactive-control enumerator, and chooses the closest type-compatible control.
  // It is intentionally thin: it only binds label -> control; filling remains in
  // FormHandler / SelectAdapter / DatePicker.
  function resolveLiveHigherEducationFormScope(fallbackScope) {
    var section = resolveHigherEducationSectionScope(null);
    var roots = [];
    function addRoot(node) {
      if (!node || roots.indexOf(node) !== -1 || !isActuallyVisible(node)) return;
      roots.push(node);
    }
    if (fallbackScope && fallbackScope.isConnected !== false) addRoot(fallbackScope);
    if (section) {
      [
        ".apply-module__form form.scrd-web--form-edit",
        "form.scrd-web--form-edit",
        ".scrd-web--form-edit",
        ".apply-form--edit",
        "form.el-form",
        ".el-form"
      ].forEach(function (selector) {
        try { Array.from(section.querySelectorAll(selector)).forEach(addRoot); } catch (eSelector) {}
      });
    }
    var scored = roots.map(function (root) {
      var controls = enumerateInteractiveControls(root).filter(function (entry) { return entry.visible; });
      var labels = higherEducationLabelNodes(root);
      var className = String(root.className || "");
      var bonus = /scrd-web--form-edit|apply-form--edit/.test(className) ? 1500 : (/el-form/.test(className) ? 500 : 0);
      var depth = 0;
      for (var node = root; node && section && node !== section; node = node.parentElement) depth += 1;
      return { root: root, controls: controls.length, labels: labels.length, score: controls.length * 120 + labels.length * 25 + bonus + depth };
    }).filter(function (entry) { return entry.controls >= 3; });
    scored.sort(function (a, b) { return b.score - a.score; });
    return scored.length ? scored[0].root : (fallbackScope && fallbackScope.isConnected !== false ? fallbackScope : null);
  }

  function higherEducationItemLabelAliases(item) {
    var labels = item && item.label;
    labels = Array.isArray(labels) ? labels : [labels];
    return labels.filter(Boolean).map(normalizeHigherEducationLabel);
  }

  function findLiveHigherEducationLabel(scope, item, fallbackLabel) {
    if (!scope) return fallbackLabel || null;
    var aliases = higherEducationItemLabelAliases(item);
    var nodes = [];
    try { nodes = Array.from(scope.querySelectorAll("label, .el-form-item__label, .form-item__label")); } catch (e) {}
    var matches = nodes.filter(function (node) {
      return isActuallyVisible(node) && aliases.indexOf(normalizeHigherEducationLabel(node.textContent)) !== -1;
    });
    if (!matches.length) return fallbackLabel && scope.contains && scope.contains(fallbackLabel) ? fallbackLabel : null;
    // Prefer a label whose own form item already exposes a compatible interactive control.
    var expectedType = higherEducationExpectedControlType(item);
    for (var i = 0; i < matches.length; i += 1) {
      var fieldItem = matches[i].closest && matches[i].closest(".el-form-item, .form-item, .form-group, [role='group']");
      if (!fieldItem) continue;
      var direct = resolveHigherEducationDirectFieldControl(fieldItem, expectedType);
      if (direct) return matches[i];
    }
    return matches[0];
  }

  function resolveHigherEducationDirectFieldControl(fieldItem, expectedType) {
    if (!fieldItem) return null;
    try {
      if (expectedType === "select") {
        var select = Array.from(fieldItem.querySelectorAll(".el-select:not(.is-disabled), .el-cascader:not(.is-disabled), select:not([disabled]), [role='combobox']")).find(isActuallyVisible);
        if (select) return { element: select, type: "select", source: "live_form_item" };
      } else if (expectedType === "date") {
        var date = Array.from(fieldItem.querySelectorAll(".el-date-editor:not(.is-disabled), .el-range-editor:not(.is-disabled), input[type='date'], input[type='month']")).find(isActuallyVisible);
        if (date) return { element: date, type: "date", source: "live_form_item" };
        var dateInput = Array.from(fieldItem.querySelectorAll("input:not([disabled])")).find(function (node) {
          if (!isActuallyVisible(node)) return false;
          var hint = normalizeHigherEducationControlHint([node.getAttribute("placeholder"), node.getAttribute("aria-label"), node.getAttribute("name")].filter(Boolean).join(" "));
          return /(入学|毕业|开始|结束|时间|日期)/.test(hint);
        });
        if (dateInput) return { element: dateInput, type: "date", source: "live_form_item_hint" };
      } else {
        var autocomplete = Array.from(fieldItem.querySelectorAll(".el-autocomplete input:not([disabled]):not([readonly]), input[aria-autocomplete='list']:not([disabled]):not([readonly])")).find(isActuallyVisible);
        if (autocomplete) return { element: autocomplete, type: "autocomplete", source: "live_form_item" };
        var input = Array.from(fieldItem.querySelectorAll("textarea:not([disabled]):not([readonly]), input:not([type='hidden']):not([type='file']):not([type='radio']):not([type='checkbox']):not([disabled]):not([readonly])")).find(function (node) {
          return isActuallyVisible(node) && !(node.closest && node.closest(".el-select, .el-cascader, .el-date-editor, .el-range-editor"));
        });
        if (input) return { element: input, type: input.tagName === "TEXTAREA" ? "textarea" : "text", source: "live_form_item" };
      }
    } catch (e) {}
    return null;
  }

  function resolveHigherEducationNavigationControl(scope, label, item) {
    scope = resolveLiveHigherEducationFormScope(scope) || scope;
    if (!scope) return null;
    label = findLiveHigherEducationLabel(scope, item, label);
    var expectedType = higherEducationExpectedControlType(item);
    var directFieldItem = label && label.closest && label.closest(".el-form-item, .form-item, .form-group, [role='group']");
    var directControl = resolveHigherEducationDirectFieldControl(directFieldItem, expectedType);
    if (directControl) return directControl;
    var entries = enumerateInteractiveControls(scope).filter(function (entry) {
      return entry.visible && entry.element && (!entry.element.disabled || expectedType !== "text");
    });
    var fieldItem = label && label.closest && label.closest(".el-form-item, .form-item, .form-group, [role='group']");
    var keywords = higherEducationFieldKeywords(item);
    var labelRect = null;
    try { labelRect = label && label.getBoundingClientRect ? label.getBoundingClientRect() : null; } catch (eLabelRect) {}
    var seen = [];
    var candidates = [];

    entries.forEach(function (entry) {
      var control = higherEducationCanonicalControl(entry.element, expectedType, scope);
      if (!control || seen.indexOf(control) !== -1 || !isActuallyVisible(control)) return;
      seen.push(control);
      var score = 0;
      var source = "editor_geometry";
      if (fieldItem && fieldItem.contains && fieldItem.contains(control)) {
        score += 5000;
        source = "field_item";
      }
      var hint = higherEducationControlHint(control);
      if (hint && keywords.some(function (keyword) { return keyword && (hint.indexOf(keyword) !== -1 || keyword.indexOf(hint) !== -1); })) {
        score += 3500;
        source = source === "field_item" ? "field_item_hint" : "placeholder_hint";
      }
      try {
        var rect = control.getBoundingClientRect();
        if (labelRect && rect && rect.width > 0 && rect.height > 0) {
          var below = rect.top - labelRect.bottom;
          var dx = Math.abs(rect.left - labelRect.left);
          var centerDy = Math.abs((rect.top + rect.height / 2) - (labelRect.top + labelRect.height / 2));
          if (below >= -20 && below <= 150 && dx <= 180) score += 1800 - Math.min(1200, Math.abs(below) * 5 + dx * 2);
          else if (centerDy <= 90 && dx <= 420) score += 700 - Math.min(600, centerDy * 3 + dx);
        }
      } catch (eRect) {}
      // Prefer wrapper controls for select/date and leaf inputs for text.
      if (expectedType === "select" && control.matches && control.matches(".el-select, .el-cascader, [role='combobox'], select")) score += 300;
      if (expectedType === "date" && control.matches && control.matches(".el-date-editor, .el-range-editor, input[type='date'], input[type='month']")) score += 300;
      if (expectedType === "text" && control.matches && control.matches("input, textarea")) score += 300;
      candidates.push({ element: control, type: expectedType === "select" ? "select" : expectedType === "date" ? "date" : "text", score: score, source: source });
    });

    candidates.sort(function (a, b) { return b.score - a.score; });
    if (!candidates.length) return null;
    // A zero/near-zero score means the only candidates are unrelated controls in
    // the same editor.  Do not guess across fields.
    if (candidates[0].score < 250) return null;
    return candidates[0];
  }

  function resolveHigherEducationEditorScope(step) {
    var card = findStepCard(step, document);
    var searchRoot = card || document;
    var keyLabels = ["学校名称", "学历", "学位"];
    var secondaryLabels = ["专业", "学科属性", "入学时间", "毕业时间", "办学属地"];
    var candidates = [];
    try {
      candidates = queryVisibleIncludingRoot(searchRoot, step.scopeSelector || ".apply-module__form").filter(isVisible);
    } catch (eSelector) {}
    var labels = higherEducationLabelNodes(searchRoot);
    function valid(scope) {
      if (!scope || scope === document || !isVisible(scope)) return false;
      var texts = higherEducationLabelNodes(scope).map(function (node) { return normalizeHigherEducationLabel(node.textContent); });
      var hasKeys = keyLabels.every(function (label) { return texts.indexOf(label) !== -1; });
      var hasSecondary = secondaryLabels.some(function (label) { return texts.indexOf(label) !== -1; });
      var controls = [];
      try { controls = Array.from(scope.querySelectorAll("input:not([type='hidden']):not([type='file']), textarea, select, .el-select, .el-date-editor, [role='combobox']")).filter(isVisible); } catch (eControls) {}
      return hasKeys && hasSecondary && controls.length >= 3;
    }
    var explicit = candidates.find(valid);
    if (explicit) {
      var explicitLabelCount = higherEducationLabelNodes(explicit).length;
      var explicitControls = higherEducationInteractiveControls(explicit);
      var editorCandidates = [];
      try { editorCandidates = Array.from(explicit.querySelectorAll("form, .scrd-web--form-edit, .apply-form--edit, .el-form, [class*='form-edit']")).filter(function (node) { return isActuallyVisible(node) && valid(node); }); } catch (eEditorCandidates) {}
      editorCandidates.sort(function (a, b) {
        var aLabels = higherEducationLabelNodes(a).length, bLabels = higherEducationLabelNodes(b).length;
        if (aLabels !== bLabels) return aLabels - bLabels;
        return higherEducationInteractiveControls(b).length - higherEducationInteractiveControls(a).length;
      });
      var selectedEditor = explicitLabelCount > 30 && editorCandidates.length ? editorCandidates[0] : explicit;
      writeHigherEducationTrace({ scopeSanityTrace: { configuredScopeLabelCount: explicitLabelCount, configuredScopeEditableControlCount: explicitControls.length, likelyTooBroad: explicitLabelCount > 30, candidateEditorCount: editorCandidates.length, selectedEditorStrategy: selectedEditor === explicit ? "configured_scope" : "smallest_active_editor" } });
      return { scope: selectedEditor, strategy: selectedEditor === explicit ? "configured_selector" : "configured_nested_active_editor" };
    }
    var anchors = labels.filter(function (node) { return keyLabels.indexOf(normalizeHigherEducationLabel(node.textContent)) !== -1; });
    if (anchors.length < keyLabels.length) return { scope: null, strategy: "", reason: "key_labels_not_found" };
    var node = anchors[0];
    for (var depth = 0; node && node !== document.body && depth < 10; depth += 1, node = node.parentElement) {
      if (anchors.every(function (anchor) { return node.contains(anchor); }) && valid(node)) {
        return { scope: node, strategy: "semantic_common_ancestor" };
      }
    }
    return { scope: null, strategy: "", reason: "higher_education_scope_not_resolved" };
  }

  function resolveHigherEducationSectionScope(step) {
    return findResumeSectionRootByTitle("高等教育经历") || findStepCard(step, document) || null;
  }

  function findResumeSectionRootByTitle(titleText) {
    var wanted = normalizeHigherEducationLabel(titleText);
    var headings = [];
    try {
      headings = Array.from(document.querySelectorAll(".form-content--title, [class*='section-title'], [class*='module-title'], h1, h2, h3, h4, h5, h6"));
    } catch (eHeadings) {}
    var candidates = headings.filter(function (heading) {
      return isActuallyVisible(heading) && normalizeHigherEducationLabel(heading.textContent) === wanted;
    }).map(function (heading) {
      var section = heading.closest && heading.closest(".apply-module, section, [class*='section'], [class*='module']");
      return section && isActuallyVisible(section) ? { heading: heading, section: section } : null;
    }).filter(Boolean);
    candidates.sort(function (a, b) {
      var ar = a.heading.getBoundingClientRect(), br = b.heading.getBoundingClientRect();
      return Math.abs(ar.top - 100) - Math.abs(br.top - 100);
    });
    return candidates.length ? candidates[0].section : null;
  }

  function higherEducationInteractiveControls(section) {
    return enumerateInteractiveControls(section).filter(function (entry) {
      var node = entry.element;
      if (!entry.visible) return false;
      if (node.disabled || String(node.type || "").toLowerCase() === "hidden") return false;
      if (node.matches && node.matches("input, textarea") && node.readOnly && !(node.closest && node.closest(".el-date-editor"))) return false;
      return true;
    }).map(function (entry) { return entry.element; });
  }

  // Stable Higher Education mode only accepts a user-opened editor containing
  // real interactive controls. Read-only display cards (for example
  // .apply-form-read-only / .labelOnly-text) are never considered editors.
  function classifyHigherEducationEditableRoot(section) {
    if (!section) return { root: null, editableControlCount: 0, state: "not_found", reason: "higher_education_section_not_resolved" };
    var candidates = [section];
    try {
      candidates = candidates.concat(Array.from(section.querySelectorAll("form, [role='form'], .el-form")));
    } catch (eCandidates) {}
    candidates = candidates.filter(function (candidate, index, all) {
      return candidate && all.indexOf(candidate) === index && isActuallyVisible(candidate);
    }).map(function (candidate) {
      var controls = higherEducationInteractiveControls(candidate);
      return { root: candidate, controls: controls };
    }).filter(function (candidate) { return candidate.controls.length > 0; });
    candidates.sort(function (a, b) {
      if (a.controls.length !== b.controls.length) return a.controls.length - b.controls.length;
      var aDepth = 0, bDepth = 0, node;
      for (node = a.root; node && node !== section; node = node.parentElement) aDepth += 1;
      for (node = b.root; node && node !== section; node = node.parentElement) bDepth += 1;
      return bDepth - aDepth;
    });
    if (!candidates.length) {
      var hasReadOnly = false;
      try { hasReadOnly = !!section.querySelector(".apply-form-read-only, .labelOnly-text"); } catch (eReadOnly) {}
      return { root: null, editableControlCount: 0, state: hasReadOnly ? "read_only_records" : "not_found", reason: "higher_education_editor_not_open" };
    }
    return { root: candidates[0].root, editableControlCount: candidates[0].controls.length, state: "editable", reason: "" };
  }

  function resolveHigherEducationEditableRoot(step) {
    return classifyHigherEducationEditableRoot(resolveHigherEducationSectionScope(step));
  }

  function findHigherEducationAddButton(section) {
    if (!section) return null;
    // 智联公共模板的“添加”在不同企业皮肤中可能是 button，也可能是
    // form-content--title-box 内的 icon-box。先复用站点现有的稳定结构，
    // 再退回同一 section 内的文本搜索；绝不跨模块查找。
    var preferred = findAddButtonByText(
      section,
      ["添加", "新增", "+ 添加"],
      ".form-content--title-box .icon-box, .form-content--title-box [class*='add'], .no-data .add-now, button, a, [role='button']"
    );
    return preferred || findAddButtonByText(section, ["添加", "新增", "+ 添加"]);
  }

  function normalizeEducationIdentityText(value) {
    return normalizeText(value).replace(/[\s·•・，,。；;：:（）()【】\[\]{}\-_/]+/g, "").toLowerCase();
  }

  function educationIdentityTextMatches(a, b) {
    a = normalizeEducationIdentityText(a);
    b = normalizeEducationIdentityText(b);
    if (!a || !b) return false;
    return a === b || a.indexOf(b) !== -1 || b.indexOf(a) !== -1;
  }

  function higherEducationDisplayLabelPattern(labelText) {
    var plain = String(labelText == null ? "" : labelText)
      .replace(/必填/g, "")
      .replace(/[＊*：:]/g, "")
      .replace(/\s+/g, "")
      .trim();
    if (!plain) return null;
    var chars = Array.from(plain).map(function (ch) { return ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); });
    // Rendered read-only cards often use typography such as "学 位：经济学硕士".
    // Require a real separator (colon or whitespace) after the label so "学位"
    // never steals values from a different field such as "学位类型".
    return new RegExp("^\\s*" + chars.join("\\s*") + "(?:\\s*[：:]\\s*|\\s+)(.*?)\\s*$");
  }

  function parseHigherEducationDisplayText(renderedText, labelText) {
    var target = normalizeHigherEducationLabel(labelText);
    if (!target) return "";
    var pattern = higherEducationDisplayLabelPattern(labelText);
    var chunks = String(renderedText == null ? "" : renderedText)
      .replace(/\u00a0/g, " ")
      .split(/[\r\n\t]+/)
      .map(function (part) { return String(part || "").trim(); })
      .filter(Boolean);
    function cleanedRaw(value) {
      var raw = String(value == null ? "" : value).trim();
      var normalized = normalizeText(raw);
      if (!normalized || normalized === "--" || normalized === "-" || normalized === target) return "";
      return raw;
    }
    for (var i = 0; i < chunks.length; i += 1) {
      var chunk = chunks[i];
      var match = pattern && pattern.exec(chunk);
      if (match) {
        var inlineValue = cleanedRaw(match[1]);
        if (inlineValue) return inlineValue;
      }
      if (normalizeHigherEducationLabel(chunk) === target) {
        for (var j = i + 1; j < Math.min(chunks.length, i + 3); j += 1) {
          var next = cleanedRaw(chunks[j]);
          if (!next) continue;
          // Do not consume the next field label as the current value.
          var nextNormalized = normalizeHigherEducationLabel(next);
          var knownLabel = ["学校名称", "毕业院校", "院校名称", "学校", "学历", "学历层次", "学位", "学位名称", "专业", "专业名称", "入学时间", "开始时间", "起始时间", "毕业时间", "结束时间", "终止时间"].indexOf(nextNormalized) !== -1;
          if (!knownLabel && next.length <= 180) return next;
          break;
        }
      }
    }
    return "";
  }

  function readHigherEducationDisplayField(card, labelText) {
    if (!card) return "";
    var target = normalizeHigherEducationLabel(labelText);
    var labels = higherEducationLabelNodes(card).filter(function (candidate) {
      return normalizeHigherEducationLabel(candidate.textContent) === target;
    });
    function cleaned(value) {
      value = normalizeText(value);
      if (!value || value === "--" || value === "-" || value === target) return "";
      return value;
    }
    for (var i = 0; i < labels.length; i += 1) {
      var label = labels[i];
      var item = label && label.closest && label.closest(".el-form-item, [class*='form-item']");
      if (item) {
        var nodes = [];
        try { nodes = Array.from(item.querySelectorAll(".apply-form-read-only, .labelOnly-text")); } catch (eReadOnlyNodes) {}
        for (var j = 0; j < nodes.length; j += 1) {
          if (!isActuallyVisible(nodes[j])) continue;
          var directValue = cleaned(nodes[j].textContent);
          if (directValue) return directValue;
        }
        var content = null;
        try { content = item.querySelector(".el-form-item__content, [class*='form-item__content']"); } catch (eContent) {}
        if (content && isActuallyVisible(content)) {
          var contentValue = cleaned(content.textContent);
          if (contentValue) return contentValue;
        }
        var itemSibling = item.nextElementSibling;
        if (itemSibling && isActuallyVisible(itemSibling)) {
          var itemSiblingValue = cleaned(itemSibling.textContent);
          if (itemSiblingValue) return itemSiblingValue;
        }
      }

      // Plain read-only skins (including old enterprise templates) often render
      // "label + value" without any .el-form-item wrapper.  Prefer the nearest
      // sibling/row before falling back to rendered text parsing.
      var sibling = label && label.nextElementSibling;
      if (sibling && isActuallyVisible(sibling)) {
        var siblingValue = cleaned(sibling.textContent);
        if (siblingValue) return siblingValue;
      }
      var parent = label && label.parentElement;
      if (parent) {
        var parentRendered = parseHigherEducationDisplayText(parent.innerText || parent.textContent || "", labelText);
        if (parentRendered) return parentRendered;
        var parentSibling = parent.nextElementSibling;
        if (parentSibling && isActuallyVisible(parentSibling)) {
          var parentSiblingValue = cleaned(parentSibling.textContent);
          if (parentSiblingValue) return parentSiblingValue;
        }
      }
    }

    // Last-resort read-only parser: use rendered lines/tabs inside this record
    // card.  It is still record-scoped and label-anchored, so it does not infer
    // values from neighboring education cards.
    return parseHigherEducationDisplayText(card.innerText || card.textContent || "", labelText);
  }

  function readHigherEducationDisplayFieldAliases(card, aliases) {
    aliases = Array.isArray(aliases) ? aliases : [aliases];
    for (var i = 0; i < aliases.length; i += 1) {
      var value = readHigherEducationDisplayField(card, aliases[i]);
      if (value) return value;
    }
    return "";
  }

  function higherEducationCardHasAnyLabel(card, aliases) {
    aliases = (Array.isArray(aliases) ? aliases : [aliases]).map(normalizeHigherEducationLabel);
    var labels = higherEducationLabelNodes(card).map(function (candidate) { return normalizeHigherEducationLabel(candidate.textContent); });
    return aliases.some(function (alias) { return labels.indexOf(alias) !== -1; });
  }

  function canonicalEducationIdentityPart(value, kind) {
    var text = normalizeText(value);
    if (!text) return "";
    if (kind === "level") {
      if (/博士/.test(text)) return "博士";
      if (/硕士|研究生/.test(text)) return "硕士";
      if (/本科|大学/.test(text)) return "本科";
      if (/专科|大专/.test(text)) return "专科";
      if (/高中|中专/.test(text)) return "高中";
    } else {
      if (/博士/.test(text)) return "博士";
      if (/硕士/.test(text)) return "硕士";
      if (/学士|本科/.test(text)) return "学士";
      if (/无学位|未取得|未获得|^无$/.test(text)) return "无学位";
    }
    return "";
  }

  function scanHigherEducationExistingRecords(section) {
    if (!section) return [];
    var labels = higherEducationLabelNodes(section);
    var levelLabels = labels.filter(function (label) { return ["学历", "学历层次"].indexOf(normalizeHigherEducationLabel(label.textContent)) !== -1; });
    var cards = [];
    // Prefer the same outer read-only cards used by the public repeat adapter;
    // those wrappers include the record-level Edit action.  The older
    // label-ancestor heuristic remains as a fallback for skins without those
    // wrappers.
    try {
      cards = findZhaopinRepeatDisplayCards(section).filter(function (card) {
        return higherEducationCardHasAnyLabel(card, ["学校名称", "毕业院校", "院校名称", "学校"]) &&
          higherEducationCardHasAnyLabel(card, ["学历", "学历层次"]);
      });
    } catch (eRepeatCards) { cards = []; }
    if (!cards.length) {
      levelLabels.forEach(function (label) {
        var node = label;
        for (var depth = 0; node && node !== section && depth < 8; depth += 1, node = node.parentElement) {
          if (higherEducationCardHasAnyLabel(node, ["学校名称", "毕业院校", "院校名称", "学校"]) &&
              higherEducationCardHasAnyLabel(node, ["学历", "学历层次"])) {
            if (cards.indexOf(node) === -1) cards.push(node);
            break;
          }
        }
      });
    }
    return cards.map(function (card, cardIndex) {
      var school = readHigherEducationDisplayFieldAliases(card, ["学校名称", "毕业院校", "院校名称", "学校"]);
      var major = readHigherEducationDisplayFieldAliases(card, ["专业", "专业名称"]);
      var levelRaw = readHigherEducationDisplayFieldAliases(card, ["学历", "学历层次"]);
      var degreeRaw = readHigherEducationDisplayFieldAliases(card, ["学位", "学位名称"]);
      var startTime = readHigherEducationDisplayFieldAliases(card, ["入学时间", "开始时间", "起始时间"]);
      var endTime = readHigherEducationDisplayFieldAliases(card, ["毕业时间", "结束时间", "终止时间"]);
      return {
        card: card,
        cardIndex: cardIndex,
        identity: {
          school: school,
          major: major,
          level: canonicalEducationIdentityPart(levelRaw, "level"),
          degree: canonicalEducationIdentityPart(degreeRaw, "degree"),
          startTime: normalizeText(startTime),
          endTime: normalizeText(endTime),
        }
      };
    });
  }

  function scanHigherEducationExistingIdentities(section) {
    return scanHigherEducationExistingRecords(section).map(function (entry) { return entry.identity; });
  }

  function higherEducationProfileIdentity(row) {
    row = row || {};
    return {
      school: normalizeText(row.school || row.schoolName || row.university || ""),
      major: normalizeText(row.major || row.majorName || ""),
      level: canonicalEducationIdentityPart(row.level || row.educationLevel, "level"),
      degree: canonicalEducationIdentityPart(row.degree, "degree"),
      startTime: normalizeText(row.startTime || row.startDate || ""),
      endTime: normalizeText(row.endTime || row.endDate || ""),
    };
  }

  function higherEducationIdentityHasSignal(item) {
    return !!(item && (item.school || item.major || item.level || item.degree || item.startTime || item.endTime));
  }

  function scoreHigherEducationIdentity(pageIdentity, profileIdentity) {
    var score = 0;
    if (pageIdentity.level && profileIdentity.level) {
      if (pageIdentity.level !== profileIdentity.level) return { compatible: false, score: -1 };
      score += 60;
    }
    if (pageIdentity.degree && profileIdentity.degree) {
      if (pageIdentity.degree !== profileIdentity.degree) return { compatible: false, score: -1 };
      score += 45;
    }
    if (pageIdentity.major && profileIdentity.major) {
      if (!educationIdentityTextMatches(pageIdentity.major, profileIdentity.major)) return { compatible: false, score: -1 };
      score += 40;
    }
    if (pageIdentity.school && profileIdentity.school) {
      if (!educationIdentityTextMatches(pageIdentity.school, profileIdentity.school)) return { compatible: false, score: -1 };
      score += 20;
    }
    if (pageIdentity.startTime && profileIdentity.startTime && educationIdentityTextMatches(pageIdentity.startTime, profileIdentity.startTime)) score += 10;
    if (pageIdentity.endTime && profileIdentity.endTime && educationIdentityTextMatches(pageIdentity.endTime, profileIdentity.endTime)) score += 10;
    return { compatible: true, score: score };
  }

  function matchHigherEducationExistingRecord(profileRow, existingRecords) {
    var profileIdentity = higherEducationProfileIdentity(profileRow);
    if (!higherEducationIdentityHasSignal(profileIdentity)) return { record: null, recordIndex: -1, reason: "education_profile_identity_missing" };
    var scored = (Array.isArray(existingRecords) ? existingRecords : []).map(function (entry, index) {
      var identity = entry && entry.identity || {};
      if (!higherEducationIdentityHasSignal(identity)) return { entry: entry, index: index, compatible: false, score: -1 };
      var result = scoreHigherEducationIdentity(identity, profileIdentity);
      return { entry: entry, index: index, compatible: result.compatible, score: result.score };
    }).filter(function (item) { return item.compatible && item.score > 0; });
    if (!scored.length) return { record: null, recordIndex: -1, reason: "education_existing_record_not_found" };
    scored.sort(function (a, b) { return b.score - a.score; });
    if (scored.length > 1 && scored[0].score === scored[1].score) return { record: null, recordIndex: -1, reason: "education_existing_record_match_uncertain" };
    return { record: scored[0].entry, recordIndex: Number.isInteger(scored[0].entry && scored[0].entry.cardIndex) ? scored[0].entry.cardIndex : scored[0].index, reason: "" };
  }

  function waitForHigherEducationEditableRoot(step, timeoutMs) {
    return new Promise(function (resolve) {
      var finished = false;
      var observer = null;
      function finish(result) {
        if (finished) return;
        finished = true;
        if (observer) observer.disconnect();
        clearTimeout(timer);
        resolve(result);
      }
      function rescan() {
        var state = resolveHigherEducationEditableRoot(step);
        if (state.root) finish(state);
      }
      var section = resolveHigherEducationSectionScope(step);
      if (section && typeof MutationObserver === "function") {
        observer = new MutationObserver(rescan);
        observer.observe(section, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "style", "aria-hidden"] });
      }
      var timer = setTimeout(function () { finish(resolveHigherEducationEditableRoot(step)); }, timeoutMs || 5000);
      rescan();
    });
  }

  async function runHigherEducationNavigationAdapter(step) {
    var section = resolveHigherEducationSectionScope(step);
    var activeSection = detectActiveResumeSection();
    if (!section) return { enteredSection: false, sectionDetected: activeSection.detectedSection || "", sectionRootFound: false, editableRootFound: false, editableControlCount: 0, editorState: "not_found", addButtonFound: false, addButtonClicked: false, reason: "higher_education_section_not_resolved" };
    var editor = classifyHigherEducationEditableRoot(section);
    var addButton = findHigherEducationAddButton(section);
    var profileRows = Array.isArray(step.plannedRepeatRows) ? step.plannedRepeatRows : (Array.isArray(step.dataOverride) ? step.dataOverride : []);
    var existingRecords = scanHigherEducationExistingRecords(section);
    var existingIdentities = existingRecords.map(function (entry) { return entry.identity; });
    var currentRow = Array.isArray(step.dataOverride) ? step.dataOverride[0] : null;
    var existingMatch = currentRow ? matchHigherEducationExistingRecord(currentRow, existingRecords) : { record: null, recordIndex: -1, reason: "education_profile_identity_missing" };
    var target = selectRemainingEducationRecord(profileRows, existingIdentities);
    var result = { enteredSection: activeSection.detectedSection === "高等教育经历", sectionDetected: activeSection.detectedSection || "", sectionRootFound: true, profileRecordCount: profileRows.length, existingPageRecordCount: existingIdentities.length, missingRecordCount: Number.isInteger(target.missingRecordCount) ? target.missingRecordCount : (target.record ? 1 : Math.max(0, profileRows.length - existingIdentities.length)), targetProfileRecordIndex: Number.isInteger(step.repeatIndex) ? step.repeatIndex : target.recordIndex, matchedExistingRecordIndex: existingMatch && Number.isInteger(existingMatch.recordIndex) ? existingMatch.recordIndex : -1, editableRootFound: !!editor.root, editableControlCount: editor.editableControlCount, editorState: editor.state, addButtonFound: !!addButton, addButtonClicked: false, editButtonFound: false, editButtonClicked: false, editorAppeared: !!editor.root, genericFillerStarted: false, safeToLeave: false, action: editor.root ? "reuse_visible_editor" : "", stoppedBecause: "", reason: editor.reason || "", root: editor.root };
    if (editor.root) return result;
    if (!result.enteredSection) { result.reason = "education_section_not_active"; result.stoppedBecause = result.reason; return result; }

    // Matching card count/identity only proves that a record exists; it does not
    // prove that all education fields are complete.  Reopen the uniquely matched
    // saved card and run the shared education executor so GPA, discipline, study
    // mode, ranking and other fields are audited/refilled before later sections.
    if (step.repairExistingEducationRecords === true && existingMatch && existingMatch.record && existingMatch.record.card) {
      var existingEditButton = findZhaopinRepeatEditButton(existingMatch.record.card) || findHigherEducationEditButton(existingMatch.record.card);
      result.editButtonFound = !!existingEditButton;
      if (!existingEditButton) {
        result.reason = "education_existing_edit_button_not_found";
        result.stoppedBecause = result.reason;
        return result;
      }
      try {
        if (!(await safeClick(existingEditButton))) {
          result.reason = "education_existing_edit_click_failed";
          result.stoppedBecause = result.reason;
          return result;
        }
      } catch (eExistingEdit) {
        result.reason = "education_existing_edit_click_failed";
        result.stoppedBecause = result.reason;
        return result;
      }
      result.editButtonClicked = true;
      var existingEditor = await waitForHigherEducationEditableRoot(step, step.timeoutMs || 6000);
      result.root = existingEditor && existingEditor.root || null;
      result.editableRootFound = !!result.root;
      result.editorAppeared = !!result.root;
      result.editableControlCount = Number(existingEditor && existingEditor.editableControlCount || 0);
      result.editorState = existingEditor && existingEditor.state || "unknown";
      result.action = result.root ? "opened_existing_editor" : "";
      result.reason = result.root ? "" : "education_existing_editor_not_opened";
      result.stoppedBecause = result.reason;
      if (result.root) step.__afZhaopinRepeatAction = "opened_existing_editor";
      return result;
    }
    if (step.repairExistingEducationRecords === true && existingMatch && existingMatch.reason === "education_existing_record_match_uncertain") {
      result.reason = "needs_review:education_existing_record_match_uncertain";
      result.stoppedBecause = result.reason;
      return result;
    }

    if (!target.record) {
      result.reason = target.reason || "education_existing_record_match_uncertain";
      result.safeToLeave = result.reason === "education_no_missing_record" && result.missingRecordCount === 0;
      result.stoppedBecause = result.safeToLeave ? "education_complete_no_missing_record" : result.reason;
      return result;
    }
    // The selected row is handed to the existing generic executor through the
    // step only. It is deliberately never copied into the diagnostic object.
    step.dataOverride = [target.record];
    step.repeatIndex = target.recordIndex;
    if (step.autoOpenEducationEditor !== true) return result;
    if (!addButton) { result.reason = "add_button_not_found"; result.stoppedBecause = result.reason; return result; }
    try {
      if (!(await safeClick(addButton))) { result.reason = "add_click_failed"; result.stoppedBecause = result.reason; return result; }
    } catch (eAddClick) {
      result.reason = "add_click_failed";
      result.stoppedBecause = result.reason;
      return result;
    }
    result.addButtonClicked = true;
    editor = await waitForHigherEducationEditableRoot(step, step.timeoutMs || 6000);
    result.editableRootFound = !!editor.root;
    result.editorAppeared = !!editor.root;
    result.editableControlCount = editor.editableControlCount;
    result.editorState = editor.state;
    result.action = editor.root ? "opened_add_editor" : "";
    if (editor.root) step.__afZhaopinRepeatAction = "opened_add_editor";
    result.reason = editor.root ? "" : "education_add_editor_not_opened";
    result.stoppedBecause = editor.root ? "" : "editor_not_opened";
    result.root = editor.root;
    return result;
  }


  function normalizeZhaopinRepeatIdentityText(value) {
    return normalizeText(value).toLowerCase().replace(/[\s（）()【】\[\]{}<>《》·,，.。:：;；/\\|_\-—–]/g, "");
  }

  function zhaopinRepeatDateKey(value) {
    var digits = String(value || "").replace(/\D/g, "");
    return digits.length >= 6 ? digits.slice(0, 6) : digits;
  }

  function zhaopinRepeatRowIdentity(step, row) {
    row = row || {};
    var category = String(step && (step.categoryOverride || step.category) || "");
    var kind = /projectExperience/.test(category) ? "project"
      : (/certificates/.test(category) ? "certificate"
        : (/languageSkills/.test(category) ? "language"
          : (/campusLeadership/.test(category) ? "leadership"
            : (/awards/.test(category) ? "award"
              : (/familyMembers/.test(category) ? "family" : "work")))));
    if (kind === "project") {
      return {
        kind: kind,
        primary: normalizeZhaopinRepeatIdentityText(row.name || row.projectName || row.activityName || ""),
        secondary: [normalizeZhaopinRepeatIdentityText(row.role || row.position || "")].filter(Boolean),
        dates: [zhaopinRepeatDateKey(row.startTime || row.startDate), zhaopinRepeatDateKey(row.endTime || row.endDate)].filter(Boolean),
      };
    }
    if (kind === "certificate") {
      return {
        kind: kind,
        primary: normalizeZhaopinRepeatIdentityText(row.certificateName || row.certificate || row.name || ""),
        secondary: [],
        dates: [zhaopinRepeatDateKey(row.obtainedTime || row.date)].filter(Boolean),
      };
    }
    if (kind === "language") {
      return {
        kind: kind,
        primary: normalizeZhaopinRepeatIdentityText(row.name || row.language || row.certificateName || row.certificate || ""),
        secondary: [
          normalizeZhaopinRepeatIdentityText(row.certificateName || row.certificate || ""),
          normalizeZhaopinRepeatIdentityText(row.proficiency || row.englishLevel || ""),
        ].filter(Boolean),
        dates: [zhaopinRepeatDateKey(row.obtainedTime || row.date)].filter(Boolean),
      };
    }
    if (kind === "leadership") {
      return {
        kind: kind,
        primary: normalizeZhaopinRepeatIdentityText(row.projectName || row.organization || row.name || ""),
        secondary: [normalizeZhaopinRepeatIdentityText(row.title || row.position || "")].filter(Boolean),
        dates: [zhaopinRepeatDateKey(row.startTime || row.startDate), zhaopinRepeatDateKey(row.endTime || row.endDate)].filter(Boolean),
      };
    }
    if (kind === "award") {
      return {
        kind: kind,
        primary: normalizeZhaopinRepeatIdentityText(row.awardName || row.name || ""),
        secondary: [normalizeZhaopinRepeatIdentityText(row.awardLevel || row.awardIssuer || "")].filter(Boolean),
        dates: [zhaopinRepeatDateKey(row.awardTime || row.date)].filter(Boolean),
      };
    }
    if (kind === "family") {
      return {
        kind: kind,
        primary: normalizeZhaopinRepeatIdentityText(row.name || ""),
        secondary: [normalizeZhaopinRepeatIdentityText(row.relationship || ""), normalizeZhaopinRepeatIdentityText(row.company || row.position || "")].filter(Boolean),
        dates: [zhaopinRepeatDateKey(row.birthDate)].filter(Boolean),
      };
    }
    return {
      kind: kind,
      primary: normalizeZhaopinRepeatIdentityText(row.company || row.organization || row.employer || ""),
      secondary: [
        normalizeZhaopinRepeatIdentityText(row.position || row.jobTitle || row.title || ""),
        normalizeZhaopinRepeatIdentityText(row.department || ""),
      ].filter(Boolean),
      dates: [zhaopinRepeatDateKey(row.startTime || row.startDate), zhaopinRepeatDateKey(row.endTime || row.endDate)].filter(Boolean),
    };
  }

  function isZhaopinRecoveryRecordLock(step) {
    return !!(step && step.__afRecoveryRecordLock && step.__afRecoveryRecordLock.active === true);
  }

  function zhaopinRepeatCardMatchState(card, identity) {
    if (!card || !identity || !identity.primary) return { strong: false, primary: false, supporting: 0 };
    var text = normalizeZhaopinRepeatIdentityText(card.textContent || "");
    var digits = String(card.textContent || "").replace(/\D/g, "");
    var primaryMatch = !!identity.primary && text.indexOf(identity.primary) !== -1;
    if (!primaryMatch) return { strong: false, primary: false, supporting: 0 };
    var supporting = 0;
    (identity.secondary || []).forEach(function (token) {
      if (token && text.indexOf(token) !== -1) supporting += 1;
    });
    (identity.dates || []).forEach(function (token) {
      if (token && digits.indexOf(token) !== -1) supporting += 1;
    });
    var hasSupportingIdentity = (identity.secondary || []).length + (identity.dates || []).length > 0;
    return { strong: primaryMatch && (!hasSupportingIdentity || supporting > 0), primary: primaryMatch, supporting: supporting };
  }

  function readZhaopinRepeatEditorIdentityValues(root) {
    if (!root) return [];
    var values = [];
    var controls = [];
    try { controls = zhaopinRepeatInteractiveControls(root); } catch (e) { controls = []; }
    controls.forEach(function (node) {
      if (!node) return;
      var value = "";
      try {
        if (node.tagName && String(node.tagName).toLowerCase() === "select" && node.selectedOptions && node.selectedOptions.length) {
          value = Array.from(node.selectedOptions).map(function (option) { return option && option.textContent || ""; }).join(" ");
        }
      } catch (eSelect) {}
      if (!value) {
        try { value = String(node.value == null ? "" : node.value); } catch (eValue) {}
      }
      if (!value) {
        try { value = String(node.textContent || ""); } catch (eText) {}
      }
      value = normalizeText(value);
      if (value) values.push(value);
    });
    return values;
  }

  function zhaopinRepeatEditorMatchState(root, identity) {
    if (!root || !identity || !identity.primary) {
      return { strong: false, primary: false, supporting: 0, sampledValueCount: 0 };
    }
    var values = readZhaopinRepeatEditorIdentityValues(root);
    var normalizedValues = values.map(normalizeZhaopinRepeatIdentityText).filter(Boolean);
    var joinedDigits = values.join(" ").replace(/\D/g, "");
    var primaryMatch = normalizedValues.some(function (value) {
      return value.indexOf(identity.primary) !== -1;
    });
    if (!primaryMatch) {
      return { strong: false, primary: false, supporting: 0, sampledValueCount: normalizedValues.length };
    }
    var supporting = 0;
    (identity.secondary || []).forEach(function (token) {
      if (token && normalizedValues.some(function (value) { return value.indexOf(token) !== -1; })) supporting += 1;
    });
    (identity.dates || []).forEach(function (token) {
      if (token && joinedDigits.indexOf(token) !== -1) supporting += 1;
    });
    var hasSupportingIdentity = (identity.secondary || []).length + (identity.dates || []).length > 0;
    return {
      strong: primaryMatch && (!hasSupportingIdentity || supporting > 0),
      primary: primaryMatch,
      supporting: supporting,
      sampledValueCount: normalizedValues.length
    };
  }

  function zhaopinRepeatInteractiveControls(root) {
    if (!root) return [];
    var selector = "input:not([type='hidden']):not([type='file']), textarea, select, [contenteditable='true'], [role='textbox'], [role='combobox'], .el-select, .el-date-editor";
    try {
      return Array.from(root.querySelectorAll(selector)).filter(function (node) {
        if (!isActuallyVisible(node)) return false;
        if (node.disabled) return false;
        if ((node.matches && node.matches("input, textarea")) && node.readOnly && !(node.closest && node.closest(".el-date-editor"))) return false;
        return true;
      });
    } catch (e) {
      return [];
    }
  }

  function classifyZhaopinRepeatEditableRoot(section) {
    if (!section) return { root: null, editableControlCount: 0, state: "not_found" };
    var candidates = [];
    try {
      candidates = Array.from(section.querySelectorAll("form.scrd-web--form-edit, form.el-form, .apply-form--edit, .apply-form-edit, [class*='form-edit']"));
    } catch (e) {}
    candidates = candidates.filter(isActuallyVisible).map(function (candidate) {
      return { root: candidate, count: zhaopinRepeatInteractiveControls(candidate).length };
    }).filter(function (entry) { return entry.count > 0; });
    candidates.sort(function (a, b) { return b.count - a.count; });
    if (!candidates.length) return { root: null, editableControlCount: 0, state: "display" };
    return { root: candidates[0].root, editableControlCount: candidates[0].count, state: "editing" };
  }

  function findZhaopinRepeatDisplayCards(section) {
    if (!section) return [];
    var candidates = [];
    try {
      candidates = Array.from(section.querySelectorAll(".apply-form, .apply-form-read-only, [class*='apply-form']"));
    } catch (e) {}
    candidates = candidates.filter(function (candidate) {
      if (!candidate || candidate === section || !isActuallyVisible(candidate)) return false;
      var cls = String(candidate.className || "");
      if (/apply-module__form|form-edit|apply-form--edit/.test(cls)) return false;
      if (zhaopinRepeatInteractiveControls(candidate).length) return false;
      var text = normalizeText(candidate.textContent || "");
      if (!text || text.length < 2) return false;
      var readOnlyMarker = null;
      try { readOnlyMarker = candidate.querySelector(".apply-form-read-only, .labelOnly-text, [class*='read-only'], [class*='readonly']"); } catch (eMarker) {}
      var editAction = null;
      try {
        editAction = Array.from(candidate.querySelectorAll("button, a, [role='button'], span, i")).filter(isActuallyVisible).find(function (node) {
          return /编辑|修改/.test(normalizeText(node.textContent || node.getAttribute && (node.getAttribute("title") || node.getAttribute("aria-label")) || ""));
        }) || null;
      } catch (eEdit) {}
      return !!readOnlyMarker || !!editAction || /--/.test(text);
    });
    // Nested read-only wrappers frequently describe the same saved record. Keep
    // only the outermost visible card so record counts are stable.
    return candidates.filter(function (candidate) {
      return !candidates.some(function (other) { return other !== candidate && other.contains && other.contains(candidate); });
    });
  }

  function zhaopinRepeatCardSignature(card) {
    var text = normalizeText(card && card.textContent || "");
    return text
      .replace(/编辑|修改|添加|新增|取消/g, "")
      .replace(/[\s：:，,；;。._-]+/g, "")
      .toLowerCase();
  }

  function hasObviousDuplicateZhaopinRepeatCards(cards) {
    var counts = {};
    var duplicateCount = 0;
    (cards || []).forEach(function (card) {
      var signature = zhaopinRepeatCardSignature(card);
      if (!signature || signature.length < 8) return;
      counts[signature] = Number(counts[signature] || 0) + 1;
      if (counts[signature] === 2) duplicateCount += 1;
    });
    return duplicateCount > 0;
  }

  function findZhaopinRepeatAddButton(section) {
    if (!section) return null;
    var roots = [];
    try {
      var titleBox = section.querySelector(".form-content--title-box");
      if (titleBox) roots.push(titleBox);
      var noData = section.querySelector(".no-data");
      if (noData) roots.push(noData);
    } catch (eRoots) {}
    roots.push(section);
    for (var i = 0; i < roots.length; i += 1) {
      var root = roots[i];
      var candidates = [];
      try {
        candidates = Array.from(root.querySelectorAll(".icon-box.icon-box-only, .icon-box, .add-now, button, a, [role='button'], span"));
      } catch (eCandidates) {}
      var found = candidates.filter(isActuallyVisible).find(function (node) {
        if (node.closest && node.closest("form.scrd-web--form-edit, .apply-form--edit, .apply-form-edit")) return false;
        var text = normalizeText(node.textContent || node.getAttribute && (node.getAttribute("title") || node.getAttribute("aria-label")) || "");
        if (/^(?:添加|新增|立即添加)$/.test(text)) return true;
        return i < 2 && /icon-box/.test(String(node.className || "")) && /添加|新增/.test(text);
      });
      if (found) return found;
    }
    return null;
  }

  function findZhaopinRepeatEditButton(card) {
    if (!card) return null;
    var candidates = [];
    try { candidates = Array.from(card.querySelectorAll("button, a, [role='button'], span, i")); } catch (e) {}
    return candidates.filter(isActuallyVisible).find(function (node) {
      var text = normalizeText(node.textContent || node.getAttribute && (node.getAttribute("title") || node.getAttribute("aria-label")) || "");
      return /^(?:编辑|修改)$/.test(text) || /编辑|修改/.test(text);
    }) || null;
  }

  async function openZhaopinRepeatExistingEditor(card, step, section) {
    var editButton = findZhaopinRepeatEditButton(card);
    var result = { editButtonFound: !!editButton, editButtonClicked: false, root: null };
    if (!editButton) return result;
    try {
      if (!(await safeClick(editButton))) return result;
    } catch (eClick) { return result; }
    result.editButtonClicked = true;
    var editor = await waitForZhaopinRepeatEditableRoot(step, section, step.timeoutMs || 6000);
    result.root = editor && editor.root || null;
    result.editableControlCount = editor && editor.editableControlCount || 0;
    return result;
  }

  function waitForZhaopinRepeatEditableRoot(step, section, timeoutMs) {
    return new Promise(function (resolve) {
      var finished = false;
      var observer = null;
      function finish(result) {
        if (finished) return;
        finished = true;
        if (observer) observer.disconnect();
        clearTimeout(timer);
        resolve(result);
      }
      function rescan() {
        var liveSection = findResumeSectionRootByTitle(step.cardTitle || step.name) || section;
        var state = classifyZhaopinRepeatEditableRoot(liveSection);
        if (state.root) finish(state);
      }
      if (section && typeof MutationObserver === "function") {
        observer = new MutationObserver(rescan);
        observer.observe(section, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "style", "aria-hidden"] });
      }
      var timer = setTimeout(function () {
        var liveSection = findResumeSectionRootByTitle(step.cardTitle || step.name) || section;
        finish(classifyZhaopinRepeatEditableRoot(liveSection));
      }, timeoutMs || 6000);
      rescan();
    });
  }

  function writeZhaopinRepeatSectionTrace(entry) {
    try {
      var trace = JSON.parse(document.documentElement.getAttribute("data-af-zhaopin-repeat-section-trace") || "{}");
      if (!trace || typeof trace !== "object") trace = {};
      if (!Array.isArray(trace.records)) trace.records = [];
      var safeEntry = {
        section: String(entry && entry.section || ""),
        category: String(entry && entry.category || ""),
        repeatIndex: Number.isInteger(entry && entry.repeatIndex) ? entry.repeatIndex : -1,
        existingPageRecordCount: Number(entry && entry.existingPageRecordCount || 0),
        plannedRecordCount: Number(entry && entry.plannedRecordCount || 0),
        excessRecordCount: Number(entry && entry.excessRecordCount || 0),
        excessRepairMode: String(entry && entry.excessRepairMode || ""),
        matchedRecordCount: Number(entry && entry.matchedRecordCount || 0),
        recoveryRecordLockActive: !!(entry && entry.recoveryRecordLockActive),
        visibleEditorIdentityMatched: !!(entry && entry.visibleEditorIdentityMatched),
        visibleEditorIdentityPrimary: !!(entry && entry.visibleEditorIdentityPrimary),
        visibleEditorIdentitySupporting: Number(entry && entry.visibleEditorIdentitySupporting || 0),
        editButtonFound: !!(entry && entry.editButtonFound),
        editButtonClicked: !!(entry && entry.editButtonClicked),
        addButtonFound: !!(entry && entry.addButtonFound),
        addButtonClicked: !!(entry && entry.addButtonClicked),
        editorAppeared: !!(entry && entry.editorAppeared),
        repairFailureCancelled: !!(entry && entry.repairFailureCancelled),
        continuedAfterRepairFailure: !!(entry && entry.continuedAfterRepairFailure),
        action: String(entry && entry.action || ""),
        reason: String(entry && entry.reason || ""),
      };
      trace.records.push(safeEntry);
      if (trace.records.length > 30) trace.records = trace.records.slice(-30);
      trace.last = safeEntry;
      document.documentElement.setAttribute("data-af-zhaopin-repeat-section-trace", JSON.stringify(trace));
    } catch (e) {}
  }

  async function runZhaopinRepeatNavigationAdapter(step) {
    var sectionTitle = String(step && (step.cardTitle || step.name) || "");
    var section = findResumeSectionRootByTitle(sectionTitle) || findStepCard(step, document);
    var activeSection = detectActiveResumeSection();
    var row = Array.isArray(step && step.dataOverride) ? step.dataOverride[0] : null;
    var category = String(step && (step.categoryOverride || step.category) || "");
    var result = {
      enteredSection: normalizeSectionTitle(activeSection.detectedSection) === normalizeSectionTitle(sectionTitle),
      sectionDetected: activeSection.detectedSection || "",
      sectionRootFound: !!section,
      editableRootFound: false,
      editableControlCount: 0,
      existingPageRecordCount: 0,
      plannedRecordCount: Array.isArray(step && step.plannedRepeatRows) ? step.plannedRepeatRows.length : 0,
      excessRecordCount: 0,
      excessRepairMode: "",
      matchedRecordCount: 0,
      editButtonFound: false,
      editButtonClicked: false,
      addButtonFound: false,
      addButtonClicked: false,
      editorAppeared: false,
      safeToLeave: false,
      action: "",
      reason: "",
      root: null,
    };
    if (!section) {
      result.reason = "repeat_section_not_resolved";
      writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
      return result;
    }
    var plannedRows = Array.isArray(step && step.plannedRepeatRows) ? step.plannedRepeatRows : [];
    result.plannedRecordCount = plannedRows.length;
    var identity = zhaopinRepeatRowIdentity(step, row);
    var recoveryRecordLockActive = isZhaopinRecoveryRecordLock(step);
    result.recoveryRecordLockActive = recoveryRecordLockActive;

    var editor = classifyZhaopinRepeatEditableRoot(section);
    result.editableRootFound = !!editor.root;
    result.editableControlCount = editor.editableControlCount;
    result.editorAppeared = !!editor.root;
    result.root = editor.root;
    if (!result.enteredSection) {
      result.reason = "repeat_section_not_active";
      writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
      return result;
    }
    if (editor.root) {
      if (recoveryRecordLockActive) {
        var editorIdentityState = zhaopinRepeatEditorMatchState(editor.root, identity);
        result.visibleEditorIdentityMatched = editorIdentityState.strong === true;
        result.visibleEditorIdentityPrimary = editorIdentityState.primary === true;
        result.visibleEditorIdentitySupporting = Number(editorIdentityState.supporting || 0);
        if (!editorIdentityState.strong) {
          // Build155: a visible editor left over from the manually repaired previous
          // record is NOT evidence that it belongs to the next profile row. During
          // recovery, never reuse an editor until its business identity is proven.
          result.root = null;
          result.action = "blocked_recovery_visible_editor_identity_unresolved";
          result.reason = "needs_review:repeat_recovery_visible_editor_identity_unresolved";
          writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
          return result;
        }
        result.action = "reuse_visible_editor_verified";
      } else {
        result.action = "reuse_visible_editor";
      }
      writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
      return result;
    }

    var cards = findZhaopinRepeatDisplayCards(section);
    result.existingPageRecordCount = cards.length;
    var allowRepairDespiteExcess = false;
    if (plannedRows.length && cards.length > plannedRows.length) {
      result.excessRecordCount = cards.length - plannedRows.length;
      allowRepairDespiteExcess = !!(
        step && step.zhaopinRepairCorruptedExcessDuplicates === true &&
        step.zhaopinRepairExistingByPosition === true &&
        !isZhaopinRecoveryRecordLock(step) && step.__afDisablePositionalRepeatRepair !== true &&
        hasObviousDuplicateZhaopinRepeatCards(cards)
      );
      if (allowRepairDespiteExcess) {
        result.excessRepairMode = "repair_planned_rows_preserve_excess";
      } else if (step && step.zhaopinBlockOnExcessExistingRecords === true) {
        result.action = "blocked_excess_existing_records";
        result.reason = "needs_review:repeat_excess_existing_records";
        writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
        return result;
      }
    }
    if (!identity.primary) {
      result.reason = "needs_review:repeat_identity_missing";
      writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
      return result;
    }
    var states = cards.map(function (card) { return zhaopinRepeatCardMatchState(card, identity); });
    var strongMatchIndexes = [];
    var primaryOnlyMatches = 0;
    states.forEach(function (state, index) {
      if (state.strong) strongMatchIndexes.push(index);
      else if (state.primary) primaryOnlyMatches += 1;
    });
    result.matchedRecordCount = strongMatchIndexes.length;
    if (strongMatchIndexes.length === 1) {
      if (step && step.zhaopinRepairExistingRecords === true) {
        var matchedOpen = await openZhaopinRepeatExistingEditor(cards[strongMatchIndexes[0]], step, section);
        result.editButtonFound = !!matchedOpen.editButtonFound;
        result.editButtonClicked = !!matchedOpen.editButtonClicked;
        result.root = matchedOpen.root;
        result.editableRootFound = !!matchedOpen.root;
        result.editorAppeared = !!matchedOpen.root;
        result.editableControlCount = Number(matchedOpen.editableControlCount || 0);
        result.action = matchedOpen.root ? "opened_existing_editor" : "";
        result.reason = matchedOpen.root ? "" : "repeat_existing_edit_failed";
        writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
        return result;
      }
      result.safeToLeave = true;
      result.action = "record_already_present";
      result.reason = "repeat_record_already_present";
      writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
      return result;
    }
    if (strongMatchIndexes.length > 1) {
      result.reason = "needs_review:repeat_existing_record_match_uncertain";
      writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
      return result;
    }

    // Build 32/33 可能已经留下只有“职务/描述”等少量字段的半成品卡片。
    // 在页面记录数不超过资料库计划数时，允许按同一 repeatIndex 打开旧卡片
    // 修复；不会删除记录，也不会在记录数超额时擅自覆盖。
    if (step && step.zhaopinRepairExistingByPosition === true && !isZhaopinRecoveryRecordLock(step) && step.__afDisablePositionalRepeatRepair !== true && Number.isInteger(step.repeatIndex) &&
        step.repeatIndex >= 0 && step.repeatIndex < cards.length &&
        (cards.length <= plannedRows.length || allowRepairDespiteExcess)) {
      var positionalOpen = await openZhaopinRepeatExistingEditor(cards[step.repeatIndex], step, section);
      result.editButtonFound = !!positionalOpen.editButtonFound;
      result.editButtonClicked = !!positionalOpen.editButtonClicked;
      result.root = positionalOpen.root;
      result.editableRootFound = !!positionalOpen.root;
      result.editorAppeared = !!positionalOpen.root;
      result.editableControlCount = Number(positionalOpen.editableControlCount || 0);
      result.action = positionalOpen.root ? "opened_existing_editor_by_position" : "";
      result.reason = positionalOpen.root ? "" : (primaryOnlyMatches > 0 ? "needs_review:repeat_existing_record_match_uncertain" : "repeat_existing_edit_failed");
      writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
      return result;
    }
    if (primaryOnlyMatches > 0) {
      result.reason = "needs_review:repeat_existing_record_match_uncertain";
      writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
      return result;
    }

    if (isZhaopinRecoveryRecordLock(step) && cards.length >= plannedRows.length) {
      result.action = "blocked_recovery_record_identity_unresolved";
      result.reason = "needs_review:repeat_recovery_record_identity_unresolved";
      writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
      return result;
    }

    var addButton = findZhaopinRepeatAddButton(section);
    result.addButtonFound = !!addButton;
    if (!addButton) {
      result.reason = "repeat_add_button_not_found";
      writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
      return result;
    }
    try {
      if (!(await safeClick(addButton))) {
        result.reason = "repeat_add_click_failed";
        writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
        return result;
      }
    } catch (eAdd) {
      result.reason = "repeat_add_click_failed";
      writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
      return result;
    }
    result.addButtonClicked = true;
    editor = await waitForZhaopinRepeatEditableRoot(step, section, step.timeoutMs || 6000);
    result.editableRootFound = !!editor.root;
    result.editableControlCount = editor.editableControlCount;
    result.editorAppeared = !!editor.root;
    result.root = editor.root;
    result.action = editor.root ? "opened_add_editor" : "";
    result.reason = editor.root ? "" : "repeat_add_editor_not_opened";
    writeZhaopinRepeatSectionTrace(Object.assign({ section: sectionTitle, category: category, repeatIndex: step && step.repeatIndex }, result));
    return result;
  }

  function selectRemainingEducationRecord(profileRows, existingIdentities) {
    var rows = Array.isArray(profileRows) ? profileRows : [];
    var identities = Array.isArray(existingIdentities) ? existingIdentities : [];
    var pageIdentities = identities.map(higherEducationProfileIdentity);
    if (pageIdentities.some(function (item) { return !higherEducationIdentityHasSignal(item); })) {
      return { record: null, recordIndex: -1, missingRecordCount: Math.max(0, rows.length - pageIdentities.length), matchedProfileIndices: [], reason: "education_existing_record_match_uncertain" };
    }
    var used = [];
    for (var i = 0; i < pageIdentities.length; i += 1) {
      var pageIdentity = pageIdentities[i];
      var scored = rows.map(function (row, index) {
        var result = scoreHigherEducationIdentity(pageIdentity, higherEducationProfileIdentity(row));
        return { index: index, compatible: result.compatible, score: result.score };
      }).filter(function (entry) { return used.indexOf(entry.index) === -1 && entry.compatible; });
      if (!scored.length) {
        return { record: null, recordIndex: -1, missingRecordCount: Math.max(0, rows.length - used.length), matchedProfileIndices: used.slice(), reason: "education_existing_record_match_uncertain" };
      }
      scored.sort(function (a, b) { return b.score - a.score; });
      if (scored[0].score <= 0 || (scored.length > 1 && scored[0].score === scored[1].score)) {
        return { record: null, recordIndex: -1, missingRecordCount: Math.max(0, rows.length - used.length), matchedProfileIndices: used.slice(), reason: "education_existing_record_match_uncertain" };
      }
      used.push(scored[0].index);
    }
    var remaining = rows.map(function (row, index) { return { row: row, index: index }; }).filter(function (entry) { return used.indexOf(entry.index) === -1; });
    if (remaining.length === 0) {
      return { record: null, recordIndex: -1, missingRecordCount: 0, matchedProfileIndices: used.slice(), reason: "education_no_missing_record" };
    }
    if (remaining.length !== 1) {
      return { record: null, recordIndex: -1, missingRecordCount: remaining.length, matchedProfileIndices: used.slice(), reason: "needs_review:education_record_not_unique" };
    }
    return { record: remaining[0].row, recordIndex: remaining[0].index, missingRecordCount: 1, matchedProfileIndices: used.slice(), reason: "" };
  }

  function createInitialEducationRepeatNavigationTrace(step) {
    var profileRecordCount = Array.isArray(step && step.plannedRepeatRows)
      ? step.plannedRepeatRows.length
      : (Array.isArray(step && step.dataOverride) ? step.dataOverride.length : 0);
    return { enteredSection: false, sectionDetected: detectActiveResumeSection().detectedSection || "", profileRecordCount: profileRecordCount, existingPageRecordCount: 0, missingRecordCount: 0, targetProfileRecordIndex: -1, addButtonFound: false, addButtonClicked: false, editorAppeared: false, editorControlCount: 0, genericFillerStarted: false, safeToLeave: false, stoppedBecause: "section_navigation_pending" };
  }

  function findHigherEducationEditButton(section) {
    if (!section) return null;
    var candidates = [];
    try { candidates = Array.from(section.querySelectorAll("button, a, [role='button'], .icon-box, [class*='edit']")).filter(isVisible); } catch (e) {}
    return candidates.find(function (node) {
      var text = normalizeText(node.textContent || node.getAttribute && (node.getAttribute("title") || node.getAttribute("aria-label")) || "");
      return /^(编辑|修改)$/.test(text) || /(?:编辑|修改)/.test(text) && String(node.className || "").indexOf("edit") !== -1;
    }) || null;
  }

  function detectHigherEducationEditorState(step) {
    var section = resolveHigherEducationSectionScope(step);
    if (!section) return { state: "unknown", section: null, editorReady: false, editableControlCount: 0, editButton: null, reason: "higher_education_section_not_resolved" };
    var controls = higherEducationInteractiveControls(section);
    var editButton = findHigherEducationEditButton(section);
    var creating = false;
    try { creating = !!Array.from(section.querySelectorAll("form, .apply-form--edit, [class*='edit']")).filter(isVisible).find(function (node) { return /添加|新增/.test(normalizeText(node.textContent)); }); } catch (eCreating) {}
    if (controls.length >= 3) return { state: creating ? "creating" : "editing", section: section, editorReady: true, editableControlCount: controls.length, editButton: editButton, reason: "" };
    if (higherEducationLabelNodes(section).length && editButton) return { state: "display", section: section, editorReady: false, editableControlCount: controls.length, editButton: editButton, reason: "higher_education_editor_not_open" };
    return { state: "unknown", section: section, editorReady: false, editableControlCount: controls.length, editButton: editButton, reason: "higher_education_editor_state_unknown" };
  }

  function detectActiveResumeSection() {
    var active = null;
    try { active = document.querySelector(".resume-menu-item.active .resume-menu-item__title, .resume-menu-item.is-active .resume-menu-item__title, .resume-menu-item.current .resume-menu-item__title, .resume-menu-item[class*='active'] .resume-menu-item__title, .resume-menu-item[class*='selected'] .resume-menu-item__title, .resume-menu-item[aria-current='true'] .resume-menu-item__title, [aria-current='page'].resume-menu-item__title, .resume-menu-item__title.active, .resume-menu-item__title.is-active, .resume-menu-item__title[class*='selected'], .resume-menu-item:has(.active-marker) .resume-menu-item__title, .resume-menu-item:has([aria-selected='true']) .resume-menu-item__title"); } catch (eActive) {}
    var activeText = normalizeHigherEducationLabel(active && active.textContent);
    var headingCandidates = [];
    try {
      headingCandidates = Array.from(document.querySelectorAll(".form-content--title, [class*='section-title'], [class*='module-title'], h1, h2, h3, h4, h5, h6")).filter(isActuallyVisible).map(function (heading) {
        var text = normalizeHigherEducationLabel(heading.textContent);
        if (!text || text.length > 30) return null;
        var rect = heading.getBoundingClientRect();
        var viewportHeight = Number(window.innerHeight || document.documentElement.clientHeight || 800);
        var intersects = rect.bottom > 0 && rect.top < viewportHeight;
        return intersects ? { text: text, distance: Math.abs(rect.top - 100) } : null;
      }).filter(Boolean).sort(function (a, b) { return a.distance - b.distance; });
    } catch (eHeading) {}
    var contentHeadingText = headingCandidates.length ? headingCandidates[0].text : "";
    var detected = activeText || contentHeadingText;
    var strategy = activeText ? (contentHeadingText === activeText ? "navigation_and_content" : "active_navigation") : (contentHeadingText ? "viewport_content_heading" : "none");
    var confidence = strategy === "navigation_and_content" ? "high" : (strategy === "active_navigation" ? "high" : (strategy === "viewport_content_heading" ? "medium" : "none"));
    return { activeNavText: activeText, contentHeadingText: contentHeadingText, detectedSection: detected, detectionStrategy: strategy, confidence: confidence, currentVisibleSectionTitle: detected };
  }

  function detectActiveSectionState() {
    return detectActiveResumeSection();
  }

  function resumeExecutionStepsFromActiveSection(executionSteps, sectionTitle) {
    var steps = Array.isArray(executionSteps) ? executionSteps : [];
    var normalizedSection = normalizeSectionTitle(sectionTitle);
    if (!normalizedSection) return steps;
    var activeIndex = steps.findIndex(function (step) {
      return step && normalizeSectionTitle(step.cardTitle || step.name) === normalizedSection;
    });
    return activeIndex > 0 ? steps.slice(activeIndex) : steps;
  }

  function findUnsavedResumeNavigationModal() {
    try {
      return Array.from(document.querySelectorAll(".el-message-box__wrapper[role='dialog'], .el-message-box__wrapper, .el-message-box, [role='dialog']")).filter(isActuallyVisible).find(function (dialog) {
        return /当前模块还未保存|是否要保存当前模块信息|保存当前模块信息/.test(normalizeText(dialog.textContent));
      }) || null;
    } catch (eModal) {
      return null;
    }
  }

  function inspectCurrentModuleValidation(sectionTitle) {
    var root = findResumeSectionRootByTitle(sectionTitle);
    var labels = [];
    if (!root) return { section: String(sectionTitle || ""), visibleErrorCount: 0, requiredErrorLabels: [], canSaveAndNavigate: false, reason: "current_module_scope_not_resolved" };
    var errors = [];
    try { errors = Array.from(root.querySelectorAll(".el-form-item.is-error, .el-form-item__error")).filter(isActuallyVisible); } catch (eErrors) {}
    var errorItems = [];
    errors.forEach(function (error) {
      var item = error.matches && error.matches(".el-form-item") ? error : (error.closest && error.closest(".el-form-item"));
      if (item && errorItems.indexOf(item) === -1) errorItems.push(item);
      var label = null;
      try { label = item && item.querySelector(".el-form-item__label, label, [class*='label']"); } catch (eLabel) {}
      var text = normalizeHigherEducationLabel(label && label.textContent);
      if (text && labels.indexOf(text) === -1) labels.push(text);
    });
    return { section: String(sectionTitle || ""), visibleErrorCount: errorItems.length, requiredErrorLabels: labels, canSaveAndNavigate: errorItems.length === 0, reason: errorItems.length ? "current_module_validation_failed" : "" };
  }

  async function completeModuleSaveAndNavigate(modal, fromSection, targetSection, step) {
    var validation = inspectCurrentModuleValidation(fromSection);
    var trace = { fromSection: String(fromSection || ""), targetSection: String(targetSection || ""), navigationRequested: true, unsavedModalDetected: !!modal, validationChecked: true, visibleErrorCount: validation.visibleErrorCount, blockingLabels: validation.requiredErrorLabels.slice(), saveAndNavigateButtonFound: false, saveAndNavigateClicked: false, modalClosed: false, targetSectionEntered: false, result: "", reason: validation.reason || "" };
    if (!validation.canSaveAndNavigate) {
      trace.result = "blocked_by_validation";
      trace.reason = validation.reason || "current_module_validation_failed";
      return trace;
    }
    var saveAndNavigate = findByText(modal, ["保存并跳转"], "button, [role='button']");
    trace.saveAndNavigateButtonFound = !!saveAndNavigate;
    if (!saveAndNavigate) { trace.result = "failed"; trace.reason = "save_and_navigate_button_not_found"; return trace; }
    try { trace.saveAndNavigateClicked = !!(await safeClick(saveAndNavigate)); } catch (eClick) {}
    if (!trace.saveAndNavigateClicked) { trace.result = "failed"; trace.reason = "save_navigation_failed"; return trace; }
    var completed = await waitUntil(function () {
      var modalClosed = !isActuallyVisible(modal);
      var current = detectActiveResumeSection();
      return modalClosed && current.detectedSection === targetSection ? { current: current } : null;
    }, step && (step.sectionNavigationTimeoutMs || step.timeoutMs) || 8000);
    trace.modalClosed = !isActuallyVisible(modal);
    trace.targetSectionEntered = !!(completed && completed.current && completed.current.detectedSection === targetSection);
    trace.result = trace.modalClosed && trace.targetSectionEntered ? "success" : "failed";
    trace.reason = trace.result === "success" ? "" : "save_navigation_failed";
    return trace;
  }

  function analyzedNavigationNodeIsActive(node) {
    var current = node;
    var depth = 0;
    while (current && current !== document && depth < 7) {
      try {
        var ariaCurrent = String(current.getAttribute && current.getAttribute("aria-current") || "").toLowerCase();
        var ariaSelected = String(current.getAttribute && current.getAttribute("aria-selected") || "").toLowerCase();
        if (ariaCurrent === "page" || ariaCurrent === "true" || ariaSelected === "true") return true;
        var className = String(current.className || "");
        if (/(?:^|\s)(?:on|active|current|selected|is-active|is-current|is-selected)(?:\s|$)/i.test(className)) return true;
      } catch (eState) {}
      current = current.parentElement;
      depth += 1;
    }
    return false;
  }

  function analyzedNavigationResolveUnique(selector) {
    var query = String(selector || "").trim();
    if (!query) return { element: null, count: 0 };
    try {
      var nodes = Array.from(document.querySelectorAll(query)).filter(isActuallyVisible);
      return { element: nodes.length === 1 ? nodes[0] : null, count: nodes.length };
    } catch (eSelector) {
      return { element: null, count: 0, error: "invalid_selector" };
    }
  }

  function analyzedNavigationControlText(node) {
    if (!node) return "";
    var value = "";
    try { value = node.value || node.getAttribute && node.getAttribute("value") || ""; } catch (eValue) {}
    return normalizeText(node.textContent || value || node.getAttribute && (node.getAttribute("aria-label") || node.getAttribute("title")) || "");
  }

  function findExplicitSectionSaveButton(sectionText) {
    var normalizedSection = normalizeSectionTitle(sectionText);
    var exactTexts = ["保存" + normalizedSection, "保存当前" + normalizedSection].map(normalizeText).filter(Boolean);
    var candidates = [];
    try {
      candidates = Array.from(document.querySelectorAll("button, a, input[type='button'], input[type='submit'], [role='button']")).filter(isActuallyVisible).filter(function (node) {
        var text = analyzedNavigationControlText(node);
        return text && !FORBIDDEN_ACTION_TEXT.test(text);
      });
    } catch (eCandidates) {}
    var exact = candidates.filter(function (node) { return exactTexts.indexOf(analyzedNavigationControlText(node)) !== -1; });
    if (exact.length === 1) return { element: exact[0], count: 1, strategy: "section_exact", text: analyzedNavigationControlText(exact[0]) };
    if (exact.length > 1) return { element: null, count: exact.length, strategy: "section_exact_ambiguous", text: "" };
    var generic = candidates.filter(function (node) { return analyzedNavigationControlText(node) === normalizeText("保存"); });
    if (generic.length === 1) return { element: generic[0], count: 1, strategy: "single_generic_save", text: analyzedNavigationControlText(generic[0]) };
    return { element: null, count: generic.length, strategy: generic.length > 1 ? "generic_save_ambiguous" : "save_not_found", text: "" };
  }

  function collectAnalyzedNavigationValidationMessages() {
    var selectors = [
      ".error", ".invalid", ".field-validation-error", ".help-block",
      "[class*='error' i]", "[class*='invalid' i]", "[class*='wrong' i]",
      "[class*='warn' i]", "[class*='tips' i]", "[class*='tip' i]"
    ].join(", ");
    var nodes = [];
    try { nodes = Array.from(document.querySelectorAll(selectors)).filter(isActuallyVisible); } catch (eNodes) {}
    var seen = [];
    nodes.forEach(function (node) {
      var text = normalizeText(node.textContent || "");
      if (!text || text.length > 100) return;
      if (!/(必填|不能为空|请选择|请填写|格式|错误|无效)/.test(text)) return;
      if (seen.indexOf(text) === -1) seen.push(text);
    });
    return seen.slice(0, 20);
  }

  function analyzedNavigationSuccessText(node) {
    var text = normalizeText(node && node.textContent || "");
    if (!text || text.length > 300) return "";
    return /(保存成功|保存完成|修改成功|更新成功)/.test(text) ? text : "";
  }

  function analyzedNavigationVisibleInOwnerDocument(element) {
    if (!element || element.isConnected === false) return false;
    var rect = null;
    try { rect = element.getBoundingClientRect(); } catch (eRect) {}
    if (!rect || rect.width <= 0 || rect.height <= 0) return false;
    var ownerDoc = null;
    var ownerWin = null;
    try { ownerDoc = element.ownerDocument || document; } catch (eOwnerDoc) { ownerDoc = document; }
    try { ownerWin = ownerDoc && ownerDoc.defaultView || window; } catch (eOwnerWin) { ownerWin = window; }
    var node = element;
    while (node && node !== ownerDoc) {
      try {
        // Build64: aria-hidden is an accessibility-tree hint, not a visual rendering
        // primitive. Legacy Bootstrap/custom modals may remain aria-hidden=true even
        // while visibly rendered. Save-feedback verification must therefore rely on
        // actual geometry plus display/visibility instead of rejecting on aria-hidden.
        var style = ownerWin && ownerWin.getComputedStyle ? ownerWin.getComputedStyle(node) : null;
        if (style && (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse")) return false;
      } catch (eStyle) {}
      node = node.parentElement;
    }
    return true;
  }

  function analyzedNavigationTextNodeIsRendered(textNode) {
    if (!textNode || !textNode.parentElement || textNode.parentElement.isConnected === false) return false;
    var ownerDoc = null;
    var ownerWin = null;
    try { ownerDoc = textNode.ownerDocument || document; } catch (eOwnerDoc) { ownerDoc = document; }
    try { ownerWin = ownerDoc && ownerDoc.defaultView || window; } catch (eOwnerWin) { ownerWin = window; }
    var node = textNode.parentElement;
    while (node && node !== ownerDoc) {
      try {
        var style = ownerWin && ownerWin.getComputedStyle ? ownerWin.getComputedStyle(node) : null;
        if (style && (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse")) return false;
      } catch (eStyle) {}
      node = node.parentElement;
    }
    try {
      if (ownerDoc && ownerDoc.createRange) {
        var range = ownerDoc.createRange();
        range.selectNodeContents(textNode);
        var rects = range.getClientRects ? Array.from(range.getClientRects()) : [];
        if (rects.some(function (rect) { return rect && rect.width > 0 && rect.height > 0; })) return true;
        var rect = range.getBoundingClientRect ? range.getBoundingClientRect() : null;
        if (rect && rect.width > 0 && rect.height > 0) return true;
      }
    } catch (eRange) {}
    // Test/fallback environments may not implement Range. If the parent itself has
    // a rendered box, the text is still safe to consider visually present.
    return analyzedNavigationVisibleInOwnerDocument(textNode.parentElement);
  }

  function collectAnalyzedNavigationSuccessTextNodes(rootEntry, limit) {
    var out = [];
    var root = rootEntry && rootEntry.root;
    if (!root) return out;
    var ownerDoc = null;
    var ownerWin = null;
    try { ownerDoc = root.ownerDocument || (root.nodeType === 9 ? root : document); } catch (eDoc) { ownerDoc = document; }
    try { ownerWin = ownerDoc && ownerDoc.defaultView || window; } catch (eWin) { ownerWin = window; }
    var showText = 4;
    try { if (ownerWin && ownerWin.NodeFilter) showText = ownerWin.NodeFilter.SHOW_TEXT; } catch (eFilter) {}
    try {
      if (!ownerDoc || !ownerDoc.createTreeWalker) return out;
      var walker = ownerDoc.createTreeWalker(root, showText);
      var current = walker.nextNode();
      while (current && out.length < Number(limit || 24)) {
        var text = normalizeText(current.nodeValue || current.textContent || "");
        if (text && text.length <= 180 && /(保存成功|保存完成|修改成功|更新成功)/.test(text)) {
          out.push({ node: current, text: text, source: rootEntry.source || "document", rendered: analyzedNavigationTextNodeIsRendered(current) });
        }
        current = walker.nextNode();
      }
    } catch (eWalker) {}
    return out;
  }

  function collectAnalyzedNavigationSearchRoots() {
    var roots = [];
    var seen = [];
    function addRoot(root, source) {
      if (!root || typeof root.querySelectorAll !== "function" || seen.indexOf(root) !== -1) return;
      seen.push(root);
      roots.push({ root: root, source: source || "document" });
      var hosts = [];
      try { hosts = Array.from(root.querySelectorAll("*")); } catch (eHosts) {}
      hosts.forEach(function (host, index) {
        try {
          if (host.shadowRoot) addRoot(host.shadowRoot, (source || "document") + ":shadow:" + index);
        } catch (eShadow) {}
      });
      var frames = [];
      try { frames = Array.from(root.querySelectorAll("iframe, frame")); } catch (eFrames) {}
      frames.slice(0, 20).forEach(function (frame, index) {
        try {
          if (frame.contentDocument) addRoot(frame.contentDocument, (source || "document") + ":frame:" + index);
        } catch (eFrameDoc) {}
      });
    }
    addRoot(document, "document");
    try {
      if (window.top && window.top !== window && window.top.document) addRoot(window.top.document, "top_document");
    } catch (eTop) {}
    return roots.slice(0, 40);
  }

  function findAnalyzedNavigationModalCloseControl(modal) {
    if (!modal || typeof modal.querySelectorAll !== "function") return { element: null, count: 0, strategy: "modal_missing" };
    var nodes = [];
    try {
      nodes = Array.from(modal.querySelectorAll("button, a, [role='button'], input[type='button'], input[type='submit'], [data-dismiss='modal'], [data-bs-dismiss='modal'], .close, [class*='close' i]")).filter(analyzedNavigationVisibleInOwnerDocument);
    } catch (eNodes) {}
    var candidates = nodes.map(function (node) {
      var text = analyzedNavigationControlText(node);
      var aria = normalizeText(node.getAttribute && (node.getAttribute("aria-label") || node.getAttribute("title")) || "");
      var className = String(node.className || "");
      var primaryCloseText = /^(关闭|确定|知道了|我知道了)$/i.test(text);
      var iconCloseText = /^(×|x|✕|✖)$/i.test(text);
      var containsCloseText = text.length <= 12 && /(关闭|close)/i.test(text);
      var exactAria = /^(关闭|close)$/i.test(aria);
      var dismissAttr = !!(node.getAttribute && (node.getAttribute("data-dismiss") === "modal" || node.getAttribute("data-bs-dismiss") === "modal"));
      var closeClass = /(?:^|\s)(?:close|modal-close|dialog-close)(?:\s|$)/i.test(className);
      var score = primaryCloseText ? 7 : containsCloseText ? 6 : exactAria ? 5 : dismissAttr ? 4 : iconCloseText ? 3 : closeClass ? 2 : 0;
      return { node: node, score: score, text: text || aria || className };
    }).filter(function (entry) { return entry.score > 0; });
    if (!candidates.length) return { element: null, count: 0, strategy: "close_not_found" };
    candidates.sort(function (a, b) { return b.score - a.score; });
    var topScore = candidates[0].score;
    var top = candidates.filter(function (entry) { return entry.score === topScore; });
    if (top.length !== 1) return { element: null, count: top.length, strategy: "close_ambiguous" };
    return { element: top[0].node, count: 1, strategy: "modal_close_control", text: top[0].text };
  }

  function findAnalyzedNavigationSaveSuccessFeedback() {
    var roots = collectAnalyzedNavigationSearchRoots();
    var messageSelector = "[role='alert'], .alert, .message, [class*='message' i], [class*='toast' i], [class*='notice' i], [class*='success' i]";
    var modalSelector = "[role='dialog'], [aria-modal='true'], .modal, [class*='modal' i], [class*='dialog' i], [class*='layer' i], [class*='popup' i]";
    for (var r = 0; r < roots.length; r += 1) {
      var rootEntry = roots[r];
      var messageNodes = [];
      try { messageNodes = Array.from(rootEntry.root.querySelectorAll(messageSelector)).filter(analyzedNavigationVisibleInOwnerDocument); } catch (eNodes) {}
      for (var i = 0; i < messageNodes.length; i += 1) {
        var messageText = analyzedNavigationSuccessText(messageNodes[i]);
        if (messageText) return { kind: "message", text: messageText, element: messageNodes[i], modal: null, strategy: "message_selector", rootSource: rootEntry.source };
      }
      var modalNodes = [];
      try { modalNodes = Array.from(rootEntry.root.querySelectorAll(modalSelector)).filter(analyzedNavigationVisibleInOwnerDocument); } catch (eModalNodes) {}
      for (var j = 0; j < modalNodes.length; j += 1) {
        var modalText = analyzedNavigationSuccessText(modalNodes[j]);
        if (modalText) return { kind: "modal", text: modalText, element: modalNodes[j], modal: modalNodes[j], strategy: "modal_selector", rootSource: rootEntry.source };
      }
    }

    // Build63: after an explicit local save, scan every visible element instead of
    // guessing which HTML tag owns the success phrase. This catches legacy widgets
    // whose body text lives in h4/label/strong/custom elements. Search also covers
    // accessible iframes and open shadow roots. The phrase itself must still be an
    // explicit save-success phrase, and navigation remains blocked until verified.
    var textCandidates = [];
    roots.forEach(function (rootEntry) {
      var nodes = [];
      try { nodes = Array.from(rootEntry.root.querySelectorAll("*")); } catch (eAll) {}
      nodes.forEach(function (node) {
        if (!analyzedNavigationVisibleInOwnerDocument(node)) return;
        var text = normalizeText(node.textContent || "");
        if (!text || text.length > 180 || !/(保存成功|保存完成|修改成功|更新成功)/.test(text)) return;
        textCandidates.push({ node: node, text: text, source: rootEntry.source });
      });
    });
    textCandidates.sort(function (a, b) { return a.text.length - b.text.length; });
    for (var k = 0; k < textCandidates.length; k += 1) {
      var current = textCandidates[k].node;
      var depth = 0;
      while (current && depth < 12) {
        if (analyzedNavigationVisibleInOwnerDocument(current)) {
          var currentText = analyzedNavigationSuccessText(current);
          if (currentText) {
            var closeProbe = findAnalyzedNavigationModalCloseControl(current);
            if (closeProbe && closeProbe.element && closeProbe.count === 1) {
              return { kind: "modal", text: currentText, element: current, modal: current, strategy: "all_element_success_ancestor", rootSource: textCandidates[k].source };
            }
          }
        }
        try {
          if (current.parentElement) current = current.parentElement;
          else if (current.getRootNode && current.getRootNode().host) current = current.getRootNode().host;
          else current = null;
        } catch (eParent) { current = null; }
        depth += 1;
      }
    }

    // Build64 second fallback: the success phrase may be a rendered Text node whose
    // immediate parent has no layout box (for example display:contents) or whose
    // legacy dialog ancestor carries stale aria-hidden=true. Range geometry tells us
    // whether the text itself is visibly painted. From that text node we walk upward
    // and choose the smallest ancestor containing one safe close control.
    for (var tr = 0; tr < roots.length; tr += 1) {
      var textNodes = collectAnalyzedNavigationSuccessTextNodes(roots[tr], 24);
      for (var tn = 0; tn < textNodes.length; tn += 1) {
        if (!textNodes[tn].rendered) continue;
        var ancestor = textNodes[tn].node.parentElement || textNodes[tn].node.parentNode || null;
        var ancestorDepth = 0;
        while (ancestor && ancestorDepth < 14) {
          var ancestorText = "";
          try { ancestorText = normalizeText(ancestor.textContent || ""); } catch (eAncestorText) {}
          if (ancestorText && ancestorText.length <= 1200 && /(保存成功|保存完成|修改成功|更新成功)/.test(ancestorText)) {
            var ancestorClose = findAnalyzedNavigationModalCloseControl(ancestor);
            if (ancestorClose && ancestorClose.element && ancestorClose.count === 1) {
              return { kind: "modal", text: textNodes[tn].text, element: ancestor, modal: ancestor, strategy: "rendered_text_node_ancestor", rootSource: textNodes[tn].source };
            }
          }
          try {
            if (ancestor.parentElement) ancestor = ancestor.parentElement;
            else if (ancestor.getRootNode && ancestor.getRootNode().host) ancestor = ancestor.getRootNode().host;
            else ancestor = null;
          } catch (eAncestorParent) { ancestor = null; }
          ancestorDepth += 1;
        }
      }
    }
    return null;
  }

  function collectAnalyzedNavigationSaveFeedbackDiagnostics() {
    var roots = collectAnalyzedNavigationSearchRoots();
    var out = { rootCount: roots.length, rootsWithSuccessText: [], candidates: [], textNodeCandidates: [], elementSuccessTextCount: 0, renderedElementSuccessTextCount: 0 };
    roots.forEach(function (entry) {
      var rootText = "";
      try {
        var carrier = entry.root.body || entry.root.host || entry.root.documentElement || null;
        rootText = normalizeText(carrier && carrier.textContent || "");
      } catch (eRootText) {}
      if (/(保存成功|保存完成|修改成功|更新成功)/.test(rootText)) out.rootsWithSuccessText.push(entry.source);
      var nodes = [];
      try { nodes = Array.from(entry.root.querySelectorAll("*")); } catch (eNodes) {}
      nodes.forEach(function (node) {
        var text = normalizeText(node.textContent || "");
        if (!text || text.length > 180 || !/(保存成功|保存完成|修改成功|更新成功)/.test(text)) return;
        out.elementSuccessTextCount += 1;
        var rendered = analyzedNavigationVisibleInOwnerDocument(node);
        if (rendered) out.renderedElementSuccessTextCount += 1;
        if (out.candidates.length >= 12 || !rendered) return;
        var close = findAnalyzedNavigationModalCloseControl(node);
        out.candidates.push({
          source: entry.source,
          tagName: String(node.tagName || "").toLowerCase(),
          text: text.slice(0, 120),
          closeFound: !!(close && close.element),
          closeCount: Number(close && close.count || 0),
          closeStrategy: String(close && close.strategy || "")
        });
      });
      var textNodes = collectAnalyzedNavigationSuccessTextNodes(entry, 12);
      textNodes.forEach(function (candidate) {
        if (out.textNodeCandidates.length >= 12) return;
        var parent = candidate.node && candidate.node.parentElement;
        out.textNodeCandidates.push({
          source: candidate.source,
          parentTagName: String(parent && parent.tagName || "").toLowerCase(),
          text: String(candidate.text || "").slice(0, 120),
          rendered: !!candidate.rendered,
          parentAriaHidden: String(parent && parent.getAttribute && parent.getAttribute("aria-hidden") || "")
        });
      });
    });
    out.rootsWithSuccessText = out.rootsWithSuccessText.slice(0, 12);
    return out;
  }

  async function closeAnalyzedNavigationSaveSuccessModal(modal, timeoutMs) {
    var result = { found: false, strategy: "", text: "", clickDispatched: false, closed: false };
    var close = findAnalyzedNavigationModalCloseControl(modal);
    result.found = !!close.element;
    result.strategy = close.strategy || "";
    result.text = close.text || "";
    if (!close.element) return result;
    try { result.clickDispatched = !!(await safeClick(close.element)); } catch (eClick) { result.clickDispatched = false; }
    if (!result.clickDispatched) return result;
    var gone = await waitUntil(function () {
      try { return !modal.isConnected || !analyzedNavigationVisibleInOwnerDocument(modal) ? true : null; } catch (eGone) { return true; }
    }, Number(timeoutMs || 1800));
    result.closed = !!gone;
    return result;
  }

  async function runAnalyzedSectionNavigationTransaction(plan) {
    plan = plan || {};
    var from = plan.from || {};
    var target = plan.target || {};
    var trace = {
      fromSection: String(from.text || ""),
      targetSection: String(target.text || ""),
      fromSelector: String(from.selectorHint || ""),
      targetSelector: String(target.selectorHint || ""),
      fromSelectorCount: 0,
      targetSelectorCount: 0,
      fromActiveBefore: false,
      saveButtonFound: false,
      saveButtonText: "",
      saveButtonStrategy: "",
      saveClickDispatched: false,
      saveFeedbackVerified: false,
      saveFeedbackText: "",
      saveFeedbackKind: "",
      saveFeedbackDetectionStrategy: "",
      saveFeedbackWaitMs: 0,
      saveFeedbackProbe: null,
      saveModalDetected: false,
      saveModalCloseFound: false,
      saveModalCloseText: "",
      saveModalCloseStrategy: "",
      saveModalCloseClickDispatched: false,
      saveModalClosed: false,
      newValidationMessages: [],
      targetNavClickDispatched: false,
      targetActiveAfter: false,
      result: "",
      reason: ""
    };

    var fromResolved = analyzedNavigationResolveUnique(from.selectorHint);
    var targetResolved = analyzedNavigationResolveUnique(target.selectorHint);
    trace.fromSelectorCount = Number(fromResolved.count || 0);
    trace.targetSelectorCount = Number(targetResolved.count || 0);
    if (!fromResolved.element || trace.fromSelectorCount !== 1) {
      trace.result = "failed";
      trace.reason = trace.fromSelectorCount > 1 ? "from_selector_not_unique" : "from_selector_not_found";
      return trace;
    }
    if (!targetResolved.element || trace.targetSelectorCount !== 1) {
      trace.result = "failed";
      trace.reason = trace.targetSelectorCount > 1 ? "target_selector_not_unique" : "target_selector_not_found";
      return trace;
    }

    trace.fromActiveBefore = analyzedNavigationNodeIsActive(fromResolved.element);
    if (plan.requireFromActive !== false && !trace.fromActiveBefore) {
      trace.result = "failed";
      trace.reason = "from_section_not_active";
      return trace;
    }

    var validationBefore = collectAnalyzedNavigationValidationMessages();
    var save = findExplicitSectionSaveButton(from.text);
    trace.saveButtonFound = !!save.element;
    trace.saveButtonText = save.text || "";
    trace.saveButtonStrategy = save.strategy || "";
    if (!save.element) {
      trace.result = "failed";
      trace.reason = save.count > 1 ? "save_button_ambiguous" : "save_button_not_found";
      return trace;
    }

    try { trace.saveClickDispatched = !!(await safeClick(save.element)); } catch (eSave) {
      trace.result = "failed";
      trace.reason = "save_click_failed";
      return trace;
    }
    if (!trace.saveClickDispatched) {
      trace.result = "failed";
      trace.reason = "save_click_failed";
      return trace;
    }

    var saveFeedbackStartedAt = Date.now();
    var feedback = await waitUntil(function () {
      var successFeedback = findAnalyzedNavigationSaveSuccessFeedback();
      if (successFeedback) return { successFeedback: successFeedback };
      var afterMessages = collectAnalyzedNavigationValidationMessages();
      var newMessages = afterMessages.filter(function (text) { return validationBefore.indexOf(text) === -1; });
      if (newMessages.length) return { validationMessages: newMessages };
      return null;
    }, Number(plan.saveFeedbackTimeoutMs || 5000));
    trace.saveFeedbackWaitMs = Math.max(0, Date.now() - saveFeedbackStartedAt);

    if (feedback && feedback.successFeedback) {
      trace.saveFeedbackVerified = true;
      trace.saveFeedbackText = feedback.successFeedback.text || "";
      trace.saveFeedbackKind = feedback.successFeedback.kind || "";
      trace.saveFeedbackDetectionStrategy = feedback.successFeedback.strategy || "";
      trace.saveModalDetected = feedback.successFeedback.kind === "modal";
      if (trace.saveModalDetected) {
        var modalClose = await closeAnalyzedNavigationSaveSuccessModal(feedback.successFeedback.modal, Number(plan.saveModalCloseTimeoutMs || 1800));
        trace.saveModalCloseFound = !!modalClose.found;
        trace.saveModalCloseText = modalClose.text || "";
        trace.saveModalCloseStrategy = modalClose.strategy || "";
        trace.saveModalCloseClickDispatched = !!modalClose.clickDispatched;
        trace.saveModalClosed = !!modalClose.closed;
        if (!trace.saveModalCloseFound) {
          trace.result = "failed";
          trace.reason = "save_success_modal_close_not_found";
          return trace;
        }
        if (!trace.saveModalCloseClickDispatched || !trace.saveModalClosed) {
          trace.result = "failed";
          trace.reason = trace.saveModalCloseClickDispatched ? "save_success_modal_not_closed" : "save_success_modal_close_failed";
          return trace;
        }
      }
    }
    if (feedback && Array.isArray(feedback.validationMessages) && feedback.validationMessages.length) {
      trace.newValidationMessages = feedback.validationMessages.slice(0, 20);
      trace.result = "blocked_by_validation";
      trace.reason = "save_validation_failed";
      return trace;
    }
    if (!feedback && plan.requireSaveFeedback === true) {
      trace.saveFeedbackProbe = collectAnalyzedNavigationSaveFeedbackDiagnostics();
      trace.result = "failed";
      trace.reason = "save_feedback_timeout";
      return trace;
    }

    try { trace.targetNavClickDispatched = !!(await safeClick(targetResolved.element)); } catch (eTarget) {
      trace.result = "failed";
      trace.reason = "target_nav_click_failed";
      return trace;
    }
    if (!trace.targetNavClickDispatched) {
      trace.result = "failed";
      trace.reason = "target_nav_click_failed";
      return trace;
    }

    var entered = await waitUntil(function () {
      var currentTarget = analyzedNavigationResolveUnique(target.selectorHint);
      return currentTarget.element && analyzedNavigationNodeIsActive(currentTarget.element) ? currentTarget.element : null;
    }, Number(plan.navigationTimeoutMs || 3500));
    trace.targetActiveAfter = !!entered;
    if (!trace.targetActiveAfter) {
      trace.result = "failed";
      trace.reason = "target_section_not_active_after_click";
      return trace;
    }

    trace.result = trace.saveFeedbackVerified ? "success_verified_save" : "partial_save_unverified_navigation_success";
    trace.reason = trace.saveFeedbackVerified ? "" : "save_click_not_dom_verified";
    return trace;
  }


  function analyzedEditorProbeNormalizeAddText(value) {
    return normalizeText(value).replace(/^[+＋]/, "");
  }

  function analyzedEditorProbeActionLike(node) {
    if (!node || node.nodeType === 9) return false;
    var tag = String(node.tagName || "").toUpperCase();
    if (tag === "BUTTON" || tag === "A") return true;
    var role = String(node.getAttribute && node.getAttribute("role") || "").toLowerCase();
    if (role === "button") return true;
    try { if (node.hasAttribute && node.hasAttribute("onclick")) return true; } catch (eOnclick) {}
    var cls = String(node.className || "");
    if (/(^|[-_\s])(add|btn|button|click)([-_\s]|$)/i.test(cls)) return true;
    try {
      var style = window.getComputedStyle ? window.getComputedStyle(node) : null;
      if (style && style.cursor === "pointer") return true;
    } catch (eStyle) {}
    return false;
  }

  function analyzedEditorProbeNearestAction(node) {
    var current = node;
    for (var depth = 0; current && current !== document.body && depth < 5; depth += 1, current = current.parentElement) {
      if (analyzedEditorProbeActionLike(current)) return current;
    }
    return node || null;
  }

  function analyzedEditorProbeSectionAliases(sectionText) {
    var base = normalizeText(sectionText || "教育背景");
    var aliases = [base];
    if (base.indexOf("其他") !== -1) aliases.push(base.replace(/其他/g, "其它"));
    if (base.indexOf("其它") !== -1) aliases.push(base.replace(/其它/g, "其他"));
    return aliases.filter(function (value, index, all) { return value && all.indexOf(value) === index; });
  }

  function findAnalyzedEducationAddControl(sectionText) {
    var sectionAliases = analyzedEditorProbeSectionAliases(sectionText || "教育背景");
    var wantedList = sectionAliases.map(function (value) { return "添加" + value; });
    var wanted = wantedList[0] || "添加教育背景";
    var nodes = [];
    try { nodes = Array.from(document.querySelectorAll("button, a, [role='button'], [onclick], div, span, li")); } catch (eNodes) {}
    var raw = nodes.filter(function (node) {
      if (!isActuallyVisible(node)) return false;
      var text = analyzedEditorProbeNormalizeAddText(node.textContent || node.getAttribute && (node.getAttribute("aria-label") || node.getAttribute("title")) || "");
      return wantedList.indexOf(text) !== -1;
    });
    var targets = [];
    raw.forEach(function (node) {
      var target = analyzedEditorProbeNearestAction(node);
      if (target && targets.indexOf(target) === -1) targets.push(target);
    });
    targets = targets.filter(function (target) {
      return !targets.some(function (other) { return other !== target && target.contains && target.contains(other); });
    });
    targets.sort(function (a, b) {
      var aStrong = analyzedEditorProbeActionLike(a) ? 0 : 1;
      var bStrong = analyzedEditorProbeActionLike(b) ? 0 : 1;
      if (aStrong !== bStrong) return aStrong - bStrong;
      var at = analyzedEditorProbeNormalizeAddText(a.textContent || "");
      var bt = analyzedEditorProbeNormalizeAddText(b.textContent || "");
      var aExact = wantedList.indexOf(at) !== -1;
      var bExact = wantedList.indexOf(bt) !== -1;
      if (aExact !== bExact) return aExact ? -1 : 1;
      return at.length - bt.length;
    });
    var usedAlias = !!(targets[0] && analyzedEditorProbeNormalizeAddText(targets[0].textContent || "") !== wanted);
    return {
      element: targets.length === 1 ? targets[0] : null,
      count: targets.length,
      text: targets[0] ? normalizeText(targets[0].textContent || "") : "",
      strategy: targets.length === 1 ? (usedAlias ? "section_text_alias" : "exact_add_section_text") : (targets.length > 1 ? "ambiguous_exact_add_section_text" : "not_found")
    };
  }

  function analyzedEditorProbeVisibleControls(root) {
    return enumerateInteractiveControls(root || document).filter(function (entry) {
      if (!entry || !entry.element || !entry.visible) return false;
      var node = entry.element;
      var type = String(node.type || node.getAttribute && node.getAttribute("type") || "").toLowerCase();
      return type !== "hidden" && type !== "file" && !node.disabled;
    }).map(function (entry) { return entry.element; }).filter(function (node, index, all) {
      return all.indexOf(node) === index;
    });
  }

  function analyzedEditorProbeCommonAncestor(nodes) {
    nodes = (nodes || []).filter(Boolean);
    if (!nodes.length) return null;
    var current = nodes[0];
    while (current && current !== document.body && current !== document.documentElement) {
      var containsAll = nodes.every(function (node) { try { return current === node || current.contains(node); } catch (eContains) { return false; } });
      if (containsAll) return current;
      current = current.parentElement;
    }
    return current || document.body || null;
  }

  function analyzedEditorProbeAttrSelector(tag, attr, value) {
    value = String(value || "");
    if (!value || value.length > 120) return "";
    var escaped = value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    return String(tag || "").toLowerCase() + "[" + attr + "=\"" + escaped + "\"]";
  }

  function analyzedEditorProbeSelectorHint(node) {
    if (!node || !node.tagName) return "";
    var tag = String(node.tagName || "").toLowerCase();
    var id = String(node.id || "");
    if (id && id.length <= 120) {
      var idSel = analyzedEditorProbeAttrSelector("", "id", id).replace(/^\[?/, "[");
      idSel = "[id=\"" + id.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + "\"]";
      try { if (document.querySelectorAll(idSel).length === 1) return idSel; } catch (eId) {}
    }
    var name = String(node.getAttribute && node.getAttribute("name") || "");
    var nameSel = analyzedEditorProbeAttrSelector(tag, "name", name);
    if (nameSel) {
      try { if (document.querySelectorAll(nameSel).length === 1) return nameSel; } catch (eName) {}
    }
    var placeholder = String(node.getAttribute && node.getAttribute("placeholder") || "");
    var placeholderSel = analyzedEditorProbeAttrSelector(tag, "placeholder", placeholder);
    if (placeholderSel) {
      try { if (document.querySelectorAll(placeholderSel).length === 1) return placeholderSel; } catch (ePlaceholder) {}
    }
    return "";
  }

  function analyzedEditorProbeLabel(node) {
    if (!node) return "";
    var aria = normalizeText(node.getAttribute && node.getAttribute("aria-label") || "");
    if (aria) return aria.slice(0, 120);
    var id = String(node.id || "");
    if (id) {
      try {
        var labels = Array.from(document.querySelectorAll("label"));
        var explicit = labels.find(function (label) { return String(label.getAttribute("for") || "") === id && isActuallyVisible(label); });
        if (explicit) return normalizeText(explicit.textContent || "").slice(0, 120);
      } catch (eLabelFor) {}
    }
    try {
      var group = node.closest && node.closest(".form-group, .form-item, .el-form-item, .control-group, li, tr, td, [role='group']");
      if (group) {
        var label = group.querySelector && group.querySelector("label, .label, [class*='label' i], th");
        var groupLabel = normalizeText(label && label.textContent || "");
        if (groupLabel) return groupLabel.slice(0, 120);
      }
    } catch (eGroup) {}
    var placeholder = normalizeText(node.getAttribute && node.getAttribute("placeholder") || "");
    return placeholder.slice(0, 120);
  }

  function analyzedEditorProbeSanitizeControl(node) {
    var tag = String(node && node.tagName || "").toLowerCase();
    var inputType = String(node && (node.type || node.getAttribute && node.getAttribute("type")) || "").toLowerCase();
    var options = [];
    if (tag === "select") {
      try { options = Array.from(node.options || []).map(function (option) { return normalizeText(option.textContent || "").slice(0, 100); }).filter(Boolean).slice(0, 40); } catch (eOptions) {}
    }
    return {
      tagName: tag,
      inputType: inputType,
      name: String(node && node.getAttribute && node.getAttribute("name") || "").slice(0, 120),
      id: String(node && node.id || "").slice(0, 120),
      placeholder: String(node && node.getAttribute && node.getAttribute("placeholder") || "").slice(0, 160),
      label: analyzedEditorProbeLabel(node),
      required: !!(node && (node.required || node.getAttribute && node.getAttribute("aria-required") === "true")),
      readOnly: !!(node && node.readOnly),
      role: String(node && node.getAttribute && node.getAttribute("role") || "").slice(0, 80),
      selectorHint: analyzedEditorProbeSelectorHint(node),
      options: options
    };
  }

  function findAnalyzedEditorSafeCloseControl(scope) {
    if (!scope) return { element: null, count: 0, text: "", strategy: "", scope: null, scopeDepth: -1 };
    var aliases = ["取消", "关闭", "返回", "收起"];
    var cursor = scope;
    var depth = 0;
    var lastAmbiguous = null;
    // The controls' smallest common ancestor is often only the fields grid.
    // Action buttons may live one or two wrappers higher. Expand locally instead
    // of searching the whole document, and take the nearest scope containing one
    // unambiguous safe-close action.
    while (cursor && depth <= 6) {
      var nodes = [];
      try { nodes = Array.from(cursor.querySelectorAll("button, a, [role='button'], input[type='button']")); } catch (eNodes) {}
      var matches = nodes.filter(function (node) {
        if (!isActuallyVisible(node)) return false;
        var text = normalizeText(node.textContent || node.value || node.getAttribute && (node.getAttribute("aria-label") || node.getAttribute("title")) || "");
        return aliases.indexOf(text) !== -1;
      });
      matches.sort(function (a, b) {
        var at = normalizeText(a.textContent || a.value || "");
        var bt = normalizeText(b.textContent || b.value || "");
        return aliases.indexOf(at) - aliases.indexOf(bt);
      });
      if (matches.length === 1) {
        return {
          element: matches[0],
          count: 1,
          text: normalizeText(matches[0].textContent || matches[0].value || ""),
          strategy: depth === 0 ? "explicit_cancel_close" : "expanded_scope_cancel_close",
          scope: cursor,
          scopeDepth: depth
        };
      }
      if (matches.length > 1 && !lastAmbiguous) {
        lastAmbiguous = {
          element: null, count: matches.length,
          text: normalizeText(matches[0].textContent || matches[0].value || ""),
          strategy: "ambiguous_cancel_close", scope: cursor, scopeDepth: depth
        };
      }
      if (cursor === document.body || cursor === document.documentElement) break;
      cursor = cursor.parentElement;
      depth += 1;
    }
    return lastAmbiguous || { element: null, count: 0, text: "", strategy: "not_found", scope: null, scopeDepth: -1 };
  }

  function analyzedEditorActionTexts(scope) {
    var actions = [];
    try { actions = Array.from((scope || document).querySelectorAll("button, a, [role='button'], input[type='button'], input[type='submit']")); } catch (eActions) {}
    return actions.filter(isActuallyVisible).map(function (node) {
      return normalizeText(node.textContent || node.value || node.getAttribute && (node.getAttribute("aria-label") || node.getAttribute("title")) || "").slice(0, 100);
    }).filter(Boolean).filter(function (text, index, all) { return all.indexOf(text) === index; }).slice(0, 30);
  }

  async function runAnalyzedSectionAddEditorProbe(plan) {
    plan = plan || {};
    var section = plan.section || {};
    var trace = {
      section: String(section.text || ""),
      sectionSelector: String(section.selectorHint || ""),
      sectionSelectorCount: 0,
      sectionActiveBefore: false,
      addButtonFound: false,
      addButtonCount: 0,
      addButtonText: "",
      addButtonStrategy: "",
      addClickDispatched: false,
      baselineVisibleControlCount: 0,
      editorOpened: false,
      editorOpenWaitMs: 0,
      newVisibleControlCount: 0,
      editorScopeTagName: "",
      editorScopeClassName: "",
      fields: [],
      actionTexts: [],
      safeCloseFound: false,
      safeCloseCount: 0,
      safeCloseText: "",
      safeCloseStrategy: "",
      safeCloseScopeDepth: -1,
      actionScopeTagName: "",
      actionScopeClassName: "",
      safeCloseClickDispatched: false,
      editorClosed: false,
      leftOpen: false,
      result: "",
      reason: "",
      safety: { valuesCaptured: false, fieldsWritten: false, saveExecuted: false, finalSubmitExecuted: false }
    };
    var resolved = analyzedNavigationResolveUnique(section.selectorHint);
    trace.sectionSelectorCount = Number(resolved.count || 0);
    if (!resolved.element || trace.sectionSelectorCount !== 1) {
      trace.result = "failed";
      trace.reason = trace.sectionSelectorCount > 1 ? "section_selector_not_unique" : "section_selector_not_found";
      return trace;
    }
    trace.sectionActiveBefore = analyzedNavigationNodeIsActive(resolved.element);
    if (plan.requireSectionActive !== false && !trace.sectionActiveBefore) {
      trace.result = "failed";
      trace.reason = "section_not_active";
      return trace;
    }

    var beforeControls = analyzedEditorProbeVisibleControls(document);
    trace.baselineVisibleControlCount = beforeControls.length;
    var add = findAnalyzedEducationAddControl(section.text);
    trace.addButtonFound = !!add.element;
    trace.addButtonCount = Number(add.count || 0);
    trace.addButtonText = add.text || "";
    trace.addButtonStrategy = add.strategy || "";
    if (!add.element) {
      trace.result = "failed";
      trace.reason = trace.addButtonCount > 1 ? "section_add_ambiguous" : "section_add_not_found";
      return trace;
    }
    try { trace.addClickDispatched = !!(await safeClick(add.element)); } catch (eAdd) { trace.addClickDispatched = false; }
    if (!trace.addClickDispatched) {
      trace.result = "failed";
      trace.reason = "section_add_click_failed";
      return trace;
    }

    var openedAt = Date.now();
    var opened = await waitUntil(function () {
      var nowControls = analyzedEditorProbeVisibleControls(document);
      var newControls = nowControls.filter(function (node) { return beforeControls.indexOf(node) === -1; });
      return newControls.length ? { all: nowControls, newlyVisible: newControls } : null;
    }, Number(plan.editorOpenTimeoutMs || 4000));
    trace.editorOpenWaitMs = Math.max(0, Date.now() - openedAt);
    if (!opened || !opened.newlyVisible || !opened.newlyVisible.length) {
      trace.result = "failed";
      trace.reason = "section_editor_not_opened";
      return trace;
    }
    trace.editorOpened = true;
    trace.newVisibleControlCount = opened.newlyVisible.length;
    var scope = analyzedEditorProbeCommonAncestor(opened.newlyVisible) || document.body;
    trace.editorScopeTagName = String(scope && scope.tagName || "").toLowerCase();
    trace.editorScopeClassName = String(scope && scope.className || "").replace(/\s+/g, " ").trim().slice(0, 180);
    trace.fields = opened.newlyVisible.slice(0, 100).map(analyzedEditorProbeSanitizeControl);

    var close = findAnalyzedEditorSafeCloseControl(scope);
    var actionScope = close.scope || scope;
    trace.actionScopeTagName = String(actionScope && actionScope.tagName || "").toLowerCase();
    trace.actionScopeClassName = String(actionScope && actionScope.className || "").replace(/\s+/g, " ").trim().slice(0, 180);
    trace.actionTexts = analyzedEditorActionTexts(actionScope);
    trace.safeCloseFound = !!close.element;
    trace.safeCloseCount = Number(close.count || 0);
    trace.safeCloseText = close.text || "";
    trace.safeCloseStrategy = close.strategy || "";
    trace.safeCloseScopeDepth = Number.isFinite(Number(close.scopeDepth)) ? Number(close.scopeDepth) : -1;
    if (!close.element) {
      trace.leftOpen = true;
      trace.result = "probe_complete_left_open";
      trace.reason = close.count > 1 ? "safe_close_ambiguous" : "safe_close_not_found";
      return trace;
    }
    try { trace.safeCloseClickDispatched = !!(await safeClick(close.element)); } catch (eClose) { trace.safeCloseClickDispatched = false; }
    if (!trace.safeCloseClickDispatched) {
      trace.leftOpen = true;
      trace.result = "probe_complete_left_open";
      trace.reason = "safe_close_click_failed";
      return trace;
    }
    var closed = await waitUntil(function () {
      var remaining = opened.newlyVisible.filter(function (node) { return node && node.isConnected !== false && isActuallyVisible(node); });
      return remaining.length === 0 ? true : null;
    }, Number(plan.editorCloseTimeoutMs || 2500));
    trace.editorClosed = !!closed;
    trace.leftOpen = !trace.editorClosed;
    trace.result = trace.editorClosed ? "probe_complete_closed" : "probe_complete_left_open";
    trace.reason = trace.editorClosed ? "" : "safe_close_not_confirmed";
    return trace;
  }

  async function runAnalyzedEducationAddEditorProbe(plan) {
    plan = plan || {};
    var section = plan.section || {};
    if (normalizeText(section.text) !== "教育背景") {
      return {
        section: String(section.text || ""),
        result: "failed",
        reason: "education_section_required",
        safety: { valuesCaptured: false, fieldsWritten: false, saveExecuted: false, finalSubmitExecuted: false }
      };
    }
    var result = await runAnalyzedSectionAddEditorProbe(plan);
    if (result && result.reason === "section_not_active") result.reason = "education_section_not_active";
    return result;
  }

  async function runAnalyzedResumeSectionEditorSurvey(plan) {
    plan = plan || {};
    var sections = Array.isArray(plan.sections) ? plan.sections : [];
    var trace = {
      requestedSectionCount: sections.length,
      completedSectionCount: 0,
      failedSectionCount: 0,
      preflightOpenControlCount: 0,
      preflightRecoveryAttempted: false,
      preflightRecoverySucceeded: false,
      preflightRecoveryStrategy: "",
      sections: [],
      result: "",
      reason: "",
      safety: { valuesCaptured: false, fieldsWritten: false, saveExecuted: false, finalSubmitExecuted: false }
    };
    // A previous probe may have intentionally stopped with an editor open. Before
    // navigating away, recover only through an explicit local safe-close control.
    var preflightControls = analyzedEditorProbeVisibleControls(document);
    trace.preflightOpenControlCount = preflightControls.length;
    if (preflightControls.length) {
      var preflightScope = analyzedEditorProbeCommonAncestor(preflightControls) || document.body;
      var preflightClose = findAnalyzedEditorSafeCloseControl(preflightScope);
      trace.preflightRecoveryAttempted = true;
      trace.preflightRecoveryStrategy = preflightClose.strategy || "";
      if (!preflightClose.element) {
        trace.result = "blocked_open_editor";
        trace.reason = preflightClose.count > 1 ? "preflight_safe_close_ambiguous" : "preflight_safe_close_not_found";
        return trace;
      }
      var preflightClicked = false;
      try { preflightClicked = !!(await safeClick(preflightClose.element)); } catch (ePreflightClose) { preflightClicked = false; }
      if (!preflightClicked) {
        trace.result = "blocked_open_editor";
        trace.reason = "preflight_safe_close_click_failed";
        return trace;
      }
      var preflightClosed = await waitUntil(function () {
        return analyzedEditorProbeVisibleControls(document).length === 0 ? true : null;
      }, Number(plan.editorCloseTimeoutMs || 2500));
      trace.preflightRecoverySucceeded = !!preflightClosed;
      if (!preflightClosed) {
        trace.result = "blocked_open_editor";
        trace.reason = "preflight_safe_close_not_confirmed";
        return trace;
      }
    }
    for (var index = 0; index < sections.length; index += 1) {
      var section = sections[index] || {};
      var item = {
        section: String(section.text || ""),
        navigationSelector: String(section.selectorHint || ""),
        navigationSelectorCount: 0,
        navigationActiveBefore: false,
        navigationClickDispatched: false,
        navigationActiveAfter: false,
        probe: null
      };
      var resolved = analyzedNavigationResolveUnique(section.selectorHint);
      item.navigationSelectorCount = Number(resolved.count || 0);
      if (!resolved.element || item.navigationSelectorCount !== 1) {
        item.probe = { result: "failed", reason: item.navigationSelectorCount > 1 ? "section_selector_not_unique" : "section_selector_not_found" };
        trace.sections.push(item);
        trace.failedSectionCount += 1;
        continue;
      }
      item.navigationActiveBefore = analyzedNavigationNodeIsActive(resolved.element);
      if (!item.navigationActiveBefore) {
        try { item.navigationClickDispatched = !!(await safeClick(resolved.element)); } catch (eNav) { item.navigationClickDispatched = false; }
        if (!item.navigationClickDispatched) {
          item.probe = { result: "failed", reason: "section_navigation_click_failed" };
          trace.sections.push(item);
          trace.failedSectionCount += 1;
          continue;
        }
        var activated = await waitUntil(function () {
          var latest = analyzedNavigationResolveUnique(section.selectorHint);
          return latest.element && analyzedNavigationNodeIsActive(latest.element) ? true : null;
        }, Number(plan.navigationTimeoutMs || 3000));
        item.navigationActiveAfter = !!activated;
      } else {
        item.navigationActiveAfter = true;
      }
      if (!item.navigationActiveAfter) {
        item.probe = { result: "failed", reason: "section_navigation_not_active" };
        trace.sections.push(item);
        trace.failedSectionCount += 1;
        continue;
      }
      item.probe = await runAnalyzedSectionAddEditorProbe({
        section: section,
        requireSectionActive: true,
        editorOpenTimeoutMs: Number(plan.editorOpenTimeoutMs || 4500),
        editorCloseTimeoutMs: Number(plan.editorCloseTimeoutMs || 2500)
      });
      trace.sections.push(item);
      if (item.probe && item.probe.result === "probe_complete_closed") {
        trace.completedSectionCount += 1;
        continue;
      }
      trace.failedSectionCount += 1;
      // An editor left open can block later navigation or make subsequent probes unsafe.
      if (item.probe && item.probe.leftOpen) {
        trace.result = "partial_stopped_open_editor";
        trace.reason = item.probe.reason || "section_probe_left_open";
        return trace;
      }
    }
    trace.result = trace.failedSectionCount ? "complete_with_gaps" : "complete";
    trace.reason = trace.failedSectionCount ? "some_sections_not_probeable" : "";
    return trace;
  }

  function analyzedBatchPreviewNormalizeProvince(value) {
    var text = normalizeText(value || "").replace(/\s+/g, "");
    if (!text) return "";
    var municipalities = ["北京", "上海", "天津", "重庆"];
    for (var m = 0; m < municipalities.length; m += 1) {
      if (text.indexOf(municipalities[m]) !== -1) return municipalities[m] + "市";
    }
    var explicit = text.match(/(内蒙古自治区|广西壮族自治区|西藏自治区|宁夏回族自治区|新疆维吾尔自治区|香港特别行政区|澳门特别行政区|[^省]{2,8}省)/);
    if (explicit) return explicit[1];
    var provinceNames = ["河北", "山西", "辽宁", "吉林", "黑龙江", "江苏", "浙江", "安徽", "福建", "江西", "山东", "河南", "湖北", "湖南", "广东", "海南", "四川", "贵州", "云南", "陕西", "甘肃", "青海", "台湾"];
    for (var i = 0; i < provinceNames.length; i += 1) {
      if (text.indexOf(provinceNames[i]) !== -1) return provinceNames[i] + "省";
    }
    var autonomous = { "内蒙古": "内蒙古自治区", "广西": "广西壮族自治区", "西藏": "西藏自治区", "宁夏": "宁夏回族自治区", "新疆": "新疆维吾尔自治区", "香港": "香港特别行政区", "澳门": "澳门特别行政区" };
    var keys = Object.keys(autonomous);
    for (var k = 0; k < keys.length; k += 1) if (text.indexOf(keys[k]) !== -1) return autonomous[keys[k]];
    return "";
  }

  function analyzedBatchPreviewNormalizeCity(value) {
    var text = normalizeText(value || "").replace(/\s+/g, "");
    if (!text) return "";
    var municipalities = ["北京", "上海", "天津", "重庆"];
    for (var m = 0; m < municipalities.length; m += 1) if (text.indexOf(municipalities[m]) !== -1) return municipalities[m] + "市";
    var explicit = text.match(/([\u4e00-\u9fa5]{2,8}市)/);
    if (explicit) return explicit[1];
    var cleaned = text.replace(/^远程[（(]?/, "").replace(/[）)]$/, "");
    if (/^[\u4e00-\u9fa5]{2,6}$/.test(cleaned) && !/省|自治区|特别行政区/.test(cleaned)) return cleaned + "市";
    return "";
  }

  function analyzedBatchPreviewNormalizeRelation(value) {
    var text = normalizeText(value || "");
    if (/父/.test(text)) return "父";
    if (/母/.test(text)) return "母";
    if (/夫|丈夫/.test(text)) return "夫";
    if (/妻|妻子/.test(text)) return "妻";
    if (/子/.test(text)) return "子";
    if (/女/.test(text)) return "女";
    return text;
  }

  function analyzedBatchPreviewNormalizeAwardLevel(value) {
    var text = normalizeText(value || "");
    if (/国际/.test(text)) return "国际级";
    if (/国家/.test(text)) return "国家级";
    if (/省|部/.test(text)) return "省部级";
    if (/市/.test(text)) return "市级";
    if (/校/.test(text)) return "校级";
    if (/院/.test(text)) return "院级";
    if (/系/.test(text)) return "系级";
    return text ? "其它" : "";
  }

  function analyzedBatchPreviewAwardNameAliases(value) {
    var text = normalizeText(value || "");
    var aliases = [];
    if (text) aliases.push(text);
    if (/奖学金/.test(text)) aliases.push("其他奖学金");
    else if (text) aliases.push("其他奖项");
    return aliases;
  }

  function analyzedBatchPreviewBuildLanguageRecords(profile) {
    var rows = Array.isArray(profile && profile.languageSkills) ? profile.languageSkills : [];
    var out = [];
    rows.forEach(function (row, sourceIndex) {
      row = row || {};
      var language = normalizeText(row.name || "英语") || "英语";
      var firstLanguage = language === "英语" ? "是" : "";
      if (normalizeText(row.cet4Score || "")) out.push({ sourceIndex: sourceIndex, language: language, levelAliases: ["大学英语四级", "英语四级", "CET4", "四级"], grade: row.cet4Score, firstLanguage: firstLanguage, kind: "cet4" });
      if (normalizeText(row.cet6Score || "")) out.push({ sourceIndex: sourceIndex, language: language, levelAliases: ["大学英语六级", "英语六级", "CET6", "六级"], grade: row.cet6Score, firstLanguage: firstLanguage, kind: "cet6" });
      var otherExam = normalizeText(row.otherEnglishExam || row.certificateName || row.certificate || "");
      var otherScore = row.otherEnglishScore || row.ieltsScore || ((/IELTS|雅思/i.test(otherExam)) ? row.score : "");
      if (otherExam && normalizeText(otherScore || "")) {
        var aliases = /IELTS|雅思/i.test(otherExam) ? ["IELTS", "雅思"] : [otherExam];
        out.push({ sourceIndex: sourceIndex, language: language, levelAliases: aliases, grade: otherScore, firstLanguage: firstLanguage, kind: "other_exam" });
      }
      if (!out.some(function (entry) { return entry.sourceIndex === sourceIndex; })) {
        out.push({ sourceIndex: sourceIndex, language: language, levelAliases: [row.englishLevel, row.proficiency, row.certificateName].filter(Boolean), grade: row.score || "", firstLanguage: firstLanguage, kind: "generic" });
      }
    });
    return out;
  }

  function analyzedBatchSelectLanguageRecords(profile, plan) {
    plan = plan || {};
    var rows = analyzedBatchPreviewBuildLanguageRecords(profile);
    var preferred = Array.isArray(plan.preferredLanguageExamAliases) ? plan.preferredLanguageExamAliases.filter(Boolean) : [];
    var policy = normalizeText(plan.languageRecordSelectionPolicy || "");
    if (preferred.length) {
      var preferredKeys = preferred.map(function (value) { return normalizeChoiceText(value).toLowerCase(); }).filter(Boolean);
      var matched = rows.filter(function (row) {
        var aliases = Array.isArray(row && row.levelAliases) ? row.levelAliases : [];
        return aliases.some(function (alias) {
          var key = normalizeChoiceText(alias).toLowerCase();
          return preferredKeys.some(function (wanted) { return key === wanted || (key && wanted && (key.indexOf(wanted) !== -1 || wanted.indexOf(key) !== -1)); });
        });
      });
      if (matched.length || policy === "preferred_only") rows = matched;
    }
    var limit = Number(plan.languageRecordLimit || 0);
    if (Number.isFinite(limit) && limit > 0) rows = rows.slice(0, limit);
    return rows;
  }

  function analyzedBatchPreviewCaptureControls(controls) {
    return (controls || []).map(function (control) {
      return {
        control: control,
        value: String(control && control.value != null ? control.value : ""),
        checked: !!(control && control.checked),
        selectedIndex: Number(control && control.selectedIndex)
      };
    });
  }

  function analyzedBatchPreviewRestoreControls(snapshots) {
    var ok = true;
    (snapshots || []).slice().reverse().forEach(function (item) {
      var control = item && item.control;
      if (!control || control.isConnected === false) return;
      try {
        var tag = String(control.tagName || "").toLowerCase();
        var type = String(control.type || "").toLowerCase();
        if (type === "radio" || type === "checkbox") {
          control.checked = !!item.checked;
          control.dispatchEvent(new Event("input", { bubbles: true }));
          control.dispatchEvent(new Event("change", { bubbles: true }));
          return;
        }
        if (tag === "select") {
          var setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value");
          if (setter && setter.set) setter.set.call(control, item.value); else control.value = item.value;
          control.dispatchEvent(new Event("input", { bubbles: true }));
          control.dispatchEvent(new Event("change", { bubbles: true }));
          return;
        }
        var proto = tag === "textarea" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        var valueSetter = Object.getOwnPropertyDescriptor(proto, "value");
        if (valueSetter && valueSetter.set) valueSetter.set.call(control, item.value); else control.value = item.value;
        control.dispatchEvent(new Event("input", { bubbles: true }));
        control.dispatchEvent(new Event("change", { bubbles: true }));
      } catch (eRestore) { ok = false; }
    });
    return ok;
  }

  function analyzedBatchPreviewSelectAlias(control, aliases) {
    aliases = (Array.isArray(aliases) ? aliases : [aliases]).map(function (x) { return normalizeChoiceText(x || ""); }).filter(Boolean);
    if (!control || !aliases.length) return "";
    var options = [];
    try { options = Array.from(control.options || []); } catch (e) { options = []; }
    for (var a = 0; a < aliases.length; a += 1) {
      var wanted = normalizeChoiceText(aliases[a]).toLowerCase();
      var exact = options.find(function (option) {
        var text = normalizeChoiceText(option.textContent || option.label || option.value || "").toLowerCase();
        return text === wanted;
      });
      if (exact) return normalizeText(exact.textContent || exact.label || exact.value || "");
    }
    for (var b = 0; b < aliases.length; b += 1) {
      var needle = normalizeChoiceText(aliases[b]).toLowerCase();
      var fuzzy = options.find(function (option) {
        var text = normalizeChoiceText(option.textContent || option.label || option.value || "").toLowerCase();
        return text && needle && (text.indexOf(needle) !== -1 || needle.indexOf(text) !== -1);
      });
      if (fuzzy) return normalizeText(fuzzy.textContent || fuzzy.label || fuzzy.value || "");
    }
    return "";
  }

  async function analyzedBatchPreviewFillSpec(scope, spec) {
    spec = Object.assign({}, spec || {});
    if (spec.kind === "select" && Array.isArray(spec.aliases)) {
      var lookup = analyzedEducationPreviewField(scope, spec.id, spec.name);
      if (lookup.element && spec.waitForOptions) {
        await waitUntil(function () { try { return lookup.element.options && lookup.element.options.length > 1 ? true : null; } catch (e) { return null; } }, Number(spec.waitForOptions || 1800));
      }
      var resolved = analyzedBatchPreviewSelectAlias(lookup.element, spec.aliases);
      if (!resolved) {
        return { fieldKey: spec.fieldKey, controlId: spec.id || "", controlName: spec.name || "", controlCount: lookup.count, writer: "select", attempted: false, committed: false, readbackMatch: false, reason: spec.aliases.length ? "select_option_not_found" : "profile_value_missing" };
      }
      spec.value = resolved;
      delete spec.aliases;
    }
    return analyzedEducationPreviewFillOne(scope, spec);
  }

  async function analyzedBatchPreviewNavigate(section, timeoutMs) {
    var resolved = analyzedNavigationResolveUnique(section && section.selectorHint);
    if (!resolved.element || resolved.count !== 1) return { ok: false, reason: resolved.count > 1 ? "section_selector_not_unique" : "section_selector_not_found" };
    if (analyzedNavigationNodeIsActive(resolved.element)) return { ok: true, clicked: false };
    var clicked = false;
    try { clicked = !!(await safeClick(resolved.element)); } catch (eClick) { clicked = false; }
    if (!clicked) return { ok: false, reason: "section_navigation_click_failed" };
    var active = await waitUntil(function () {
      var latest = analyzedNavigationResolveUnique(section.selectorHint);
      return latest.element && analyzedNavigationNodeIsActive(latest.element) ? true : null;
    }, Number(timeoutMs || 3000));
    return { ok: !!active, clicked: true, reason: active ? "" : "section_navigation_not_active" };
  }

  async function analyzedBatchPreviewOpenEditor(section, timeoutMs) {
    var before = analyzedEditorProbeVisibleControls(document);
    var add = findAnalyzedEducationAddControl(section.text);
    if (!add.element) return { ok: false, reason: add.count > 1 ? "section_add_ambiguous" : "section_add_not_found", add: add };
    var clicked = false;
    try { clicked = !!(await safeClick(add.element)); } catch (eClick) { clicked = false; }
    if (!clicked) return { ok: false, reason: "section_add_click_failed", add: add };
    var opened = await waitUntil(function () {
      var now = analyzedEditorProbeVisibleControls(document);
      var fresh = now.filter(function (node) { return before.indexOf(node) === -1; });
      return fresh.length ? { controls: fresh } : null;
    }, Number(timeoutMs || 4500));
    if (!opened || !opened.controls || !opened.controls.length) return { ok: false, reason: "section_editor_not_opened", add: add };
    var scope = analyzedEditorProbeCommonAncestor(opened.controls) || document.body;
    return { ok: true, add: add, controls: opened.controls, scope: scope, snapshots: analyzedBatchPreviewCaptureControls(opened.controls) };
  }

  async function analyzedBatchPreviewRestoreAndClose(opened, closeTimeoutMs) {
    var result = { restored: false, closeFound: false, closeClicked: false, closed: false, closeStrategy: "", closeScopeDepth: -1 };
    if (!opened || !opened.ok) return result;
    result.restored = analyzedBatchPreviewRestoreControls(opened.snapshots);
    await sleep(80);
    var close = findAnalyzedEditorSafeCloseControl(opened.scope);
    result.closeFound = !!close.element;
    result.closeStrategy = close.strategy || "";
    result.closeScopeDepth = Number.isFinite(Number(close.scopeDepth)) ? Number(close.scopeDepth) : -1;
    if (!close.element) return result;
    try { result.closeClicked = !!(await safeClick(close.element)); } catch (eClick) { result.closeClicked = false; }
    if (!result.closeClicked) return result;
    var closed = await waitUntil(function () {
      var remaining = (opened.controls || []).filter(function (node) { return node && node.isConnected !== false && isActuallyVisible(node); });
      return remaining.length === 0 ? true : null;
    }, Number(closeTimeoutMs || 2500));
    result.closed = !!closed;
    return result;
  }

  async function analyzedBatchPreviewOneRecord(section, specs, meta, plan) {
    var trace = {
      recordKind: String(meta && meta.kind || "record"),
      profileRecordIndex: Number.isInteger(meta && meta.profileRecordIndex) ? meta.profileRecordIndex : 0,
      editorOpened: false,
      fieldTrace: [],
      attemptedFieldCount: 0,
      committedFieldCount: 0,
      failedFieldCount: 0,
      skippedFieldCount: 0,
      restored: false,
      editorClosed: false,
      result: "",
      reason: "",
      safety: { valuesCaptured: false, fieldsWritten: false, saveExecuted: false, finalSubmitExecuted: false }
    };
    var opened = await analyzedBatchPreviewOpenEditor(section, Number(plan.editorOpenTimeoutMs || 4500));
    trace.editorOpened = !!opened.ok;
    if (!opened.ok) { trace.result = "failed"; trace.reason = opened.reason || "editor_open_failed"; return trace; }
    for (var i = 0; i < specs.length; i += 1) trace.fieldTrace.push(await analyzedBatchPreviewFillSpec(opened.scope, specs[i]));
    trace.attemptedFieldCount = trace.fieldTrace.filter(function (item) { return item && item.attempted; }).length;
    trace.committedFieldCount = trace.fieldTrace.filter(function (item) { return item && item.committed; }).length;
    trace.failedFieldCount = trace.fieldTrace.filter(function (item) { return item && item.attempted && !item.committed; }).length;
    trace.skippedFieldCount = trace.fieldTrace.filter(function (item) { return item && !item.attempted; }).length;
    trace.safety.fieldsWritten = trace.attemptedFieldCount > 0;
    var cleanup = await analyzedBatchPreviewRestoreAndClose(opened, Number(plan.editorCloseTimeoutMs || 2500));
    trace.restored = !!cleanup.restored;
    trace.editorClosed = !!cleanup.closed;
    if (!cleanup.closed) {
      trace.result = "left_open";
      trace.reason = !cleanup.closeFound ? "safe_close_not_found" : (!cleanup.closeClicked ? "safe_close_click_failed" : "safe_close_not_confirmed");
      return trace;
    }
    trace.result = trace.failedFieldCount ? "preview_with_field_gaps" : "preview_complete";
    trace.reason = trace.failedFieldCount ? "some_fields_failed_readback" : "";
    return trace;
  }

  async function runAnalyzedResumeSectionPreviewBatch(plan) {
    plan = plan || {};
    var sections = Array.isArray(plan.sections) ? plan.sections : [];
    var profile = plan.profile || {};
    var byName = {};
    sections.forEach(function (section) { byName[normalizeText(section && section.text || "")] = section; });
    var trace = {
      requestedSectionCount: sections.length,
      sections: [],
      result: "",
      reason: "",
      safety: { valuesCaptured: false, fieldsWritten: false, saveExecuted: false, finalSubmitExecuted: false }
    };

    var jobs = [];
    var languageRows = analyzedBatchSelectLanguageRecords(profile, plan);
    languageRows.forEach(function (row, index) {
      jobs.push({ sectionName: "外语水平", kind: row.kind || "language", profileRecordIndex: index, specs: [
        { fieldKey: "language", id: "language", name: "language", kind: "select", value: row.language },
        { fieldKey: "languageLevel", id: "languageLevel", name: "languageLevel", kind: "select", aliases: row.levelAliases || [], waitForOptions: Number(plan.dynamicOptionTimeoutMs || 1800) },
        { fieldKey: "firstLanguage", id: "", name: "firstLanguage", kind: "radio", value: row.firstLanguage },
        { fieldKey: "englishGrade", id: "englishGrade", name: "englishGrade", kind: "text", value: row.grade }
      ] });
    });

    var basic = profile.basicInfo || {};
    jobs.push({ sectionName: "通讯信息", kind: "communication", profileRecordIndex: 0, specs: [
      { fieldKey: "country", id: "regions", name: "regions", kind: "select", value: basic.country || "中国" },
      { fieldKey: "currentProvince", id: "city", name: "city", kind: "select", value: analyzedBatchPreviewNormalizeProvince(basic.currentAddress || basic.currentResidence || basic.currentAddressDetail) },
      { fieldKey: "currentAddressDetail", id: "specificAddress", name: "specificAddress", kind: "text", value: basic.currentAddressDetail },
      { fieldKey: "phone", id: "phoneNumber", name: "phoneNumber", kind: "text", value: basic.phone },
      { fieldKey: "qq", id: "qqid", name: "qqid", kind: "text", value: basic.qq },
      { fieldKey: "mailingProvince", id: "jt", name: "province", kind: "select", value: analyzedBatchPreviewNormalizeProvince(basic.communicationAddress || basic.mailingAddress || basic.hukouLocation) },
      { fieldKey: "communicationAddress", id: "distrctName", name: "distrctName", kind: "text", value: basic.communicationAddress || basic.mailingAddress },
      { fieldKey: "postalCode", id: "postCode", name: "postCode", kind: "text", value: basic.postalCode },
      { fieldKey: "email", id: "email", name: "email", kind: "text", value: basic.email },
      { fieldKey: "wechat", id: "wechatid", name: "wechatid", kind: "text", value: basic.wechat }
    ] });

    var internships = Array.isArray(profile.internshipExperience) ? profile.internshipExperience : [];
    if (internships.length) {
      var job = internships[0] || {};
      var workText = normalizeText(job.workLocation || "");
      jobs.push({ sectionName: "实习/工作/入伍经历", kind: "internship", profileRecordIndex: 0, specs: [
        { fieldKey: "country", id: "jobCountry", name: "country", kind: "select", value: "中国" },
        { fieldKey: "province", id: "gt", name: "province", kind: "select", value: analyzedBatchPreviewNormalizeProvince(workText) },
        { fieldKey: "city", id: "jobcity", name: "jobcity", kind: "select", aliases: [analyzedBatchPreviewNormalizeCity(workText)].filter(Boolean), waitForOptions: Number(plan.dynamicOptionTimeoutMs || 1800) },
        { fieldKey: "startTime", id: "startDate", name: "startDate", kind: "date", value: job.startDate || job.startTime },
        { fieldKey: "industry", id: "industry", name: "industry", kind: "select", value: job.industry },
        { fieldKey: "endTime", id: "endDate", name: "endDate", kind: "date", value: job.endDate || job.endTime },
        { fieldKey: "department", id: "departmentName", name: "departmentName", kind: "text", value: job.department },
        { fieldKey: "position", id: "jobName", name: "jobName", kind: "text", value: job.position },
        { fieldKey: "description", id: "jobDesc", name: "jobDesc", kind: "text", value: [job.detailedContent, job.result].filter(Boolean).join("；") }
      ], unmappedProfileFields: normalizeText(job.company || "") ? ["company"] : [] });
    }

    var awards = Array.isArray(profile.awards) ? profile.awards : [];
    if (awards.length) {
      var award = awards[0] || {};
      jobs.push({ sectionName: "获奖信息", kind: "award", profileRecordIndex: 0, specs: [
        { fieldKey: "awardTime", id: "time", name: "time", kind: "date", value: award.awardTime || award.awardDate },
        { fieldKey: "awardIssuer", id: "company", name: "company", kind: "text", value: award.awardIssuer },
        { fieldKey: "awardName", id: "awardsNameId", name: "awardsNameId", kind: "select", aliases: analyzedBatchPreviewAwardNameAliases(award.awardName) },
        { fieldKey: "awardLevel", id: "awardsLevel", name: "awardsLevel", kind: "select", value: analyzedBatchPreviewNormalizeAwardLevel(award.awardLevel) },
        { fieldKey: "awardNameDetail", id: "awardsDesc", name: "awardsDesc", kind: "text", value: award.awardName },
        { fieldKey: "awardDescription", id: "rewardDescribe", name: "rewardDescribe", kind: "text", value: award.awardDescription }
      ] });
    }

    var family = Array.isArray(profile.familyMembers) ? profile.familyMembers : [];
    if (family.length) {
      var member = family[0] || {};
      jobs.push({ sectionName: "家庭成员", kind: "family", profileRecordIndex: 0, specs: [
        { fieldKey: "relationship", id: "relation", name: "relation", kind: "select", value: analyzedBatchPreviewNormalizeRelation(member.relationship) },
        { fieldKey: "company", id: "department", name: "department", kind: "text", value: member.company },
        { fieldKey: "address", id: "address", name: "address", kind: "text", value: member.address },
        { fieldKey: "phone", id: "relativesPhoneNumber", name: "relativesPhoneNumber", kind: "text", value: member.phone },
        { fieldKey: "name", id: "name", name: "name", kind: "text", value: member.name },
        { fieldKey: "birthDate", id: "birthday", name: "birthday", kind: "date", value: member.birthDate },
        { fieldKey: "position", id: "post", name: "post", kind: "text", value: member.position }
      ] });
    }

    for (var j = 0; j < jobs.length; j += 1) {
      var jobPlan = jobs[j];
      var section = byName[jobPlan.sectionName];
      var item = { section: jobPlan.sectionName, recordKind: jobPlan.kind, profileRecordIndex: jobPlan.profileRecordIndex, navigation: null, preview: null, unmappedProfileFields: jobPlan.unmappedProfileFields || [] };
      if (!section) { item.preview = { result: "failed", reason: "section_plan_missing" }; trace.sections.push(item); continue; }
      item.navigation = await analyzedBatchPreviewNavigate(section, Number(plan.navigationTimeoutMs || 3000));
      if (!item.navigation.ok) { item.preview = { result: "failed", reason: item.navigation.reason || "navigation_failed" }; trace.sections.push(item); continue; }
      item.preview = await analyzedBatchPreviewOneRecord(section, jobPlan.specs, { kind: jobPlan.kind, profileRecordIndex: jobPlan.profileRecordIndex }, plan);
      trace.sections.push(item);
      trace.safety.fieldsWritten = trace.safety.fieldsWritten || !!(item.preview && item.preview.safety && item.preview.safety.fieldsWritten);
      if (item.preview && item.preview.result === "left_open") {
        trace.result = "partial_stopped_open_editor";
        trace.reason = item.preview.reason || "preview_left_open";
        return trace;
      }
    }

    var other = byName["其他资格"];
    if (other) {
      var otherItem = { section: "其他资格", recordKind: "structure_probe", profileRecordIndex: -1, navigation: null, preview: null, unmappedProfileFields: [] };
      otherItem.navigation = await analyzedBatchPreviewNavigate(other, Number(plan.navigationTimeoutMs || 3000));
      if (otherItem.navigation.ok) {
        otherItem.preview = await runAnalyzedSectionAddEditorProbe({ section: other, requireSectionActive: true, editorOpenTimeoutMs: Number(plan.editorOpenTimeoutMs || 4500), editorCloseTimeoutMs: Number(plan.editorCloseTimeoutMs || 2500) });
      } else {
        otherItem.preview = { result: "failed", reason: otherItem.navigation.reason || "navigation_failed" };
      }
      trace.sections.push(otherItem);
    }

    var failed = trace.sections.filter(function (item) { return !item.preview || (item.preview.result !== "preview_complete" && item.preview.result !== "preview_with_field_gaps" && item.preview.result !== "probe_complete_closed"); });
    trace.result = failed.length ? "complete_with_gaps" : "complete";
    trace.reason = failed.length ? "some_preview_steps_not_complete" : "";
    return trace;
  }


  function analyzedEducationPreviewNormalizeProvince(value) {
    var text = normalizeText(value || "").replace(/\s+/g, "");
    if (!text) return "";
    if (/^(北京|上海|天津|重庆)$/.test(text)) return text + "市";
    if (/^(北京市|上海市|天津市|重庆市)$/.test(text)) return text;
    var first = text.split(/[、,，/\-]/)[0] || text;
    if (/省$|自治区$|特别行政区$/.test(first)) return first;
    if (/^(内蒙古|广西|西藏|宁夏|新疆)$/.test(first)) {
      var map = { "内蒙古": "内蒙古自治区", "广西": "广西壮族自治区", "西藏": "西藏自治区", "宁夏": "宁夏回族自治区", "新疆": "新疆维吾尔自治区" };
      return map[first] || first;
    }
    return first;
  }

  function analyzedEducationPreviewNormalizeSchoolAffiliation(value, isOverseas) {
    var text = normalizeText(value || "");
    var overseas = normalizeText(isOverseas || "");
    if (/境外|国外|海外|港澳台/.test(text) || /^(?:是|true|1)$/i.test(overseas)) return "境外";
    if (/境内|国内/.test(text) || /^(?:否|false|0)$/i.test(overseas)) return "境内";
    return "";
  }

  function analyzedEducationPreviewNormalizeEducationType(value) {
    var text = normalizeText(value || "");
    if (!text) return "";
    if (/全日制/.test(text)) return "普通全日制";
    return text;
  }

  function analyzedEducationPreviewNormalizeLevel(value) {
    var text = normalizeText(value || "");
    if (!text) return "";
    if (/博士/.test(text)) return "博士研究生";
    if (/硕士|研究生/.test(text)) return "硕士研究生";
    if (/本科|学士/.test(text)) return "大学本科";
    if (/大专|专科/.test(text)) return "大专";
    if (/高职/.test(text)) return "高职";
    return text;
  }

  function analyzedEducationPreviewNormalizeDegree(record) {
    record = record || {};
    var degree = normalizeText(record.degree || "");
    var category = normalizeText(record.majorCategory || "");
    if (!degree) return "";
    if (category && /(?:学士|硕士|博士)$/.test(degree) && degree.indexOf(category) !== 0) return category + degree;
    return degree;
  }

  function analyzedEducationPreviewField(scope, id, name) {
    var matches = [];
    try {
      if (id) matches = Array.from(scope.querySelectorAll('[id="' + String(id).replace(/"/g, '\\"') + '"]')).filter(isActuallyVisible);
      if (!matches.length && name) matches = Array.from(scope.querySelectorAll('[name="' + String(name).replace(/"/g, '\\"') + '"]')).filter(isActuallyVisible);
    } catch (e) { matches = []; }
    return { element: matches.length === 1 ? matches[0] : null, count: matches.length };
  }

  function analyzedEducationPreviewReadbackMatches(control, wanted, kind) {
    if (!control) return false;
    var target = normalizeText(wanted || "").replace(/\s+/g, "");
    if (!target) return false;
    if (kind === "select") {
      var optionText = "";
      try { optionText = normalizeText(control.options && control.selectedIndex >= 0 && control.options[control.selectedIndex] && control.options[control.selectedIndex].textContent || ""); } catch (e) {}
      var normalizedOption = optionText.replace(/\s+/g, "");
      return !!(normalizedOption && (normalizedOption === target || normalizedOption.indexOf(target) !== -1 || target.indexOf(normalizedOption) !== -1));
    }
    var current = normalizeText(control.value || "").replace(/\s+/g, "");
    if (kind === "date") {
      var currentDigits = current.replace(/\D/g, "");
      var targetDigits = target.replace(/\D/g, "");
      return !!(currentDigits && targetDigits && (currentDigits === targetDigits || currentDigits.indexOf(targetDigits.slice(0, 6)) !== -1));
    }
    return !!(current && (current === target || current.indexOf(target) !== -1 || target.indexOf(current) !== -1));
  }

  function analyzedEducationPreviewBoolean(value) {
    var text = normalizeText(value == null ? "" : value);
    if (!text) return null;
    if (/^(?:是|true|1|yes|y)$/i.test(text)) return true;
    if (/^(?:否|false|0|no|n)$/i.test(text)) return false;
    return null;
  }

  function analyzedEducationPreviewRadioText(control) {
    if (!control) return "";
    var bits = [];
    try {
      if (control.labels && control.labels.length) Array.from(control.labels).forEach(function (label) { bits.push(label.textContent || ""); });
      if (control.id) {
        var owner = control.ownerDocument || document;
        var explicit = owner.querySelector('label[for="' + String(control.id).replace(/"/g, '\\"') + '"]');
        if (explicit) bits.push(explicit.textContent || "");
      }
      var previous = control.previousSibling;
      var next = control.nextSibling;
      if (previous && previous.textContent) bits.push(previous.textContent);
      if (next && next.textContent) bits.push(next.textContent);
      var labelParent = control.closest && control.closest("label");
      if (labelParent) bits.push(labelParent.textContent || "");
      if (control.value) bits.push(control.value);
      // Parent text is useful as a last fallback, but it often contains both
      // radio labels (for example "是 否"). Keep it last so direct labels,
      // sibling text and the native value dominate identity scoring.
      if (control.parentElement) bits.push(control.parentElement.textContent || "");
    } catch (e) {}
    return normalizeText(bits.join(" "));
  }

  async function analyzedEducationPreviewFillRadio(scope, spec, trace) {
    var radios = [];
    try {
      if (spec.name) radios = Array.from(scope.querySelectorAll('input[type="radio"][name="' + String(spec.name).replace(/"/g, '\\"') + '"]')).filter(isActuallyVisible);
      if (!radios.length && spec.id) radios = Array.from(scope.querySelectorAll('input[type="radio"][id="' + String(spec.id).replace(/"/g, '\\"') + '"]')).filter(isActuallyVisible);
    } catch (eRadios) { radios = []; }
    trace.controlCount = radios.length;
    if (!spec.value) { trace.reason = "profile_value_missing"; return trace; }
    if (!radios.length) { trace.reason = "control_not_found"; return trace; }
    var wanted = normalizeChoiceText(spec.value);
    var wantedBool = analyzedEducationPreviewBoolean(spec.value);
    var scored = radios.map(function (radio) {
      var text = normalizeChoiceText(analyzedEducationPreviewRadioText(radio));
      var value = normalizeChoiceText(radio.value || "");
      var score = text === wanted || value === wanted ? 7 : (text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1 || value.indexOf(wanted) !== -1 || wanted.indexOf(value) !== -1 ? 4 : 0);
      if (wantedBool !== null) {
        var positive = /^(?:1|true|yes|y|是)$/i.test(value);
        var negative = /^(?:0|false|no|n|否)$/i.test(value);
        if ((wantedBool && positive) || (!wantedBool && negative)) score = Math.max(score, 9);
        if ((wantedBool && /是|第一|主要/.test(text) && !/否/.test(text)) || (!wantedBool && /否/.test(text))) score = Math.max(score, 8);
      }
      return { radio: radio, score: score };
    }).filter(function (entry) { return entry.score > 0; });
    scored.sort(function (a, b) { return b.score - a.score; });
    if (!scored.length) { trace.reason = "radio_option_not_found"; return trace; }
    if (scored.length > 1 && scored[0].score === scored[1].score) { trace.reason = "radio_option_ambiguous"; return trace; }
    trace.attempted = true;
    try {
      if (!scored[0].radio.checked) await safeClick(scored[0].radio);
      if (!scored[0].radio.checked) {
        scored[0].radio.checked = true;
        try { scored[0].radio.dispatchEvent(new Event("input", { bubbles: true })); } catch (eInput) {}
        try { scored[0].radio.dispatchEvent(new Event("change", { bubbles: true })); } catch (eChange) {}
      }
    } catch (eRadioFill) { trace.reason = "fill_exception"; return trace; }
    trace.readbackMatch = !!scored[0].radio.checked;
    trace.committed = trace.readbackMatch;
    if (!trace.committed) trace.reason = "readback_mismatch";
    return trace;
  }

  async function analyzedEducationPreviewFillOne(scope, spec) {
    var trace = {
      fieldKey: spec.fieldKey,
      controlId: spec.id || "",
      controlName: spec.name || "",
      controlCount: 0,
      writer: spec.kind,
      attempted: false,
      committed: false,
      readbackMatch: false,
      reason: ""
    };
    if (spec.kind === "radio") return analyzedEducationPreviewFillRadio(scope, spec, trace);
    var lookup = analyzedEducationPreviewField(scope, spec.id, spec.name);
    trace.controlCount = lookup.count;
    if (spec.value === undefined || spec.value === null || normalizeText(spec.value) === "") { trace.reason = "profile_value_missing"; return trace; }
    if (!lookup.element) { trace.reason = lookup.count > 1 ? "control_not_unique" : "control_not_found"; return trace; }
    var control = lookup.element;
    trace.attempted = true;
    var ok = false;
    try {
      if (spec.kind === "checkbox") {
        var wantedChecked = analyzedEducationPreviewBoolean(spec.value);
        if (wantedChecked === null) { trace.attempted = false; trace.reason = "profile_value_invalid"; return trace; }
        if (!!control.checked !== wantedChecked) await safeClick(control);
        if (!!control.checked !== wantedChecked) {
          control.checked = wantedChecked;
          try { control.dispatchEvent(new Event("input", { bubbles: true })); } catch (eCbInput) {}
          try { control.dispatchEvent(new Event("change", { bubbles: true })); } catch (eCbChange) {}
        }
        ok = !!control.checked === wantedChecked;
        trace.readbackMatch = ok;
        trace.committed = ok;
        if (!ok) trace.reason = "readback_mismatch";
        return trace;
      }
      if (spec.kind === "select") {
        ok = setNativeSelectValue(control, spec.value);
      } else if (spec.kind === "date") {
        ok = !!(AF.FormHandler && typeof AF.FormHandler.fillFormElement === "function" && await AF.FormHandler.fillFormElement(control, spec.value, "date", { source: "analyzed_education_preview" }));
      } else if (spec.kind === "search") {
        ok = !!(AF.FormHandler && typeof AF.FormHandler.fillFormElement === "function" && await AF.FormHandler.fillFormElement(control, spec.value, "search", { source: "analyzed_education_preview" }));
        if (!ok && !control.readOnly) {
          setElementTextInput(control, spec.value);
          ok = true;
          trace.writer = "search_text_fallback";
        }
      } else {
        ok = !!(AF.FormHandler && typeof AF.FormHandler.fillFormElement === "function" && await AF.FormHandler.fillFormElement(control, spec.value, "text", { source: "analyzed_education_preview" }));
        if (!ok && !control.readOnly) {
          setElementTextInput(control, spec.value);
          ok = true;
          trace.writer = "text_fallback";
        }
      }
    } catch (eFill) {
      trace.reason = "fill_exception";
      return trace;
    }
    trace.readbackMatch = analyzedEducationPreviewReadbackMatches(control, spec.value, spec.kind);
    trace.committed = !!(ok && trace.readbackMatch);
    if (!ok) trace.reason = "writer_failed";
    else if (!trace.readbackMatch) trace.reason = "readback_mismatch";
    return trace;
  }


  function analyzedBatchSaveNormalizeIdentityToken(value) {
    return normalizeChoiceText(value || "").toLowerCase().replace(/[\s（）()【】\[\]{}<>《》·,，.。:：;；/\\|_\-—–]/g, "");
  }

  function analyzedBatchSaveDateKey(value) {
    var digits = String(value || "").replace(/\D/g, "");
    return digits.length >= 6 ? digits.slice(0, 6) : digits;
  }

  function analyzedBatchSaveIdentityReadableText(root) {
    if (!root) return "";
    // Saved-record identity must come from rendered read-only content, never
    // from an open editor's select options or hidden form vocabulary. A blank
    // award editor, for example, contains "其他奖学金" in <option> nodes and
    // must not make that award look already saved.
    try {
      var clone = root.cloneNode(true);
      var interactive = clone.querySelectorAll("select, option, datalist, input, textarea, button, script, style, template, [contenteditable='true'], [role='listbox'], [role='option']");
      Array.from(interactive || []).forEach(function (node) { try { node.remove(); } catch (eRemove) {} });
      return normalizeText(clone.textContent || "");
    } catch (eClone) {
      return normalizeText(root.textContent || "");
    }
  }

  function analyzedBatchSaveIdentityPresent(root, identity) {
    if (!root || !identity) return false;
    var raw = analyzedBatchSaveIdentityReadableText(root);
    var text = analyzedBatchSaveNormalizeIdentityToken(raw);
    var digits = String(raw || "").replace(/\D/g, "");
    var primaryAliases = (Array.isArray(identity.primaryAliases) ? identity.primaryAliases : [identity.primary]).map(analyzedBatchSaveNormalizeIdentityToken).filter(Boolean);
    if (!primaryAliases.length) return false;
    var primaryMatched = primaryAliases.some(function (token) { return token && text.indexOf(token) !== -1; });
    if (!primaryMatched) return false;
    var supporting = Array.isArray(identity.supporting) ? identity.supporting : [];
    var matchedSupporting = 0;
    supporting.forEach(function (token) {
      var rawToken = String(token || "");
      var dateToken = analyzedBatchSaveDateKey(rawToken);
      var normalized = analyzedBatchSaveNormalizeIdentityToken(rawToken);
      if ((dateToken && dateToken.length >= 6 && digits.indexOf(dateToken) !== -1) || (normalized && text.indexOf(normalized) !== -1)) matchedSupporting += 1;
    });
    var required = Number.isFinite(Number(identity.requiredSupporting)) ? Number(identity.requiredSupporting) : (supporting.length ? 1 : 0);
    return matchedSupporting >= required;
  }

  function analyzedBatchSaveSectionRoot(section) {
    var resolved = resolveAnalyzedEducationSectionRoot(section && section.text || "");
    return resolved && resolved.root || null;
  }

  function analyzedBatchSaveLanguageJobs(profile, plan) {
    return analyzedBatchSelectLanguageRecords(profile, plan).map(function (row, index) {
      return {
        sectionName: "外语水平",
        kind: row.kind || "language",
        profileRecordIndex: index,
        identity: { primaryAliases: row.levelAliases || [], supporting: [row.grade], requiredSupporting: normalizeText(row.grade || "") ? 1 : 0 },
        specs: [
          { fieldKey: "language", id: "language", name: "language", kind: "select", value: row.language },
          { fieldKey: "languageLevel", id: "languageLevel", name: "languageLevel", kind: "select", aliases: row.levelAliases || [], waitForOptions: Number(plan.dynamicOptionTimeoutMs || 1800) },
          { fieldKey: "firstLanguage", id: "", name: "firstLanguage", kind: "radio", value: row.firstLanguage },
          { fieldKey: "englishGrade", id: "englishGrade", name: "englishGrade", kind: "text", value: row.grade }
        ]
      };
    });
  }

  function analyzedBatchSaveBuildJobs(profile, plan) {
    profile = profile || {};
    var jobs = analyzedBatchSaveLanguageJobs(profile, plan);
    var basic = profile.basicInfo || {};
    var communicationPrimary = basic.phone || basic.email || basic.communicationAddress || basic.mailingAddress || "";
    jobs.push({ sectionName: "通讯信息", kind: "communication", profileRecordIndex: 0,
      identity: { primaryAliases: [communicationPrimary].filter(Boolean), supporting: [basic.email, basic.communicationAddress || basic.mailingAddress].filter(Boolean), requiredSupporting: (basic.email || basic.communicationAddress || basic.mailingAddress) ? 1 : 0 },
      specs: [
        { fieldKey: "country", id: "regions", name: "regions", kind: "select", value: basic.country || "中国" },
        { fieldKey: "currentProvince", id: "city", name: "city", kind: "select", value: analyzedBatchPreviewNormalizeProvince(basic.currentAddress || basic.currentResidence || basic.currentAddressDetail) },
        { fieldKey: "currentAddressDetail", id: "specificAddress", name: "specificAddress", kind: "text", value: basic.currentAddressDetail },
        { fieldKey: "phone", id: "phoneNumber", name: "phoneNumber", kind: "text", value: basic.phone },
        { fieldKey: "qq", id: "qqid", name: "qqid", kind: "text", value: basic.qq },
        { fieldKey: "mailingProvince", id: "jt", name: "province", kind: "select", value: analyzedBatchPreviewNormalizeProvince(basic.communicationAddress || basic.mailingAddress || basic.hukouLocation) },
        { fieldKey: "communicationAddress", id: "distrctName", name: "distrctName", kind: "text", value: basic.communicationAddress || basic.mailingAddress },
        { fieldKey: "postalCode", id: "postCode", name: "postCode", kind: "text", value: basic.postalCode },
        { fieldKey: "email", id: "email", name: "email", kind: "text", value: basic.email },
        { fieldKey: "wechat", id: "wechatid", name: "wechatid", kind: "text", value: basic.wechat }
      ]
    });

    var internships = Array.isArray(profile.internshipExperience) ? profile.internshipExperience : [];
    internships.forEach(function (row, index) {
      row = row || {};
      var workText = normalizeText(row.workLocation || "");
      var primary = row.position || row.department || row.company || "";
      jobs.push({ sectionName: "实习/工作/入伍经历", kind: "internship", profileRecordIndex: index,
        identity: { primaryAliases: [primary].filter(Boolean), supporting: [row.startDate || row.startTime, row.endDate || row.endTime, row.department].filter(Boolean), requiredSupporting: 1 },
        unmappedProfileFields: normalizeText(row.company || "") ? ["company"] : [],
        specs: [
          { fieldKey: "country", id: "jobCountry", name: "country", kind: "select", value: "中国" },
          { fieldKey: "province", id: "gt", name: "province", kind: "select", value: analyzedBatchPreviewNormalizeProvince(workText) },
          { fieldKey: "city", id: "jobcity", name: "jobcity", kind: "select", aliases: [analyzedBatchPreviewNormalizeCity(workText)].filter(Boolean), waitForOptions: Number(plan.dynamicOptionTimeoutMs || 1800) },
          { fieldKey: "startTime", id: "startDate", name: "startDate", kind: "date", value: row.startDate || row.startTime },
          { fieldKey: "industry", id: "industry", name: "industry", kind: "select", value: row.industry },
          { fieldKey: "endTime", id: "endDate", name: "endDate", kind: "date", value: row.endDate || row.endTime },
          { fieldKey: "department", id: "departmentName", name: "departmentName", kind: "text", value: row.department },
          { fieldKey: "position", id: "jobName", name: "jobName", kind: "text", value: row.position },
          { fieldKey: "description", id: "jobDesc", name: "jobDesc", kind: "text", value: [row.detailedContent, row.result].filter(Boolean).join("；") }
        ]
      });
    });

    var awards = Array.isArray(profile.awards) ? profile.awards : [];
    awards.forEach(function (row, index) {
      row = row || {};
      jobs.push({ sectionName: "获奖信息", kind: "award", profileRecordIndex: index,
        identity: { primaryAliases: analyzedBatchPreviewAwardNameAliases(row.awardName), supporting: [row.awardTime || row.awardDate, row.awardIssuer].filter(Boolean), requiredSupporting: (row.awardTime || row.awardDate || row.awardIssuer) ? 1 : 0 },
        specs: [
          { fieldKey: "awardTime", id: "time", name: "time", kind: "date", value: row.awardTime || row.awardDate },
          { fieldKey: "awardIssuer", id: "company", name: "company", kind: "text", value: row.awardIssuer },
          { fieldKey: "awardName", id: "awardsNameId", name: "awardsNameId", kind: "select", aliases: analyzedBatchPreviewAwardNameAliases(row.awardName) },
          { fieldKey: "awardLevel", id: "awardsLevel", name: "awardsLevel", kind: "select", value: analyzedBatchPreviewNormalizeAwardLevel(row.awardLevel) },
          { fieldKey: "awardNameDetail", id: "awardsDesc", name: "awardsDesc", kind: "text", value: row.awardName },
          { fieldKey: "awardDescription", id: "rewardDescribe", name: "rewardDescribe", kind: "text", value: row.awardDescription }
        ]
      });
    });

    var family = Array.isArray(profile.familyMembers) ? profile.familyMembers : [];
    family.forEach(function (row, index) {
      row = row || {};
      jobs.push({ sectionName: "家庭成员", kind: "family", profileRecordIndex: index,
        identity: { primaryAliases: [row.name].filter(Boolean), supporting: [row.relationship, row.birthDate, row.company].filter(Boolean), requiredSupporting: (row.relationship || row.birthDate || row.company) ? 1 : 0 },
        specs: [
          { fieldKey: "relationship", id: "relation", name: "relation", kind: "select", value: analyzedBatchPreviewNormalizeRelation(row.relationship) },
          { fieldKey: "company", id: "department", name: "department", kind: "text", value: row.company },
          { fieldKey: "address", id: "address", name: "address", kind: "text", value: row.address },
          { fieldKey: "phone", id: "relativesPhoneNumber", name: "relativesPhoneNumber", kind: "text", value: row.phone },
          { fieldKey: "name", id: "name", name: "name", kind: "text", value: row.name },
          { fieldKey: "birthDate", id: "birthday", name: "birthday", kind: "date", value: row.birthDate },
          { fieldKey: "position", id: "post", name: "post", kind: "text", value: row.position || "无" }
        ]
      });
    });

    var other = Array.isArray(profile.otherQualifications) ? profile.otherQualifications : [];
    other.forEach(function (row, index) {
      row = row || {};
      var title = row.title || row.type || row.category || "其他";
      var content = row.content || row.description || row.value || "";
      jobs.push({ sectionName: "其他资格", kind: "other_qualification", profileRecordIndex: index,
        identity: { primaryAliases: [title].filter(Boolean), supporting: [content].filter(Boolean), requiredSupporting: content ? 1 : 0 },
        specs: [
          { fieldKey: "title", id: "title", name: "title", kind: "select", value: title },
          { fieldKey: "content", id: "content", name: "content", kind: "text", value: content }
        ]
      });
    });
    return jobs;
  }

  function analyzedBatchSaveEditorFormRoot(opened) {
    if (!opened || !opened.scope) return null;
    var cursor = opened.scope;
    for (var depth = 0; cursor && depth < 8; depth += 1) {
      if (String(cursor.tagName || "").toLowerCase() === "form") return cursor;
      cursor = cursor.parentElement;
    }
    try {
      if (opened.scope.closest) {
        var nearest = opened.scope.closest("form");
        if (nearest) return nearest;
      }
    } catch (eClosest) {}
    return opened.scope;
  }

  function analyzedBatchSaveControlText(control) {
    if (!control) return "";
    if (String(control.type || "").toLowerCase() === "radio" || String(control.type || "").toLowerCase() === "checkbox") {
      return control.checked ? normalizeText(control.value || "1") : "";
    }
    if (String(control.tagName || "").toLowerCase() === "select") {
      try {
        var option = control.options && control.selectedIndex >= 0 ? control.options[control.selectedIndex] : null;
        var selected = normalizeText(option && (option.textContent || option.value) || control.value || "");
        return /^(?:请选择|选择|--+|无)$/i.test(selected) ? "" : selected;
      } catch (eSelect) { return normalizeText(control.value || ""); }
    }
    return normalizeText(control.value || "");
  }

  function analyzedBatchSaveLocalRequirementContext(control, root) {
    var cursor = control && control.parentElement;
    for (var depth = 0; cursor && cursor !== root && depth < 5; depth += 1, cursor = cursor.parentElement) {
      var text = normalizeText(cursor.textContent || "");
      if (!text || text.length > 280) continue;
      var controlCount = 0;
      try { controlCount = cursor.querySelectorAll("input,select,textarea").length; } catch (eCount) {}
      // Do not inherit a sibling field's red asterisk from a two-column row.
      // Contextual required markers are trusted only in the nearest single-control wrapper.
      if (controlCount > 1) continue;
      if (/[＊*]|必填|必须|required/i.test(text)) return text;
      if (/(?:至少|最少|不少于)\s*\d+\s*(?:个)?(?:字|字符)/.test(text)) return text;
    }
    return "";
  }

  function analyzedBatchSaveParsedMinLength(control, contextText) {
    var nativeMin = 0;
    try {
      var raw = Number(control && control.minLength);
      if (Number.isFinite(raw) && raw > 0) nativeMin = raw;
    } catch (eMin) {}
    var source = [control && control.getAttribute && control.getAttribute("placeholder"), contextText].filter(Boolean).join(" ");
    var match = source.match(/(?:至少|最少|不少于)\s*(\d+)\s*(?:个)?(?:字|字符)/);
    var hinted = match ? Number(match[1]) : 0;
    return Math.max(nativeMin || 0, hinted || 0);
  }

  function analyzedBatchSaveManualInputRequirement(opened) {
    var out = { required: false, issueCount: 0, issues: [], strategy: "" };
    var root = analyzedBatchSaveEditorFormRoot(opened);
    if (!root) return out;
    var controls = [];
    try {
      controls = Array.from(root.querySelectorAll("input,select,textarea")).filter(function (control) {
        if (!control || control.disabled || !isActuallyVisible(control)) return false;
        var type = String(control.type || "").toLowerCase();
        return type !== "hidden" && type !== "file" && type !== "button" && type !== "submit" && type !== "reset";
      });
    } catch (eControls) { controls = []; }
    var seenRadioNames = {};
    controls.forEach(function (control) {
      var tag = String(control.tagName || "").toLowerCase();
      var type = String(control.type || "").toLowerCase();
      var contextText = analyzedBatchSaveLocalRequirementContext(control, root);
      var explicitRequired = false;
      try { explicitRequired = !!(control.required || control.getAttribute("required") != null || control.getAttribute("aria-required") === "true"); } catch (eReq) {}
      var contextualRequired = /[＊*]|必填|必须|required/i.test(contextText || "");
      var required = explicitRequired || contextualRequired;
      var label = normalizeText(analyzedEditorProbeLabel(control) || "");
      var id = String(control.id || "");
      var name = String(control.getAttribute && control.getAttribute("name") || "");
      var valueText = analyzedBatchSaveControlText(control);
      var issue = null;
      if (type === "radio") {
        if (name && seenRadioNames[name]) return;
        if (name) seenRadioNames[name] = true;
        var group = [];
        try { group = Array.from(root.querySelectorAll('input[type="radio"][name="' + name.replace(/"/g, '\\"') + '"]')).filter(isActuallyVisible); } catch (eGroup) { group = [control]; }
        var checked = group.some(function (item) { return !!item.checked; });
        if (required && !checked) issue = { reason: "required_empty" };
      } else if (type === "checkbox") {
        if (required && !control.checked) issue = { reason: "required_empty" };
      } else {
        if (required && !valueText) issue = { reason: "required_empty" };
        var minLength = analyzedBatchSaveParsedMinLength(control, contextText);
        if (!issue && minLength > 0 && valueText && Array.from(valueText).length < minLength) issue = { reason: "min_length", minLength: minLength, currentLength: Array.from(valueText).length };
        var invalid = false;
        var validationMessage = "";
        try {
          invalid = !!(control.validity && control.validity.valid === false);
          validationMessage = normalizeText(control.validationMessage || "");
        } catch (eValidity) {}
        if (!issue && invalid) issue = { reason: "browser_invalid", validationMessage: validationMessage.slice(0, 160) };
      }
      if (!issue) return;
      out.issues.push({
        fieldKey: id || name || label || tag,
        controlId: id,
        controlName: name,
        label: label.slice(0, 120),
        reason: issue.reason,
        minLength: Number(issue.minLength || 0),
        currentLength: Number(issue.currentLength || 0),
        validationMessage: String(issue.validationMessage || "").slice(0, 160)
      });
    });
    out.issueCount = out.issues.length;
    out.required = out.issueCount > 0;
    out.strategy = out.required ? "required_or_invalid_visible_control" : "no_manual_input_requirement";
    return out;
  }

  function analyzedBatchSaveMeaningfulExistingSpec(scope, spec) {
    var trace = {
      fieldKey: spec.fieldKey,
      controlId: spec.id || "",
      controlName: spec.name || "",
      controlCount: 0,
      writer: spec.kind,
      attempted: false,
      committed: false,
      readbackMatch: false,
      preservedExisting: false,
      reason: ""
    };
    if (!scope || !spec) return null;
    if (spec.kind === "radio") {
      var radios = [];
      try { if (spec.name) radios = Array.from(scope.querySelectorAll('input[type="radio"][name="' + String(spec.name).replace(/"/g, '\\"') + '"]')).filter(isActuallyVisible); } catch (eRadios) { radios = []; }
      trace.controlCount = radios.length;
      var checked = radios.find(function (radio) { return !!radio.checked; });
      if (!checked) return null;
      trace.committed = true;
      trace.preservedExisting = true;
      trace.reason = "existing_manual_value_preserved";
      return trace;
    }
    var lookup = analyzedEducationPreviewField(scope, spec.id, spec.name);
    trace.controlCount = lookup.count;
    if (!lookup.element) return null;
    var current = analyzedBatchSaveControlText(lookup.element);
    if (!current) return null;
    trace.readbackMatch = analyzedEducationPreviewReadbackMatches(lookup.element, spec.value, spec.kind);
    trace.committed = true;
    trace.preservedExisting = true;
    trace.reason = trace.readbackMatch ? "existing_value_already_matches" : "existing_manual_value_preserved";
    return trace;
  }

  function analyzedBatchSaveManualFileRequirement(opened) {
    var out = { required: false, fileInputCount: 0, missingFileCount: 0, requiredFileCount: 0, strategy: "" };
    if (!opened || !opened.scope) return out;
    var root = analyzedBatchSaveEditorFormRoot(opened) || opened.scope;
    var inputs = [];
    try { inputs = Array.from(root.querySelectorAll('input[type="file"]')).filter(function (node) { return node && !node.disabled; }); } catch (eInputs) { inputs = []; }
    out.fileInputCount = inputs.length;
    inputs.forEach(function (input) {
      var hasFile = false;
      try { hasFile = !!((input.files && input.files.length) || normalizeText(input.value || "")); } catch (eFiles) { hasFile = !!normalizeText(input.value || ""); }
      if (hasFile) return;
      out.missingFileCount += 1;
      var contextText = "";
      var node = input;
      for (var up = 0; node && up < 5; up += 1) {
        var text = normalizeText(node.textContent || "");
        if (text && text.length <= 900) contextText = text;
        if (/(上传|选择文件|附件|证明|成绩单|证书|文件)/i.test(contextText) && /(必填|必须|required)/i.test(contextText)) break;
        node = node.parentElement;
      }
      var explicitRequired = false;
      try { explicitRequired = !!(input.required || input.getAttribute("required") != null || input.getAttribute("aria-required") === "true"); } catch (eRequired) {}
      var contextualRequired = /(上传|选择文件|附件|证明|成绩单|证书|文件)/i.test(contextText) && /(必填|必须|required)/i.test(contextText);
      if (explicitRequired || contextualRequired) out.requiredFileCount += 1;
    });
    out.required = out.requiredFileCount > 0;
    out.strategy = out.required ? "required_file_input_without_file" : (out.fileInputCount ? "file_input_optional_or_satisfied" : "no_file_input");
    return out;
  }

  function analyzedBatchSaveFindOpenEditor(section, job) {
    job = job || {};
    var specs = Array.isArray(job.specs) ? job.specs : [];
    var matchedSpecKeys = [];
    var controls = [];
    specs.forEach(function (spec) {
      spec = spec || {};
      var kind = String(spec.kind || "");
      var id = String(spec.id || "");
      var name = String(spec.name || "");
      var local = [];
      try {
        if (kind === "radio" && name) {
          local = Array.from(document.querySelectorAll('[name="' + name.replace(/"/g, '\"') + '"]')).filter(isActuallyVisible);
        } else {
          var lookup = analyzedEducationPreviewField(document, id, name);
          if (lookup.element) local = [lookup.element];
        }
      } catch (eLookup) { local = []; }
      if (!local.length) return;
      matchedSpecKeys.push(String(spec.fieldKey || id || name || matchedSpecKeys.length));
      local.forEach(function (node) { if (controls.indexOf(node) === -1) controls.push(node); });
    });
    var expectedCount = specs.filter(function (spec) { return spec && (spec.id || spec.name); }).length;
    var minMatched = expectedCount <= 2 ? expectedCount : 2;
    if (!expectedCount || matchedSpecKeys.length < minMatched || !controls.length) {
      return { ok: false, reason: "no_matching_open_editor", matchedFieldCount: matchedSpecKeys.length, controls: [] };
    }
    var scope = analyzedEditorProbeCommonAncestor(controls) || document.body;
    var close = findAnalyzedEditorSafeCloseControl(scope);
    var save = findExplicitSectionSaveButton(section && section.text || "");
    if (!close.element && !save.element) {
      return { ok: false, reason: "matching_controls_without_editor_actions", matchedFieldCount: matchedSpecKeys.length, controls: controls };
    }
    return {
      ok: true,
      acquisition: "adopted_existing_editor",
      matchedFieldCount: matchedSpecKeys.length,
      controls: controls,
      scope: scope,
      snapshots: analyzedBatchPreviewCaptureControls(controls)
    };
  }

  async function analyzedBatchSaveOneRecord(section, job, plan) {
    var trace = {
      section: String(job.sectionName || section && section.text || ""),
      recordKind: String(job.kind || "record"),
      profileRecordIndex: Number.isInteger(job.profileRecordIndex) ? job.profileRecordIndex : 0,
      navigation: null,
      identityPresentBefore: false,
      editorAcquisition: "",
      existingEditorFieldMatchCount: 0,
      fieldTrace: [],
      attemptedFieldCount: 0,
      committedFieldCount: 0,
      failedFieldCount: 0,
      skippedFieldCount: 0,
      saveButtonFound: false,
      saveClickDispatched: false,
      saveFeedbackVerified: false,
      saveFeedbackKind: "",
      saveModalClosed: false,
      newValidationMessages: [],
      manualActionRequired: false,
      manualActionReason: "",
      manualRequirementKinds: [],
      manualActionFields: [],
      manualInputIssueCount: 0,
      fileInputCount: 0,
      missingRequiredFileCount: 0,
      identityVerifiedAfter: false,
      unmappedProfileFields: job.unmappedProfileFields || [],
      result: "",
      reason: "",
      safety: { valuesCaptured: false, fieldsWritten: false, saveExecuted: false, finalSubmitExecuted: false }
    };
    trace.navigation = await analyzedBatchPreviewNavigate(section, Number(plan.navigationTimeoutMs || 3000));
    if (!trace.navigation.ok) { trace.result = "failed"; trace.reason = trace.navigation.reason || "navigation_failed"; return trace; }
    var rootBefore = analyzedBatchSaveSectionRoot(section);
    trace.identityPresentBefore = analyzedBatchSaveIdentityPresent(rootBefore, job.identity);
    if (trace.identityPresentBefore) { trace.result = "already_present"; return trace; }

    var opened = analyzedBatchSaveFindOpenEditor(section, job);
    if (opened && opened.ok) {
      trace.editorAcquisition = opened.acquisition || "adopted_existing_editor";
      trace.existingEditorFieldMatchCount = Number(opened.matchedFieldCount || 0);
    } else {
      opened = await analyzedBatchPreviewOpenEditor(section, Number(plan.editorOpenTimeoutMs || 4500));
      if (opened && opened.ok) opened.acquisition = "clicked_add";
      trace.editorAcquisition = opened && opened.acquisition || "";
    }
    if (!opened.ok) { trace.result = "failed"; trace.reason = opened.reason || "editor_open_failed"; return trace; }
    for (var i = 0; i < job.specs.length; i += 1) {
      var spec = job.specs[i];
      var preserved = opened.acquisition === "adopted_existing_editor" ? analyzedBatchSaveMeaningfulExistingSpec(opened.scope, spec) : null;
      trace.fieldTrace.push(preserved || await analyzedBatchPreviewFillSpec(opened.scope, spec));
    }
    trace.attemptedFieldCount = trace.fieldTrace.filter(function (item) { return item && item.attempted; }).length;
    trace.committedFieldCount = trace.fieldTrace.filter(function (item) { return item && item.committed; }).length;
    trace.failedFieldCount = trace.fieldTrace.filter(function (item) { return item && item.attempted && !item.committed; }).length;
    trace.skippedFieldCount = trace.fieldTrace.filter(function (item) { return item && !item.attempted; }).length;
    trace.safety.fieldsWritten = trace.attemptedFieldCount > 0;
    if (trace.failedFieldCount > 0 || trace.committedFieldCount === 0) {
      trace.result = "blocked_by_fill_failure";
      trace.reason = trace.failedFieldCount > 0 ? "field_readback_failed" : "no_field_committed";
      return trace;
    }

    var manualFile = analyzedBatchSaveManualFileRequirement(opened);
    var manualInput = analyzedBatchSaveManualInputRequirement(opened);
    trace.fileInputCount = Number(manualFile.fileInputCount || 0);
    trace.missingRequiredFileCount = Number(manualFile.requiredFileCount || 0);
    trace.manualInputIssueCount = Number(manualInput.issueCount || 0);
    trace.manualActionFields = Array.isArray(manualInput.issues) ? manualInput.issues.slice(0, 20) : [];
    if (manualFile.required) trace.manualRequirementKinds.push("required_file");
    if (manualInput.required) trace.manualRequirementKinds.push("required_input");
    if (manualFile.required || manualInput.required) {
      trace.manualActionRequired = true;
      trace.manualActionReason = manualFile.required && manualInput.required ? "manual_requirements_pending" : (manualFile.required ? "required_file_upload_missing" : "required_input_missing_or_invalid");
      trace.result = "manual_action_required";
      trace.reason = trace.manualActionReason;
      return trace;
    }

    var validationBefore = collectAnalyzedNavigationValidationMessages();
    var save = findExplicitSectionSaveButton(section.text);
    trace.saveButtonFound = !!save.element;
    if (!save.element) { trace.result = "failed"; trace.reason = save.count > 1 ? "save_button_ambiguous" : "save_button_not_found"; return trace; }
    try { trace.saveClickDispatched = !!(await safeClick(save.element)); } catch (eSave) { trace.saveClickDispatched = false; }
    if (!trace.saveClickDispatched) { trace.result = "failed"; trace.reason = "save_click_failed"; return trace; }
    trace.safety.saveExecuted = true;

    var feedback = await waitUntil(function () {
      var successFeedback = findAnalyzedNavigationSaveSuccessFeedback();
      if (successFeedback) return { successFeedback: successFeedback };
      var afterMessages = collectAnalyzedNavigationValidationMessages();
      var fresh = afterMessages.filter(function (text) { return validationBefore.indexOf(text) === -1; });
      if (fresh.length) return { validationMessages: fresh };
      var liveManual = analyzedBatchSaveManualInputRequirement(opened);
      if (liveManual.required) return { manualInput: liveManual };
      return null;
    }, Number(plan.saveFeedbackTimeoutMs || 5000));
    if (feedback && Array.isArray(feedback.validationMessages) && feedback.validationMessages.length) {
      trace.newValidationMessages = feedback.validationMessages.slice(0, 20);
      trace.manualActionRequired = true;
      trace.manualActionReason = "save_validation_requires_manual_input";
      trace.manualRequirementKinds.push("validation_message");
      trace.result = "manual_action_required";
      trace.reason = trace.manualActionReason;
      return trace;
    }
    if (feedback && feedback.manualInput && feedback.manualInput.required) {
      trace.manualInputIssueCount = Number(feedback.manualInput.issueCount || 0);
      trace.manualActionFields = Array.isArray(feedback.manualInput.issues) ? feedback.manualInput.issues.slice(0, 20) : [];
      trace.manualActionRequired = true;
      trace.manualActionReason = "save_validation_requires_manual_input";
      if (trace.manualRequirementKinds.indexOf("required_input") === -1) trace.manualRequirementKinds.push("required_input");
      trace.result = "manual_action_required";
      trace.reason = trace.manualActionReason;
      return trace;
    }
    if (!feedback || !feedback.successFeedback) {
      var timedOutManual = analyzedBatchSaveManualInputRequirement(opened);
      if (timedOutManual.required) {
        trace.manualInputIssueCount = Number(timedOutManual.issueCount || 0);
        trace.manualActionFields = Array.isArray(timedOutManual.issues) ? timedOutManual.issues.slice(0, 20) : [];
        trace.manualActionRequired = true;
        trace.manualActionReason = "save_timeout_with_manual_requirement";
        if (trace.manualRequirementKinds.indexOf("required_input") === -1) trace.manualRequirementKinds.push("required_input");
        trace.result = "manual_action_required";
        trace.reason = trace.manualActionReason;
        return trace;
      }
      trace.result = "failed"; trace.reason = "save_feedback_timeout"; return trace;
    }
    trace.saveFeedbackVerified = true;
    trace.saveFeedbackKind = feedback.successFeedback.kind || "";
    if (feedback.successFeedback.kind === "modal") {
      var closed = await closeAnalyzedNavigationSaveSuccessModal(feedback.successFeedback.modal, Number(plan.saveModalCloseTimeoutMs || 2200));
      trace.saveModalClosed = !!closed.closed;
      if (!closed.found || !closed.clickDispatched || !closed.closed) {
        trace.result = "failed";
        trace.reason = !closed.found ? "save_modal_close_not_found" : (!closed.clickDispatched ? "save_modal_close_failed" : "save_modal_not_closed");
        return trace;
      }
    }

    var verified = await waitUntil(function () {
      var liveRoot = analyzedBatchSaveSectionRoot(section) || rootBefore;
      return analyzedBatchSaveIdentityPresent(liveRoot, job.identity) ? true : null;
    }, Number(plan.postSaveVerifyTimeoutMs || 4000));
    trace.identityVerifiedAfter = !!verified;
    if (!verified) { trace.result = "saved_unverified"; trace.reason = "saved_identity_not_verified"; return trace; }
    trace.result = "saved_and_verified";
    return trace;
  }

  async function runAnalyzedResumeSectionSaveBatch(plan) {
    plan = plan || {};
    var sections = Array.isArray(plan.sections) ? plan.sections : [];
    var profile = plan.profile || {};
    var byName = {};
    sections.forEach(function (section) { byName[normalizeText(section && section.text || "")] = section; });
    var jobs = analyzedBatchSaveBuildJobs(profile, plan);
    var trace = {
      plannedRecordCount: jobs.length,
      savedRecordCount: 0,
      alreadyPresentCount: 0,
      skippedRecordCount: 0,
      manualActionCount: 0,
      records: [],
      result: "",
      reason: "",
      safety: { valuesCaptured: false, fieldsWritten: false, saveExecuted: false, finalSubmitExecuted: false }
    };
    for (var i = 0; i < jobs.length; i += 1) {
      var job = jobs[i];
      var section = byName[job.sectionName];
      if (!section) {
        var missing = { section: job.sectionName, recordKind: job.kind, profileRecordIndex: job.profileRecordIndex, result: "failed", reason: "section_plan_missing", safety: { valuesCaptured: false, fieldsWritten: false, saveExecuted: false, finalSubmitExecuted: false } };
        trace.records.push(missing); trace.result = "stopped"; trace.reason = missing.reason; return trace;
      }
      var item = await analyzedBatchSaveOneRecord(section, job, plan);
      trace.records.push(item);
      trace.safety.fieldsWritten = trace.safety.fieldsWritten || !!(item.safety && item.safety.fieldsWritten);
      trace.safety.saveExecuted = trace.safety.saveExecuted || !!(item.safety && item.safety.saveExecuted);
      if (item.result === "already_present") { trace.alreadyPresentCount += 1; continue; }
      if (item.result === "saved_and_verified") { trace.savedRecordCount += 1; continue; }
      if (item.result === "manual_action_required") {
        trace.manualActionCount += 1;
        trace.result = "paused_for_manual_action";
        trace.reason = item.reason || "manual_action_required";
        return trace;
      }
      trace.result = "stopped";
      trace.reason = item.reason || item.result || "record_transaction_failed";
      return trace;
    }
    if (!Array.isArray(profile.otherQualifications) || !profile.otherQualifications.length) {
      trace.records.push({ section: "其他资格", recordKind: "other_qualification", profileRecordIndex: -1, result: "skipped_no_profile_records", reason: "other_qualification_profile_missing", safety: { valuesCaptured: false, fieldsWritten: false, saveExecuted: false, finalSubmitExecuted: false } });
      trace.skippedRecordCount += 1;
    }
    trace.result = "complete";
    return trace;
  }

  async function runAnalyzedEducationRecordPreviewFill(plan) {
    plan = plan || {};
    var section = plan.section || {};
    var record = plan.record || {};
    var trace = {
      section: String(section.text || ""),
      sectionSelector: String(section.selectorHint || ""),
      sectionSelectorCount: 0,
      sectionActiveBefore: false,
      profileRecordCount: Number(plan.profileRecordCount || 0),
      profileRecordIndex: Number.isInteger(plan.profileRecordIndex) ? plan.profileRecordIndex : 0,
      addButtonFound: false,
      addButtonCount: 0,
      addClickDispatched: false,
      editorOpened: false,
      editorScopeTagName: "",
      fieldTrace: [],
      attemptedFieldCount: 0,
      committedFieldCount: 0,
      failedFieldCount: 0,
      skippedFieldCount: 0,
      dynamicSchoolOptionCount: 0,
      saveControlFound: false,
      saveExecuted: false,
      editorLeftOpen: false,
      result: "",
      reason: "",
      safety: { valuesCaptured: false, fieldsWritten: false, saveExecuted: false, finalSubmitExecuted: false }
    };
    if (normalizeText(section.text) !== "教育背景") { trace.result = "failed"; trace.reason = "education_section_required"; return trace; }
    if (!record || typeof record !== "object" || !normalizeText(record.school || "")) { trace.result = "failed"; trace.reason = "education_profile_record_missing"; return trace; }
    var resolved = analyzedNavigationResolveUnique(section.selectorHint);
    trace.sectionSelectorCount = Number(resolved.count || 0);
    if (!resolved.element || trace.sectionSelectorCount !== 1) { trace.result = "failed"; trace.reason = trace.sectionSelectorCount > 1 ? "section_selector_not_unique" : "section_selector_not_found"; return trace; }
    trace.sectionActiveBefore = analyzedNavigationNodeIsActive(resolved.element);
    if (plan.requireSectionActive !== false && !trace.sectionActiveBefore) { trace.result = "failed"; trace.reason = "education_section_not_active"; return trace; }

    var beforeControls = analyzedEditorProbeVisibleControls(document);
    var add = findAnalyzedEducationAddControl(section.text);
    trace.addButtonFound = !!add.element;
    trace.addButtonCount = Number(add.count || 0);
    if (!add.element) { trace.result = "failed"; trace.reason = trace.addButtonCount > 1 ? "education_add_ambiguous" : "education_add_not_found"; return trace; }
    try { trace.addClickDispatched = !!(await safeClick(add.element)); } catch (eAdd) { trace.addClickDispatched = false; }
    if (!trace.addClickDispatched) { trace.result = "failed"; trace.reason = "education_add_click_failed"; return trace; }

    var opened = await waitUntil(function () {
      var nowControls = analyzedEditorProbeVisibleControls(document);
      var newlyVisible = nowControls.filter(function (node) { return beforeControls.indexOf(node) === -1; });
      return newlyVisible.length ? { newlyVisible: newlyVisible } : null;
    }, Number(plan.editorOpenTimeoutMs || 4500));
    if (!opened || !opened.newlyVisible || !opened.newlyVisible.length) { trace.result = "failed"; trace.reason = "education_editor_not_opened"; return trace; }
    trace.editorOpened = true;
    var scope = analyzedEditorProbeCommonAncestor(opened.newlyVisible) || document.body;
    trace.editorScopeTagName = String(scope && scope.tagName || "").toLowerCase();

    var specs = [
      { fieldKey: "schoolAffiliation", id: "", name: "type", kind: "radio", value: analyzedEducationPreviewNormalizeSchoolAffiliation(record.schoolAffiliation, record.isOverseas) },
      { fieldKey: "schoolLocation", id: "province", name: "province", kind: "select", value: analyzedEducationPreviewNormalizeProvince(record.schoolLocation || record.city) },
      { fieldKey: "educationType", id: "educationType", name: "educationType", kind: "select", value: analyzedEducationPreviewNormalizeEducationType(record.educationType) }
    ];
    for (var firstIndex = 0; firstIndex < specs.length; firstIndex++) trace.fieldTrace.push(await analyzedEducationPreviewFillOne(scope, specs[firstIndex]));

    var schoolCodeLookup = analyzedEducationPreviewField(scope, "schoolCode", "schoolCode");
    if (schoolCodeLookup.element) {
      await waitUntil(function () { try { return schoolCodeLookup.element.options && schoolCodeLookup.element.options.length > 1 ? true : null; } catch (e) { return null; } }, Number(plan.dynamicOptionTimeoutMs || 2200));
      try { trace.dynamicSchoolOptionCount = Number(schoolCodeLookup.element.options && schoolCodeLookup.element.options.length || 0); } catch (eCount) {}
      if (trace.dynamicSchoolOptionCount > 1) {
        trace.fieldTrace.push(await analyzedEducationPreviewFillOne(scope, { fieldKey: "school", id: "schoolCode", name: "schoolCode", kind: "select", value: record.school }));
      } else {
        trace.fieldTrace.push({ fieldKey: "school", controlId: "schoolCode", controlName: "schoolCode", controlCount: 1, writer: "select", attempted: false, committed: false, readbackMatch: false, reason: "dynamic_school_options_not_loaded" });
      }
    }

    var remainingSpecs = [
      { fieldKey: "school", id: "schoolChinaName", name: "schoolChinaName", kind: "text", value: record.school },
      { fieldKey: "startTime", id: "educationStartDate", name: "educationStartDate", kind: "date", value: record.startTime || record.startDate },
      { fieldKey: "degree", id: "xw", name: "degree", kind: "select", value: analyzedEducationPreviewNormalizeDegree(record) },
      { fieldKey: "endTime", id: "educationEndDate", name: "educationEndDate", kind: "date", value: record.endTime || record.endDate },
      { fieldKey: "degreeNumber", id: "degreeNumber", name: "degreeNumber", kind: "text", value: record.degreeNumber },
      { fieldKey: "level", id: "xl", name: "education", kind: "select", value: analyzedEducationPreviewNormalizeLevel(record.level) },
      { fieldKey: "educationNumber", id: "educationNumber", name: "educationNumber", kind: "text", value: record.educationNumber },
      { fieldKey: "major", id: "major", name: "major", kind: "search", value: record.major },
      { fieldKey: "gradePointType", id: "gradePointType", name: "gradePointType", kind: "select", value: record.gradePointType },
      { fieldKey: "majorDirection", id: "majorDirection", name: "majorDirection", kind: "text", value: record.majorDirection || record.researchDirection },
      { fieldKey: "gpa", id: "gradePoint", name: "gradePoint", kind: "text", value: record.gpa },
      { fieldKey: "degreeType", id: "", name: "researchType", kind: "radio", value: record.degreeType },
      { fieldKey: "researchDirection", id: "researchDirection", name: "researchDirection", kind: "text", value: record.researchDirection },
      { fieldKey: "isHighestEducation", id: "maxEdu", name: "maxEdu", kind: "checkbox", value: record.isHighestEducation },
      { fieldKey: "isHighestDegree", id: "maxDeg", name: "maxDeg", kind: "checkbox", value: record.isHighestDegree },
      { fieldKey: "isFirstEducation", id: "firstEdu", name: "firstEdu", kind: "checkbox", value: record.isFirstEducation },
      { fieldKey: "isDoubleEducation", id: "dubbleEdu", name: "dubbleEdu", kind: "checkbox", value: record.isDoubleEducation }
    ];
    for (var index = 0; index < remainingSpecs.length; index++) trace.fieldTrace.push(await analyzedEducationPreviewFillOne(scope, remainingSpecs[index]));

    trace.attemptedFieldCount = trace.fieldTrace.filter(function (item) { return item.attempted; }).length;
    trace.committedFieldCount = trace.fieldTrace.filter(function (item) { return item.committed; }).length;
    trace.failedFieldCount = trace.fieldTrace.filter(function (item) { return item.attempted && !item.committed; }).length;
    trace.skippedFieldCount = trace.fieldTrace.filter(function (item) { return !item.attempted; }).length;
    trace.safety.fieldsWritten = trace.attemptedFieldCount > 0;
    try {
      trace.saveControlFound = Array.from(scope.querySelectorAll("button, a, [role='button'], input[type='submit'], input[type='button']")).filter(isActuallyVisible).some(function (node) {
        return normalizeText(node.textContent || node.value || "") === "保存教育背景";
      });
    } catch (eSaveFind) {}
    trace.saveExecuted = false;
    trace.safety.saveExecuted = false;
    trace.editorLeftOpen = true;
    trace.result = trace.committedFieldCount > 0 ? "preview_filled_left_open" : "failed";
    trace.reason = trace.committedFieldCount > 0 ? "" : "no_field_committed";
    return trace;
  }


  function resolveAnalyzedEducationSectionRoot(sectionText) {
    var add = findAnalyzedEducationAddControl(sectionText || "教育背景");
    if (!add.element) return { root: null, add: add, strategy: "add_not_found" };
    var wanted = normalizeText(sectionText || "教育背景");
    var current = add.element;
    for (var depth = 0; current && current !== document.body && depth < 10; depth += 1, current = current.parentElement) {
      var headings = [];
      try { headings = Array.from(current.querySelectorAll("h1,h2,h3,h4,h5,h6,legend,[class*='title' i],[class*='tit' i],strong,span,div")); } catch (eHead) {}
      var hasHeading = headings.some(function (node) {
        if (!isActuallyVisible(node)) return false;
        if (normalizeText(node.textContent || "") !== wanted) return false;
        if (node === add.element || (add.element.contains && add.element.contains(node))) return false;
        try {
          var hr = node.getBoundingClientRect();
          var ar = add.element.getBoundingClientRect();
          return hr.bottom <= ar.top + 8 && hr.left < ar.right && hr.right > ar.left - 500;
        } catch (eRect) { return true; }
      });
      if (hasHeading) return { root: current, add: add, strategy: "add_heading_common_ancestor" };
    }
    return { root: null, add: add, strategy: "section_root_not_found" };
  }

  function analyzedEducationExistingIdentitySignalCount(existingRecords) {
    return (Array.isArray(existingRecords) ? existingRecords : []).filter(function (entry) {
      return higherEducationIdentityHasSignal(entry && entry.identity);
    }).length;
  }

  async function runAnalyzedEducationContinuePreview(plan) {
    plan = plan || {};
    var section = plan.section || {};
    var rows = Array.isArray(plan.records) ? plan.records : [];
    var trace = {
      section: String(section.text || ""),
      sectionActiveBefore: false,
      sectionRootFound: false,
      sectionRootStrategy: "",
      profileRecordCount: rows.length,
      existingPageRecordCount: 0,
      existingIdentitySignalCount: 0,
      existingIdentitySignalFields: [],
      matchedProfileIndices: [],
      missingRecordCount: 0,
      targetProfileRecordIndex: -1,
      targetSelectionReason: "",
      editorAlreadyOpen: false,
      preview: null,
      result: "",
      reason: "",
      safety: { valuesCaptured: false, savedRecordValuesLogged: false, fieldsWritten: false, saveExecuted: false, finalSubmitExecuted: false }
    };
    if (normalizeText(section.text) !== "教育背景") { trace.result = "failed"; trace.reason = "education_section_required"; return trace; }
    if (!rows.length) { trace.result = "failed"; trace.reason = "education_profile_records_missing"; return trace; }
    var nav = analyzedNavigationResolveUnique(section.selectorHint);
    if (!nav.element || nav.count !== 1) { trace.result = "failed"; trace.reason = nav.count > 1 ? "section_selector_not_unique" : "section_selector_not_found"; return trace; }
    trace.sectionActiveBefore = analyzedNavigationNodeIsActive(nav.element);
    if (plan.requireSectionActive !== false && !trace.sectionActiveBefore) { trace.result = "failed"; trace.reason = "education_section_not_active"; return trace; }

    try {
      trace.editorAlreadyOpen = Array.from(document.querySelectorAll("button,a,[role='button'],input[type='submit'],input[type='button']")).filter(isActuallyVisible).some(function (node) {
        return normalizeText(node.textContent || node.value || "") === "保存教育背景";
      });
    } catch (eEditor) {}
    if (trace.editorAlreadyOpen) { trace.result = "failed"; trace.reason = "education_editor_already_open"; return trace; }

    var sectionResolved = resolveAnalyzedEducationSectionRoot(section.text);
    trace.sectionRootFound = !!sectionResolved.root;
    trace.sectionRootStrategy = sectionResolved.strategy || "";
    if (!sectionResolved.root) { trace.result = "failed"; trace.reason = "education_section_root_not_found"; return trace; }

    var existing = scanHigherEducationExistingRecords(sectionResolved.root);
    var identities = existing.map(function (entry) { return entry.identity; });
    trace.existingPageRecordCount = existing.length;
    trace.existingIdentitySignalCount = analyzedEducationExistingIdentitySignalCount(existing);
    trace.existingIdentitySignalFields = existing.map(function (entry) {
      var identity = entry && entry.identity || {};
      return ["school", "major", "level", "degree", "startTime", "endTime"].filter(function (key) { return !!identity[key]; });
    });
    var target = selectRemainingEducationRecord(rows, identities);
    trace.matchedProfileIndices = Array.isArray(target.matchedProfileIndices) ? target.matchedProfileIndices.slice() : [];
    trace.missingRecordCount = Number(target.missingRecordCount || 0);
    trace.targetProfileRecordIndex = Number.isInteger(target.recordIndex) ? target.recordIndex : -1;
    trace.targetSelectionReason = String(target.reason || "");
    if (!target.record) {
      if (target.reason === "education_no_missing_record") { trace.result = "complete"; trace.reason = "education_no_missing_record"; return trace; }
      trace.result = "needs_review";
      trace.reason = target.reason || "education_existing_record_match_uncertain";
      return trace;
    }

    var previewPlan = {
      section: section,
      requireSectionActive: true,
      record: target.record,
      profileRecordIndex: target.recordIndex,
      profileRecordCount: rows.length,
      editorOpenTimeoutMs: Number(plan.editorOpenTimeoutMs || 4500),
      dynamicOptionTimeoutMs: Number(plan.dynamicOptionTimeoutMs || 2200)
    };
    trace.preview = await runAnalyzedEducationRecordPreviewFill(previewPlan);
    trace.safety.fieldsWritten = !!(trace.preview && trace.preview.safety && trace.preview.safety.fieldsWritten);
    trace.safety.saveExecuted = false;
    if (trace.preview && trace.preview.result === "preview_filled_left_open") {
      trace.result = "missing_record_preview_filled";
      trace.reason = "";
    } else {
      trace.result = "failed";
      trace.reason = trace.preview && trace.preview.reason || "missing_record_preview_failed";
    }
    return trace;
  }


  async function runAnalyzedEducationRepeatSaveTransaction(plan) {
    plan = plan || {};
    var section = plan.section || {};
    var rows = Array.isArray(plan.records) ? plan.records : [];
    var trace = {
      section: String(section.text || ""),
      sectionActiveBefore: false,
      sectionRootFound: false,
      profileRecordCount: rows.length,
      existingPageRecordCountBefore: 0,
      existingIdentitySignalFields: [],
      matchedProfileIndicesBefore: [],
      missingRecordCountBefore: 0,
      targetProfileRecordIndex: -1,
      preview: null,
      saveButtonFound: false,
      saveClickDispatched: false,
      saveFeedbackVerified: false,
      saveFeedbackKind: "",
      saveFeedbackDetectionStrategy: "",
      saveModalDetected: false,
      saveModalClosed: false,
      newValidationMessages: [],
      existingPageRecordCountAfter: 0,
      matchedProfileIndicesAfter: [],
      missingRecordCountAfter: 0,
      postSaveSelectionReason: "",
      targetIdentityVerified: false,
      result: "",
      reason: "",
      safety: { valuesCaptured: false, savedRecordValuesLogged: false, fieldsWritten: false, saveExecuted: false, finalSubmitExecuted: false }
    };
    if (normalizeText(section.text) !== "教育背景") { trace.result = "failed"; trace.reason = "education_section_required"; return trace; }
    if (!rows.length) { trace.result = "failed"; trace.reason = "education_profile_records_missing"; return trace; }
    var nav = analyzedNavigationResolveUnique(section.selectorHint);
    if (!nav.element || nav.count !== 1) { trace.result = "failed"; trace.reason = nav.count > 1 ? "section_selector_not_unique" : "section_selector_not_found"; return trace; }
    trace.sectionActiveBefore = analyzedNavigationNodeIsActive(nav.element);
    if (plan.requireSectionActive !== false && !trace.sectionActiveBefore) { trace.result = "failed"; trace.reason = "education_section_not_active"; return trace; }

    var sectionResolved = resolveAnalyzedEducationSectionRoot(section.text);
    trace.sectionRootFound = !!sectionResolved.root;
    if (!sectionResolved.root) { trace.result = "failed"; trace.reason = "education_section_root_not_found"; return trace; }
    var existingBefore = scanHigherEducationExistingRecords(sectionResolved.root);
    var identitiesBefore = existingBefore.map(function (entry) { return entry.identity; });
    trace.existingPageRecordCountBefore = existingBefore.length;
    trace.existingIdentitySignalFields = existingBefore.map(function (entry) {
      var identity = entry && entry.identity || {};
      return ["school", "major", "level", "degree", "startTime", "endTime"].filter(function (key) { return !!identity[key]; });
    });
    var target = selectRemainingEducationRecord(rows, identitiesBefore);
    trace.matchedProfileIndicesBefore = Array.isArray(target.matchedProfileIndices) ? target.matchedProfileIndices.slice() : [];
    trace.missingRecordCountBefore = Number(target.missingRecordCount || 0);
    trace.targetProfileRecordIndex = Number.isInteger(target.recordIndex) ? target.recordIndex : -1;
    if (!target.record) {
      if (target.reason === "education_no_missing_record") {
        trace.existingPageRecordCountAfter = trace.existingPageRecordCountBefore;
        trace.matchedProfileIndicesAfter = trace.matchedProfileIndicesBefore.slice();
        trace.missingRecordCountAfter = 0;
        trace.targetIdentityVerified = true;
        trace.result = "complete";
        trace.reason = "education_no_missing_record";
        return trace;
      }
      trace.result = "needs_review";
      trace.reason = target.reason || "education_existing_record_match_uncertain";
      return trace;
    }

    trace.preview = await runAnalyzedEducationRecordPreviewFill({
      section: section,
      requireSectionActive: true,
      record: target.record,
      profileRecordIndex: target.recordIndex,
      profileRecordCount: rows.length,
      editorOpenTimeoutMs: Number(plan.editorOpenTimeoutMs || 4500),
      dynamicOptionTimeoutMs: Number(plan.dynamicOptionTimeoutMs || 2200)
    });
    trace.safety.fieldsWritten = !!(trace.preview && trace.preview.safety && trace.preview.safety.fieldsWritten);
    if (!trace.preview || trace.preview.result !== "preview_filled_left_open") {
      trace.result = "failed";
      trace.reason = trace.preview && trace.preview.reason || "missing_record_fill_failed";
      return trace;
    }
    if (Number(trace.preview.failedFieldCount || 0) > 0) {
      trace.result = "blocked_by_fill_failure";
      trace.reason = "education_fill_readback_failed";
      return trace;
    }

    var validationBefore = collectAnalyzedNavigationValidationMessages();
    var save = findExplicitSectionSaveButton("教育背景");
    trace.saveButtonFound = !!save.element;
    if (!save.element) { trace.result = "failed"; trace.reason = save.count > 1 ? "education_save_ambiguous" : "education_save_not_found"; return trace; }
    try { trace.saveClickDispatched = !!(await safeClick(save.element)); } catch (eSave) { trace.saveClickDispatched = false; }
    if (!trace.saveClickDispatched) { trace.result = "failed"; trace.reason = "education_save_click_failed"; return trace; }
    trace.safety.saveExecuted = true;

    var feedback = await waitUntil(function () {
      var successFeedback = findAnalyzedNavigationSaveSuccessFeedback();
      if (successFeedback) return { successFeedback: successFeedback };
      var afterMessages = collectAnalyzedNavigationValidationMessages();
      var fresh = afterMessages.filter(function (text) { return validationBefore.indexOf(text) === -1; });
      if (fresh.length) return { validationMessages: fresh };
      return null;
    }, Number(plan.saveFeedbackTimeoutMs || 5000));
    if (feedback && Array.isArray(feedback.validationMessages) && feedback.validationMessages.length) {
      trace.newValidationMessages = feedback.validationMessages.slice(0, 20);
      trace.result = "blocked_by_validation";
      trace.reason = "education_save_validation_failed";
      return trace;
    }
    if (!feedback || !feedback.successFeedback) {
      trace.result = "failed";
      trace.reason = "education_save_feedback_timeout";
      return trace;
    }
    trace.saveFeedbackVerified = true;
    trace.saveFeedbackKind = feedback.successFeedback.kind || "";
    trace.saveFeedbackDetectionStrategy = feedback.successFeedback.strategy || "";
    trace.saveModalDetected = feedback.successFeedback.kind === "modal";
    if (trace.saveModalDetected) {
      var closed = await closeAnalyzedNavigationSaveSuccessModal(feedback.successFeedback.modal, Number(plan.saveModalCloseTimeoutMs || 1800));
      trace.saveModalClosed = !!closed.closed;
      if (!closed.found || !closed.clickDispatched || !closed.closed) {
        trace.result = "failed";
        trace.reason = !closed.found ? "education_save_modal_close_not_found" : (!closed.clickDispatched ? "education_save_modal_close_failed" : "education_save_modal_not_closed");
        return trace;
      }
    }

    var verified = await waitUntil(function () {
      var resolvedAfter = resolveAnalyzedEducationSectionRoot(section.text);
      if (!resolvedAfter.root) return null;
      var existingAfter = scanHigherEducationExistingRecords(resolvedAfter.root);
      if (existingAfter.length < existingBefore.length + 1) return null;
      var afterTarget = selectRemainingEducationRecord(rows, existingAfter.map(function (entry) { return entry.identity; }));
      return { existing: existingAfter, selection: afterTarget };
    }, Number(plan.postSaveVerifyTimeoutMs || 4000));
    if (!verified) {
      trace.result = "failed";
      trace.reason = "education_saved_card_not_verified";
      return trace;
    }
    trace.existingPageRecordCountAfter = verified.existing.length;
    trace.matchedProfileIndicesAfter = Array.isArray(verified.selection.matchedProfileIndices) ? verified.selection.matchedProfileIndices.slice() : [];
    trace.missingRecordCountAfter = Number(verified.selection.missingRecordCount || 0);
    trace.postSaveSelectionReason = String(verified.selection.reason || "");
    trace.targetIdentityVerified = trace.matchedProfileIndicesAfter.indexOf(target.recordIndex) !== -1;
    if (!trace.targetIdentityVerified) {
      trace.result = "failed";
      trace.reason = "education_saved_identity_not_verified";
      return trace;
    }
    trace.result = verified.selection.reason === "education_no_missing_record" ? "saved_and_complete" : "saved_and_verified";
    trace.reason = "";
    return trace;
  }

  async function navigateToResumeSection(targetSection, step) {
    var before = detectActiveResumeSection();
    var trace = { fromSection: before.detectedSection || "", targetSection: String(targetSection || ""), targetNavFound: false, navClickDispatched: false, unsavedModalDetected: false, activeSectionAfterClick: before.detectedSection || "", entered: before.detectedSection === targetSection, reason: "" };
    if (trace.entered) return trace;
    var targetNav = null;
    try {
      targetNav = Array.from(document.querySelectorAll(".resume-menu-item")).filter(isActuallyVisible).find(function (node) {
        var title = node.querySelector && node.querySelector(".resume-menu-item__title, h6");
        return normalizeSectionTitle(title && title.textContent) === normalizeSectionTitle(targetSection);
      }) || null;
    } catch (eNavFind) {}
    trace.targetNavFound = !!targetNav;
    if (!targetNav) { trace.reason = "target_nav_not_found"; return trace; }
    try {
      trace.navClickDispatched = !!(await safeClick(targetNav));
    } catch (eNavClick) {
      trace.reason = "nav_click_failed";
      return trace;
    }
    if (!trace.navClickDispatched) { trace.reason = "nav_click_failed"; return trace; }
    var outcome = await waitUntil(function () {
      if (findUnsavedResumeNavigationModal()) return { modal: true };
      var current = detectActiveResumeSection();
      return current.detectedSection === targetSection ? { entered: true, current: current.detectedSection } : null;
    }, step && (step.sectionNavigationTimeoutMs || step.timeoutMs) || 6000);
    trace.unsavedModalDetected = !!(outcome && outcome.modal);
    if (trace.unsavedModalDetected) {
      trace.navigationState = "awaiting_save_before_navigation";
      trace.moduleTransactionTrace = await completeModuleSaveAndNavigate(findUnsavedResumeNavigationModal(), trace.fromSection, targetSection, step);
      var transactionAfter = detectActiveResumeSection();
      trace.activeSectionAfterClick = transactionAfter.detectedSection || "";
      trace.entered = trace.moduleTransactionTrace.result === "success" && trace.activeSectionAfterClick === targetSection;
      trace.reason = trace.entered ? "" : trace.moduleTransactionTrace.reason;
      return trace;
    }
    var after = detectActiveResumeSection();
    trace.activeSectionAfterClick = after.detectedSection || "";
    trace.entered = !!(outcome && outcome.entered && after.detectedSection === targetSection);
    trace.reason = trace.entered ? "" : "section_change_timeout";
    return trace;
  }

  function writeHigherEducationTrace(update) {
    try {
      var trace = JSON.parse(document.documentElement.getAttribute("data-af-zhaopin-higher-education-trace") || "{}");
      trace = trace && typeof trace === "object" ? trace : {};
      Object.keys(update || {}).forEach(function (key) { trace[key] = update[key]; });
      if (!Array.isArray(trace.records)) trace.records = [];
      document.documentElement.setAttribute("data-af-zhaopin-higher-education-trace", JSON.stringify(trace));
    } catch (e) {}
  }

  function appendHigherEducationFieldTrace(entry) {
    try {
      var trace = JSON.parse(document.documentElement.getAttribute("data-af-zhaopin-higher-education-trace") || "{}");
      trace = trace && typeof trace === "object" ? trace : {};
      if (!Array.isArray(trace.records)) trace.records = [];
      trace.records.push(entry);
      document.documentElement.setAttribute("data-af-zhaopin-higher-education-trace", JSON.stringify(trace));
    } catch (e) {}
  }

  function findHigherEducationLabel(scope, labelText) {
    var wanted = normalizeHigherEducationLabel(labelText);
    return higherEducationLabelNodes(scope).find(function (node) {
      return normalizeHigherEducationLabel(node.textContent) === wanted;
    }) || null;
  }

  function resolveHigherEducationFieldItem(label, scope) {
    if (!label || !scope || scope === document) return { element: null, strategy: "none" };
    var parent = label.parentElement;
    if (parent && parent.matches && parent.matches(".el-form-item") && scope.contains(parent)) {
      return { element: parent, strategy: "direct_parent" };
    }
    var closest = null;
    try { closest = label.closest && label.closest(".el-form-item"); } catch (e) {}
    if (closest && scope.contains(closest)) return { element: closest, strategy: "closest" };
    return { element: null, strategy: "none" };
  }

  function resolveControlFromLabel(label, expectedType, scope) {
    var result = { element: null, fieldItem: null, fieldItemStrategy: "none", content: null, contentControlCount: 0, candidates: [], reason: "field_item_not_resolved" };
    if (!label || !scope || scope === document || !scope.contains(label)) return result;
    var fieldItemResolution = resolveHigherEducationFieldItem(label, scope);
    var fieldItem = fieldItemResolution.element;
    if (!fieldItem) return result;
    result.fieldItem = fieldItem;
    result.fieldItemStrategy = fieldItemResolution.strategy;
    var content = null;
    try { content = fieldItem.querySelector(":scope > .el-form-item__content") || fieldItem.querySelector(".el-form-item__content"); } catch (eContent) {
      try { content = fieldItem.querySelector(".el-form-item__content"); } catch (eFallbackContent) {}
    }
    result.content = content;
    if (!content) { result.reason = "field_content_not_resolved"; return result; }
    var candidates = [];
    try {
      if (expectedType === "date") candidates = Array.from(content.querySelectorAll(".el-date-editor, input[type='date'], .el-date-editor input, input[readonly][placeholder*='时间'], input[readonly][placeholder*='日期']"));
      else if (expectedType === "choice") candidates = Array.from(content.querySelectorAll(".el-select, .el-cascader, [role='combobox'], select"));
      else candidates = Array.from(content.querySelectorAll("textarea, input:not([type='hidden']):not([type='checkbox']):not([type='radio'])")).filter(function (candidate) {
        return !(candidate.closest && candidate.closest(".el-select, .el-cascader, .el-date-editor"));
      });
      candidates = candidates.filter(isVisible);
    } catch (eCandidates) {}
    result.candidates = candidates;
    result.contentControlCount = candidates.length;
    var selected = candidates.find(function (candidate) {
      if (expectedType === "text") return !candidate.disabled && !candidate.readOnly;
      return true;
    }) || null;
    result.element = selected;
    result.reason = selected ? "" : "no_compatible_control";
    return result;
  }

  var higherEducationFieldItemIds = typeof WeakMap === "function" ? new WeakMap() : null;
  var higherEducationFieldItemIdSeed = 0;
  var higherEducationRuntimeBindings = new Map();
  function higherEducationBindingKey(recordIndex, fieldKey) {
    return String(Number.isInteger(recordIndex) ? recordIndex : 0) + ":" + String(fieldKey || "");
  }
  function setHigherEducationRuntimeBinding(recordIndex, fieldKey, binding) {
    higherEducationRuntimeBindings.set(higherEducationBindingKey(recordIndex, fieldKey), binding);
  }
  function getHigherEducationRuntimeBinding(recordIndex, fieldKey) {
    return higherEducationRuntimeBindings.get(higherEducationBindingKey(recordIndex, fieldKey)) || null;
  }
  function higherEducationFieldItemId(fieldItem) {
    if (!fieldItem) return "";
    if (!higherEducationFieldItemIds) return "field-item-unknown";
    if (!higherEducationFieldItemIds.has(fieldItem)) higherEducationFieldItemIds.set(fieldItem, "field-item-" + (++higherEducationFieldItemIdSeed));
    return higherEducationFieldItemIds.get(fieldItem);
  }

  function higherEducationTypeCompatible(expectedType, detectedType) {
    var type = String(detectedType || "");
    if (expectedType === "date") return type === "date";
    if (expectedType === "choice") return /^(?:select|search|autocomplete|multiSelect|radio)$/.test(type);
    return /^(?:text|textarea|contentEditable|search|autocomplete)$/.test(type);
  }

  function resolveHigherEducationGeometryBinding(scope, label, expectedType) {
    if (!scope || !label) return null;
    var labelRect = label.getBoundingClientRect();
    var candidates = enumerateInteractiveControls(scope).filter(function (entry) {
      return entry.visible && higherEducationTypeCompatible(expectedType, entry.detectedType);
    }).map(function (entry) {
      var rect = entry.element.getBoundingClientRect();
      var below = rect.top >= labelRect.top - 4;
      var horizontal = Math.abs(rect.left - labelRect.left);
      var vertical = Math.max(0, rect.top - labelRect.bottom);
      var overlap = Math.max(0, Math.min(rect.right, labelRect.right) - Math.max(rect.left, labelRect.left));
      return { entry: entry, score: (below ? 1000 : -1000) + Math.min(300, overlap * 3) - vertical * 2 - horizontal };
    }).filter(function (candidate) { return candidate.score > 0; });
    candidates.sort(function (a, b) { return b.score - a.score; });
    return candidates.length ? candidates[0].entry : null;
  }

  function resolveFieldBinding(matcher, scope, labelText, expectedType, fieldKey) {
    var labels = allHigherEducationLabelNodes(scope, labelText);
    var resolverTrace = { fieldKey: String(fieldKey || ""), specialResolverAttempted: false, specialResolverFound: false, coreMatcherAttempted: false, coreMatcherFound: false, coreMatcherDetectedType: "", resultInsideActiveEditor: false, geometryFallbackAttempted: false, finalSource: "", finalDetectedType: "", finalControlFound: false, reason: "" };
    var candidates = labels.map(function (label, index) {
      var structure = resolveControlFromLabel(label, expectedType, scope);
      var matched = { element: null, type: null };
      resolverTrace.coreMatcherAttempted = true;
      try { matched = matcher && matcher.findElementAndTypeByLabel(label) || matched; } catch (eMatcher) { resolverTrace.reason = "core_matcher_exception"; }
      if (matched.element) {
        resolverTrace.coreMatcherFound = true;
        resolverTrace.coreMatcherDetectedType = String(matched.type || "");
      }
      var inScope = !!(matched.element && scope && scope.contains(matched.element));
      if (inScope) resolverTrace.resultInsideActiveEditor = true;
      var compatible = inScope && isActuallyVisible(matched.element) && higherEducationTypeCompatible(expectedType, matched.type);
      var binding = { element: compatible ? matched.element : null, detectedType: matched.type || "", fieldItem: structure.fieldItem, fieldItemStrategy: structure.fieldItemStrategy, content: structure.content, contentControlCount: structure.contentControlCount, candidates: matched.element ? [matched.element] : [], reason: compatible ? "" : (matched.element ? (inScope ? "detected_type_incompatible" : "matcher_control_outside_scope") : "core_matcher_control_not_found"), source: "element_matcher" };
      var fieldItemVisible = !!(binding.fieldItem && isActuallyVisible(binding.fieldItem));
      var visibleControls = binding.candidates.filter(isActuallyVisible);
      return { index: index, label: label, binding: binding, fieldItemVisible: fieldItemVisible, visibleControls: visibleControls };
    });
    var uniqueCandidates = [];
    var seenFieldItems = [];
    candidates.forEach(function (candidate) {
      var fieldItem = candidate.binding.fieldItem;
      if (!fieldItem || seenFieldItems.indexOf(fieldItem) !== -1) return;
      seenFieldItems.push(fieldItem);
      uniqueCandidates.push(candidate);
    });
    var usable = uniqueCandidates.filter(function (candidate) { return candidate.fieldItemVisible && candidate.visibleControls.length > 0 && candidate.binding.element && isActuallyVisible(candidate.binding.element); });
    usable.sort(function (a, b) {
      var aRect = a.binding.fieldItem.getBoundingClientRect(), bRect = b.binding.fieldItem.getBoundingClientRect();
      var aArea = aRect.width * aRect.height, bArea = bRect.width * bRect.height;
      return aArea - bArea || b.visibleControls.length - a.visibleControls.length || b.index - a.index;
    });
    var selected = usable[0] || null;
    if (!selected && labels.length) {
      resolverTrace.geometryFallbackAttempted = true;
      for (var geometryIndex = 0; geometryIndex < labels.length && !selected; geometryIndex += 1) {
        if (!isActuallyVisible(labels[geometryIndex])) continue;
        var geometryEntry = resolveHigherEducationGeometryBinding(scope, labels[geometryIndex], expectedType);
        if (geometryEntry) {
          var geometryStructure = resolveControlFromLabel(labels[geometryIndex], expectedType, scope);
          selected = { index: geometryIndex, label: labels[geometryIndex], fieldItemVisible: !!(geometryStructure.fieldItem && isActuallyVisible(geometryStructure.fieldItem)), visibleControls: [geometryEntry.element], binding: { element: geometryEntry.element, detectedType: geometryEntry.detectedType, fieldItem: geometryStructure.fieldItem, fieldItemStrategy: geometryStructure.fieldItemStrategy, content: geometryStructure.content, contentControlCount: geometryStructure.contentControlCount, candidates: [geometryEntry.element], reason: "", source: "active_editor_geometry" } };
        }
      }
    }
    resolverTrace.finalSource = selected ? String(selected.binding.source || "element_matcher") : "";
    resolverTrace.finalDetectedType = selected ? String(selected.binding.detectedType || "") : "";
    resolverTrace.finalControlFound = !!(selected && selected.binding.element);
    resolverTrace.reason = resolverTrace.finalControlFound ? "" : (resolverTrace.reason || (resolverTrace.coreMatcherFound ? "core_matcher_result_rejected" : "core_matcher_control_not_found"));
    var candidateTrace = {
      fieldKey: String(fieldKey || ""), normalizedLabel: normalizeHigherEducationLabel(labelText), matchingLabelCount: labels.length, uniqueFieldItemCount: uniqueCandidates.length,
      candidates: candidates.map(function (candidate) {
        var item = candidate.binding;
        var ancestorHidden = !!(candidate.label && !isActuallyVisible(candidate.label));
        return { index: candidate.index, visible: isActuallyVisible(candidate.label), connected: candidate.label.isConnected !== false, fieldItemResolved: !!item.fieldItem, fieldItemVisible: candidate.fieldItemVisible, contentResolved: !!item.content, compatibleControlCount: item.candidates.length, visibleCompatibleControlCount: candidate.visibleControls.length, fieldItemClass: String(item.fieldItem && item.fieldItem.className || ""), ancestorHidden: ancestorHidden, fieldItemId: higherEducationFieldItemId(item.fieldItem) };
      }),
      selectedCandidateIndex: selected ? selected.index : -1,
      selectedFieldItemId: selected ? higherEducationFieldItemId(selected.binding.fieldItem) : "",
      selectedControlTag: selected ? String(selected.binding.element.tagName || "").toLowerCase() : "",
      selectedControlClass: selected ? String(selected.binding.element.className || "") : "",
      selectedDetectedType: selected ? String(selected.binding.detectedType || "") : ""
    };
    try {
      var trace = JSON.parse(document.documentElement.getAttribute("data-af-zhaopin-higher-education-trace") || "{}");
      if (!Array.isArray(trace.labelCandidateTrace)) trace.labelCandidateTrace = [];
      trace.labelCandidateTrace.push(candidateTrace);
      if (!Array.isArray(trace.higherEducationBindingResolverTrace)) trace.higherEducationBindingResolverTrace = [];
      trace.higherEducationBindingResolverTrace.push(resolverTrace);
      if (!selected) {
        var diagnosticItem = candidates.find(function (candidate) { return candidate.binding.fieldItem; });
        var diagnosticRoot = diagnosticItem && diagnosticItem.binding.fieldItem;
        var describeNode = function (node) { return node ? { tag: String(node.tagName || "").toLowerCase(), className: String(node.className || "") } : null; };
        var describeStructure = function (node, depth) {
          if (!node || depth > 4) return null;
          return { tag: String(node.tagName || "").toLowerCase(), className: String(node.className || ""), role: String(node.getAttribute && node.getAttribute("role") || ""), type: String(node.type || node.getAttribute && node.getAttribute("type") || ""), tabindex: String(node.getAttribute && node.getAttribute("tabindex") || ""), ariaExpanded: String(node.getAttribute && node.getAttribute("aria-expanded") || ""), ariaHaspopup: String(node.getAttribute && node.getAttribute("aria-haspopup") || ""), hasShadowRoot: !!node.shadowRoot, children: Array.from(node.children || []).slice(0, 10).map(function (child) { return describeStructure(child, depth + 1); }) };
        };
        if (!Array.isArray(trace.fieldStructureTrace)) trace.fieldStructureTrace = [];
        trace.fieldStructureTrace.push({
          fieldKey: String(fieldKey || ""),
          fieldItemDescendantInputCount: diagnosticRoot ? diagnosticRoot.querySelectorAll("input").length : 0,
          fieldItemDescendantSelectCount: diagnosticRoot ? diagnosticRoot.querySelectorAll("select, .el-select, .el-cascader, [role='combobox']").length : 0,
          fieldItemDescendantDateCount: diagnosticRoot ? diagnosticRoot.querySelectorAll(".el-date-editor, input[type='date']").length : 0,
          directChildren: diagnosticRoot ? Array.from(diagnosticRoot.children).map(describeNode).slice(0, 12) : [],
          contentStructure: diagnosticItem && diagnosticItem.binding.content ? describeStructure(diagnosticItem.binding.content, 0) : null,
          previousSibling: describeNode(diagnosticRoot && diagnosticRoot.previousElementSibling),
          nextSibling: describeNode(diagnosticRoot && diagnosticRoot.nextElementSibling)
        });
      }
      document.documentElement.setAttribute("data-af-zhaopin-higher-education-trace", JSON.stringify(trace));
    } catch (eTrace) {}
    return selected ? { label: selected.label, control: selected.binding.element, detectedType: selected.binding.detectedType, expectedType: expectedType, source: selected.binding.source || "element_matcher", fieldItem: selected.binding.fieldItem, content: selected.binding.content, binding: selected.binding, trace: candidateTrace } : { label: labels[0] || null, control: null, detectedType: "", expectedType: expectedType, source: "", fieldItem: null, content: null, binding: null, trace: candidateTrace };
  }

  function findHigherEducationTextControl(label, scope) {
    return resolveControlFromLabel(label, "text", scope).element;
  }

  async function fillHigherEducationText(matcher, label, value, item, scope) {
    var traceBase = {
      recordIndex: Number.isInteger(item && item.__recordIndex) ? item.__recordIndex : 0,
      fieldKey: String(item && item.field || ""), label: String(item && item.label || ""),
      valueAvailable: hasMeaningfulValue(value), scopeResolved: !!scope,
      labelFound: !!label, controlFound: false, controlType: "text",
      alreadyCorrect: false, executionPath: "direct_scoped_text", committed: false, reason: ""
    };
    if (!scope) { traceBase.reason = "scope_not_resolved"; appendHigherEducationFieldTrace(traceBase); return false; }
    if (!label) { traceBase.reason = "label_not_found"; appendHigherEducationFieldTrace(traceBase); return false; }
    var resolvedFieldBinding = getHigherEducationRuntimeBinding(item && item.__recordIndex || 0, item && item.field);
    var binding = resolvedFieldBinding && resolvedFieldBinding.binding || resolveControlFromLabel(label, "text", scope);
    var control = resolvedFieldBinding && resolvedFieldBinding.control || binding.element;
    traceBase.controlType = resolvedFieldBinding && resolvedFieldBinding.detectedType || binding.detectedType || "text";
    traceBase.controlFound = !!control;
    traceBase.controlType = control && control.tagName && control.tagName.toLowerCase() === "textarea" ? "textarea" : "text";
    traceBase.labelControlTrace = { fieldKey: traceBase.fieldKey, labelTag: String(label.tagName || "").toLowerCase(), labelClass: String(label.className || ""), parentTag: String(label.parentElement && label.parentElement.tagName || "").toLowerCase(), parentClass: String(label.parentElement && label.parentElement.className || ""), fieldItemResolved: !!binding.fieldItem, fieldItemResolutionStrategy: binding.fieldItemStrategy, contentResolved: !!binding.content, contentControlCount: binding.contentControlCount, candidateControlCount: binding.candidates.length, expectedType: "text", selectedTag: String(control && control.tagName || "").toLowerCase(), selectedClass: String(control && control.className || ""), reason: binding.reason || "" };
    if (!control) { traceBase.reason = "control_not_found"; appendHigherEducationFieldTrace(traceBase); return false; }
    var target = String(value == null ? "" : value);
    if (normalizeText(control.value) === normalizeText(target)) {
      traceBase.alreadyCorrect = true; traceBase.committed = true; traceBase.executionPath = "already_correct";
      appendHigherEducationFieldTrace(traceBase); return true;
    }
    if (!hasMeaningfulValue(value)) { traceBase.reason = "value_unavailable"; appendHigherEducationFieldTrace(traceBase); return false; }
    var detectedTextType = resolvedFieldBinding && resolvedFieldBinding.detectedType || binding.detectedType || "text";
    var wrote = await AF.FormHandler.fillFormElement(control, target, detectedTextType);
    await sleep(350);
    var liveBinding = resolveFieldBinding(matcher, scope, item.label, "text", item.field);
    var liveControl = liveBinding.control;
    traceBase.committed = !!(wrote && liveControl && normalizeText(liveControl.value) === normalizeText(target));
    traceBase.reason = traceBase.committed ? "" : "commit_failed";
    appendHigherEducationFieldTrace(traceBase);
    return traceBase.committed;
  }

  function resolveReadyElement(step) {
    if (step && step.higherEducationVariant === true) {
      var higherReady = resolveHigherEducationEditorScope(step);
      if (higherReady.scope) return higherReady.scope;
    }
    if (step && step.wizardSectionTitle) {
      var headingSelector = step.wizardHeadingSelector || "h5";
      var headings = [];
      try { headings = Array.from(document.querySelectorAll(headingSelector)).filter(isVisible); } catch (e) {}
      var wantedHeading = normalizeText(step.wizardSectionTitle);
      var heading = headings.find(function (node) {
        return normalizeText(node.textContent) === wantedHeading;
      });
      if (!heading) return null;
      if (Number.isInteger(step.repeatIndex) && step.scopeSelector) {
        try {
          return Array.from(document.querySelectorAll(step.scopeSelector)).filter(isVisible)[step.repeatIndex] || null;
        } catch (e2) {
          return null;
        }
      }
      return heading;
    }
    var ready = null;
    var card = findStepCard(step, document);
    var searchRoot = card || document;
    if (step.readySelector) {
      var readyCandidates = queryVisibleIncludingRoot(searchRoot, step.readySelector);
      if (!readyCandidates.length && searchRoot !== document && step.strictReadyWithinCard !== true) {
        readyCandidates = queryVisibleIncludingRoot(document, step.readySelector);
      }
      ready = pickBestVisibleCandidate(readyCandidates, step);
    }
    else if (step.scopeSelector) {
      var scopeCandidates = queryVisibleIncludingRoot(searchRoot, step.scopeSelector);
      if (!scopeCandidates.length && searchRoot !== document && step.strictReadyWithinCard !== true) {
        scopeCandidates = queryVisibleIncludingRoot(document, step.scopeSelector);
      }
      ready = pickBestVisibleCandidate(scopeCandidates, step);
    }
    else ready = findTrigger(step);
    if ((!ready || !isVisible(ready)) && step && Array.isArray(step.semanticScopeLabels)) {
      try {
        var semanticRoot = card || document;
        var semanticForms = Array.from(semanticRoot.querySelectorAll("form, .apply-form--edit, .apply-form" )).filter(isVisible);
        ready = semanticForms.find(function (form) {
          var text = normalizeText(form.textContent);
          return step.semanticScopeLabels.filter(function (label) { return text.indexOf(normalizeText(label)) !== -1; }).length >= 2;
        }) || null;
      } catch (eSemanticReady) {}
    }
    if (!ready || !isVisible(ready)) return null;
    if (step.readyText && normalizeText(ready.textContent).indexOf(normalizeText(step.readyText)) === -1) return null;
    if (step.readyEditableSelector) {
      var editableRoot = card || ready || document;
      var editable = null;
      try {
        editable = Array.from(editableRoot.querySelectorAll(step.readyEditableSelector)).find(isVisible) || null;
      } catch (e3) {}
      if (!editable) return null;
    }
    if (step.activeSelector) {
      var active = document.querySelector(step.activeSelector);
      if (!active || !isVisible(active)) return null;
    }
    return ready;
  }

  function resolveStepScope(step, ready) {
    if (step && step.higherEducationVariant === true) {
      var higherScope = resolveHigherEducationEditorScope(step);
      return higherScope.scope || null;
    }
    if (step && step.cardAsScope) {
      var cardScope = findStepCard(step, document) || ready || null;
      // Saved Ping An cards keep their disabled form DOM beside the active
      // edit-mode form. Using the whole cv-module as scope makes label matching
      // select those stale controls first. Repeated campus steps must fill only
      // the single currently visible editor.
      if (cardScope && step.useVisibleRepeatEditorAsScope === true && step.repeatReadySelector) {
        try {
          if (step.activeRepeatEditorSelector) {
            var activeEditors = Array.from(cardScope.querySelectorAll(step.activeRepeatEditorSelector)).filter(function (editor) {
              var style = window.getComputedStyle ? getComputedStyle(editor) : null;
              return (!style || style.display !== "none" && style.visibility !== "hidden") &&
                editor.offsetWidth > 0 && editor.offsetHeight > 0;
            });
            var activeEditor = activeEditors[activeEditors.length - 1] || null;
            var activeEditorForm = activeEditor && activeEditor.querySelector("form.el-form.resume, form");
            if (activeEditorForm) return activeEditorForm;
            if (activeEditor) return activeEditor;
            // 保存重绘期间，新编辑器可能已替换到新的栏目节点，
            // 而 cardScope 还是上一次解析到的旧节点。明确允许的重复步骤
            // 必须回到当前页面重新取最后一个可见编辑器。
            if (step.repeatReadyGlobalFallback === true) {
              var globalActiveEditors = Array.from(document.querySelectorAll(step.activeRepeatEditorSelector)).filter(function (editor) {
                var globalStyle = window.getComputedStyle ? getComputedStyle(editor) : null;
                return (!globalStyle || globalStyle.display !== "none" && globalStyle.visibility !== "hidden") &&
                  editor.offsetWidth > 0 && editor.offsetHeight > 0;
              });
              var globalActiveEditor = globalActiveEditors[globalActiveEditors.length - 1] || null;
              var globalActiveForm = globalActiveEditor && globalActiveEditor.querySelector("form.el-form.resume, form");
              if (globalActiveForm) return globalActiveForm;
              if (globalActiveEditor) return globalActiveEditor;
            }
          }
          var visibleEditorScope = Array.from(cardScope.querySelectorAll(step.repeatReadySelector)).filter(isVisible).find(function (node) {
            return node.matches && node.matches("form") || node.closest && node.closest("form.el-form.resume, .edit-mode form");
          });
          if (visibleEditorScope) {
            return visibleEditorScope.matches && visibleEditorScope.matches("form")
              ? visibleEditorScope
              : (visibleEditorScope.closest("form.el-form.resume, .edit-mode form") || visibleEditorScope);
          }
        } catch (eVisibleEditorScope) {}
      }
      return cardScope;
    }
    if (!step || !step.scopeSelector) return ready || null;
    var card = findStepCard(step, document);
    var root = card || document;
    try {
      if (ready && ready.matches && ready.matches(step.scopeSelector) && isVisible(ready)) return ready;
      var visibleScopes = queryVisibleIncludingRoot(root, step.scopeSelector);
      if (!visibleScopes.length && root !== document) visibleScopes = queryVisibleIncludingRoot(document, step.scopeSelector);
      if (!visibleScopes.length && Array.isArray(step.semanticScopeLabels)) {
        var semanticCandidates = Array.from(root.querySelectorAll("form, .apply-form--edit, .apply-form")).filter(isVisible);
        var semanticScope = semanticCandidates.find(function (candidate) {
          var candidateText = normalizeText(candidate.textContent);
          return step.semanticScopeLabels.filter(function (label) {
            return candidateText.indexOf(normalizeText(label)) !== -1;
          }).length >= 2;
        });
        if (semanticScope) return semanticScope;
      }
      if (step.scopeByReadyText || step.readyText) {
        var matchedScope = pickBestVisibleCandidate(visibleScopes, step);
        if (matchedScope) return matchedScope;
      }
      // 中信教育的 scopeSelector 是唯一的外层 #jyjlform，真正需要按
      // repeatIndex 定位的是其内部 [way-scope] 卡片。若此处对外层表单
      // 再按第 N 条索引，第二条开始就会得到 null，后续行卡片逻辑永远
      // 无法执行。
      if (Number.isInteger(step.repeatIndex) && step.useRepeatRowScopeByIndex !== true && step.sharedRepeatScope !== true) {
        return visibleScopes[step.repeatIndex] || null;
      }
      return pickBestVisibleCandidate(visibleScopes, step);
    } catch (e) {
      return null;
    }
  }

  async function closeStepEditor(step) {
    if (!step || !step.diagnosticCloseSelector) return;
    var card = findStepCard(step, document);
    var root = card || document;
    try {
      var closeButton = Array.from(root.querySelectorAll(step.diagnosticCloseSelector)).find(isVisible);
      if (closeButton) {
        await safeClick(closeButton);
        await sleep(150);
      }
    } catch (e) {}
  }

  function hasMeaningfulValue(value) {
    if (value === null || value === undefined) return false;
    if (Array.isArray(value)) return value.some(hasMeaningfulValue);
    if (value && typeof value === "object") {
      return Object.keys(value).some(function (field) {
        return hasMeaningfulValue(value[field]);
      });
    }
    return String(value).trim() !== "";
  }

  function hasResumeData(resume, category) {
    if (!category) return true;
    var categories = Array.isArray(category) ? category : [category];
    return categories.some(function (key) {
      return hasMeaningfulValue(resume && resume[key]);
    });
  }

  function currentPageHeadingText() {
    var heading = null;
    try { heading = Array.from(document.querySelectorAll("h1")).find(isVisible) || null; } catch (eH1) {}
    if (!heading) {
      var candidates = [];
      try { candidates = Array.from(document.querySelectorAll(".rtit, .right h1, [class*='title']")).filter(isVisible); } catch (e) {}
      heading = candidates.find(function (node) {
        var text = normalizeText(node && node.textContent);
        return text && text.length <= 40;
      }) || null;
    }
    return normalizeText(heading && heading.textContent);
  }

  function stepMatchesCurrentPage(step) {
    if (!step || !step.pageHeadingText) return true;
    var current = currentPageHeadingText();
    var wanted = Array.isArray(step.pageHeadingText) ? step.pageHeadingText : [step.pageHeadingText];
    return wanted.some(function (text) {
      text = normalizeText(text);
      return text && current && (current === text || current.indexOf(text) !== -1 || text.indexOf(current) !== -1);
    });
  }

  function findVisibleStepEditor(step, root) {
    root = root || findStepCard(step, document) || document;
    var selector = step && step.repeatReadySelector ||
      "form.el-form.resume, .edit-mode form, .edit-mode input:not([type='hidden']), .edit-mode textarea";
    try {
      return Array.from(root.querySelectorAll(selector)).find(isVisible) || null;
    } catch (e) {
      return null;
    }
  }

  function resolveStrictRepeatAddRoot(step) {
    if (!step || step.strictRepeatAddRoot !== true) return findStepCard(step, document) || null;
    var selector = step.sectionRootSelector || ".cv-module";
    var wanted = step.cardTitle || step.name;
    var sections = [];
    try { sections = Array.from(document.querySelectorAll(selector)); } catch (e) { return null; }
    return sections.find(function (section) {
      var title = null;
      try {
        title = section.querySelector(step.cardTitleSelector || ".title-wrapper .title, .modules-title .title, .title");
      } catch (eTitle) {}
      return title && titleMatchesSection(title.textContent, wanted);
    }) || null;
  }

  function editorHasUserValue(editor) {
    if (!editor) return false;
    try {
      var controls = Array.from(editor.querySelectorAll(
        "input:not([type='hidden']):not([type='checkbox']):not([type='radio']), textarea, select"
      )).filter(isVisible);
      return controls.some(function (control) {
        return normalizeText(control.value || control.textContent || "") !== "";
      });
    } catch (e) {
      return false;
    }
  }

  async function closeEmptyRepeatEditorAfterLast(step) {
    if (!step || step.closeEmptyRepeatEditorAfterLast !== true || !step.isLastRepeatStep) return false;
    var root = resolveStrictRepeatAddRoot(step) || findStepCard(step, document);
    if (!root) return false;
    var requiredCount = Number(step.repeatTotal || 0);
    var savedCount = resolveExistingRepeatCards(step, root).length;
    if (!requiredCount || savedCount < requiredCount) return false;
    var emptyEditor = await waitUntil(function () {
      var editors = [];
      try {
        editors = Array.from(root.querySelectorAll(
          step.activeRepeatEditorSelector || ".item > .item-module > .edit-mode"
        )).filter(isVisible).reverse();
      } catch (eEditors) {}
      return editors.find(function (editor) { return !editorHasUserValue(editor); }) || null;
    }, step.closeEmptyRepeatEditorTimeoutMs || 1400);
    if (!emptyEditor) return false;
    var cancelButton = findByText(
      emptyEditor,
      step.closeEmptyRepeatEditorText || ["取消"],
      step.closeEmptyRepeatEditorButtonSelector || "button, a, [role='button']"
    );
    if (!cancelButton) return false;
    await safeClick(cancelButton);
    await sleep(step.closeEmptyRepeatEditorWaitMs || 250);
    return true;
  }

  async function removeExtraExistingCardsAfterLast(step) {
    if (!step || step.removeExtraExistingCardsAfterLast !== true || !step.isLastRepeatStep) return 0;
    if (!step.existingCardSelector || !step.existingDeleteActionSelector) return 0;
    var targetCount = Number(step.repeatTotal || 0);
    if (!Number.isInteger(targetCount) || targetCount < 0) return 0;
    var removed = 0;
    for (var attempt = 0; attempt < 20; attempt++) {
      var root = step.repeatAddRootSelector
        ? document.querySelector(step.repeatAddRootSelector)
        : findStepCard(step, document);
      if (!root) throw new Error("找不到重复经历栏目，无法核对历史卡片数量");
      var cards = resolveExistingRepeatCards(step, root);
      if (cards.length <= targetCount) return removed;

      // 从最后一张多余卡片开始删除，前 N 张已经按当前简历顺序覆盖完成。
      // 只在明确配置了站点卡片、编辑和删除边界时执行，空白表单路径不会进入。
      var deleteStep = Object.assign({}, step, { updateExistingIndex: cards.length - 1 });
      if (!await openExistingRepeatEditor(deleteStep)) {
        throw new Error("历史卡片数量多于当前简历，但未能打开第" + cards.length + "张卡片");
      }
      var editor = null;
      try {
        editor = Array.from(document.querySelectorAll(
          step.activeRepeatEditorSelector || step.scopeSelector
        )).filter(isVisible).pop() || null;
      } catch (eEditor) {}
      if (!editor) editor = resolveReadyElement(step) || root;
      var deleteAction = null;
      try {
        deleteAction = Array.from(editor.querySelectorAll(step.existingDeleteActionSelector)).find(isVisible) || null;
      } catch (eDeleteSelector) {}
      if (!deleteAction) {
        deleteAction = findByText(editor, step.existingDeleteText || ["删除"], "button, a, span, [role='button']");
      }
      if (!deleteAction) throw new Error("已打开多余历史卡片，但找不到删除按钮");
      await safeClick(deleteAction);
      await sleep(step.waitAfterDeleteClickMs == null ? 220 : step.waitAfterDeleteClickMs);

      var confirmDialog = null;
      try {
        confirmDialog = Array.from(document.querySelectorAll(
          step.deleteConfirmDialogSelector || ".ivu-modal-wrap, .ivu-modal-confirm, .s-dialog, [role='dialog']"
        )).filter(isVisible).filter(function (node) {
          return /删除|确认/.test(normalizeText(node.textContent));
        }).pop() || null;
      } catch (eConfirmDialog) {}
      if (confirmDialog) {
        var confirmButton = findByText(
          confirmDialog,
          step.deleteConfirmText || ["确定", "确认", "确 定"],
          "button, a, [role='button']"
        );
        if (!confirmButton) throw new Error("删除历史卡片时出现确认弹窗，但找不到确认按钮");
        await safeClick(confirmButton);
        await sleep(step.waitAfterDeleteConfirmMs == null ? 280 : step.waitAfterDeleteConfirmMs);
      }

      var decreased = await waitUntil(function () {
        var liveRoot = step.repeatAddRootSelector
          ? document.querySelector(step.repeatAddRootSelector)
          : findStepCard(step, document);
        if (!liveRoot) return null;
        return resolveExistingRepeatCards(step, liveRoot).length < cards.length ? true : null;
      }, step.deleteTimeoutMs || 5000);
      if (!decreased) throw new Error("点击删除后历史卡片数量没有减少");
      removed += 1;
    }
    throw new Error("历史卡片数量异常，已停止继续删除");
  }

  async function activateStep(step) {
    // 已存在的同页重复表单按索引直接填写，避免再次点击新增后只打开空卡片。
    if (step && step.useRepeatRowScopeByIndex === true && Number.isInteger(step.repeatIndex) && step.rowScopeSelector) {
      try {
        var indexedRoot = step.repeatAddRootSelector ? document.querySelector(step.repeatAddRootSelector) : document;
        var resolveIndexedRow = function () {
          var liveRoot = step.repeatAddRootSelector ? document.querySelector(step.repeatAddRootSelector) : indexedRoot;
          if (!liveRoot) return null;
          var indexedRows = Array.from(liveRoot.querySelectorAll(step.rowScopeSelector)).filter(isVisible);
          return indexedRows[step.repeatIndex] || null;
        };
        var indexedRow = resolveIndexedRow();
        if (!indexedRow && step.waitForRepeatRowByIndex === true && step.repeatIndex > 0) {
          indexedRow = await waitUntil(resolveIndexedRow, step.repeatRowIndexTimeoutMs || step.timeoutMs || 7000);
        }
        if (indexedRow) return indexedRow;
        if (step.waitForRepeatRowByIndex === true && step.repeatIndex > 0) {
          throw new Error("未等到第" + (step.repeatIndex + 1) + "张联动卡片：" + (step.name || step.category || "重复经历"));
        }
      } catch (eIndexedRepeat) {
        if (step.waitForRepeatRowByIndex === true) throw eIndexedRepeat;
      }
    }
    if (step && step.wizardSectionTitle) {
      var wizardReady = resolveReadyElement(step);
      // 重复向导条目即使栏目仍处于打开状态，也必须先点击“添加”创建新卡片。
      if (wizardReady && !(Number.isInteger(step.repeatIndex) && step.repeatIndex > 0 && step.wizardAddText)) return wizardReady;
      if (Number.isInteger(step.repeatIndex) && step.wizardAddText) {
        var headingSelector = step.wizardHeadingSelector || "h5";
        var heading = Array.from(document.querySelectorAll(headingSelector)).filter(isVisible).find(function (node) {
          // 招商银行空模块把“添加”按钮放在 .item-name 标题节点内部，
          // textContent 因而是“实践经历添加”而不是单独的“实践经历”。
          // 复用栏目标题匹配，既允许按钮附加文本，也保留长度边界，禁止
          // 误把包含大量其它模块文本的外层容器当成当前栏目。
          return titleMatchesSection(node.textContent, step.wizardSectionTitle);
        });
        if (!heading) throw new Error("向导当前栏目不是：" + step.wizardSectionTitle);
        var wizardAddRoot = step.wizardSectionRootSelector && heading.closest
          ? heading.closest(step.wizardSectionRootSelector)
          : null;
        wizardAddRoot = wizardAddRoot || document;
        var addButton = null;
        if (step.wizardAddSelector) {
          try {
            addButton = Array.from(wizardAddRoot.querySelectorAll(step.wizardAddSelector)).find(isVisible) || null;
          } catch (eWizardAddSelector) {}
        }
        if (!addButton) {
          addButton = findByText(
            wizardAddRoot,
            step.wizardAddText,
            step.wizardAddCandidateSelector || "button, a, [role='button'], div, span"
          );
        }
        if (!addButton) throw new Error("找不到新增按钮：" + step.wizardAddText);
        var wizardAddClicked = false;
        if (step.wizardAddUseAntMainBridge === true) {
          wizardAddClicked = await clickAntActionInPage(
            addButton,
            step.wizardAddClickTimeoutMs || 3000
          );
        }
        if (!wizardAddClicked) await safeClick(addButton);
        await sleep(step.waitAfterClickMs == null ? 250 : step.waitAfterClickMs);
        wizardReady = await waitUntil(function () { return resolveReadyElement(step); }, step.timeoutMs);
        if (wizardReady) return wizardReady;
      }
      throw new Error("未进入向导栏目：" + step.wizardSectionTitle);
    }
    var alreadyReady = step && step.forceTriggerClick === true ? null : resolveReadyElement(step);
    if (/^applyjob\.chinahr\.com$/i.test(window.location.hostname) && step && (step.name === "个人信息" || step.scopeSelector === "#6a82a4e4f6bf3d0ac213d654")) {
      try { var chinahrBasicRoot = document.getElementById("6a82a4e4f6bf3d0ac213d654"); var chinahrBasicGroup = chinahrBasicRoot && Array.from(chinahrBasicRoot.querySelectorAll(".aply-group")).find(isVisible); if (chinahrBasicGroup) alreadyReady = chinahrBasicGroup; } catch (eChinahrBasicDirectReady) {}
    }
    if (!alreadyReady && /^applyjob\.chinahr\.com$/i.test(window.location.hostname) && step && step.scopeSelector === "#6a82a4e4f6bf3d0ac213d654") {
      try { alreadyReady = Array.from(document.querySelectorAll("#6a82a4e4f6bf3d0ac213d654 > .aply-group, #6a82a4e4f6bf3d0ac213d654 .aply-group")).find(isVisible) || null; } catch (eChinahrBasicReady) {}
    }
    // 新增一条记录后，站点可能按学历或时间自动重排所有已保存卡片。
    // 因此不能继续使用执行计划生成时缓存的卡片下标；真正打开编辑器前，
    // 用当前 DOM 和当前行数据重新解析一次目标卡片。
    if (
      step && typeof step.existingRowIndexResolver === "function" &&
      Array.isArray(step.dataOverride) && step.dataOverride.length
    ) {
      try {
        var liveExistingIndex = Number(step.existingRowIndexResolver(
          step.dataOverride[0], document, step, step.repeatIndex
        ));
        if (Number.isInteger(liveExistingIndex) && liveExistingIndex >= 0) {
          step.updateExistingIndex = liveExistingIndex;
        } else {
          delete step.updateExistingIndex;
        }
      } catch (eLiveExistingIndex) {}
    }
    // Execution plans are built before any new cards are saved. Re-check the
    // live direct card count before editing. If this row's planned position is
    // beyond the cards that really exist, it is a missing row and must use Add.
    if (Number.isInteger(step.updateExistingIndex) && step.preferDirectExistingCards === true) {
      try {
        var liveRepeatRoot = step.repeatAddRootSelector
          ? document.querySelector(step.repeatAddRootSelector)
          : (findStepCard(step, document) || document);
        var liveRepeatCards = resolveExistingRepeatCards(step, liveRepeatRoot || document);
        if (step.updateExistingIndex >= liveRepeatCards.length) {
          delete step.updateExistingIndex;
          step.forceAddRepeat = true;
        }
      } catch (eLiveDirectCards) {}
    }
    if (/^job\.spdb\.com\.cn$/i.test(window.location.hostname) && /教育情况/.test(String(step.name || "")) && Number.isInteger(step.repeatIndex)) {
      try { var spdbCards = document.querySelectorAll(".fromcontainer.formblocksolid .infoline"); if (step.repeatIndex < spdbCards.length) step.updateExistingIndex = step.repeatIndex; } catch (eSpdbIndex) {}
    }
    // 二次填写路径：只有执行计划明确标记当前页面已有对应卡片时才进入编辑。
    // 新用户页面没有 display-mode 卡片，不会产生 updateExistingIndex，因此
    // 完全沿用下面原有的“添加第一条/添加下一条”流程。
    if (Number.isInteger(step.updateExistingIndex)) {
      if (await openExistingRepeatEditor(step)) {
        var existingReady = resolveReadyElement(step) || findStepCard(step, document);
        await clearExistingEditorBeforeFill(step, existingReady);
        return existingReady;
      }
      throw new Error("已有记录存在，但悬停后未能打开编辑表单：" + (step.name || step.category || "未命名步骤"));
    }
    if (
      Number.isInteger(step.repeatIndex) &&
      (step.repeatIndex > 0 || step.forceAddRepeat === true) &&
      step.directMenuNavigation &&
      !findStepCard(step, document)
    ) {
      var repeatMenuItem = Array.from(document.querySelectorAll(".resume-menu-item")).find(function (node) {
        var title = node.querySelector(".resume-menu-item__title, h6");
        return title && titleMatchesSection(title.textContent, step.cardTitle || step.name);
      });
      if (!repeatMenuItem) {
        throw new Error("找不到重复经历大类入口：" + (step.cardTitle || step.name || "未命名步骤"));
      }
      await safeClick(repeatMenuItem);
      await sleep(step.waitAfterClickMs == null ? 300 : step.waitAfterClickMs);
      if (step.handleNavigationSavePrompt) {
        var repeatNavigationPrompt = await waitUntil(function () {
          return Array.from(document.querySelectorAll('.el-message-box__wrapper[role="dialog"], .el-message-box__wrapper')).filter(isVisible).find(function (node) {
            return /当前模块还未保存/.test(normalizeText(node.textContent));
          }) || null;
        }, step.navigationPromptTimeoutMs || 1800);
        if (repeatNavigationPrompt) {
          var repeatSaveAndJump = repeatNavigationPrompt.querySelector(".el-message-box__btns button.el-button--primary") ||
            Array.from(repeatNavigationPrompt.querySelectorAll("button")).find(function (node) {
              return /保存并跳转/.test(normalizeText(node.textContent));
            });
          if (repeatSaveAndJump) {
            await safeClick(repeatSaveAndJump);
            await waitUntil(function () { return !isVisible(repeatNavigationPrompt); }, 8000);
          }
        }
      }
      var repeatSectionReady = await waitUntil(function () {
        return findStepCard(step, document);
      }, step.timeoutMs || 6000);
      if (!repeatSectionReady) {
        throw new Error("点击后未进入重复经历大类：" + (step.cardTitle || step.name || "未命名步骤"));
      }
    }

    if (
      Number.isInteger(step.repeatIndex) &&
      (step.repeatIndex > 0 || step.forceAddRepeat === true) &&
      !hasPreparedRepeatRow(step, step.repeatIndex) &&
      (step.repeatAddText || step.repeatAddSelector || step.repeatAddSelectors)
    ) {
      // 重复经历的“添加/新增”必须限制在当前栏目根节点。很多招聘页每个模块
      // 都叫“添加”，全页面搜索会误点工作经历，造成教育被跳过、项目只填一条。
      var repeatRoot = resolveStrictRepeatAddRoot(step) || (step.strictRepeatAddRoot === true ? null : (findStepCard(step, document) || document));
      if (!repeatRoot) throw new Error("找不到当前重复经历栏目：" + (step.cardTitle || step.name || step.category || "未命名步骤"));
      if (step.repeatAddRootSelector) {
        try { repeatRoot = document.querySelector(step.repeatAddRootSelector) || document; } catch (e0) {}
      }
      // 少数原生表单会用当前栏目中的前置选择项控制“新增”入口是否显示。
      // 该动作只允许由站点配置明确声明，且仍严格限定在当前 repeatRoot 内，
      // 不能为了显示按钮去点击其它栏目或猜填用户数据。
      if (step.repeatAddPrerequisite && step.repeatAddPrerequisite.type === "citicSelect") {
        var prerequisite = step.repeatAddPrerequisite;
        var prerequisiteData = Array.isArray(step.dataOverride) ? step.dataOverride[0] : null;
        var prerequisiteValue = prerequisiteData && prerequisiteData[prerequisite.field];
        if (!hasMeaningfulValue(prerequisiteValue) || !await fillCiticSelect(repeatRoot, prerequisiteValue, prerequisite)) {
          throw new Error("新增前置字段填写失败：" + (prerequisite.label || prerequisite.field || "未命名字段"));
        }
        await sleep(prerequisite.waitAfterMs == null ? 240 : prerequisite.waitAfterMs);
      }
      // 上一条保存后，部分 Ant 页面会立即留下下一条空白编辑器；另一些页面
      // 则在第一次点击“添加”后已打开表单，但旧等待逻辑因 findStepCard()
      // 命中栏目里的局部小节点而误判为未出现。明确配置了栏目根节点时，
      // 新增与就绪检测都必须以同一个 repeatRoot 为准。若编辑器已存在，直接
      // 复用，禁止再点一次“添加”把它切走或重复创建。
      var existingRepeatEditor = null;
      try {
        existingRepeatEditor = Array.from(repeatRoot.querySelectorAll(
          step.repeatReadySelector || "form.el-form.resume, .edit-mode form, .edit-mode input:not([type='hidden'])"
        )).find(isVisible) || null;
      } catch (eExistingRepeatEditor) {}
      if (existingRepeatEditor) {
        if (step.reuseDirtyRepeatEditor === false && editorHasUserValue(existingRepeatEditor)) {
          throw new Error("上一条记录仍停留在未保存编辑态，跳过当前大类剩余条目：" + (step.name || step.category || "未命名步骤"));
        }
        return existingRepeatEditor;
      }
      if (step.repeatHoverBeforeAdd !== false) {
        var repeatHoverTarget = repeatRoot;
        if (step.repeatAddHoverSelector) {
          try { repeatHoverTarget = repeatRoot.querySelector(step.repeatAddHoverSelector) || repeatHoverTarget; } catch (eHover) {}
        }
        await hoverElementForAction(repeatHoverTarget, step.repeatAddHoverWaitMs == null ? 260 : step.repeatAddHoverWaitMs);
      }
      var repeatAddButton = null;
      var repeatSelectors = [];
      if (Array.isArray(step.repeatAddSelectors)) repeatSelectors = repeatSelectors.concat(step.repeatAddSelectors);
      if (step.repeatAddSelector) repeatSelectors.push(step.repeatAddSelector);
      for (var repeatSelectorIndex = 0; repeatSelectorIndex < repeatSelectors.length && !repeatAddButton; repeatSelectorIndex++) {
        try {
          var repeatCandidates = Array.from(repeatRoot.querySelectorAll(repeatSelectors[repeatSelectorIndex]));
          repeatAddButton = repeatCandidates.find(isVisible) || (step.repeatAddAllowHidden ? repeatCandidates[0] : null);
        } catch (eSelector) {}
      }
      if (!repeatAddButton && step.repeatAddText) {
        repeatAddButton = findAddButtonByText(
          repeatRoot,
          step.repeatAddText,
          step.repeatAddCandidateSelector || "button, a, [role='button'], div, span"
        );
      }
      if (!repeatAddButton) throw new Error("找不到新增下一条按钮：" + step.repeatAddText);
      var beforeRepeatCardCount = step.repeatAddWaitForRowCount === true
        ? resolveExistingRepeatCards(step, repeatRoot).length
        : 0;
      var repeatAddClicked = false;
      if (step.repeatAddUsePinganCampusBridge === true) {
        repeatAddClicked = await clickPinganCampusRepeatAdd(
          repeatHoverTarget,
          repeatAddButton,
          step.repeatAddHoverWaitMs == null ? 360 : step.repeatAddHoverWaitMs
        );
      }
      if (step.repeatAddUseAntMainBridge === true) {
        if (!repeatAddClicked) repeatAddClicked = await clickAntActionInPage(repeatAddButton, step.repeatAddClickTimeoutMs || 3000);
      }
      if (!repeatAddClicked && step.repeatAddNativeClick === true && typeof repeatAddButton.click === "function") {
        // 与平安社招相同，后续仍走“当前栏目新增 → 等编辑器 → 填写 → 保存”；
        // 校招只在入口处兼容常驻 DOM 但 display:none 的添加节点。
        repeatAddButton.click();
        repeatAddClicked = true;
      }
      if (!repeatAddClicked) await safeClick(repeatAddButton);
      await sleep(step.repeatAddWaitMs == null ? (step.waitAfterClickMs == null ? 300 : step.waitAfterClickMs) : step.repeatAddWaitMs);
      var repeatReady = await waitUntil(function () {
        if (step.repeatAddWaitForRowCount === true) {
          var currentRepeatCardCount = resolveExistingRepeatCards(step, repeatRoot).length;
          if (currentRepeatCardCount <= beforeRepeatCardCount) return null;
        }
        // repeatAddRootSelector 是站点配置提供的确定栏目边界，优先级高于
        // findStepCard() 的启发式标题定位。
        var currentCard = step.repeatAddRootSelector
          ? repeatRoot
          : (findStepCard(step, document) || repeatRoot);
        // cardAsScope 的 resolveReadyElement 可能仍返回栏目里任意已有控件，不能
        // 证明新卡片已打开。重复步骤要求当前栏目内出现可见编辑表单。
        if (step.cardAsScope) {
          var editForm = Array.from(currentCard.querySelectorAll(
            step.repeatReadySelector || "form.el-form.resume, .edit-mode form, .edit-mode input:not([type='hidden'])"
          )).find(isVisible);
          if (!editForm && step.repeatReadyGlobalFallback === true) {
            try {
              var globalReadySelector = step.activeRepeatEditorSelector || step.repeatReadySelector;
              editForm = Array.from(document.querySelectorAll(globalReadySelector)).filter(isVisible).pop() || null;
            } catch (eGlobalRepeatReady) {}
          }
          return editForm || null;
        }
        return resolveReadyElement(step);
      }, step.timeoutMs);
      // React 懒加载或按钮动画可能吞掉第一次点击。仅当同一栏目根节点内
      // 确认仍没有编辑表单时，才用 MAIN world 事件重试一次；一旦表单已
      // 出现绝不重试，避免创建重复卡片。
      if (!repeatReady && step.repeatAddUseAntMainBridge === true) {
        var repeatRetryClicked = await clickAntActionInPage(
          repeatAddButton,
          step.repeatAddClickTimeoutMs || 3000
        );
        if (repeatRetryClicked) {
          await sleep(step.repeatAddRetryWaitMs == null ? 500 : step.repeatAddRetryWaitMs);
          repeatReady = await waitUntil(function () {
            var retryRoot = step.repeatAddRootSelector
              ? repeatRoot
              : (findStepCard(step, document) || repeatRoot);
            try {
              return Array.from(retryRoot.querySelectorAll(
                step.repeatReadySelector || "form.el-form.resume, .edit-mode form, .edit-mode input:not([type='hidden'])"
              )).find(isVisible) || null;
            } catch (eRetryReady) { return null; }
          }, step.repeatAddRetryTimeoutMs || 2500);
        }
      }
      // 平安校招专用新增包：按钮可能始终 display:none，但节点上的 Vue
      // 处理器可由原生 click 激活。第一次触发后若编辑器没有出现，只在同一
      // 栏目重新取得当前按钮并重试一次，不触碰任何字段或其它栏目。
      if (!repeatReady && step.repeatAddNativeClick === true) {
        var campusRetryButton = null;
        for (var campusRetrySelectorIndex = 0; campusRetrySelectorIndex < repeatSelectors.length && !campusRetryButton; campusRetrySelectorIndex++) {
          try {
            campusRetryButton = repeatRoot.querySelector(repeatSelectors[campusRetrySelectorIndex]);
          } catch (eCampusRetrySelector) {}
        }
        if (campusRetryButton && typeof campusRetryButton.click === "function") {
          campusRetryButton.click();
          await sleep(step.repeatAddRetryWaitMs == null ? 550 : step.repeatAddRetryWaitMs);
          repeatReady = await waitUntil(function () {
            try {
              return Array.from(repeatRoot.querySelectorAll(
                step.repeatReadySelector || "form.el-form.resume, .edit-mode form, .edit-mode input:not([type='hidden'])"
              )).find(isVisible) || null;
            } catch (eCampusRetryReady) { return null; }
          }, step.repeatAddRetryTimeoutMs || 2800);
        }
      }
      if (repeatReady) return repeatReady;
      throw new Error("新增下一条后未等到表单出现：" + (step.name || step.category || "未命名步骤"));
    }
    if (alreadyReady && step.skipClickWhenReady !== false) {
      var alreadyCard = findStepCard(step, document);
      var alreadyEditor = findVisibleStepEditor(step, alreadyCard || document);
      if (
        step.editExistingSectionWhenClosed &&
        step.cardAsScope &&
        alreadyCard &&
        !alreadyEditor
      ) {
        var openedExistingEditor = await openExistingSectionEditor(step);
        if (openedExistingEditor) {
          var readyAfterExistingOpen = await waitUntil(function () { return resolveReadyElement(step); }, step.timeoutMs);
          if (readyAfterExistingOpen) return readyAfterExistingOpen;
        }
      } else {
        return alreadyReady;
      }
    }

    var trigger = findTrigger(step);
    if (!trigger) throw new Error("找不到大类入口：" + (step.name || step.category || "未命名步骤"));
    var directMenuClicked = false;
    if (step.directMenuNavigation) {
      try {
        var menuItem = Array.from(document.querySelectorAll(".resume-menu-item")).find(function (node) {
          var title = node.querySelector(".resume-menu-item__title, h6");
          var wantedMenuTitle = normalizeSectionTitle(step.cardTitle || step.name);
          var actualMenuTitle = normalizeSectionTitle(title && title.textContent);
          return title && wantedMenuTitle && actualMenuTitle.indexOf(wantedMenuTitle) !== -1;
        });
        if (menuItem && menuItem !== trigger) { await safeClick(menuItem); directMenuClicked = true; await sleep(350); }
      } catch (eDirectMenu) {}
    }
    if (!directMenuClicked) {
      if (step.triggerNativeClick === true && typeof trigger.click === "function") trigger.click();
      else await safeClick(trigger);
    }
    await sleep(step.waitAfterClickMs == null ? 200 : step.waitAfterClickMs);
    if (step.handleNavigationSavePrompt) {
      var promptAfterNavigation = await waitUntil(function () { return Array.from(document.querySelectorAll('.el-message-box__wrapper[role="dialog"], .el-message-box__wrapper')).filter(isVisible).find(function (node) { return /当前模块还未保存/.test(normalizeText(node.textContent)); }) || null; }, step.navigationPromptTimeoutMs || 1800);
      if (promptAfterNavigation) {
        var jumpAfterNavigation = promptAfterNavigation.querySelector('.el-message-box__btns button.el-button--primary') || Array.from(promptAfterNavigation.querySelectorAll('button')).find(function (node) { return /保存并跳转/.test(normalizeText(node.textContent)); });
        if (jumpAfterNavigation) { try { jumpAfterNavigation.click(); } catch (eJumpNavigation) { await safeClick(jumpAfterNavigation); } await waitUntil(function () { return !isVisible(promptAfterNavigation); }, 8000); await sleep(500); }
      }
    }
    var readyAfterNavigation = resolveReadyElement(step);
    var cardAfterNavigation = findStepCard(step, document);
    var editorAfterNavigation = findVisibleStepEditor(step, cardAfterNavigation || document);
    if (
      step.editExistingSectionWhenClosed &&
      step.cardAsScope &&
      cardAfterNavigation &&
      !editorAfterNavigation
    ) {
      var actionOpenedFromCard = await clickActionAfterTrigger(step, trigger);
      if (!actionOpenedFromCard) {
        await openExistingSectionEditor(step);
      }
    } else if (!readyAfterNavigation) {
      var actionOpened = await clickActionAfterTrigger(step, trigger);
      if (!actionOpened && step.editExistingSectionWhenClosed) {
        await openExistingSectionEditor(step);
      }
    }

    var ready = await waitUntil(function () { return resolveReadyElement(step); }, step.timeoutMs);
    if (!ready) throw new Error("点击后未等到表单出现：" + (step.name || step.category || "未命名步骤"));
    return ready;
  }

  function mergeResult(summary, result) {
    result = result || {};
    summary.filledCount += result.filledCount || 0;
    summary.totalFields += result.totalFields || result.totalFieldsFound || 0;
    if (Array.isArray(result.failedFields)) {
      summary.failedFields = summary.failedFields.concat(result.failedFields);
    }
  }

  function visibleTitle(matcher) {
    var titles = matcher && matcher.findTitle ? matcher.findTitle() : [];
    return Array.from(titles || []).find(isVisible) || null;
  }

  function visibleTitleForScope(matcher, scope) {
    if (scope && scope.closest) {
      var owner = scope.closest(".tab-block.re-block, .floor_view, .ant-card, .el-card, .resume-section, .resume-module, .form-section, .comp, .mb22");
      var titleSelector = matcher && matcher.config && matcher.config.selectors && matcher.config.selectors.title && matcher.config.selectors.title.class;
      if (owner && titleSelector) {
        try {
          var ownerTitles = Array.from(owner.querySelectorAll(titleSelector)).filter(isVisible);
          if (ownerTitles.length) return ownerTitles[0];
        } catch (e) {}
      }
      if (owner) {
        try {
          var fallbackTitle = Array.from(owner.querySelectorAll(".floor_view_title h3, .index_title, h1, h2, h3, [class*='title']")).find(isVisible);
          if (fallbackTitle) return fallbackTitle;
        } catch (e2) {}
      }
    }
    return visibleTitle(matcher);
  }

  function combineCategoryRows(resume, categories) {
    var rows = [];
    categories.forEach(function (category) {
      var value = resume && resume[category];
      if (!Array.isArray(value)) return;
      value.forEach(function (item) {
        if (!item || typeof item !== "object") return;
        rows.push(Object.assign({}, item, { __afCategory: category }));
      });
    });
    return rows;
  }

  function prepareStepRows(step, resume) {
    var categories = Array.isArray(step.category) ? step.category : [step.category];
    var rows = combineCategoryRows(resume, categories);
    if (typeof step.rowFilter === "function") {
      rows = rows.filter(function (row, index) {
        try {
          return step.rowFilter(row, index, resume) !== false;
        } catch (e) {
          return false;
        }
      });
    }
    if (typeof step.rowSort === "function") {
      rows = rows.slice().sort(function (left, right) {
        try { return Number(step.rowSort(left, right, resume)) || 0; } catch (e) { return 0; }
      });
    }
    if (typeof step.rowsTransform === "function") {
      try {
        var transformedRows = step.rowsTransform(rows.slice(), resume);
        if (Array.isArray(transformedRows)) rows = transformedRows;
      } catch (e) {}
    }
    if (typeof step.rowsValidator === "function") {
      var validationMessage = "";
      try { validationMessage = String(step.rowsValidator(rows.slice(), resume) || ""); } catch (eValidateRows) {}
      if (validationMessage) {
        // Some sites enforce a stricter record set than the canonical profile
        // necessarily contains (for example, Bank of Communications asks for
        // education starting from high school). A missing prerequisite should
        // be able to block only that repeat section, not abort unrelated basic
        // info / work / language sections before they get a chance to fill.
        if (step.rowsValidationFailureMode === "skip_step" || step.rowsValidationFailureMode === "manual_checkpoint") {
          try {
            Object.defineProperty(rows, "__afRowsValidationError", {
              value: validationMessage,
              configurable: true,
              enumerable: false,
              writable: true
            });
            Object.defineProperty(rows, "__afRowsValidationMode", {
              value: String(step.rowsValidationFailureMode || "skip_step"),
              configurable: true,
              enumerable: false,
              writable: true
            });
          } catch (eValidationMeta) {
            rows.__afRowsValidationError = validationMessage;
            rows.__afRowsValidationMode = String(step.rowsValidationFailureMode || "skip_step");
          }
        } else {
          throw new Error(validationMessage);
        }
      }
    }
    if (typeof step.rowTransform === "function") {
      rows = rows.map(function (row, index) {
        try {
          var transformed = step.rowTransform(row, index, resume);
          return transformed && typeof transformed === "object" ? transformed : row;
        } catch (e) {
          return row;
        }
      });
    }
    return rows;
  }

  // 正式填写和特殊工作流诊断共用同一套数据判断，避免没有该类经历时
  // 诊断仍然点击“添加”并打开空弹窗。
  function getStepDataDecision(step, resume, options) {
    options = options || {};
    if (!stepMatchesCurrentPage(step)) {
      return { shouldRun: false, rows: null, reason: "当前不是该大类页面" };
    }
    if (!options.skipManualCheckpoint && step && typeof step.manualCheckpointWhen === "function") {
      var checkpointReason = "";
      try { checkpointReason = String(step.manualCheckpointWhen(resume, step) || ""); } catch (eCheckpointWhen) {}
      if (checkpointReason) {
        return {
          shouldRun: false,
          rows: null,
          reason: checkpointReason,
          needsReview: true,
          validationBlocked: true,
          manualCheckpoint: true,
          validationMode: "manual_checkpoint"
        };
      }
    }
    var forced = step && step.skipIfNoResumeData === false;
    var hasSourceData = hasResumeData(resume, step && step.category);
    var rows = step && step.repeatForCategoryData ? prepareStepRows(step, resume) : null;
    var rowsValidationError = rows && String(rows.__afRowsValidationError || "");
    var rowsValidationMode = rows && String(rows.__afRowsValidationMode || "");
    // Generic resumable-checkpoint rule: when the persisted manual gate for
    // this exact step has already been positively resolved, do not recreate
    // the same gate through a category rowsValidator. Other validation modes
    // remain blocking.
    if (rowsValidationError && options.skipManualCheckpoint && rowsValidationMode === "manual_checkpoint") {
      rowsValidationError = "";
    }
    if (rowsValidationError) {
      return {
        shouldRun: false,
        rows: rows,
        reason: rowsValidationError,
        needsReview: true,
        validationBlocked: true,
        manualCheckpoint: rowsValidationMode === "manual_checkpoint",
        validationMode: rowsValidationMode || "skip_step"
      };
    }

    if (forced) {
      return { shouldRun: true, rows: rows, reason: "" };
    }
    if (!hasSourceData) {
      return { shouldRun: false, rows: rows, reason: "当前简历无此类经历或信息" };
    }
    if (step && step.repeatForCategoryData && (!rows || rows.length === 0)) {
      return { shouldRun: false, rows: rows, reason: "当前简历数据不符合本站填报条件" };
    }
    return { shouldRun: true, rows: rows, reason: "" };
  }

  function aggregateRows(rows, fields, separator) {
    return (rows || []).map(function (row) {
      return (fields || []).map(function (field) { return row && row[field]; }).filter(function (value) {
        return value !== null && value !== undefined && String(value).trim() !== "";
      }).join(" / ");
    }).filter(Boolean).join(separator || "\n");
  }

  function findLabelForSequence(labels, wanted) {
    var wantedList = (Array.isArray(wanted) ? wanted : [wanted]).map(normalizeText).filter(Boolean);
    var candidates = Array.from(labels || []).map(function (label) {
      var text = normalizeText(label && label.textContent);
      if (!text) return null;
      var matchedTarget = wantedList.find(function (target) {
        return text === target || text.indexOf(target) !== -1;
      });
      if (!matchedTarget) return null;
      var formItem = label.closest && label.closest(".el-form-item, .ant-form-item, .form-group, [class*='form-item'], [class*='formItem']");
      var hasControl = false;
      try {
        hasControl = !!(formItem && Array.from(formItem.querySelectorAll(
          "input:not([type='hidden']), textarea, select, [role='combobox'], [role='textbox'], .el-select, .el-cascader, .el-date-editor, .ant-select, .ant-picker"
        )).some(isVisible));
      } catch (e) {}
      var className = String(label.className || "");
      var exact = text === matchedTarget ? 0 : 1;
      var fieldLabel = /(^|\s)(el-form-item__label|ant-form-item-required|ant-form-item-label)(\s|$)/.test(className) ? 0 : 1;
      var controlPenalty = hasControl ? 0 : 1;
      // 特殊站点里 matcher 可能把整块 section 文本也当成 label。
      // 这类文本虽然“包含”目标字段，但会让后续控件定位退回到整块 scope，
      // 导致日期/证书等值串到第一个输入框。优先短文本、真实 form-item label。
      var longPenalty = text.length > matchedTarget.length + 12 ? 1 : 0;
      return { label: label, exact: exact, fieldLabel: fieldLabel, controlPenalty: controlPenalty, longPenalty: longPenalty, length: text.length };
    }).filter(Boolean);
    candidates.sort(function (a, b) {
      return a.exact - b.exact ||
        a.fieldLabel - b.fieldLabel ||
        a.controlPenalty - b.controlPenalty ||
        a.longPenalty - b.longPenalty ||
        a.length - b.length;
    });
    return candidates.length ? candidates[0].label : null;
  }

  // 中国银行申请表的字段标签没有独立 id/name，且“紧急联系人姓名”与
  // “紧急联系人手机”只共享前缀。特殊字段必须按标签完整文本定位，不能
  // 让通用 matcher 的包含匹配把手机错配到姓名输入框。
  function findExactLabelForSequence(labels, wanted) {
    var target = normalizeText(wanted);
    if (!target) return null;
    var pool = Array.from(labels || []);
    if (!pool.some(function (label) { return normalizeText(label && label.textContent) === target; })) {
      pool = pool.concat(Array.from(document.querySelectorAll(".aply-field-label")));
    }
    return pool.find(function (label) {
      return normalizeText(label && label.textContent) === target;
    }) || null;
  }


  function resolveSequenceControl(matcher, label) {
    try {
      var row = label && label.closest && label.closest(".floor_view_editor_item");
      if (row) {
        var radios = Array.from(row.querySelectorAll(".radio_selector .label_radio")).filter(isVisible);
        if (radios.length) return { type: "radio", element: radios };

        var customSelect = Array.from(row.querySelectorAll(
          ".multi_select_box.multi_search_selector, .select_box.search_selector, .multi_select_box, .select_box"
        )).find(isVisible);
        if (customSelect) return { type: "select", element: customSelect };

        var dateInput = Array.from(row.querySelectorAll(".date_box input.edit_field_value")).find(isVisible);
        if (dateInput) return { type: "date", element: dateInput };

        var textControl = Array.from(row.querySelectorAll(
          "textarea.edit_field_value, input.edit_field_value:not([type='hidden']):not([style*='display: none'])"
        )).find(isVisible);
        if (textControl) return { type: "text", element: textControl };
      }

      // 民生等 Angular 表单会在每一条重复经历中复用完全相同的 id/for
      // （例如 SchoolName、College、Major）。通用 matcher 按 htmlFor 调用
      // document.getElementById() 时只能拿到第一条，导致第二条数据写回第一条。
      // fieldSequence 已经把 label 限定在当前记录中，因此优先只在最近的
      // .form-group 内解析控件，绝不让重复 id 逃出当前经历作用域。
      var formGroup = label && label.closest && label.closest(".form-group");
      if (formGroup) {
        var localRadios = Array.from(formGroup.querySelectorAll(
          ".ui-radiobutton, input[type='radio'], [role='radio']"
        )).filter(isVisible);
        if (localRadios.length) return { type: "radio", element: localRadios };

        var localDropdown = Array.from(formGroup.querySelectorAll(
          ".ui-dropdown, select, [role='combobox']"
        )).find(isVisible);
        if (localDropdown) return { type: "select", element: localDropdown };

        var localText = Array.from(formGroup.querySelectorAll(
          "textarea, input:not([type='hidden']):not([type='file']):not([type='radio']):not([type='checkbox'])"
        )).find(function (node) {
          return isVisible(node) && !node.disabled && !node.readOnly;
        });
        if (localText) return { type: "text", element: localText };
      }

      // Element UI / Element Plus 会把下拉面板挂到 body，通用 matcher 很容易
      // 误取到上一个尚未关闭的下拉。fieldSequence 已经锁定了当前 label，必须先
      // 在最近的 .el-form-item 内寻找控件，确保每个值只驱动自己的 radio/select。
      var elementFormItem = label && label.closest && label.closest(".el-form-item");
      if (elementFormItem) {
        var elementRadios = Array.from(elementFormItem.querySelectorAll(
          ".el-radio-group .el-radio, .el-radio-group [role='radio'], input[type='radio']"
        )).filter(isVisible);
        if (elementRadios.length) return { type: "radio", element: elementRadios };

        var elementCascader = Array.from(elementFormItem.querySelectorAll(".el-cascader:not(.is-disabled)")).find(isVisible);
        if (elementCascader) return { type: "select", element: elementCascader };

        var elementSelect = Array.from(elementFormItem.querySelectorAll(".el-select:not(.is-disabled)")).find(isVisible);
        if (elementSelect) return { type: "select", element: elementSelect };

        var elementDate = Array.from(elementFormItem.querySelectorAll(".el-date-editor:not(.is-disabled)")).find(isVisible);
        if (elementDate) return { type: "date", element: elementDate };

        var elementText = Array.from(elementFormItem.querySelectorAll(
          "textarea:not([disabled]):not([readonly]), input:not([type='hidden']):not([type='file']):not([type='radio']):not([type='checkbox']):not([disabled]):not([readonly])"
        )).find(isVisible);
        if (elementText) return { type: "text", element: elementText };
      }

      var antFormItem = label && label.closest && label.closest(".ant-form-item");
      if (antFormItem) {
        var antRadios = Array.from(antFormItem.querySelectorAll(
          ".ant-radio-wrapper, .ant-radio-group [role='radio'], input[type='radio']"
        )).filter(isVisible);
        if (antRadios.length) return { type: "radio", element: antRadios };

        var antSelect = Array.from(antFormItem.querySelectorAll(".ant-select:not(.ant-select-disabled)")).find(isVisible);
        if (antSelect) return { type: "select", element: antSelect };

        var antDate = Array.from(antFormItem.querySelectorAll(".ant-picker:not(.ant-picker-disabled)")).find(isVisible);
        if (antDate) return { type: "date", element: antDate };

        var antText = Array.from(antFormItem.querySelectorAll(
          "textarea:not([disabled]):not([readonly]), input:not([type='hidden']):not([type='file']):not([type='radio']):not([type='checkbox']):not([disabled]):not([readonly])"
        )).find(isVisible);
        if (antText) return { type: "text", element: antText };
      }
    } catch (e) {}
    return matcher.findElementAndTypeByLabel(label);
  }

  // 智联校园重复经历的可见字段标题不一定会被 Core matcher 识别为 label。
  // 例如国开行“实习岗位”在部分 Vue 状态下只是普通 div/span 文本。
  // 这里只在当前可见 repeat editor 内寻找短文本、精确语义的标签节点，
  // 不退回 document，也不根据 DOM 顺序猜字段。
  function findZhaopinRepeatLocalLabel(scope, wanted) {
    if (!scope) return null;
    var targets = (Array.isArray(wanted) ? wanted : [wanted]).map(normalizeText).filter(Boolean);
    if (!targets.length) return null;
    var candidates = [];
    try {
      candidates = Array.from(scope.querySelectorAll(
        "label, .el-form-item__label, .ant-form-item-label, [class*='field-label'], [class*='form-label'], [class*='label'], span, div"
      )).filter(isActuallyVisible);
    } catch (e) {}
    var scored = candidates.map(function (node, index) {
      var text = normalizeText(node && node.textContent);
      if (!text || text.length > 32) return null;
      var exactTarget = targets.find(function (target) { return text === target; });
      var looseTarget = exactTarget || targets.find(function (target) {
        return text.indexOf(target) !== -1 && text.length <= target.length + 3;
      });
      if (!looseTarget) return null;
      // 排除把整行/整块文字当标签的情况：候选节点内部如果已经包含
      // 可编辑控件，就让更小的纯文本后代节点优先。
      var containsControl = false;
      try {
        containsControl = !!node.querySelector(
          "input:not([type='hidden']), textarea, select, .el-select, .el-date-editor, .ant-select, .ant-picker, [role='combobox']"
        );
      } catch (eControl) {}
      return {
        node: node,
        exact: exactTarget ? 0 : 1,
        containsControl: containsControl ? 1 : 0,
        length: text.length,
        index: index,
      };
    }).filter(Boolean);
    scored.sort(function (a, b) {
      return a.exact - b.exact || a.containsControl - b.containsControl || a.length - b.length || a.index - b.index;
    });
    return scored.length ? scored[0].node : null;
  }

  function zhaopinRepeatControlGeometryScore(label, control) {
    if (!label || !control || !label.getBoundingClientRect || !control.getBoundingClientRect) return Number.POSITIVE_INFINITY;
    var labelRect = label.getBoundingClientRect();
    var controlRect = control.getBoundingClientRect();
    if (!labelRect || !controlRect) return Number.POSITIVE_INFINITY;
    var labelCenterX = (Number(labelRect.left) + Number(labelRect.right)) / 2;
    var controlCenterX = (Number(controlRect.left) + Number(controlRect.right)) / 2;
    var horizontalGap = 0;
    if (Number(controlRect.right) < Number(labelRect.left)) horizontalGap = Number(labelRect.left) - Number(controlRect.right);
    else if (Number(controlRect.left) > Number(labelRect.right)) horizontalGap = Number(controlRect.left) - Number(labelRect.right);
    var verticalGap = 0;
    var abovePenalty = 0;
    if (Number(controlRect.top) >= Number(labelRect.bottom)) {
      verticalGap = Number(controlRect.top) - Number(labelRect.bottom);
    } else if (Number(controlRect.bottom) <= Number(labelRect.top)) {
      verticalGap = Number(labelRect.top) - Number(controlRect.bottom);
      abovePenalty = 10000;
    } else {
      // Label and control can overlap vertically in compact Element layouts.
      verticalGap = 0;
    }
    var centerDistance = Math.abs(controlCenterX - labelCenterX);
    return abovePenalty + verticalGap * 12 + horizontalGap * 6 + centerDistance;
  }

  function chooseNearestZhaopinRepeatControl(label, controls) {
    var visible = Array.from(controls || []).filter(isActuallyVisible);
    if (!visible.length) return null;
    if (visible.length === 1) return visible[0];
    return visible.map(function (control, index) {
      return { control: control, index: index, score: zhaopinRepeatControlGeometryScore(label, control) };
    }).sort(function (left, right) {
      return left.score - right.score || left.index - right.index;
    })[0].control;
  }

  function resolveZhaopinRepeatLocalControl(label, item, scope) {
    if (!label || !item) return null;
    var configuredType = String(item.type || "");
    var group = closestLooseFormItem(label, scope);
    if (!group) return null;
    try {
      if (configuredType === "zhaopinCampusDate" || configuredType === "elementDate" || configuredType === "date") {
        var dateContainers = Array.from(group.querySelectorAll(
          ".el-date-editor:not(.is-disabled), .ant-picker:not(.ant-picker-disabled), input[type='date'], input[type='month']"
        )).filter(isActuallyVisible);
        var dateContainer = chooseNearestZhaopinRepeatControl(label, dateContainers);
        if (dateContainer) return { type: "date", element: dateContainer, source: "zhaopin_repeat_local_date_geometry" };
        var dateInputs = Array.from(group.querySelectorAll(
          "input:not([type='hidden']):not([type='file']):not([disabled]):not([readonly])"
        )).filter(function (node) {
          if (!isActuallyVisible(node)) return false;
          if (node.closest && node.closest(".el-select, .el-cascader, .ant-select")) return false;
          var placeholder = normalizeText(node.getAttribute && node.getAttribute("placeholder"));
          var value = String(node.value || "");
          return /日期|时间|年|月|日/.test(placeholder) || /^\d{4}[-/.]\d{1,2}(?:[-/.]\d{1,2})?$/.test(value);
        });
        if (!dateInputs.length) {
          dateInputs = Array.from(group.querySelectorAll(
            "input:not([type='hidden']):not([type='file']):not([disabled]):not([readonly])"
          )).filter(function (node) {
            return isActuallyVisible(node) && !(node.closest && node.closest(".el-select, .el-cascader, .ant-select"));
          });
        }
        var dateInput = chooseNearestZhaopinRepeatControl(label, dateInputs);
        if (dateInput) return { type: "date", element: dateInput, source: "zhaopin_repeat_local_date_input_geometry" };
      }
      if (configuredType === "text" || configuredType === "zhaopinText") {
        var textControls = Array.from(group.querySelectorAll(
          "textarea:not([disabled]):not([readonly]), input:not([type='hidden']):not([type='file']):not([type='radio']):not([type='checkbox']):not([disabled]):not([readonly])"
        )).filter(function (node) {
          return isActuallyVisible(node) && !(node.closest && node.closest(".el-select, .el-cascader, .el-date-editor, .ant-select, .ant-picker"));
        });
        var textControl = chooseNearestZhaopinRepeatControl(label, textControls);
        if (textControl) return { type: "text", element: textControl, source: "zhaopin_repeat_local_text_geometry" };
      }
      if (/select|choice/i.test(configuredType)) {
        var selectControls = Array.from(group.querySelectorAll(
          ".el-select:not(.is-disabled), .el-cascader:not(.is-disabled), .ant-select:not(.ant-select-disabled), select:not([disabled]), [role='combobox']"
        )).filter(isActuallyVisible);
        var selectControl = chooseNearestZhaopinRepeatControl(label, selectControls);
        if (selectControl) return { type: "select", element: selectControl, source: "zhaopin_repeat_local_select_geometry" };
      }
    } catch (e) {}
    return null;
  }

  function resolveSequenceControlByConfiguredType(matcher, label, item, scope) {
    var configuredType = item && item.type;
    if (item && item.zhaopinRepeatLocalBinding === true) {
      var localRepeatControl = resolveZhaopinRepeatLocalControl(label, item, scope);
      if (localRepeatControl && localRepeatControl.element) return localRepeatControl;
    }
    if (item && item.coreMatcherFirst === true) {
      try {
        var coreMatch = matcher && matcher.findElementAndTypeByLabel(label);
        if (coreMatch && coreMatch.element && coreMatch.type && isActuallyVisible(coreMatch.element)) return coreMatch;
      } catch (eCoreMatcherFirst) {}
    }
    if (item && item.selector) {
      try {
        var selectorRoot = label && (label.closest("li.aply-field-li, .inputblock, .formblock.formedit, form") || label.parentElement);
        var configuredControl = selectorRoot && selectorRoot.querySelector(item.selector);
        if (configuredControl) {
          var configuredResolvedType = /date/i.test(String(configuredType || "")) ? "date" :
            (/select|choice|cascader/i.test(String(configuredType || "")) ? "select" : "text");
          return { type: configuredResolvedType, element: configuredControl };
        }
      } catch (eConfiguredSelector) {}
    }
    var formItem = label && label.closest && label.closest(".el-form-item, .ant-form-item, .form-group, [class*='form-item']");
    if (formItem) {
      try {
        if (configuredType === "elementSelect") {
          var elementSelects = Array.from(formItem.querySelectorAll(".el-select:not(.is-disabled), .ant-select:not(.ant-select-disabled):not(.ant-cascader)")).filter(isVisible);
          var wantedPlaceholder = normalizeText(item && item.selectPlaceholder);
          var elementSelect = wantedPlaceholder && elementSelects.find(function (select) {
            var input = select.querySelector("input");
            return normalizeText(input && input.getAttribute("placeholder")) === wantedPlaceholder;
          });
          elementSelect = elementSelect || elementSelects[Math.max(0, Number(item && item.selectIndex) || 0)] || elementSelects[0];
          if (elementSelect) return { type: "select", element: elementSelect };
        }
        if (configuredType === "elementSelectOrText") {
          var autocompleteInputs = Array.from(formItem.querySelectorAll(
            ".el-autocomplete input.el-input__inner:not([disabled]):not([readonly]), input[aria-autocomplete='list']:not([disabled]):not([readonly]), input[fetchsuggestions]:not([disabled]):not([readonly])"
          )).filter(isVisible);
          var autocompleteInput = autocompleteInputs[Math.max(0, Number(item && item.autocompleteIndex) || 0)] || autocompleteInputs[0];
          if (autocompleteInput) return { type: "autocomplete", element: autocompleteInput };
          var selectOrTextSelect = Array.from(formItem.querySelectorAll(".el-select:not(.is-disabled), .ant-select:not(.ant-select-disabled)")).find(isVisible);
          if (selectOrTextSelect) return { type: "select", element: selectOrTextSelect };
          var selectOrTextInput = Array.from(formItem.querySelectorAll(
            "textarea:not([disabled]):not([readonly]), input:not([type='hidden']):not([type='file']):not([type='radio']):not([type='checkbox']):not([disabled]):not([readonly])"
          )).find(function (node) {
            return isVisible(node) && !(node.closest && node.closest(".el-cascader, .el-date-editor, .ant-select, .ant-picker"));
          });
          if (selectOrTextInput) return { type: "text", element: selectOrTextInput };
        }
        if (configuredType === "elementCascader") {
          var elementCascader = Array.from(formItem.querySelectorAll(".el-cascader:not(.is-disabled), .ant-select.ant-cascader:not(.ant-select-disabled), .ant-cascader-picker")).find(isVisible);
          if (elementCascader) return { type: "select", element: elementCascader };
        }
        if (configuredType === "elementDate") {
          var elementDate = Array.from(formItem.querySelectorAll(".el-date-editor:not(.is-disabled), .ant-picker:not(.ant-picker-disabled)")).find(isVisible);
          if (elementDate) return { type: "date", element: elementDate };
        }
        if (configuredType === "customSelect") {
          var customTrigger = Array.from(formItem.querySelectorAll(
            item.customTriggerSelector || "input.el-input__inner, [role='combobox'], .skill-dialog, .select_Content, [class*='select']"
          )).find(isVisible);
          if (customTrigger) return { type: "select", element: customTrigger };
        }
        if (configuredType === "text") {
          var text = Array.from(formItem.querySelectorAll(
            "textarea:not([disabled]):not([readonly]), input:not([type='hidden']):not([type='file']):not([type='radio']):not([type='checkbox']):not([disabled]):not([readonly])"
          )).find(function (node) {
            return isVisible(node) && !(node.closest && node.closest(".el-select, .el-cascader, .el-date-editor, .ant-select, .ant-picker"));
          });
          if (text) return { type: "text", element: text };
        }
      } catch (e) {}
    }
    return resolveSequenceControl(matcher, label);
  }

  function controlHasExistingValue(control) {
    var controls = Array.isArray(control) ? control : [control];
    return controls.some(function (node) {
      if (!node) return false;
      if (node.checked === true) return true;
      if (node.value !== undefined && String(node.value || "").trim() !== "") return true;
      var text = normalizeText(node.textContent);
      return text && !/请选择|选择省份|请选择日期/.test(text);
    });
  }

  function isCurrentEndText(value) {
    return /^(至今|目前|现在|仍在职|在职|仍在进行|当前)$/.test(String(value == null ? "" : value).trim());
  }

  async function clickCurrentEndNearLabel(label, scope) {
    try {
      var looseGroup = closestLooseFormItem(label, scope);
      if (looseGroup) {
        var directNow = Array.from(looseGroup.querySelectorAll(
          "label, button, a, span, div, [role='button'], [role='checkbox'], input[type='checkbox']"
        )).filter(isVisible).find(function (node) {
          var wrapper = node.closest && node.closest("label, button, [role='button'], .el-checkbox, .ant-checkbox-wrapper") || node;
          return /^至今$/.test(normalizeText(wrapper.textContent || node.textContent || node.getAttribute("aria-label") || node.getAttribute("title")));
        });
        if (directNow) {
          await safeClick(directNow.closest && directNow.closest("label, button, [role='button'], .el-checkbox, .ant-checkbox-wrapper") || directNow);
          await sleep(220);
          return true;
        }
      }
      var roots = [];
      var formItem = label && label.closest && label.closest(".el-form-item, .ant-form-item, .form-group, [class*='form-item']");
      var row = label && label.closest && label.closest("form.el-form, .el-form, .education-item, .work-item, .experience-item, .row, .ant-row");
      [formItem, formItem && formItem.parentElement, row, scope].forEach(function (root) {
        if (root && roots.indexOf(root) === -1) roots.push(root);
      });
      var candidates = [];
      roots.forEach(function (root) {
        try {
          candidates = candidates.concat(Array.from(root.querySelectorAll(
            "button, a, label, span, div, [role='button'], [role='checkbox'], input[type='checkbox']"
          )));
        } catch (e) {}
      });
      var origin = (formItem || label).getBoundingClientRect();
      var best = candidates.filter(isVisible).map(function (node) {
        var wrapper = node.closest && node.closest("button, label, [role='button'], .el-button, .el-checkbox") || node;
        var text = normalizeText(wrapper.textContent || node.textContent || node.getAttribute("aria-label") || node.getAttribute("title"));
        if (!/^至今$/.test(text)) return null;
        var rect = wrapper.getBoundingClientRect();
        var distance = Math.abs(rect.left - origin.left) + Math.abs(rect.top - origin.top);
        return { element: wrapper, distance: distance };
      }).filter(Boolean).sort(function (a, b) { return a.distance - b.distance; })[0];
      if (!best || best.distance > 800) return false;
      await safeClick(best.element);
      await sleep(220);
      return true;
    } catch (e) {
      return false;
    }
  }

  async function clickBankcommCurrentEndNearLabel(label, scope) {
    try {
      var formItem = label && label.closest && label.closest(".ant-form-item");
      var form = formItem && formItem.closest && formItem.closest("form.ant-form");
      var root = form || scope || document;
      var candidates = Array.from(root.querySelectorAll(
        ".ant-checkbox-wrapper, [role='checkbox'], label, input[type='checkbox']"
      )).filter(isVisible).map(function (node) {
        return node.closest && node.closest(".ant-checkbox-wrapper, label, [role='checkbox']") || node;
      }).filter(function (node, index, all) {
        if (all.indexOf(node) !== index) return false;
        var text = normalizeText(
          node.textContent || node.getAttribute("aria-label") || node.getAttribute("title")
        );
        return /^至今$/.test(text);
      });
      if (!candidates.length) return false;

      var origin = (formItem || label).getBoundingClientRect();
      var target = candidates.map(function (node) {
        var rect = node.getBoundingClientRect();
        return {
          element: node,
          distance: Math.abs(rect.left - origin.right) + Math.abs(rect.top - origin.top),
        };
      }).sort(function (a, b) { return a.distance - b.distance; })[0].element;
      var checkbox = target.matches && target.matches("input[type='checkbox']")
        ? target
        : target.querySelector("input[type='checkbox']");
      function isChecked() {
        return !!(
          (checkbox && checkbox.checked) ||
          target.getAttribute("aria-checked") === "true" ||
          target.classList.contains("ant-checkbox-wrapper-checked") ||
          target.querySelector(".ant-checkbox-checked")
        );
      }
      if (isChecked()) return true;

      var clicked = await clickAntActionInPage(target, 3000);
      if (!clicked) await safeClick(target);
      for (var attempt = 0; attempt < 12; attempt += 1) {
        if (isChecked()) return true;
        await sleep(100);
      }
      if (clicked) {
        await safeClick(target);
        for (var retry = 0; retry < 8; retry += 1) {
          if (isChecked()) return true;
          await sleep(100);
        }
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  function refreshSequenceScope(step, fallbackScope) {
    if (!step || !step.scopeSelector || !Number.isInteger(step.repeatIndex)) return fallbackScope || document;
    if (step.sharedRepeatScope === true) {
      try {
        var liveCard = findStepCard(step, document) || document;
        var liveEditors = queryVisibleIncludingRoot(liveCard, step.repeatReadySelector || step.scopeSelector).filter(isVisible);
        return liveEditors[liveEditors.length - 1] || fallbackScope || document;
      } catch (eSharedRepeatScope) { return fallbackScope || document; }
    }
    try {
      // 重复卡片在选择联动字段后可能被站点局部重绘。此时不能继续使用
      // 旧卡片节点，必须从明确的大类根节点中重新取得当前第 N 张卡。
      // root 省略时保持原来的全页面查找，避免影响既有站点。
      var root = document;
      if (step.scopeRefreshRootSelector) {
        root = document.querySelector(step.scopeRefreshRootSelector) || document;
      }
      return Array.from(root.querySelectorAll(step.scopeSelector)).filter(isVisible)[step.repeatIndex] || fallbackScope || document;
    } catch (e) {
      return fallbackScope || document;
    }
  }

  function findVisibleCascaderOption(selector, value) {
    var wanted = normalizeText(value);
    if (!wanted) return null;
    var nodes = [];
    try { nodes = Array.from(document.querySelectorAll(selector)); } catch (e) {}
    var visible = nodes.filter(isVisible);
    return visible.find(function (node) {
      return normalizeText(node.textContent) === wanted;
    }) || visible.find(function (node) {
      var text = normalizeText(node.textContent);
      return text && (text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1);
    }) || null;
  }

  function hasVisibleCascaderOptions(selector) {
    try {
      return Array.from(document.querySelectorAll(selector)).some(isVisible);
    } catch (e) {
      return false;
    }
  }

  async function clickCascaderElement(element, useMouseSequence) {
    if (!element) return false;
    try { element.scrollIntoView && element.scrollIntoView({ block: "center", inline: "nearest" }); } catch (e) {}
    try { element.focus && element.focus(); } catch (e2) {}
    if (useMouseSequence) {
      try {
        // 交通银行当前 Ant Cascader 在 DOM 中预渲染了隐藏菜单，真正打开动作
        // 绑定在 selector 的 mousedown，而不是 HTMLElement.click()。必须模拟
        // 一次完整鼠标操作；只调用 click() 时 dropdown 会一直保留 hidden 类。
        ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach(function (eventName) {
          var EventCtor = /^pointer/.test(eventName) && typeof PointerEvent === "function" ? PointerEvent : MouseEvent;
          element.dispatchEvent(new EventCtor(eventName, {
            bubbles: true,
            cancelable: true,
            composed: true,
            view: window,
            button: 0,
            buttons: /down$/.test(eventName) ? 1 : 0,
          }));
        });
        await sleep(100);
        return true;
      } catch (eMouseSequence) {}
    }
    try {
      // 农行使用的旧版 Ant Cascader 不响应 DomUtils.safeClickElement 中带
      // buttons=1 的合成 click；HTMLElement.click() 能正确触发 React onClick。
      element.click();
      await sleep(80);
      return true;
    } catch (e3) {
      return safeClick(element);
    }
  }

  function ensureAntCascaderBridge() {
    if (antCascaderBridgePromise) return antCascaderBridgePromise;
    antCascaderBridgePromise = new Promise(function (resolve) {
      // 交行 CSP 会阻止通过页面 <script src=chrome-extension://...> 动态注入。
      // 让 service worker 使用 chrome.scripting 在 MAIN world 执行，才能读取
      // React 私有 props 并驱动 rc-cascader。此方式也适用于其他严格 CSP 站点。
      try {
        chrome.runtime.sendMessage({ action: "ensureAntMainBridge" }, function (response) {
          if (chrome.runtime.lastError) {
            try { document.documentElement.setAttribute("data-af-ant-inject-error", chrome.runtime.lastError.message || "runtime_error"); } catch (eMarker) {}
            resolve(false);
            return;
          }
          try { document.documentElement.setAttribute("data-af-ant-inject-error", response && response.success ? "" : String(response && response.error || "inject_failed")); } catch (eMarker2) {}
          resolve(!!(response && response.success));
        });
      } catch (e) { resolve(false); }
    });
    return antCascaderBridgePromise;
  }

  async function fillAntCascaderInPage(trigger, values, timeoutMs) {
    lastCascaderError = "";
    if (!trigger) {
      lastCascaderError = "cascader_trigger_not_found";
      return false;
    }
    var missingIndex = values.findIndex(function (value) {
      return value === null || value === undefined || String(value).trim() === "";
    });
    if (missingIndex !== -1) {
      lastCascaderError = "cascader_path_level_" + (missingIndex + 1) + "_missing";
      return false;
    }
    if (!await ensureAntCascaderBridge()) {
      lastCascaderError = "ant_cascader_bridge_load_failed";
      return false;
    }
    var token = "af_cascader_" + Date.now() + "_" + Math.random().toString(36).slice(2);
    var id = token + "_fill";
    trigger.setAttribute("data-af-ant-cascader-token", token);
    var wrapper = trigger.closest && trigger.closest(".ant-cascader-picker, .ant-select.ant-cascader, .ant-cascader");
    if (wrapper) wrapper.setAttribute("data-af-ant-cascader-token", token);
    return new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        lastCascaderError = "ant_cascader_bridge_timeout";
        resolve(false);
      }, timeoutMs || 9000);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (data.type !== "AF_ANT_CASCADER_RESULT_V2" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        lastCascaderError = data.ok ? "" : (data.error || "ant_cascader_bridge_failed");
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: "AF_ANT_CASCADER_REQUEST_V2",
        id: id,
        token: token,
        values: values.map(function (value) { return String(value == null ? "" : value); }),
      }, "*");
    });
  }

  async function clickAntActionInPage(element, timeoutMs) {
    if (!element || !await ensureAntCascaderBridge()) return false;
    // findByText 可能命中包含按钮文字的外层 resumeForm。React 的 onClick
    // 实际绑定在内部 button，桥接标记必须落到真正的可点击元素上。
    if (!element.matches || !element.matches("button, a, [role='button']")) {
      var nestedAction = null;
      try {
        nestedAction = Array.from(element.querySelectorAll("button, a, [role='button']")).find(isVisible) || null;
      } catch (eNestedAction) {}
      if (nestedAction) element = nestedAction;
    }
    var token = "af_action_" + Date.now() + "_" + Math.random().toString(36).slice(2);
    var id = token + "_click";
    element.setAttribute("data-af-ant-action-token", token);
    return new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, timeoutMs || 3000);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (data.type !== "AF_ANT_ACTION_CLICK_RESULT_V2" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({ type: "AF_ANT_ACTION_CLICK_REQUEST_V2", id: id, token: token }, "*");
    });
  }

  async function typeAntSearchInPage(input, value, timeoutMs) {
    if (!input || !await ensureAntCascaderBridge()) return false;
    var token = "af_ant_special_" + Date.now() + "_" + Math.random().toString(36).slice(2);
    var id = token + "_type";
    input.setAttribute("data-af-ant-token", token);
    return new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, timeoutMs || 6000);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (data.type !== "AF_ANT_TYPE_RESULT_V2" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok && normalizeText(data.value) === normalizeText(value));
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        // schoolSearch 已经位于打开的交行 Cascader 内，禁止 MAIN bridge
        // 再次开关 owning select，否则会把真正的搜索区域切走。
        type: "AF_ANT_DIRECT_TYPE_REQUEST_V2",
        id: id,
        token: token,
        value: String(value == null ? "" : value),
      }, "*");
    });
  }

  async function clickAntSearchOptionInPage(input, option, value, timeoutMs) {
    if (!input || !await ensureAntCascaderBridge()) return false;
    var inputToken = input.getAttribute("data-af-ant-token") || "";
    if (!inputToken) {
      inputToken = "af_ant_special_" + Date.now() + "_" + Math.random().toString(36).slice(2);
      input.setAttribute("data-af-ant-token", inputToken);
    }
    var optionToken = "";
    if (option) {
      optionToken = "af_ant_special_option_" + Date.now() + "_" + Math.random().toString(36).slice(2);
      option.setAttribute("data-af-ant-option-token", optionToken);
    }
    var id = (optionToken || inputToken) + "_click";
    return new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, timeoutMs || 7000);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (data.type !== "AF_ANT_CLICK_RESULT_V2" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: "AF_ANT_CLICK_REQUEST_V2",
        id: id,
        token: optionToken,
        inputToken: inputToken,
        value: String(value == null ? "" : value),
      }, "*");
    });
  }

  function findVisibleBankcommSearchInput(inputId) {
    var candidates = [];
    try { candidates = Array.from(document.querySelectorAll("input[id='" + inputId + "']")).filter(isVisible); } catch (e) {}
    // 多条教育经历会重复生成相同 id；当前新打开的 portal 节点通常位于 DOM 最后。
    return candidates[candidates.length - 1] || null;
  }

  async function typeBankcommVisibleSearchInput(input, value, timeoutMs) {
    if (!input || !hasMeaningfulValue(value)) return null;
    var inputId = input.id || "";
    var wanted = String(value).trim();
    var bridgeOk = await typeAntSearchInPage(input, wanted, timeoutMs || 6000);
    var current = inputId ? findVisibleBankcommSearchInput(inputId) : input;
    if (bridgeOk && current && isVisible(current) && normalizeText(current.value) === normalizeText(wanted)) return current;
    current = await waitUntil(function () {
      var node = inputId ? findVisibleBankcommSearchInput(inputId) : input;
      return node && isVisible(node) ? node : null;
    }, 800);
    if (!current) return null;
    try {
      current.focus && current.focus();
      current.select && current.select();
      var inserted = !!(document.execCommand && document.execCommand("insertText", false, wanted));
      if (!inserted || normalizeText(current.value) !== normalizeText(wanted)) {
        var descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
        if (descriptor && descriptor.set) descriptor.set.call(current, wanted);
        else current.value = wanted;
        current.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: wanted, inputType: "insertText" }));
        current.dispatchEvent(new Event("change", { bubbles: true, cancelable: true, composed: true }));
      }
    } catch (eDirectSearch) {}
    await sleep(350);
    current = inputId ? findVisibleBankcommSearchInput(inputId) : current;
    return current && isVisible(current) && normalizeText(current.value) === normalizeText(wanted) ? current : null;
  }

  async function fillBankcommCommitmentCheckboxes(scope, item) {
    var root = scope || document;
    var requiredCount = Math.max(1, Number(item && item.requiredCount || 2));
    var entries = [];
    var seenInputs = [];
    try {
      Array.from(root.querySelectorAll("label.ant-checkbox-wrapper, .ant-checkbox-wrapper, label, [role='checkbox'], input[type='checkbox']"))
        .filter(isVisible)
        .forEach(function (node) {
          var wrapper = node.matches && node.matches("input[type='checkbox']")
            ? (node.closest && node.closest("label, .ant-checkbox-wrapper, [role='checkbox']") || node)
            : node;
          var text = normalizeText((wrapper && wrapper.textContent) || (node && node.textContent) || "");
          if (text.indexOf("本人承诺") === -1) return;
          var input = wrapper && wrapper.matches && wrapper.matches("input[type='checkbox']")
            ? wrapper
            : (wrapper && wrapper.querySelector ? wrapper.querySelector("input[type='checkbox']") : null);
          if (!input && node && node.matches && node.matches("input[type='checkbox']")) input = node;
          if (!input || seenInputs.indexOf(input) !== -1) return;
          seenInputs.push(input);
          entries.push({ wrapper: wrapper || input, input: input });
        });
    } catch (eFindCommitments) {}
    if (entries.length < requiredCount) return false;
    var checkedCount = 0;
    for (var i = 0; i < entries.length; i++) {
      var entry = entries[i];
      var input = entry.input;
      var wrapper = entry.wrapper || input;
      var checked = !!input.checked ||
        String(input.getAttribute && input.getAttribute("aria-checked") || "") === "true" ||
        /ant-checkbox-wrapper-checked|ant-checkbox-checked/.test(String(wrapper.className || ""));
      if (!checked) {
        try { await safeClick(wrapper); } catch (eCommitClick) {
          try { input.click(); } catch (eCommitInputClick) {}
        }
        await sleep(100);
      }
      var liveChecked = !!input.checked ||
        String(input.getAttribute && input.getAttribute("aria-checked") || "") === "true" ||
        /ant-checkbox-wrapper-checked|ant-checkbox-checked/.test(String(wrapper.className || "")) ||
        !!(wrapper.querySelector && wrapper.querySelector(".ant-checkbox-checked"));
      if (liveChecked) checkedCount += 1;
    }
    return checkedCount >= requiredCount;
  }

  function findVisibleBankcommResearchCheckbox(checkboxText) {
    var wanted = normalizeText(checkboxText || "若未找到，请填写研究方向");
    var nodes = [];
    try {
      nodes = Array.from(document.querySelectorAll(
        "label.ant-checkbox-wrapper, .ant-checkbox-wrapper, label, [role='checkbox']"
      )).filter(isVisible);
    } catch (eResearchCheckboxGlobal) {}
    return nodes.find(function (node) {
      return normalizeText(node.textContent).indexOf(wanted) !== -1;
    }) || null;
  }

  function resolveBankcommResearchPopupFromCheckbox(checkboxWrapper) {
    if (!checkboxWrapper) return null;
    var node = checkboxWrapper;
    var best = null;
    for (var depth = 0; node && depth < 9; depth += 1, node = node.parentElement) {
      if (!isVisible(node)) continue;
      var text = normalizeText(node.textContent);
      var hasMenu = false;
      var hasInput = false;
      var hasSubmit = false;
      try {
        hasMenu = !!node.querySelector(".ant-cascader-menu-item, .ant-cascader-menu, .ant-cascader-menus");
        hasInput = !!Array.from(node.querySelectorAll("input:not([type='checkbox']):not([type='hidden'])")).filter(isVisible).length;
        hasSubmit = !!Array.from(node.querySelectorAll("button, a, [role='button']")).filter(isVisible).some(function (action) {
          return normalizeText(action.textContent) === "提交";
        });
      } catch (eResearchPopupScope) {}
      if (hasMenu || hasInput || hasSubmit) best = node;
      if (hasMenu && hasInput) return node;
      if (text && text.length > 5000) break;
    }
    return best || checkboxWrapper.parentElement || checkboxWrapper;
  }

  async function openBankcommResearchCustomDropdown(formItem, checkboxText, item) {
    if (!formItem) return null;
    var existingCheckbox = findVisibleBankcommResearchCheckbox(checkboxText);
    if (existingCheckbox) {
      return {
        trigger: null,
        checkboxWrapper: existingCheckbox,
        dropdown: resolveBankcommResearchPopupFromCheckbox(existingCheckbox),
      };
    }

    var selectors = [
      ".ant-cascader-picker input",
      ".ant-select.ant-cascader input",
      "input.ant-cascader-input",
      ".ant-cascader-picker-label",
      ".ant-select-selection",
      ".ant-select-selector",
      ".ant-cascader-picker",
      ".ant-select.ant-cascader",
      ".ant-cascader"
    ];
    var triggers = [];
    var seen = [];
    selectors.forEach(function (selector) {
      var found = [];
      try { found = Array.from(formItem.querySelectorAll(selector)); } catch (eResearchTriggerQuery) {}
      found.filter(isVisible).forEach(function (node) {
        if (seen.indexOf(node) !== -1) return;
        seen.push(node);
        triggers.push(node);
      });
    });

    for (var i = 0; i < triggers.length; i += 1) {
      var trigger = triggers[i];
      try { await clickCascaderElement(trigger, true); } catch (eResearchMouseOpen) {}
      var checkbox = await waitUntil(function () {
        return findVisibleBankcommResearchCheckbox(checkboxText);
      }, item && item.fallbackOpenAttemptTimeoutMs || 550);
      if (!checkbox) {
        try { await safeClick(trigger); } catch (eResearchSafeOpen) {}
        checkbox = await waitUntil(function () {
          return findVisibleBankcommResearchCheckbox(checkboxText);
        }, item && item.fallbackOpenAttemptTimeoutMs || 550);
      }
      if (checkbox) {
        return {
          trigger: trigger,
          checkboxWrapper: checkbox,
          dropdown: resolveBankcommResearchPopupFromCheckbox(checkbox),
        };
      }
    }
    return null;
  }

  function findVisibleBankcommResearchDropdown(checkboxText, trigger) {
    var wanted = normalizeText(checkboxText || "若未找到，请填写研究方向");
    var candidates = [];
    var seen = [];
    function addCandidate(node) {
      if (!node || seen.indexOf(node) !== -1 || !isVisible(node)) return;
      seen.push(node);
      candidates.push(node);
    }

    // Ant Design 3.x/rc-cascader（交行当前页面）会把 popup 直接 portal 成
    // `.ant-cascader-menus`，并不一定存在 `.ant-cascader-dropdown` 外壳。
    // Build121 只认后两种 dropdown，因此“肉眼已经展开”仍会误报
    // research_custom_dropdown_not_found。先覆盖 Ant 旧/新两代真实 popup 根。
    try {
      Array.from(document.querySelectorAll(
        ".ant-cascader-dropdown:not(.ant-cascader-dropdown-hidden), " +
        ".ant-select-dropdown:not(.ant-select-dropdown-hidden), " +
        ".ant-cascader-menus, " +
        ".ant-cascader-menu"
      )).forEach(addCandidate);
    } catch (eDropdown) {}

    // 若触发控件暴露 aria-controls / aria-owns，优先把它关联的 portal 加入候选。
    // 这样页面同时存在多个 Cascader 时不会误拿另一个教育字段的菜单。
    try {
      var ariaNodes = [trigger].concat(trigger ? Array.from(trigger.querySelectorAll("[aria-controls], [aria-owns]")) : []);
      ariaNodes.forEach(function (node) {
        if (!node || !node.getAttribute) return;
        ["aria-controls", "aria-owns"].forEach(function (attr) {
          String(node.getAttribute(attr) || "").split(/\s+/).filter(Boolean).forEach(function (id) {
            var owned = document.getElementById(id);
            if (!owned) return;
            addCandidate(owned);
            var parent = owned.parentElement;
            for (var depth = 0; parent && depth < 4; depth++, parent = parent.parentElement) addCandidate(parent);
          });
        });
      });
    } catch (eAriaPopup) {}

    // 某些交行构建把“若未找到”footer 放在 `.ant-cascader-menus` 的父层。
    // 从唯一的 checkbox 文案反向向上找 popup，避免依赖易变 class 名。
    try {
      Array.from(document.querySelectorAll(
        "label.ant-checkbox-wrapper, .ant-checkbox-wrapper, label, [role='checkbox']"
      )).filter(isVisible).forEach(function (checkboxNode) {
        if (normalizeText(checkboxNode.textContent).indexOf(wanted) === -1) return;
        addCandidate(checkboxNode);
        var parent = checkboxNode.parentElement;
        for (var depth = 0; parent && depth < 6; depth++, parent = parent.parentElement) {
          addCandidate(parent);
          try {
            if (parent.querySelector(".ant-cascader-menu-item, .ant-cascader-menu, .ant-cascader-menus")) break;
          } catch (ePopupParentQuery) {}
        }
      });
    } catch (eCheckboxPopup) {}

    var matched = candidates.filter(function (node) {
      return normalizeText(node.textContent).indexOf(wanted) !== -1;
    });
    if (!matched.length) return null;

    // 选离当前研究方向 trigger 最近的那个 popup；没有几何信息时取最后创建的。
    if (trigger && trigger.getBoundingClientRect) {
      try {
        var tr = trigger.getBoundingClientRect();
        matched.sort(function (a, b) {
          var ar = a.getBoundingClientRect();
          var br = b.getBoundingClientRect();
          var ad = Math.abs(ar.left - tr.left) + Math.min(Math.abs(ar.top - tr.bottom), Math.abs(ar.bottom - tr.top));
          var bd = Math.abs(br.left - tr.left) + Math.min(Math.abs(br.top - tr.bottom), Math.abs(br.bottom - tr.top));
          // 更小的容器通常是实际 popup，而不是 body 级祖先；距离相同时优先小面积。
          if (ad !== bd) return ad - bd;
          return (ar.width * ar.height) - (br.width * br.height);
        });
        return matched[0] || null;
      } catch (ePopupGeometry) {}
    }
    return matched[matched.length - 1] || null;
  }

  var lastBankcommResearchCustomError = "";

  async function typeBankcommResearchCustomInputInPage(input, value, timeoutMs) {
    if (!input || !hasMeaningfulValue(value) || !await ensureAntCascaderBridge()) return false;
    var token = "af_bankcomm_research_custom_" + Date.now() + "_" + Math.random().toString(36).slice(2);
    var id = token + "_type";
    input.setAttribute("data-af-ant-token", token);
    return new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, timeoutMs || 3500);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (data.type !== "AF_ANT_TYPE_RESULT_V2" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok && normalizeText(data.value) === normalizeText(value));
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: "AF_ANT_DIRECT_TYPE_REQUEST_V2",
        id: id,
        token: token,
        value: String(value == null ? "" : value),
        // 与学校/专业搜索不同，这个输入框的“提交”按钮读取组件 state。
        // DOM value 正确并不代表 React state 已更新，因此要求 MAIN bridge
        // 在输入后显式调用受控组件 onInput/onChange 再返回。
        forceReactCommit: true,
      }, "*");
    });
  }

  async function fillBankcommResearchCustomValue(label, value, item) {
    lastBankcommResearchCustomError = "";
    if (!label || !hasMeaningfulValue(value)) return false;
    var formItem = label.closest && label.closest(".ant-form-item");
    if (!formItem) { lastBankcommResearchCustomError = "research_trigger_not_found"; return false; }

    var checkboxText = item && item.fallbackCheckboxText || "若未找到，请填写研究方向";
    // 交行当前研究方向是 Ant 3/rc-cascader。真正开菜单的处理器可能绑在
    // input/label/selection，而不是外层 `.ant-cascader`。Build122 只点外层，
    // 所以自动流程中菜单从未出现。这里逐个尝试真实可点击子节点，并以
    // 唯一的“若未找到”checkbox 变为可见作为“菜单已打开”的判据。
    var opened = await openBankcommResearchCustomDropdown(formItem, checkboxText, item);
    if (!opened) { lastBankcommResearchCustomError = "research_custom_menu_not_opened"; return false; }
    var trigger = opened.trigger || formItem.querySelector(
      ".ant-cascader-picker input, .ant-select.ant-cascader input, input.ant-cascader-input, .ant-cascader-picker, .ant-select.ant-cascader, .ant-cascader"
    );
    var checkboxWrapper = opened.checkboxWrapper || findVisibleBankcommResearchCheckbox(checkboxText);
    var dropdown = opened.dropdown || resolveBankcommResearchPopupFromCheckbox(checkboxWrapper) ||
      findVisibleBankcommResearchDropdown(checkboxText, trigger);
    if (!dropdown) { lastBankcommResearchCustomError = "research_custom_dropdown_not_found"; return false; }
    if (!checkboxWrapper) { lastBankcommResearchCustomError = "research_custom_checkbox_not_found"; return false; }

    // 勾选前记录当前 popup 里的输入框。交行这里始终存在一个“试试搜索研究方向”的
    // 旧搜索框；勾选“若未找到”之后才会新增真正的自定义研究方向输入框，并在同一行
    // 出现蓝色“提交”按钮。Build123 误把旧搜索框（id=researchSearch）当成自定义框，
    // 所以肉眼能看到“无”却无法写回主字段。这里必须锁定“新增且与提交按钮同组”的输入。
    var inputsBeforeCustom = [];
    try {
      inputsBeforeCustom = Array.from(dropdown.querySelectorAll("input:not([type='checkbox']):not([type='hidden'])")).filter(isVisible);
    } catch (eResearchInputsBeforeCustom) {}

    var checkboxInput = null;
    try { checkboxInput = checkboxWrapper.querySelector("input[type='checkbox']"); } catch (eCheckboxInput) {}
    var checked = !!(checkboxInput && checkboxInput.checked) || /ant-checkbox-wrapper-checked|ant-checkbox-checked/.test(String(checkboxWrapper.className || ""));
    if (!checked) {
      try {
        if (checkboxInput && typeof checkboxInput.click === "function") checkboxInput.click();
        else if (typeof checkboxWrapper.click === "function") checkboxWrapper.click();
        else await safeClick(checkboxWrapper);
      } catch (eClickResearchCheckbox) {
        try { await safeClick(checkboxWrapper); } catch (eResearchFallbackClick2) {}
      }
      await sleep(120);
    }

    var submitText = normalizeText(item && item.fallbackSubmitButtonText || "提交");
    var customRow = await waitUntil(function () {
      var liveDropdown = findVisibleBankcommResearchDropdown(checkboxText, trigger) || dropdown;
      var actions = [];
      try {
        actions = Array.from(liveDropdown.querySelectorAll("button, a, [role='button']")).filter(isVisible);
      } catch (eResearchCustomRowActions) {}
      var submit = actions.find(function (node) {
        return normalizeText(node.textContent) === submitText;
      }) || null;
      if (!submit) return null;

      var candidates = [];
      var node = submit.parentElement;
      for (var depth = 0; node && depth < 4; depth += 1, node = node.parentElement) {
        try {
          Array.from(node.querySelectorAll("input:not([type='checkbox']):not([type='hidden'])")).filter(isVisible).forEach(function (inputNode) {
            if (candidates.indexOf(inputNode) === -1) candidates.push(inputNode);
          });
        } catch (eResearchCustomRowInputs) {}
        if (candidates.length) break;
      }

      // 第一优先：勾选之后新出现、且不是旧搜索框的输入。
      var customInput = candidates.find(function (inputNode) {
        var placeholder = normalizeText(inputNode.getAttribute && inputNode.getAttribute("placeholder"));
        if (inputNode.id === "researchSearch") return false;
        if (/搜索研究方向|试试搜索/.test(placeholder)) return false;
        return inputsBeforeCustom.indexOf(inputNode) === -1;
      }) || null;

      // React 可能重建节点，节点 identity 不能作为唯一依据；退而求其次，仍只接受
      // 与“提交”同组且明确不是搜索框的输入。
      if (!customInput) {
        customInput = candidates.find(function (inputNode) {
          var placeholder = normalizeText(inputNode.getAttribute && inputNode.getAttribute("placeholder"));
          return inputNode.id !== "researchSearch" && !/搜索研究方向|试试搜索/.test(placeholder);
        }) || null;
      }
      return customInput ? { input: customInput, submitButton: submit } : null;
    }, item && item.fallbackInputTimeoutMs || 1800);
    if (!customRow || !customRow.input) {
      lastBankcommResearchCustomError = "research_custom_new_input_not_found";
      return false;
    }

    var input = customRow.input;
    var submitButton = customRow.submitButton;
    var typedOk = await typeBankcommResearchCustomInputInPage(input, value, item && item.fallbackTypeTimeoutMs || 3500);
    var typed = input && input.id ? findVisibleBankcommSearchInput(input.id) : input;
    if (!typedOk && typed) {
      try { await AF.FormHandler.fillFormElement(input, value, "text"); } catch (eFallbackResearchText) {}
      typed = input;
    }
    if (!typed) { lastBankcommResearchCustomError = "research_custom_input_commit_failed"; return false; }
    try {
      typed.dispatchEvent(new Event("change", { bubbles: true, cancelable: true, composed: true }));
    } catch (eCommitResearchFallback) {}
    await sleep(120);

    // 交行“若未找到，请填写研究方向”不是普通自由文本：输入后还必须点击
    // 弹层里的“提交”，React 才会把自定义值真正回写到主 Cascader。
    // Build119 只验证了输入框 value 后就按 Escape 收层，页面因此仍显示
    // “请选择研究方向”，保存自然被必填校验拦住。这里把“输入 → 提交 →
    // 主字段回写”作为一个完整事务，只有回写成功才返回 true。
    var committed = normalizeText(typed && typed.value) === normalizeText(value);
    var liveCheckbox = null;
    try { liveCheckbox = checkboxWrapper.querySelector("input[type='checkbox']"); } catch (eLiveCheckbox) {}
    var stillChecked = !!(liveCheckbox && liveCheckbox.checked) || /ant-checkbox-wrapper-checked|ant-checkbox-checked/.test(String(checkboxWrapper.className || ""));
    if (!committed) { lastBankcommResearchCustomError = "research_custom_input_value_not_committed"; return false; }
    if (!stillChecked) { lastBankcommResearchCustomError = "research_custom_checkbox_lost"; return false; }

    // 优先复用与“新增自定义输入框”同组锁定的提交按钮；若 React 重绘导致节点
    // 失效，再从当前 popup 重新定位一次。
    if (!submitButton || !isVisible(submitButton)) {
      submitButton = await waitUntil(function () {
        var liveDropdown = findVisibleBankcommResearchDropdown(checkboxText, trigger) || dropdown;
        var actions = [];
        try {
          actions = Array.from(liveDropdown.querySelectorAll("button, a, [role='button']")).filter(isVisible);
        } catch (eResearchSubmitButtons) {}
        return actions.find(function (node) {
          return normalizeText(node.textContent) === submitText;
        }) || null;
      }, item && item.fallbackSubmitTimeoutMs || 1500);
    }
    if (!submitButton) { lastBankcommResearchCustomError = "research_custom_submit_not_found"; return false; }

    var submitClicked = false;
    try { submitClicked = await clickAntActionInPage(submitButton, item && item.fallbackSubmitClickTimeoutMs || 3000); } catch (eResearchSubmitBridge) {}
    if (!submitClicked) {
      try { await safeClick(submitButton); submitClicked = true; } catch (eResearchSubmitDom) {}
    }
    if (!submitClicked) { lastBankcommResearchCustomError = "research_custom_submit_click_failed"; return false; }

    var writeback = await waitUntil(function () {
      var currentItem = label.closest && label.closest(".ant-form-item");
      var selected = currentItem && currentItem.querySelector(
        ".ant-select-selection-item, .ant-select-selection-selected-value, .ant-cascader-picker-label, .ant-select-selection__rendered"
      );
      var selectedText = normalizeText(selected && (selected.getAttribute("title") || selected.textContent));
      var wantedText = normalizeText(value);
      if (selectedText && (selectedText === wantedText || selectedText.indexOf(wantedText) !== -1)) return selected;
      return null;
    }, item && item.fallbackWritebackTimeoutMs || 3200);

    if (writeback) { lastBankcommResearchCustomError = ""; return true; }
    lastBankcommResearchCustomError = "research_custom_writeback_not_observed";
    return false;
  }

  // 兴业银行学校名称表面是普通 ant-input，实际由 Vue 监听真实编辑事件后
  // 远程生成 ant-dropdown-menu-item。直接设置 value 只会“看起来有字”，
  // 不会产生候选，也不会写入学校对象。必须走 MAIN world 输入并点击候选。
  async function fillCibSchool(value, item, scope) {
    if (!hasMeaningfulValue(value)) return false;
    var root = refreshSequenceScope(null, scope) || scope || document;
    var input = null;
    try {
      input = Array.from(root.querySelectorAll(
        ".querySchoolByCountry input[placeholder*='三个关键字'], input[placeholder*='三个关键字']"
      )).filter(isVisible)[0] || null;
    } catch (eFindCibSchool) {}
    if (!input) return false;
    var wanted = String(value).trim();
    try { await safeClick(input); } catch (eClickCibSchool) {}
    var liveInput = await typeBankcommVisibleSearchInput(input, wanted, item && item.inputTimeoutMs || 6500);
    if (!liveInput) return false;
    var option = await waitUntil(function () {
      var candidates = [];
      try {
        candidates = Array.from(document.querySelectorAll(
          ".ant-dropdown:not(.ant-dropdown-hidden) .ant-dropdown-menu-item, " +
          ".ant-dropdown-menu:not(.ant-dropdown-menu-hidden) .ant-dropdown-menu-item, " +
          "[role='listbox'] [role='option']"
        )).filter(isVisible);
      } catch (eOptions) {}
      return candidates.find(function (node) {
        return normalizeText(node.textContent) === normalizeText(wanted);
      }) || (item && item.allowFirstOptionFallback === false ? null : candidates[0]) || null;
    }, item && item.optionTimeoutMs || 5000);
    if (!option) return false;
    var clicked = await clickAntSearchOptionInPage(liveInput, option, wanted, item && item.clickTimeoutMs || 5000);
    if (!clicked) await safeClick(option);
    return !!(await waitUntil(function () {
      return normalizeText(input.value) === normalizeText(wanted) && !isVisible(option) ? true : null;
    }, item && item.commitTimeoutMs || 1800));
  }

  async function fillDependentCascader(label, values, item) {
    values = (values || []).map(function (value) {
      return value === null || value === undefined ? "" : String(value).trim();
    });
    var missingIndex = values.findIndex(function (value) { return !value; });
    if (missingIndex !== -1) {
      lastCascaderError = "cascader_path_level_" + (missingIndex + 1) + "_missing";
      return false;
    }
    var formItem = label && label.closest && label.closest(
      item.formItemSelector || ".ant-form-item, .form-item, [class*='form-item']"
    );
    var triggerSelector = item.triggerSelector ||
      ".ant-cascader-picker input, .ant-select.ant-cascader input, input.ant-cascader-input, .ant-cascader-picker, .ant-select.ant-cascader, .ant-cascader, input[readonly]";
    if (!formItem || !formItem.querySelector(triggerSelector)) {
      var root = label && label.closest && label.closest(".ant-modal-wrap, .ant-modal-content, form") || document;
      var wantedLabel = normalizeText(label && label.textContent);
      var candidates = [];
      try {
        candidates = Array.from(root.querySelectorAll(item.formItemSelector || ".ant-form-item, .form-item, [class*='form-item']"));
      } catch (e) {}
      formItem = candidates.find(function (candidate) {
        if (!candidate.querySelector(triggerSelector)) return false;
        var labelNode = candidate.querySelector(".ant-form-item-label, label, [class*='label']");
        var text = normalizeText(labelNode && labelNode.textContent);
        return text && wantedLabel && (text === wantedLabel || text.indexOf(wantedLabel) !== -1 || wantedLabel.indexOf(text) !== -1);
      }) || null;
    }
    if (!formItem) {
      lastCascaderError = "cascader_form_item_not_found";
      return false;
    }
    var trigger = null;
    try {
      trigger = formItem.querySelector(triggerSelector);
    } catch (e) {}
    if (!trigger) {
      lastCascaderError = "cascader_trigger_not_found";
      return false;
    }
    if (!item.skipAntBridge && await fillAntCascaderInPage(trigger, values, item.bridgeTimeoutMs)) return true;
    var optionSelector = item.optionSelector ||
      ".ant-cascader-menu-item, .ant-cascader-menu li, .ant-cascader-menus li";
    await clickCascaderElement(trigger, item.useMouseSequence === true);
    await sleep(item.waitAfterOpenMs == null ? 250 : item.waitAfterOpenMs);
    if (!hasVisibleCascaderOptions(optionSelector)) {
      var wrapper = trigger.closest && trigger.closest(".ant-cascader-picker, .ant-select.ant-cascader, .ant-cascader");
      if (wrapper && wrapper !== trigger) await clickCascaderElement(wrapper, item.useMouseSequence === true);
      await sleep(item.waitAfterOpenRetryMs == null ? 250 : item.waitAfterOpenRetryMs);
    }
    if (!hasVisibleCascaderOptions(optionSelector)) return false;

    for (var i = 0; i < values.length; i++) {
      var value = values[i];
      var option = await waitUntil(function () {
        return findVisibleCascaderOption(optionSelector, value);
      }, item.optionTimeoutMs || 3500);
      if (!option) return false;
      await clickCascaderElement(option, item.useMouseSequence === true);
      await sleep(item.waitAfterOptionMs == null ? 250 : item.waitAfterOptionMs);
    }
    return true;
  }

  async function fillAbcMajorWithOther(matcher, label, data, item, scope) {
    var majorValue = data && data[item.majorField || "major"];
    var values = (item.dataFields || []).map(function (field) { return data && data[field]; });
    var hasFullPath = values.every(function (value) {
      return value !== null && value !== undefined && String(value).trim() !== "";
    });
    if (hasFullPath && await fillDependentCascader(label, values, item)) return true;
    if (!hasMeaningfulValue(majorValue)) return false;

    var otherOk = await fillDependentCascader(label, [item.otherOption || "其他"], Object.assign({}, item, {
      bridgeTimeoutMs: item.otherBridgeTimeoutMs || item.bridgeTimeoutMs,
      optionTimeoutMs: item.otherOptionTimeoutMs || item.optionTimeoutMs,
    }));
    if (!otherOk) return false;

    var startedAt = Date.now();
    var otherLabelText = item.otherLabel || "其他专业";
    while (Date.now() - startedAt < (item.otherInputTimeoutMs || 3500)) {
      var currentScope = refreshSequenceScope(stepLikeForScope(item), scope) || scope || document;
      var labels = matcher.findLabelsByCard(currentScope) || matcher.findAllLabels() || [];
      var otherLabel = findLabelForSequence(labels, otherLabelText);
      if (otherLabel) {
        var found = resolveSequenceControlByConfiguredType(matcher, otherLabel, {
          field: item.majorField || "major",
          label: otherLabelText,
        });
        if (found && found.element && found.type &&
            await AF.FormHandler.fillFormElement(found.element, majorValue, found.type)) {
          return true;
        }
      }
      await sleep(150);
    }
    return false;
  }

  function stepLikeForScope(item) {
    return { scopeSelector: item.scopeSelector || ".ant-modal-wrap" };
  }

  async function fillElementCascaderCheckbox(label, value, item) {
    var wanted = normalizeText(value);
    if (!wanted) return false;
    var formItem = label && label.closest && label.closest(".el-form-item");
    if (!formItem) return false;
    var trigger = formItem.querySelector(item.triggerSelector || ".el-cascader .el-input__wrapper, .el-cascader input, .el-cascader");
    if (!trigger) return false;
    await safeClick(trigger);
    await sleep(item.waitAfterOpenMs == null ? 280 : item.waitAfterOpenMs);

    function findLocalPanel() {
      try {
        return Array.from(formItem.querySelectorAll(".el-cascader__dropdown, .el-cascader-panel")).find(isVisible) || null;
      } catch (e) {
        return null;
      }
    }

    function panelContainsWanted(node) {
      return !!(node && normalizeText(node.textContent).indexOf(wanted) !== -1);
    }

    var panel = await waitUntil(function () {
      try {
        var local = findLocalPanel();
        if (local) return local;
        var visiblePanels = Array.from(document.querySelectorAll(".el-cascader__dropdown, .el-cascader-panel")).filter(isVisible);
        return visiblePanels.find(panelContainsWanted) || visiblePanels[0] || null;
      } catch (e) {
        return null;
      }
    }, item.panelTimeoutMs || 2500);
    if (!panel) {
      try {
        var wrapper = trigger.closest && trigger.closest(".el-input__wrapper, .el-cascader");
        if (wrapper && wrapper !== trigger) wrapper.click();
        else trigger.click && trigger.click();
      } catch (e0) {}
      await sleep(item.waitAfterOpenRetryMs == null ? 300 : item.waitAfterOpenRetryMs);
      panel = findLocalPanel();
    }
    if (!panel) return false;

    function findOption() {
      var nodes = [];
      try { nodes = Array.from(panel.querySelectorAll(".el-cascader-node")); } catch (e) {}
      return nodes.find(function (node) {
        return normalizeText(node.textContent) === wanted;
      }) || nodes.find(function (node) {
        var text = normalizeText(node.textContent);
        return text && (text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1);
      }) || null;
    }

    var option = findOption();
    if (!option) {
      var scrollBox = panel.querySelector(".el-scrollbar__wrap, .el-cascader-menu__wrap");
      for (var i = 0; i < 8 && !option && scrollBox; i++) {
        scrollBox.scrollTop = scrollBox.scrollTop + 240;
        await sleep(120);
        option = findOption();
      }
    }
    if (!option) return false;
    try { option.scrollIntoView && option.scrollIntoView({ block: "center", inline: "nearest" }); } catch (e2) {}
    await sleep(80);
    var checkbox = option.querySelector(".el-checkbox__inner") ||
      option.querySelector(".el-checkbox__input:not(.is-disabled)") ||
      option.querySelector("input[type='checkbox']:not(:disabled)") ||
      option.querySelector("input[type='checkbox']");
    await safeClick(checkbox || option);
    await sleep(item.waitAfterSelectMs == null ? 250 : item.waitAfterSelectMs);
    var immediateInput = option.querySelector("input[type='checkbox']");
    if (immediateInput && !immediateInput.checked) {
      try {
        (checkbox || option).click && (checkbox || option).click();
      } catch (e3) {}
      await sleep(180);
    }

    var selectedTags = Array.from(formItem.querySelectorAll(".el-cascader__tags .el-tag, .el-tag")).map(function (tag) {
      return normalizeText(tag.textContent);
    }).join("");
    var checkboxInput = option.querySelector("input[type='checkbox']");
    var optionChecked = (checkboxInput && checkboxInput.checked) || /is-checked|in-active-path/.test(String(option.className || ""));
    return selectedTags.indexOf(wanted) !== -1 || !!optionChecked;
  }

  function normalizeChoiceText(value) {
    // 招聘站点经常把同一个兜底选项写成“其他”或“其它”。
    // 这两个词在排名等枚举字段中语义等价；统一成“其他”，让候选查找、
    // Vue 提交后的 read-back 和保存前校验使用同一套规范值。
    return String(value == null ? "" : value)
      .replace(/\s+/g, "")
      .replace(/其它/g, "其他")
      .trim();
  }

  function choiceValueList(value) {
    if (Array.isArray(value)) {
      return value.map(function (item) { return String(item == null ? "" : item).trim(); }).filter(Boolean);
    }
    if (value && typeof value === "object") {
      var candidate = value.name || value.label || value.text || value.value || "";
      return candidate ? [String(candidate).trim()] : [];
    }
    var text = String(value == null ? "" : value).trim();
    return text ? [text] : [];
  }

  function optionTextMatches(node, value) {
    var text = normalizeChoiceText(node && node.textContent);
    var wanted = normalizeChoiceText(value);
    if (!text || !wanted) return false;
    if (text === wanted || text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1) return true;
    try {
      if (AF.DomUtils && typeof AF.DomUtils.isOptionMatch === "function") {
        return AF.DomUtils.isOptionMatch(node.textContent || "", value);
      }
    } catch (e) {}
    return false;
  }

  function getElementChoiceInput(container) {
    if (!container) return null;
    return Array.from(container.querySelectorAll(".el-input__inner, .el-select__input, input:not([type='hidden'])")).find(isVisible) || null;
  }

  function getElementChoiceCurrentValue(container) {
    var input = getElementChoiceInput(container);
    var inputValue = input && String(input.value || "").trim();
    if (inputValue) return inputValue;
    try {
      if (input && input.readOnly) {
        var placeholder = String(input.getAttribute("placeholder") || "").trim();
        if (placeholder && !/^(?:请选择|请输入|请填写|选择)/.test(placeholder)) return normalizeText(placeholder);
      }
      // Element Plus 2.x 的单选框经常把真实已选值渲染在
      // .el-select__selected-item / .el-select__selection 内，而内部 input.value
      // 保持为空。此前保存前复核只读 input，导致页面明明显示“其它”，
      // 却被误判为未选择，然后再次打开下拉把状态扰乱。优先读取真正的
      // 已选展示节点，并排除 placeholder。
      var selectedNodes = Array.from(container.querySelectorAll(
        ".el-select__selected-item, .el-select__selection-item, .el-select__selected, .el-select__selection .el-select__selected-item"
      )).filter(isVisible);
      var selectedText = selectedNodes.map(function (node) {
        var text = normalizeText(node.textContent);
        if (!text || /^(?:请选择|请输入|请填写|选择)$/.test(text)) return "";
        return text;
      }).filter(Boolean).join(" / ");
      if (selectedText) return selectedText;

      var cascaderLabel = container.querySelector(".el-cascader__label");
      if (cascaderLabel && normalizeText(cascaderLabel.textContent)) return normalizeText(cascaderLabel.textContent);
      return Array.from(container.querySelectorAll(".el-select__tags .el-tag, .el-cascader__tags .el-tag, .el-tag")).map(function (tag) {
        return normalizeText(tag.textContent);
      }).filter(Boolean).join(" / ");
    } catch (e) {
      return "";
    }
  }

  // 工行新版基本信息的籍贯、生源地和户口所在地不是 Cascader，而是同一
  // form item 中相互依赖的 Ant Select，部分页面版本为省、市、区三级。
  async function fillIcbcLinkedSelect(label, value, item) {
    var values = Array.isArray(value) ? value.filter(Boolean) : String(value || "").split(/\s*\/\s*|\s*>\s*/).filter(Boolean);
    if (!values.length) return false;
    var formItem = label && label.closest && label.closest(".ant-form-item");
    if (!formItem || !AF.SelectAdapter || typeof AF.SelectAdapter.create !== "function") return false;
    var selects = Array.from(formItem.querySelectorAll(".ant-select:not(.ant-select-disabled)")).filter(isVisible);
    // 页面可能只有省市两级；按实际控件数量填写已有层级，不因额外区县
    // 数据让整个字段失败。启用 dynamicLevels 时，每次选择后重新读取控件，
    // 兼容家庭住址在省/市选择完成后才动态渲染第三级区下拉的版本。
    var levelCount = item && item.dynamicLevels === true ? values.length : Math.min(values.length, selects.length);
    if (!levelCount) return false;
    for (var index = 0; index < levelCount; index++) {
      if (item && item.dynamicLevels === true && index >= selects.length) {
        await waitUntil(function () {
          selects = Array.from(formItem.querySelectorAll(".ant-select:not(.ant-select-disabled)")).filter(isVisible);
          return selects[index] || null;
        }, item.levelTimeoutMs || 1800);
      } else if (item && item.dynamicLevels === true) {
        selects = Array.from(formItem.querySelectorAll(".ant-select:not(.ant-select-disabled)")).filter(isVisible);
      }
      if (!selects[index]) return false;
      var selected = await AF.SelectAdapter.create(selects[index], "string").selectValue(values[index]);
      if (!selected) return false;
      await sleep(item && item.waitAfterEachMs == null ? 180 : item.waitAfterEachMs);
    }
    return true;
  }

  async function fillIcbcAddress(label, data, item) {
    var path = data && item && data[item.pathField];
    if (!Array.isArray(path) && path) path = String(path).split(/\s*\/\s*|\s*>\s*|\s*,\s*/).filter(Boolean);
    // 直辖市数据可能带有中间占位层“市辖区/县”，需要折叠为页面实际
    // 可选的地区层；普通省市区路径保持三级。
    if (Array.isArray(path) && path.length > 2 && (/^(?:市辖区|县)$/.test(String(path[1] || "")) || String(path[0] || "") === String(path[1] || ""))) {
      path = [path[0], path[2]].filter(Boolean);
    }
    var hasPath = Array.isArray(path) ? path.length > 0 : hasMeaningfulValue(path);
    var addressOk = !hasPath || await fillIcbcLinkedSelect(label, path, item);
    var detail = data && item && data[item.field];
    if (!hasMeaningfulValue(detail)) return addressOk;
    var formItem = label && label.closest && label.closest(".ant-form-item");
    // 工行家庭住址的详细地址是 textarea（不是 input），且没有固定 id。
    var input = formItem && Array.from(formItem.querySelectorAll(
      "input:not([type='hidden']):not([type='file']):not([disabled]):not([readonly]), textarea:not([disabled]):not([readonly])"
    )).find(isVisible);
    return !!(addressOk && input && await AF.FormHandler.fillFormElement(input, detail, "text"));
  }

  async function fillIcbcDate(label, value, item, scope) {
    var text = String(value == null ? "" : value).trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return false;
    // 工行页面的日期标签是 span，外层类名带 CSS Modules 后缀
    //（如 picker__item___3xEzR），不能依赖标准 label 或精确类名。
    var pickerItem = label && label.closest && label.closest("[class*='picker__item']");
    if (!pickerItem) {
      var dateRoot = scope || document;
      var dateItems = [];
      try {
        dateItems = Array.from(dateRoot.querySelectorAll("[class*='picker__item']")).filter(isVisible);
      } catch (eDateItems) {}
      var wantedLabel = normalizeText(item && item.label);
      pickerItem = dateItems.find(function (node) {
        var labelNode = node.querySelector("[class*='picker__label']");
        return wantedLabel && labelNode && normalizeText(labelNode.textContent).indexOf(wantedLabel) !== -1;
      }) || dateItems[Math.max(0, Number(item && item.dateIndex) || 0)] || null;
    }
    var input = pickerItem && pickerItem.querySelector(".ant-calendar-picker-input");
    var picker = pickerItem && pickerItem.querySelector(".ant-calendar-picker");
    if (!input || !picker) return false;
    try { document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true })); } catch (e) {}
    var ok = await AF.FormHandler.fillFormElement(picker, text, "date");
    await sleep(item && item.waitAfterMs == null ? 220 : item.waitAfterMs);
    return !!(ok && String(input.value || "").trim() === text);
  }

  async function fillIcbcSchoolSearch(label, value, item) {
    if (!hasMeaningfulValue(value)) return false;
    var formItem = label && label.closest && label.closest(".ant-form-item");
    var trigger = formItem && formItem.querySelector(item && item.selector || ".ant-select");
    if (trigger && !trigger.matches(".ant-select, .ant-select-selector, [role='combobox']")) {
      trigger = trigger.closest(".ant-select, .ant-select-selector, [role='combobox']") || formItem.querySelector(".ant-select");
    }
    if (!trigger) return false;
    var selected = trigger.querySelector(".ant-select-selection-selected-value");
    if (selected && normalizeText(selected.getAttribute("title") || selected.textContent) === normalizeText(value)) return true;
    await safeClick(trigger);
    var input = await waitUntil(function () {
      var local = formItem && Array.from(formItem.querySelectorAll(".ant-select-search__field, input[autocomplete='off']")).find(isVisible);
      if (local) return local;
      return Array.from(document.querySelectorAll(".ant-select-search__field, input[autocomplete='off']")).filter(isVisible).pop() || null;
    }, item && item.inputTimeoutMs || 1800);
    if (!input) return false;
    var live = await typeBankcommVisibleSearchInput(input, String(value).trim(), item && item.searchTypeTimeoutMs || 6500);
    if (!live) return false;
    var option = await waitUntil(function () {
      return Array.from(document.querySelectorAll(
        ".ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-item-option, " +
        ".ant-dropdown:not(.ant-dropdown-hidden) .ant-dropdown-menu-item, [role='listbox'] [role='option']"
      )).filter(isVisible).find(function (node) {
        return normalizeText(node.textContent) === normalizeText(value);
      }) || null;
    }, item && item.optionTimeoutMs || 5000);
    if (!option) return false;
    var clicked = await clickAntSearchOptionInPage(live, option, String(value).trim(), item && item.clickTimeoutMs || 5000);
    if (!clicked) await safeClick(option);
    return !!(await waitUntil(function () {
      var current = formItem && formItem.querySelector(".ant-select-selection-selected-value");
      return current && normalizeText(current.getAttribute("title") || current.textContent) === normalizeText(value) ? current : null;
    }, item && item.commitTimeoutMs || 2500));
  }

  async function fillIcbcMajor(label, data, item) {
    var formItem = label && label.closest && label.closest(".ant-form-item");
    if (!formItem || !AF.SelectAdapter || typeof AF.SelectAdapter.create !== "function") return false;
    var path = data && data[item && item.pathField || "icbcMajorPath"];
    if (!Array.isArray(path) || path.filter(Boolean).length < 3) return false;
    var selects = Array.from(formItem.querySelectorAll(".ant-select:not(.ant-select-disabled)")).filter(isVisible);
    if (selects.length < 3) return false;
    var values = path.filter(Boolean).slice(0, 3);
    for (var index = 0; index < values.length; index++) {
      if (!await AF.SelectAdapter.create(selects[index], "string").selectValue(values[index])) return false;
      await sleep(item && item.waitAfterEachMs == null ? 220 : item.waitAfterEachMs);
    }
    return true;
  }

  async function fillIcbcHighSchool(label, value, data, item) {
    var formItem = label && label.closest && label.closest(".ant-form-item");
    if (!formItem) return false;
    var path = data && item && data[item.pathField];
    if (!Array.isArray(path) && path) path = String(path).split(/\s*\/\s*|\s*>\s*|\s*,\s*/).filter(Boolean);
    var selects = Array.from(formItem.querySelectorAll(".ant-select:not(.ant-select-disabled)")).filter(isVisible);
    if (Array.isArray(path) && path.length && AF.SelectAdapter && selects.length >= path.length) {
      for (var index = 0; index < Math.min(2, path.length); index++) {
        if (!await AF.SelectAdapter.create(selects[index], "string").selectValue(path[index])) return false;
        await sleep(180);
      }
    }
    var input = Array.from(formItem.querySelectorAll("input:not([type='hidden']):not([disabled]):not([readonly])")).find(isVisible);
    return !!(input && hasMeaningfulValue(value) && await AF.FormHandler.fillFormElement(input, value, "text"));
  }

  function elementChoiceValueMatches(container, value) {
    var values = choiceValueList(value);
    var wanted = normalizeChoiceText(values[values.length - 1] || "");
    var current = normalizeChoiceText(getElementChoiceCurrentValue(container));
    return !!(wanted && current && (current === wanted || current.indexOf(wanted) !== -1 || wanted.indexOf(current) !== -1));
  }

  function setElementTextInput(input, value) {
    if (!input) return;
    var text = String(value == null ? "" : value);
    var descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
    if (descriptor && descriptor.set) descriptor.set.call(input, text);
    else input.value = text;
    input.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: text, inputType: "insertText" }));
    input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
    input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, key: text.slice(-1) || " " }));
  }

  async function typeElementAutocompleteInput(input, value, item) {
    if (!input) return false;
    var text = String(value == null ? "" : value);
    var descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
    if (item && item.waitBeforeInputMs) await sleep(item.waitBeforeInputMs);
    try { input.focus(); } catch (eFocus) {}
    await clickElementChoiceNode(input);
    try { input.select && input.select(); } catch (eSelect) {}

    try {
      if (document.execCommand) document.execCommand("delete", false, null);
    } catch (eDeleteCommand) {}
    if (input.value) {
      if (descriptor && descriptor.set) descriptor.set.call(input, "");
      else input.value = "";
    }
    input.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: "", inputType: "deleteContentBackward" }));
    input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
    await sleep(item && item.waitAfterClearMs == null ? 220 : item && item.waitAfterClearMs);

    var current = "";
    for (var i = 0; i < text.length; i++) {
      var ch = text[i];
      current += ch;
      input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: ch }));
      try { input.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, composed: true, data: ch, inputType: "insertText" })); } catch (eBeforeInput) {}
      var insertedChar = false;
      try {
        insertedChar = !!(document.execCommand && document.execCommand("insertText", false, ch));
      } catch (eCharCommand) {}
      if (!insertedChar || normalizeChoiceText(input.value) !== normalizeChoiceText(current)) {
        if (descriptor && descriptor.set) descriptor.set.call(input, current);
        else input.value = current;
      }
      input.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: ch, inputType: "insertText" }));
      input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, key: ch }));
      await sleep(item && item.typeIntervalMs == null ? 95 : item && item.typeIntervalMs);
    }
    try { input.dispatchEvent(new CompositionEvent("compositionend", { bubbles: true, cancelable: true, composed: true, data: text })); } catch (eComposition) {}
    input.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: text, inputType: "insertText" }));
    input.dispatchEvent(new Event("search", { bubbles: true, cancelable: true }));
    input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
    return normalizeChoiceText(input.value) === normalizeChoiceText(text);
  }

  async function fillTrustedElementAutocomplete(input, value, item) {
    if (!input || !hasMeaningfulValue(value)) return false;
    if (!window.chrome || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      if (item) item.__trustedAutocompleteError = "可信输入通道不可用";
      return false;
    }
    var marker = "af_trusted_autocomplete_" + Date.now() + "_" + Math.random().toString(16).slice(2);
    var markerHost = input.closest(".el-form-item") || input.closest(".el-autocomplete") || input.parentElement;
    try {
      input.setAttribute("data-af-trusted-autocomplete-id", marker);
      if (markerHost) markerHost.setAttribute("data-af-trusted-autocomplete-host", marker);
      var response = await new Promise(function (resolve) {
        chrome.runtime.sendMessage({
          action: "trustedElementAutocomplete",
          marker: marker,
          value: String(value),
          panelSelector: item && item.autocompletePanelSelector ||
            ".el-autocomplete-suggestion, .el-popper.my-autocomplete",
          optionSelector: item && item.autocompleteOptionSelector ||
            ".el-autocomplete-suggestion__list li, .el-autocomplete-suggestion li, [role='option'], li",
          waitAfterClearMs: item && item.waitAfterClearMs,
          typeIntervalMs: item && item.typeIntervalMs,
          waitAfterInputMs: item && item.waitAfterInputMs,
          waitBeforeOptionClickMs: item && item.waitBeforeOptionClickMs,
          waitAfterSelectMs: item && item.waitAfterSelectMs,
          waitAfterBlurMs: item && item.waitAfterBlurMs,
          optionTimeoutMs: item && item.optionTimeoutMs,
          fallbackToFirstOption: !!(item && item.fallbackToFirstOption),
          requireBlurAfterSelect: !!(item && item.requireBlurAfterSelect),
          forceVueSelectAfterClick: !!(item && item.forceVueSelectAfterClick),
          preferLastAutocompleteInput: !!(item && item.preferLastAutocompleteInput),
          preserveExistingInput: !!(item && item.preserveExistingInput),
        }, function (res) {
          resolve(res || { success: false, error: chrome.runtime.lastError && chrome.runtime.lastError.message });
        });
      });
      await sleep(item && item.waitAfterTrustedMs == null ? 260 : item && item.waitAfterTrustedMs);
      if (response && response.success) return true;
      if (item) {
        item.__trustedAutocompleteError = response && (response.error || JSON.stringify(response.detail || response.finalState || response).slice(0, 240)) || "可信输入失败";
      }
      return false;
    } catch (e) {
      if (item) item.__trustedAutocompleteError = e && e.message ? e.message : String(e);
      return false;
    } finally {
      try { input.removeAttribute("data-af-trusted-autocomplete-id"); } catch (eRemove) {}
      try {
        var currentHost = document.querySelector('[data-af-trusted-autocomplete-host="' + marker + '"]');
        var currentInput = currentHost && currentHost.querySelector("input");
        if (currentInput) currentInput.removeAttribute("data-af-trusted-autocomplete-id");
        if (currentHost) currentHost.removeAttribute("data-af-trusted-autocomplete-host");
      } catch (eRemoveHost) {}
    }
  }

  async function fillBankcommDate(label, value, item, scope) {
    var text = String(value == null ? "" : value).trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return false;
    var formItem = label && label.closest && label.closest(".ant-form-item");
    var input = null;
    try {
      input = formItem && Array.from(formItem.querySelectorAll(
        ".ant-picker input:not([disabled]), .ant-calendar-picker-input:not([disabled]), input[placeholder*='日期']:not([disabled]), input:not([type='hidden']):not([disabled])"
      )).find(isVisible);
    } catch (e) {}
    if (!input) return false;

    // 先关闭其它日期面板，避免上一条经历的弹层被当前字段复用。
    try { document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true })); } catch (eEscape) {}
    // 不再把 input.value 的表面变化当成成功；交通银行是 React 受控日期组件，
    // DOM 显示变化不代表 Form model 已更新。关闭残留面板后，必须真实驱动当前 picker。
    var picker = formItem && formItem.querySelector(
      ".ant-picker:not(.ant-picker-disabled), .ant-calendar-picker:not(.ant-calendar-picker-disabled)"
    );
    if (!picker) return false;
    try {
      var clear = picker.querySelector(".ant-picker-clear, .ant-calendar-picker-clear, .anticon-close-circle");
      if (clear && isVisible(clear)) {
        await safeClick(clear);
        await sleep(100);
      }
    } catch (eClearPicker) {}
    var ok = await AF.FormHandler.fillFormElement(picker, text, "date");
    await sleep(item && item.waitAfterMs == null ? 260 : item && item.waitAfterMs);
    return !!(ok && String(input.value || "").trim() === text);
  }

  function bankcommEducationOptionAliases(value) {
    var text = normalizeText(value);
    if (/博士/.test(text)) return ["博士研究生", "博士"];
    if (/硕士/.test(text)) return ["硕士研究生", "硕士"];
    if (/双学位/.test(text)) return ["双学位"];
    if (/本科|学士/.test(text)) return ["本科"];
    if (/大专|专科/.test(text)) return ["大专"];
    if (/高中/.test(text)) return ["高中"];
    if (/中专|职高|技校/.test(text)) return ["中专"];
    if (/^(无|其他)$/.test(text)) return ["无"];
    return [String(value || "").trim()].filter(Boolean);
  }

  async function fillBankcommStrictEducationSelect(label, value, item) {
    var formItem = label && label.closest && label.closest(".ant-form-item");
    var select = null;
    try {
      select = formItem && Array.from(formItem.querySelectorAll(
        ".ant-select:not(.ant-select-disabled):not(.ant-cascader)"
      )).find(isVisible);
    } catch (e) {}
    if (!select) return false;
    var aliases = bankcommEducationOptionAliases(value).map(normalizeText).filter(Boolean);
    if (!aliases.length) return false;

    var displayed = function () {
      var selected = select.querySelector(".ant-select-selection-item, .ant-select-selection-selected-value");
      return normalizeText(selected && (selected.getAttribute("title") || selected.textContent));
    };
    if (aliases.indexOf(displayed()) !== -1) return true;

    await safeClick(select);
    var option = await waitUntil(function () {
      var nodes = [];
      try {
        nodes = Array.from(document.querySelectorAll(
          ".ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-item-option, " +
          ".ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-dropdown-menu-item, " +
          "[role='listbox']:not([aria-hidden='true']) [role='option']"
        )).filter(isVisible);
      } catch (e) {}
      // 学历禁止相似度/包含匹配。只能命中本站真实选项的精确文字，
      // “大学本科”绝不能因为智能兜底被选成“硕士研究生”。
      return nodes.find(function (node) {
        var optionText = normalizeText(node.getAttribute("title") || node.textContent);
        return aliases.indexOf(optionText) !== -1;
      }) || null;
    }, item && item.optionTimeoutMs || 3000);
    if (!option) {
      try { document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true })); } catch (eClose) {}
      return false;
    }
    await safeClick(option);
    return !!(await waitUntil(function () {
      return aliases.indexOf(displayed()) !== -1 ? true : null;
    }, item && item.writebackTimeoutMs || 1800));
  }

  async function fillPinganText(label, value, item, scope) {
    if (!hasMeaningfulValue(value)) return false;
    var group = closestLooseFormItem(label, scope);
    var input = null;
    try {
      input = Array.from(group.querySelectorAll(
        "textarea:not([disabled]):not([readonly]), input:not([type='hidden']):not([type='file']):not([type='radio']):not([type='checkbox']):not([disabled]):not([readonly])"
      )).filter(function (node) {
        return isVisible(node) && !(node.closest && node.closest(".el-select, .el-cascader, .el-date-editor"));
      })[0] || null;
    } catch (e) {}
    if (!input) return false;
    var text = String(value).trim();
    // 平安是 Vue 受控输入。通用 text handler 为兼容旧站点还会同步 value
    // attribute；这里会造成“HTML 看似有值，但 Vue model 仍为空”。平安文本
    // 直接使用原生 value setter + input 事件，并等待 Vue 完成一次渲染。
    try {
      await ensureElementInViewport(input);
      input.focus && input.focus();
      setElementTextInput(input, "");
      await sleep(30);
      setElementTextInput(input, text);
      input.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: text, inputType: "insertText" }));
      input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true, composed: true }));
      await sleep(item && item.waitAfterInputMs == null ? 180 : item && item.waitAfterInputMs);
      input.blur && input.blur();
      await sleep(item && item.waitAfterInputMs == null ? 220 : item && item.waitAfterInputMs);
    } catch (e0) {}
    if (String(input.value || "").trim() === text) return true;

    // 少数 Vue 输入包装器只接受真实编辑命令，再补一次用户式输入路径。
    try {
      input.focus && input.focus();
      input.select && input.select();
      document.execCommand && document.execCommand("insertText", false, text);
      input.dispatchEvent(new Event("input", { bubbles: true, cancelable: true, composed: true }));
      input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true, composed: true }));
      await sleep(180);
      input.blur && input.blur();
      await sleep(180);
    } catch (e1) {}
    return String(input.value || "").trim() === text;
  }

  function findScrollableAncestors(node) {
    var ancestors = [];
    var current = node && node.parentElement;
    while (current && current !== document.documentElement) {
      try {
        var style = window.getComputedStyle(current);
        var overflow = [style.overflowY, style.overflow].join(" ");
        if (/(auto|scroll|overlay)/.test(overflow) && current.scrollHeight > current.clientHeight + 8) {
          ancestors.push(current);
        }
      } catch (e) {}
      current = current.parentElement;
    }
    ancestors.push(document.scrollingElement || document.documentElement);
    return ancestors;
  }

  async function ensureElementInViewport(element) {
    if (!element || !element.getBoundingClientRect) return;
    try { element.scrollIntoView && element.scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" }); } catch (e) {}
    await sleep(80);
    var rect = element.getBoundingClientRect();
    var viewportHeight = window.innerHeight || document.documentElement.clientHeight || 800;
    if (rect.top >= 8 && rect.bottom <= viewportHeight - 8) return;

    var ancestors = findScrollableAncestors(element);
    for (var i = 0; i < ancestors.length; i++) {
      try {
        var scroller = ancestors[i];
        var scrollerRect = scroller === document.scrollingElement || scroller === document.documentElement
          ? { top: 0, height: viewportHeight }
          : scroller.getBoundingClientRect();
        rect = element.getBoundingClientRect();
        var targetTop = rect.top - scrollerRect.top - (scrollerRect.height / 2) + (rect.height / 2);
        scroller.scrollTop += targetTop;
        await sleep(80);
        rect = element.getBoundingClientRect();
        if (rect.top >= 8 && rect.bottom <= viewportHeight - 8) return;
      } catch (e2) {}
    }
  }

  async function clickElementChoiceNode(node) {
    if (!node) return false;
    await ensureElementInViewport(node);
    await sleep(40);
    try {
      ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach(function (eventName) {
        var EventCtor = eventName.indexOf("pointer") === 0 && window.PointerEvent ? window.PointerEvent : window.MouseEvent;
        node.dispatchEvent(new EventCtor(eventName, { bubbles: true, cancelable: true, composed: true, view: window }));
      });
    } catch (e2) {}
    await sleep(80);
    try { node.click && node.click(); } catch (e3) {}
    await sleep(180);
    return true;
  }

  // Element Select 也是开关型控件。通用 clickElementChoiceNode 为兼容旧站点
  // 会先派发一次 click 再调用 HTMLElement.click()，对部分智联字段会造成
  // “打开后立即关闭”，随后代码只能把文字写进 input，页面看似选中但 Vue
  // model 实际仍为空。严格提交路径只产生一次真实 click，不直接改 input.value。
  async function clickElementSelectNodeOnce(node) {
    if (!node) return false;
    await ensureElementInViewport(node);
    await sleep(40);
    try {
      ["pointerdown", "mousedown", "pointerup", "mouseup"].forEach(function (eventName) {
        var EventCtor = eventName.indexOf("pointer") === 0 && window.PointerEvent ? window.PointerEvent : window.MouseEvent;
        node.dispatchEvent(new EventCtor(eventName, { bubbles: true, cancelable: true, composed: true, view: window }));
      });
    } catch (e0) {}
    try {
      if (typeof node.click === "function") node.click();
      else node.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, composed: true, view: window }));
    } catch (e1) { return false; }
    await sleep(180);
    return true;
  }

  function getElementSelectFormItem(container) {
    return container && container.closest && container.closest(".el-form-item");
  }

  function elementSelectHasVisibleValidationError(container) {
    var formItem = getElementSelectFormItem(container);
    if (!formItem) return false;
    if (/\bis-error\b/.test(String(formItem.className || ""))) return true;
    try {
      return Array.from(formItem.querySelectorAll(".el-form-item__error")).some(isVisible);
    } catch (e) {
      return false;
    }
  }

  function elementSelectDisplayedValueMatches(container, value) {
    if (!container) return false;
    var values = choiceValueList(value);
    var wanted = normalizeChoiceText(values[values.length - 1] || "");
    if (!wanted) return false;
    var current = normalizeChoiceText(getElementChoiceCurrentValue(container));
    if (!current || !(current === wanted || current.indexOf(wanted) !== -1 || wanted.indexOf(current) !== -1)) return false;
    // 保存前的只读复核只确认“当前这个 select 的真实 selected-item 是否仍在”。
    // Element Plus 有时在一次旧校验之后暂时保留 .is-error class，即使候选
    // 已经真实选中；这类 stale class 不应在点击网站自己的“添加/保存”之前
    // 把流程拦死。真正的必填校验仍由网站保存动作最终兜底。
    try {
      var selectedNodes = Array.from(container.querySelectorAll(
        ".el-select__selected-item, .el-select__selection-item, .el-select__selected, .el-select__selection .el-select__selected-item"
      )).filter(isVisible);
      if (selectedNodes.some(function (node) {
        var text = normalizeChoiceText(node.textContent);
        return text && (text === wanted || text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1);
      })) return true;
    } catch (eSelected) {}
    var input = getElementChoiceInput(container);
    return !!(input && input.readOnly && current);
  }

  function elementSelectVisibleValidationMessages(container) {
    var formItem = getElementSelectFormItem(container);
    if (!formItem) return [];
    try {
      return Array.from(formItem.querySelectorAll(".el-form-item__error"))
        .filter(isVisible)
        .map(function (node) { return normalizeText(node.textContent); })
        .filter(Boolean);
    } catch (e) {
      return [];
    }
  }

  function elementSelectCommittedValueMatches(container, value) {
    if (!container || elementSelectHasVisibleValidationError(container)) return false;
    var values = choiceValueList(value);
    var wanted = normalizeChoiceText(values[values.length - 1] || "");
    if (!wanted) return false;
    var input = getElementChoiceInput(container);
    var current = normalizeChoiceText(getElementChoiceCurrentValue(container));
    if (!current || !(current === wanted || current.indexOf(wanted) !== -1 || wanted.indexOf(current) !== -1)) return false;
    // 单选 Element Select 的输入框通常 readonly；只有真实候选点击才会让组件
    // 持久化该值。可编辑过滤输入框不能仅凭 input.value 判断提交成功。
    if (input && !input.readOnly) {
      try {
        var selectedToken = container.querySelector(".el-select__tags .el-tag, .el-select__selected-item, .el-select__selection, .el-select__selected");
        if (!selectedToken) return false;
      } catch (eToken) { return false; }
    }
    return true;
  }

  // 智联高等教育的“年级排名”等必填 Element Select 必须通过真实候选点击
  // 更新 Vue model。禁止 setElementTextInput 伪造显示值；并要求点击后表单项
  // 无校验错误且值在一次 Vue 重绘后仍保留。
  async function fillPersistentElementSelectChoice(control, value, item) {
    if (!control || !hasMeaningfulValue(value)) return false;
    var container = control.closest && control.closest(".el-select") || control;
    if (!container || !container.matches || !container.matches(".el-select")) return false;

    // 如果页面本来就已经是有效选中状态，直接接受。
    if (elementSelectCommittedValueMatches(container, value)) return true;

    var input = getElementChoiceInput(container);
    var trigger = container.querySelector && (
      container.querySelector(".el-input__wrapper") ||
      container.querySelector(".select-trigger") ||
      input
    ) || container;
    try { document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true })); } catch (eEsc) {}
    await sleep(100);
    if (!(await clickElementSelectNodeOnce(trigger))) return false;

    var panelSelector = ".el-select-dropdown, .el-select__popper, [role='listbox']";
    var optionSelector = ".el-select-dropdown__item, [role='option']";
    var panel = await waitUntil(function () {
      var linked = findAriaLinkedElementChoicePanel(container, panelSelector, optionSelector, value, false);
      if (linked) return linked;
      return findVisibleElementPanel(container, panelSelector, optionSelector, value, true);
    }, item && item.panelTimeoutMs || 3200);
    if (!panel) return false;

    var option = await findElementChoiceOptionWithScroll(panel, optionSelector, value, Object.assign({}, item || {}, { optionScrollAttempts: 20 }));
    if (!option || !isVisible(option)) return false;
    var optionTarget = option.querySelector && option.querySelector("span") || option;
    if (!(await clickElementSelectNodeOnce(optionTarget))) return false;

    // 等待 Element/Vue 真正完成提交。只读 input 的值、面板关闭、表单校验
    // 三者共同确认；随后再等待一拍，防止短暂显示后被下一次渲染清空。
    var committed = await waitUntil(function () {
      var liveContainer = container;
      if (!liveContainer.isConnected) return null;
      var expanded = input && input.getAttribute && input.getAttribute("aria-expanded");
      if (expanded === "true") return null;
      return elementSelectCommittedValueMatches(liveContainer, value) ? true : null;
    }, item && item.commitTimeoutMs || 2600);
    if (!committed) return false;
    try { input && input.blur && input.blur(); } catch (eBlur) {}
    await sleep(item && item.persistVerifyMs || 520);
    return elementSelectCommittedValueMatches(container, value);
  }

  // 日期选择器是典型的开关型控件：同一节点连续触发两次 click 会先打开、
  // 再立即关闭浮层。通用选择器为了兼容部分站点会派发 click 后再调用
  // node.click()，不能用于 Element 月份面板。日期交互只产生一次 click。
  async function clickElementDateNode(node) {
    if (!node) return false;
    await ensureElementInViewport(node);
    await sleep(40);
    // 该站的 readonly 月份输入框依赖 focus 打开浮层。content-script
    // 调用 HTMLElement.click() 不一定产生浏览器默认的聚焦动作，因此此前
    // 看起来会“完全跳过”，连下拉面板都不出现。
    if (node.matches && node.matches("input, [tabindex], [role='button']")) {
      try { node.focus({ preventScroll: true }); } catch (eFocus) {
        try { node.focus(); } catch (eFocusFallback) {}
      }
      await sleep(80);
    }
    try {
      ["pointerdown", "mousedown", "pointerup", "mouseup"].forEach(function (eventName) {
        var EventCtor = eventName.indexOf("pointer") === 0 && window.PointerEvent ? window.PointerEvent : window.MouseEvent;
        node.dispatchEvent(new EventCtor(eventName, { bubbles: true, cancelable: true, composed: true, view: window }));
      });
    } catch (e0) {}
    try {
      if (typeof node.click === "function") node.click();
      else node.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, composed: true, view: window }));
    } catch (e1) {}
    await sleep(180);
    return true;
  }

  function findVisibleElementPanel(container, panelSelector, optionSelector, value, preferNearestPanel) {
    var wanted = normalizeChoiceText(value);
    var roots = [];
    var formItem = container && container.closest && container.closest(".el-form-item");
    [container, formItem, document].forEach(function (root) {
      if (root && roots.indexOf(root) === -1) roots.push(root);
    });
    var panels = [];
    roots.forEach(function (root) {
      try {
        panels = panels.concat(Array.from(root.querySelectorAll(panelSelector)));
      } catch (e) {}
    });
    var seen = [];
    panels = panels.filter(function (panel) {
      if (!panel || seen.indexOf(panel) !== -1) return false;
      seen.push(panel);
      return isVisible(panel) && panel.getAttribute("aria-hidden") !== "true";
    });
    if (wanted) {
      var matchedPanels = panels.filter(function (panel) {
        try {
          return Array.from(panel.querySelectorAll(optionSelector)).filter(isVisible).some(function (option) {
            return optionTextMatches(option, wanted);
          });
        } catch (e) {
          return false;
        }
      });
      if (matchedPanels.length && !preferNearestPanel) return matchedPanels[0];
      if (matchedPanels.length) panels = matchedPanels;
    }
    if (!panels.length) return null;
    var refRect = (container || document.body).getBoundingClientRect();
    panels.sort(function (a, b) {
      var ar = a.getBoundingClientRect();
      var br = b.getBoundingClientRect();
      var ad = Math.abs(ar.left - refRect.left) + Math.abs(ar.top - refRect.bottom);
      var bd = Math.abs(br.left - refRect.left) + Math.abs(br.top - refRect.bottom);
      return ad - bd;
    });
    return panels[0] || null;
  }

  function findLocalElementPanels(container, panelSelector) {
    var roots = [];
    var formItem = container && container.closest && container.closest(".el-form-item");
    [container, formItem].forEach(function (root) {
      if (root && roots.indexOf(root) === -1) roots.push(root);
    });
    var panels = [];
    roots.forEach(function (root) {
      try {
        panels = panels.concat(Array.from(root.querySelectorAll(panelSelector)));
      } catch (e) {}
    });
    var seen = [];
    return panels.filter(function (panel) {
      if (!panel || seen.indexOf(panel) !== -1) return false;
      seen.push(panel);
      return true;
    });
  }

  function panelHasElementChoiceOption(panel, optionSelector, value, includeHidden) {
    if (!panel) return false;
    try {
      return Array.from(panel.querySelectorAll(optionSelector)).some(function (option) {
        return (includeHidden || isVisible(option)) && optionTextMatches(option, value);
      });
    } catch (e) {
      return false;
    }
  }

  function findLocalElementPanelWithOption(container, panelSelector, optionSelector, value) {
    var panels = findLocalElementPanels(container, panelSelector);
    if (!panels.length) return null;
    var wanted = normalizeChoiceText(value);
    if (wanted) {
      var matched = panels.find(function (panel) {
        return panelHasElementChoiceOption(panel, optionSelector, wanted, true);
      });
      if (matched) return matched;
    }
    return panels[0] || null;
  }

  function findAriaLinkedElementChoicePanel(container, panelSelector, optionSelector, value, includeHidden) {
    if (!container) return null;
    var nodes = [container];
    try { nodes = nodes.concat(Array.from(container.querySelectorAll("[aria-controls], [aria-owns]"))); } catch (e) {}
    var ids = [];
    nodes.forEach(function (node) {
      ["aria-controls", "aria-owns"].forEach(function (attr) {
        var raw = node && node.getAttribute && node.getAttribute(attr);
        String(raw || "").split(/\s+/).filter(Boolean).forEach(function (id) {
          if (ids.indexOf(id) === -1) ids.push(id);
        });
      });
    });
    for (var i = 0; i < ids.length; i++) {
      var linked = document.getElementById(ids[i]);
      if (!linked) continue;
      var panel = linked;
      try {
        if (panelSelector && !(linked.matches && linked.matches(panelSelector))) {
          panel = linked.closest && linked.closest(panelSelector) || linked.querySelector && linked.querySelector(panelSelector) || linked;
        }
      } catch (ePanel) { panel = linked; }
      if (!includeHidden && !isElementPanelOpen(panel)) continue;
      if (!value || panelHasElementChoiceOption(panel, optionSelector, value, true)) return panel;
    }
    return null;
  }

  async function forceCommitElementChoiceViaAria(control, value, item) {
    if (!control || !hasMeaningfulValue(value)) return false;
    var container = control.closest && control.closest(".el-select, .el-cascader") || control;
    if (!container || !container.matches || !container.matches(".el-select")) return false;
    if (elementChoiceValueMatches(container, value)) return true;
    var optionSelector = ".el-select-dropdown__item";
    var panelSelector = ".el-select-dropdown, .el-select__popper, [role='listbox']";
    var trigger = container.querySelector && (
      container.querySelector(".el-input__wrapper") ||
      container.querySelector(".select-trigger") ||
      getElementChoiceInput(container)
    ) || container;
    try { await clickElementChoiceNode(trigger); } catch (eClick) {}
    await sleep(item && item.waitAfterOpenMs == null ? 260 : item.waitAfterOpenMs);
    var panel = findAriaLinkedElementChoicePanel(container, panelSelector, optionSelector, value, false);
    if (!panel) {
      // Element/Element Plus often leaves the aria-linked popper mounted but hidden.
      // Using that exact relationship is safer than searching all global "其他" options.
      panel = findAriaLinkedElementChoicePanel(container, panelSelector, optionSelector, value, true);
    }
    if (!panel) return false;
    var option = findElementChoiceOption(panel, optionSelector, value, true);
    if (!option) return false;
    try {
      if (isVisible(option)) await clickElementChoiceNode(option.querySelector("span") || option);
      else {
        var target = option.querySelector("span") || option;
        if (typeof target.click === "function") target.click();
        else target.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, composed: true, view: window }));
      }
    } catch (eOption) { return false; }
    await sleep(item && item.waitAfterSelectMs == null ? 260 : item.waitAfterSelectMs);
    return elementChoiceValueMatches(container, value);
  }

  function isElementPanelOpen(panel) {
    return !!(panel && isVisible(panel) && panel.getAttribute("aria-hidden") !== "true");
  }

  function findOpenLocalElementPanel(container, panelSelector) {
    return findLocalElementPanels(container, panelSelector).find(isElementPanelOpen) || null;
  }

  function findAnyOpenElementPanel(container, panelSelector, optionSelector, value) {
    return findOpenLocalElementPanel(container, panelSelector) ||
      findVisibleElementPanel(container, panelSelector, optionSelector, value);
  }

  async function openScopedElementPanel(container, panelSelector, optionSelector, value, item) {
    if (!container) return null;
    // 徽商银行的省/市/县下拉都挂载到 body，且每个弹层都包含相似候选。
    // 切换到下一行时，上一个弹层在关闭动画中仍会被判断为可见。严格模式
    // 不在点击前复用任何全局弹层，确保先真实打开当前控件。
    var strictCurrentControl = !!(item && item.strictCurrentControl);
    var opened = strictCurrentControl
      ? findOpenLocalElementPanel(container, panelSelector)
      : findAnyOpenElementPanel(container, panelSelector, optionSelector, value);
    if (opened) return opened;
    var localPanel = findLocalElementPanelWithOption(container, panelSelector, optionSelector, value);
    var trigger = container.querySelector && (
      container.querySelector(".el-input__wrapper") ||
      container.querySelector(".select-trigger") ||
      getElementChoiceInput(container)
    ) || container;
    var hasLocalKnownPanel = !!localPanel;
    var timeoutMs = item && item.panelTimeoutMs || (hasLocalKnownPanel ? 1200 : item && item.optionTimeoutMs || 2600);
    for (var attempt = 0; attempt < 2; attempt++) {
      await clickElementChoiceNode(trigger);
      await sleep(item && item.waitAfterOpenMs == null ? (hasLocalKnownPanel ? 260 : 320) : item && item.waitAfterOpenMs);
      var panel = await waitUntil(function () {
        if (!strictCurrentControl) return findAnyOpenElementPanel(container, panelSelector, optionSelector, value);
        return findOpenLocalElementPanel(container, panelSelector) ||
          findVisibleElementPanel(container, panelSelector, optionSelector, value, true);
      }, timeoutMs);
      if (panel) return panel;
      // 有些 Element Plus 实例第一次 focus 只激活输入框，第二次才展开；
      // 但不要继续点 input/container 等其它目标，避免刚展开又被切换关闭。
      try { trigger.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: "ArrowDown" })); } catch (e) {}
      await sleep(120);
    }
    return null;
  }

  function findElementChoiceOption(panel, optionSelector, value, includeHidden) {
    if (!panel) return null;
    var options = [];
    try {
      options = Array.from(panel.querySelectorAll(optionSelector)).filter(function (node) {
        return includeHidden || isVisible(node);
      });
    } catch (e) {}
    function isDisabledChoice(node) {
      return !!(node && (
        node.disabled ||
        node.getAttribute && node.getAttribute("aria-disabled") === "true" ||
        /is-disabled|disabled/.test(String(node.className || ""))
      ));
    }
    var enabledOptions = options.filter(function (node) { return !isDisabledChoice(node); });
    return enabledOptions.find(function (node) {
      return normalizeChoiceText(node.textContent) === normalizeChoiceText(value);
    }) || enabledOptions.find(function (node) {
      return optionTextMatches(node, value);
    }) || null;
  }

  async function findElementChoiceOptionWithScroll(panel, optionSelector, value, item) {
    var includeHidden = !isElementPanelOpen(panel);
    var option = findElementChoiceOption(panel, optionSelector, value, includeHidden);
    if (option) return option;
    var scrollers = [];
    try {
      scrollers = Array.from(panel.querySelectorAll(".el-scrollbar__wrap, .el-cascader-menu__wrap, .el-select-dropdown__wrap")).filter(function (node) {
        return (includeHidden || isVisible(node)) && node.scrollHeight > node.clientHeight + 8;
      });
    } catch (e) {}
    if (!scrollers.length && panel.scrollHeight > panel.clientHeight + 8) scrollers = [panel];
    for (var i = 0; i < scrollers.length; i++) {
      var scroller = scrollers[i];
      try { scroller.scrollTop = 0; } catch (e2) {}
      for (var attempt = 0; attempt < (item && item.optionScrollAttempts || 12); attempt++) {
        option = findElementChoiceOption(panel, optionSelector, value, includeHidden);
        if (option) return option;
        try { scroller.scrollTop += Math.max(120, Math.floor(scroller.clientHeight * 0.8)); } catch (e3) {}
        await sleep(item && item.waitAfterOptionScrollMs == null ? 90 : item && item.waitAfterOptionScrollMs);
      }
    }
    return findElementChoiceOption(panel, optionSelector, value, includeHidden);
  }

  function summarizeElementChoiceFailure(control, value) {
    if (!control) return "控件未解析";
    var container = control.closest && control.closest(".el-select, .el-cascader") || control;
    var isCascader = !!(container.matches && container.matches(".el-cascader"));
    var panelSelector = isCascader ? ".el-cascader__dropdown, .el-cascader-panel, .el-cascader-menus" : ".el-select-dropdown, .el-select__popper";
    var optionSelector = isCascader ? ".el-cascader-node, .el-cascader__suggestion-item, .el-cascader-menu__item, .el-cascader__dropdown li" : ".el-select-dropdown__item";
    var wanted = choiceValueList(value).join(" > ");
    var current = getElementChoiceCurrentValue(container);
    var panel = findVisibleElementPanel(container, panelSelector, optionSelector, choiceValueList(value).slice(-1)[0]);
    var options = [];
    try {
      if (!panel) panel = findLocalElementPanelWithOption(container, panelSelector, optionSelector, choiceValueList(value).slice(-1)[0]);
      var includeHidden = panel && !isElementPanelOpen(panel);
      options = panel ? Array.from(panel.querySelectorAll(optionSelector)).filter(function (node) {
        return includeHidden || isVisible(node);
      }).map(function (node) {
        return normalizeText(node.textContent);
      }).filter(Boolean).slice(0, 12) : [];
    } catch (e) {}
    return "Element" + (isCascader ? "级联" : "下拉") + "填写失败；目标=" + wanted + "；当前=" + (current || "空") + (options.length ? "；候选=" + options.join("/") : "；候选未展开");
  }

  async function fillScopedElementChoice(control, value, item) {
    if (!control || !hasMeaningfulValue(value)) return false;
    var container = control.closest && control.closest(".el-select, .el-cascader") || control;
    if (!container || !container.matches || !container.matches(".el-select, .el-cascader")) return false;
    if (elementChoiceValueMatches(container, value)) return true;

    var isCascader = container.matches(".el-cascader");
    var values = choiceValueList(value);
    if (!values.length) return false;
    if (!isCascader) {
      var selectPanel = await openScopedElementPanel(
        container,
        ".el-select-dropdown, .el-select__popper",
        ".el-select-dropdown__item",
        values[values.length - 1],
        item
      );
      var input = getElementChoiceInput(container);
      if (input && !input.disabled && !input.readOnly && /^(text|search)?$/.test(input.type || "text")) {
        try { input.focus(); } catch (e) {}
        setElementTextInput(input, values[values.length - 1]);
        await sleep(item && item.waitAfterInputMs == null ? 260 : item && item.waitAfterInputMs);
        selectPanel = findVisibleElementPanel(container, ".el-select-dropdown, .el-select__popper", ".el-select-dropdown__item", values[values.length - 1]) || selectPanel;
      }
      if (!selectPanel) return false;
      var option = await findElementChoiceOptionWithScroll(selectPanel, ".el-select-dropdown__item", values[values.length - 1], item);
      if (!option) return false;
      await clickElementChoiceNode(option.querySelector("span") || option);
      await sleep(item && item.waitAfterSelectMs == null ? 220 : item && item.waitAfterSelectMs);
      return elementChoiceValueMatches(container, values[values.length - 1]);
    }

    var cascaderPanel = await openScopedElementPanel(
      container,
      ".el-cascader__dropdown, .el-cascader-panel, .el-cascader-menus",
      ".el-cascader-node, .el-cascader__suggestion-item, .el-cascader-menu__item, .el-cascader__dropdown li",
      values[0],
      item
    );
    if (!cascaderPanel) return false;
    var selectedCascaderNode = null;
    for (var index = 0; index < values.length; index++) {
      var pathValue = values[index];
      var node = await findElementChoiceOptionWithScroll(
        cascaderPanel,
        ".el-cascader-node, .el-cascader__suggestion-item, .el-cascader-menu__item, .el-cascader__dropdown li",
        pathValue,
        item
      );
      if (!node) return false;
      await clickElementChoiceNode(node);
      selectedCascaderNode = node;
      var nextValue = values[index + 1];
      if (nextValue) {
        await waitUntil(function () {
          var refreshedPanel = findVisibleElementPanel(container, ".el-cascader__dropdown, .el-cascader-panel, .el-cascader-menus", ".el-cascader-node, .el-cascader__suggestion-item, .el-cascader-menu__item, .el-cascader__dropdown li", nextValue) || cascaderPanel;
          if (!refreshedPanel) return null;
          return findElementChoiceOption(refreshedPanel, ".el-cascader-node, .el-cascader__suggestion-item, .el-cascader-menu__item, .el-cascader__dropdown li", nextValue, false) ? refreshedPanel : null;
        }, item && item.nextOptionTimeoutMs || 1600);
        cascaderPanel = findVisibleElementPanel(container, ".el-cascader__dropdown, .el-cascader-panel, .el-cascader-menus", ".el-cascader-node, .el-cascader__suggestion-item, .el-cascader-menu__item, .el-cascader__dropdown li", nextValue) || cascaderPanel;
      } else {
        await sleep(item && item.waitAfterOptionMs == null ? 260 : item && item.waitAfterOptionMs);
      }
    }
    await sleep(item && item.waitAfterSelectMs == null ? 220 : item && item.waitAfterSelectMs);
    return elementChoiceValueMatches(container, values[values.length - 1]) ||
      !!(selectedCascaderNode && /is-active|in-active-path|is-checked|is-selected/.test(String(selectedCascaderNode.className || "")));
  }

  async function fillElementAutocomplete(control, value, item) {
    if (!control || !hasMeaningfulValue(value)) return false;
    var input = control.matches && control.matches("input, textarea") ? control : getElementChoiceInput(control);
    if (!input || input.readOnly) return false;
    var wanted = choiceValueList(value).slice(-1)[0] || String(value || "").trim();
    if (!wanted) return false;
    // 平安在清空学校后会替换 autocomplete/input 节点。后续校验必须每次
    // 从稳定的 el-form-item 重新获取当前 input，不能继续检查旧节点。
    var autocompleteScope = input.closest && (input.closest(".el-form-item") || input.closest(".el-autocomplete")) || input.parentElement;
    var preferLastAutocompleteInput = !!(item && item.preferLastAutocompleteInput);
    var requestedAutocompleteIndex = Number(item && item.autocompleteIndex);
    if (!Number.isFinite(requestedAutocompleteIndex) || requestedAutocompleteIndex < 0) {
      requestedAutocompleteIndex = preferLastAutocompleteInput ? -1 : 0;
      try {
        var initialAutocompleteInputs = Array.from(autocompleteScope.querySelectorAll(
          ".el-autocomplete input.el-input__inner:not([readonly]), input[aria-autocomplete='list']:not([readonly]), input[fetchsuggestions]:not([readonly])"
        )).filter(isVisible);
        if (!preferLastAutocompleteInput) {
          var initialAutocompleteIndex = initialAutocompleteInputs.indexOf(input);
          if (initialAutocompleteIndex >= 0) requestedAutocompleteIndex = initialAutocompleteIndex;
        }
      } catch (eInitialAutocompleteIndex) {}
    }
    function currentAutocompleteInput() {
      var freshInputs = [];
      try {
        freshInputs = autocompleteScope && Array.from(autocompleteScope.querySelectorAll(
          ".el-autocomplete input.el-input__inner:not([readonly]), input[aria-autocomplete='list']:not([readonly]), input[fetchsuggestions]:not([readonly])"
        )).filter(isVisible) || [];
      } catch (eFreshInput) {}
      return preferLastAutocompleteInput && freshInputs.length
        ? freshInputs[freshInputs.length - 1]
        : freshInputs[requestedAutocompleteIndex] || freshInputs[0] || input;
    }
    if (input.disabled) {
      var autocompleteRoot = input.closest && input.closest(".el-form-item, .el-autocomplete") || null;
      input = await waitUntil(function () {
        var freshInputs = autocompleteRoot && Array.from(autocompleteRoot.querySelectorAll(
          ".el-autocomplete input.el-input__inner:not([readonly]), input[aria-autocomplete='list']:not([readonly]), input[fetchsuggestions]:not([readonly])"
        )).filter(isVisible) || [];
        var freshInput = preferLastAutocompleteInput && freshInputs.length ? freshInputs[freshInputs.length - 1] : freshInputs[0] || input;
        return freshInput && !freshInput.disabled && isVisible(freshInput) ? freshInput : null;
      }, item && item.enableTimeoutMs || 2600);
      if (!input) return false;
    }

    function autocompleteAccepted() {
      input = currentAutocompleteInput();
      if (!input || normalizeChoiceText(input.value) !== normalizeChoiceText(wanted)) return false;
      var formItem = input.closest && input.closest(".el-form-item");
      return !(formItem && /is-error/.test(String(formItem.className || "")));
    }
    async function releaseAutocompleteFocus() {
      input = currentAutocompleteInput();
      if (input) {
        try { input.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true, cancelable: true, composed: true })); } catch (eInputEscape) {}
        try { input.dispatchEvent(new KeyboardEvent("keyup", { key: "Escape", code: "Escape", bubbles: true, cancelable: true, composed: true })); } catch (eInputEscapeUp) {}
        try { input.blur && input.blur(); } catch (eInputBlur) {}
      }
      try { document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true, cancelable: true, composed: true })); } catch (eDocumentEscape) {}
      await sleep(item && item.waitAfterBlurMs == null ? 180 : item && item.waitAfterBlurMs);
    }

    if (item && item.trustedAutocomplete) {
      var trustedItem = item;
      // 已有资料回填时，部分 Element Autocomplete 的真实键盘全选只会
      // 选中/删除尾部文字，随后新值被追加到旧值前缀后面。指定此开关的
      // 站点先用页面输入事件完整覆盖并核对值，再让可信通道只负责选择
      // 候选项，避免“交通工程”被写成“交通软件工程”。
      if (item.pretypeBeforeTrusted === true) {
        input = currentAutocompleteInput();
        var pretypedOk = await typeElementAutocompleteInput(input, wanted, item);
        input = currentAutocompleteInput();
        if (!pretypedOk || !input || normalizeChoiceText(input.value) !== normalizeChoiceText(wanted)) {
          await releaseAutocompleteFocus();
          return false;
        }
        await sleep(item.waitAfterInputMs == null ? 520 : item.waitAfterInputMs);
        trustedItem = Object.assign({}, item, { preserveExistingInput: true });
      }
      item.__trustedAutocompleteError = "";
      var trustedOk = await fillTrustedElementAutocomplete(input, wanted, trustedItem);
      input = currentAutocompleteInput();
      if (trustedOk && autocompleteAccepted()) return true;
      if (item.trustedAutocompleteRequired) {
        await releaseAutocompleteFocus();
        return false;
      }
    }

    await typeElementAutocompleteInput(input, wanted, item);
    await sleep(item && item.waitAfterInputMs == null ? 520 : item && item.waitAfterInputMs);

    var panelSelector = item && item.autocompletePanelSelector ||
      ".el-autocomplete-suggestion:not([style*='display: none']), .el-popper.my-autocomplete:not([style*='display: none']), .el-autocomplete-suggestion";
    var optionSelector = item && item.autocompleteOptionSelector ||
      ".el-autocomplete-suggestion__list li, li, [role='option']";
    var panel = await waitUntil(function () {
      var panels = [];
      try { panels = Array.from(document.querySelectorAll(panelSelector)).filter(isVisible); } catch (ePanel) {}
      var matched = panels.find(function (candidate) {
        try {
          return Array.from(candidate.querySelectorAll(optionSelector)).filter(isVisible).some(function (option) {
            return optionTextMatches(option, wanted);
          });
        } catch (eOption) {
          return false;
        }
      });
      return matched || null;
    }, item && item.optionTimeoutMs || 3200);

    if (panel) {
      var option = await findElementChoiceOptionWithScroll(panel, optionSelector, wanted, item);
      if (option) {
        await clickElementChoiceNode(option);
        await sleep(item && item.waitAfterSelectMs == null ? 260 : item && item.waitAfterSelectMs);
        var selectedOk = await waitUntil(function () {
          return autocompleteAccepted() ? input : null;
        }, item && item.writebackTimeoutMs || 1800);
        if (selectedOk) return true;
      }
    }

    // 有些 Element Autocomplete 候选层能被键盘接管，但 DOM 点击不回写。
    // 这里补一次 ArrowDown + Enter，只在前面的候选点击失败后执行。
    try {
      input.focus && input.focus();
      input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: "ArrowDown", code: "ArrowDown" }));
      input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, key: "ArrowDown", code: "ArrowDown" }));
      await sleep(120);
      input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: "Enter", code: "Enter" }));
      input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, key: "Enter", code: "Enter" }));
      input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      await sleep(item && item.waitAfterSelectMs == null ? 260 : item && item.waitAfterSelectMs);
      if (autocompleteAccepted()) return true;
    } catch (eKeyboardSelect) {}

    await releaseAutocompleteFocus();
    return item && item.allowAutocompleteFreeText === true &&
      autocompleteAccepted();
  }

  async function fillElementSelectGroup(label, data, item) {
    var fields = Array.isArray(item && item.dataFields) ? item.dataFields : [];
    if (!fields.length) return false;
    var attempted = 0;
    for (var index = 0; index < fields.length; index++) {
      var value = data && data[fields[index]];
      if (!hasMeaningfulValue(value)) continue;
      attempted++;
      var formItem = label && label.closest && label.closest(".el-form-item");
      var content = formItem && formItem.querySelector(":scope > .el-form-item__content");
      var selects = content ? Array.from(content.querySelectorAll(":scope > .el-select:not(.is-disabled)")).filter(isVisible) : [];
      var select = selects[index];
      if (!select) return false;
      var levelItem = Object.assign({}, item, { selectIndex: index });
      var ok = await fillScopedElementChoice(select, value, levelItem);
      if (!ok && AF.SelectAdapter && typeof AF.SelectAdapter.create === "function") {
        ok = await AF.SelectAdapter.create(select, typeof value === "object" ? "object" : "string").selectValue(value);
        await sleep(item && item.waitAfterLevelMs == null ? 360 : item && item.waitAfterLevelMs);
        ok = !!(ok && elementChoiceValueMatches(select, value));
      }
      if (!ok) return false;
      await sleep(item && item.waitAfterLevelMs == null ? 360 : item && item.waitAfterLevelMs);
    }
    return attempted > 0 || item && item.optional === true;
  }

  async function fillElementSelectAutocompleteGroup(label, data, item) {
    var fields = Array.isArray(item && item.dataFields) ? item.dataFields : [];
    if (fields.length < 2) return false;
    var attempted = 0;
    var selectValue = data && data[fields[0]];
    if (hasMeaningfulValue(selectValue)) {
      attempted++;
      var formItem = label && label.closest && label.closest(".el-form-item");
      var content = formItem && formItem.querySelector(":scope > .el-form-item__content");
      var select = content && Array.from(content.querySelectorAll(":scope > .el-select:not(.is-disabled)")).filter(isVisible)[0];
      if (!select) return false;
      var selectOk = await fillScopedElementChoice(select, selectValue, item);
      if (!selectOk && AF.SelectAdapter && typeof AF.SelectAdapter.create === "function") {
        selectOk = await AF.SelectAdapter.create(select, typeof selectValue === "object" ? "object" : "string").selectValue(selectValue);
        await sleep(item && item.waitAfterLevelMs == null ? 420 : item && item.waitAfterLevelMs);
        selectOk = !!(selectOk && elementChoiceValueMatches(select, selectValue));
      }
      if (!selectOk) return false;
      await sleep(item && item.waitAfterLevelMs == null ? 420 : item && item.waitAfterLevelMs);
    }
    for (var autoIndex = 0; autoIndex < fields.length - 1; autoIndex++) {
      var autocompleteValue = data && data[fields[autoIndex + 1]];
      if (!hasMeaningfulValue(autocompleteValue)) continue;
      attempted++;
      var currentFormItem = label && label.closest && label.closest(".el-form-item");
      var currentContent = currentFormItem && currentFormItem.querySelector(":scope > .el-form-item__content");
      var autocompleteInputs = currentContent ? Array.from(currentContent.querySelectorAll(
        ":scope > .el-autocomplete input.el-input__inner:not([disabled]):not([readonly])"
      )).filter(isVisible) : [];
      var autocompleteInput = autocompleteInputs[autoIndex];
      if (!autocompleteInput) return false;
      var autocompleteItem = Object.assign({}, item, { autocompleteIndex: autoIndex });
      var autocompleteOk = await fillElementAutocomplete(autocompleteInput, autocompleteValue, autocompleteItem);
      if (!autocompleteOk) return false;
      await sleep(item && item.waitAfterLevelMs == null ? 420 : item && item.waitAfterLevelMs);
    }
    return attempted > 0 || item && item.optional === true;
  }

  async function fillHsbankEndDate(label, value, item) {
    if (!label || !hasMeaningfulValue(value)) return false;
    var formItem = label.closest && label.closest(".el-form-item");
    if (!formItem) return false;
    var custom = formItem.querySelector(".enhanced-date-picker-container");
    if (!custom) {
      var elementDate = Array.from(formItem.querySelectorAll(".el-date-editor:not(.is-disabled)")).find(isVisible);
      return !!(elementDate && await AF.FormHandler.fillFormElement(elementDate, value, "date"));
    }
    var input = custom.querySelector(".custom-date-input input, input[placeholder='选择日期']");
    var trigger = custom.querySelector(".custom-date-input") || input;
    if (!input || !trigger) return false;
    await safeClick(trigger);
    var calendar = await waitUntil(function () {
      var node = custom.querySelector(".calendar");
      return node && isVisible(node) ? node : null;
    }, item && item.firstOpenTimeoutMs || 520);
    // 该自制日期控件偶尔不会响应通用 mousedown/mouseup/click 序列，旧逻辑
    // 会在这里直接失败，表现为工作/实习结束时间被跳过。仅当日历确实没有
    // 展开时，再用单次原生日期点击兜底，避免对已经打开的控件二次点击关闭。
    if (!calendar) {
      await clickElementDateNode(trigger);
      calendar = await waitUntil(function () {
        var node = custom.querySelector(".calendar");
        return node && isVisible(node) ? node : null;
      }, item && item.openTimeoutMs || 1400);
    }
    if (!calendar && input !== trigger) {
      await clickElementDateNode(input);
      calendar = await waitUntil(function () {
        var node = custom.querySelector(".calendar");
        return node && isVisible(node) ? node : null;
      }, item && item.openTimeoutMs || 1000);
    }
    if (!calendar) return false;
    if (isCurrentEndText(value)) {
      var untilNow = Array.from(calendar.querySelectorAll("button")).find(function (button) {
        return isVisible(button) && normalizeText(button.textContent) === "至今";
      });
      if (!untilNow) return false;
      await clickElementDateNode(untilNow);
      await sleep(item && item.waitAfterSelectMs == null ? 260 : item && item.waitAfterSelectMs);
      return /至今/.test(String(input.value || ""));
    }
    var match = String(value || "").match(/(\d{4})[^\d]?(\d{1,2})(?:[^\d]?(\d{1,2}))?/);
    if (!match) return false;
    var targetYear = Number(match[1]);
    var targetMonth = Number(match[2]);
    // 兼容旧简历只有“年月”的结束时间：结束时间按当月最后一天填写。
    var targetDay = match[3] ? Number(match[3]) : new Date(targetYear, targetMonth, 0).getDate();
    function headerYearMonth() {
      var selectors = Array.from(calendar.querySelectorAll(".calendar-title .selector > span"));
      var yearMatch = String(selectors[0] && selectors[0].textContent || "").match(/\d{4}/);
      var monthMatch = String(selectors[1] && selectors[1].textContent || "").match(/\d{1,2}/);
      return yearMatch && monthMatch ? [Number(yearMatch[0]), Number(monthMatch[0])] : null;
    }
    var header = headerYearMonth();
    if (!header) return false;
    var navButtons = Array.from(calendar.querySelectorAll("button.nav-btn"));
    var previousYear = navButtons[0];
    var previousMonth = navButtons[1];
    var nextMonth = navButtons[2];
    var nextYear = navButtons[3];
    var yearDiff = targetYear - header[0];
    if (Math.abs(yearDiff) > 50) return false;
    for (var yearMove = 0; yearMove < Math.abs(yearDiff); yearMove++) {
      var beforeYearHeader = headerYearMonth();
      await clickElementDateNode(yearDiff < 0 ? previousYear : nextYear);
      var saveSuccess = await waitUntil(function () {
        var afterYearHeader = headerYearMonth();
        return afterYearHeader && beforeYearHeader && afterYearHeader[0] !== beforeYearHeader[0] ? afterYearHeader : null;
      }, item && item.monthMoveTimeoutMs || 800);
    }
    header = headerYearMonth();
    if (!header) return false;
    var monthDiff = targetMonth - header[1];
    for (var move = 0; move < Math.abs(monthDiff); move++) {
      var beforeHeader = headerYearMonth();
      await clickElementDateNode(monthDiff < 0 ? previousMonth : nextMonth);
      var saveSuccess = await waitUntil(function () {
        var afterHeader = headerYearMonth();
        return afterHeader && beforeHeader && (afterHeader[0] !== beforeHeader[0] || afterHeader[1] !== beforeHeader[1]) ? afterHeader : null;
      }, item && item.monthMoveTimeoutMs || 800);
    }
    var targetDayNode = Array.from(calendar.querySelectorAll(".calendar-grid .day:not(.disabled):not(.other-month)")).find(function (day) {
      return Number(normalizeText(day.textContent)) === targetDay;
    });
    if (!targetDayNode) return false;
    await clickElementDateNode(targetDayNode);
    await sleep(item && item.waitAfterSelectMs == null ? 260 : item && item.waitAfterSelectMs);
    return normalizeText(input.value) === normalizeText(String(match[1]) + "-" + String(targetMonth).padStart(2, "0") + "-" + String(targetDay).padStart(2, "0"));
  }

  async function fillScopedText(scope, value, item) {
    if (!scope || !hasMeaningfulValue(value)) return false;
    var selector = item && item.controlSelector || "textarea:not([disabled]):not([readonly]), input:not([type='hidden']):not([type='file']):not([disabled]):not([readonly])";
    var control = null;
    try { control = Array.from(scope.querySelectorAll(selector)).find(isVisible) || null; } catch (e) {}
    if (!control) return false;
    var ok = false;
    try { ok = await AF.FormHandler.fillFormElement(control, value, "text"); } catch (e2) {}
    if (!ok || String(control.value || "").trim() !== String(value).trim()) {
      setElementTextInput(control, value);
      try { control.blur && control.blur(); } catch (e3) {}
    }
    await sleep(item && item.waitAfterInputMs == null ? 180 : item && item.waitAfterInputMs);
    return String(control.value || "").trim() === String(value).trim() || ok;
  }

  async function fillJob51CitySearch(label, value, item, scope) {
    if (!hasMeaningfulValue(value)) return false;
    var group = label && label.closest && label.closest(".el-form-item") || closestLooseFormItem(label, scope);
    var container = null;
    var input = null;
    try {
      container = group.querySelector(item && item.containerSelector || ".item_input.input-list, .item_input-area") || group;
      input = Array.from(container.querySelectorAll(item && item.inputSelector || ".area_input input, input.el-input__inner, input:not([type='hidden'])"))
        .find(function (node) { return isVisible(node) && !node.disabled && !node.readOnly; }) || null;
    } catch (e) {}
    if (!input) return false;
    var wanted = String(value).replace(/市$/g, "").trim();
    var normalizedWanted = normalizeText(wanted);
    var committedText = function () {
      var tagRoot = null;
      try { tagRoot = container.querySelector(".area_tags") || group.querySelector(".area_tags"); } catch (e2) {}
      return normalizeText(tagRoot && tagRoot.textContent || "").replace(/市/g, "");
    };
    var closeOpenCityDialog = async function () {
      var openDialog = null;
      try {
        openDialog = Array.from(document.querySelectorAll(".el-dialog__wrapper.jbs_resume_cascader_dialog")).find(isVisible) || null;
      } catch (eCloseQuery) {}
      if (!openDialog) return true;
      var confirmButton = null;
      try {
        confirmButton = Array.from(openDialog.querySelectorAll("button.confirm_button, .confirm_button, .dialog_footer_wrapper button.el-button--primary"))
          .find(isVisible) || null;
      } catch (eConfirmQuery) {}
      if (confirmButton) {
        await safeClick(confirmButton);
        await sleep(item && item.waitAfterConfirmClickMs == null ? 180 : item && item.waitAfterConfirmClickMs);
        if (isVisible(openDialog) && typeof confirmButton.click === "function") {
          try { confirmButton.click(); } catch (eNativeConfirm) {}
          await sleep(180);
        }
      }
      if (isVisible(openDialog)) {
        var closeButton = null;
        try {
          closeButton = Array.from(openDialog.querySelectorAll(".el-dialog__headerbtn, button[aria-label='Close']"))
            .find(isVisible) || null;
        } catch (eCloseButtonQuery) {}
        if (closeButton) {
          await safeClick(closeButton);
          await sleep(160);
        }
      }
      return !isVisible(openDialog);
    };
    // 51job 的可见 input 只是弹窗入口。直接写 input.value 会显示城市名称，
    // 但不会更新 Vue 表单里的城市 code，因此只能以已选 tag 作为成功依据。
    if (committedText().indexOf(normalizedWanted) !== -1) {
      await closeOpenCityDialog();
      return committedText().indexOf(normalizedWanted) !== -1;
    }

    try { document.activeElement && document.activeElement.blur && document.activeElement.blur(); } catch (e3) {}
    await safeClick(input);
    var dialog = await waitUntil(function () {
      var dialogs = [];
      try { dialogs = Array.from(document.querySelectorAll(".el-dialog__wrapper.jbs_resume_cascader_dialog")); } catch (e4) {}
      return dialogs.find(isVisible) || null;
    }, item && item.optionTimeoutMs || 3000);
    if (!dialog) return false;

    var option = null;
    try {
      option = Array.from(dialog.querySelectorAll(".resumeDialog__top-city, .resumeDialog__right-city"))
        .filter(isVisible)
        .find(function (node) {
          var text = normalizeText(node.getAttribute("title") || node.textContent || "").replace(/市$/g, "");
          return text === normalizedWanted;
        }) || null;
    } catch (e5) {}
    if (!option) return false;
    if (!/resumeDialog__(?:top|right)-city-active/.test(String(option.className || ""))) {
      await safeClick(option);
      await sleep(item && item.waitAfterSelectMs == null ? 180 : item && item.waitAfterSelectMs);
    }

    var confirm = null;
    try { confirm = Array.from(dialog.querySelectorAll("button.confirm_button, .dialog_footer_wrapper button")).find(isVisible) || null; } catch (e6) {}
    if (!confirm) return false;
    await safeClick(confirm);
    var closed = await waitUntil(function () { return !isVisible(dialog) ? true : null; }, item && item.confirmTimeoutMs || 2000);
    if (!closed && typeof confirm.click === "function") {
      try { confirm.click(); } catch (eNativeConfirm2) {}
      closed = await waitUntil(function () { return !isVisible(dialog) ? true : null; }, item && item.confirmTimeoutMs || 2000);
    }
    await sleep(120);
    return committedText().indexOf(normalizedWanted) !== -1 && !isVisible(dialog);
  }

  function setNativeSelectValue(select, value) {
    if (!select) return false;
    var target = normalizeChoiceText(value).toLowerCase();
    var option = Array.from(select.options || []).find(function (o) {
      var text = normalizeChoiceText(o.textContent || o.label || o.value || "").toLowerCase();
      return text === target || text.indexOf(target) !== -1 || target.indexOf(text) !== -1;
    });
    if (!option) return false;
    var setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value");
    if (setter && setter.set) setter.set.call(select, option.value); else select.value = option.value;
    select.dispatchEvent(new Event("input", { bubbles: true }));
    select.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  async function fillSfCityPicker(label, value, item, scope) {
    // 顺丰地点弹窗尚未纳入本轮填写范围。保留函数供后续专用适配，
    // 但必须在入口处返回，防止任何遗留配置点击地点输入框。
    return false;
    /* eslint-disable no-unreachable */
    try {
      var input = label && label.closest && label.closest(".el-form-item") && label.closest(".el-form-item").querySelector("input.el-input__inner");
      if (!input || !value) return false;
      var text = typeof value === "string" ? value : [value.province, value.city, value.district, value.provinceName, value.cityName].filter(Boolean).join("");
      var province = (text.match(/^(北京市|上海市|天津市|重庆市|[^省]+省|[^区]+自治区|香港特别行政区|澳门特别行政区)/) || [""])[1];
      var city = (text.match(/(?:省|自治区)([^市]+市)|^(北京市|上海市|天津市|重庆市)/) || ["", "", ""])[1] || (text.match(/^(北京市|上海市|天津市|重庆市)/) || [""])[1];
      await AF.DomUtils.safeClickElement(input);
      await sleep(180);
      var dialog = Array.from(document.querySelectorAll(".el-dialog")).find(function (node) {
        return isVisible(node) && /城市选择/.test(String(node.textContent || ""));
      });
      if (!dialog) return false;
      var selects = Array.from(dialog.querySelectorAll("select"));
      if (!selects.length) return false;
      if (province) { setNativeSelectValue(selects[0], province); await sleep(160); }
      if (selects[1]) {
        if (city && !setNativeSelectValue(selects[1], city) && /^(北京市|上海市|天津市|重庆市)$/.test(province)) {
          var fallback = Array.from(selects[1].options || []).find(function (o) { return !/^(市|区|县)$/.test(String(o.value || o.textContent || "").trim()); });
          if (fallback) setNativeSelectValue(selects[1], fallback.value || fallback.textContent);
        }
        await sleep(100);
      }
      var ok = Array.from(dialog.querySelectorAll("button, .el-button")).find(function (node) { return /^确定$|^确认$/.test(String(node.textContent || "").trim()); });
      if (ok) await AF.DomUtils.safeClickElement(ok);
      await sleep(180);
      return String(input.value || "").replace(/\s+/g, "") !== "";
    } catch (e) { return false; }
    /* eslint-enable no-unreachable */
  }

  async function fillSpdbCityPicker(label, value, item, scope) {
    if (!hasMeaningfulValue(value)) return false;
    var text = typeof value === "string"
      ? value
      : [value.province, value.city, value.provinceName, value.cityName].filter(Boolean).join("");
    text = String(text || "").replace(/\s+/g, "").trim();
    if (!text) return false;
    var provinceMatch = text.match(/^(.*?(?:省|自治区|特别行政区|北京市|上海市|天津市|重庆市))/);
    var province = provinceMatch ? provinceMatch[1] : "";
    var rest = province ? text.slice(province.length) : text;
    var cityMatch = rest.match(/^(.+?(?:市|自治州|地区|盟))/);
    var city = cityMatch ? cityMatch[1] : rest;
    var group = label && label.closest && label.closest(".inputblock") || closestLooseFormItem(label, scope);
    if (!group) return false;
    var input = null;
    try { input = Array.from(group.querySelectorAll(item && item.inputSelector || "input.schoolSelect, input.selVal" )).find(isVisible) || null; } catch (eInput) {}
    if (!input) return false;
    var normalize = function (v) { return String(v || "").replace(/\s+/g, "").replace(/[省市]$/g, ""); };
    var wantedText = normalize(text);
    if (normalize(input.value).indexOf(wantedText) !== -1) return true;
    try { input.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window })); } catch (eMouseDown) {}
    await clickLooseTrigger(input);
    var popup = null;
    try { popup = Array.from(group.querySelectorAll(".provinceSchool")).find(isVisible) || Array.from(document.querySelectorAll(".provinceSchool")).find(isVisible) || null; } catch (ePopup) {}
    if (!popup) return false;
    var provincePanel = function () { try { return Array.from(popup.querySelectorAll(".schoolList li")).filter(isVisible); } catch (e) { return []; } };
    var cityPanel = function () { try { return Array.from(popup.querySelectorAll(".subList li")).filter(isVisible); } catch (e) { return []; } };
    var currentCityPanel = cityPanel();
    if (!currentCityPanel.length && province) {
      var provinceItem = provincePanel().find(function (node) { return normalize(node.getAttribute("title") || node.textContent) === normalize(province); });
      if (!provinceItem) return false;
      await clickElementChoiceNode(provinceItem);
      currentCityPanel = await waitUntil(function () { var list = cityPanel(); return list.length ? list : null; }, item && item.cityListTimeoutMs || 1800);
    }
    if (!currentCityPanel || !currentCityPanel.length) return false;
    var cityItem = currentCityPanel.find(function (node) { return normalize(node.getAttribute("title") || node.textContent) === normalize(city); });
    if (!cityItem) return false;
    await clickElementChoiceNode(cityItem);
    await sleep(item && item.waitAfterCityMs == null ? 160 : item.waitAfterCityMs);
    if (!isVisible(popup)) {
      var autoHiddenCodes = [];
      try { autoHiddenCodes = Array.from(group.querySelectorAll("input.localState, input.regCity")).map(function (node) { return String(node.value || "").trim(); }); } catch (eAutoHidden) {}
      var autoHasHiddenCodes = group.querySelector && group.querySelector("input.localState, input.regCity");
      return normalize(input.value).indexOf(wantedText) !== -1 && (!autoHasHiddenCodes || autoHiddenCodes.filter(Boolean).length >= 2);
    }
    var confirm = null;
    try { confirm = Array.from(popup.querySelectorAll(".button span[flag='1'], .button .button_reset")).filter(isVisible).find(function (node) { return node.getAttribute("flag") === "1" || normalizeText(node.textContent) === "确定"; }) || null; } catch (eConfirm) {}
    if (!confirm) return false;
    await clickElementChoiceNode(confirm);
    var closed = await waitUntil(function () { return !isVisible(popup) ? true : null; }, item && item.confirmTimeoutMs || 1800);
    var hiddenValues = [];
    try { hiddenValues = Array.from(group.querySelectorAll("input.localState, input.regCity")).map(function (node) { return String(node.value || "").trim(); }); } catch (eHidden) {}
    var hasHiddenCodes = group.querySelector && group.querySelector("input.localState, input.regCity");
    return !!closed && normalize(input.value).indexOf(wantedText) !== -1 && (!hasHiddenCodes || hiddenValues.filter(Boolean).length >= 2);
  }

  async function fillSpdbSchoolPicker(label, value, item, scope) {
    var wanted = String(value || "").replace(/\s+/g, "").trim();
    if (!wanted) return false;
    var group = label && label.closest && label.closest(".school") || scope || document;
    var input = Array.from(group.querySelectorAll("input.schoolSelect, input.selVal")).find(isVisible);
    if (!input) return false;
    await clickLooseTrigger(input);
    var popup = await waitUntil(function () { return Array.from(document.querySelectorAll(".provinceSchool")).find(isVisible) || null; }, item && item.popupTimeoutMs || 1800);
    if (!popup) return false;
    var search = Array.from(popup.querySelectorAll("input[name='STATE'], input.state")).find(isVisible);
    if (search) { setElementTextInput(search, value); await sleep(item && item.searchWaitMs || 300); }
    var option = await waitUntil(function () { return Array.from(popup.querySelectorAll(".schoolList li, li.DoubleWidthLi")).filter(isVisible).find(function (node) { var text = String(node.getAttribute("title") || node.textContent || "").replace(/\s+/g, "").trim(); return text === wanted || text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1; }) || null; }, item && item.optionTimeoutMs || 2500);
    if (!option) return false;
    await clickElementChoiceNode(option); await sleep(120);
    var confirm = Array.from(popup.querySelectorAll(".button span[flag='1'], .button .button_reset")).find(isVisible);
    if (confirm) await clickElementChoiceNode(confirm);
    await sleep(160);
    return String(input.value || "").replace(/\s+/g, "").indexOf(wanted) !== -1 && !isVisible(popup);
  }

  async function fillSpdbFamilyAddress(value, item) {
    if (value && value.basicInfo && typeof value.basicInfo === "object") value = Object.assign({}, value.basicInfo, value);
    var form = null;
    try { form = Array.from(document.querySelectorAll("form.formData, form.formedit")).find(function (node) { return /家庭住址/.test(String(node.querySelector("input[name='addType']")?.value || "")); }) || null; } catch (eForm) {}
    if (!form || !value) return false;
    var text = typeof value === "string" ? value : (value.text || [value.province, value.city, value.detail].filter(Boolean).join(""));
    text = String(text || "").replace(/\s+/g, "");
    var province = (text.match(/^(.*?(?:省|自治区|特别行政区|北京市|上海市|天津市|重庆市))/) || [""])[1];
    var rest = province ? text.slice(province.length) : text;
    var city = (rest.match(/^(.+?(?:市|自治州|地区|盟))/) || ["", rest])[1];
    var postal = value && value.postal || item && item.postalCode || "";
    var detail = value && (value.detail || value.familyAddressDetail || value.currentAddressDetail) || item && item.detail || text;
    var country = form.querySelector("select[name='countryCd']");
    var state = form.querySelector("select[name='state']");
    var citySelect = form.querySelector("select[name='city']");
    var address = form.querySelector("input[name='address']");
    var postalInput = form.querySelector("input[name='postal']");
    // 编辑已有家庭住址时先清空旧值，避免旧的省市/地址让流程误判为已完成。
    if (postalInput) await AF.FormHandler.fillFormElement(postalInput, "", "text");
    if (address) await AF.FormHandler.fillFormElement(address, "", "text");
    if (state) { state.value = ""; state.dispatchEvent(new Event("change", { bubbles: true })); }
    if (citySelect) { citySelect.value = ""; citySelect.dispatchEvent(new Event("change", { bubbles: true })); }
    if (country) setNativeSelectValue(country, "CHN");
    async function select2Pick(select, wanted) {
      if (!select || !wanted) return false;
      var host = select.parentElement, trigger = host && host.querySelector(".select2-selection");
      if (trigger) {
        await safeClick(trigger);
        var option = await waitUntil(function () { return findByText(document, wanted, ".select2-results__option, .select2-dropdown li, [role='option']"); }, 1800);
        if (option) { await safeClick(option); return true; }
      }
      return setNativeSelectValue(select, wanted);
    }
    if (state && province) await select2Pick(state, province);
    await sleep(180);
    if (citySelect && city) {
      await waitUntil(function () { return citySelect.options && citySelect.options.length > 1 ? true : null; }, 1800);
      await select2Pick(citySelect, city);
    }
    var postalValue = postal || "";
    if (!postalValue) { try { var currentForm = Array.from(document.querySelectorAll("form.formData")).find(function (node) { return /现住址/.test(String(node.querySelector("input[name='addType']")?.value || "")); }); var currentPostal = currentForm && currentForm.querySelector("input[name='postal']"); postalValue = currentPostal && currentPostal.value || ""; } catch (ePostal) {} }
    if (postalInput && postalValue) await AF.FormHandler.fillFormElement(postalInput, postalValue, "text");
    if (address && detail) await AF.FormHandler.fillFormElement(address, detail, "text");
    return !!((state && province && String(state.value || "") !== "") && (citySelect && city && String(citySelect.value || "") !== ""));
  }

  // 顺丰页面把“居民身份证”等证件类型统一显示为“身份证”。
  // 仅在顺丰专用步骤调用，避免改变普通站点的严格选项匹配。
  async function fillSfIdType(label, value, item) {
    var text = String(value == null ? "" : value).trim();
    if (/居民身份证|大陆身份证|二代身份证|身份证/.test(text)) text = "身份证";
    var formItem = label && label.closest && label.closest(".el-form-item");
    var control = formItem && formItem.querySelector(".el-select:not(.is-disabled), select");
    if (!control) return false;
    if (control.matches && control.matches("select")) return setNativeSelectValue(control, text);
    return fillScopedElementChoice(control, text, Object.assign({}, item, { allowPartialMatch: true }));
  }

  async function fillJob51Salary(label, data, item) {
    var group = label && label.closest && label.closest(".el-form-item");
    if (!group) return false;
    var selects = [];
    try { selects = Array.from(group.querySelectorAll(".el-select:not(.is-disabled)")); } catch (e) {}
    if (selects.length < 3) return false;
    var values = [data && data[item.minField], data && data[item.maxField], data && data[item.monthsField]];
    var allOk = true;
    for (var i = 0; i < values.length; i++) {
      if (!hasMeaningfulValue(values[i])) continue;
      var currentSelect = selects[i];
      if (currentSelect.classList.contains("is-disabled") || currentSelect.querySelector(".is-disabled")) {
        var enabled = await waitUntil(function () {
          return !currentSelect.classList.contains("is-disabled") && !currentSelect.querySelector(".is-disabled") ? currentSelect : null;
        }, item && item.enableTimeoutMs || 1800);
        if (!enabled) { allOk = false; continue; }
      }
      var selected = false;
      if (AF.SelectAdapter && typeof AF.SelectAdapter.create === "function") {
        try { selected = await AF.SelectAdapter.create(currentSelect, "string").selectValue(values[i]); } catch (e2) {}
      }
      if (!selected) selected = await fillScopedElementChoice(currentSelect, values[i], item);
      allOk = allOk && selected;
      await sleep(item && item.waitAfterEachMs == null ? 180 : item && item.waitAfterEachMs);
    }
    return allOk;
  }

  async function waitForFieldReadyAfterSelection(scope, item) {
    if (!item || (!item.afterSelectReadyLabel && !item.afterSelectReadySelector)) return true;
    if (item.afterSelectReadySelector) {
      return !!(await waitUntil(function () {
        var roots = [];
        if (scope && scope.isConnected !== false) roots.push(scope);
        roots.push(document);
        return roots.some(function (root) {
          try {
            return Array.from(root.querySelectorAll(item.afterSelectReadySelector)).some(isVisible);
          } catch (eSelector) {
            return false;
          }
        }) ? true : null;
      }, item.afterSelectTimeoutMs || 2200));
    }
    var wanted = (Array.isArray(item.afterSelectReadyLabel) ? item.afterSelectReadyLabel : [item.afterSelectReadyLabel])
      .map(normalizeText).filter(Boolean);
    return !!(await waitUntil(function () {
      var root = scope || document;
      var labels = [];
      try { labels = Array.from(root.querySelectorAll("label")); } catch (e) {}
      return labels.find(function (node) {
        var text = normalizeText(node.textContent);
        return isVisible(node) && wanted.some(function (target) { return text.indexOf(target) !== -1; });
      }) || null;
    }, item.afterSelectTimeoutMs || 2200));
  }

  function closestLooseFormItem(label, scope) {
    var roots = [];
    var current = label;
    for (var depth = 0; current && current !== document && depth < 5; depth++, current = current.parentElement) {
      roots.push(current);
      if (current.matches && current.matches(".el-form-item, .ant-form-item, .form-group, [class*='form-item'], [class*='formItem']")) break;
    }
    if (scope) roots.push(scope);
    return roots.find(function (root) {
      try {
        return root && Array.from(root.querySelectorAll("input:not([type='hidden']), textarea, [role='combobox']")).some(isVisible);
      } catch (e) {
        return false;
      }
    }) || label;
  }

  function normalizePinganOptionText(value) {
    return normalizeChoiceText(value).replace(/^中国/, "").replace(/省|市|区|县|特别行政区|自治区/g, "");
  }

  function optionTextMatchesLoose(node, value) {
    var text = normalizeChoiceText(node && node.textContent);
    var wanted = normalizeChoiceText(value);
    if (!text || !wanted) return false;
    if (text === wanted) return true;
    if (/^\+?\d+$/.test(wanted) && text.indexOf(wanted) !== -1) return true;
    var textLoose = normalizePinganOptionText(text);
    var wantedLoose = normalizePinganOptionText(wanted);
    return !!(textLoose && wantedLoose && textLoose === wantedLoose);
  }

  function findFloatingOption(value, item) {
    var selectors = item && item.optionSelector || [
      ".el-cascader-node",
      ".el-cascader__suggestion-item",
      ".el-cascader-menu__item",
      ".el-select-dropdown__item",
      ".ant-cascader-menu-item",
      ".ant-select-item-option",
      "[role='option']",
      "[role='treeitem']",
      "li",
      "[class*='option']",
      "[class*='item']"
    ].join(",");
    var nodes = [];
    try { nodes = Array.from(document.querySelectorAll(selectors)); } catch (e) {}
    var candidates = nodes.filter(function (node) {
      if (!isVisible(node)) return false;
      var text = normalizeText(node.textContent || node.getAttribute("title") || node.getAttribute("aria-label"));
      if (!text || text.length > 80) return false;
      if (!optionTextMatchesLoose(node, value)) return false;
      var floatingRoot = node.closest && node.closest(
        ".el-popper, .el-cascader__dropdown, .el-select-dropdown, .ant-cascader-menus, .ant-select-dropdown, [class*='popper'], [class*='dropdown'], [class*='cascader'], [class*='menu'], [role='listbox'], [role='tree']"
      );
      return !!floatingRoot || /option|item|node|menu/i.test(String(node.className || ""));
    });
    candidates.sort(function (a, b) {
      var at = normalizeChoiceText(a.textContent);
      var bt = normalizeChoiceText(b.textContent);
      var wanted = normalizeChoiceText(value);
      var aExact = at === wanted ? 0 : 1;
      var bExact = bt === wanted ? 0 : 1;
      if (aExact !== bExact) return aExact - bExact;
      var ar = a.getBoundingClientRect();
      var br = b.getBoundingClientRect();
      return ar.top - br.top || ar.left - br.left;
    });
    return candidates[0] || null;
  }

  async function clickLooseTrigger(element) {
    if (!element) return false;
    var target = element.closest && element.closest(".el-cascader, .el-select, .ant-cascader-picker, .ant-select, [role='combobox'], [class*='cascader'], [class*='select']") || element;
    await ensureElementInViewport(target);
    try { target.focus && target.focus(); } catch (e0) {}
    await safeClick(target);
    await sleep(120);
    return true;
  }

  async function fillPinganCascader(label, value, item, scope) {
    var values = choiceValueList(value);
    if (!values.length) return false;
    var group = closestLooseFormItem(label, scope);
    var trigger = null;
    try {
      trigger = Array.from(group.querySelectorAll(
        ".el-cascader, .ant-cascader-picker, [class*='cascader'], [role='combobox'], input:not([type='hidden'])"
      )).find(isVisible);
    } catch (e) {}
    if (!trigger) return false;
    // 仍然交给插件现有 SelectAdapter；平安特殊工作流只负责锁定字段和提供
    // 路径。adapter 同时支持 Element UI 2.x 与 Element Plus。
    if (AF.SelectAdapter && typeof AF.SelectAdapter.create === "function") {
      try {
        var adapterValue = Array.isArray(value) ? value : value;
        if (await AF.SelectAdapter.create(trigger, typeof adapterValue === "object" ? "object" : "string").selectValue(adapterValue)) {
          return true;
        }
      } catch (eAdapter) {}
    }
    await clickLooseTrigger(trigger);
    var input = null;
    try { input = Array.from(group.querySelectorAll("input:not([type='hidden'])")).find(isVisible) || null; } catch (e0) {}
    var lastValue = values[values.length - 1];
    if (input && !input.disabled && (!input.readOnly || /请输入/.test(input.placeholder || ""))) {
      setElementTextInput(input, lastValue);
      await sleep(item && item.waitAfterInputMs == null ? 320 : item && item.waitAfterInputMs);
      var searchedOption = await waitUntil(function () { return findFloatingOption(lastValue, item); }, item && item.searchOptionTimeoutMs || 1800);
      if (searchedOption) {
        await clickElementChoiceNode(searchedOption);
        await sleep(item && item.waitAfterSelectMs == null ? 220 : item && item.waitAfterSelectMs);
        return elementChoiceValueMatches(group, lastValue) ||
          normalizePinganOptionText(group.textContent).indexOf(normalizePinganOptionText(lastValue)) !== -1;
      }
      await clickLooseTrigger(trigger);
    }
    for (var i = 0; i < values.length; i++) {
      var optionValue = values[i];
      var option = await waitUntil(function () { return findFloatingOption(optionValue, item); }, item && item.optionTimeoutMs || 1800);
      if (!option) return false;
      await clickElementChoiceNode(option);
      await sleep(item && item.waitAfterOptionMs == null ? 180 : item && item.waitAfterOptionMs);
    }
    var confirm = findByText(document, item && item.confirmText || ["确定", "确认"], "button, a, [role='button']");
    if (confirm) {
      try { await safeClick(confirm); await sleep(160); } catch (e0) {}
    }
    await sleep(item && item.waitAfterSelectMs == null ? 220 : item && item.waitAfterSelectMs);
    try {
      var inputs = Array.from(group.querySelectorAll("input:not([type='hidden'])")).filter(isVisible);
      var text = inputs.map(function (input) { return input.value || input.placeholder || ""; }).join(" ");
      var finalValue = values[values.length - 1];
      return optionTextMatchesLoose({ textContent: text }, finalValue) || normalizeText(text).indexOf(normalizeText(finalValue)) !== -1;
    } catch (e2) {
      return true;
    }
  }

  async function fillPinganPhone(label, data, item, scope) {
    var group = closestLooseFormItem(label, scope);
    var inputs = [];
    try {
      inputs = Array.from(group.querySelectorAll("input:not([type='hidden']):not([type='file'])")).filter(isVisible);
    } catch (e) {}
    if (inputs.length < 2) return false;
    var codeInput = inputs[0];
    var phoneInput = inputs.find(function (input) {
      return /手机/.test(String(input.placeholder || "")) && input !== codeInput;
    }) || inputs[inputs.length - 1];
    var rawPhone = String(data && data[item.phoneField || "phone"] || "").trim();
    var phone = rawPhone.replace(/[^\d]/g, "");
    if (phone.indexOf("86") === 0 && phone.length > 11) phone = phone.slice(2);
    var codeOk = false;
    var codeContainer = codeInput.closest && codeInput.closest(".el-select, .ant-select, [role='combobox'], [class*='select']") || codeInput;
    await clickLooseTrigger(codeContainer);
    var codeOption = await waitUntil(function () {
      var exact = findFloatingOption("+86", item);
      if (exact) return exact;
      var china = findFloatingOption("中国", item);
      if (china && /(^|\\D)86(\\D|$)/.test(normalizeText(china.textContent))) return china;
      return null;
    }, item && item.optionTimeoutMs || 2200);
    if (codeOption) {
      await clickElementChoiceNode(codeOption);
      codeOk = true;
    }
    if (!codeOk || normalizeText(codeInput.value).indexOf("+86") === -1) {
      setElementTextInput(codeInput, "+86");
      codeOk = true;
    }
    var phoneOk = false;
    if (phone && phoneInput) {
      phoneOk = await AF.FormHandler.fillFormElement(phoneInput, phone, "text");
    }
    return !!(codeOk && phoneOk);
  }

  async function fillPinganInlineSelect(label, value, item, scope) {
    var wantedValues = choiceValueList(value);
    if (!wantedValues.length) return false;
    var wanted = wantedValues[wantedValues.length - 1];
    // 平安同一模块里既有已保存记录的展示文字，也有当前新增表单。必须优先
    // 锁定 label 所属的真实 form-item；否则“熟练”等展示文字会被误当成选项
    // 点击，函数虽然返回成功，Vue 下拉值却没有真正变化。
    var group = label && label.closest && label.closest(".el-form-item") || closestLooseFormItem(label, scope);
    var select = null;
    try {
      select = Array.from(group.querySelectorAll(
        ".el-select:not(.is-disabled), .ant-select:not(.ant-select-disabled), [role='combobox']"
      )).find(isVisible);
    } catch (e) {}
    if (select && elementChoiceValueMatches(select, wanted)) return true;
    if (select) {
      if (AF.SelectAdapter && typeof AF.SelectAdapter.create === "function") {
        try {
          if (await AF.SelectAdapter.create(select, "string").selectValue(wanted) &&
            elementChoiceValueMatches(select, wanted)) return true;
        } catch (e1) {}
      }
      if (await fillScopedElementChoice(select, wanted, item)) return true;
      // 个别平安页面版本把下拉浮层挂在 body，Element scoped panel 偶尔无法
      // 建立归属关系。最后再明确打开当前下拉，并只从可见浮层中找选项。
      await clickLooseTrigger(select);
      var floatingOption = await waitUntil(function () {
        return findFloatingOption(wanted, Object.assign({}, item || {}, {
          optionSelector: ".el-select-dropdown__item, [role='option']",
        }));
      }, item && item.optionTimeoutMs || 2200);
      if (floatingOption) {
        await clickElementChoiceNode(floatingOption.querySelector("span") || floatingOption);
        await sleep(item && item.waitAfterSelectMs == null ? 220 : item && item.waitAfterSelectMs);
        return elementChoiceValueMatches(select, wanted);
      }
    }

    // 兼容少数用 radio/chip 模拟的内嵌选择，但不再扫描普通 div/span，且
    // 点击后必须出现 checked/selected/active 状态才算成功。
    var localNodes = [];
    try {
      localNodes = Array.from(group.querySelectorAll(
        "label[role='radio'], [role='radio'], button, li[role='option'], [role='option']"
      ));
    } catch (e0) {}
    var localOption = localNodes.filter(isVisible).find(function (node) {
      var text = normalizeText(node.textContent || node.getAttribute("title") || node.getAttribute("aria-label"));
      return text && text.length <= 40 && optionTextMatchesLoose(node, wanted);
    });
    if (localOption) {
      await clickElementChoiceNode(localOption);
      await sleep(item && item.waitAfterSelectMs == null ? 180 : item && item.waitAfterSelectMs);
      return localOption.getAttribute("aria-checked") === "true" ||
        localOption.getAttribute("aria-selected") === "true" ||
        /is-checked|is-selected|is-active|active|selected|checked/.test(String(localOption.className || ""));
    }
    return false;
  }

  function zhaopinTextMatch(candidate, wanted) {
    var actual = normalizeText(candidate);
    var target = normalizeText(wanted);
    if (!actual || !target) return -1;
    if (actual === target) return 100;
    if (actual.indexOf(target) !== -1) return 80;
    if (target.indexOf(actual) !== -1 && actual.length >= 2) return 60;
    return -1;
  }

  function findBestZhaopinTextOption(root, value, selector) {
    var candidates = [];
    try {
      candidates = Array.from((root || document).querySelectorAll(
        selector || ".s-search-select li.s-option, .s-options__content > li.s-option, .s-dialog li, .s-dialog [role='option'], .ivu-select-item"
      )).filter(isVisible);
    } catch (e) {}
    candidates = candidates.map(function (node) {
      return node.closest && node.closest("li.s-option, [role='option'], .ivu-select-item") || node;
    }).filter(function (node, index, array) {
      return node && array.indexOf(node) === index;
    });
    return candidates.map(function (node) {
      return { node: node, score: zhaopinTextMatch(node.textContent, value) };
    }).filter(function (entry) { return entry.score >= 0; })
      .sort(function (a, b) { return b.score - a.score; })[0];
  }

  function findFirstVisibleZhaopinOption(root, selector) {
    var candidates = [];
    try {
      candidates = Array.from((root || document).querySelectorAll(
        selector || ".s-options__content > li.s-option"
      )).filter(isVisible);
    } catch (e) {}
    var first = candidates[0] || null;
    if (!first) return null;
    first = first.closest && first.closest("li.s-option, [role='option'], .ivu-select-item") || first;
    return { node: first, score: 1 };
  }

  async function fillZhaopinSearchSelect(value, item, scope) {
    if (!hasMeaningfulValue(value)) return false;
    var input = null;
    try {
      input = Array.from((scope || document).querySelectorAll(
        item.inputSelector || ".s-search-select input.s-input__inner, input.s-input__inner"
      )).find(isVisible) || null;
    } catch (eInput) {}
    if (!input) return false;
    if (item.openBeforeInput === true) {
      await safeClick(input);
      await sleep(item.waitAfterOpenMs == null ? 180 : item.waitAfterOpenMs);
    }
    if (input.readOnly) {
      var editableInput = await waitUntil(function () {
        var root = input.closest && (input.closest(".el-select, .apply-remote-select, .el-form-item") || input.parentElement);
        try {
          return Array.from((root || document).querySelectorAll("input.el-input__inner, input"))
            .filter(isVisible)
            .find(function (node) {
              return !node.disabled && !node.readOnly &&
                (!input.placeholder || node.placeholder === input.placeholder);
            }) || null;
        } catch (eEditableInput) {
          return null;
        }
      }, item.waitForEditableInputMs || 1400);
      if (editableInput) input = editableInput;
    }

    // 公司/学校远程搜索不能用 value setter 直接写入。那样只会让
    // input 表面显示文字，不会稳定触发搜索和候选项的 select 回调，
    // 保存时组件内部企业 id 仍为空。优先通过 CDP 生成真实按键与
    // 鼠标点击，并且只有具体 li.s-option 被选中后才算成功。
    var trustedItem = Object.assign({}, item || {}, {
      autocompletePanelSelector: item.autocompletePanelSelector || ".s-options",
      autocompleteOptionSelector: item.optionSelector || ".s-options__content > li.s-option",
      waitAfterClearMs: item.waitAfterClearMs == null ? 180 : item.waitAfterClearMs,
      waitAfterInputMs: item.searchWaitMs == null ? 700 : item.searchWaitMs,
      waitBeforeOptionClickMs: item.waitBeforeOptionClickMs == null ? 260 : item.waitBeforeOptionClickMs,
      waitAfterSelectMs: item.waitAfterSelectMs == null ? 260 : item.waitAfterSelectMs,
      optionTimeoutMs: item.optionTimeoutMs || 4200,
    });
    if (await fillTrustedElementAutocomplete(input, String(value), trustedItem)) return true;

    // 调试器通道不可用时，再用逐字输入事件降级；不再一次性
    // 直接设置 value。降级路径仍必须看到并点击具体候选项。
    var typed = await typeElementAutocompleteInput(input, String(value), Object.assign({}, item || {}, {
      waitAfterClearMs: item.waitAfterClearMs == null ? 180 : item.waitAfterClearMs,
      typeIntervalMs: item.typeIntervalMs == null ? 80 : item.typeIntervalMs,
    }));
    if (!typed) return false;
    var inputReady = await waitUntil(function () {
      return normalizeText(input.value) === normalizeText(value) ? input : null;
    }, item.inputWriteTimeoutMs || 1000);
    if (!inputReady) return false;
    // 远程公司/学校搜索存在防抖。必须等本次完整关键词触发的候选列表
    // 返回后再选择，不能复用输入前或上一次搜索遗留的旧候选。
    await sleep(item.searchWaitMs == null ? 520 : item.searchWaitMs);
    var match = await waitUntil(function () {
      // 优先选精准/相似候选；公司名称在企业库中确实没有
      // 可匹配项时，才降级选站点默认排序的第一项。
      var bestMatch = findBestZhaopinTextOption(document, value, item.optionSelector) || null;
      if (bestMatch) return bestMatch;
      if (item.fallbackToFirstOption === true) {
        return findFirstVisibleZhaopinOption(document, item.optionSelector) || null;
      }
      return null;
    }, item.optionTimeoutMs || 3200);
    if (match && match.node) {
      await safeClick(match.node);
      await sleep(item.waitAfterSelectMs || 180);
      return !!(await waitUntil(function () {
        var actual = normalizeText(input.value);
        var wanted = normalizeText(value);
        var optionsOpen = false;
        try { optionsOpen = Array.from(document.querySelectorAll(".s-options")).some(isVisible); } catch (eOptions) {}
        return actual && !optionsOpen && (actual.indexOf(wanted) !== -1 || wanted.indexOf(actual) !== -1) ? input : null;
      }, item.writebackTimeoutMs || 1600));
    }
    // 公司和证书允许保存自由文本；学校和专业必须选中智联候选。
    if (item.allowPlainText === true) {
      input.dispatchEvent(new Event("change", { bubbles: true }));
      input.blur();
      return normalizeText(input.value) === normalizeText(value);
    }
    return false;
  }

  async function fillZhaopinSchoolSelect(label, value, item, scope) {
    if (!hasMeaningfulValue(value)) return false;
    var formItem = label && label.closest && label.closest(".el-form-item");
    if (!formItem) return false;
    var container = formItem.querySelector(".apply-remote-select, .el-select") || formItem;
    var trigger = null;
    try {
      trigger = Array.from(formItem.querySelectorAll("input[placeholder], .el-select, .apply-remote-select, [role='combobox']")).find(isVisible) || null;
    } catch (eTrigger) {}
    if (!trigger) return false;

    function currentText() {
      var input = Array.from(formItem.querySelectorAll("input.el-input__inner, input")).find(isVisible) || null;
      var text = input && (String(input.value || "").trim() || String(input.getAttribute("placeholder") || "").trim());
      if (!text) text = getElementChoiceCurrentValue(container);
      return normalizeChoiceText(text);
    }

    function schoolDropdownOpen() {
      return Array.from(document.querySelectorAll(".apply-remote-select__dropdown, .el-select-dropdown")).some(isVisible);
    }
    // 搜索词仍在输入框时不代表已选中；选中后组件可能清空 value，改用 placeholder 回显。
    if (currentText() === normalizeChoiceText(value) && !schoolDropdownOpen()) return true;

    await clickLooseTrigger(trigger);
    var editableInput = null;
    try {
      editableInput = Array.from(formItem.querySelectorAll("input.el-input__inner, input"))
        .filter(isVisible)
        .find(function (node) {
          return !node.disabled && !node.readOnly;
        }) || null;
    } catch (eEditable) {}
    var searchInput = editableInput;
    if (!searchInput) {
      try {
        searchInput = Array.from(formItem.querySelectorAll("input.el-input__inner, input"))
          .filter(isVisible)
          .find(function (node) {
            return !node.disabled;
          }) || null;
      } catch (eSearchInput) {}
    }
    if (!searchInput) searchInput = trigger;
    if (searchInput) {
      var searchText = normalizeChoiceText(searchInput.value || searchInput.getAttribute("placeholder") || "");
      if (searchText !== normalizeChoiceText(value)) {
        var typed = await typeElementAutocompleteInput(searchInput, String(value), Object.assign({}, item || {}, {
          waitAfterClearMs: item && item.waitAfterClearMs == null ? 120 : item && item.waitAfterClearMs,
          typeIntervalMs: item && item.typeIntervalMs == null ? 70 : item && item.typeIntervalMs,
        }));
        if (!typed) setElementTextInput(searchInput, String(value));
        await sleep(item && item.searchWaitMs == null ? 520 : item && item.searchWaitMs);
      }
    }
    var dropdown = await waitUntil(function () {
      try {
        return Array.from(document.querySelectorAll(".apply-remote-select__dropdown, .el-select-dropdown"))
          .filter(isVisible)
          .find(function (panel) {
            var manualAdd = findByText(panel, ["手动添加"], "button, a, [role='button']");
            var hasNoMatch = /无匹配结果/.test(normalizeText(panel.textContent));
            var hasOption = Array.from(panel.querySelectorAll(".el-select-dropdown__item, [role='option'], li"))
              .filter(isVisible)
              .some(function (node) {
                return !/无匹配结果/.test(normalizeText(node.textContent));
              });
            return hasOption || hasNoMatch || manualAdd;
          }) || null;
      } catch (eDropdown) {
        return null;
      }
    }, item && item.optionTimeoutMs || 3000);
    var options = [];
    try {
      options = dropdown ? Array.from(dropdown.querySelectorAll(".el-select-dropdown__item, [role='option'], li")).filter(function (node) {
        return isVisible(node) && !/无匹配结果/.test(normalizeText(node.textContent)) && !/is-disabled|disabled/.test(String(node.className || ""));
      }) : [];
    } catch (eOptions) {}
    var wanted = normalizeChoiceText(value);
    var option = options.find(function (node) {
      return normalizeChoiceText(node.textContent) === wanted;
    }) || (!(item && item.exactSchoolMatch) && options.find(function (node) {
      var text = normalizeChoiceText(node.textContent);
      return text && (text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1);
    })) || (item && !item.exactSchoolMatch && item.fallbackToFirstOption === true ? options[0] : null);

    if (option) {
      await clickElementChoiceNode(option);
      await sleep(item && item.waitAfterSelectMs == null ? 260 : item && item.waitAfterSelectMs);
      if (item && item.exactSchoolMatch) {
        return !!(await waitUntil(function () {
          return !schoolDropdownOpen() && currentText() === wanted;
        }, item.writebackTimeoutMs || 2000));
      }
      if (currentText() === wanted) return true;
    }

    if (item && item.manualAddWhenHighSchool === true) {
      var manualAddButton = dropdown && findByText(dropdown, ["手动添加"], "button, a, [role='button']");
      if (!manualAddButton) {
        try {
          manualAddButton = Array.from(document.querySelectorAll(".apply-remote-select__footer-action")).find(isVisible) || null;
        } catch (eManualButton) {}
      }
      if (!manualAddButton) return false;
      await safeClick(manualAddButton);
      var dialog = await waitUntil(function () {
        try { return Array.from(document.querySelectorAll(".school-manual-add-dialog, .el-dialog")).filter(isVisible).pop() || null; } catch (eDialog) { return null; }
      }, item.dialogTimeoutMs || 2500);
      if (!dialog) return false;
      var dialogInput = null;
      try {
        dialogInput = dialog.querySelector(".school-manual-add-dialog input[placeholder='请输入学校名称'], .school-manual-add-dialog input.el-input__inner, .el-dialog__body input.el-input__inner, .el-dialog__body input");
        if (!dialogInput || !isVisible(dialogInput)) {
          dialogInput = Array.from(dialog.querySelectorAll("input.el-input__inner, input")).find(isVisible) || null;
        }
      } catch (eDialogInput) {}
      if (!dialogInput) return false;
      setElementTextInput(dialogInput, String(value));
      await sleep(item.waitAfterInputMs == null ? 220 : item.waitAfterInputMs);
      var confirmButton = findByText(dialog, ["确 定", "确定"], "button, a, [role='button']");
      if (!confirmButton) {
        try {
          confirmButton = Array.from(dialog.querySelectorAll(".v-dialog__footer-confirm, .el-dialog__footer button, button")).find(isVisible) || null;
        } catch (eConfirm) {}
      }
      if (!confirmButton) return false;
      await safeClick(confirmButton);
      await sleep(item.waitAfterSelectMs == null ? 260 : item.waitAfterSelectMs);
      return currentText() === wanted || normalizeChoiceText(formItem.textContent || "").indexOf(wanted) !== -1;
    }

    return item && item.exactSchoolMatch ? false : currentText() === wanted;
  }

  async function fillZhaopinPsbcHighSchoolSelect(label, value, item, scope) {
    if (!hasMeaningfulValue(value)) return false;
    var formItem = label && label.closest && label.closest(".el-form-item");
    if (!formItem) return false;
    var trigger = null;
    try {
      trigger = formItem.querySelector(".apply-form-school .el-select, .apply-form-school .el-input, .apply-remote-select .el-select, .apply-remote-select .el-input, .el-select, .el-input");
      if (!trigger || !isVisible(trigger)) {
        trigger = Array.from(formItem.querySelectorAll("input.el-input__inner, input, .el-select")).find(isVisible) || null;
      }
    } catch (eTrigger) {}
    if (trigger && AF.SelectAdapter && typeof AF.SelectAdapter.create === "function") {
      try {
        var adapterValue = { name: String(value), selectFirstOption: true, fallbackFirst: true, allowFirstOption: true, requireBlurAfterSelect: true };
        var adapter = AF.SelectAdapter.create(trigger, "string");
        if (adapter && await adapter.selectValue(adapterValue)) return true;
      } catch (eAdapter) {}
    }
    return fillZhaopinSchoolSelect(label, value, Object.assign({}, item || {}, {
      manualAddWhenHighSchool: true,
    }), scope);
  }

  async function fillZhaopinDialogSelect(value, item, scope) {
    if (!hasMeaningfulValue(value)) return false;
    var trigger = null;
    if (item._labelElement && item._labelElement.closest) {
      try {
        var labelledRow = item._labelElement.closest(".job-target-edit__item, .select-area, li");
        trigger = labelledRow && labelledRow.querySelector(".select-input");
      } catch (eLabelledTrigger) {}
    }
    try {
      trigger = Array.from((scope || document).querySelectorAll(item.triggerSelector || ".select-input")).find(isVisible) || null;
    } catch (eTrigger) {}
    if (!trigger) return false;
    await safeClick(trigger);
    var dialog = await waitUntil(function () {
      try { return Array.from(document.querySelectorAll(".s-dialog")).filter(isVisible).pop() || null; }
      catch (e) { return null; }
    }, item.dialogTimeoutMs || 2200);
    if (!dialog) return false;
    var search = null;
    try {
      search = Array.from(dialog.querySelectorAll("input")).find(isVisible) || null;
    } catch (eSearch) {}
    if (search) {
      setElementTextInput(search, "");
      setElementTextInput(search, String(value));
      await sleep(item.searchWaitMs || 450);
    }
    var match = findBestZhaopinTextOption(dialog, value,
      item.optionSelector || "li, [class*='option'], [class*='item']");
    if (!match || !match.node) {
      var close = null;
      try { close = dialog.querySelector(".s-dialog__icon.s-icon-guanbi"); } catch (eClose) {}
      if (close) await safeClick(close);
      return false;
    }
    await safeClick(match.node);
    await sleep(item.waitAfterSelectMs || 220);
    // 有些智联分类要先点一级再点搜索结果；如果弹窗仍在，
    // 再尝试点一次当前文本的最佳叶子。
    var stillOpen = isVisible(dialog);
    if (stillOpen) {
      var leaf = findBestZhaopinTextOption(dialog, value,
        item.leafSelector || "li, [class*='option'], [class*='item']");
      if (leaf && leaf.node) {
        await safeClick(leaf.node);
        await sleep(item.waitAfterSelectMs || 220);
      }
    }
    return !isVisible(dialog) || normalizeText(trigger.textContent).indexOf(normalizeText(value)) !== -1;
  }

  function normalizeZhaopinRegionName(value) {
    return normalizeText(value).replace(/(?:壮族自治区|回族自治区|维吾尔自治区|自治区|特别行政区|省|市)$/g, "");
  }

  function findZhaopinAdministrativeOption(dialog, selector, value) {
    var wanted = normalizeZhaopinRegionName(value);
    if (!wanted) return null;
    var nodes = [];
    try { nodes = Array.from(dialog.querySelectorAll(selector)); } catch (e) {}
    if (!nodes.length) {
      try { nodes = Array.from(dialog.querySelectorAll(".s-cascader__option")); } catch (eFallback) {}
    }
    return nodes.find(function (node) {
      var titleNode = node.querySelector && node.querySelector("p[title]");
      return normalizeZhaopinRegionName(titleNode ? titleNode.getAttribute("title") : node.textContent) === wanted;
    }) || nodes.find(function (node) {
      var titleNode = node.querySelector && node.querySelector("p[title]");
      var text = normalizeZhaopinRegionName(titleNode ? titleNode.getAttribute("title") : node.textContent);
      return text && (text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1);
    }) || null;
  }

  function findZhaopinAdministrativeLeaf(dialog, value) {
    var wanted = normalizeZhaopinRegionName(value);
    var prefix = Array.from(wanted).slice(0, 2).join("");
    if (!prefix) return null;
    var nodes = [];
    try { nodes = Array.from(dialog.querySelectorAll(".s-cascader__third-level .s-checkbutton__item, .s-cascader__third-level .s-cascader__option, .s-cascader__third-level li, .s-cascader__third-level p")); } catch (e) {}
    return nodes.find(function (node) {
      var text = normalizeZhaopinRegionName(node.textContent);
      return text && (text.indexOf(prefix) === 0 || prefix.indexOf(text.slice(0, 2)) === 0);
    }) || null;
  }

  function splitZhaopinAdministrativeParts(value) {
    if (value && typeof value === "object" && !Array.isArray(value)) {
      var objectParts = [value.province, value.city, value.district || value.area || value.county, value.provinceName, value.cityName, value.districtName];
      var named = objectParts.filter(function (part) { return part != null && String(part).trim(); }).map(function (part) { return String(part).trim(); });
      if (named.length >= 2) return named.slice(0, 3);
    }
    if (Array.isArray(value)) return value.map(function (part) { return String(part || "").trim(); }).filter(Boolean);
    var text = String(value || "").trim();
    if (!text) return [];
    var parts = text.split(/\s*(?:\/|-|>|,|，|、)\s*/).filter(Boolean);
    if (parts.length > 1) return parts;
    var match = text.match(/^(.+?(?:省|自治区|特别行政区|北京市|上海市|天津市|重庆市))(.+?(?:市|自治州|地区|盟))(.+?(?:区|县|旗|镇|乡|街道))$/);
    if (match) return match.slice(1).filter(Boolean);
    match = text.match(/^(.+?(?:省|自治区|特别行政区|北京市|上海市|天津市|重庆市))(.+?(?:市|自治州|地区|盟))$/);
    return match ? match.slice(1).filter(Boolean) : [text];
  }

  async function fillZhaopinPhoenixAdministrativeArea(dialog, parts, item, trigger) {
    for (var level = 0; level < parts.length; level++) {
      var wanted = normalizeZhaopinRegionName(parts[level]);
      var prefix = Array.from(wanted).slice(0, 2).join("");
      var option = await waitUntil(function () {
        var nodes = Array.from(dialog.querySelectorAll(".area-item-container")).filter(isVisible);
        return nodes.find(function (node) {
          var text = normalizeZhaopinRegionName((node.querySelector(".area-text-label") || node).textContent);
          if (!text) return false;
          if (level === parts.length - 1) return text.indexOf(prefix) === 0 || prefix.indexOf(text.slice(0, 2)) === 0;
          return text === wanted || text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1;
        }) || null;
      }, item.optionTimeoutMs || 2600);
      if (!option) return false;
      await safeClick(option);
      await sleep(item.waitAfterLevelMs || 220);
    }
    var confirm = findByText(dialog, item.confirmText || ["确定"], ".phoenix-button__content, button, [role='button']");
    if (confirm && !confirm.disabled && !/is-disabled/.test(String(confirm.className || ""))) await safeClick(confirm);
    var leaf = normalizeZhaopinRegionName(parts[parts.length - 1] || "");
    var prefix = Array.from(leaf).slice(0, 2).join("");
    return !!(await waitUntil(function () {
      if (!isVisible(dialog)) return true;
      var actual = normalizeZhaopinRegionName(trigger && (trigger.value || trigger.textContent || ""));
      return prefix && actual && (actual.indexOf(prefix) !== -1 || prefix.indexOf(actual.slice(0, 2)) === 0) ? true : null;
    }, item.commitTimeoutMs || 2600));
  }

  async function fillZhaopinAdministrativeArea(value, item, scope) {
    var parts = splitZhaopinAdministrativeParts(value);
    if (!parts.length) return false;
    if (parts.length === 3 && /^(北京市|上海市|天津市|重庆市)$/.test(parts[0]) && normalizeZhaopinRegionName(parts[1]) === "市辖区") {
      parts = ["热门", parts[0].replace(/市$/, ""), parts[2]];
    }
    var root = scope || document;
    var trigger = null;
    if (item._labelElement && item._labelElement.closest) {
      try {
        var labelledRow = item._labelElement.closest(".job-target-edit__item, .select-area, .el-form-item, li");
        trigger = labelledRow && (labelledRow.querySelector(".select-input, .el-cascader, input.el-input__inner[readonly], input[readonly]") || labelledRow.querySelector("input.el-input__inner"));
      } catch (eLabelledTrigger) {}
    }
    if (!trigger && item.triggerSelector) {
      try { trigger = Array.from(root.querySelectorAll(item.triggerSelector)).find(isVisible) || null; } catch (eSelector) {}
    }
    if (!trigger) return false;
    var leafText = normalizeZhaopinRegionName(parts[parts.length - 1]);
    if (leafText && normalizeZhaopinRegionName(trigger.textContent).indexOf(leafText) !== -1) return true;

    var dialog = await openZhaopinCascaderDialog(trigger, "请选择行政区", item.dialogTimeoutMs || 2600);
    if (!dialog) return false;
    if (dialog.querySelector(".area-selector-container")) {
      return await fillZhaopinPhoenixAdministrativeArea(dialog, parts, item, trigger);
    }
    var levelCount = Math.min(parts.length, 3);
    var selectedLevels = 0;
    var getLevelNodes = function (currentLevel) {
      var selectors = currentLevel === 0
        ? ".s-cascader__first-level .s-cascader__option, .s-cascader__first-level li, .s-cascader__second-level .s-cascader__option, .s-cascader__second-level .s-checkbutton__item"
        : currentLevel === 1
          ? ".s-cascader__second-level .s-cascader__option, .s-cascader__second-level li, .s-cascader__second-level .s-checkbutton__item, .s-cascader__third-level .s-checkbutton__item"
          : ".s-cascader__third-level .s-cascader__select-button-wrapper, .s-cascader__third-level .s-checkbutton__item, .s-cascader__third-level li.s-cascader__option";
      try { return Array.from(dialog.querySelectorAll(selectors)).filter(isVisible); } catch (eNodes) { return []; }
    };
    var findLevelOption = function (currentLevel, value) {
      var nodes = getLevelNodes(currentLevel);
      var wanted = normalizeZhaopinRegionName(value);
      if (currentLevel === 2) {
        var prefix = Array.from(wanted).slice(0, 2).join("");
        return nodes.find(function (node) {
          var text = normalizeZhaopinRegionName(node.textContent);
          return text && (text.indexOf(prefix) === 0 || prefix.indexOf(text.slice(0, 2)) === 0);
        }) || null;
      }
      return nodes.find(function (node) {
        var text = normalizeZhaopinRegionName(node.textContent);
        return text === wanted;
      }) || nodes.find(function (node) {
        var text = normalizeZhaopinRegionName(node.textContent);
        return text && (text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1);
      }) || null;
    };
    for (var level = 0; level < levelCount; level++) {
      var beforeNext = "";
      if (level < levelCount - 1) beforeNext = getLevelNodes(level + 1).map(function (node) { return normalizeText(node.textContent); }).join("|");
      var option = await waitUntil(function () {
        return findLevelOption(level, parts[level]);
      }, item.optionTimeoutMs || 2200);
      if (!option && level === 2) {
        try {
          var wantedLeaf = normalizeZhaopinRegionName(parts[level]);
          option = Array.from(dialog.querySelectorAll(".s-cascader__third-level li.s-checkbutton__item")).find(function (node) {
            return normalizeZhaopinRegionName(node.textContent) === wantedLeaf;
          }) || null;
        } catch (eExactLeaf) {}
      }
      if (!option && level === 2 && item.defaultFirstOnMissing) option = getLevelNodes(level)[0] || null;
      if (!option) break;
      // 联通级联的事件绑定在 li 内层的内容节点上；点击 li 本身在部分版本无效。
      var clickTarget = option.querySelector("p.s-cascader__option-content") || option.querySelector(".s-checkbutton__item") || option;
      await safeClick(clickTarget);
      if (level === 2) {
        await sleep(120);
        var selectedLeaf = option.classList && /--selected/.test(String(option.className || ""));
        if (!selectedLeaf) {
          var wrapper = option.closest && option.closest(".s-cascader__select-button-wrapper");
          if (wrapper) {
            await safeClick(wrapper);
            try { if (typeof wrapper.click === "function") wrapper.click(); } catch (eNativeLeafClick) {}
          }
          selectedLeaf = await waitUntil(function () { return option.classList && /--selected/.test(String(option.className || "")); }, 500);
          if (!selectedLeaf && item.defaultFirstOnMissing) {
            var firstLeaf = getLevelNodes(2).find(function (node) { return node !== option; }) || option;
            var firstWrapper = firstLeaf.closest && firstLeaf.closest(".s-cascader__select-button-wrapper") || firstLeaf;
            await safeClick(firstWrapper);
            try { if (typeof firstWrapper.click === "function") firstWrapper.click(); } catch (eNativeFirstLeafClick) {}
          }
        }
      }
      if (level < 2) {
        await sleep(120);
        var active = option.classList && /--active|--selected/.test(String(option.className || ""));
        if (!active) {
          var retry = await waitUntil(function () { return findLevelOption(level, parts[level]); }, 500);
          if (retry) await safeClick(level === 2 ? (retry.closest && retry.closest(".s-cascader__select-button-wrapper") || retry) : (retry.querySelector("p.s-cascader__option-content") || retry.querySelector(".s-checkbutton__item") || retry));
        }
      }
      selectedLevels += 1;
      // 一级/二级点击后列表会重绘，等待下一层出现后再继续。
      await sleep(item.waitAfterLevelMs || 260);
      if (level < levelCount - 1) {
        await waitUntil(function () {
          var nextNodes = getLevelNodes(level + 1);
          var afterNext = nextNodes.map(function (node) { return normalizeText(node.textContent); }).join("|");
          return nextNodes.length && afterNext !== beforeNext ? true : null;
        }, item.optionTimeoutMs || 2200);
      }
    }

    // 只有逐级点击未找到目标时，才使用城市搜索兜底；搜索结果仍按省-市-区路径筛选。
    if (selectedLevels < levelCount && isVisible(dialog)) {
      var citySearch = null;
      try { citySearch = Array.from(dialog.querySelectorAll("input[placeholder='搜索城市名/区县'], input.s-input__inner")).find(function (node) { return node && node.offsetParent !== null || node; }) || null; } catch (eCitySearch) {}
      if (citySearch && parts.length >= 2) {
        setElementTextInput(citySearch, "");
        setElementTextInput(citySearch, String(parts.length >= 3 ? parts[2] : parts[1]));
        await sleep(item.searchWaitMs || 450);
        var result = await waitUntil(function () {
          var nodes = Array.from(dialog.querySelectorAll(".s-options__content > li.s-option"));
          var leaf = normalizeZhaopinRegionName(parts[parts.length - 1]);
          var prefix = Array.from(leaf).slice(0, 2).join("");
          return nodes.find(function (node) {
            var text = normalizeText((node.querySelector(".s-option__label") || node).textContent);
            return text.indexOf(leaf) !== -1 || text.indexOf(prefix) !== -1;
          }) || null;
        }, item.optionTimeoutMs || 2600);
        if (result) {
          await safeClick(result.querySelector(".s-option__label") || result);
          return !!(await waitUntil(function () { return !isVisible(dialog) || normalizeZhaopinRegionName(trigger.value || trigger.textContent || "").indexOf(normalizeZhaopinRegionName(parts[1])) !== -1; }, item.commitTimeoutMs || 2600));
        }
      }
    }

    // 联通 s-cascader 选到末级后会自动提交并关闭弹窗，不存在“确定”按钮。
    if (!isVisible(dialog)) return true;
    var committedLeaf = normalizeZhaopinRegionName(trigger.value || trigger.textContent || "");
    if (leafText && committedLeaf && (committedLeaf.indexOf(leafText) !== -1 || leafText.indexOf(committedLeaf) !== -1)) return true;

    // 城市库的直辖市路径可能以“北京/朝阳区”而不是
    // “北京市/市辖区/朝阳区”呈现。逐级路径未走完时用叶子搜索兜底。
    if (item.allowRegionSearchFallback === true && selectedLevels < levelCount && isVisible(dialog)) {
      var search = null;
      try {
        search = Array.from(dialog.querySelectorAll("input[placeholder='搜索城市名'], input")).filter(isVisible)[0] || null;
      } catch (eSearch) {}
      if (search) {
        setElementTextInput(search, "");
        setElementTextInput(search, String(parts[parts.length - 1]));
        await sleep(item.searchWaitMs || 450);
        var searchResult = await waitUntil(function () {
          return findZhaopinAdministrativeOption(
            dialog,
            ".s-cascader__search-result li, .s-cascader__option, li, [class*='option']",
            parts[parts.length - 1]
          );
        }, item.optionTimeoutMs || 2200);
        if (searchResult) {
          await safeClick(searchResult);
          selectedLevels = parts.length;
          await sleep(item.waitAfterLevelMs || 180);
        }
      }
    }

    var confirm = findByText(dialog, item.confirmText || ["确定"], "button, [role='button']");
    if (!confirm || confirm.disabled || /is-disabled/.test(String(confirm.className || ""))) {
      var close = null;
      try { close = dialog.querySelector(".s-dialog__header .s-dialog__close, .s-dialog__icon.s-icon-guanbi, [class*='dialog__close'], [class*='dialog__icon']"); } catch (eClose) {}
      if (close) await safeClick(close);
      if (isVisible(dialog)) {
        await safeClick(trigger);
        if (isVisible(dialog)) {
          try {
            ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach(function (name) {
              var Ctor = /^pointer/.test(name) && typeof PointerEvent === "function" ? PointerEvent : MouseEvent;
              trigger.dispatchEvent(new Ctor(name, { bubbles: true, cancelable: true, composed: true, view: window, button: 0 }));
            });
          } catch (eToggle) {}
        }
      }
      if (isVisible(dialog)) {
        try {
          var esc = new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true, cancelable: true });
          dialog.dispatchEvent(esc); document.dispatchEvent(esc); window.dispatchEvent(esc);
        } catch (eEsc) {}
      }
      return !!(await waitUntil(function () {
        return !isVisible(dialog) || (leafText && normalizeZhaopinRegionName(trigger.value || trigger.textContent || "")).indexOf(leafText) !== -1;
      }, item.commitTimeoutMs || 2600));
    }
    await safeClick(confirm);
    return !!(await waitUntil(function () {
      var actual = normalizeZhaopinRegionName(trigger.textContent);
      return !isVisible(dialog) && (!leafText || actual.indexOf(leafText) !== -1) ? true : null;
    }, item.commitTimeoutMs || 2400));
  }

  function findZhaopinCascaderNode(dialog, selector, value) {
    var wanted = normalizeText(value);
    if (!wanted) return null;
    var nodes = [];
    try { nodes = Array.from(dialog.querySelectorAll(selector)).filter(isVisible); } catch (e) {}
    return nodes.find(function (node) { return normalizeText(node.textContent) === wanted; }) ||
      nodes.find(function (node) {
        var text = normalizeText(node.textContent);
        return text && (text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1);
      }) || null;
  }

  async function openZhaopinCascaderDialog(trigger, dialogLabel, timeoutMs) {
    function findDialog() {
      try {
        return Array.from(document.querySelectorAll(".s-dialog")).filter(isVisible).find(function (node) {
          return normalizeText(node.getAttribute("aria-label")) === normalizeText(dialogLabel);
        }) || null;
      } catch (e) { return null; }
    }
    await safeClick(trigger);
    var dialog = await waitUntil(findDialog, timeoutMs || 2600);
    if (dialog) return dialog;
    try {
      ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach(function (eventName) {
        var EventCtor = /^pointer/.test(eventName) && typeof PointerEvent === "function" ? PointerEvent : MouseEvent;
        trigger.dispatchEvent(new EventCtor(eventName, {
          bubbles: true,
          cancelable: true,
          composed: true,
          view: window,
          button: 0,
        }));
      });
      if (typeof trigger.click === "function") trigger.click();
    } catch (eRetry) {}
    return await waitUntil(findDialog, timeoutMs || 2600);
  }

  async function fillZhaopinTaxonomyCascader(value, item, scope, kind) {
    if (!hasMeaningfulValue(value)) return false;
    var trigger = null;
    try {
      trigger = Array.from((scope || document).querySelectorAll(item.triggerSelector || ".select-input")).find(isVisible) || null;
    } catch (eTrigger) {}
    if (!trigger) return false;

    if (kind === "position") {
      var jobTypeOk = await fillZhaopinJobTypeCascader(trigger, value, item);
      if (jobTypeOk || findVisibleZhaopinJobTypeModal()) return jobTypeOk;
    }

    var dialogLabel = kind === "industry" ? "请选择行业类别" : "请选择职位类别";
    var dialog = await openZhaopinCascaderDialog(trigger, dialogLabel, item.dialogTimeoutMs);
    if (!dialog) return false;

    var parts = String(value || "").split(/\s+\/\s+/).filter(Boolean);
    var expectedLength = kind === "industry" ? 2 : 3;
    var selected = false;
    if (parts.length === expectedLength) {
      var first = await waitUntil(function () {
        return findZhaopinCascaderNode(dialog, ".s-cascader__first-level .s-cascader__option", parts[0]);
      }, item.optionTimeoutMs || 2200);
      if (first) {
        await safeClick(first);
        await sleep(item.waitAfterLevelMs || 180);
        if (kind === "position") {
          var second = await waitUntil(function () {
            return findZhaopinCascaderNode(dialog, ".s-cascader__second-level .s-cascader__option", parts[1]);
          }, item.optionTimeoutMs || 2200);
          if (second) {
            await safeClick(second);
            await sleep(item.waitAfterLevelMs || 180);
          } else {
            first = null;
          }
        }
        if (first) {
          var leafValue = parts[parts.length - 1];
          var leaf = await waitUntil(function () {
            return findZhaopinCascaderNode(dialog, ".s-cascader__third-level .s-checkbutton__item", leafValue);
          }, item.optionTimeoutMs || 2600);
          if (leaf) {
            await safeClick(leaf);
            await sleep(item.waitAfterSelectMs || 240);
            selected = true;
          }
        }
      }
    }

    if (!selected && isVisible(dialog)) {
      var wanted = parts[parts.length - 1] || String(value);
      var search = null;
      try {
        search = Array.from(dialog.querySelectorAll("input")).filter(isVisible).find(function (input) {
          return /搜索行业类别或产品词|搜索职位类别/.test(String(input.placeholder || ""));
        }) || null;
      } catch (eSearch) {}
      if (search) {
        setElementTextInput(search, "");
        setElementTextInput(search, wanted);
        await sleep(item.searchWaitMs || 500);
        var result = await waitUntil(function () {
          return findZhaopinCascaderNode(dialog, ".s-cascader__third-level .s-checkbutton__item, .s-checkbutton__item, li, [class*='option']", wanted);
        }, item.optionTimeoutMs || 2600);
        if (result) {
          await safeClick(result);
          await sleep(item.waitAfterSelectMs || 240);
          selected = true;
        }
      }
    }

    if (!selected) {
      var close = null;
      try { close = dialog.querySelector(".s-dialog__icon.s-icon-guanbi, [class*='dialog__icon']"); } catch (eClose) {}
      if (close) await safeClick(close);
      return false;
    }
    var leafText = normalizeText(parts[parts.length - 1] || value);
    var committed = await waitUntil(function () {
      return !isVisible(dialog) || normalizeText(trigger.textContent).indexOf(leafText) !== -1 ? true : null;
    }, item.commitTimeoutMs || 2200);
    return !!committed;
  }

  function findVisibleZhaopinJobTypeModal() {
    try {
      return Array.from(document.querySelectorAll(".job-type__modal")).filter(isVisible).pop() || null;
    } catch (e) { return null; }
  }

  async function fillZhaopinJobTypeCascader(trigger, value, item) {
    var parts = String(value || "").split(/\s+\/\s+/).filter(Boolean);
    if (parts.length !== 3) return false;
    var modal = findVisibleZhaopinJobTypeModal();
    if (!modal) {
      await safeClick(trigger);
      modal = await waitUntil(findVisibleZhaopinJobTypeModal, item.dialogTimeoutMs || 2600);
    }
    if (!modal) return false;

    async function clickLevel(selector, text, nextSelector, nextText) {
      var node = await waitUntil(function () {
        return findZhaopinCascaderNode(modal, selector, text);
      }, item.optionTimeoutMs || 2200);
      if (!node) return false;
      await safeClick(node);
      await sleep(item.waitAfterLevelMs || 140);
      if (!nextSelector) return true;
      var next = findZhaopinCascaderNode(modal, nextSelector, nextText);
      if (next) return true;
      try { if (typeof node.click === "function") node.click(); } catch (eNative) {}
      return !!await waitUntil(function () {
        return findZhaopinCascaderNode(modal, nextSelector, nextText);
      }, item.optionTimeoutMs || 2200);
    }

    var firstOk = await clickLevel(
      ".level-one .job-type__level-item-name",
      parts[0],
      ".level-two .job-type__level-item-name",
      parts[1]
    );
    var secondOk = firstOk && await clickLevel(
      ".level-two .job-type__level-item-name",
      parts[1],
      ".job-type__last-level-item",
      parts[2]
    );
    var leaf = secondOk && await waitUntil(function () {
      return findZhaopinCascaderNode(modal, ".job-type__last-level-item", parts[2]);
    }, item.optionTimeoutMs || 2200);
    if (!leaf) {
      var close = null;
      try { close = modal.querySelector(".ivu-modal-close"); } catch (eClose) {}
      if (close) await safeClick(close);
      return false;
    }
    await safeClick(leaf);
    await sleep(item.waitAfterSelectMs || 220);
    var wanted = normalizeText(parts[2]);
    return !!await waitUntil(function () {
      return !isVisible(modal) || normalizeText(trigger.textContent).indexOf(wanted) !== -1 ? true : null;
    }, item.commitTimeoutMs || 2200);
  }



  async function fillZhaopinChoice(label, value, item, scope) {
    if (!hasMeaningfulValue(value)) return false;
    var choiceDiag = item && item.higherEducationField === true ? {
      fieldKey: String(item.field || ""), triggerFound: false, triggerTag: "", triggerClass: "",
      fieldItemResolved: false, fieldItemResolutionStrategy: "none", triggerStrategy: "",
      clickDispatched: false, popupDetected: false, popupStrategy: "", visibleOptionCount: 0,
      exactMatchFound: false, normalizedMatchFound: false, optionClicked: false, committed: false, reason: ""
    } : null;
    function saveChoiceDiag(reason) {
      if (!choiceDiag) return;
      choiceDiag.reason = reason || "";
      try {
        var rootTrace = JSON.parse(document.documentElement.getAttribute("data-af-zhaopin-higher-education-trace") || "{}");
        if (!Array.isArray(rootTrace.zhaopinChoiceTrace)) rootTrace.zhaopinChoiceTrace = [];
        rootTrace.zhaopinChoiceTrace.push(choiceDiag);
        document.documentElement.setAttribute("data-af-zhaopin-higher-education-trace", JSON.stringify(rootTrace));
      } catch (e) {}
    }
    var choiceValue = String(value).trim();
    if (/(?:大学英语|英语)?六级|CET\s*[- ]?6/i.test(choiceValue)) choiceValue = "CET6";
    else if (/(?:大学英语|英语)?四级|CET\s*[- ]?4/i.test(choiceValue)) choiceValue = "CET4";
    else if (/(?:英语专业|专业英语|专)?八级|TEM\s*[- ]?8/i.test(choiceValue)) choiceValue = "TEM8";
    else if (/(?:英语专业|专业英语|专)?四级|TEM\s*[- ]?4/i.test(choiceValue)) choiceValue = "TEM4";
    var root = scope || document;
    if (label && label.closest) {
      try { root = label.closest(".el-form-item, .edu-edit-form, .job-target-edit__item, li, .edit-panel-wrap-item") || root; }
      catch (eRoot) {}
    }
    var selectInput = null;
    if (item && item.higherEducationField === true) {
      var resolvedChoiceBinding = getHigherEducationRuntimeBinding(item && item.__recordIndex || 0, item && item.field);
      var choiceBinding = resolvedChoiceBinding && resolvedChoiceBinding.binding || resolveControlFromLabel(label, "choice", scope || root);
      selectInput = resolvedChoiceBinding && resolvedChoiceBinding.control || choiceBinding.element;
      if (choiceDiag) {
        choiceDiag.fieldItemResolved = !!choiceBinding.fieldItem;
        choiceDiag.fieldItemResolutionStrategy = choiceBinding.fieldItemStrategy;
        choiceDiag.triggerStrategy = selectInput ? "field_item_content_el_select" : "";
      }
    } else {
      try { selectInput = root.querySelector(".el-select input.el-input__inner, .el-select"); } catch (eSelect) {}
    }
    if (selectInput) {
      if (choiceDiag) {
        choiceDiag.triggerFound = true;
        choiceDiag.triggerTag = String(selectInput.tagName || "").toLowerCase();
        choiceDiag.triggerClass = String(selectInput.className || "");
      }
      if (item && item.useElementChoiceFirst === true) {
        var selectContainer = selectInput.closest && selectInput.closest(".el-select, .el-cascader") || selectInput;
        var elementChoiceOk = await fillScopedElementChoice(
          selectContainer,
          choiceValue,
          Object.assign({ strictCurrentControl: true }, item || {})
        );
        if (elementChoiceOk) return true;
      }
      var valueInput = selectInput.matches && selectInput.matches("input")
        ? selectInput
        : (selectInput.querySelector && selectInput.querySelector("input.el-input__inner, input"));
      var choiceContainer = selectInput.closest && selectInput.closest(".el-select, .el-cascader") || selectInput;
      var wanted = normalizeText(choiceValue);
      var choiceComparable = function (text) {
        var normalized = normalizeText(text);
        return item && item.acceptMunicipalitySuffix === true ? normalized.replace(/市$/, "") : normalized;
      };
      var currentValueMatches = function () {
        if (choiceComparable(valueInput && valueInput.value) === choiceComparable(wanted)) return true;
        // Element Plus 部分 Select 在候选提交后会清空内部 input.value，只在
        // selected-item 中保留显示文本。对明确要求的站点字段允许读取这一
        // 真实展示状态，避免“页面已选 IELTS、适配器却报失败”的 false negative。
        if (item && item.verifyDisplayedSelection === true && choiceContainer) {
          try { return elementChoiceValueMatches(choiceContainer, choiceValue); } catch (eDisplayedChoice) {}
        }
        return false;
      };
      if (item.verifySelection === true && currentValueMatches()) {
        if (item && item.higherEducationField === true) {
          try {
            var selectedTrace = JSON.parse(document.documentElement.getAttribute("data-af-zhaopin-higher-education-trace") || "{}");
            selectedTrace[item.field] = { label: String(item.label || ""), controlFound: true, currentSelected: true, candidateFound: null, executionPath: "already_selected", committed: true };
            document.documentElement.setAttribute("data-af-zhaopin-higher-education-trace", JSON.stringify(selectedTrace));
          } catch (eSelectedHigherTrace) {}
        }
        if (choiceDiag) { choiceDiag.committed = true; saveChoiceDiag(""); }
        return true;
      }
      var attempts = item.verifySelection === true ? Math.max(1, Number(item.retryCount) || 2) : 1;
      for (var attempt = 0; attempt < attempts; attempt++) {
        await safeClick(valueInput || selectInput);
        if (choiceDiag) choiceDiag.clickDispatched = true;
        var dropdownOption = await waitUntil(function () {
          var panels = [];
          try {
            panels = Array.from(document.querySelectorAll(".el-select-dropdown, .el-select__popper"))
              .filter(isVisible)
              .reverse();
          } catch (ePanels) {}
          for (var panelIndex = 0; panelIndex < panels.length; panelIndex++) {
            if (choiceDiag) {
              choiceDiag.popupDetected = true;
              choiceDiag.popupStrategy = "body_portal";
              var visibleOptions = Array.from(panels[panelIndex].querySelectorAll(".el-select-dropdown__item, [role='option']")).filter(isVisible);
              choiceDiag.visibleOptionCount = Math.max(choiceDiag.visibleOptionCount, visibleOptions.length);
              choiceDiag.exactMatchFound = choiceDiag.exactMatchFound || visibleOptions.some(function (node) { return normalizeText(node.textContent) === normalizeText(choiceValue); });
              choiceDiag.normalizedMatchFound = choiceDiag.normalizedMatchFound || visibleOptions.some(function (node) { var text = normalizeText(node.textContent); var target = normalizeText(choiceValue); return text === target || text.indexOf(target) !== -1 || target.indexOf(text) !== -1; });
            }
            var panelOption = findByText(panels[panelIndex], choiceValue, ".el-select-dropdown__item, [role='option']");
            if (panelOption) return panelOption;
          }
          return findByText(document, choiceValue, ".el-select-dropdown__item, [role='option']");
        }, item.optionTimeoutMs || 1800);
        if (item && item.higherEducationField === true) {
          try {
            var trace = JSON.parse(document.documentElement.getAttribute("data-af-zhaopin-higher-education-trace") || "{}");
            trace[item.field] = Object.assign({}, trace[item.field] || {}, {
              label: String(item.label || ""),
              controlFound: true,
              currentSelected: !!normalizeText(valueInput && valueInput.value),
              candidateFound: !!dropdownOption,
              executionPath: currentValueMatches() ? "already_selected" : "zhaopin_choice"
            });
            document.documentElement.setAttribute("data-af-zhaopin-higher-education-trace", JSON.stringify(trace));
          } catch (eHigherTrace) {}
        }
        if (!dropdownOption) break;
        await safeClick(dropdownOption);
        if (choiceDiag) choiceDiag.optionClicked = true;
        await sleep(item.waitAfterSelectMs || 120);
        if (item.verifySelection !== true) return true;
        var committed = await waitUntil(currentValueMatches, item.commitTimeoutMs || 1200);
        if (committed) {
          if (item && item.higherEducationField === true) {
            try {
              var committedTrace = JSON.parse(document.documentElement.getAttribute("data-af-zhaopin-higher-education-trace") || "{}");
              committedTrace[item.field] = Object.assign({}, committedTrace[item.field] || {}, { committed: true });
              document.documentElement.setAttribute("data-af-zhaopin-higher-education-trace", JSON.stringify(committedTrace));
            } catch (eCommittedHigherTrace) {}
          }
          if (choiceDiag) { choiceDiag.committed = true; saveChoiceDiag(""); }
          return true;
        }
        await sleep(item.retryDelayMs || 180);
      }
      if (item.verifySelection === true) { saveChoiceDiag(choiceDiag && choiceDiag.popupDetected ? "option_not_found_or_commit_failed" : "popup_not_detected"); return false; }
    }
    var option = findByText(root, choiceValue, item.optionSelector || ".zp-radio__item, .ivu-radio-wrapper, label, li");
    if (!option) option = findByText(scope || document, choiceValue, item.optionSelector || ".zp-radio__item, .ivu-radio-wrapper, label, li");
    if (!option) { saveChoiceDiag(selectInput ? "option_not_found" : "trigger_not_found"); return false; }
    await safeClick(option);
    await sleep(item.waitAfterSelectMs || 100);
    if (choiceDiag) { choiceDiag.optionClicked = true; choiceDiag.committed = true; saveChoiceDiag(""); }
    return true;
  }

  async function fillZhaopinPhone(label, value, item, scope) {
    var row = label && label.closest ? label.closest(".el-form-item") : null;
    if (!row) return false;
    var inputs = Array.from(row.querySelectorAll("input.el-input__inner"));
    var country = inputs.find(function (input) { return input.readOnly; });
    var phone = inputs.find(function (input) { return !input.readOnly; });
    if (country) {
      await safeClick(country);
      await sleep(120);
      var option = findByText(document, ["86", "+86"], ".el-select-dropdown__item, [role='option'], li");
      if (option) await safeClick(option);
    }
    if (!phone || !hasMeaningfulValue(value)) return false;
    return await AF.FormHandler.fillFormElement(phone, String(value), "text");
  }

  async function fillZhaopinCheckbox(label, value, item, scope) {
    var shouldCheck = /^(?:是|有|true|yes|y|1|勾选|实习)$/i.test(normalizeText(value));
    var root = scope || document;
    var checkbox = null;
    if (label && label.closest) {
      try {
        var row = label.closest(".job-target-edit__item, .edu-edit-form, .job-exp-edit-form, label") || root;
        checkbox = row.matches && row.matches("label.ivu-checkbox-wrapper") ? row : row.querySelector("label.ivu-checkbox-wrapper, input[type='checkbox']");
      } catch (eRow) {}
    }
    if (!checkbox && item.checkboxSelector) {
      try { checkbox = Array.from(root.querySelectorAll(item.checkboxSelector)).find(isVisible) || null; } catch (eSelector) {}
    }
    if (!checkbox) return false;
    var input = checkbox.matches && checkbox.matches("input[type='checkbox']") ? checkbox : checkbox.querySelector("input[type='checkbox']");
    var checked = input ? !!input.checked : /checked/.test(String(checkbox.className || ""));
    if (checked !== shouldCheck) await safeClick(checkbox);
    return !!(await waitUntil(function () {
      var liveRoot = scope && scope.isConnected !== false ? scope : document;
      var liveCheckbox = null;
      try {
        liveCheckbox = item.checkboxSelector
          ? liveRoot.querySelector(item.checkboxSelector)
          : liveRoot.querySelector("label.ivu-checkbox-wrapper input[type='checkbox']");
      } catch (eLiveCheckbox) {}
      if (!liveCheckbox && input && input.isConnected !== false) liveCheckbox = input;
      return liveCheckbox && !!liveCheckbox.checked === shouldCheck ? liveCheckbox : null;
    }, item.writebackTimeoutMs || 1200));
  }

  async function fillZhaopinSkillGroups(groups, item, scope) {
    if (!Array.isArray(groups) || !groups.some(function (group) { return group && Array.isArray(group.values) && group.values.length; })) return false;
    var root = scope || document;
    var trigger = null;
    try {
      trigger = Array.from(root.querySelectorAll(item.triggerSelector || ".job-exp-edit-item__skill-labels")).find(isVisible) || null;
    } catch (eTrigger) {}
    if (!trigger) return false;
    await safeClick(trigger);
    var dialog = await waitUntil(function () {
      try {
        return Array.from(document.querySelectorAll(item.dialogSelector || ".s-job-keyword-industry__dialog--theme-default, [role='dialog'][aria-label*='丰富专业技能']")).filter(isVisible).sort(function (a, b) {
          return elementStackScore(b) - elementStackScore(a);
        })[0] || null;
      } catch (eDialog) { return null; }
    }, item.dialogTimeoutMs || 3000);
    if (!dialog) return false;

    var desiredGroups = groups.filter(function (group) {
      return group && Array.isArray(group.values) && group.values.length;
    });
    var allOk = true;
    for (var gi = 0; gi < desiredGroups.length; gi++) {
      var desired = desiredGroups[gi];
      var title = normalizeText(desired.title);
      var groupContainers = [];
      try {
        groupContainers = Array.from(dialog.querySelectorAll(
          ".s-checkbutton-drilldown-multi-limit__list-item, .s-checkbutton-drilldown-multi-limit__add"
        )).filter(isVisible);
      } catch (eGroups) {}
      var groupRoot = groupContainers.find(function (node) {
        return title && normalizeText(node.textContent).indexOf(title) !== -1;
      }) || groupContainers[desiredGroups.indexOf(desired)] || dialog;

      if (item.replaceExisting === true) {
        var desiredValueMap = {};
        desired.values.forEach(function (value) { desiredValueMap[normalizeText(value)] = true; });
        var selectedExisting = [];
        try {
          selectedExisting = Array.from(groupRoot.querySelectorAll(
            ".s-checkbutton-drilldown-multi-limit__item--selected"
          )).filter(isVisible);
        } catch (eSelectedExisting) {}
        for (var existingIndex = 0; existingIndex < selectedExisting.length; existingIndex++) {
          var existingValue = normalizeText(selectedExisting[existingIndex].textContent);
          if (!desiredValueMap[existingValue]) {
            await safeClick(selectedExisting[existingIndex]);
            await sleep(item.waitAfterTagMs || 100);
          }
        }
      }

      for (var vi = 0; vi < desired.values.length; vi++) {
        var wanted = String(desired.values[vi] || "").trim();
        if (!wanted) continue;
        var option = null;
        try {
          option = Array.from(groupRoot.querySelectorAll(".s-checkbutton-drilldown-multi-limit__item")).filter(isVisible).find(function (node) {
            return normalizeText(node.textContent) === normalizeText(wanted);
          }) || null;
        } catch (eOption) {}
        if (option) {
          if (!/s-checkbutton-drilldown-multi-limit__item--selected/.test(String(option.className || ""))) {
            await safeClick(option);
            await sleep(item.waitAfterTagMs || 100);
          }
          continue;
        }

        var custom = null;
        try { custom = Array.from(groupRoot.querySelectorAll(".s-checkbutton-drilldown-multi-limit__item__add")).filter(isVisible)[0] || null; } catch (eCustom) {}
        if (!custom) { allOk = false; continue; }
        await safeClick(custom);
        var customInput = await waitUntil(function () {
          try { return Array.from(groupRoot.querySelectorAll("input.s-input__inner[placeholder='请输入']")).filter(isVisible)[0] || null; }
          catch (eInput) { return null; }
        }, item.customInputTimeoutMs || 1200);
        if (!customInput) { allOk = false; continue; }
        var setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
        if (setter && setter.set) setter.set.call(customInput, wanted); else customInput.value = wanted;
        customInput.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, data: wanted, inputType: "insertText" }));
        customInput.dispatchEvent(new Event("change", { bubbles: true }));
        var addButton = null;
        try { addButton = Array.from(groupRoot.querySelectorAll(".s-checkbutton-drilldown-multi-limit__add-button:not(.is-cancel)")).filter(isVisible)[0] || null; } catch (eAdd) {}
        if (!addButton) { allOk = false; continue; }
        await safeClick(addButton);
        await sleep(item.waitAfterTagMs || 120);
      }
    }

    var confirm = Array.from(dialog.querySelectorAll("button, [role='button'], .s-button")).filter(isVisible).find(function (node) {
      return /^确定(?:[·•]?\d+)?$/.test(normalizeText(node.textContent));
    });
    if (!confirm) return false;
    await safeClick(confirm);
    var closed = await waitUntil(function () { return !isVisible(dialog) ? true : null; }, item.commitTimeoutMs || 2500);
    if (!closed) return false;
    var triggerText = normalizeText(trigger.textContent);
    var selectedValues = desiredGroups.reduce(function (all, group) { return all.concat(group.values); }, []);
    return allOk && selectedValues.every(function (value) { return triggerText.indexOf(normalizeText(value)) !== -1; });
  }

  async function fillZhaopinEducationDate(value, item, scope) {
    if (!hasMeaningfulValue(value) || !item.inputSelector) return false;
    var root = scope || document;
    var input = null;
    try { input = Array.from(root.querySelectorAll(item.inputSelector)).find(isVisible) || null; } catch (eInput) {}
    if (!input) return false;
    var expected = normalizeYearMonthValue(value);
    if (!expected) return false;
    if (normalizeYearMonthValue(input.value) === expected) return true;
    var parsed = expected.match(/^(\d{4})-(\d{2})$/);
    if (!parsed) return false;
    var targetYear = Number(parsed[1]);
    var targetMonth = Number(parsed[2]);

    function findVisibleZhaopinMonthPanel() {
      try {
        // 智联的 iView MonthPicker 启用了 transfer，弹层被挂到 body，
        // 不在输入框自己的 .ivu-date-picker 容器中。
        return Array.from(document.querySelectorAll(
          ".ivu-select-dropdown.ivu-date-picker-transfer[data-transfer='true']"
        )).filter(isVisible).pop() || null;
      } catch (ePanel) { return null; }
    }

    function forceZhaopinPickerClick(element) {
      if (!element) return false;
      try { element.scrollIntoView && element.scrollIntoView({ block: "center", inline: "nearest" }); } catch (eScroll) {}
      try { element.focus && element.focus(); } catch (eFocus) {}
      ["pointerdown", "mousedown", "pointerup", "mouseup"].forEach(function (eventName) {
        try {
          var EventCtor = /^pointer/.test(eventName) && typeof PointerEvent === "function" ? PointerEvent : MouseEvent;
          element.dispatchEvent(new EventCtor(eventName, {
            bubbles: true,
            cancelable: true,
            composed: true,
            view: window,
            button: 0,
            buttons: /down$/.test(eventName) ? 1 : 0,
          }));
        } catch (eEvent) {
          dispatchMouseEventCompat(element, eventName);
        }
      });
      try {
        element.click && element.click();
        return true;
      } catch (eNativeClick) {
        return dispatchMouseEventCompat(element, "click");
      }
    }

    var panel = null;
    var pickerTrigger = input.closest && input.closest(".ivu-date-picker-rel, .ivu-date-picker-editor");
    for (var openAttempt = 0; openAttempt < 3 && !panel; openAttempt++) {
      var openTarget = openAttempt === 0 ? input : (pickerTrigger || input);
      try { openTarget.focus && openTarget.focus(); } catch (eFocusPicker) {}
      await safeClick(openTarget);
      panel = await waitUntil(findVisibleZhaopinMonthPanel, item.panelAttemptTimeoutMs || 800);
      if (!panel) {
        // safeClickElement 在个别 Vue 版本中会返回已点击，但组件
        // 未必真正打开。再向输入框补齐完整鼠标事件链。
        dispatchMouseEventCompat(input, "mousedown");
        dispatchMouseEventCompat(input, "mouseup");
        dispatchMouseEventCompat(input, "click");
        try { input.click && input.click(); } catch (eNativePickerClick) {}
        panel = await waitUntil(findVisibleZhaopinMonthPanel, item.panelRetryTimeoutMs || 700);
      }
    }
    if (!panel) return false;

    var reachedYear = false;
    for (var yearAttempt = 0; yearAttempt < 40; yearAttempt++) {
      var header = null;
      try {
        header = Array.from(panel.querySelectorAll(".ivu-date-picker-header-label")).find(isVisible) || null;
      } catch (eHeader) {}
      var headerMatch = String(header && header.textContent || "").match(/(\d{4})/);
      if (!headerMatch) return false;
      var currentYear = Number(headerMatch[1]);
      if (currentYear === targetYear) {
        reachedYear = true;
        break;
      }
      var directionSelector = currentYear < targetYear
        ? ".ivu-date-picker-next-btn-arrow-double"
        : ".ivu-date-picker-prev-btn-arrow-double";
      var yearButton = null;
      try { yearButton = Array.from(panel.querySelectorAll(directionSelector)).find(isVisible) || null; } catch (eYearButton) {}
      if (!yearButton) return false;
      var previousYear = currentYear;
      var yearChanged = null;
      for (var yearClickAttempt = 0; yearClickAttempt < 3 && !yearChanged; yearClickAttempt++) {
        await safeClick(yearButton);
        yearChanged = await waitUntil(function () {
          var liveHeader = null;
          try { liveHeader = Array.from(panel.querySelectorAll(".ivu-date-picker-header-label")).find(isVisible) || null; } catch (eLiveHeader) {}
          var liveMatch = String(liveHeader && liveHeader.textContent || "").match(/(\d{4})/);
          return liveMatch && Number(liveMatch[1]) !== previousYear ? liveHeader : null;
        }, item.yearChangeTimeoutMs || 700);
        if (!yearChanged) {
          try { yearButton = Array.from(panel.querySelectorAll(directionSelector)).find(isVisible) || yearButton; } catch (eRefreshYearButton) {}
          // DomUtils 在智联 iView 箭头上偶尔会返回 true，但年份完全没有变化。
          // 只有确认未变化后才补一次原生 click，避免正常点击时跨越两个年份。
          forceZhaopinPickerClick(yearButton);
          yearChanged = await waitUntil(function () {
            var forcedHeader = null;
            try { forcedHeader = Array.from(panel.querySelectorAll(".ivu-date-picker-header-label")).find(isVisible) || null; } catch (eForcedHeader) {}
            var forcedMatch = String(forcedHeader && forcedHeader.textContent || "").match(/(\d{4})/);
            return forcedMatch && Number(forcedMatch[1]) !== previousYear ? forcedHeader : null;
          }, item.forcedYearChangeTimeoutMs || 700);
        }
      }
      if (!yearChanged) return false;
    }
    if (!reachedYear) return false;

    var monthCell = null;
    try {
      monthCell = Array.from(panel.querySelectorAll(
        ".ivu-date-picker-cells-month .ivu-date-picker-cells-cell:not(.ivu-date-picker-cells-cell-disabled)"
      )).find(function (cell) {
        return Number(String(cell.textContent || "").match(/\d+/)?.[0]) === targetMonth;
      }) || null;
    } catch (eMonth) {}
    if (!monthCell) return false;
    for (var monthClickAttempt = 0; monthClickAttempt < 3; monthClickAttempt++) {
      await safeClick(monthCell);
      var committedMonth = await waitUntil(function () {
        var liveInput = null;
        try {
          var liveRoot = scope && scope.isConnected !== false ? scope : document;
          liveInput = Array.from(liveRoot.querySelectorAll(item.inputSelector)).find(isVisible) || null;
        } catch (eLiveInput) {}
        return liveInput && normalizeYearMonthValue(liveInput.value) === expected ? liveInput : null;
      }, item.writebackAttemptTimeoutMs || 900);
      if (committedMonth) return true;
      panel = findVisibleZhaopinMonthPanel();
      if (!panel) break;
      try {
        monthCell = Array.from(panel.querySelectorAll(
          ".ivu-date-picker-cells-month .ivu-date-picker-cells-cell:not(.ivu-date-picker-cells-cell-disabled)"
        )).find(function (cell) {
          var monthMatch = String(cell.textContent || "").match(/\d+/);
          return monthMatch && Number(monthMatch[0]) === targetMonth;
        }) || monthCell;
      } catch (eRefreshMonth) {}
      // 月份格也可能被通用点击误报成功；确认输入框尚未回写后再强制点击。
      forceZhaopinPickerClick(monthCell);
      committedMonth = await waitUntil(function () {
        var forcedInput = null;
        try {
          var forcedRoot = scope && scope.isConnected !== false ? scope : document;
          forcedInput = Array.from(forcedRoot.querySelectorAll(item.inputSelector)).find(isVisible) || null;
        } catch (eForcedInput) {}
        return forcedInput && normalizeYearMonthValue(forcedInput.value) === expected ? forcedInput : null;
      }, item.forcedWritebackTimeoutMs || 900);
      if (committedMonth) return true;
    }
    return false;
  }

  async function fillZhaopinWorkEndDate(label, value, item, scope) {
    if (!hasMeaningfulValue(value)) return false;
    if (isCurrentEndText(value)) return clickCurrentEndNearLabel(label, scope);
    return fillZhaopinEducationDate(value, item, scope);
  }

  async function fillZhaopinText(value, item, scope) {
    if (!hasMeaningfulValue(value) || !item.inputSelector) return false;
    var root = scope || document;
    var input = null;
    try { input = Array.from(root.querySelectorAll(item.inputSelector)).find(isVisible) || null; } catch (eInput) {}
    if (!input || !AF.FormHandler || typeof AF.FormHandler.fillFormElement !== "function") return false;
    var ok = await AF.FormHandler.fillFormElement(input, value, "text");
    if (!ok) return false;
    return !!(await waitUntil(function () {
      return normalizeText(input.value) === normalizeText(value) ? input : null;
    }, item.writebackTimeoutMs || 1200));
  }

  async function fillZhaopinEducationLevel(value, item, scope) {
    if (!hasMeaningfulValue(value)) return false;
    var root = scope || document;
    var select = null;
    try {
      select = Array.from(root.querySelectorAll(".ivu-select:not(.ivu-select-disabled)")).find(isVisible) || null;
    } catch (eSelect) {}
    if (!select) return false;

    var wanted = normalizeText(value);
    var current = select.querySelector(".ivu-select-selected-value, .ivu-select-placeholder");
    if (normalizeText(current && current.textContent) === wanted) return true;

    var trigger = select.querySelector(".ivu-select-selection, [role='combobox']") || select;
    await safeClick(trigger);
    var option = await waitUntil(function () {
      try {
        return Array.from(document.querySelectorAll(".ivu-select-dropdown .ivu-select-item"))
          .filter(isVisible)
          .find(function (node) { return normalizeText(node.textContent) === wanted; }) || null;
      } catch (eOption) {
        return null;
      }
    }, item.optionTimeoutMs || 3000);
    if (!option) return false;
    await safeClick(option);

    var committed = await waitUntil(function () {
      var liveSelect = null;
      try {
        liveSelect = Array.from((scope && scope.isConnected !== false ? scope : document)
          .querySelectorAll(".ivu-select:not(.ivu-select-disabled)")).find(isVisible) || null;
      } catch (eLive) {}
      var selected = liveSelect && liveSelect.querySelector(".ivu-select-selected-value");
      return normalizeText(selected && selected.textContent) === wanted ? liveSelect : null;
    }, item.writebackTimeoutMs || 2500);
    if (!committed) return false;
    return waitForFieldReadyAfterSelection(scope, item);
  }

  async function fillPinganDateText(label, value, item, scope) {
    if (!hasMeaningfulValue(value)) return false;
    // 开始时间和结束时间位于同一行，loose group 有时会扩到整张 form，随后
    // querySelector 取到第一个日期框，造成结束日期反写并覆盖开始日期。
    // 平安日期必须锁定当前 label 自己的 Element form-item。
    var group = label && label.closest && label.closest(".el-form-item") || closestLooseFormItem(label, scope);
    var input = null;
    var dateEditor = null;
    try {
      dateEditor = Array.from(group.querySelectorAll(".el-date-editor:not(.is-disabled)")).find(isVisible) || null;
      input = dateEditor && dateEditor.querySelector("input") || Array.from(group.querySelectorAll("input[placeholder*='日期'], input:not([type='hidden'])")).find(isVisible);
    } catch (e) {}
    if (!input) return false;
    var text = String(value).trim();
    if (/^至今$/.test(text)) return false;
    // 日期必须通过现有 DatePicker 引擎打开面板、定位年月日并点击；不再把
    // Element 日期输入框当普通文本写入，避免只改 DOM、没有更新 Vue model。
    if (dateEditor && AF.FormHandler && typeof AF.FormHandler.fillFormElement === "function") {
      try {
        if (await AF.FormHandler.fillFormElement(dateEditor, text, "date")) return true;
      } catch (eDateEngine) {}
    }
    var dateOk = false;
    try {
      await ensureElementInViewport(input);
      input.focus && input.focus();
      input.select && input.select();
      document.execCommand && document.execCommand("insertText", false, text);
      input.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: text, inputType: "insertText" }));
      input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true, composed: true }));
      input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, composed: true, key: "Enter", code: "Enter" }));
      input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, composed: true, key: "Enter", code: "Enter" }));
      input.blur && input.blur();
      await sleep(item && item.waitAfterInputMs == null ? 220 : item && item.waitAfterInputMs);
      if (String(input.value || "").trim() === text) return true;
    } catch (e00) {}
    try {
      dateOk = await AF.FormHandler.fillFormElement(input, text, "date");
    } catch (e0) {}
    if (!dateOk || String(input.value || "").trim() !== text) {
      setElementTextInput(input, text);
      try {
        input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, composed: true, key: "Enter", code: "Enter" }));
        input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, composed: true, key: "Enter", code: "Enter" }));
      } catch (e1) {}
    }
    try { input.blur && input.blur(); } catch (e2) {}
    await sleep(item && item.waitAfterInputMs == null ? 180 : item && item.waitAfterInputMs);
    return String(input.value || "").trim() === text || dateOk;
  }

  async function fillPinganCurrentEnd(label, value, item, scope) {
    // 同 fillPinganDateText：结束时间只能在当前字段容器内查找日期框/至今，
    // 不能回退到包含开始时间的整张经历表单。
    function currentEndRoot() {
      var currentGroup = label && label.closest && label.closest(".el-form-item") || closestLooseFormItem(label, scope);
      var currentCard = label && label.closest && label.closest(".work-module");
      var currentEditForm = label && label.closest && label.closest(".edit-mode, form.el-form, .el-form");
      return {
        group: currentGroup,
        roots: [currentGroup, currentGroup && currentGroup.parentElement, currentEditForm, currentCard]
          .filter(function (root, index, roots) { return root && roots.indexOf(root) === index; }),
      };
    }

    function findCurrentEndControl() {
      var context = currentEndRoot();
      var origin = (context.group || label).getBoundingClientRect();
      var matches = [];
      context.roots.forEach(function (root, rootIndex) {
        try {
          Array.from(root.querySelectorAll(
            ".el-checkbox, .ant-checkbox-wrapper, label, [role='checkbox'], input[type='checkbox']"
          )).forEach(function (node) {
            var wrapper = node.closest && node.closest(".el-checkbox, .ant-checkbox-wrapper, label, [role='checkbox']") || node;
            if (!isVisible(wrapper)) return;
            var checkbox = wrapper.matches && wrapper.matches("input[type='checkbox']")
              ? wrapper
              : wrapper.querySelector && wrapper.querySelector("input[type='checkbox']");
            var text = normalizeText(
              wrapper.textContent || node.textContent ||
              wrapper.getAttribute("aria-label") || wrapper.getAttribute("title") ||
              checkbox && (checkbox.getAttribute("aria-label") || checkbox.getAttribute("title"))
            );
            if (!/^至今$/.test(text)) return;
            var rect = wrapper.getBoundingClientRect();
            matches.push({
              wrapper: wrapper,
              checkbox: checkbox,
              // 优先结束时间同一 form-item，其次当前编辑表单；距离仅用于同层消歧。
              score: rootIndex * 1000 + Math.abs(rect.left - origin.left) + Math.abs(rect.top - origin.top),
            });
          });
        } catch (e) {}
      });
      matches.sort(function (a, b) { return a.score - b.score; });
      return matches[0] || null;
    }

    function currentEndIsChecked(control) {
      if (!control) return false;
      var checkbox = control.checkbox;
      var wrapper = control.wrapper;
      var stateNodes = [checkbox, wrapper];
      try {
        if (wrapper && wrapper.querySelectorAll) {
          stateNodes = stateNodes.concat(Array.from(wrapper.querySelectorAll(
            ".el-checkbox__input, .ant-checkbox, [role='checkbox']"
          )));
        }
      } catch (e) {}
      return stateNodes.filter(Boolean).some(function (node) {
        return node.checked === true ||
          node.getAttribute && node.getAttribute("aria-checked") === "true" ||
          /(^|\s)(is-checked|ant-checkbox-checked|checked|selected|active)(\s|$)/.test(String(node.className || ""));
      });
    }

    var context = currentEndRoot();
    var input = null;
    try {
      input = Array.from(context.group.querySelectorAll(
        ".el-date-editor input, input[placeholder*='日期'], input:not([type='hidden']):not([type='checkbox'])"
      )).find(isVisible);
    } catch (e) {}
    var currentControl = findCurrentEndControl();

    if (isCurrentEndText(value)) {
      // 二次编辑时旧记录可能已经是“至今”。已选中必须保持原状，不能再点一次反选。
      if (currentEndIsChecked(currentControl)) return true;
      if (!currentControl) return false;

      // 只有尚未勾选时才清空旧日期；Vue 重绘后重新获取控件，避免点击失效的旧节点。
      if (input && String(input.value || "").trim()) {
        setElementTextInput(input, "");
        try { input.blur && input.blur(); } catch (e0) {}
        await sleep(80);
        currentControl = findCurrentEndControl() || currentControl;
      }
      await safeClick(currentControl.wrapper);
      var checkedControl = await waitUntil(function () {
        var refreshed = findCurrentEndControl();
        return currentEndIsChecked(refreshed) ? refreshed : null;
      }, item && item.currentEndTimeoutMs || 1200);
      return !!checkedControl;
    }

    // 旧记录原来是“至今”、新数据改成具体日期时，先取消复选框再填写日期。
    if (currentEndIsChecked(currentControl)) {
      await safeClick(currentControl.wrapper);
      var unchecked = await waitUntil(function () {
        var refreshed = findCurrentEndControl();
        return !refreshed || !currentEndIsChecked(refreshed) ? true : null;
      }, item && item.currentEndTimeoutMs || 1200);
      if (!unchecked) return false;
      await sleep(80);
      var enabledDateInput = await waitUntil(function () {
        var refreshedContext = currentEndRoot();
        try {
          return Array.from(refreshedContext.group.querySelectorAll(
            ".el-date-editor:not(.is-disabled) input:not([disabled]), input[placeholder*='日期']:not([disabled])"
          )).find(isVisible) || null;
        } catch (eWaitEnabled) {
          return null;
        }
      }, item && item.currentEndTimeoutMs || 1200);
      if (!enabledDateInput) return false;
    }
    return fillPinganDateText(label, value, item, scope);
  }

  function normalizeYearMonthValue(value) {
    var match = String(value == null ? "" : value).trim().match(
      /^(\d{4})(?:-|\/|\.|\u5e74)(\d{1,2})(?:(?:-|\/|\.|\u6708)\d{1,2})?\u6708?$/
    );
    if (!match) return "";
    return match[1] + "-" + String(parseInt(match[2], 10)).padStart(2, "0");
  }

  // 只把真正“精确到月份”的值交给月份路径。YYYY-MM-DD 必须保留日精度，
  // 继续交给通用 DatePicker 点击具体日期，不能先截断成 YYYY-MM。
  function isYearMonthOnlyValue(value) {
    return /^(\d{4})(?:-|\/|\.|\u5e74)(\d{1,2})\u6708?$/.test(String(value == null ? "" : value).trim());
  }

  function readElementMonthStage(item) {
    try {
      var raw = document.documentElement.getAttribute("data-af-element-month-debug") || "{}";
      var state = JSON.parse(raw) || {};
      var key = String(item && item.field || item && item.label || "date");
      return String(state[key] || "");
    } catch (e) {
      return "";
    }
  }

  async function closeElementDatePanelWithoutSelection(input, panel) {
    // 关闭面板时绝不能点击 footer/link button。Element 的这类按钮在部分版本
    // 就是“今天”，此前的兜底正是因此把两个教育日期都写成当前日期。
    try {
      if (input && input.dispatchEvent) {
        input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, composed: true, key: "Escape", code: "Escape" }));
        input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, composed: true, key: "Escape", code: "Escape" }));
      }
    } catch (e0) {}
    try { input && input.blur && input.blur(); } catch (e1) {}
    await sleep(100);
    return !panel || !isVisible(panel);
  }

  function parseElementYearRange(text) {
    var matches = String(text || "").match(/\d{4}/g) || [];
    var years = matches.map(function (yearText) {
      return parseInt(yearText, 10);
    }).filter(function (year) {
      return !isNaN(year);
    });
    if (!years.length) return null;
    return { min: Math.min.apply(Math, years), max: Math.max.apply(Math, years) };
  }

  function findLinkedElementDatePanel(input) {
    var controlsId = input && input.getAttribute && input.getAttribute("aria-controls");
    if (controlsId) {
      var linked = document.getElementById(controlsId);
      if (linked && isVisible(linked)) return linked.querySelector(".el-date-picker") || linked;
    }
    var poppers = [];
    try {
      poppers = Array.from(document.querySelectorAll(".el-picker__popper")).filter(function (node) {
        return isVisible(node) && node.getAttribute("aria-hidden") !== "true";
      });
    } catch (e) {}
    if (poppers.length) {
      poppers.sort(function (a, b) {
        var za = parseInt(getComputedStyle(a).zIndex, 10) || 0;
        var zb = parseInt(getComputedStyle(b).zIndex, 10) || 0;
        return zb - za;
      });
      return poppers[0].querySelector(".el-date-picker") || poppers[0];
    }
    try {
      return Array.from(document.querySelectorAll(".el-date-picker")).find(isVisible) || null;
    } catch (e2) {
      return null;
    }
  }

  function isElementMonthDateControl(control) {
    var container = control && control.closest && control.closest(".el-date-editor") || control;
    return !!(container && container.classList && container.classList.contains("el-date-editor") && /month/.test(String(container.className || "")));
  }

  async function fillElementMonthInputDirect(control, value, item) {
    var yearMonth = normalizeYearMonthValue(value);
    if (!yearMonth || !isElementMonthDateControl(control)) return false;
    var container = control.closest && control.closest(".el-date-editor") || control;
    var input = container.querySelector && container.querySelector("input") || (control.matches && control.matches("input") ? control : null);
    if (!input || input.disabled || input.readOnly) return false;
    try { input.scrollIntoView && input.scrollIntoView({ block: "center", inline: "nearest" }); } catch (e0) {}
    try { input.focus && input.focus(); } catch (e1) {}

    var descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
    if (descriptor && descriptor.set) descriptor.set.call(input, "");
    else input.value = "";
    input.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: "", inputType: "deleteContentBackward" }));
    await sleep(item && item.waitAfterClearMs == null ? 60 : item && item.waitAfterClearMs);

    if (descriptor && descriptor.set) descriptor.set.call(input, yearMonth);
    else input.value = yearMonth;
    input.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: yearMonth, inputType: "insertText" }));
    input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true, composed: true }));
    input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, composed: true, key: "Enter", code: "Enter" }));
    input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, composed: true, key: "Enter", code: "Enter" }));
    try { input.blur && input.blur(); } catch (e2) {}
    input.dispatchEvent(new FocusEvent("blur", { bubbles: false, cancelable: false, composed: true }));
    await sleep(item && item.waitAfterInputMs == null ? 380 : item && item.waitAfterInputMs);

    var popperId = input.getAttribute("aria-controls") || container.getAttribute("aria-controls");
    var popper = popperId && document.getElementById(popperId);
    if (popper && isVisible(popper)) {
      try { document.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, composed: true, key: "Escape", code: "Escape" })); } catch (e3) {}
      await sleep(80);
    }
    return normalizeYearMonthValue(input.value) === yearMonth;
  }

  async function fillMonthRangeNearLabel(label, data, item, scope) {
    var startValue = data && item && item.startField ? data[item.startField] : "";
    var endValue = data && item && item.endField ? data[item.endField] : "";
    var startMonth = normalizeYearMonthValue(startValue);
    var endMonth = normalizeYearMonthValue(endValue);
    var root = label && label.closest && label.closest(item.formSelector || "form.el-form, form, .el-form") || scope || document;
    // 该站把起止时间放在同一个 .timeSelect 中。优先限制到这个组合容器，
    // 避免表单后续再增加其他日期控件时按全表单顺序拿错输入框。
    var rangeRoot = label && label.closest && label.closest(item.rangeSelector || ".timeSelect") || root;
    var editors = [];
    try {
      editors = Array.from(rangeRoot.querySelectorAll(".el-date-editor")).filter(isVisible);
    } catch (e) {}
    var offset = Number(item.dateStartIndex || 0);
    var startEditor = editors[offset];
    var endEditor = editors[offset + 1];
    // 51job 项目经历的视觉语义仍是“项目时间：开始 至 结束”，但 DOM
    // 会拆成两个相邻 .el-form-item：左侧 label=项目时间，右侧 label=结束时间。
    // 原逻辑只在同一个 .timeSelect / form-item 内找两个日期框，导致项目时间
    // 和结束时间都留空。这里只在缺少 endEditor 时做邻近兜底，不影响工作经历
    // 那种同容器已有两个日期框的稳定路径。
    if ((!startEditor || !endEditor) && item && item.endLabel && label) {
      var startItem = label.closest && label.closest(".el-form-item");
      var endLabelText = normalizeText(item.endLabel);
      var endItem = null;
      var siblings = [];
      try {
        siblings = Array.from((startItem && startItem.parentElement || root).querySelectorAll(".el-form-item")).filter(isVisible);
      } catch (eSiblingItems) {}
      var startIndex = startItem ? siblings.indexOf(startItem) : -1;
      for (var siblingIndex = Math.max(0, startIndex + 1); siblingIndex < siblings.length; siblingIndex++) {
        var siblingLabel = null;
        try { siblingLabel = siblings[siblingIndex].querySelector(".el-form-item__label, label"); } catch (eSiblingLabel) {}
        var siblingText = normalizeText(siblingLabel && siblingLabel.textContent);
        if (siblingText === endLabelText || siblingText.indexOf(endLabelText) !== -1) {
          endItem = siblings[siblingIndex];
          break;
        }
        // 只向后找近邻，避免跨到项目描述、下一块经历或其它模块。
        if (siblingIndex - startIndex > 3) break;
      }
      if (!startEditor && startItem) {
        try { startEditor = Array.from(startItem.querySelectorAll(".el-date-editor")).filter(isVisible)[offset || 0] || startEditor; } catch (eStartSibling) {}
      }
      if (!endEditor && endItem) {
        try { endEditor = Array.from(endItem.querySelectorAll(".el-date-editor")).filter(isVisible)[0] || endEditor; } catch (eEndSibling) {}
      }
    }
    var startOk = !startMonth;
    var endOk = !endMonth && !isCurrentEndText(endValue);
    if (startEditor && startMonth) startOk = await fillElementMonthPicker(startEditor, startMonth, item);
    if (endEditor && isCurrentEndText(endValue)) {
      endOk = await fillElementCurrentMonthShortcut(endEditor, item);
    } else if (endEditor && endMonth) {
      endOk = await fillElementMonthPicker(endEditor, endMonth, item);
    }
    return !!(startOk && endOk);
  }

  // 51Job 的新增工作/项目表单不是通用的“双日期同容器”结构：
  // 开始时间位于 .timeSelect 内，结束时间是其外部同级 .endTime。
  // 使用站点专用路径直接从当前可见编辑器取两个控件，避免标签范围、
  // 公司联想浮层和额外包装层影响日期定位。
  async function fillJob51MonthPicker(control, value, item) {
    var yearMonth = normalizeYearMonthValue(value);
    if (!control || !yearMonth) return false;
    var parsed = yearMonth.match(/^(\d{4})-(\d{2})$/);
    if (!parsed) return false;
    var targetYear = parseInt(parsed[1], 10);
    var targetMonth = parseInt(parsed[2], 10);
    var container = control.closest && control.closest(".el-date-editor") || control;
    var input = container.querySelector && container.querySelector("input") || null;
    if (!input) return false;
    if (normalizeYearMonthValue(input.value) === yearMonth) return true;

    function markJob51DateStage(stage, detail) {
      try {
        document.documentElement.setAttribute("data-af-job51-date-stage", String(stage || ""));
        document.documentElement.setAttribute("data-af-job51-date-detail", String(detail || ""));
      } catch (eMark) {}
    }
    async function clickJob51DateOnce(node) {
      if (!node) return false;
      await ensureElementInViewport(node);
      try { node.focus && node.focus({ preventScroll: true }); } catch (eFocus) {}
      try {
        if (typeof node.click === "function") node.click();
        else node.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, composed: true, view: window }));
      } catch (eClick) { return false; }
      await sleep(220);
      return true;
    }

    markJob51DateStage("open", yearMonth);
    // 已有旧值的 readonly 日期输入框仅调用 HTMLElement.click() 时，
    // 51Job 不会打开月份面板；输入框需要 focus + pointer/mouse 序列。
    // 年份箭头和月份格仍使用下方的单次原生点击，避免重复翻页。
    await clickElementDateNode(input);
    var panel = await waitUntil(function () { return findLinkedElementDatePanel(input); }, item.panelTimeoutMs || 2500);
    if (!panel) {
      markJob51DateStage("panel_not_open", yearMonth);
      return false;
    }
    var readPanelYear = function () {
      var header = Array.from(panel.querySelectorAll(".el-date-picker__header-label")).find(isVisible);
      return parseInt(String(header && header.textContent || "").replace(/\D/g, ""), 10);
    };
    var currentYear = readPanelYear();
    if (isNaN(currentYear)) {
      markJob51DateStage("year_unreadable", yearMonth);
      return false;
    }

    for (var yearStep = 0; currentYear !== targetYear && yearStep < 40; yearStep++) {
      var selector = targetYear < currentYear
        ? '.el-date-picker__prev-btn.el-icon-d-arrow-left, button.el-date-picker__prev-btn[aria-label="前一年"]'
        : '.el-date-picker__next-btn.el-icon-d-arrow-right, button.el-date-picker__next-btn[aria-label="后一年"]';
      var yearButton = Array.from(panel.querySelectorAll(selector)).find(isVisible);
      if (!yearButton) {
        markJob51DateStage("year_button_missing", currentYear + "->" + targetYear);
        return false;
      }
      var beforeYear = currentYear;
      markJob51DateStage("navigate_year", beforeYear + "->" + targetYear);
      await clickJob51DateOnce(yearButton);
      var changedYear = await waitUntil(function () {
        var nextYear = readPanelYear();
        return !isNaN(nextYear) && nextYear !== beforeYear ? nextYear : null;
      }, item.yearNavigationTimeoutMs || 1200);
      if (!changedYear) {
        markJob51DateStage("year_not_changed", beforeYear + "->" + targetYear);
        return false;
      }
      currentYear = changedYear;
    }
    if (currentYear !== targetYear) {
      markJob51DateStage("year_not_reached", currentYear + "->" + targetYear);
      return false;
    }

    var monthCell = await waitUntil(function () {
      return Array.from(panel.querySelectorAll(".el-month-table .cell")).filter(isVisible).find(function (cell) {
        var text = normalizeText(cell.textContent);
        return text === String(targetMonth) + "月" ||
          text === String(targetMonth).padStart(2, "0") + "月" ||
          text === String(targetMonth).padStart(2, "0");
      }) || null;
    }, item.monthTimeoutMs || 1800);
    if (!monthCell) {
      markJob51DateStage("month_missing", yearMonth);
      return false;
    }
    for (var monthAttempt = 0; monthAttempt < 3; monthAttempt++) {
      markJob51DateStage("select_month", yearMonth + "#" + (monthAttempt + 1));
      await clickJob51DateOnce(monthCell);
      var committed = await waitUntil(function () {
        return normalizeYearMonthValue(input.value) === yearMonth ? true : null;
      }, item.monthCommitTimeoutMs || 1000);
      if (committed) {
        markJob51DateStage("committed", yearMonth);
        return true;
      }
      if (!isVisible(panel)) break;
    }
    var finalOk = normalizeYearMonthValue(input.value) === yearMonth;
    markJob51DateStage(finalOk ? "committed" : "month_not_committed", yearMonth + "|" + String(input.value || ""));
    return finalOk;
  }

  async function fillJob51MonthRange(data, item, scope) {
    var root = scope || document;
    var editor = null;
    try {
      editor = Array.from(document.querySelectorAll(
        item.editorSelector || "#workExperience .editWorkExperience, #ProjectExperience .project_edit"
      )).find(isVisible) || null;
    } catch (eEditor) {}
    root = editor || root;
    var startEditor = null;
    var endEditor = null;
    try { startEditor = Array.from(root.querySelectorAll(item.startSelector || ".timeSelect .startTime .el-date-editor")).find(isVisible) || null; } catch (eStart) {}
    try { endEditor = Array.from(root.querySelectorAll(item.endSelector || ".endTime .el-date-editor")).find(isVisible) || null; } catch (eEnd) {}
    if (!startEditor || !endEditor) return false;

    var startValue = data && item.startField ? data[item.startField] : "";
    var endValue = data && item.endField ? data[item.endField] : "";
    var startMonth = normalizeYearMonthValue(startValue);
    var endMonth = normalizeYearMonthValue(endValue);
    if (!startMonth) return false;

    var startOk = await fillJob51MonthPicker(startEditor, startMonth, item);
    if (!startOk) {
      // 二次编辑时可能残留上一张卡片的月份。首次覆盖未提交时，重新取得
      // 当前编辑器和开始控件后再试一次，禁止把旧日期带到新公司。
      try {
        editor = Array.from(document.querySelectorAll(item.editorSelector)).find(isVisible) || editor;
        startEditor = editor && Array.from(editor.querySelectorAll(item.startSelector)).find(isVisible) || startEditor;
      } catch (eRetryStart) {}
      startOk = await fillJob51MonthPicker(startEditor, startMonth, item);
    }
    if (!startOk) return false;
    // 51Job 项目表单在开始月份提交后会触发 Vue 重绘，之前缓存的
    // .endTime 节点会脱离文档。工作表单通常不重绘，但统一在此重新
    // 获取当前可见编辑器和结束控件，保证两种表单都使用活节点。
    try {
      editor = Array.from(document.querySelectorAll(
        item.editorSelector || "#workExperience .editWorkExperience, #ProjectExperience .project_edit"
      )).find(isVisible) || editor;
    } catch (eRefreshEditor) {}
    root = editor || root;
    try {
      endEditor = Array.from(root.querySelectorAll(item.endSelector || ".endTime .el-date-editor")).find(isVisible) || null;
    } catch (eRefreshEnd) { endEditor = null; }
    if (!endEditor) return false;
    var endOk = false;
    if (isCurrentEndText(endValue)) endOk = await fillElementCurrentMonthShortcut(endEditor, item);
    else if (endMonth) endOk = await fillJob51MonthPicker(endEditor, endMonth, item);
    if (!endOk) {
      try {
        editor = Array.from(document.querySelectorAll(item.editorSelector)).find(isVisible) || editor;
        endEditor = editor && Array.from(editor.querySelectorAll(item.endSelector)).find(isVisible) || endEditor;
      } catch (eRetryEnd) {}
      if (isCurrentEndText(endValue)) endOk = await fillElementCurrentMonthShortcut(endEditor, item);
      else if (endMonth) endOk = await fillJob51MonthPicker(endEditor, endMonth, item);
    }
    if (!(startOk && endOk)) return false;

    // 保存前最后一次读取活节点。具体月份必须与当前行严格一致，不能仅凭
    // 控件“无报错”就接受上一张卡片留下的日期。
    try {
      editor = Array.from(document.querySelectorAll(item.editorSelector)).find(isVisible) || editor;
      var finalStartInput = editor && editor.querySelector(item.startSelector + " input");
      var finalEndInput = editor && editor.querySelector(item.endSelector + " input");
      if (!finalStartInput || normalizeYearMonthValue(finalStartInput.value) !== startMonth) return false;
      if (!isCurrentEndText(endValue) && (!finalEndInput || normalizeYearMonthValue(finalEndInput.value) !== endMonth)) return false;
    } catch (eFinalDateVerify) { return false; }
    return true;
  }

  async function fillElementCurrentMonthShortcut(control, item) {
    if (!control) return false;
    var container = control.closest && control.closest(".el-date-editor") || control;
    var input = container.querySelector && container.querySelector("input") || null;
    if (!input) return false;
    if (isCurrentEndText(input.value)) return true;

    await clickElementDateNode(input);
    var panel = await waitUntil(function () {
      return findLinkedElementDatePanel(input);
    }, item && item.panelTimeoutMs || 2500);
    if (!panel) return false;

    var shortcut = Array.from(panel.querySelectorAll(
      ".el-picker-panel__shortcut, .el-picker-panel__shortcut_footer button, button"
    )).filter(isVisible).find(function (node) {
      return isCurrentEndText(normalizeText(node.textContent));
    });
    if (!shortcut) return false;
    await clickElementDateNode(shortcut);
    await sleep(item && item.waitAfterSelectMs == null ? 360 : item && item.waitAfterSelectMs);

    // 站点可能把“至今”保存在 Vue 状态而不写入 input.value。除真实值外，
    // 也接受结束时间表单项已经通过校验且面板关闭的状态。
    if (isCurrentEndText(input.value)) return true;
    var formItem = container.closest && container.closest(".el-form-item");
    return !!(formItem && !formItem.classList.contains("is-error") && !isVisible(panel));
  }

  function markElementMonthStage(item, stage) {
    try {
      var raw = document.documentElement.getAttribute("data-af-element-month-debug") || "{}";
      var state = {};
      try { state = JSON.parse(raw) || {}; } catch (eParse) {}
      var key = String(item && item.field || item && item.label || "date");
      state[key] = String(stage || "");
      document.documentElement.setAttribute("data-af-element-month-debug", JSON.stringify(state));
    } catch (e) {}
  }

  async function fillElementMonthPicker(control, value, item) {
    var yearMonth = normalizeYearMonthValue(value);
    markElementMonthStage(item, "begin");
    if (!yearMonth || !control) { markElementMonthStage(item, "invalid_input"); return false; }
    if (await fillElementMonthInputDirect(control, value, item)) { markElementMonthStage(item, "direct_committed"); return true; }
    // Element Plus 的 month picker 在浙商家庭情况里会把 content-script 合成点击
    // 误处理成半截文本（例如只留下 "1972" 或 "9"）。月份框失败后必须停止，
    // 不能再回落到面板点击或通用日期器，否则会污染当前行并阻断保存。
    if (!item || item.allowElementMonthPanel !== true) { markElementMonthStage(item, "panel_fallback_disabled"); return false; }
    var parsed = yearMonth.match(/^(\d{4})-(\d{2})$/);
    if (!parsed) return false;
    var targetYear = parseInt(parsed[1], 10);
    var targetMonth = parseInt(parsed[2], 10);
    var container = control.closest && control.closest(".el-date-editor") || control;
    if (!container || !container.classList || !container.classList.contains("el-date-editor")) { markElementMonthStage(item, "not_element_date_editor"); return false; }
    if (!/month/.test(String(container.className || "")) && item.forceElementMonthPanel !== true) { markElementMonthStage(item, "not_month_control"); return false; }
    var input = container.querySelector && container.querySelector("input") || (control.matches && control.matches("input") ? control : null);
    if (!input) { markElementMonthStage(item, "input_missing"); return false; }
    if (normalizeYearMonthValue(input.value) === yearMonth) { markElementMonthStage(item, "already_committed"); return true; }

    try { input.scrollIntoView && input.scrollIntoView({ block: "center", inline: "nearest" }); } catch (e0) {}
    await clickElementDateNode(input);
    await sleep(item && item.waitAfterOpenMs == null ? 260 : item && item.waitAfterOpenMs);
    var panel = await waitUntil(function () {
      return findLinkedElementDatePanel(input);
    }, item && item.panelTimeoutMs || 2500);
    if (!panel) {
      await clickElementDateNode(container);
      await sleep(item && item.waitAfterOpenRetryMs == null ? 260 : item && item.waitAfterOpenRetryMs);
      panel = findLinkedElementDatePanel(input);
    }
    if (!panel) { markElementMonthStage(item, "panel_missing"); return false; }

    var yearHeader = Array.from(panel.querySelectorAll(".el-date-picker__header-label")).find(isVisible);
    var visibleYearCells = Array.from(panel.querySelectorAll(".el-year-table .cell")).filter(isVisible);
    var visibleMonthCells = Array.from(panel.querySelectorAll(".el-month-table .cell")).filter(isVisible);
    var visibleHeaderYear = parseInt(String(yearHeader && yearHeader.textContent || "").replace(/\D/g, ""), 10);
    // Element UI 的年/月/日三张 table 会同时常驻 DOM，仅用 display
    // 切换。不能用 querySelector 判断年份面板是否已打开，否则会
    // 直接点到隐藏的年份节点，Vue 不会收到有效选择。
    // 月份面板已经显示且年份正好匹配时，直接点月份，不再多走一次
    // “年份标题 -> 年份 -> 月份”。这正是该站打开月份框后的默认状态。
    var yearOk = visibleMonthCells.length > 0 && visibleHeaderYear === targetYear;
    if (!yearOk && yearHeader && !visibleYearCells.length) {
      // Element UI 的年份标题在表单动画、滚动或上一个弹窗
      // 刚关闭时，第一次合成 click 偶尔不会切换面板。不能点一次
      // 就盲目继续；必须看到年份表真正显示后才进入下一步。
      for (var openYearAttempt = 0; openYearAttempt < 3 && !visibleYearCells.length; openYearAttempt++) {
        yearHeader = Array.from(panel.querySelectorAll(".el-date-picker__header-label")).find(isVisible) || yearHeader;
        await clickElementDateNode(yearHeader);
        visibleYearCells = await waitUntil(function () {
          var cells = Array.from(panel.querySelectorAll(".el-year-table .cell")).filter(isVisible);
          return cells.length ? cells : null;
        }, item && item.yearPanelTimeoutMs || 650) || [];
      }
      if (!visibleYearCells.length) { markElementMonthStage(item, "year_panel_missing"); return false; }
    }

    for (var yearAttempt = 0; !yearOk && yearAttempt < 30; yearAttempt++) {
      var yearCells = Array.from(panel.querySelectorAll(".el-year-table .cell")).filter(isVisible);
      var targetYearCell = yearCells.find(function (cell) {
        return parseInt(String(cell.textContent || "").trim(), 10) === targetYear;
      });
      if (targetYearCell) {
        // 选中年份后应立即回到月份表。如果仍停在年份表，
        // 说明点击没有被 Vue 接收，重新获取节点后再试，不得
        // 把“已找到 DOM”误当成“已选中年份”。
        var monthPanelReady = null;
        for (var selectYearAttempt = 0; selectYearAttempt < 3 && !monthPanelReady; selectYearAttempt++) {
          var refreshedYearCells = Array.from(panel.querySelectorAll(".el-year-table .cell")).filter(isVisible);
          targetYearCell = refreshedYearCells.find(function (cell) {
            return parseInt(String(cell.textContent || "").trim(), 10) === targetYear;
          }) || targetYearCell;
          await clickElementDateNode(targetYearCell);
          monthPanelReady = await waitUntil(function () {
            var months = Array.from(panel.querySelectorAll(".el-month-table .cell")).filter(isVisible);
            var header = Array.from(panel.querySelectorAll(".el-date-picker__header-label")).find(isVisible);
            var headerYear = parseInt(String(header && header.textContent || "").replace(/\D/g, ""), 10);
            return months.length && headerYear === targetYear ? months : null;
          }, item && item.monthPanelTimeoutMs || 700);
        }
        if (monthPanelReady) {
          yearOk = true;
          break;
        }
        markElementMonthStage(item, "year_not_committed");
        return false;
      }
      var headerText = Array.from(panel.querySelectorAll(".el-date-picker__header-label")).filter(isVisible).map(function (node) {
        return node.textContent || "";
      }).join(" ");
      var range = parseElementYearRange(headerText) || parseElementYearRange(yearCells.map(function (cell) {
        return cell.textContent || "";
      }).join(" "));
      if (!range) { markElementMonthStage(item, "year_range_missing"); return false; }
      var buttonSelector = targetYear < range.min
        ? '.el-date-picker__prev-btn.el-icon-d-arrow-left, .el-date-picker__prev-btn.d-arrow-left, button.el-date-picker__prev-btn[aria-label="前一年"], .el-date-picker__prev-btn .d-arrow-left, .el-date-picker__prev-btn button[aria-label="前一年"]'
        : '.el-date-picker__next-btn.el-icon-d-arrow-right, .el-date-picker__next-btn.d-arrow-right, button.el-date-picker__next-btn[aria-label="后一年"], .el-date-picker__next-btn .d-arrow-right, .el-date-picker__next-btn button[aria-label="后一年"]';
      var pageButton = Array.from(panel.querySelectorAll(buttonSelector)).find(isVisible);
      if (!pageButton) { markElementMonthStage(item, "year_nav_button_missing"); return false; }
      await clickElementDateNode(pageButton);
      await sleep(140);
    }
    if (!yearOk) { markElementMonthStage(item, "year_not_reached"); return false; }

    var monthNames = ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"];
    var wantedMonthText = monthNames[targetMonth - 1];
    var monthCell = await waitUntil(function () {
      var cells = Array.from(panel.querySelectorAll(".el-month-table .cell")).filter(isVisible);
      return cells.find(function (cell) {
        var text = normalizeText(cell.textContent);
      return text === wantedMonthText ||
        text === String(targetMonth) + "月" ||
        text === String(targetMonth).padStart(2, "0") ||
        text === String(targetMonth).padStart(2, "0") + "月";
      }) || null;
    }, item && item.monthTimeoutMs || 1600);
    if (!monthCell) { markElementMonthStage(item, "month_missing"); return false; }
    // 月份节点也以 input 真实回填为成功标准。遇到第一次
    // click 被弹窗动画吞掉时，在面板仍显示的前提下重试。
    for (var selectMonthAttempt = 0; selectMonthAttempt < 3; selectMonthAttempt++) {
      monthCell = Array.from(panel.querySelectorAll(".el-month-table .cell")).filter(isVisible).find(function (cell) {
        var text = normalizeText(cell.textContent);
        return text === wantedMonthText ||
          text === String(targetMonth) + "月" ||
          text === String(targetMonth).padStart(2, "0") ||
          text === String(targetMonth).padStart(2, "0") + "月";
      }) || monthCell;
      await clickElementDateNode(monthCell);
      var committed = await waitUntil(function () {
        return normalizeYearMonthValue(input.value) === yearMonth ? true : null;
      }, item && item.monthCommitTimeoutMs || 800);
      if (committed) { markElementMonthStage(item, "panel_committed"); return true; }
      if (!isVisible(panel)) break;
    }
    // 如果点击月份后进入“日”面板，说明这是 full-date picker，而资料只有 YYYY-MM。
    // 此时网站要求一个具体日期；不能擅自补 1 日/末日，更不能点击“今天”兜底。
    // 安全做法是关闭面板并明确返回需要补充日精度。
    var visibleDayCells = [];
    try {
      visibleDayCells = Array.from(panel.querySelectorAll(
        ".el-date-table td.available:not(.prev-month):not(.next-month), .el-date-table td:not(.disabled):not(.prev-month):not(.next-month)"
      )).filter(isVisible);
    } catch (eDayCells) {}
    if (visibleDayCells.length) {
      await closeElementDatePanelWithoutSelection(input, panel);
      markElementMonthStage(item, "day_precision_required");
      return false;
    }

    // 对真正的 month picker，月份点击本身就必须完成回填。不要再点击任意 footer/link
    // 按钮作为兜底：不同 Element 版本里它可能表示“今天/此刻”，会污染用户资料。
    var finalCommitted = normalizeYearMonthValue(input.value) === yearMonth;
    markElementMonthStage(item, finalCommitted ? "panel_committed" : "month_not_committed");
    return finalCommitted;
  }

  function normalizeFullDateValue(value) {
    var match = String(value == null ? "" : value).trim().match(/^(\d{4})(?:-|\/|\.|年)(\d{1,2})(?:-|\/|\.|月)(\d{1,2})日?$/);
    if (!match) return "";
    return match[1] + "-" + String(parseInt(match[2], 10)).padStart(2, "0") + "-" + String(parseInt(match[3], 10)).padStart(2, "0");
  }

  async function fillZhaopinCampusDate(matcher, label, value, item, scope) {
    if (!hasMeaningfulValue(value)) return false;
    var dateItem = Object.assign({}, item || {}, { type: "elementDate" });
    var found = resolveSequenceControlByConfiguredType(matcher, label, dateItem, scope);
    if (!found || !found.element) return false;
    var control = found.element;
    var exactDate = normalizeFullDateValue(value);
    var monthValue = normalizeYearMonthValue(value);
    var monthControl = isElementMonthDateControl(control) || item && item.forceElementMonthPanel === true;
    var preContainer = control.closest && control.closest(".el-date-editor") || control;
    var preInput = preContainer && preContainer.querySelector && preContainer.querySelector("input") || (control.matches && control.matches("input") ? control : null);
    // 修复已有记录时，日期可能已经是正确值。readonly/受控日期 input 再次
    // 调用通用 FormHandler 可能返回 false，不能把“已经正确”误报成填写失败。
    if (preInput) {
      if (monthControl && monthValue && normalizeYearMonthValue(preInput.value) === monthValue) return true;
      if (!monthControl && exactDate && normalizeFullDateValue(preInput.value) === exactDate) return true;
    }
    var ok = false;
    if (monthControl) {
      if (!monthValue) return false;
      ok = await fillElementMonthPicker(control, monthValue, item);
    } else {
      // full-date picker 必须有真实日精度；只有 YYYY-MM 时明确停止，禁止补 1 日/末日。
      if (!exactDate) {
        markElementMonthStage(item, "day_precision_required");
        return false;
      }
      ok = await AF.FormHandler.fillFormElement(control, exactDate, "date");
    }
    if (!ok) return false;
    await sleep(item && item.persistVerifyMs == null ? 260 : item.persistVerifyMs);
    var container = control.closest && control.closest(".el-date-editor") || control;
    var input = container.querySelector && container.querySelector("input") || (control.matches && control.matches("input") ? control : null);
    if (!input) return ok;
    if (monthControl) return normalizeYearMonthValue(input.value) === monthValue;
    return normalizeFullDateValue(input.value) === exactDate;
  }

  function huaweiNamedControl(label, item, scope) {
    var name = String(item && item.controlName || "").trim();
    if (!name) return null;
    var form = label && label.closest && label.closest("form.layui-form");
    var root = form || scope || document;
    var selector = '[name="' + name.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"]';
    var controls = [];
    try { controls = Array.from(root.querySelectorAll(selector)); } catch (e) {}
    if (!controls.length && root !== document) {
      try { controls = Array.from(document.querySelectorAll(selector)).filter(isVisible); } catch (e2) {}
    }
    var nativeControl = controls.find(function (node) {
      return node.matches && node.matches("select, textarea, input:not(.layui-unselect)");
    }) || controls[0] || null;
    var formItem = nativeControl && nativeControl.closest && nativeControl.closest(".layui-form-item") ||
      label && label.closest && label.closest(".layui-form-item") || form;
    return { root: root, form: form, formItem: formItem, nativeControl: nativeControl, controls: controls };
  }

  function huaweiDisplayedSelect(containerInfo) {
    if (!containerInfo || !containerInfo.nativeControl) return null;
    var nativeSelect = containerInfo.nativeControl.matches && containerInfo.nativeControl.matches("select")
      ? containerInfo.nativeControl
      : null;
    var formItem = containerInfo.formItem;
    var generated = null;
    try {
      generated = nativeSelect && nativeSelect.nextElementSibling && nativeSelect.nextElementSibling.matches(".layui-form-select")
        ? nativeSelect.nextElementSibling
        : Array.from((formItem || containerInfo.root).querySelectorAll(".layui-form-select")).find(isVisible);
    } catch (e) {}
    return generated || nativeSelect;
  }

  function huaweiSelectCommitted(containerInfo, value) {
    if (!containerInfo) return false;
    var wanted = normalizeText(value);
    var nativeValue = String(containerInfo.nativeControl && containerInfo.nativeControl.value || "").trim();
    var shown = "";
    try {
      var generated = huaweiDisplayedSelect(containerInfo);
      var shownInput = generated && generated.querySelector && generated.querySelector(".layui-select-title input");
      shown = normalizeText(shownInput && shownInput.value);
    } catch (e) {}
    return !!(nativeValue && shown && (shown === wanted || shown.indexOf(wanted) !== -1 || wanted.indexOf(shown) !== -1));
  }

  async function fillHuaweiSearchSelect(label, value, item, scope) {
    if (!hasMeaningfulValue(value)) return false;
    var info = huaweiNamedControl(label, item, scope);
    var generated = huaweiDisplayedSelect(info);
    var input = generated && generated.querySelector && generated.querySelector(".layui-select-title input");
    if (!info || !generated || !input || input.readOnly || input.disabled) return false;
    var text = String(value).trim();
    if (huaweiSelectCommitted(info, text)) return true;
    await safeClick(input);
    await sleep(item.waitAfterOpenMs == null ? 160 : item.waitAfterOpenMs);
    await typeElementAutocompleteInput(input, text, {
      waitAfterClearMs: item.waitAfterClearMs == null ? 120 : item.waitAfterClearMs,
      typeIntervalMs: item.typeIntervalMs == null ? 45 : item.typeIntervalMs,
    });
    var option = await waitUntil(function () {
      var nodes = [];
      try { nodes = Array.from(generated.querySelectorAll("dl dd")); } catch (e) {}
      var candidates = nodes.filter(isVisible).filter(function (node) {
        return !node.classList.contains("layui-select-tips") && normalizeText(node.textContent);
      });
      var wanted = normalizeText(text);
      return candidates.find(function (node) { return normalizeText(node.textContent) === wanted; }) ||
        candidates.find(function (node) {
          var optionText = normalizeText(node.textContent);
          return optionText.indexOf(wanted) !== -1 || wanted.indexOf(optionText) !== -1;
        }) || (item.fallbackToFirstOption === true ? candidates[0] : null) || null;
    }, item.optionTimeoutMs || 4500);
    if (!option) return false;
    await safeClick(option);
    await sleep(item.waitAfterSelectMs == null ? 220 : item.waitAfterSelectMs);
    return huaweiSelectCommitted(info, text) || !!String(info.nativeControl && info.nativeControl.value || "").trim();
  }

  async function fillHuaweiField(label, value, item, scope) {
    var info = huaweiNamedControl(label, item, scope);
    if (!info || !info.nativeControl || !hasMeaningfulValue(value)) return false;
    if (item.preserveExisting === true) {
      if (item.type === "huaweiRadio" && info.controls.some(function (node) { return node.checked === true; })) return true;
      if (item.type === "huaweiSelect" || item.type === "huaweiSearchSelect") {
        if (String(info.nativeControl.value || "").trim()) return true;
      } else if (String(info.nativeControl.value || "").trim()) {
        return true;
      }
    }
    if (item.type === "huaweiSearchSelect") {
      return fillHuaweiSearchSelect(label, value, item, scope);
    }
    if (item.type === "huaweiSelect") {
      if (huaweiSelectCommitted(info, value)) return true;
      var selectContainer = huaweiDisplayedSelect(info);
      if (!selectContainer || !AF.SelectAdapter || typeof AF.SelectAdapter.create !== "function") return false;
      var selectOk = await AF.SelectAdapter.create(selectContainer, "string").selectValue(value);
      await sleep(item.waitAfterSelectMs == null ? 140 : item.waitAfterSelectMs);
      return !!selectOk && huaweiSelectCommitted(info, value);
    }
    if (item.type === "huaweiRadio") {
      var radios = info.controls.filter(function (node) { return node.type === "radio"; });
      return radios.length ? AF.FormHandler.fillFormElement(radios, value, "radio") : false;
    }
    if (item.type === "huaweiDate") {
      return AF.FormHandler.fillFormElement(info.nativeControl, value, "date");
    }
    return AF.FormHandler.fillFormElement(
      info.nativeControl,
      value,
      info.nativeControl.tagName === "TEXTAREA" ? "textarea" : "text"
    );
  }

  function setHuaweiInputValue(input, value) {
    if (!input) return;
    var text = String(value == null ? "" : value);
    var proto = input.tagName === "TEXTAREA" ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    var descriptor = Object.getOwnPropertyDescriptor(proto, "value");
    if (descriptor && descriptor.set) descriptor.set.call(input, text);
    else input.value = text;
    try {
      input.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        cancelable: true,
        composed: true,
        data: text,
        inputType: text ? "insertText" : "deleteContentBackward",
      }));
    } catch (eInput) {
      input.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
    }
    input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
  }

  async function clearHuaweiPage(scope) {
    if (!scope) return;
    var controls = [];
    try {
      controls = Array.from(scope.querySelectorAll("input, textarea, select"));
    } catch (e) {}
    controls.forEach(function (control) {
      if (!control || control.disabled) return;
      var type = String(control.type || "").toLowerCase();
      if (/^(hidden|file|button|submit|reset)$/.test(type)) return;
      if (control.matches && control.matches("input.layui-unselect")) return;
      if (type === "radio" || type === "checkbox") {
        control.checked = false;
        control.removeAttribute("checked");
        var choiceWrapper = control.nextElementSibling;
        if (choiceWrapper) {
          choiceWrapper.classList.remove("layui-form-radioed", "layui-form-checked");
        }
        control.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
        return;
      }
      if (control.tagName === "SELECT") {
        control.selectedIndex = 0;
        control.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
        control.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
        var generated = control.nextElementSibling;
        if (generated && generated.matches && generated.matches(".layui-form-select")) {
          var titleInput = generated.querySelector(".layui-select-title input");
          if (titleInput) setHuaweiInputValue(titleInput, "");
          Array.from(generated.querySelectorAll("dd")).forEach(function (option) {
            option.classList.toggle("layui-this", option.classList.contains("layui-select-tips"));
          });
        }
        return;
      }
      if (!control.readOnly) setHuaweiInputValue(control, "");
    });
    try {
      if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    } catch (eBlur) {}
    await sleep(180);
  }

  function huaweiRows(step, scope) {
    if (!step || !step.rowScopeSelector || !scope) return [];
    try { return Array.from(scope.querySelectorAll(step.rowScopeSelector)); } catch (e) { return []; }
  }

  async function trimHuaweiRepeatedRows(step, scope, wantedCount) {
    if (!step || step.replaceExistingRows !== true) return;
    var minimum = Math.max(0, Number(step.rowMinimumCount || 0));
    var targetCount = Math.max(minimum, Number(wantedCount || 0));
    for (var guard = 0; guard < 30; guard++) {
      var rows = huaweiRows(step, scope);
      if (rows.length <= targetCount) return;
      var row = rows[rows.length - 1];
      var deleteButton = null;
      try { deleteButton = row.querySelector(step.rowDeleteSelector || ".btn-delete"); } catch (eDeleteFind) {}
      if (!deleteButton || typeof deleteButton.click !== "function") {
        throw new Error("无法删除多余的华为历史记录：" + (step.name || step.category || "经历"));
      }
      var beforeCount = rows.length;
      deleteButton.click();
      await sleep(step.rowDeleteWaitMs == null ? 180 : step.rowDeleteWaitMs);
      var confirmButton = null;
      try {
        confirmButton = Array.from(document.querySelectorAll(
          ".layui-layer-dialog .layui-layer-btn0, .layui-layer-btn a, [role='dialog'] button"
        )).filter(isVisible).find(function (node) {
          return /^(确定|确认|是)$/.test(normalizeText(node.textContent));
        }) || null;
      } catch (eConfirm) {}
      if (confirmButton && typeof confirmButton.click === "function") {
        confirmButton.click();
        await sleep(180);
      }
      var removed = await waitUntil(function () {
        return huaweiRows(step, scope).length < beforeCount ? true : null;
      }, step.rowDeleteTimeoutMs || 1800);
      if (!removed) throw new Error("华为历史记录删除后数量没有减少：" + (step.name || step.category || "经历"));
    }
    throw new Error("华为历史记录数量异常，已停止继续删除");
  }

  async function selectWebFormsNative(select, value) {
    if (!select || !hasMeaningfulValue(value)) return false;
    var wanted = normalizeText(value).replace(/省|市$/g, "");
    var selectedText = normalizeText(
      select.options && select.selectedIndex >= 0 && select.options[select.selectedIndex]
        ? select.options[select.selectedIndex].textContent || select.value
        : select.value
    ).replace(/省|市$/g, "");
    // 条件下拉发生 WebForms 回传后，续填会再次执行当前步骤。目标值已经
    // 选中时直接视为成功，禁止重复触发 change 导致无限回传。
    if (selectedText && (selectedText === wanted || selectedText.indexOf(wanted) !== -1 || wanted.indexOf(selectedText) !== -1)) {
      return true;
    }
    if (AF.SelectAdapter && typeof AF.SelectAdapter.create === "function") {
      try {
        var adapter = AF.SelectAdapter.create(select, "string");
        if (adapter && await adapter.selectValue(value)) return true;
      } catch (eAdapter) {}
    }
    var option = Array.from(select.options || []).find(function (candidate) {
      var text = normalizeText(candidate.textContent || candidate.value).replace(/省|市$/g, "");
      return text && (text === wanted || text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1);
    });
    if (!option) return false;
    select.value = option.value;
    select.dispatchEvent(new Event("input", { bubbles: true }));
    select.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  async function fillWebFormsYearMonth(label, value) {
    var match = String(value || "").match(/(\d{4})\D*(\d{1,2})?/);
    var row = label && label.closest && label.closest("dl[dlcolname]");
    var selects = row ? Array.from(row.querySelectorAll("dd select")).filter(isVisible) : [];
    if (!match || selects.length < 2) return false;
    var yearOk = await selectWebFormsNative(selects[0], match[1]);
    await sleep(80);
    var monthOk = await selectWebFormsNative(selects[1], String(Number(match[2] || 1)).padStart(2, "0"));
    return !!(yearOk && monthOk);
  }

  async function fillWebFormsLinkedSelect(label, value, item) {
    var path = Array.isArray(value)
      ? value.filter(Boolean)
      : String(value || "").split(/\s*\/\s*|\s*>\s*/).filter(Boolean);
    var row = label && label.closest && label.closest("dl[dlcolname]");
    var selects = row ? Array.from(row.querySelectorAll("dd select")).filter(isVisible) : [];
    if (!path.length || selects.length < 2) return false;
    var firstOk = await selectWebFormsNative(selects[0], path[0]);
    if (!firstOk) return false;
    var secondReady = await waitUntil(function () {
      return selects[1] && Array.from(selects[1].options || []).some(function (option) {
        return normalizeText(option.textContent || option.value);
      }) ? selects[1] : null;
    }, item.optionTimeoutMs || 3500);
    if (!secondReady) return false;
    for (var i = 1; i < path.length; i++) {
      if (await selectWebFormsNative(secondReady, path[i])) return true;
    }
    return false;
  }

  async function fillWebFormsText(label, value, item) {
    if (!label || !hasMeaningfulValue(value)) return false;
    var row = label.closest && label.closest("dl[dlcolname]");
    if (!row) return false;
    var input = null;
    try {
      if (item && item.inputSelector) input = row.querySelector(item.inputSelector);
      if (!input) {
        input = Array.from(row.querySelectorAll(
          "dd input:not([type='hidden']):not([type='file']):not([disabled]):not([readonly]), dd textarea:not([disabled]):not([readonly])"
        )).filter(isVisible).pop() || null;
      }
    } catch (eFind) {}
    if (!input) return false;
    var textValue = String(value).trim();
    var inputCode = String(input.getAttribute("inputcolname") || "");
    if (inputCode === "MobilePhone") {
      var digits = textValue.replace(/\D/g, "");
      if (/^86\d{11}$/.test(digits)) digits = digits.slice(2);
      if (digits) textValue = digits;
    } else if (inputCode === "IDCard") {
      textValue = textValue.replace(/\s+/g, "");
    }
    return !!(await AF.FormHandler.fillFormElement(input, textValue, "text"));
  }

  async function fillWebFormsSelect(label, value, item) {
    if (!label || !hasMeaningfulValue(value)) return false;
    var row = label.closest && label.closest("dl[dlcolname]");
    if (!row) return false;
    var select = null;
    try {
      select = item && item.selectSelector ? row.querySelector(item.selectSelector) : row.querySelector("dd select");
    } catch (eFind) {}
    if (!select) return false;
    if (item && item.postbackAutoContinueWorkflowId) {
      try {
        window.sessionStorage.setItem("__afSpecialWorkflowAutoContinue", JSON.stringify({
          workflowId: item.postbackAutoContinueWorkflowId,
          hostname: window.location.hostname,
          startedAt: Date.now(),
        }));
      } catch (eContinueStore) {}
    }
    var selected = await selectWebFormsNative(select, value);
    if (!selected) return false;
    if (item && item.waitForSelectorAfterSelect) {
      var appeared = await waitUntil(function () {
        try {
          var node = document.querySelector(item.waitForSelectorAfterSelect);
          return node && isVisible(node) ? node : null;
        } catch (eWaitSelector) { return null; }
      }, item.optionTimeoutMs || 3500);
      if (!appeared) return false;
    } else {
      await sleep(item && item.waitAfterMs == null ? 100 : item.waitAfterMs);
    }
    return true;
  }

  function webFormsDateText(value) {
    if (/至今|目前|现在/.test(String(value || ""))) {
      var now = new Date();
      return now.getFullYear() + "-" + String(now.getMonth() + 1).padStart(2, "0") + "-" + String(now.getDate()).padStart(2, "0");
    }
    var match = String(value || "").match(/(\d{4})\D*(\d{1,2})?(?:\D*(\d{1,2}))?/);
    if (!match) return "";
    return match[1] + "-" + String(Number(match[2] || 1)).padStart(2, "0") + "-" +
      String(Number(match[3] || 1)).padStart(2, "0");
  }

  async function fillWebFormsDateText(label, value, item) {
    var text = webFormsDateText(value);
    var row = label && label.closest && label.closest("dl[dlcolname]");
    if (!row || !text) return false;
    var input = null;
    try {
      input = item && item.inputSelector ? row.querySelector(item.inputSelector) : row.querySelector("dd input[type='text']");
    } catch (eFind) {}
    if (!input) return false;
    var wasReadOnly = !!input.readOnly;
    if (wasReadOnly) input.readOnly = false;
    setElementTextInput(input, text);
    if (wasReadOnly) input.readOnly = true;
    await sleep(item && item.waitAfterMs == null ? 80 : item.waitAfterMs);
    return String(input.value || "").trim() === text;
  }

  function normalizeWebFormsDictionaryText(value) {
    return normalizeText(value).replace(/[()（）·•,，.。\-—_]/g, "").toLowerCase();
  }

  async function fillWebFormsDictionary(label, value, item) {
    if (!label || !hasMeaningfulValue(value)) return false;
    var row = label.closest && label.closest("dl[dlcolname]");
    if (!row) return false;
    var select = null;
    try {
      select = item && item.selectSelector ? row.querySelector(item.selectSelector) : row.querySelector("dd select[data-dict]");
    } catch (eFind) {}
    if (!select) return false;
    var wanted = normalizeWebFormsDictionaryText(value);
    var options = Array.from(select.options || []).filter(function (option) {
      return normalizeText(option.textContent || option.value);
    });
    var option = options.find(function (candidate) {
      return normalizeWebFormsDictionaryText(candidate.textContent || candidate.value) === wanted;
    }) || options.find(function (candidate) {
      var text = normalizeWebFormsDictionaryText(candidate.textContent || candidate.value);
      return text && wanted && (text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1);
    });
    var usedOther = false;
    if (!option) {
      option = options.find(function (candidate) {
        return /其他院校|其他学校|其他专业/.test(normalizeText(candidate.textContent || candidate.value));
      }) || null;
      usedOther = !!option;
    }
    if (!option) return false;
    select.value = option.value;
    select.dispatchEvent(new Event("input", { bubbles: true }));
    select.dispatchEvent(new Event("change", { bubbles: true }));
    var comboInput = row.querySelector(".custom-combobox-input");
    if (comboInput) setElementTextInput(comboInput, option.textContent || value);
    if (usedOther && item && item.otherInputSelector) {
      var otherInput = document.querySelector(item.otherInputSelector);
      if (otherInput) await AF.FormHandler.fillFormElement(otherInput, value, "text");
    }
    await sleep(item && item.waitAfterMs == null ? 100 : item.waitAfterMs);
    return select.value === option.value;
  }

  async function fillWebFormsCheckboxGroup(label, value, item) {
    if (!label) return false;
    var row = label.closest && label.closest("dl[dlcolname]");
    if (!row) return false;
    var wantedValues = Array.isArray(value) ? value.slice() : String(value || "").split(/[、,，;；/|]+/);
    wantedValues = wantedValues.map(function (entry) { return normalizeText(entry); }).filter(Boolean);
    if (!wantedValues.length && item && item.defaultValue) wantedValues = [normalizeText(item.defaultValue)];
    if (!wantedValues.length) return false;
    var checkboxes = [];
    try { checkboxes = Array.from(row.querySelectorAll("dd input[type='checkbox']")).filter(isVisible); } catch (e) {}
    if (!checkboxes.length) return false;
    var targets = checkboxes.filter(function (checkbox) {
      var text = normalizeText(checkbox.value || (checkbox.parentElement && checkbox.parentElement.textContent));
      return wantedValues.some(function (wanted) {
        return text === wanted || text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1;
      });
    });
    if (!targets.length && item && item.defaultValue) {
      var fallback = normalizeText(item.defaultValue);
      targets = checkboxes.filter(function (checkbox) {
        return normalizeText(checkbox.value || (checkbox.parentElement && checkbox.parentElement.textContent)) === fallback;
      });
    }
    if (!targets.length) return false;
    if (!item || item.clearExisting !== false) {
      checkboxes.forEach(function (checkbox) {
        if (checkbox.checked && targets.indexOf(checkbox) === -1 && typeof checkbox.click === "function") checkbox.click();
      });
    }
    targets.forEach(function (checkbox) {
      if (!checkbox.checked && typeof checkbox.click === "function") checkbox.click();
    });
    await sleep(item && item.waitAfterMs == null ? 100 : item.waitAfterMs);
    return targets.every(function (checkbox) { return checkbox.checked; });
  }

  // 中信银行的原生表单把字段标题放在 td 内的普通 div 中，而不是 label/dl。
  // 这些处理器只接受站点配置给出的 selector，并始终限制在当前 form 或重复行内。
  function citicFindControl(scope, selector) {
    if (!selector) return null;
    try { return (scope || document).querySelector(selector); } catch (e) { return null; }
  }

  async function fillCiticText(scope, value, item) {
    var input = citicFindControl(scope, item && item.selector);
    if (!input || !hasMeaningfulValue(value)) return false;
    return !!(await AF.FormHandler.fillFormElement(input, String(value).trim(), "text"));
  }

  async function fillCiticSelect(scope, value, item) {
    var select = citicFindControl(scope, item && item.selector);
    if (!select) return false;
    var requested = value;
    if (!hasMeaningfulValue(requested) && item && item.defaultFirst === true) {
      var firstUseful = Array.from(select.options || []).find(function (option) {
        return option && option.value && !/请选择|请选|--/.test(normalizeText(option.textContent || option.value));
      });
      requested = firstUseful && (firstUseful.textContent || firstUseful.value);
    }
    if (!hasMeaningfulValue(requested)) return false;
    var selected = item && item.forceNative === true
      ? false
      : await selectWebFormsNative(select, requested);
    var normalizedCiticChoice = function (choice) {
      var text = normalizeText(choice).replace(/省|市$/g, "");
      if (item && item.areaFuzzy === true) {
        text = text.replace(/特别行政区|维吾尔自治区|壮族自治区|回族自治区|自治区|省|市|区|县|旗$/g, "");
      }
      return text;
    };
    var matchesRequested = function () {
      var current = select.options && select.selectedIndex >= 0 ? select.options[select.selectedIndex] : null;
      var currentText = normalizedCiticChoice(current && (current.textContent || current.value));
      var wanted = normalizedCiticChoice(requested);
      return !!(currentText && wanted && (currentText === wanted || currentText.indexOf(wanted) !== -1 || wanted.indexOf(currentText) !== -1));
    };
    // selectpicker 的适配器有时会返回成功，却没有真正改变隐藏的原生 select。
    // 中信表单依赖这个原生值触发下一级级联，因此必须以原生选中结果作为准绳。
    if (!selected || !matchesRequested()) {
      var wanted = normalizedCiticChoice(requested);
      var option = Array.from(select.options || []).find(function (candidate) {
        var text = normalizedCiticChoice(candidate.textContent || candidate.value);
        return candidate.value && text && (text === wanted || text.indexOf(wanted) !== -1 || wanted.indexOf(text) !== -1);
      });
      if (!option) return false;
      select.value = option.value;
      try { select.dispatchEvent(new Event("input", { bubbles: true })); } catch (eInput) {}
      try { select.dispatchEvent(new Event("change", { bubbles: true })); } catch (eChange) {}
    }
    try {
      if (window.jQuery && window.jQuery.fn && typeof window.jQuery.fn.selectpicker === "function") {
        // 中信的地区控件由 bootstrap-select 接管。仅修改隐藏 select 并
        // dispatch change 不会稳定同步第三个区县框，必须走插件自身的 val API。
        if (item && item.bootstrapPickerCommit === true) {
          window.jQuery(select).selectpicker("val", select.value);
          window.jQuery(select).trigger("change");
        }
        window.jQuery(select).selectpicker("refresh");
      }
    } catch (eRefresh) {}
    await sleep(item && item.waitAfterMs == null ? 120 : item.waitAfterMs);
    return matchesRequested();
  }

  async function fillCiticSchoolSelect(scope, value, item) {
    var select = citicFindControl(scope, item && item.selector);
    if (!select || select.disabled || !hasMeaningfulValue(value)) return false;

    // 中信高等教育的学校库在下拉首次打开后才写入原生 select。未展开时
    // 只有“请选择”，直接按值匹配必然失败。
    var picker = select.closest && select.closest(".bootstrap-select");
    var trigger = picker && picker.querySelector("button.dropdown-toggle");
    if (trigger && isVisible(trigger)) {
      await safeClick(trigger);
      var loaded = await waitUntil(function () {
        return Array.from(select.options || []).some(function (option) {
          return option && option.value && !/请选择|请选/.test(normalizeText(option.textContent));
        }) ? true : null;
      }, item && item.optionLoadTimeoutMs || 3500);
      if (!loaded) return false;
    }
    return fillCiticSelect(scope, value, Object.assign({}, item, {
      bootstrapPickerCommit: true,
    }));
  }

  // 中信职业资格认证的固定类型不足以覆盖所有真实证书。没有精确类型时，
  // 只能选择页面的“其他”并保留用户的原始证书名称，不能猜成相近证书。
  async function fillCiticSelectWithOther(scope, value, item) {
    if (!hasMeaningfulValue(value)) return false;
    if (await fillCiticSelect(scope, value, item)) return true;
    if (!item || !item.otherSelector || !await fillCiticSelect(scope, item.otherOptionText || "其他", item)) return false;
    return fillCiticText(scope, value, { selector: item.otherSelector });
  }

  async function fillCiticDate(scope, value, item) {
    var input = citicFindControl(scope, item && item.selector);
    var text = webFormsDateText(value);
    if (!input || !text) return false;
    var wasReadOnly = !!input.readOnly;
    if (wasReadOnly) input.readOnly = false;
    setElementTextInput(input, text);
    if (wasReadOnly) input.readOnly = true;
    try { input.dispatchEvent(new Event("blur", { bubbles: true })); } catch (eBlur) {}
    await sleep(item && item.waitAfterMs == null ? 100 : item.waitAfterMs);
    return String(input.value || "").trim() === text;
  }

  async function fillCiticCurrentOrDate(scope, value, item) {
    if (!isCurrentEndText(value)) return fillCiticDate(scope, value, item);
    var currentButton = citicFindControl(scope, item && item.currentSelector);
    if (!currentButton) return false;
    await safeClick(currentButton);
    await sleep(item && item.waitAfterMs == null ? 120 : item.waitAfterMs);
    var input = citicFindControl(scope, item && item.selector);
    return !input || /至今|目前|现在/.test(String(input.value || ""));
  }

  async function fillCiticLinkedSelect(scope, value, item) {
    var path = Array.isArray(value) ? value.filter(Boolean) : String(value || "").split(/\s*\/\s*|\s*>\s*/).filter(Boolean);
    var selectors = item && (item.selectors || item.selector);
    selectors = Array.isArray(selectors) ? selectors : [selectors].filter(Boolean);
    if (!path.length || !selectors.length) return false;
    var levelCount = Math.min(path.length, selectors.length);
    for (var index = 0; index < levelCount; index++) {
      var select = citicFindControl(scope, selectors[index]);
      if (!select || !await fillCiticSelect(scope, path[index], { selector: selectors[index], forceNative: item && item.forceNative === true, bootstrapPickerCommit: item && item.bootstrapPickerCommit === true, areaFuzzy: item && item.areaFuzzy === true, waitAfterMs: item.waitAfterEachMs == null ? 180 : item.waitAfterEachMs })) return false;
      // 生源地、户口仅有两级，不应因简历地址含区县而等待并不存在的第三级控件。
      if (index < levelCount - 1) {
        var nextSelector = selectors[index + 1];
        var ready = await waitUntil(function () {
          var next = citicFindControl(scope, nextSelector);
          return next && Array.from(next.options || []).some(function (option) { return normalizeText(option.textContent) && !/请选择/.test(normalizeText(option.textContent)); }) ? next : null;
        }, item.optionTimeoutMs || 3500);
        if (!ready) return false;
      }
    }
    return true;
  }

  function configuredSequenceValue(data, item) {
    if (item && Array.isArray(item.valueFields)) {
      var values = item.valueFields.map(function (field) { return data && data[field]; }).filter(hasMeaningfulValue);
      if (item.type === "webformsLinkedSelect") return values;
      return values.join(item.valueSeparator || " / ");
    }
    return data && item && data[item.field];
  }

  async function fillChinahrIdNumber(label, value, item) {
    if (!hasMeaningfulValue(value)) return false;
    var row = label && label.closest && label.closest(".aply-field-li");
    if (!row) row = Array.from(document.querySelectorAll(".aply-field-li")).find(function (candidate) { var title = candidate.querySelector(".aply-field-label"); return /证件号码/.test(normalizeText(title && title.textContent)); });
    if (!row) return false;
    var typePicker = row.querySelector(item && item.typeSelector || ".antd-short.ant-cascader-picker");
    var numberInput = row.querySelector(item && item.controlSelector || "input.aply-field-input.short");
    if (!typePicker || !numberInput) return false;
    await clickCascaderElement(typePicker, true);
    var option = await waitUntil(function () {
      return Array.from(document.querySelectorAll(".ant-cascader-menu-item, .ant-cascader-menu li, .ant-cascader-menus li"))
        .filter(isVisible).find(function (node) { return normalizeText(node.textContent || node.title) === "身份证"; }) || null;
    }, item && item.optionTimeoutMs || 2500);
    if (!option) return false;
    await clickCascaderElement(option, true);
    await sleep(120);
    var typeText = normalizeText(row.querySelector(".ant-cascader-picker-label") && row.querySelector(".ant-cascader-picker-label").textContent);
    if (typeText && typeText.indexOf("身份证") === -1) return false;
    return !!(await AF.FormHandler.fillFormElement(numberInput, String(value).trim(), "text"));
  }

  function installSequenceSaveGuard(step) {
    var terminalField = step && step.blockSaveUntilField;
    if (!terminalField || typeof document === "undefined" || !document.addEventListener) return null;
    step.__afSequenceSaveGuardUnlocked = false;
    var expiresAt = Date.now() + Number(step.sequenceSaveGuardTimeoutMs || 45000);
    var removed = false;
    function cleanupIfExpired() {
      if (Date.now() <= expiresAt) return false;
      remove();
      return true;
    }
    function isSaveLikeAction(node) {
      if (!node) return false;
      var text = normalizeText(node.textContent || node.value || node.getAttribute && (node.getAttribute("aria-label") || node.getAttribute("title")) || "");
      return /^(?:保存|保存并更新|保存并跳转|添加|确认添加|提交)$/.test(text);
    }
    function shouldBlock(target) {
      if (step.__afSequenceSaveGuardUnlocked === true || cleanupIfExpired()) return false;
      var action = target && target.closest && target.closest("button, a, [role='button'], input[type='submit'], input[type='button']");
      return !!(action && isSaveLikeAction(action));
    }
    function blockEvent(event) {
      if (!shouldBlock(event && event.target)) return;
      try { event.preventDefault(); } catch (ePrevent) {}
      try { event.stopImmediatePropagation(); } catch (eStop) {}
      try { event.stopPropagation(); } catch (eStopPropagation) {}
    }
    function blockEnterSubmit(event) {
      if (!event || event.key !== "Enter" || step.__afSequenceSaveGuardUnlocked === true || cleanupIfExpired()) return;
      var target = event.target;
      if (!target || target.closest && target.closest("textarea")) return;
      if (target.closest && target.closest("form.scrd-web--form-edit, .apply-module__form")) blockEvent(event);
    }
    function remove() {
      if (removed) return;
      removed = true;
      try { document.removeEventListener("mousedown", blockEvent, true); } catch (eMouseDownRemove) {}
      try { document.removeEventListener("click", blockEvent, true); } catch (eClickRemove) {}
      try { document.removeEventListener("submit", blockEvent, true); } catch (eSubmitRemove) {}
      try { document.removeEventListener("keydown", blockEnterSubmit, true); } catch (eKeyRemove) {}
    }
    try { document.addEventListener("mousedown", blockEvent, true); } catch (eMouseDownAdd) {}
    try { document.addEventListener("click", blockEvent, true); } catch (eClickAdd) {}
    try { document.addEventListener("submit", blockEvent, true); } catch (eSubmitAdd) {}
    try { document.addEventListener("keydown", blockEnterSubmit, true); } catch (eKeyAdd) {}
    return remove;
  }

  // 国聘专用入口。未声明 iguopinField 的站点不会进入以下控件路径。
  function isIguopinResume() {
    return window.location.hostname === "c.iguopin.com" && /^\/resume\/?$/.test(window.location.pathname);
  }
  function iguopinVisible(root, selector) {
    return Array.from(root.querySelectorAll(selector)).filter(isVisible);
  }
  function iguopinText(node) { return normalizeText(node && (node.textContent || node.title) || ""); }
  function iguopinSetText(input, value) {
    var proto = input.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    var setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    input.focus();
    setter.call(input, String(value));
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function iguopinPath(value) {
    if (Array.isArray(value)) return value.map(String).map(function (part) { return part.trim(); }).filter(Boolean);
    if (value && typeof value === "object") return [value.province || value.provinceName, value.city || value.cityName, value.district || value.districtName].filter(Boolean);
    // 行业/职位名称本身包含斜线，因此不按单个斜线拆分自由文本。
    return String(value || "").split(/\s*(?:>|→|\|)\s*|\s+\/\s+/).filter(Boolean);
  }
  async function iguopinSelect(input, value, item, scope) {
    var select = input.closest(".ant-select");
    if (!select) return false;
    var wanted = normalizeText(value);
    var displayed = select.querySelector(".ant-select-selection-item");
    function selected() {
      if (item.proxyId) {
        var code = scope.querySelector('[id="' + item.proxyId + '"]');
        var name = scope.querySelector('[id="' + item.proxyName + '"]');
        return !!(code && code.value && name && normalizeText(name.value) === wanted);
      }
      var current = select.querySelector(".ant-select-selection-item");
      return current && iguopinText(current) === wanted;
    }
    if (displayed && selected()) return true;
    var trigger = select.querySelector(".ant-select-selector");
    trigger.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    if (item.kind === "remote" || select.classList.contains("ant-select-show-search")) iguopinSetText(input, value);
    var option = await waitUntil(function () {
      if (isStopRequested()) return null;
      // 通过 aria-controls 绑定正在搜索的列表，不读取已关闭的旧下拉。
      var id = input.getAttribute("aria-controls") || input.getAttribute("aria-owns");
      var list = id && document.getElementById(id);
      var dropdown = list && list.closest(".ant-select-dropdown");
      var panels = dropdown && isVisible(dropdown) ? [dropdown] : iguopinVisible(document, ".ant-select-dropdown");
      var matches = [];
      panels.forEach(function (panel) {
        matches = matches.concat(iguopinVisible(panel, ".ant-select-item-option").filter(function (node) {
          return !node.classList.contains("ant-select-item-option-disabled") && iguopinText(node) === wanted;
        }));
      });
      return matches.length === 1 ? matches[0] : null;
    }, item.optionTimeoutMs || 4500);
    if (!option) {
      input.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
      input.blur();
      return false;
    }
    await safeClick(option);
    return !!(await waitUntil(function () {
      return selected() && input.getAttribute("aria-expanded") !== "true";
    }, 1800));
  }
  async function iguopinPopup(input, value, item) {
    var path = iguopinPath(value);
    function choiceText(text) {
      text = normalizeText(text);
      return item.popupKind === "region" ? text.replace(/(?:壮族自治区|回族自治区|维吾尔自治区|自治区|特别行政区|省|市)$/, "") : text;
    }
    if (item.popupKind === "region" && typeof value === "string" && path.length === 1) {
      var parts = value.split(/[-/、]/).filter(Boolean);
      if (parts.length > 1) path = parts;
    }
    if (!path.length) return false;
    var select = input.closest(".ant-select") || input.parentElement;
    var selected = select.querySelector(".ant-select-selection-item");
    var expected = choiceText(path[path.length - 1]);
    if (selected && choiceText(iguopinText(selected).split(/[\/]/).pop()) === expected) return true;
    await safeClick(input);
    var modal = await waitUntil(function () {
      var modals = iguopinVisible(document, ".ant-modal");
      return modals.length === 1 ? modals[0] : null;
    }, 2000);
    if (!modal) return false;
    var ok = false;
    try {
      for (var i = 0; i < path.length; i++) {
        if (isStopRequested()) return false;
        var part = choiceText(path[i]);
        var candidates = iguopinVisible(modal, ".level-item, .leaf-item, .ant-tabs-tab").filter(function (node) { return choiceText(node.textContent) === part; });
        // 直辖市在省/市两层同名；进入省后只选下一层，不重复点击 active 父级。
        var children = candidates.filter(function (node) { return !node.classList.contains("active") && !node.classList.contains("ant-tabs-tab-active"); });
        if (children.length) candidates = children;
        else if (candidates.length === 1 && (candidates[0].classList.contains("active") || candidates[0].classList.contains("ant-tabs-tab-active"))) continue;
        if (!candidates.length && path.length === 1) {
          var search = iguopinVisible(modal, "input").find(function (node) { return !node.disabled && node.type !== "hidden"; });
          if (search) {
            iguopinSetText(search, path[i]);
            candidates = await waitUntil(function () {
              var matches = iguopinVisible(modal, ".leaf-item, .ant-select-item-option").filter(function (node) { return iguopinText(node) === part; });
              return matches.length ? matches : null;
            }, 3000) || [];
          }
        }
        // 不用第一个模糊项冒充成功；同名多路径要求简历给出明确路径。
        if (candidates.length !== 1) return false;
        await safeClick(candidates[0]);
        await sleep(180);
        if (!isVisible(modal)) {
          if (i !== path.length - 1) return false;
          break;
        }
      }
      if (isVisible(modal) && item.popupKind === "region") {
        var cityLeaves = iguopinVisible(modal, ".leaf-item").filter(function (node) { return choiceText(node.textContent) === expected; });
        if (cityLeaves.length === 1) { await safeClick(cityLeaves[0]); await sleep(180); }
      }
      if (isVisible(modal)) {
        var confirm = iguopinVisible(modal, "button.ant-btn-primary").find(function (node) { return iguopinText(node) === "确定"; });
        if (!confirm || confirm.disabled) return false;
        // 多选叶子点击后必须出现在已选区域，不能确认只有导航路径的状态。
        if (item.multi && !/已选[：:]?[1-3]\/3/.test(normalizeText(modal.innerText))) return false;
        await safeClick(confirm);
      }
      ok = !!(await waitUntil(function () {
        var display = select.querySelector(".ant-select-selection-item");
        return !isVisible(modal) && display && choiceText(display.textContent).indexOf(expected) !== -1;
      }, 1800));
      return ok;
    } finally {
      if (!ok && isVisible(modal)) {
        var close = modal.querySelector(".ant-modal-close");
        if (close) { await safeClick(close); await sleep(150); }
      }
    }
  }
  async function iguopinMonth(input, value, display) {
    display = display || input;
    var wanted = normalizeYearMonthValue(value);
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(wanted)) return false;
    if (normalizeYearMonthValue(display.value) === wanted) return true;
    input.focus(); input.dispatchEvent(new MouseEvent("mousedown", { bubbles: true })); input.click();
    var panel = await waitUntil(function () { return iguopinVisible(document, ".ant-picker-dropdown")[0] || null; }, 1800);
    if (!panel) return false;
    for (var attempt = 0; attempt < 120 && !isStopRequested(); attempt++) {
      var cells = iguopinVisible(panel, '.ant-picker-month-panel td[title="' + wanted + '"]:not(.ant-picker-cell-disabled)');
      if (cells.length) {
        await safeClick(cells[0]);
        return !!(await waitUntil(function () { return normalizeYearMonthValue(display.value) === wanted; }, 900));
      }
      var headers = iguopinVisible(panel, ".ant-picker-year-btn");
      var years = headers.map(function (node) { return parseInt(node.textContent, 10); }).filter(Number.isFinite);
      if (!years.length) return false;
      var targetYear = parseInt(wanted, 10);
      var backwards = targetYear < Math.min.apply(Math, years);
      var selector = backwards ? ".ant-picker-header-super-prev-btn" : ".ant-picker-header-super-next-btn";
      var arrows = iguopinVisible(panel, selector).filter(function (node) {
        return !node.disabled && getComputedStyle(node).visibility !== "hidden";
      });
      var arrow = backwards ? arrows[0] : arrows[arrows.length - 1];
      if (!arrow) return false;
      var before = years.join(",");
      await safeClick(arrow);
      if (!await waitUntil(function () {
        return iguopinVisible(panel, ".ant-picker-year-btn").map(function (node) { return parseInt(node.textContent, 10); }).join(",") !== before;
      }, 700)) return false;
    }
    return false;
  }
  async function fillIguopinField(scope, value, item) {
    if (!isIguopinResume() || !scope || !scope.closest || !scope.closest(".edit-section")) return { ok: false, reason: "国聘字段作用域不匹配" };
    var input = scope.querySelector(item.controlSelector);
    if (!input || !isVisible(input)) {
      // 高中联动等只跳过确实不存在的控件；可见必填仍报错。
      return { ok: false, skipped: item.optional === true, reason: "未找到当前模块可见控件" };
    }
    if (input.disabled) return { ok: true, skipped: true };
    if (!hasMeaningfulValue(value) || item.kind === "range" && (!value.startTime || !value.endTime)) {
      return { ok: false, skipped: item.optional === true, reason: "简历缺少此字段资料" };
    }
    if (isStopRequested()) return { ok: false, reason: "填写已停止" };
    var ok = false;
    if (item.kind === "text") {
      if (input.readOnly || input.type === "hidden") return { ok: false, reason: "控件不可直接输入" };
      iguopinSetText(input, value);
      input.blur();
      await sleep(120);
      ok = input.isConnected && String(input.value) === String(value);
    } else if (item.kind === "radio" || input.querySelector && input.querySelector("input[type='radio']")) {
      var group = input.matches("input") ? input.closest(".ant-form-item") : input;
      var radios = iguopinVisible(group, ".ant-radio-wrapper").filter(function (node) { return iguopinText(node) === normalizeText(value); });
      if (radios.length === 1) {
        var radio = radios[0].querySelector("input[type='radio']");
        if (radio && !radio.disabled) {
          if (!radio.checked) await safeClick(radios[0]);
          ok = !!(await waitUntil(function () { return radio.checked; }, 900));
        }
      }
    } else if (item.kind === "checkbox") {
      var checkbox = input.matches("input[type='checkbox']") ? input : input.querySelector("input[type='checkbox']");
      var yes = value === true || /^(是|有|true|1)$/.test(String(value));
      var no = value === false || /^(否|无|false|0)$/.test(String(value));
      if (checkbox && (yes || no) && !checkbox.disabled) {
        if (checkbox.checked !== yes) await safeClick(checkbox);
        ok = checkbox.checked === yes;
      }
    } else if (item.kind === "select" || item.kind === "remote") {
      ok = await iguopinSelect(input, value, item, scope);
    } else if (item.kind === "popup") {
      ok = await iguopinPopup(input, value, item);
    } else if (item.kind === "date" || item.kind === "currentDate" || item.kind === "range") {
      var display = item.displaySelector && scope.querySelector(item.displaySelector) || input;
      if (item.kind === "currentDate" && /^(至今|现在|目前|present|current)$/i.test(String(value))) {
        input.focus(); input.dispatchEvent(new MouseEvent("mousedown", { bubbles: true })); input.click();
        var current = await waitUntil(function () {
          var panels = iguopinVisible(document, ".ant-picker-dropdown");
          if (panels.length !== 1) return null;
          return iguopinVisible(panels[0], "button").find(function (node) { return iguopinText(node) === "至今"; });
        }, 1800);
        if (current) {
          await safeClick(current);
          ok = !!(await waitUntil(function () { return display.value === "至今"; }, 900));
        }
      } else {
        var dateValue = item.kind === "range" ? { startTime: normalizeYearMonthValue(value.startTime), endTime: normalizeYearMonthValue(value.endTime) }
          : item.precision === "day" ? String(value) : normalizeYearMonthValue(value);
        if (dateValue && (item.kind !== "range" || dateValue.startTime && dateValue.endTime)) {
          // 国聘月份面板没有月切换按钮，与日历面板分开处理。
          if (item.kind === "range") {
            var range = input.closest(".ant-picker-range");
            var inputs = range && range.querySelectorAll("input");
            ok = !!(inputs && inputs.length === 2 &&
              await iguopinMonth(inputs[0], dateValue.startTime) && await iguopinMonth(inputs[1], dateValue.endTime) &&
              normalizeYearMonthValue(inputs[0].value) === dateValue.startTime && normalizeYearMonthValue(inputs[1].value) === dateValue.endTime);
          } else {
            ok = item.precision === "day" ? await AF.FormHandler.fillFormElement(input, dateValue, "date") : await iguopinMonth(input, dateValue, display);
            ok = !!(ok && (item.precision === "day" ? display.value === dateValue : normalizeYearMonthValue(display.value) === dateValue));
          }
        }
      }
    } else if (item.kind === "tags") {
      var tags = Array.isArray(value) ? value : String(value).split(/[,，;；\n]/);
      ok = true;
      for (var i = 0; i < tags.length; i++) {
        var tag = String(tags[i]).trim();
        if (!tag) continue;
        if (isStopRequested()) return { ok: false, reason: "填写已停止" };
        if (iguopinVisible(scope, ".ant-tag").some(function (node) { return iguopinText(node) === normalizeText(tag); })) continue;
        iguopinSetText(input, tag);
        var add = iguopinVisible(scope, "button").find(function (node) { return iguopinText(node) === "添加关键词"; });
        if (!add || add.disabled) { ok = false; break; }
        await safeClick(add); await sleep(150);
        if (input.value || !iguopinVisible(scope, ".ant-tag").some(function (node) { return iguopinText(node) === normalizeText(tag); })) { ok = false; break; }
      }
    }
    return { ok: !!ok, reason: "未找到精确候选或控件未回写，请检查该字段" };
  }

  async function executeFieldSequence(engine, matcher, step, data, category, scope) {
    var labels = matcher.findLabelsByCard(scope || document) || matcher.findAllLabels() || [];
    var before = engine.formHandler.filledFieldsCount || 0;
    var failed = [];
    var recoveryStartIndex = Number(step && step.__afRecoveryFieldStartIndex);
    if (!Number.isInteger(recoveryStartIndex) || recoveryStartIndex < 0) recoveryStartIndex = 0;
    var sequenceCompletedActions = Array.isArray(step && step.__afRecoveryCompletedActions)
      ? step.__afRecoveryCompletedActions.slice(0, 200)
      : [];
    var sequenceActionCursor = null;
    var removeSequenceSaveGuard = installSequenceSaveGuard(step);
    if (step && step.higherEducationVariant === true) {
      var higherResolution = resolveHigherEducationEditorScope(step);
      var higherControls = higherResolution.scope ? enumerateInteractiveControls(higherResolution.scope).filter(function (entry) { return entry.visible; }) : [];
      writeHigherEducationTrace({
        scope: { resolved: !!higherResolution.scope, strategy: higherResolution.strategy || "", visibleLabelCount: higherResolution.scope ? higherEducationLabelNodes(higherResolution.scope).length : 0, controlCount: higherControls.length, reason: higherResolution.scope ? "" : (higherResolution.reason || "higher_education_scope_not_resolved") },
        currentVisibleEditorMode: true
      });
    }

    for (var i = 0; i < step.fieldSequence.length; i++) {
      var item = step.fieldSequence[i];
      if (i < recoveryStartIndex) continue;
      var failedCountBeforeAction = failed.length;
      var currentSequenceActionId = specialSequenceActionId(item, i);
      if (/^applyjob\.chinahr\.com$/i.test(window.location.hostname) && /辅修专业|辅修情况/.test(String(item && item.label || ""))) continue;
      scope = refreshSequenceScope(step, scope);
      if (step && step.higherEducationNavigationAdapter === true) {
        scope = resolveLiveHigherEducationFormScope(scope) || scope;
      }
      // 站点可声明字段在本轮完全跳过：不定位、不点击、不打开弹窗。
      if (item.skip === true) continue;
      if (typeof item.when === "function") {
        var shouldRunItem = true;
        try {
          shouldRunItem = item.when(data, category, step, scope) !== false;
        } catch (eWhen) {
          shouldRunItem = false;
        }
        if (!shouldRunItem) {
          await sleep(item.waitAfterMs == null ? 80 : item.waitAfterMs);
          continue;
        }
      }
      if (/^job\.spdb\.com\.cn$/i.test(window.location.hostname) && /基本信息/.test(String(step.name || ""))) {
        var spdbExistingLabel = findLabelForSequence(labels, item.label);
        var spdbExisting = spdbExistingLabel && resolveSequenceControlByConfiguredType(matcher, spdbExistingLabel, item);
        var spdbExistingInput = spdbExisting && spdbExisting.element && (spdbExisting.element.matches("input, textarea, select") ? spdbExisting.element : spdbExisting.element.querySelector && spdbExisting.element.querySelector("input, textarea, select"));
        var spdbExpected = data && data[item.field];
        var spdbExpectedText = Array.isArray(spdbExpected) ? spdbExpected.join("") : (spdbExpected && typeof spdbExpected === "object" ? [spdbExpected.province, spdbExpected.city, spdbExpected.district, spdbExpected.provinceName, spdbExpected.cityName, spdbExpected.districtName].filter(Boolean).join("") : String(spdbExpected || ""));
        var spdbCurrentText = String(spdbExistingInput && spdbExistingInput.value || "");
        var spdbCityPrefixAccepted = item.type === "spdbCityPicker" && spdbCurrentText && spdbExpectedText && normalizeChoiceText(spdbExpectedText).indexOf(normalizeChoiceText(spdbCurrentText)) === 0;
        if (spdbExistingInput && hasMeaningfulValue(spdbExpected) && (normalizeChoiceText(spdbCurrentText) === normalizeChoiceText(spdbExpectedText) || spdbCityPrefixAccepted)) {
          engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
          continue;
        }
      }
      // 浦发联系地址的“家庭住址”仅由 disabled input 标识，没有 label 节点；
      // 必须在通用标签匹配前直接调用专用填写器。
      if (item.type === "iguopinField") {
        var iguopinResult = await fillIguopinField(scope, configuredSequenceValue(data, item), item);
        if (iguopinResult.ok && !iguopinResult.skipped) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (!iguopinResult.skipped && !iguopinResult.ok) failed.push({ fieldKey: item.field, label: item.label, reason: iguopinResult.reason });
        if (isStopRequested()) break;
        await sleep(100);
        continue;
      }
      if (item.type === "spdbFamilyAddress") {
        var directSpdbAddress = data && data[item.field];
        if (!hasMeaningfulValue(directSpdbAddress)) {
          var spdbSource = data && data.basicInfo && typeof data.basicInfo === "object" ? data.basicInfo : (data || {});
          var spdbPath = Array.isArray(spdbSource.currentAddressPath) ? spdbSource.currentAddressPath.join("") : String(spdbSource.currentAddressPath || "").replace(/\s*\/\s*/g, "");
          directSpdbAddress = { text: spdbPath || spdbSource.currentAddress || spdbSource.familyAddress || "", detail: spdbSource.currentAddressDetail || spdbSource.familyAddressDetail || spdbSource.currentAddress || spdbSource.familyAddress || "", postal: spdbSource.postalCode || spdbSource.zipCode || "" };
        }
        var directSpdbAddressOk = hasMeaningfulValue(directSpdbAddress) && await fillSpdbFamilyAddress(directSpdbAddress, item);
        if (directSpdbAddressOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "浦发家庭住址填写失败" });
        await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
        continue;
      }
      if (item.type === "chinahrIdNumber") {
        var chinaHrIdValue = data && data[item.field];
        var chinaHrIdItem = label && label.closest && label.closest(".aply-field-li");
        var chinaHrIdOk = false;
        if (chinaHrIdItem && hasMeaningfulValue(chinaHrIdValue)) {
          var chinaHrIdPicker = Array.from(chinaHrIdItem.querySelectorAll(".ant-cascader-picker, .ant-select.ant-cascader, [role='combobox']")).find(isVisible);
          if (chinaHrIdPicker) await fillDependentCascader(label, ["身份证"], { bridgeTimeoutMs: 2500 });
          var chinaHrIdInput = Array.from(chinaHrIdItem.querySelectorAll("input[type='text']")).filter(function (node) {
            return isVisible(node) && !node.classList.contains("ant-cascader-input");
          }).pop();
          if (chinaHrIdInput) {
            chinaHrIdOk = await AF.FormHandler.fillFormElement(chinaHrIdInput, chinaHrIdValue, "text");
            if (!chinaHrIdOk || String(chinaHrIdInput.value || "").trim() !== String(chinaHrIdValue).trim()) {
              setElementTextInput(chinaHrIdInput, chinaHrIdValue);
              chinaHrIdOk = String(chinaHrIdInput.value || "").trim() === String(chinaHrIdValue).trim();
            }
          }
        }
        if (chinaHrIdOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "中国银行证件类型/号码填写失败" });
        continue;
      }
      if (item.type === "spdbSchoolPicker" && !/^高中/.test(String(data && (data.level || data.educationLevel || "")))) {
        var spdbSchoolValue = data && data[item.field];
        var spdbSchoolOk = hasMeaningfulValue(spdbSchoolValue) && await fillSpdbSchoolPicker(null, spdbSchoolValue, item, scope);
        if (spdbSchoolOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "浦发学校弹层选择失败" });
        continue;
      }
      if (item.type === "spdbSchoolPicker") {
        var spdbHighSchoolValue = data && data[item.field];
        var spdbHighSchoolInput = scope && scope.querySelector("input[name='schoolDescr']");
        var spdbHighSchoolOk = hasMeaningfulValue(spdbHighSchoolValue) && spdbHighSchoolInput && await AF.FormHandler.fillFormElement(spdbHighSchoolInput, spdbHighSchoolValue, "text");
        if (spdbHighSchoolOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "浦发高中学校名称填写失败" });
        continue;
      }
      // 智联教育时间的真实 DOM 是普通 <li> + .edu-edit-title，
      // 两个 MonthPicker 只能通过 placeholder 区分，不属于常规
      // form-item 标签容器。必须在通用 label 匹配之前直接执行，
      // 否则标签未识别时会连日期弹层都不打开。
      if (item.type === "zhaopinEducationDate") {
        var directZhaopinEducationDateValue = data && data[item.field];
        var directZhaopinEducationDateOk = await fillZhaopinEducationDate(
          directZhaopinEducationDateValue, item, scope
        );
        if (directZhaopinEducationDateOk) {
          engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        } else if (item.optional !== true) {
          failed.push({ fieldKey: item.field, label: String(item.label), reason: "智联在校时间填写失败" });
        }
        await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
        continue;
      }
      // 招商银行把开始、结束日期做成同一个“时间”表单项里的两个独立
      // Ant DatePicker。把整个 {startTime,endTime} 对象交给单个日期控件时，
      // 日期器会把结束日期写入第一个输入框。这里按当前经历卡片重新定位
      // 两个输入框，分别调用现有 Ant 日期能力，避免跨卡或首尾颠倒。
      if (item.type === "cmbchinaDateRange") {
        var cmbchinaStartValue = data && data[item.startField || "startTime"];
        var cmbchinaEndValue = data && data[item.endField || "endTime"];
        function findCmbchinaDateInputs() {
          var currentRoot = refreshSequenceScope(step, scope) || scope || document;
          var groups = [];
          try { groups = Array.from(currentRoot.querySelectorAll(".ant-form-item")); } catch (eGroups) {}
          var timeGroup = groups.find(function (group) {
            var labelNode = group.querySelector(".ant-form-item-label, label");
            return normalizeText(labelNode && labelNode.textContent) === normalizeText(item.label || "时间");
          });
          if (!timeGroup) return [];
          try {
            return Array.from(timeGroup.querySelectorAll(".ant-picker input, input[placeholder*='时间']")).filter(isVisible);
          } catch (eInputs) {
            return [];
          }
        }
        var cmbchinaDateInputs = findCmbchinaDateInputs();
        var cmbchinaStartOk = false;
        var cmbchinaEndOk = false;
        if (cmbchinaDateInputs.length >= 2 && hasMeaningfulValue(cmbchinaStartValue)) {
          cmbchinaStartOk = await AF.FormHandler.fillFormElement(cmbchinaDateInputs[0], cmbchinaStartValue, "date");
          await sleep(item.waitBetweenDatesMs == null ? 180 : item.waitBetweenDatesMs);
        }
        cmbchinaDateInputs = findCmbchinaDateInputs();
        if (cmbchinaDateInputs.length >= 2 && hasMeaningfulValue(cmbchinaEndValue)) {
          cmbchinaEndOk = await AF.FormHandler.fillFormElement(cmbchinaDateInputs[1], cmbchinaEndValue, "date");
        }
        if (cmbchinaStartOk && cmbchinaEndOk) {
          engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        } else if (item.optional !== true) {
          failed.push({
            fieldKey: [item.startField || "startTime", item.endField || "endTime"].join("+"),
            label: String(item.label),
            reason: "招商银行开始/结束日期填写失败",
          });
        }
        await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
        continue;
      }
      // 招商银行荣誉“获奖时间”是 Ant MonthPicker：打开后先选年份，再选月份，
      // 选中月份即提交，没有日期（日）这一层。通用 Ant 日期入口会把月份面板
      // 误判成完整日期面板，因此这里直接复用 DatePicker 的年月导航底座。
      if (item.type === "cmbchinaMonthDate") {
        var cmbchinaDateValue = data && data[item.field];
        var cmbchinaYearMonth = normalizeYearMonthValue(cmbchinaDateValue);
        var cmbchinaDateRoot = refreshSequenceScope(step, scope) || scope || document;
        var cmbchinaDateInput = null;
        try {
          cmbchinaDateInput = Array.from(cmbchinaDateRoot.querySelectorAll(
            item.inputSelector || ".ant-picker input[id$='_awardDate'], .ant-picker input"
          )).find(isVisible) || null;
        } catch (eCmbchinaDateInput) {}
        var cmbchinaDateOk = false;
        if (cmbchinaDateInput && cmbchinaYearMonth && AF.DatePicker && typeof AF.DatePicker._navigatePanel === "function") {
          var currentCmbchinaMonth = normalizeYearMonthValue(cmbchinaDateInput.value);
          if (currentCmbchinaMonth === cmbchinaYearMonth) {
            cmbchinaDateOk = true;
          } else {
            try {
              cmbchinaDateInput.focus && cmbchinaDateInput.focus();
              await AF.DomUtils.safeClickElement(cmbchinaDateInput);
            } catch (eCmbchinaMonthOpen) {}
            var cmbchinaMonthPanel = await waitUntil(function () {
              try {
                return Array.from(document.querySelectorAll(
                  ".ant-picker-dropdown:not(.ant-picker-dropdown-hidden):not([style*='display: none']):not([hidden])"
                )).filter(isVisible).find(function (panel) {
                  return !!panel.querySelector(".ant-picker-month-panel, .ant-picker-year-panel");
                }) || null;
              } catch (ePanel) { return null; }
            }, item.panelTimeoutMs || 1800);
            if (cmbchinaMonthPanel) {
              cmbchinaDateOk = await AF.DatePicker._navigatePanel({
                container: cmbchinaMonthPanel,
                dateString: cmbchinaYearMonth,
                headerClickSelector: ".ant-picker-year-btn",
                yearCellSelector: ".ant-picker-year-panel .ant-picker-cell-in-view",
                yearBoundarySelector: ".ant-picker-decade-btn",
                nextYearSelector: ".ant-picker-header-super-next-btn",
                prevYearSelector: ".ant-picker-header-super-prev-btn",
                monthPanelSelector: null,
                monthCellSelector: ".ant-picker-month-panel .ant-picker-cell",
                dayCellSelector: null,
                maxRetries: 20,
              });
              if (cmbchinaDateOk) {
                cmbchinaDateOk = !!(await waitUntil(function () {
                  return normalizeYearMonthValue(cmbchinaDateInput.value) === cmbchinaYearMonth ? true : null;
                }, item.commitTimeoutMs || 1200));
              }
            }
          }
        }
        if (cmbchinaDateOk) {
          engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        } else if (item.optional !== true) {
          failed.push({ fieldKey: item.field, label: String(item.label), reason: "招商银行获奖年月填写失败" });
        }
        await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
        continue;
      }
      if (item.type === "cmbcCertificates") {
        var certificateNames = data && data.cmbcCertificateNames;
        certificateNames = Array.isArray(certificateNames) ? certificateNames : [certificateNames].filter(Boolean);
        if (!certificateNames.length) continue;
        var certificateFilled = 0;
        for (var certificateIndex = 0; certificateIndex < certificateNames.length; certificateIndex++) {
          var certificateName = certificateNames[certificateIndex];
          var certificateRoot = refreshSequenceScope(step, scope) || document;
          if (normalizeText(certificateRoot.textContent).indexOf(normalizeText(certificateName)) !== -1) continue;
          var addCertificate = findByText(certificateRoot, item.addText || "添加证书", "button, a, [role='button']");
          if (!addCertificate) {
            failed.push({ fieldKey: "certificates", label: "技能证书", reason: "未找到添加证书入口" });
            break;
          }
          await safeClick(addCertificate);
          var certificateDialog = await waitUntil(function () {
            try { return Array.from(document.querySelectorAll("[role='dialog'], .modal-dialog")).find(isVisible) || null; } catch (e) { return null; }
          }, item.timeoutMs || 3500);
          var certificateInput = certificateDialog && Array.from(certificateDialog.querySelectorAll("input:not([type='checkbox']):not([type='radio'])")).find(isVisible);
          if (!certificateInput) {
            failed.push({ fieldKey: "certificates", label: "技能证书", reason: "证书弹窗输入框未出现" });
            break;
          }
          await AF.FormHandler.fillFormElement(certificateInput, certificateName, "text");
          var confirmButtons = Array.from(certificateDialog.querySelectorAll("button, a, [role='button']")).filter(isVisible).filter(function (node) {
            return normalizeText(node.textContent) === "确认";
          });
          if (!confirmButtons.length) {
            failed.push({ fieldKey: "certificates", label: "技能证书", reason: "证书弹窗确认按钮未出现" });
            break;
          }
          await safeClick(confirmButtons[0]);
          certificateFilled += 1;
          await sleep(item.waitAfterEachMs == null ? 180 : item.waitAfterEachMs);
        }
        engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + certificateFilled;
        await sleep(item.waitAfterMs == null ? 200 : item.waitAfterMs);
        continue;
      }
      if (/^citic(?:Text|Select|SchoolSelect|SelectWithOther|Date|CurrentOrDate|LinkedSelect)$/.test(String(item.type || ""))) {
        var citicValue = configuredSequenceValue(data, item);
        var citicOk = false;
        if (item.type === "citicText") citicOk = await fillCiticText(scope, citicValue, item);
        else if (item.type === "citicSelect") citicOk = await fillCiticSelect(scope, citicValue, item);
        else if (item.type === "citicSchoolSelect") citicOk = await fillCiticSchoolSelect(scope, citicValue, item);
        else if (item.type === "citicSelectWithOther") citicOk = await fillCiticSelectWithOther(scope, citicValue, item);
        else if (item.type === "citicDate") citicOk = await fillCiticDate(scope, citicValue, item);
        else if (item.type === "citicCurrentOrDate") citicOk = await fillCiticCurrentOrDate(scope, citicValue, item);
        else citicOk = await fillCiticLinkedSelect(scope, citicValue, item);
        if (citicOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field || (item.valueFields || []).join("+"), label: String(item.label), reason: "中信原生表单字段填写失败" });
        await sleep(item.waitAfterMs == null ? 100 : item.waitAfterMs);
        continue;
      }
      if (item.type === "cibSchool") {
        var cibSchoolValue = data && data[item.field];
        var cibSchoolOk = await fillCibSchool(cibSchoolValue, item, scope);
        if (cibSchoolOk) {
          engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        } else if (item.optional !== true) {
          failed.push({ fieldKey: item.field, label: String(item.label), reason: "兴业银行学校搜索候选选择失败" });
        }
        await sleep(item.waitAfterMs == null ? 180 : item.waitAfterMs);
        continue;
      }
      if (item.type === "bankcommGpa") {
        var bankcommGpaValue = data && data[item.gpaField || "bankcommGpa"];
        var bankcommGpaTotalValue = data && data[item.totalField || "bankcommGpaTotal"];
        var bankcommGpaRoot = refreshSequenceScope(step, scope) || scope || document;
        var bankcommGpaInput = bankcommGpaRoot.querySelector("input#gpa");
        var bankcommGpaTotalInput = bankcommGpaRoot.querySelector("input#gpaTotal");
        var bankcommGpaOk = !hasMeaningfulValue(bankcommGpaValue) ||
          (bankcommGpaInput && await AF.FormHandler.fillFormElement(bankcommGpaInput, bankcommGpaValue, "text"));
        var bankcommGpaTotalOk = !hasMeaningfulValue(bankcommGpaTotalValue) ||
          (bankcommGpaTotalInput && await AF.FormHandler.fillFormElement(bankcommGpaTotalInput, bankcommGpaTotalValue, "text"));
        if (bankcommGpaOk && bankcommGpaTotalOk) {
          engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        } else if (item.optional !== true) {
          failed.push({
            fieldKey: [item.gpaField || "bankcommGpa", item.totalField || "bankcommGpaTotal"].join("+"),
            label: String(item.label),
            reason: "交通银行 GPA 组合字段填写失败",
          });
        }
        await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
        continue;
      }
      if (item.type === "bankcommCommitmentCheckboxes") {
        var bankcommCommitmentExpected = data && data[item.field];
        var bankcommCommitmentOk = bankcommCommitmentExpected !== false &&
          await fillBankcommCommitmentCheckboxes(refreshSequenceScope(step, scope) || scope || document, item);
        if (bankcommCommitmentOk) {
          engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        } else if (item.optional !== true) {
          failed.push({ fieldKey: item.field, label: String(item.label), reason: "交通银行本人承诺复选框未全部勾选" });
        }
        await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
        continue;
      }
      labels = matcher.findLabelsByCard(scope || document) || matcher.findAllLabels() || [];
      var higherExpectedType = item.type === "elementDate" ? "date" : (item.type === "zhaopinChoice" ? "choice" : "text");
      var higherFieldBinding = null;
      if (step && step.higherEducationVariant === true) {
        try {
          higherFieldBinding = resolveFieldBinding(matcher, scope, item.label, higherExpectedType, item.field);
          setHigherEducationRuntimeBinding(step.repeatIndex || 0, item.field, higherFieldBinding);
        } catch (higherBindingError) {
          appendHigherEducationFieldTrace({ recordIndex: step.repeatIndex || 0, fieldKey: String(item.field || ""), label: String(item.label || ""), valueAvailable: hasMeaningfulValue(data && data[item.field]), scopeResolved: !!scope, labelFound: false, controlFound: false, controlType: higherExpectedType, alreadyCorrect: false, executionPath: "binding_resolution", committed: false, reason: "binding_resolution_exception", errorType: String(higherBindingError && higherBindingError.name || "Error") });
          if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "高等教育字段绑定异常" });
          continue;
        }
      }
      var label = step && step.higherEducationVariant === true
        ? higherFieldBinding.label
        : item && item.labelExact === true
        ? findExactLabelForSequence(labels, item.label)
        : findLabelForSequence(labels, item.label);
      if (!label && item && item.zhaopinRepeatLocalBinding === true) {
        label = findZhaopinRepeatLocalLabel(scope || document, item.label);
      }
      if (!label && item && item.requireLabel === true) {
        if (item.optional !== true) {
          failed.push({ fieldKey: item.field, label: String(item.label), reason: "未找到字段标签，已阻止误填其它控件" });
        }
        await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
        continue;
      }
      if (/^applyjob\.chinahr\.com$/i.test(window.location.hostname) && (normalizeText(item && item.label) === "证件号码" || item.field === "idNumber")) {
        var chinahrIdOk = await fillChinahrIdNumber(label, data && data[item.field], item);
        if (chinahrIdOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "中国银行证件类型或证件号码填写失败" });
        await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
        continue;
      }
      if (!label) {
        if (step && step.higherEducationNavigationAdapter === true) {
          appendHigherEducationFieldTrace({
            educationRecordIndex: Number.isInteger(step.repeatIndex) ? step.repeatIndex : 0,
            fieldKey: String(item.field || ""),
            genericMatcherFound: false,
            detectedType: "",
            committed: false,
            reason: "label_not_found"
          });
        }
        if (step && step.higherEducationVariant === true && item && item.higherEducationField === true) {
          appendHigherEducationFieldTrace({ recordIndex: step.repeatIndex || 0, fieldKey: String(item.field || ""), label: String(item.label || ""), valueAvailable: hasMeaningfulValue(data && data[item.field]), scopeResolved: !!scope, labelFound: false, controlFound: false, controlType: "", alreadyCorrect: false, executionPath: "", committed: false, reason: "label_not_found" });
        }
        // 平安“综合能力简述”的真实编辑态只有 textarea + 字数统计，没有字段
        // label。站点配置明确允许时，直接在当前栏目 scope 内驱动专用 Vue 文本
        // 控件；仍严格限制在当前模块，不允许退回全页面第一个输入框。
        if (item.type === "pinganText" && item.useScopeWhenLabelMissing === true) {
          var scopedPinganTextValue = data && data[item.field];
          var scopedPinganTextOk = hasMeaningfulValue(scopedPinganTextValue) &&
            await fillPinganText(null, scopedPinganTextValue, item, scope);
          if (scopedPinganTextOk) {
            engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
          } else if (item.optional !== true) {
            failed.push({ fieldKey: item.field, label: String(item.label), reason: "平安无标签 Vue 文本控件填写失败" });
          }
          await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
          continue;
        }
        if (item.type === "scopedText" && item.useScopeWhenLabelMissing === true) {
          var scopedTextValue = data && data[item.field];
          var scopedTextOk = hasMeaningfulValue(scopedTextValue) && await fillScopedText(scope, scopedTextValue, item);
          if (scopedTextOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
          else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "无标签文本控件填写失败" });
          await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
          continue;
        }
        if (item.optional !== true) failed.push({ fieldKey: item.field || "dependentField", label: String(item.label), reason: "未找到依赖字段标签" });
        continue;
      }
      if (item.type === "higherEducationText") {
        var higherTextValue = data && data[item.field];
        var higherTextItem = Object.assign({}, item, { __recordIndex: step.repeatIndex || 0 });
        var higherTextOk = await fillHigherEducationText(matcher, label, higherTextValue, higherTextItem, scope);
        if (higherTextOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "高等教育文本字段未提交" });
        await sleep(item.waitAfterMs == null ? 100 : item.waitAfterMs);
        continue;
      }
      if (item.type === "sfIdType") {
        var sfIdValue = data && data[item.field];
        var sfIdOk = hasMeaningfulValue(sfIdValue) && await fillSfIdType(label, sfIdValue, item);
        if (sfIdOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "顺丰证件类型下拉填写失败" });
        await sleep(item.waitAfterMs == null ? 100 : item.waitAfterMs);
        continue;
      }
      if (/^huawei(?:Text|Select|SearchSelect|Radio|Date)$/.test(String(item.type || ""))) {
        var huaweiValue = data && data[item.field];
        var huaweiOk = await fillHuaweiField(label, huaweiValue, item, scope);
        if (huaweiOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true && hasMeaningfulValue(huaweiValue)) failed.push({
          fieldKey: item.field,
          label: String(item.label),
          reason: "华为 LayUI 控件填写失败",
        });
      } else if (item.type === "webformsYearMonth") {
        var webformsDateValue = data && data[item.field];
        var webformsDateOk = await fillWebFormsYearMonth(label, webformsDateValue);
        if (webformsDateOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "WebForms 年月双下拉填写失败" });
      } else if (item.type === "webformsLinkedSelect") {
        var webformsLinkedValue = configuredSequenceValue(data, item);
        var webformsLinkedOk = await fillWebFormsLinkedSelect(label, webformsLinkedValue, item);
        if (webformsLinkedOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "WebForms 两级联动下拉填写失败" });
      } else if (item.type === "webformsText") {
        var webformsTextValue = configuredSequenceValue(data, item);
        var webformsTextOk = await fillWebFormsText(label, webformsTextValue, item);
        if (webformsTextOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true && hasMeaningfulValue(webformsTextValue)) {
          failed.push({ fieldKey: item.field, label: String(item.label), reason: "WebForms 精确文本输入失败" });
        }
      } else if (item.type === "webformsSelect") {
        var webformsSelectValue = data && data[item.field];
        var webformsSelectOk = await fillWebFormsSelect(label, webformsSelectValue, item);
        if (webformsSelectOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "WebForms 原生下拉填写失败" });
      } else if (item.type === "webformsDateText") {
        var webformsDateTextValue = data && data[item.field];
        var webformsDateTextOk = await fillWebFormsDateText(label, webformsDateTextValue, item);
        if (webformsDateTextOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "WebForms 只读日期填写失败" });
      } else if (item.type === "webformsDictionary") {
        var webformsDictionaryValue = data && data[item.field];
        var webformsDictionaryOk = await fillWebFormsDictionary(label, webformsDictionaryValue, item);
        if (webformsDictionaryOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "WebForms 学校/专业字典填写失败" });
      } else if (item.type === "webformsCheckboxGroup") {
        var webformsCheckboxValue = configuredSequenceValue(data, item);
        var webformsCheckboxOk = await fillWebFormsCheckboxGroup(label, webformsCheckboxValue, item);
        if (webformsCheckboxOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "WebForms 复选组填写失败" });
      } else if (item.type === "elementSelectGroup") {
        var elementSelectGroupOk = await fillElementSelectGroup(label, data, item);
        if (elementSelectGroupOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({
          fieldKey: (item.dataFields || []).join("+"),
          label: String(item.label),
          reason: "Element组合下拉未按层级完成",
        });
      } else if (item.type === "elementSelectAutocompleteGroup") {
        var elementSelectAutocompleteGroupOk = await fillElementSelectAutocompleteGroup(label, data, item);
        if (elementSelectAutocompleteGroupOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({
          fieldKey: (item.dataFields || []).join("+"),
          label: String(item.label),
          reason: "Element下拉与联想组合未按层级完成",
        });
      } else if (item.type === "bankcommStrictEducationSelect") {
        var bankcommEducationValue = data && data[item.field];
        var bankcommEducationOk = hasMeaningfulValue(bankcommEducationValue) &&
          await fillBankcommStrictEducationSelect(label, bankcommEducationValue, item);
        if (bankcommEducationOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({
          fieldKey: item.field,
          label: String(item.label),
          reason: "交通银行学历精确选择失败（目标：" + String(bankcommEducationValue || "") + "）",
        });
      } else if (item.type === "bankcommDate" || item.type === "bankcommCurrentEndOrDate") {
        var bankcommDateValue = data && data[item.field];
        var bankcommDateOk = false;
        if (item.type === "bankcommCurrentEndOrDate" && isCurrentEndText(bankcommDateValue)) {
          bankcommDateOk = await clickBankcommCurrentEndNearLabel(label, scope);
        } else if (hasMeaningfulValue(bankcommDateValue)) {
          bankcommDateOk = await fillBankcommDate(label, bankcommDateValue, item, scope);
        }
        if (bankcommDateOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "交通银行日期精确填写失败" });
      } else if (item.type === "bankcommAddressCascader" || item.type === "bankcommNativePlace") {
        var bankcommNativePath = data && data[item.field];
        var bankcommAddressInput = item.inputId ? document.getElementById(item.inputId) : null;
        var bankcommAddressFormItem = bankcommAddressInput && bankcommAddressInput.closest(".ant-form-item");
        var bankcommAddressLabel = bankcommAddressFormItem && bankcommAddressFormItem.querySelector(".ant-form-item-label") || label;
        // 只能读取 Ant Select 真正的已选值。整个 form-item.textContent 还包含
        // “请选择籍贯”等红色校验文案，旧逻辑会把校验文案误判为已有值，
        // 导致户口所在地和现居住地尚为空时被 preserveExisting 直接跳过。
        var bankcommAddressSelected = bankcommAddressFormItem && bankcommAddressFormItem.querySelector(
          ".ant-select-selection-item, .ant-select-selection-selected-value, .ant-cascader-picker-label"
        );
        var bankcommAddressHasExisting = normalizeText(bankcommAddressSelected && bankcommAddressSelected.textContent);
        if (/^请选择/.test(bankcommAddressHasExisting)) bankcommAddressHasExisting = "";
        if (item.preserveExisting && bankcommAddressHasExisting) {
          engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
          await sleep(item.waitAfterMs == null ? 100 : item.waitAfterMs);
          continue;
        }
        var bankcommNativeOk = Array.isArray(bankcommNativePath) && bankcommNativePath.length > 0 &&
          await fillDependentCascader(bankcommAddressLabel || label, bankcommNativePath, {
            formItemSelector: ".ant-form-item",
            // input#familyCounty/#home/#live 是 opacity:0 的透明搜索节点，React
            // 的打开事件绑定在外层 .ant-select-selector / .ant-select。必须点击
            // 外层，否则脚本返回“已点击”但级联菜单实际没有打开。
            triggerSelector: ".ant-select-selector, .ant-select.ant-cascader, .ant-cascader, .ant-select",
            optionSelector: ".ant-cascader-menu-item, .ant-cascader-menu li, .ant-cascader-menus li",
            optionTimeoutMs: item.optionTimeoutMs || 7000,
            waitAfterOpenMs: 500,
            waitAfterOpenRetryMs: 500,
            waitAfterOptionMs: 500,
            // 交行的 rc-cascader 会忽略 content script 派发的非可信鼠标事件。
            // 必须优先进入页面主世界，直接调用 React 节点自身的事件处理器；
            // 普通 DOM 逐级点击仅保留为桥接失败后的兜底。
            skipAntBridge: false,
            bridgeTimeoutMs: 30000,
            useMouseSequence: true,
          });
        if (bankcommNativeOk) {
          var bankcommAddressCommitted = await waitUntil(function () {
            var selected = bankcommAddressFormItem && bankcommAddressFormItem.querySelector(
              ".ant-select-selection-item, .ant-select-selection-selected-value, .ant-cascader-picker-label"
            );
            var selectedText = normalizeText(selected && selected.textContent);
            return selectedText && !/^请选择/.test(selectedText) ? selectedText : null;
          }, item.writebackTimeoutMs || 1800);
          if (bankcommAddressCommitted) {
            engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
          } else {
            bankcommNativeOk = false;
          }
        }
        if (!bankcommNativeOk) {
          // 失败时主动收起级联弹层，不能让它覆盖后面的政治面貌普通下拉。
          try { document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true })); } catch (eCloseNative) {}
          try { if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); } catch (eBlurNative) {}
          if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "交通银行地址级联填写失败：" + (lastCascaderError || "unknown") });
        }
      } else if (item.type === "bankcommSchoolSearch" || item.type === "bankcommResearchSearch" || item.type === "bankcommMajorSearch") {
        var isBankcommResearchSearch = item.type === "bankcommResearchSearch";
        var isBankcommMajorSearch = item.type === "bankcommMajorSearch";
        var bankcommSchoolPathValue = data && data[item.field];
        var bankcommSchoolName = Array.isArray(bankcommSchoolPathValue)
          ? bankcommSchoolPathValue[bankcommSchoolPathValue.length - 1]
          : bankcommSchoolPathValue;
        var bankcommSchoolItem = label.closest && label.closest(".ant-form-item");
        var bankcommSchoolTrigger = bankcommSchoolItem && bankcommSchoolItem.querySelector(".ant-select.ant-cascader, .ant-cascader");
        var bankcommSchoolOk = false;
        var bankcommResearchFallbackValue = isBankcommResearchSearch && item.fallbackField
          ? data && data[item.fallbackField]
          : "";
        // 研究方向若已经回填正确，直接跳过。此前每次仍打开三级级联，
        // 即使已有值也会白等桥接超时。
        if ((isBankcommResearchSearch || isBankcommMajorSearch) && bankcommSchoolItem && hasMeaningfulValue(bankcommSchoolName)) {
          var existingResearchSelection = bankcommSchoolItem.querySelector(
            ".ant-select-selection-item, .ant-select-selection-selected-value"
          );
          var existingResearchText = normalizeText(existingResearchSelection &&
            (existingResearchSelection.getAttribute("title") || existingResearchSelection.textContent));
          bankcommSchoolOk = !!(existingResearchText &&
            existingResearchText.indexOf(normalizeText(bankcommSchoolName)) !== -1);
        }
        // 无法确定映射时，走交行页面提供的官方“若未找到”入口，
        // 不再根据财经关键词擅自猜一个相似研究方向。
        if (!bankcommSchoolOk && isBankcommResearchSearch && hasMeaningfulValue(bankcommResearchFallbackValue)) {
          bankcommSchoolOk = await fillBankcommResearchCustomValue(
            label,
            bankcommResearchFallbackValue,
            item
          );
        }
        // 交行研究方向自带底部搜索。只有存在确定三级路径/叶子值时才搜索；
        // 未知研究方向已经在上面的官方 fallback 分支处理。
        if (!bankcommSchoolOk && bankcommSchoolTrigger && hasMeaningfulValue(bankcommSchoolName)) {
          await safeClick(bankcommSchoolTrigger);
          var bankcommSchoolSearchInput = await waitUntil(function () {
            var input = findVisibleBankcommSearchInput(
              isBankcommResearchSearch ? "researchSearch" : (isBankcommMajorSearch ? "majorSearch" : "schoolSearch")
            );
            return input && isVisible(input) ? input : null;
          }, (isBankcommResearchSearch || isBankcommMajorSearch) ? (item.searchInputTimeoutMs || 1200) : (item.searchInputTimeoutMs || 1800));
          if (bankcommSchoolSearchInput) {
            // 学校库是远程搜索型 Ant Select。通用 text handler 会在写值后立刻
            // blur，交行会因此收起/冻结搜索层，表现为“学校选项已打开但不再输入”。
            // 学校名称改用保持焦点的用户式逐字输入；专业和研究方向先维持原有
            // 已验证路径，避免扩大本次修复范围。
            if (!isBankcommResearchSearch && !isBankcommMajorSearch) {
              // 交行的 schoolSearch 是 React 受控 Ant Select。content script
              // 中的普通 DOM input 事件即使能改变 value，也不一定触发页面自己的
              // onSearch。优先通过已经加载的 Ant MAIN-world 桥接进行真实受控输入。
              var bankcommTypedSearchInput = await typeBankcommVisibleSearchInput(
                bankcommSchoolSearchInput,
                bankcommSchoolName,
                item.searchTypeTimeoutMs || 6500
              );
            } else {
              await AF.FormHandler.fillFormElement(bankcommSchoolSearchInput, bankcommSchoolName, "text");
            }
            var bankcommSchoolOption = (isBankcommResearchSearch || isBankcommMajorSearch || bankcommTypedSearchInput) && await waitUntil(function () {
              try {
                return Array.from(document.querySelectorAll(
                  ".ant-select-dropdown:not(.ant-cascader-dropdown):not(.ant-select-dropdown-hidden) .ant-select-item-option"
                )).filter(isVisible).find(function (node) {
                  var optionText = normalizeText(node.textContent);
                  var wantedText = normalizeText(bankcommSchoolName);
                  return optionText === wantedText ||
                    ((isBankcommResearchSearch || isBankcommMajorSearch) && optionText.indexOf(wantedText) !== -1);
                }) || null;
              } catch (e) { return null; }
            }, (isBankcommResearchSearch || isBankcommMajorSearch) ? (item.searchOptionTimeoutMs || 2200) : (item.optionTimeoutMs || 4500));
            if (bankcommSchoolOption || (!isBankcommResearchSearch && !isBankcommMajorSearch)) {
              // 交行底部搜索结果是 React 受控 Ant Select。content script 的
              // 合成 click 在专业名称上会被控件忽略，必须优先在 MAIN world
              // 调用该候选项自身的 React onClick，之后再检查主级联是否回写。
              var bankcommSearchOptionClicked = !isBankcommResearchSearch && !isBankcommMajorSearch
                ? await clickAntSearchOptionInPage(
                    bankcommTypedSearchInput,
                    bankcommSchoolOption,
                    bankcommSchoolName,
                    item.searchOptionClickTimeoutMs || 7000
                  )
                : await clickAntActionInPage(bankcommSchoolOption, item.searchOptionClickTimeoutMs || 3000);
              if (!bankcommSearchOptionClicked && bankcommSchoolOption) await safeClick(bankcommSchoolOption);
              bankcommSchoolOk = !!(await waitUntil(function () {
                var currentItem = label.closest && label.closest(".ant-form-item");
                var selected = currentItem && currentItem.querySelector(".ant-select-selection-item");
                var selectedText = normalizeText(selected && (selected.getAttribute("title") || selected.textContent));
                var wantedText = normalizeText(bankcommSchoolName);
                return selected && (
                  selectedText === wantedText ||
                  ((isBankcommResearchSearch || isBankcommMajorSearch) && selectedText.indexOf(wantedText) !== -1)
                ) ? selected : null;
              }, (isBankcommResearchSearch || isBankcommMajorSearch) ? (item.writebackTimeoutMs || 1200) : (item.writebackTimeoutMs || 1800)));
            }
          }
          // 搜索控件偶发未渲染时，再用完整三级路径短超时兜底。
          if (!bankcommSchoolOk && isBankcommResearchSearch &&
              Array.isArray(bankcommSchoolPathValue) && bankcommSchoolPathValue.length === 3) {
            bankcommSchoolOk = await fillDependentCascader(label, bankcommSchoolPathValue, {
              formItemSelector: ".ant-form-item",
              triggerSelector: ".ant-select.ant-cascader, .ant-cascader, .ant-select.ant-cascader input",
              optionSelector: ".ant-cascader-menu-item, .ant-cascader-menu li, .ant-cascader-menus li",
              bridgeTimeoutMs: item.bridgeTimeoutMs || 3200,
              optionTimeoutMs: item.cascaderOptionTimeoutMs || 1200,
              waitAfterOptionMs: 100,
            });
          }
          if (!bankcommSchoolOk && isBankcommMajorSearch &&
              Array.isArray(bankcommSchoolPathValue) && bankcommSchoolPathValue.length === 2) {
            bankcommSchoolOk = await fillDependentCascader(label, bankcommSchoolPathValue, {
              formItemSelector: ".ant-form-item",
              triggerSelector: ".ant-select.ant-cascader, .ant-cascader, .ant-select.ant-cascader input",
              optionSelector: ".ant-cascader-menu-item, .ant-cascader-menu li, .ant-cascader-menus li",
              bridgeTimeoutMs: item.bridgeTimeoutMs || 5000,
              optionTimeoutMs: item.cascaderOptionTimeoutMs || 1800,
              waitAfterOptionMs: 120,
            });
          }
          if (!bankcommSchoolOk && !isBankcommResearchSearch && !isBankcommMajorSearch &&
              Array.isArray(bankcommSchoolPathValue) && bankcommSchoolPathValue.length >= 2) {
            try { document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true })); } catch (eCloseSchoolSearch) {}
            await sleep(180);
            bankcommSchoolOk = await fillDependentCascader(label, bankcommSchoolPathValue, {
              formItemSelector: ".ant-form-item",
              triggerSelector: ".ant-select.ant-cascader, .ant-cascader, .ant-select.ant-cascader input",
              optionSelector: ".ant-cascader-menu-item, .ant-cascader-menu li, .ant-cascader-menus li",
              bridgeTimeoutMs: item.bridgeTimeoutMs || 8000,
              optionTimeoutMs: item.cascaderOptionTimeoutMs || 2200,
              waitAfterOptionMs: 180,
            });
          }
          if (!bankcommSchoolOk && AF.SelectAdapter && typeof AF.SelectAdapter.create === "function") {
            try {
              bankcommSchoolOk = await AF.SelectAdapter.create(
                bankcommSchoolTrigger,
                Array.isArray(bankcommSchoolPathValue) ? "object" : "string"
              ).selectValue(bankcommSchoolPathValue);
            } catch (eFallbackSchool) {}
          }
        }
        if (bankcommSchoolOk) {
          engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        } else if (item.optional !== true) {
          failed.push({
            fieldKey: item.field,
            label: String(item.label),
            reason: isBankcommResearchSearch
              ? ("交通银行研究方向快捷搜索及级联兜底均失败" + (lastBankcommResearchCustomError ? "；" + lastBankcommResearchCustomError : ""))
              : (isBankcommMajorSearch
                ? "交通银行专业名称快捷搜索及两级级联兜底均失败"
                : "交通银行学校快捷搜索及级联兜底均失败"),
          });
        }
      } else if (item.type === "pinganPhone") {
        var pinganPhoneOk = await fillPinganPhone(label, data, item, scope);
        if (pinganPhoneOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.phoneField || "phone", label: String(item.label), reason: "平安手机号区号/号码组合填写失败" });
      } else if (item.type === "pinganText") {
        var pinganTextValue = data && data[item.field];
        var pinganTextOk = hasMeaningfulValue(pinganTextValue) && await fillPinganText(label, pinganTextValue, item, scope);
        if (pinganTextOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "平安 Vue 文本控件填写失败" });
      } else if (item.type === "scopedText") {
        var normalScopedTextValue = data && data[item.field];
        var normalScopedTextOk = hasMeaningfulValue(normalScopedTextValue) && await fillScopedText(label.closest(".el-form-item") || scope, normalScopedTextValue, item);
        if (normalScopedTextOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "文本控件填写失败" });
      } else if (item.type === "job51CitySearch") {
        var job51CityValue = data && data[item.field];
        var job51CityOk = hasMeaningfulValue(job51CityValue) && await fillJob51CitySearch(label, job51CityValue, item, scope);
        if (job51CityOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "招聘网站城市搜索选择失败" });
      } else if (item.type === "sfCityPicker") {
        var sfCityValue = data && data[item.field];
        if (!hasMeaningfulValue(sfCityValue) && Array.isArray(item.dataFields)) {
          sfCityValue = item.dataFields.map(function (key) { return data && data[key]; }).find(hasMeaningfulValue);
        }
        var sfCityOk = hasMeaningfulValue(sfCityValue) && await fillSfCityPicker(label, sfCityValue, item, scope);
        if (sfCityOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "顺丰城市弹窗填写失败" });
      } else if (item.type === "spdbCityPicker") {
        var spdbCityValue = data && data[item.field];
        var spdbCityOk = hasMeaningfulValue(spdbCityValue) && await fillSpdbCityPicker(label, spdbCityValue, item, scope);
        if (spdbCityOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "浦发省市弹窗填写失败" });
      } else if (item.type === "spdbFamilyAddress") {
        var familyAddressValue = data && data[item.field];
        var familyAddressOk = hasMeaningfulValue(familyAddressValue) && await fillSpdbFamilyAddress(familyAddressValue, item);
        if (familyAddressOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "浦发家庭住址填写失败" });
      } else if (item.type === "job51Salary") {
        var job51SalaryOk = await fillJob51Salary(label, data, item);
        if (job51SalaryOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: [item.minField, item.maxField, item.monthsField].join("+"), label: String(item.label), reason: "招聘网站薪资组合下拉填写失败" });
      } else if (item.type === "icbcDate") {
        var icbcDateOk = await fillIcbcDate(label, data && data[item.field], item, scope);
        if (icbcDateOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "工商银行教育经历日期填写失败" });
      } else if (item.type === "icbcSchoolSearch") {
        var icbcSchoolOk = await fillIcbcSchoolSearch(label, data && data[item.field], item);
        if (icbcSchoolOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "工商银行学校搜索选择失败" });
      } else if (item.type === "icbcMajor") {
        var icbcMajorOk = await fillIcbcMajor(label, data, item);
        if (icbcMajorOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "工商银行专业三级下拉填写失败" });
      } else if (item.type === "icbcHighSchool") {
        var icbcHighSchoolOk = await fillIcbcHighSchool(label, data && data[item.field], data, item);
        if (icbcHighSchoolOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "工商银行高中毕业院校填写失败" });
      } else if (item.type === "icbcLinkedSelect") {
        var icbcLinkedValue = data && data[item.field];
        var icbcLinkedOk = hasMeaningfulValue(icbcLinkedValue) && await fillIcbcLinkedSelect(label, icbcLinkedValue, item);
        if (icbcLinkedOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "工商银行省市联动选择失败" });
      } else if (item.type === "icbcAddress") {
        var icbcAddressOk = await fillIcbcAddress(label, data, item);
        if (icbcAddressOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "工商银行家庭住址填写失败" });
      } else if (item.type === "pinganCascader") {
        var pinganCascaderValue = data && data[item.field];
        var pinganCascaderOk = hasMeaningfulValue(pinganCascaderValue) && await fillPinganCascader(label, pinganCascaderValue, item, scope);
        if (pinganCascaderOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "平安两层级联选择失败" });
      } else if (item.type === "pinganInlineSelect") {
        var pinganSelectValue = data && data[item.field];
        var pinganSelectOk = hasMeaningfulValue(pinganSelectValue) && await fillPinganInlineSelect(label, pinganSelectValue, item, scope);
        if (pinganSelectOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "平安内嵌/下拉选项选择失败" });
      } else if (item.type === "pinganDateText") {
        var pinganDateValue = data && data[item.field];
        var pinganDateOk = hasMeaningfulValue(pinganDateValue) && await fillPinganDateText(label, pinganDateValue, item, scope);
        if (pinganDateOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "平安日期直写失败" });
      } else if (item.type === "pinganCurrentEnd") {
        var pinganEndValue = data && data[item.field];
        var pinganEndOk = hasMeaningfulValue(pinganEndValue) && await fillPinganCurrentEnd(label, pinganEndValue, item, scope);
        if (pinganEndOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "平安结束时间/至今填写失败" });
      } else if (item.type === "elementCascaderCheckbox") {
        var checkboxValue = item.forceValue !== undefined ? item.forceValue : data && data[item.field];
        var checkboxOk = false;
        if (hasMeaningfulValue(checkboxValue)) {
          checkboxOk = await fillElementCascaderCheckbox(label, checkboxValue, item);
        }
        if (checkboxOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "Element多选级联填写失败" });
      } else if (item.type === "abcMajorWithOther") {
        var abcMajorOk = await fillAbcMajorWithOther(matcher, label, data, item, scope);
        if (abcMajorOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({
          fieldKey: (item.dataFields || []).join("+") || (item.majorField || "major"),
          label: String(item.label),
          reason: lastCascaderError ? "农业银行专业三级/其他专业填写失败：" + lastCascaderError : "农业银行专业三级/其他专业填写失败",
        });
      } else if (item.type === "cascader") {
        var values = (item.dataFields || []).map(function (field) { return data && data[field]; });
        var cascaderOk = await fillDependentCascader(label, values, item);
        if (cascaderOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({
          fieldKey: (item.dataFields || []).join("+"),
          label: String(item.label),
          reason: lastCascaderError ? "级联选择未完成：" + lastCascaderError : "级联选择未完成",
        });
      } else if (item.type === "job51ForceText") {
        var job51ForceTextValue = data && data[item.field];
        var job51ForceTextOk = false;
        var job51ForceTextRoot = scope || document;
        if (item.editorSelector) {
          try {
            job51ForceTextRoot = Array.from(document.querySelectorAll(item.editorSelector)).find(isVisible) || job51ForceTextRoot;
          } catch (eJob51ForceRoot) {}
        }
        var job51ForceTextInput = null;
        try {
          job51ForceTextInput = Array.from(job51ForceTextRoot.querySelectorAll(
            item.inputSelector || "input.el-input__inner:not([readonly])"
          )).find(isVisible) || null;
        } catch (eJob51ForceInput) {}
        if (job51ForceTextInput && hasMeaningfulValue(job51ForceTextValue)) {
          // 公司名称只是普通可保存文本，联想弹窗不是必选流程。直接写入
          // Vue input 状态，不查候选、不点击候选，也不关闭联想弹窗。
          setElementTextInput(job51ForceTextInput, "");
          await sleep(item.waitAfterClearMs == null ? 60 : item.waitAfterClearMs);
          setElementTextInput(job51ForceTextInput, String(job51ForceTextValue));
          job51ForceTextOk = !!(await waitUntil(function () {
            return normalizeText(job51ForceTextInput.value) === normalizeText(job51ForceTextValue) ? true : null;
          }, item.writebackTimeoutMs || 1200));
        }
        if (job51ForceTextOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "51Job文本强制写入失败" });
      } else if (item.type === "job51MonthRange") {
        var job51MonthRangeOk = await fillJob51MonthRange(data, item, scope);
        if (job51MonthRangeOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: [item.startField, item.endField].filter(Boolean).join("+"), label: String(item.label), reason: "51Job月份范围填写失败" });
      } else if (item.type === "monthRange") {
        var monthRangeOk = await fillMonthRangeNearLabel(label, data, item, scope);
        if (monthRangeOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: [item.startField, item.endField].filter(Boolean).join("+"), label: String(item.label), reason: "月份范围填写失败" });
      } else if (item.type === "cmbcDate") {
        var cmbcDateValue = data && data[item.field];
        var cmbcDateGroup = label.closest && label.closest(".form-group");
        var cmbcDateInput = cmbcDateGroup && Array.from(cmbcDateGroup.querySelectorAll(".ui-calendar input, input:not([type='hidden'])")).find(isVisible);
        var cmbcDateOk = false;
        if (cmbcDateInput && item.preserveExisting && String(cmbcDateInput.value || "").trim()) {
          cmbcDateOk = true;
        } else if (cmbcDateInput && hasMeaningfulValue(cmbcDateValue)) {
          var dateSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
          if (dateSetter && dateSetter.set) dateSetter.set.call(cmbcDateInput, String(cmbcDateValue));
          else cmbcDateInput.value = String(cmbcDateValue);
          cmbcDateInput.dispatchEvent(new Event("input", { bubbles: true }));
          cmbcDateInput.dispatchEvent(new Event("change", { bubbles: true }));
          cmbcDateInput.blur();
          await sleep(item.waitAfterInputMs == null ? 180 : item.waitAfterInputMs);
          cmbcDateOk = String(cmbcDateInput.value || "").trim() === String(cmbcDateValue).trim();
        }
        if (cmbcDateOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "PrimeNG日期填写失败" });
      } else if (item.type === "cmbcSchool") {
        var schoolValue = data && data[item.field];
        var schoolGroup = label.closest && label.closest(".form-group");
        var schoolInput = schoolGroup && Array.from(schoolGroup.querySelectorAll("input:not([type='hidden'])")).find(isVisible);
        var schoolOk = false;
        if (schoolInput && hasMeaningfulValue(schoolValue)) {
          // 已经是目标学校时不要再次打开搜索弹窗。此前每次都强制搜索，
          // 即使网站已有正确值，只要搜索响应稍慢也会被报告成失败。
          schoolOk = normalizeText(schoolInput.value) === normalizeText(schoolValue);
          var schoolDialog = null;
          if (!schoolOk) {
            // 弹窗属于异步创建的 Angular 组件。不能点击一次后按固定延时继续，
            // 必须确认弹窗真实出现；慢响应时最多重试三次，期间不进入下一个字段。
            for (var schoolOpenAttempt = 0; schoolOpenAttempt < 3 && !schoolDialog; schoolOpenAttempt++) {
              try {
                schoolInput.focus();
                ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach(function (eventName) {
                  var EventCtor = eventName.indexOf("pointer") === 0 && window.PointerEvent ? window.PointerEvent : window.MouseEvent;
                  schoolInput.dispatchEvent(new EventCtor(eventName, { bubbles: true, cancelable: true, view: window }));
                });
              } catch (e) {
                try { schoolInput.click(); } catch (e2) { await safeClick(schoolInput); }
              }
              schoolDialog = await waitUntil(function () {
                try { return Array.from(document.querySelectorAll("[role='dialog'], .modal-dialog")).find(isVisible) || null; } catch (e3) { return null; }
              }, item.dialogAttemptTimeoutMs || 2800);
              if (!schoolDialog) await sleep(300);
            }

            // 新版民生表单的“就读院校”改为普通文本框，不再提供搜索弹窗。
            // 弹窗未出现时直接写入并触发 Angular 输入事件。
            if (!schoolDialog && schoolInput) {
              var directSchoolSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
              if (directSchoolSetter && directSchoolSetter.set) directSchoolSetter.set.call(schoolInput, String(schoolValue));
              else schoolInput.value = String(schoolValue);
              schoolInput.dispatchEvent(new Event("input", { bubbles: true }));
              schoolInput.dispatchEvent(new Event("change", { bubbles: true }));
              schoolInput.blur();
              await sleep(180);
              schoolOk = normalizeText(schoolInput.value) === normalizeText(schoolValue);
            }

            // 主流程：先输入完整学校名称并查询，再从缩小后的结果中做精确匹配。
            // 打开时完整列表里的同名节点只保留为兜底，不优先点击。
            var fullListOption = schoolDialog && Array.from(schoolDialog.querySelectorAll("#selectorBody a")).find(function (node) {
              return normalizeText(node.textContent) === normalizeText(schoolValue);
            });
            var searchInput = schoolDialog && await waitUntil(function () {
              if (!schoolDialog || !isVisible(schoolDialog)) return null;
              return Array.from(schoolDialog.querySelectorAll("input")).find(function (input) {
                return isVisible(input) && /查询院校/.test(input.placeholder || "");
              }) || null;
            }, item.searchInputTimeoutMs || 3500);
            if (searchInput) {
              // 尽量模拟真实键盘输入：focus + select + insertText。execCommand 会触发
              // 更接近用户输入的编辑流程；不支持时再退回原生 setter + InputEvent。
              var schoolSearchSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
              try { searchInput.focus(); } catch (e5) {}
              try { searchInput.select(); } catch (e6) {}
              var insertedByCommand = false;
              try {
                insertedByCommand = !!(document.execCommand && document.execCommand("insertText", false, String(schoolValue)));
              } catch (e7) {}
              if (!insertedByCommand || normalizeText(searchInput.value) !== normalizeText(schoolValue)) {
                if (schoolSearchSetter && schoolSearchSetter.set) schoolSearchSetter.set.call(searchInput, String(schoolValue));
                else searchInput.value = String(schoolValue);
              }
              searchInput.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, data: String(schoolValue), inputType: "insertText" }));
              searchInput.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: String(schoolValue).slice(-1) }));
              searchInput.dispatchEvent(new Event("change", { bubbles: true }));
              // 给 Angular FormControl 一次变更检测时间，再点击查询。
              await sleep(item.waitAfterInputMs == null ? 260 : item.waitAfterInputMs);
              var searchRoot = searchInput.closest && searchInput.closest(".input-group");
              var searchButton = searchRoot && Array.from(searchRoot.querySelectorAll("button")).find(isVisible);
              if (searchButton) {
                try { searchButton.click(); } catch (e8) { await safeClick(searchButton); }
              }
              await sleep(item.waitAfterSearchMs == null ? 450 : item.waitAfterSearchMs);
              var schoolOption = await waitUntil(function () {
                if (!schoolDialog) return null;
                var resultRoot = schoolDialog.querySelector("#selectorBody") || schoolDialog;
                return Array.from(resultRoot.querySelectorAll("a, button, [role='option']")).filter(isVisible).find(function (node) {
                  return normalizeText(node.textContent) === normalizeText(schoolValue);
                }) || null;
              }, item.optionTimeoutMs || 6500);
              if (schoolOption) {
                try { schoolOption.click(); } catch (e9) { await safeClick(schoolOption); }
                schoolOk = !!(await waitUntil(function () {
                  var searchedSchoolScope = refreshSequenceScope(step, scope);
                  var searchedSchoolInput = searchedSchoolScope && searchedSchoolScope.querySelector("input#SchoolName, input[id='SchoolName']");
                  return searchedSchoolInput && normalizeText(searchedSchoolInput.value) === normalizeText(schoolValue) ? searchedSchoolInput : null;
                }, item.schoolWritebackTimeoutMs || 4500));
              }
            }

            // 查询控件未响应时才使用打开弹窗时捕获的完整学校库节点兜底。
            if (!schoolOk && fullListOption && fullListOption.isConnected) {
              try {
                fullListOption.scrollIntoView({ block: "center", inline: "nearest" });
                fullListOption.click();
              } catch (e10) {
                await safeClick(fullListOption);
              }
              schoolOk = !!(await waitUntil(function () {
                var fallbackSchoolScope = refreshSequenceScope(step, scope);
                var fallbackSchoolInput = fallbackSchoolScope && fallbackSchoolScope.querySelector("input#SchoolName, input[id='SchoolName']");
                return fallbackSchoolInput && normalizeText(fallbackSchoolInput.value) === normalizeText(schoolValue) ? fallbackSchoolInput : null;
              }, item.schoolWritebackTimeoutMs || 4500));
            }
          }

          // 无论弹窗是否自动关闭，都以当前第 N 条记录里的真实 input 值为准。
          if (!schoolOk) {
            schoolOk = !!(await waitUntil(function () {
              var refreshedSchoolScope = refreshSequenceScope(step, scope);
              var refreshedSchoolGroup = refreshedSchoolScope && Array.from(refreshedSchoolScope.querySelectorAll(".form-group")).find(function (group) {
                var groupLabel = Array.from(group.querySelectorAll("label")).find(function (node) {
                  return normalizeText(node.textContent).indexOf(normalizeText(item.label)) !== -1;
                });
                return !!groupLabel;
              });
              var refreshedSchoolInput = refreshedSchoolGroup && Array.from(refreshedSchoolGroup.querySelectorAll("input:not([type='hidden'])")).find(isVisible);
              return refreshedSchoolInput && normalizeText(refreshedSchoolInput.value) === normalizeText(schoolValue) ? refreshedSchoolInput : null;
            }, item.schoolWritebackTimeoutMs || 4500));
          }

          var dialogStillOpen = schoolDialog && isVisible(schoolDialog);
          if (dialogStillOpen) {
            var closeSchoolDialog = Array.from(schoolDialog.querySelectorAll("button, a, [role='button']")).filter(isVisible).find(function (node) {
              var closeText = normalizeText(node.textContent || node.getAttribute("aria-label") || node.getAttribute("title"));
              return closeText === "关闭" || closeText === "Close" || closeText === "×";
            });
            if (closeSchoolDialog) {
              try { closeSchoolDialog.click(); } catch (e11) { await safeClick(closeSchoolDialog); }
              await sleep(180);
            }
          }
        }
        if (schoolOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "院校搜索弹窗填写失败" });
      } else if (item.type === "cmbcProvinceText" || item.type === "cmbcPhone") {
        var compoundGroup = label.closest && label.closest(".form-group");
        var compoundFields = item.dataFields || [];
        var compoundSelectValue = data && data[compoundFields[0]];
        var compoundTextValue = data && data[compoundFields[1]];
        var compoundSelect = compoundGroup && Array.from(compoundGroup.querySelectorAll(".ui-dropdown")).find(isVisible);
        var compoundInput = compoundGroup && Array.from(compoundGroup.querySelectorAll("input:not([type='hidden']):not([type='file']):not([readonly])")).find(isVisible);
        var compoundSelectOk = !hasMeaningfulValue(compoundSelectValue);
        var compoundTextOk = !hasMeaningfulValue(compoundTextValue);
        if (item.preserveExisting && compoundInput && String(compoundInput.value || "").trim()) {
          engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
          await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
          continue;
        }
        if (compoundSelect && hasMeaningfulValue(compoundSelectValue)) {
          await safeClick(compoundSelect);
          var compoundOption = await waitUntil(function () {
            try {
              return Array.from(document.querySelectorAll(".ui-dropdown-item")).filter(isVisible).find(function (node) {
                var optionText = normalizeText(node.textContent);
                var wantedText = normalizeText(compoundSelectValue);
                return optionText === wantedText || optionText.indexOf(wantedText) !== -1 || wantedText.indexOf(optionText) !== -1;
              }) || null;
            } catch (e) { return null; }
          }, item.optionTimeoutMs || 2500);
          if (compoundOption) {
            await safeClick(compoundOption);
            compoundSelectOk = true;
          }
        }
        if (compoundInput && hasMeaningfulValue(compoundTextValue)) {
          compoundTextOk = await AF.FormHandler.fillFormElement(compoundInput, compoundTextValue, "text");
        }
        if (compoundSelectOk && compoundTextOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: compoundFields.join("+"), label: String(item.label), reason: "组合下拉/文本字段填写失败" });
      } else if (item.type === "zhaopinEducationLevel") {
        var zhaopinEducationLevelValue = data && data[item.field];
        var zhaopinEducationLevelOk = await fillZhaopinEducationLevel(zhaopinEducationLevelValue, item, scope);
        if (zhaopinEducationLevelOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else failed.push({ fieldKey: item.field, label: String(item.label), reason: "智联学历下拉未成功选择或后续教育表单未出现" });
      } else if (item.type === "zhaopinSearchSelect") {
        var zhaopinSearchValue = data && data[item.field];
        var zhaopinSearchOk = await fillZhaopinSearchSelect(zhaopinSearchValue, item, scope);
        if (zhaopinSearchOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "智联搜索选择失败" });
      } else if (item.type === "zhaopinSchoolSelect") {
        var zhaopinSchoolValue = data && data[item.field];
        var zhaopinSchoolOk = await fillZhaopinSchoolSelect(label, zhaopinSchoolValue, item, scope);
        if (zhaopinSchoolOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "智联学校选择失败" });
      } else if (item.type === "zhaopinPsbcHighSchoolSelect") {
        var zhaopinPsbcHighSchoolValue = data && data[item.field];
        var zhaopinPsbcHighSchoolOk = await fillZhaopinPsbcHighSchoolSelect(label, zhaopinPsbcHighSchoolValue, item, scope);
        if (zhaopinPsbcHighSchoolOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "邮储高中学校选择失败" });
      } else if (item.type === "zhaopinCampusDate") {
        var zhaopinCampusDateValue = data && data[item.field];
        var zhaopinCampusDateOk = await fillZhaopinCampusDate(matcher, label, zhaopinCampusDateValue, item, scope);
        if (zhaopinCampusDateOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) {
          var zhaopinCampusDateStage = readElementMonthStage(item);
          failed.push({
            fieldKey: item.field,
            label: String(item.label),
            reason: zhaopinCampusDateStage === "day_precision_required"
              ? "日期控件要求具体到日；个人资料当前只精确到月份，已停止自动填写以避免编造日期"
              : "智联校园日期填写或延迟回读失败"
          });
        }
      } else if (item.type === "zhaopinWorkEndDate") {
        var zhaopinWorkEndValue = data && data[item.field];
        var zhaopinWorkEndOk = await fillZhaopinWorkEndDate(label, zhaopinWorkEndValue, item, scope);
        if (zhaopinWorkEndOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "在职结束月份/至今填写失败" });
      } else if (item.type === "zhaopinText") {
        var zhaopinTextValue = data && data[item.field];
        var zhaopinTextOk = await fillZhaopinText(zhaopinTextValue, item, scope);
        if (zhaopinTextOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "文本框精确填写失败" });
      } else if (item.type === "zhaopinIndustryCascader" || item.type === "zhaopinPositionCascader") {
        var zhaopinTaxonomyValue = data && data[item.field];
        var zhaopinTaxonomyKind = item.type === "zhaopinIndustryCascader" ? "industry" : "position";
        var zhaopinTaxonomyOk = await fillZhaopinTaxonomyCascader(zhaopinTaxonomyValue, item, scope, zhaopinTaxonomyKind);
        if (zhaopinTaxonomyOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "智联专用分类路径选择失败" });
      } else if (item.type === "zhaopinSkillGroups") {
        var zhaopinSkillGroupsValue = data && data[item.field];
        var zhaopinSkillGroupsOk = await fillZhaopinSkillGroups(zhaopinSkillGroupsValue, item, scope);
        if (zhaopinSkillGroupsOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "智联拥有技能弹窗填写失败" });
      } else if (item.type === "zhaopinDialogSelect") {
        var zhaopinDialogValue = data && data[item.field];
        var zhaopinDialogItem = Object.assign({}, item, { _labelElement: label });
        var zhaopinDialogOk = await fillZhaopinDialogSelect(zhaopinDialogValue, zhaopinDialogItem, scope);
        if (zhaopinDialogOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "智联分类选择失败" });
      } else if (item.type === "zhaopinAdministrativeArea") {
        var zhaopinAdministrativeValue = data && data[item.field];
        var zhaopinAdministrativeItem = Object.assign({}, item, { _labelElement: label });
        var zhaopinAdministrativeOk = await fillZhaopinAdministrativeArea(
          zhaopinAdministrativeValue, zhaopinAdministrativeItem, scope
        );
        if (zhaopinAdministrativeOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "行政区级联选择失败" });
      } else if (item.type === "zhaopinPhone") {
        var zhaopinPhoneOk = await fillZhaopinPhone(label, data && data[item.field], item, scope);
        if (zhaopinPhoneOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "智联手机号区号/号码填写失败" });
      } else if (item.type === "zhaopinChoice") {
        var zhaopinChoiceValue = data && data[item.field];
        var zhaopinChoiceItem = step && step.higherEducationVariant === true ? Object.assign({}, item, { __recordIndex: step.repeatIndex || 0 }) : item;
        var zhaopinChoiceOk = false;
        if (step && step.higherEducationVariant === true && higherFieldBinding && higherFieldBinding.control && higherFieldBinding.detectedType) {
          zhaopinChoiceOk = await AF.FormHandler.fillFormElement(higherFieldBinding.control, zhaopinChoiceValue, higherFieldBinding.detectedType);
        }
        if (!zhaopinChoiceOk) zhaopinChoiceOk = await fillZhaopinChoice(label, zhaopinChoiceValue, zhaopinChoiceItem, scope);
        if (zhaopinChoiceOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "智联单选填写失败" });
        if (step && step.higherEducationVariant === true) appendHigherEducationFieldTrace({ recordIndex: step.repeatIndex || 0, fieldKey: String(item.field || ""), label: String(item.label || ""), valueAvailable: hasMeaningfulValue(zhaopinChoiceValue), scopeResolved: !!scope, labelFound: !!label, controlFound: !!(label && label.parentElement), controlType: "choice", alreadyCorrect: false, executionPath: "zhaopin_choice", committed: !!zhaopinChoiceOk, reason: zhaopinChoiceOk ? "" : "option_not_found_or_commit_failed" });
      } else if (item.type === "zhaopinCheckbox") {
        var zhaopinCheckboxValue = data && data[item.field];
        var zhaopinCheckboxOk = await fillZhaopinCheckbox(label, zhaopinCheckboxValue, item, scope);
        if (zhaopinCheckboxOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "智联复选填写失败" });
      } else if (item.type === "cmbchinaCompany") {
        var cmbchinaCompanyValue = data && data[item.field];
        var cmbchinaCompanyItem = label.closest && label.closest(".ant-form-item");
        var cmbchinaCompanyOk = false;
        if (cmbchinaCompanyItem && hasMeaningfulValue(cmbchinaCompanyValue)) {
          var cmbchinaFreeLabel = Array.from(cmbchinaCompanyItem.querySelectorAll("label.ant-checkbox-wrapper, label")).find(function (node) {
            return normalizeText(node.textContent).indexOf("未搜索到选项，自行填写") !== -1;
          });
          var cmbchinaFreeInput = cmbchinaFreeLabel && cmbchinaFreeLabel.querySelector("input[type='checkbox']");
          if (cmbchinaFreeLabel && cmbchinaFreeInput && !cmbchinaFreeInput.checked) {
            await safeClick(cmbchinaFreeLabel);
            await sleep(120);
          }
          var cmbchinaCompanyInput = Array.from(cmbchinaCompanyItem.querySelectorAll("input[type='text']:not([type='hidden'])")).find(isVisible);
          if (cmbchinaCompanyInput) {
            cmbchinaCompanyOk = await AF.FormHandler.fillFormElement(cmbchinaCompanyInput, cmbchinaCompanyValue, "text");
          }
        }
        if (cmbchinaCompanyOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "招商银行工作单位自由填写失败" });
      } else if (item.type === "primeDropdown") {
        var dropdownValue = data && data[item.field];
        var dropdownGroup = label.closest && label.closest(".form-group");
        var dropdownTrigger = dropdownGroup && Array.from(dropdownGroup.querySelectorAll(".ui-dropdown")).find(isVisible);
        var dropdownOk = false;
        if (item.preserveExisting && dropdownTrigger && controlHasExistingValue(dropdownTrigger)) {
          engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
          await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
          continue;
        }
        if (dropdownTrigger && hasMeaningfulValue(dropdownValue)) {
          await safeClick(dropdownTrigger);
          var dropdownOption = await waitUntil(function () {
            try {
              return Array.from(document.querySelectorAll(".ui-dropdown-item")).filter(isVisible).find(function (node) {
                var optionText = normalizeText(node.textContent);
                var wanted = normalizeText(dropdownValue);
                return optionText === wanted || optionText.indexOf(wanted) !== -1 || wanted.indexOf(optionText) !== -1;
              }) || null;
            } catch (e) { return null; }
          }, item.optionTimeoutMs || 2500);
          if (dropdownOption) {
            await safeClick(dropdownOption);
            dropdownOk = true;
          }
        }
        if (dropdownOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "PrimeNG下拉填写失败" });
      } else if (item.type === "yearMonth") {
        var rawDate = data && data[item.field];
        var dateText = String(rawDate == null ? "" : rawDate).trim();
        if (/^至今$/.test(dateText)) {
          var now = new Date();
          dateText = now.getFullYear() + "-" + String(now.getMonth() + 1).padStart(2, "0");
        }
        var match = dateText.match(/(\d{4})[^\d]?(\d{1,2})?/);
        var fieldItem = label.closest && label.closest(".floor_view_editor_item");
        var selects = fieldItem ? Array.from(fieldItem.querySelectorAll(".select_box")) : [];
        var yearMonthOk = false;
        if (match && selects.length >= 2 && AF.SelectAdapter && AF.SelectAdapter.create) {
          var yearOk = await AF.SelectAdapter.create(selects[0], "string").selectValue(match[1]);
          await sleep(120);
          var monthValue = String(Number(match[2] || 1)).padStart(2, "0");
          var monthOk = await AF.SelectAdapter.create(selects[1], "string").selectValue(monthValue);
          yearMonthOk = !!(yearOk && monthOk);
        }
        if (yearMonthOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "年月下拉填写失败" });
      } else if (item.type === "hsbankEndDate") {
        var hsbankEndDateValue = data && data[item.field];
        var hsbankEndDateOk = await fillHsbankEndDate(label, hsbankEndDateValue, item);
        if (hsbankEndDateOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "徽商银行结束时间/至今填写失败" });
      } else if (item.type === "currentEndOrDate") {
        var currentEndValue = data && data[item.field];
        var currentEndOk = false;
        if (isCurrentEndText(currentEndValue)) {
          currentEndOk = await clickCurrentEndNearLabel(label, scope);
        } else if (hasMeaningfulValue(currentEndValue)) {
          var currentEndFound = resolveSequenceControlByConfiguredType(matcher, label, item, scope);
          if (currentEndFound && currentEndFound.element && currentEndFound.type) {
            currentEndOk = await AF.FormHandler.fillFormElement(currentEndFound.element, currentEndValue, currentEndFound.type);
          }
        }
        if (currentEndOk) engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
        else if (item.optional !== true) failed.push({ fieldKey: item.field, label: String(item.label), reason: "终止时间/至今填写失败" });
      } else {
        var itemValue = data && data[item.field];
        if (item.field === "degree" && /^applyjob\.chinahr\.com$/i.test(window.location.hostname) && category === "education") {
          var degreeText = String(itemValue == null ? "" : itemValue).trim();
          if (/^(?:无|无学位|未取得|未获得)/.test(degreeText)) itemValue = "无学位";
          else if (/博士/.test(degreeText)) itemValue = "博士";
          else if (/硕士|研究生|MBA|EMBA/i.test(degreeText)) itemValue = "硕士";
          else if (/学士|本科|大学/i.test(degreeText)) itemValue = "学士";
          else if (/专科|大专|专科学历/i.test(degreeText)) itemValue = "大专";
        }
        if ((item.field === "workType" || item.field === "employmentType" || item.field === "jobNature") &&
            /^applyjob\.chinahr\.com$/i.test(window.location.hostname) &&
            category === "internshipExperience") {
          var workTypeText = String(itemValue == null ? "" : itemValue).trim();
          if (/实习/.test(workTypeText)) itemValue = "实习（未毕业在校生兼职或实习）";
          else if (/兼职/.test(workTypeText)) itemValue = "兼职";
          else if (/全职|正式/.test(workTypeText)) itemValue = "全职";
        }
        if (!hasMeaningfulValue(itemValue) && item.defaultValue != null) itemValue = item.defaultValue;
        if (typeof item.valueTransform === "function") {
          try { itemValue = item.valueTransform(itemValue, data, category); } catch (e) {}
        }
        // 简历没有该字段时保留网站原值。注册阶段预填、脱敏或锁定字段不应因此
        // 阻断整个分区保存，也不能让后续步骤继续复用这个未关闭编辑区。
        if (!hasMeaningfulValue(itemValue)) {
          if (step.failOnMissingRequiredValue === true && item.optional !== true) {
            failed.push({ fieldKey: item.field, label: String(item.label), reason: "简历中缺少必填字段值，已阻止提前保存" });
          }
          await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
          continue;
        }
        // 特殊站点的 fieldSequence 已经明确给出了“哪个标签填哪个值”，这里直接
        // 驱动控件，不再让通用字典二次猜字段。这样 ccbEnglishLevel、ccbSchoolType
        // 等站点派生字段不会因为通用别名优先级而取到错误 key。
        var found = null;
        if (step && step.higherEducationNavigationAdapter === true) {
          found = resolveHigherEducationNavigationControl(scope, label, item);
        }
        if (!found) {
          found = step && step.higherEducationVariant === true ? null : resolveSequenceControlByConfiguredType(matcher, label, item, scope);
        }
        if (step && step.higherEducationVariant === true && item.type === "elementDate") {
          var resolvedHigherDateBinding = getHigherEducationRuntimeBinding(step.repeatIndex || 0, item.field);
          var higherDateBinding = resolvedHigherDateBinding && resolvedHigherDateBinding.binding || resolveControlFromLabel(label, "date", scope);
          var higherDateControl = resolvedHigherDateBinding && resolvedHigherDateBinding.control || higherDateBinding.element;
          if (higherDateControl) found = { element: higherDateControl, type: "date" };
          var higherDateControlTrace = { fieldKey: String(item.field || ""), labelTag: String(label && label.tagName || "").toLowerCase(), labelClass: String(label && label.className || ""), parentTag: String(label && label.parentElement && label.parentElement.tagName || "").toLowerCase(), parentClass: String(label && label.parentElement && label.parentElement.className || ""), fieldItemResolved: !!higherDateBinding.fieldItem, fieldItemResolutionStrategy: higherDateBinding.fieldItemStrategy, contentResolved: !!higherDateBinding.content, contentControlCount: higherDateBinding.contentControlCount, candidateControlCount: higherDateBinding.candidates.length, expectedType: "date", selectedTag: String(higherDateControl && higherDateControl.tagName || "").toLowerCase(), selectedClass: String(higherDateControl && higherDateControl.className || ""), reason: higherDateBinding.reason || "" };
        }
        // Ping An keeps a disabled autocomplete from the saved/display record
        // beside the active editor. Label matching can legitimately reach that
        // older form item first. For an input-search field, hand the engine the
        // currently visible editable autocomplete instead of the stale node.
        if (item.trustedAutocomplete) {
          var foundAutocompleteIsUsable = !!(
            found && found.type === "autocomplete" && found.element &&
            isVisible(found.element) && !found.element.disabled && !found.element.readOnly
          );
          if (!foundAutocompleteIsUsable) {
            var liveAutocompleteRoot = refreshSequenceScope(step, scope) || scope || document;
            var liveAutocompleteInputs = [];
            try {
              liveAutocompleteInputs = Array.from(liveAutocompleteRoot.querySelectorAll(
                ".el-autocomplete input.el-input__inner:not([disabled]):not([readonly]), input[aria-autocomplete='list']:not([disabled]):not([readonly]), input[fetchsuggestions]:not([disabled]):not([readonly])"
              )).filter(isVisible);
            } catch (eLiveAutocomplete) {}
            var liveAutocompleteIndex = Math.max(0, Number(item && item.autocompleteIndex) || 0);
            if (liveAutocompleteInputs.length) {
              found = { type: "autocomplete", element: liveAutocompleteInputs[liveAutocompleteIndex] || liveAutocompleteInputs[0] };
            }
          }
        }
        var directOk = false;
        var higherEducationAlreadyCorrect = false;
        if (found && found.element && found.type) {
          // 智联高等教育中的“学制 / 是否贯通式培养 / 年级排名”等下拉会在
          // 前置字段联动后局部重绘。通用 matcher 可能仍持有刚刚被替换的
          // select 节点，因此在真正写值前只对该教育编辑器重新绑定一次当前字段。
          // 这仍然只负责 label -> control，不另造填写逻辑。
          if (step && step.higherEducationNavigationAdapter === true && found.type === "select") {
            try {
              var freshHigherSelect = resolveHigherEducationNavigationControl(scope, label, item);
              if (freshHigherSelect && freshHigherSelect.element && freshHigherSelect.type === "select") {
                found = freshHigherSelect;
              }
            } catch (eFreshHigherSelect) {}
          }
          if (item.preserveExisting && controlHasExistingValue(found.element)) {
            engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
            await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
            continue;
          }
          if (AF.FillTrace && typeof AF.FillTrace.setFieldContext === "function") {
            AF.FillTrace.setFieldContext({
              category: category,
              label: String(item.label),
              fieldKey: item.field,
              plannedValue: itemValue,
            });
          }
          // 特殊站点只负责“字段编排 + 给值”，Element 下拉/级联的真实点击
          // 优先交回统一 SelectAdapter。这样浙商这类 Element Plus 表单能复用
          // 现有 element / element-cascader 能力，不再在特殊流程里另造一套选择器。
          var isElementMonthDate = item.type === "elementDate" && isYearMonthOnlyValue(itemValue) &&
            (isElementMonthDateControl(found.element) || item.forceElementMonthPanel === true);
          // 智联高等教育的必填排名等字段不能用“input 显示了文字”作为成功判据。
          // 这些字段必须真实点击候选并通过 Vue model/校验状态的持久化验证。
          if (!isElementMonthDate && step && step.higherEducationNavigationAdapter === true &&
              found.type === "select" && item.requirePersistentSelectCommit === true) {
            try {
              directOk = await fillPersistentElementSelectChoice(found.element, itemValue, item);
              if (directOk) higherEducationAlreadyCorrect = true;
            } catch (ePersistentHigherSelect) {
              directOk = false;
            }
          }
          // 有些 Element Select 已经被前一次框架事件正确写入，但适配器因为
          // 面板已关闭而返回 false。对当前、可见、精确绑定的教育字段先做
          // read-back；目标值已真实显示时直接视为提交成功，避免重复打开下拉。
          if (!directOk && step && step.higherEducationNavigationAdapter === true && found.type === "select" && item.requirePersistentSelectCommit !== true) {
            try {
              var higherSelectContainer = found.element.closest && found.element.closest(".el-select, .el-cascader") || found.element;
              if (higherSelectContainer && elementChoiceValueMatches(higherSelectContainer, itemValue)) {
                directOk = true;
                higherEducationAlreadyCorrect = true;
              }
            } catch (eHigherAlreadyCorrect) {}
          }
          if (!directOk && isElementMonthDate) {
            directOk = await fillElementMonthPicker(found.element, itemValue, item);
          }
          if (
            !isElementMonthDate &&
            AF.SelectAdapter && typeof AF.SelectAdapter.create === "function" &&
            item.type === "customSelect" &&
            found.element instanceof Element
          ) {
            directOk = await AF.SelectAdapter.create(
              found.element,
              typeof itemValue === "object" ? "object" : "string",
              null,
              item.customSelectors || {}
            ).selectValue(itemValue);
          }
          if (
            !directOk &&
            !isElementMonthDate &&
            found.type === "autocomplete" &&
            (!item.trustedAutocomplete || item.useSelectAdapterFirst) &&
            AF.SelectAdapter && typeof AF.SelectAdapter.create === "function" &&
            found.element instanceof Element
          ) {
            var autocompleteAdapterValue = item.selectFirstOption === true
              ? { name: itemValue, selectFirstOption: true, requireBlurAfterSelect: !!item.requireBlurAfterSelect }
              : itemValue;
            directOk = await AF.SelectAdapter.create(
              found.element,
              typeof itemValue === "object" ? "object" : "string"
            ).selectValue(autocompleteAdapterValue);
          }
          if (
            !directOk &&
            !isElementMonthDate &&
            found.type === "autocomplete"
          ) {
            // A trusted autocomplete must reach fillElementAutocomplete first.
            // The generic adapter can mistake a temporary DOM value for a
            // committed selection and return true before Ping An stores the
            // school's hidden code, skipping the trusted browser-input bridge.
            directOk = await fillElementAutocomplete(found.element, itemValue, item);
          }
          if (
            !directOk &&
            !isElementMonthDate &&
            AF.SelectAdapter && typeof AF.SelectAdapter.create === "function" &&
            item.requirePersistentSelectCommit !== true &&
            /^(elementSelect|elementCascader|elementSelectOrText)$/.test(String(item.type || "")) &&
            found.element instanceof Element &&
            found.element.closest &&
            found.element.closest(".el-select, .el-cascader, .ant-select")
          ) {
            var elementAdapterValue = item.selectFirstOption === true
              ? { name: itemValue, selectFirstOption: true, fallbackFirst: true, allowFirstOption: true }
              : itemValue;
            directOk = await AF.SelectAdapter.create(
              found.element,
              typeof itemValue === "object" ? "object" : "string"
            ).selectValue(elementAdapterValue);
          }
          // elementDate 是日期面板，不是普通 Element 下拉。此前会先进入
          // fillScopedElementChoice 查找“2019-09-01”这样的选项，失败时还把日期
          // 面板留在半打开状态，导致开始时间失败、后一个结束时间反而借残留面板
          // 成功。普通选项兜底只允许选择类字段使用，日期直接交给 DatePicker。
          var canUseElementChoiceFallback = /^(elementSelect|elementCascader|elementSelectOrText|customSelect)$/.test(String(item.type || ""));
          if (!directOk && !isElementMonthDate && item.requirePersistentSelectCommit !== true && canUseElementChoiceFallback) {
            directOk = await fillScopedElementChoice(found.element, itemValue, item);
          }
          // 智联高等教育的字段 schema 使用通用 type="select"。大多数下拉
          // FormHandler 可以直接处理，但动态出现的学制/贯通培养/排名有时会
          // “值已经写入、面板已经收起”却返回 false。仅在当前教育编辑器内，
          // 对真实 Element Select/Cascader 再走一次严格绑定的精确候选兜底。
          if (!directOk && !isElementMonthDate && item.requirePersistentSelectCommit !== true && step && step.higherEducationNavigationAdapter === true &&
              found.type === "select" && found.element && found.element.closest &&
              found.element.closest(".el-select, .el-cascader")) {
            try {
              directOk = await fillScopedElementChoice(
                found.element,
                itemValue,
                Object.assign({}, item, { strictCurrentControl: true, panelTimeoutMs: item.panelTimeoutMs || 2200, optionTimeoutMs: item.optionTimeoutMs || 2200 })
              );
            } catch (eHigherSelectFallback) {
              directOk = false;
            }
          }
          // Zhaopin's rank field is an Element Select whose popper can remain mounted
          // outside the form and fail the generic "visible panel" lookup.  Use the
          // select's own aria-controls/aria-owns relationship as a final exact-control
          // fallback before giving up.  This is scoped to the already-bound control,
          // so an unrelated "其他" option in another field cannot be clicked.
          if (!directOk && !isElementMonthDate && item.requirePersistentSelectCommit !== true && step && step.higherEducationNavigationAdapter === true &&
              found.type === "select" && found.element && found.element.closest &&
              found.element.closest(".el-select")) {
            try {
              directOk = await forceCommitElementChoiceViaAria(found.element, itemValue, item);
            } catch (eHigherAriaFallback) {
              directOk = false;
            }
          }
          if (!directOk && !isElementMonthDate && found.type !== "autocomplete" && item.requirePersistentSelectCommit !== true) {
            directOk = await AF.FormHandler.fillFormElement(found.element, itemValue, found.type);
          }
          if (!directOk && !isElementMonthDate && item.requirePersistentSelectCommit !== true && step && step.higherEducationNavigationAdapter === true &&
              found.type === "select" && found.element && found.element.closest) {
            try {
              var finalHigherSelect = found.element.closest(".el-select, .el-cascader") || found.element;
              if (elementChoiceValueMatches(finalHigherSelect, itemValue)) {
                directOk = true;
                higherEducationAlreadyCorrect = true;
              }
            } catch (eHigherFinalReadback) {}
          }
        }
        if (directOk && (item.afterSelectReadyLabel || item.afterSelectReadySelector)) {
          directOk = await waitForFieldReadyAfterSelection(scope, item);
        }
        if (directOk && item.postSelectConfirmText) {
          var postSelectConfirm = await waitUntil(function () {
            var dialogs = [];
            try {
              dialogs = Array.from(document.querySelectorAll(item.postSelectConfirmSelector || ".ant-modal-confirm"));
            } catch (eConfirmSelector) {}
            return dialogs.filter(isVisible).find(function (dialog) {
              return normalizeText(dialog.textContent).indexOf(normalizeText(item.postSelectConfirmText)) !== -1;
            }) || null;
          }, item.postSelectConfirmTimeoutMs || 2500);
          if (postSelectConfirm) {
            var confirmTexts = Array.isArray(item.postSelectConfirmButtonText)
              ? item.postSelectConfirmButtonText
              : [item.postSelectConfirmButtonText || "确定"];
            var postSelectConfirmButton = findByText(
              postSelectConfirm,
              confirmTexts,
              item.postSelectConfirmButtonSelector || "button, a, [role='button']"
            );
            if (postSelectConfirmButton) {
              await safeClick(postSelectConfirmButton);
              var postSelectClosed = await waitUntil(function () {
                return !isVisible(postSelectConfirm) ? true : null;
              }, item.postSelectConfirmCloseTimeoutMs || 2500);
              if (!postSelectClosed) directOk = false;
            } else {
              directOk = false;
            }
          }
        }
        if (directOk) {
          engine.formHandler.filledFieldsCount = (engine.formHandler.filledFieldsCount || 0) + 1;
          if (step.blockSaveUntilField && item.field === step.blockSaveUntilField) {
            step.__afSequenceSaveGuardUnlocked = true;
          }
        } else if (item.optional !== true) {
          var elementMonthStage = item.type === "elementDate" ? readElementMonthStage(item) : "";
          var directFailureReason = elementMonthStage === "day_precision_required"
            ? "日期控件要求具体到日；个人资料当前只精确到月份，已停止自动填写以避免编造日期"
            : (item.__trustedAutocompleteError
              ? "可信候选输入失败：" + item.__trustedAutocompleteError
              : (found && found.element
                ? (found.type === "select"
                  ? summarizeElementChoiceFailure(found.element, itemValue)
                  : (found.type === "date"
                    ? "日期控件写入/读回失败；目标=" + String(itemValue == null ? "" : itemValue)
                    : "文本控件写入/读回失败；目标=" + String(itemValue == null ? "" : itemValue) +
                      "；当前=" + String(found.element && found.element.value || "空")))
                : "依赖字段填写失败"));
          failed.push({
            fieldKey: item.field,
            label: String(item.label),
            reason: directFailureReason,
          });
        }
        if (step && step.higherEducationVariant === true && item && item.higherEducationField === true) {
          appendHigherEducationFieldTrace({ recordIndex: step.repeatIndex || 0, fieldKey: String(item.field || ""), label: String(item.label || ""), valueAvailable: hasMeaningfulValue(itemValue), scopeResolved: !!scope, labelFound: !!label, controlFound: !!(found && found.element), controlType: found && found.type || String(item.type || ""), alreadyCorrect: false, executionPath: item.type === "elementDate" ? "label_field_item_date" : "configured_control", committed: !!directOk, reason: directOk ? "" : (found && found.element ? "commit_failed" : "control_not_found"), labelControlTrace: item.type === "elementDate" && typeof higherDateControlTrace !== "undefined" ? higherDateControlTrace : undefined });
        }
        if (step && step.higherEducationNavigationAdapter === true && item && item.higherEducationField === true) {
          appendHigherEducationFieldTrace({
            educationRecordIndex: Number.isInteger(step.repeatIndex) ? step.repeatIndex : 0,
            fieldKey: String(item.field || ""),
            genericMatcherFound: !!(found && found.element),
            detectedType: String(found && found.type || ""),
            alreadyCorrect: !!higherEducationAlreadyCorrect,
            committed: !!directOk,
            reason: directOk ? "" : (found && found.element ? "commit_failed" : "control_not_found")
          });
        }
      }
      if (step && step.__afCheckpointActionCursorEnabled === true) {
        if (failed.length > failedCountBeforeAction) {
          var nextFieldIndex = i + 1;
          sequenceActionCursor = {
            currentAction: currentSequenceActionId,
            nextAction: nextFieldIndex < step.fieldSequence.length
              ? specialSequenceActionId(step.fieldSequence[nextFieldIndex], nextFieldIndex)
              : "SAVE",
            failedFieldIndex: i,
            resumeFieldIndex: nextFieldIndex,
            completedActions: sequenceCompletedActions.slice(0, 200),
            acknowledgeCurrentActionOnRerun: true,
            sequencePhase: String(step && step.__afSequencePhase || "main")
          };
          break;
        }
        if (sequenceCompletedActions.indexOf(currentSequenceActionId) === -1) {
          sequenceCompletedActions.push(currentSequenceActionId);
        }
      }
      await sleep(item.waitAfterMs == null ? 120 : item.waitAfterMs);
    }

    var filled = (engine.formHandler.filledFieldsCount || 0) - before;
    if (removeSequenceSaveGuard) removeSequenceSaveGuard();
    return {
      success: failed.length === 0,
      message: failed.length ? "依赖字段填写未完成" : "依赖字段按顺序填写完成",
      filledCount: Math.max(0, filled),
      failedFields: failed,
      totalFieldsFound: step.fieldSequence.length,
      sequenceActionCursor: sequenceActionCursor,
      completedActions: sequenceCompletedActions.slice(0, 200),
      replayStartIndex: recoveryStartIndex
    };
  }

  async function ensureFieldsBeforeSave(engine, matcher, step, data, category, scope) {
    var items = Array.isArray(step.beforeSaveEnsureFields) ? step.beforeSaveEnsureFields : [];
    var ensuredKeys = [];
    var failedFields = [];
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      if (typeof item.when === "function") {
        var shouldEnsureItem = true;
        try {
          shouldEnsureItem = item.when(data, category, step, scope) !== false;
        } catch (eEnsureWhen) {
          shouldEnsureItem = false;
        }
        if (!shouldEnsureItem) continue;
      }
      var expected = data && data[item.field];
      if (!hasMeaningfulValue(expected)) continue;

      function currentFieldAccepted() {
        var liveScope = refreshSequenceScope(step, scope) || scope || document;
        if (step && step.higherEducationNavigationAdapter === true) {
          liveScope = resolveLiveHigherEducationFormScope(liveScope) || liveScope;
        }
        var labels = matcher.findLabelsByCard(liveScope) || [];
        if (!labels.length) labels = matcher.findAllLabels() || [];
        var label = findLabelForSequence(labels, item.label);
        if (!label && item && item.zhaopinRepeatLocalBinding === true) {
          label = findZhaopinRepeatLocalLabel(liveScope, item.label);
        }
        if (step && step.higherEducationNavigationAdapter === true) {
          label = findLiveHigherEducationLabel(liveScope, item, label) || label;
        }
        if (!label) return false;
        var found = null;
        if (step && step.higherEducationNavigationAdapter === true) {
          found = resolveHigherEducationNavigationControl(liveScope, label, item);
        }
        found = found || resolveSequenceControlByConfiguredType(matcher, label, item, scope);
        if (!found || !found.element) return false;
        var input = found.element.matches && found.element.matches("input, textarea")
          ? found.element
          : found.element.querySelector && found.element.querySelector("input, textarea");
        if (found.type === "autocomplete") {
          var formItem = label.closest && label.closest(".el-form-item");
          try {
            input = formItem && Array.from(formItem.querySelectorAll(
              ".el-autocomplete input.el-input__inner, input[aria-autocomplete='list'], input[fetchsuggestions]"
            )).find(isVisible) || input;
          } catch (eInput) {}
          if (formItem && /is-error/.test(String(formItem.className || ""))) return false;
        }
        if (item.requirePersistentSelectCommit === true && found.type === "select") {
          var strictContainer = found.element.closest && found.element.closest(".el-select") || found.element;
          var strictMatch = elementSelectCommittedValueMatches(strictContainer, expected);
          var displayMatch = elementSelectDisplayedValueMatches(strictContainer, expected);
          var visibleValidationMessages = elementSelectVisibleValidationMessages(strictContainer);
          if (step && step.higherEducationNavigationAdapter === true) {
            try {
              var preSaveTrace = JSON.parse(document.documentElement.getAttribute("data-af-zhaopin-higher-education-trace") || "{}");
              if (!Array.isArray(preSaveTrace.preSaveEnsureTrace)) preSaveTrace.preSaveEnsureTrace = [];
              preSaveTrace.preSaveEnsureTrace.push({
                fieldKey: String(item.field || ""),
                detectedType: String(found.type || ""),
                currentDisplay: normalizeChoiceText(getElementChoiceCurrentValue(strictContainer)),
                expected: normalizeChoiceText(expected),
                strictMatch: !!strictMatch,
                displayMatch: !!displayMatch,
                visibleValidationMessages: visibleValidationMessages.slice(0, 4),
                scopeContainsControl: !!(liveScope && liveScope.contains && liveScope.contains(found.element))
              });
              document.documentElement.setAttribute("data-af-zhaopin-higher-education-trace", JSON.stringify(preSaveTrace));
            } catch (ePreSaveTrace) {}
          }
          if (strictMatch) return true;
          // 如果真实 selected-item 已稳定显示目标值，且没有可见的表单错误文案，
          // 放行到网站自己的“添加/保存”动作做最终校验。不要因为遗留的
          // is-error class 或 readonly input.value 为空而在客户端提前拦截。
          if (displayMatch && visibleValidationMessages.length === 0) return true;
          return false;
        }
        var currentText = normalizeChoiceText(input && input.value);
        var expectedText = normalizeChoiceText(expected);
        return !!(currentText && expectedText && (
          currentText === expectedText ||
          (item.fallbackToFirstOption === true && (currentText.indexOf(expectedText) !== -1 || expectedText.indexOf(currentText) !== -1))
        ));
      }

      if (item.alwaysRefillBeforeSave === true || !currentFieldAccepted()) {
        var ensureStep = Object.assign({}, step, { fieldSequence: [item] });
        var ensureResult = await executeFieldSequence(engine, matcher, ensureStep, data, category, scope);
        if (!ensureResult || ensureResult.success === false || !currentFieldAccepted()) {
          failedFields.push({
            fieldKey: item.field,
            label: String(item.label),
            reason: "保存前复核仍未填入",
          });
          continue;
        }
      }
      ensuredKeys.push(item.field);
    }
    return { success: failedFields.length === 0, ensuredKeys: ensuredKeys, failedFields: failedFields };
  }

  async function ensureRepeatedRows(step, scope, rowCount) {
    var rowSelector = step.rowScopeSelector;
    if (!rowSelector || !scope) return [];
    function rows() {
      try { return Array.from(scope.querySelectorAll(rowSelector)).filter(isVisible); } catch (e) { return []; }
    }
    var currentRows = rows();
    while (currentRows.length < rowCount) {
      if (step.rowAddOnlyWhenNoExisting === true && currentRows.length > 0) break;
      var addButton = null;
      if (step.rowAddSelector) {
        try {
          var addCandidates = Array.from((scope || document).querySelectorAll(step.rowAddSelector));
          addButton = addCandidates.find(isVisible) || (step.rowAddAllowHidden === true ? addCandidates[0] : null);
        } catch (eAddSelector) {}
      }
      if (!addButton) {
        addButton = findAddButtonByText(
          scope,
          step.rowAddText || step.addText || "添加",
          step.rowAddCandidateSelector || "button, a, [role='button'], div, span"
        );
      }
      if (!addButton) break;
      var beforeCount = currentRows.length;
      if (step.postbackAutoContinueWorkflowId) {
        try {
          window.sessionStorage.setItem("__afSpecialWorkflowAutoContinue", JSON.stringify({
            workflowId: step.postbackAutoContinueWorkflowId,
            hostname: window.location.hostname,
            startedAt: Date.now(),
          }));
        } catch (ePostbackContinue) {}
      }
      if (step.rowAddNativeClick === true && typeof addButton.click === "function") {
        addButton.click();
      } else {
        await safeClick(addButton);
      }
      await sleep(step.rowAddWaitMs == null ? 450 : step.rowAddWaitMs);
      var rowAdded = await waitUntil(function () {
        return rows().length > beforeCount;
      }, step.rowAddTimeoutMs || 2500);
      // 徽商银行的新增入口是 Vue span.add。只有确认表单数量没有增加时
      // 才补一次合成点击，避免正常情况下重复生成两张空卡片。
      if (!rowAdded && step.rowAddNativeClick === true) {
        await safeClick(addButton);
        rowAdded = await waitUntil(function () {
          return rows().length > beforeCount;
        }, step.rowAddRetryTimeoutMs || 1600);
      }
      currentRows = rows();
      // 点击新增入口后如果卡片数量仍未增加，退出本轮补卡。
      // 这里不能继续 while 重复点击，否则页面未响应时会把整个特殊站点流程卡死。
      if (currentRows.length <= beforeCount) break;
    }
    return currentRows;
  }

  function hasPreparedRepeatRow(step, rowIndex) {
    if (!step || !step.repeatAddOnlyWhenMissing || !step.rowScopeSelector || !Number.isInteger(rowIndex)) return false;
    try {
      var root = step.repeatAddRootSelector
        ? document.querySelector(step.repeatAddRootSelector)
        : (findStepCard(step, document) || document);
      return !!root && Array.from(root.querySelectorAll(step.rowScopeSelector)).filter(isVisible).length > rowIndex;
    } catch (e) {
      return false;
    }
  }

  async function executeRepeatedFieldSequence(engine, matcher, step, resume, category, scope) {
    var rows = prepareStepRows(step, resume);
    var summary = { success: true, message: "重复行按顺序填写完成", filledCount: 0, failedFields: [], totalFieldsFound: 0 };
    await trimHuaweiRepeatedRows(step, scope || document, rows.length);
    for (var i = 0; i < rows.length; i++) {
      var cards = step.rowAddAfterEach
        ? await ensureRepeatedRows(step, scope || document, i + 1)
        : await ensureRepeatedRows(step, scope || document, rows.length);
      var card = cards[i];
      if (!card) {
        summary.success = false;
        summary.failedFields.push({ fieldKey: "row", label: (step.name || category) + " 第" + (i + 1) + "条", reason: "未找到对应重复行容器" });
        continue;
      }
      var rowStep = Object.assign({}, step, {
        fieldSequence: step.rowFieldSequence,
        scopeSelector: "",
        repeatIndex: undefined,
      });
      var before = engine.formHandler.filledFieldsCount || 0;
      var result = await executeFieldSequence(engine, matcher, rowStep, rows[i], rows[i].__afCategory || category, card);
      summary.filledCount += Math.max(0, (engine.formHandler.filledFieldsCount || 0) - before);
      summary.totalFieldsFound += result.totalFieldsFound || 0;
      if (result && result.success === false) {
        summary.success = false;
        summary.failedFields = summary.failedFields.concat(result.failedFields || []);
      }
      if (step.rowAddAfterEach && i < rows.length - 1) {
        cards = await ensureRepeatedRows(step, scope || document, i + 2);
        if (cards.length < i + 2) {
          summary.success = false;
          summary.failedFields.push({
            fieldKey: "rowAdd",
            label: (step.name || category) + " 第" + (i + 2) + "条",
            reason: "当前条填写后未能添加下一条",
          });
          break;
        }
      }
    }
    return summary;
  }

  async function executeIcbcEducationFill(engine, matcher, step, resume, scope) {
    var root = scope || document;
    var rows = prepareStepRows(step, resume);
    var isHighSchool = function (row) { return /高中|中专|职高|技校/.test(String(row && (row.level || row.educationLevel || ""))); };
    var higherRows = rows.filter(function (row) { return !isHighSchool(row); });
    var highRows = rows.filter(isHighSchool);
    var summary = { success: true, message: "工商银行教育经历填写完成", filledCount: 0, failedFields: [], totalFieldsFound: 0 };
    var rowStep = Object.assign({}, step, { fieldSequence: step.rowFieldSequence || [], rowFieldSequence: [] });

    function cards(selector) {
      try { return Array.from(root.querySelectorAll(selector)).filter(isVisible); } catch (e) { return []; }
    }
    // 最高学历卡的外层是 highest-edu-form___*，高校/高中卡才是
    // form-wrapper___*。按卡片内部唯一字段识别，避免把最高学历卡漏掉。
    function directEducationCards(markerSelector) {
      var wrapper = root;
      try {
        if (!wrapper.matches || !wrapper.matches(".wrapper___mC8a8")) {
          var wrappers = Array.from(root.querySelectorAll(".wrapper___mC8a8"));
          wrapper = wrappers.find(function (candidate) {
            return candidate.querySelector && candidate.querySelector(markerSelector);
          }) || wrappers[0] || root;
        }
        return Array.from(wrapper.children || []).filter(isVisible).filter(function (card) {
          return !!(card.querySelector && card.querySelector(markerSelector));
        });
      } catch (eCards) {
        return [];
      }
    }
    async function fillCard(card, row) {
      if (!card || !row) return;
      var before = engine.formHandler.filledFieldsCount || 0;
      var result = await executeFieldSequence(engine, matcher, rowStep, row, "education", card);
      summary.filledCount += Math.max(0, (engine.formHandler.filledFieldsCount || 0) - before);
      summary.totalFieldsFound += result && result.totalFieldsFound || 0;
      if (result && result.success === false) {
        summary.success = false;
        summary.failedFields = summary.failedFields.concat(result.failedFields || []);
      }
    }

    var highestCard = directEducationCards("#highestEdu")[0];
    var highestRow = higherRows.shift();
    if (highestCard && highestRow) await fillCard(highestCard, highestRow);
    else if (highestRow) {
      summary.success = false;
      summary.failedFields.push({ fieldKey: "highestEducationCard", label: "最高学历", reason: "未找到最高学历卡片" });
    }

    var higherSelector = ".wrapper___mC8a8 > [class*='form-wrapper___']:has([id^='schoolAge#'])";
    var higherStep = {
      rowScopeSelector: higherSelector,
      rowAddSelector: step.rowAddSelector,
      rowAddText: step.rowAddText,
      rowAddAfterEach: false,
      rowAddWaitMs: step.rowAddWaitMs || 500,
    };
    await ensureRepeatedRows(higherStep, root, higherRows.length);
    var higherCards = directEducationCards("[id^='schoolAge#']");
    for (var i = 0; i < higherRows.length; i++) await fillCard(higherCards[i], higherRows[i]);
    if (higherRows.length > higherCards.length) {
      summary.success = false;
      summary.failedFields.push({ fieldKey: "higherEducationCard", label: "其他高校教育经历", reason: "未能创建足够的高校教育经历卡片" });
    }

    var highCard = directEducationCards("[id^='highSchool#']")[0];
    if (!highCard && highRows.length) {
      var highAdd = findAddButtonByText(root, ["+ 添加其他高中教育经历", "添加其他高中教育经历"]);
      if (highAdd) {
        await safeClick(highAdd);
        await sleep(500);
        highCard = directEducationCards("[id^='highSchool#']")[0];
      }
    }
    if (highRows.length && highCard) await fillCard(highCard, highRows[0]);
    else if (highRows.length) {
      summary.success = false;
      summary.failedFields.push({ fieldKey: "highSchoolCard", label: "高中毕业院校", reason: "未找到高中教育经历卡片" });
    }
    if (!highestRow && !highRows.length) summary.success = false;
    return summary;
  }

  // 特殊工作流已经明确知道当前点击的是哪一类，因此直接把 category 交给现有
  // FormHandler。这样不依赖站点标题字典猜测，也能处理“工作（实习）经历”合并入口。
  async function executeCategoryFill(engine, matcher, step, resume, scope) {
    if (step.fillMode === "visible") return engine.executeVisibleFormFill(scope || document);
    if (step.customFill === "icbcEducation") return executeIcbcEducationFill(engine, matcher, step, resume, scope);
    if (/^applyjob\.chinahr\.com$/i.test(window.location.hostname) && !step.repeatForCategoryData && Array.isArray(step.fieldSequence) && step.fieldSequence.length) {
      var chinahrSequenceData = resume && (resume[step.category] || resume);
      if (Array.isArray(chinahrSequenceData)) chinahrSequenceData = chinahrSequenceData[0];
      if (typeof step.dataTransform === "function") {
        try { chinahrSequenceData = step.dataTransform(chinahrSequenceData || {}, resume) || chinahrSequenceData; } catch (eChinahrTransform) {}
      }
      return executeFieldSequence(engine, matcher, step, chinahrSequenceData || {}, step.category, scope || document);
    }
    if (!step.category) return engine.execute();

    var titleEl = visibleTitleForScope(matcher, scope);
    var hasDeclaredFieldSequence =
      Array.isArray(step.fieldSequence) && step.fieldSequence.length > 0 ||
      Array.isArray(step.preFieldSequence) && step.preFieldSequence.length > 0 ||
      Array.isArray(step.rowFieldSequence) && step.rowFieldSequence.length > 0;
    // 招商银行这类单页 Ant 表单的模块标题位于 .item-box 顶部，而新增后的
    // 单条经历 scope 只包含当前卡片字段。特殊工作流已经明确声明 fieldSequence
    // 时，不应再要求局部卡片内部重复出现模块标题；否则只会新增空卡片，随后
    // 错误退回通用填写。没有明确字段序列的旧步骤仍保持原有回退行为。
    if (!titleEl && !hasDeclaredFieldSequence) return engine.execute();
    var title = titleEl
      ? (engine.formHandler.getTitleValue(titleEl) || step.name || String(step.category))
      : (step.name || String(step.category));
    var categories = Array.isArray(step.category) ? step.category : [step.category];
    var ok = false;

    if (Array.isArray(step.rowFieldSequence) && step.rowFieldSequence.length) {
      if (Array.isArray(step.dataOverride) && step.dataOverride.length) {
        // 中信教育的学历选择会使当前卡片重绘。先生成所有计划卡片，
        // 再开始写第一张，能避免“填一张 -> 新增一张”期间的联动重绘
        // 影响下一条经历。该行为必须由站点配置显式开启。
        if (
          step.prepareRepeatRowsBeforeFirstFill === true &&
          step.repeatIndex === 0 &&
          Number(step.repeatTotal) > 1
        ) {
          var preparedRows = await ensureRepeatedRows(step, scope || document, Number(step.repeatTotal));
          if (preparedRows.length < Number(step.repeatTotal)) {
            throw new Error("教育经历预创建卡片不足：需要" + Number(step.repeatTotal) + "张，当前仅有" + preparedRows.length + "张");
          }
        }
        var singleRow = step.dataOverride[0] || {};
        var singleRowStep = Object.assign({}, step, {
          fieldSequence: step.rowFieldSequence,
        });
        var singleRowScope = scope || document;
        // 中信的“新增教育经历”会把多张编辑卡片同时留在同一 form 内。
        // 重复步骤展开后需要把第 N 条限制到第 N 张卡片，不能继续命中高中卡片。
        if (step.useRepeatRowScopeByIndex === true && step.rowScopeSelector) {
          try {
            var visibleRowScopes = Array.from(singleRowScope.querySelectorAll(step.rowScopeSelector)).filter(isVisible);
            var rowScopeIndex = Number.isInteger(step.repeatIndex) ? step.repeatIndex : visibleRowScopes.length - 1;
            if (visibleRowScopes.length) singleRowScope = visibleRowScopes[Math.min(rowScopeIndex, visibleRowScopes.length - 1)];
            // 中信教育卡会在“学历”选中后重绘。把刷新目标改为教育表单内
            // 的行容器，后续学校、日期等字段每次都能回到同一张实时卡片。
            singleRowStep.scopeRefreshRootSelector = step.scopeSelector;
            singleRowStep.scopeSelector = step.rowScopeSelector;
            singleRowStep.repeatIndex = rowScopeIndex;
          } catch (eLatestRepeatScope) {}
        }
        return executeFieldSequence(engine, matcher, singleRowStep, singleRow, singleRow.__afCategory || step.categoryOverride || categories[0], singleRowScope);
      }
      return executeRepeatedFieldSequence(engine, matcher, step, resume, categories[0], scope || document);
    }

    if (Array.isArray(step.preFieldSequence) && step.preFieldSequence.length) {
      var preCategory = step.categoryOverride || categories[0];
      var preData = Array.isArray(step.dataOverride)
        ? step.dataOverride[0]
        : resume && resume[preCategory];
      if (Array.isArray(preData)) preData = preData[0];
      if (typeof step.dataTransform === "function") {
        try { preData = step.dataTransform(preData || {}, resume) || preData; } catch (ePreTransform) {}
      }
      var preStep = Object.assign({}, step, { fieldSequence: step.preFieldSequence });
      await executeFieldSequence(engine, matcher, preStep, preData || {}, preCategory, scope || document);
    }

    if (Array.isArray(step.fieldSequence) && step.fieldSequence.length) {
      var sequenceCategory = step.categoryOverride || categories[0];
      var sequenceData = Array.isArray(step.dataOverride)
        ? step.dataOverride[0]
        : resume && resume[sequenceCategory];
      if (Array.isArray(sequenceData)) sequenceData = sequenceData[0];
      if (typeof step.dataTransform === "function") {
        try { sequenceData = step.dataTransform(sequenceData || {}, resume) || sequenceData; } catch (e) {}
      }
      return executeFieldSequence(engine, matcher, step, sequenceData || {}, sequenceCategory, scope);
    }

    if (step.aggregateCategoryData) {
      var aggregateCategory = categories[0];
      var aggregateSource = combineCategoryRows(resume, categories);
      var aggregateValue = aggregateRows(aggregateSource, step.aggregateFields || [], step.aggregateSeparator);
      var aggregateData = {};
      aggregateData[step.aggregateField] = aggregateValue;
      var aggregateLabels = matcher.findLabelsByCard(scope || document) || matcher.findAllLabels() || [];
      var aggregateBefore = engine.formHandler.filledFieldsCount;
      await engine.formHandler.fillLabels(aggregateLabels, aggregateCategory, aggregateData);
      ok = engine.formHandler.filledFieldsCount > aggregateBefore;
    } else if (Array.isArray(step.dataOverride)) {
      ok = await engine.formHandler.fillExperience(titleEl, title, {
        dataOverride: step.dataOverride,
        categoryOverride: step.categoryOverride || categories[0],
      });
    } else if (step.transformCategoryRows) {
      var transformedRows = prepareStepRows(step, resume);
      ok = await engine.formHandler.fillExperience(titleEl, title, {
        dataOverride: transformedRows,
        categoryOverride: categories[0],
      });
    } else if (categories.length > 1) {
      var combinedRows = combineCategoryRows(resume, categories);
      if (combinedRows.length) {
        ok = await engine.formHandler.fillExperience(titleEl, title, {
          dataOverride: combinedRows,
          categoryOverride: categories[0],
        });
      }
    } else {
      var category = categories[0];
      var categoryData = resume && resume[category];
      if (Array.isArray(categoryData)) {
        ok = await engine.formHandler.fillExperience(titleEl, title, { specificCategory: category });
      } else {
        ok = await engine.formHandler.fillBasicInfo(titleEl, title, { specificCategory: category });
      }
    }

    var finalResult = {
      success: ok === true,
      message: ok ? "当前大类填写完成" : "当前大类没有匹配字段或填写未完成",
      filledCount: engine.formHandler.filledFieldsCount || 0,
      failedFields: engine.formHandler.failedFields || [],
      totalFieldsFound: scope ? countVisibleFields(scope) : 1,
    };
    if (Array.isArray(step.extraFieldSequence) && step.extraFieldSequence.length) {
      var extraCategory = step.categoryOverride || categories[0];
      var extraData = Array.isArray(step.dataOverride)
        ? step.dataOverride[0]
        : resume && resume[extraCategory];
      if (Array.isArray(extraData)) extraData = extraData[0];
      if (typeof step.dataTransform === "function") {
        try { extraData = step.dataTransform(extraData || {}, resume) || extraData; } catch (eExtraTransform) {}
      }
      var extraStep = Object.assign({}, step, { fieldSequence: step.extraFieldSequence });
      var extraResult = await executeFieldSequence(engine, matcher, extraStep, extraData || {}, extraCategory, scope || document);
      finalResult.success = (finalResult.success && extraResult.success !== false) ||
        (extraResult.success !== false && (extraResult.filledCount || 0) > 0);
      if (extraResult.success !== false && (extraResult.filledCount || 0) > 0) {
        finalResult.message = "当前大类填写完成";
      }
      finalResult.filledCount = engine.formHandler.filledFieldsCount || finalResult.filledCount;
      finalResult.failedFields = (finalResult.failedFields || []).concat(extraResult.failedFields || []);
      finalResult.totalFieldsFound += extraResult.totalFieldsFound || 0;
      if (extraResult && extraResult.success === false) finalResult.message = extraResult.message || finalResult.message;
    }

    return finalResult;
  }

  async function cancelZhaopinRepeatFailedExistingRepair(step) {
    if (!step || !/^opened_existing_editor/.test(String(step.__afZhaopinRepeatAction || ""))) return false;
    var section = findStepCard(step, document) || document;
    var live = null;
    try { live = classifyZhaopinRepeatEditableRoot(section); } catch (eLive) {}
    var root = live && live.root || null;
    if (!root) return true;
    var container = root;
    try { container = root.closest && root.closest(".apply-module__form") || root; } catch (eClosest) {}
    var cancelButton = null;
    try {
      cancelButton = Array.from(container.querySelectorAll("button, a, [role='button']")).filter(isActuallyVisible).find(function (node) {
        return /^取\s*消$/.test(normalizeText(node.textContent || node.getAttribute && (node.getAttribute("aria-label") || node.getAttribute("title")) || ""));
      }) || null;
    } catch (eButtons) {}
    if (!cancelButton) return false;
    try { if (!(await safeClick(cancelButton))) return false; } catch (eClick) { return false; }
    var closed = await waitUntil(function () {
      var currentSection = findStepCard(step, document) || section;
      var current = classifyZhaopinRepeatEditableRoot(currentSection);
      return !current.root ? true : null;
    }, step.cancelFailedRepairTimeoutMs || 3500);
    return !!closed;
  }

  function findZhaopinRepeatEditorSubmitButton(step, scope) {
    if (!step || step.repeatForCategoryData !== true || step.directMenuNavigation !== true) return null;
    var action = String(step.__afZhaopinRepeatAction || "");
    var section = findStepCard(step, document) || document;
    var roots = [];
    if (scope) roots.push(scope);
    try {
      var live = classifyZhaopinRepeatEditableRoot(section);
      if (live && live.root && roots.indexOf(live.root) === -1) roots.push(live.root);
    } catch (eLive) {}
    for (var i = 0; i < roots.length; i += 1) {
      var root = roots[i];
      var container = root;
      try {
        container = root.closest && root.closest(".apply-module__form") || root;
      } catch (eClosest) {}
      var buttons = [];
      try {
        buttons = Array.from(container.querySelectorAll("button, a, [role='button']"))
          .filter(isVisible)
          .filter(function (node) {
            var text = normalizeText(node.textContent || node.getAttribute && (node.getAttribute("aria-label") || node.getAttribute("title")) || "");
            return !FORBIDDEN_ACTION_TEXT.test(text) && !/取消|返回/.test(text);
          });
      } catch (eButtons) {}
      if (!buttons.length) continue;
      var wanted = null;
      if (/opened_existing_editor/.test(action)) {
        wanted = buttons.find(function (node) { return /保存|更新/.test(normalizeText(node.textContent || "")); });
      } else if (action === "opened_add_editor") {
        wanted = buttons.find(function (node) { return /^(?:添\s*加|新增|保存)$/.test(normalizeText(node.textContent || "")); });
      } else {
        wanted = buttons.find(function (node) { return /保存|更新|添加|新增/.test(normalizeText(node.textContent || "")); });
      }
      if (wanted) return wanted;
      var primary = buttons.find(function (node) { return /el-button--primary/.test(String(node.className || "")); });
      if (primary) return primary;
      if (buttons.length === 1) return buttons[0];
    }
    return null;
  }

  function findSaveButton(step, scope) {
    var root = scope || document;
    var zhaopinRepeatSubmit = findZhaopinRepeatEditorSubmitButton(step, scope);
    if (zhaopinRepeatSubmit) return zhaopinRepeatSubmit;
    var isRepeatSubmit = !!(step && step.repeatForCategoryData === true && (step.repeatSubmitSelector || step.repeatSubmitText));
    var saveSelector = isRepeatSubmit ? step.repeatSubmitSelector : step.saveSelector;
    var saveText = isRepeatSubmit ? step.repeatSubmitText : step.saveText;
    // 平安校招的字段表单与操作按钮是同级节点：
    // .edit-mode > form.el-form.resume + .btns。重复经历填写时 scope 会被
    // 严格收窄到 form，保存按钮不在 form 内。此处先锁定“当前可见编辑器”，
    // 再在其中找保存，避免退回 document 后误点其它隐藏卡片的按钮。
    if (step && step.repeatForCategoryData === true && step.useVisibleRepeatEditorAsScope === true) {
      var activeEditor = null;
      try {
        activeEditor = scope && scope.closest && scope.closest(step.activeRepeatEditorSelector || ".edit-mode");
      } catch (eActiveClosest) {}
      if (!activeEditor || !isVisible(activeEditor)) {
        try {
          var activeCard = findStepCard(step, document) || document;
          activeEditor = Array.from(activeCard.querySelectorAll(
            step.activeRepeatEditorSelector || ".edit-mode"
          )).filter(isVisible).pop() || null;
        } catch (eActiveQuery) {}
      }
      if (activeEditor) {
        if (saveSelector) {
          try {
            var selectedInEditor = Array.from(activeEditor.querySelectorAll(saveSelector)).find(isVisible);
            if (selectedInEditor) return selectedInEditor;
          } catch (eSelectedInEditor) {}
        }
        var textSaveInEditor = findByText(activeEditor, saveText, "button, a, [role='button']");
        if (textSaveInEditor) return textSaveInEditor;
      }
    }
    if (saveSelector) {
      try {
        if (isRepeatSubmit && root && root.closest) {
          var scopedSaveRoot = root.closest(".education-edit-item__wrapper, .work-edit-item__wrapper, .project-edit-item__wrapper") || root.parentElement;
          var scopedSelected = scopedSaveRoot && Array.from(scopedSaveRoot.querySelectorAll(saveSelector)).find(isVisible);
          if (scopedSelected) return scopedSelected;
        }
        var selected = Array.from(root.querySelectorAll(saveSelector)).find(isVisible) ||
          Array.from(document.querySelectorAll(saveSelector)).find(isVisible);
        if (selected) return selected;
      } catch (e) {}
    }
    var inScope = findByText(root, saveText, "button, a, [role='button']");
    if (inScope) return inScope;
    // 顺丰教育等旧式卡片：保存按钮位于 form 外的卡片底部。仅当站点显式
    // 配置 repeatSubmit* 时，沿当前 form 向上查找同一卡片，避免误点其它模块。
    if (step && step.repeatForCategoryData === true && step.repeatSubmitText && root && root.closest) {
      var cardRoot = root.closest(".education-edit-item__wrapper, .work-edit-item__wrapper, .project-edit-item__wrapper, #educationList, #workList, #projectList") || root.parentElement;
      if (cardRoot) {
        var cardSave = findByText(cardRoot, step.repeatSubmitText, ".normal-btn.sm, button, a, [role='button']");
        if (cardSave) return cardSave;
      }
    }
    // 智联校园的重复经历新增表单把提交动作显示为“添 加”，且按钮可能在
    // form 的同级操作区中。限制在当前大类卡片内取可见主按钮作为兜底。
    if (step && step.repeatForCategoryData === true && step.directMenuNavigation === true) {
      var repeatSaveRoot = findStepCard(step, document) || root;
      try {
        var repeatPrimary = Array.from(repeatSaveRoot.querySelectorAll(
          ".apply-module__form button.el-button--primary, button.el-button--primary"
        )).filter(isVisible).find(function (node) {
          return !/取消|立即投递|提交申请/.test(normalizeText(node.textContent));
        });
        if (repeatPrimary) return repeatPrimary;
      } catch (eRepeatPrimary) {}
    }
    if (root !== document) {
      var inDocument = findByText(document, saveText, "button, a, [role='button']");
      if (inDocument) return inDocument;
    }
    var card = findStepCard(step, document);
    if (card && card !== root) {
      var inCard = findByText(card, saveText, "button, a, [role='button']");
      if (inCard) return inCard;
    }
    return null;
  }

  function findPostSaveConfirmButton(step) {
    if (!step.postSaveConfirmSelector || !step.postSaveConfirmText) return null;
    var rejectPattern = step.postSaveConfirmRejectText ? new RegExp(step.postSaveConfirmRejectText, "i") : null;
    var roots = [];
    try {
      roots = Array.from(document.querySelectorAll(step.postSaveConfirmSelector)).filter(isVisible);
    } catch (e) {}
    for (var i = roots.length - 1; i >= 0; i--) {
      if (rejectPattern && rejectPattern.test(normalizeText(roots[i].textContent))) continue;
      var button = findByText(
        roots[i],
        step.postSaveConfirmText,
        step.postSaveConfirmButtonSelector || "button, a, [role='button']"
      );
      if (button) return button;
    }
    return null;
  }

  function collectVisibleTextConstraintErrors(root) {
    root = root || document;
    var messages = [];
    var controls = [];
    try {
      controls = Array.from(root.querySelectorAll("textarea, input[type='text'], input:not([type])")).filter(isActuallyVisible);
    } catch (eControls) {}
    controls.forEach(function (control) {
      var value = String(control && control.value || "");
      if (!value) return;
      var maxLength = Number(control && (control.getAttribute && control.getAttribute("maxlength")) || control.maxLength || 0);
      if (Number.isFinite(maxLength) && maxLength > 0 && maxLength < 100000 && value.length > maxLength) {
        messages.push("内容长度超过限制（" + value.length + "/" + maxLength + "）");
      }
      var item = null;
      try { item = control.closest && control.closest(".el-form-item, .ant-form-item, [class*='form-item'], [class*='formItem']"); } catch (eItem) {}
      var localRoot = item || control.parentElement || root;
      var texts = [];
      try {
        texts = Array.from(localRoot.querySelectorAll(".el-input__count, .el-input__count-inner, [class*='count'], [class*='limit'], [class*='error']"))
          .filter(isActuallyVisible)
          .map(function (node) { return normalizeText(node.textContent); })
          .filter(Boolean);
      } catch (eTexts) {}
      texts.forEach(function (textValue) {
        var counter = textValue.match(/(\d+)\s*[\/／]\s*(\d+)/);
        if (counter && Number(counter[1]) > Number(counter[2])) {
          messages.push("内容长度超过限制（" + counter[1] + "/" + counter[2] + "）");
          return;
        }
        var limitMatch = textValue.match(/(?:最多(?:可)?(?:输入)?|不能超过|不超过)\s*(\d+)\s*(?:个)?(?:字|字符)/);
        if (limitMatch && value.length > Number(limitMatch[1])) {
          messages.push("内容长度超过限制（" + value.length + "/" + limitMatch[1] + "）");
          return;
        }
        if (/超出|超过|字数|字符数|长度/.test(textValue) && /字|字符|长度/.test(textValue)) {
          messages.push(textValue);
        }
      });
    });
    return messages.filter(function (message, index, all) { return message && all.indexOf(message) === index; }).slice(0, 8);
  }

  function collectVisibleValidationErrors(root) {
    root = root || document;
    var selectors = [
      ".el-form-item__error",
      ".ant-form-item-explain-error",
      ".ant-form-explain",
      ".form-error",
      ".error-message",
      ".invalid-feedback",
    ];
    var messages = [];
    selectors.forEach(function (selector) {
      var nodes = [];
      try { nodes = Array.from(root.querySelectorAll(selector)); } catch (e) {}
      nodes.filter(isVisible).forEach(function (node) {
        var text = normalizeText(node.textContent);
        if (text && messages.indexOf(text) === -1) messages.push(text);
      });
    });
    return messages.slice(0, 8);
  }

  async function confirmStepAfterSave(step) {
    if (!step.postSaveConfirmSelector || !step.postSaveConfirmText) return;
    var button = await waitUntil(function () {
      return findPostSaveConfirmButton(step);
    }, step.postSaveConfirmTimeoutMs || 4000);
    if (!button) {
      if (step.postSaveConfirmOptional === true) return;
      throw new Error("保存后未检测到确认弹窗：" + (step.name || step.category || "未命名步骤"));
    }
    if (step.forceNativeSaveClick === true && typeof button.click === "function") {
      try { button.scrollIntoView && button.scrollIntoView({ block: "center", inline: "nearest" }); } catch (eSaveScroll) {}
      button.click();
    } else {
      await safeClick(button);
    }
    await sleep(step.waitAfterConfirmMs == null ? 250 : step.waitAfterConfirmMs);
  }

  async function closeAndReportSaveErrorDialog(step) {
    if (!step || !step.saveErrorDialogSelector || !step.saveErrorDialogPattern) return "";
    var pattern = null;
    try { pattern = new RegExp(step.saveErrorDialogPattern); } catch (ePattern) { return ""; }
    var dialog = await waitUntil(function () {
      var dialogs = [];
      try { dialogs = Array.from(document.querySelectorAll(step.saveErrorDialogSelector)).filter(isVisible); } catch (e) {}
      return dialogs.find(function (node) { return pattern.test(normalizeText(node.textContent)); }) || null;
    }, step.saveErrorDialogTimeoutMs || 900);
    if (!dialog) return "";
    var message = normalizeText(dialog.textContent);
    var closeButton = findByText(
      dialog,
      step.saveErrorDialogButtonText || ["确定", "确 定", "确认"],
      step.saveErrorDialogButtonSelector || "button, a, [role='button']"
    );
    if (closeButton) {
      await safeClick(closeButton);
      await sleep(180);
    }
    return message;
  }

  function writeZhaopinRepeatSaveTrace(entry) {
    try {
      var trace = JSON.parse(document.documentElement.getAttribute("data-af-zhaopin-repeat-save-trace") || "{}");
      if (!trace || typeof trace !== "object") trace = {};
      if (!Array.isArray(trace.records)) trace.records = [];
      var safe = {
        section: String(entry && entry.section || ""),
        repeatIndex: Number.isInteger(entry && entry.repeatIndex) ? entry.repeatIndex : -1,
        action: String(entry && entry.action || ""),
        buttonText: String(entry && entry.buttonText || ""),
        clickCount: Number(entry && entry.clickCount || 0),
        closed: !!(entry && entry.closed),
        visibleValidationErrorCount: Number(entry && entry.visibleValidationErrorCount || 0),
        reason: String(entry && entry.reason || ""),
      };
      trace.records.push(safe);
      if (trace.records.length > 30) trace.records = trace.records.slice(-30);
      trace.last = safe;
      document.documentElement.setAttribute("data-af-zhaopin-repeat-save-trace", JSON.stringify(trace));
    } catch (e) {}
  }

  async function saveStepIfNeeded(step, scope) {
    if (!step.saveSelector && !step.saveText && !step.repeatSubmitSelector && !step.repeatSubmitText) return;
    var wizardHeadingBefore = "";
    var configuredSaveText = step.repeatForCategoryData === true && !step.isLastRepeatStep && step.repeatSaveText
      ? step.repeatSaveText
      : step.repeatForCategoryData === true && step.repeatSubmitText
      ? step.repeatSubmitText
      : step.saveText;
    var wizardSaveTexts = Array.isArray(configuredSaveText) ? configuredSaveText : [configuredSaveText];
    var isWizardNextAction = wizardSaveTexts.some(function (text) { return /下一节/.test(String(text || "")); });
    if (step.wizardRetryNextWhenStayed && step.wizardSectionTitle && isWizardNextAction) {
      try {
        var beforeHeading = Array.from(document.querySelectorAll(step.wizardHeadingSelector || "h5")).find(isVisible);
        wizardHeadingBefore = normalizeText(beforeHeading && beforeHeading.textContent);
      } catch (e) {}
    }
    var button = findSaveButton(step, scope);
    if (!button) throw new Error("找不到保存按钮：" + (step.name || step.category || "未命名步骤"));
    var actionText = normalizeText(button.textContent || button.getAttribute("aria-label") || button.getAttribute("title"));
    if (FORBIDDEN_ACTION_TEXT.test(actionText)) {
      throw new Error("拒绝点击疑似提交/删除按钮：" + actionText);
    }
    if (step.postbackAutoContinueWorkflowId) {
      try {
        window.sessionStorage.setItem("__afSpecialWorkflowAutoContinue", JSON.stringify({
          workflowId: step.postbackAutoContinueWorkflowId,
          hostname: window.location.hostname,
          pagePath: window.location.pathname,
          repeatGroupKey: step.repeatGroupKey || "",
          completedRepeatIndex: Number.isInteger(step.repeatIndex) ? step.repeatIndex : null,
          completedStepBaseIndex: Number.isInteger(step.__afWorkflowStepIndex) ? step.__afWorkflowStepIndex : null,
          completedStepName: step.repeatForCategoryData === true ? "" : (step.name || step.category || ""),
          startedAt: Date.now(),
        }));
      } catch (eContinueStore) {}
    }
    await safeClick(button);
    await sleep(step.waitAfterSaveMs == null ? 300 : step.waitAfterSaveMs);
    if (step.waitForSaveSuccess) {
      var saveSuccess = await waitUntil(function () {
        try {
          return Array.from(document.querySelectorAll(".el-message--success, .el-message, [role='alert']")).filter(isVisible).find(function (node) { return /添加成功|保存成功|保存并更新成功|更新成功/.test(normalizeText(node.textContent)); }) || null;
        } catch (eSaveSuccess) { return null; }
      }, step.saveSuccessTimeoutMs || 8000);
      if (!saveSuccess && step.saveSuccessOptional !== true) throw new Error("保存成功提示未出现");
    }
    var saveErrorDialogMessage = await closeAndReportSaveErrorDialog(step);
    if (saveErrorDialogMessage) {
      throw new Error("保存未成功；网站提示：" + saveErrorDialogMessage);
    }
    await confirmStepAfterSave(step);
    if (wizardHeadingBefore && step.wizardRetryNextWhenStayed && isWizardNextAction) {
      var wizardHeadingAfter = "";
      try {
        var afterHeading = Array.from(document.querySelectorAll(step.wizardHeadingSelector || "h5")).find(isVisible);
        wizardHeadingAfter = normalizeText(afterHeading && afterHeading.textContent);
      } catch (e2) {}
      if (wizardHeadingAfter === wizardHeadingBefore) {
        var retryButton = findSaveButton(step, null);
        if (retryButton) {
          await safeClick(retryButton);
          await sleep(step.waitAfterSaveMs == null ? 700 : step.waitAfterSaveMs);
        }
      }
    }
    if (step.waitForCloseSelector) {
      function repeatEditorClosedNow() {
        var card = findStepCard(step, document);
        // 交通银行等 React 重复经历保存后会销毁旧 form 并重绘栏目。只检查
        // 旧 scope 会因为旧节点已 detached 而误判“已关闭”，即使栏目里仍有
        // 一个可见编辑器。显式声明 waitForRepeatEditorCloseInRoot 时，必须从
        // 当前 repeat root 重新查询 live editor，形成跨记录 save barrier。
        if (step.waitForRepeatEditorCloseInRoot === true && step.repeatAddRootSelector) {
          try {
            var liveRepeatRoot = document.querySelector(step.repeatAddRootSelector);
            if (liveRepeatRoot) {
              var liveEditorSelector = step.repeatReadySelector || step.waitForCloseSelector;
              var liveEditors = queryVisibleIncludingRoot(liveRepeatRoot, liveEditorSelector);
              if (liveEditors.some(isVisible)) return null;
              return true;
            }
          } catch (eRepeatRootClose) {}
        }
        // 公共智联重复经历保存后，Vue 可能保留一个有几何尺寸但祖先已隐藏的
        // stale form。旧逻辑仅用 isVisible 会把它误判成仍处于编辑态。
        // 对 useVisibleRepeatEditorAsScope 的步骤必须使用 isActuallyVisible。
        var root = step.useVisibleRepeatEditorAsScope === true
          ? (card || document)
          : (scope || card || document);
        var nodes = queryVisibleIncludingRoot(root, step.waitForCloseSelector);
        var visible = nodes.some(step.useVisibleRepeatEditorAsScope === true ? isActuallyVisible : isVisible);
        return visible ? null : true;
      }
      var closed = await waitUntil(repeatEditorClosedNow, step.saveTimeoutMs || step.timeoutMs);
      var validationErrors = [];
      var repeatSaveClickCount = 1;
      if (!closed && step.useVisibleRepeatEditorAsScope === true && step.zhaopinRepeatRetrySaveWhenStillEditing === true) {
        var validationRoot = findStepCard(step, document) || scope || document;
        validationErrors = collectVisibleValidationErrors(validationRoot)
          .concat(collectVisibleTextConstraintErrors(validationRoot))
          .filter(function (message, index, all) { return message && all.indexOf(message) === index; });
        if (!validationErrors.length) {
          var retryRepeatSave = findSaveButton(step, null);
          if (retryRepeatSave) {
            var retryActionText = normalizeText(retryRepeatSave.textContent || retryRepeatSave.getAttribute("aria-label") || retryRepeatSave.getAttribute("title"));
            if (!FORBIDDEN_ACTION_TEXT.test(retryActionText)) {
              await safeClick(retryRepeatSave);
              repeatSaveClickCount += 1;
              await sleep(step.waitAfterSaveMs == null ? 500 : step.waitAfterSaveMs);
              closed = await waitUntil(repeatEditorClosedNow, step.saveRetryTimeoutMs || step.saveTimeoutMs || step.timeoutMs);
            }
          }
        }
      }
      if (step.useVisibleRepeatEditorAsScope === true) {
        if (!validationErrors.length && !closed) {
          var finalValidationRoot = findStepCard(step, document) || scope || document;
          validationErrors = collectVisibleValidationErrors(finalValidationRoot)
            .concat(collectVisibleTextConstraintErrors(finalValidationRoot))
            .filter(function (message, index, all) { return message && all.indexOf(message) === index; });
        }
        writeZhaopinRepeatSaveTrace({
          section: step.cardTitle || step.name || "",
          repeatIndex: step.repeatIndex,
          action: String(step.__afZhaopinRepeatAction || ""),
          buttonText: actionText,
          clickCount: repeatSaveClickCount,
          closed: !!closed,
          visibleValidationErrorCount: validationErrors.length,
          reason: closed ? "" : (validationErrors.length ? "visible_validation_error" : "editor_still_visible_after_retry"),
        });
      }
      if (!closed) {
        throw new Error(
          "保存未成功：" + (step.name || step.category || "未命名步骤") +
          (validationErrors.length ? "；校验提示：" + validationErrors.join("；") : "；表单仍处于编辑态")
        );
      }
    }
    if (step.savedSelector) {
      var saved = await waitUntil(function () {
        var element = document.querySelector(step.savedSelector);
        return element && isVisible(element) ? element : null;
      }, step.saveTimeoutMs || step.timeoutMs);
      if (!saved) throw new Error("保存后未检测到成功状态：" + (step.name || step.category || "未命名步骤"));
    }
    if (step.waitBeforeNextMs) await sleep(step.waitBeforeNextMs);
  }

  async function saveVisibleChinaHrCards() {
    var clicked = 0;
    await sleep(300);
    for (var attempt = 0; attempt < 8; attempt++) {
      var button = null;
      try {
        button = Array.from(document.querySelectorAll(".aply-form-btn.act")).find(function (node) {
          if (!isVisible(node) || /删除|移除|提交|投递/.test(normalizeText(node.textContent || ""))) return false;
          var section = node.closest && node.closest(".aply-form");
          return !!(section && /教育经历|实习工作经历|实习经历/.test(normalizeText(section.textContent || "")));
        });
      } catch (eFind) {}
      if (!button) break;
      if (!button || /删除|移除|提交|投递/.test(normalizeText(button.textContent || ""))) continue;
      try { button.scrollIntoView && button.scrollIntoView({ block: "center", inline: "nearest" }); } catch (eScroll) {}
      if (typeof button.click === "function") button.click();
      else await safeClick(button);
      clicked++;
      await waitUntil(function () { return !isVisible(button); }, 3500);
      await sleep(300);
    }
    return clicked;
  }

  async function addChinaHrEducationCardIfNeeded(resume) {
    var rows = resume && Array.isArray(resume.education) ? resume.education.filter(function (row) {
      return !/高中|中专/.test(String(row && (row.level || row.educationLevel || "") || ""));
    }) : [];
    if (rows.length < 1) return false;
    var section = null;
    try {
      section = Array.from(document.querySelectorAll(".aply-form")).find(function (node) {
        return /教育经历/.test(normalizeText(node.textContent || ""));
      });
    } catch (e) {}
    if (!section) return false;
    try {
      if (Array.from(section.querySelectorAll(".aply-group")).filter(isVisible).length >= rows.length) return false;
    } catch (eCount) {}
    var add = null;
    try {
      add = Array.from(section.querySelectorAll(".aply-form-top .aply-form-opt.add, .aply-form-empty, p, button, a, [role='button']")).find(function (node) {
        return isVisible(node) && /添加\s*教育经历|添加/.test(normalizeText(node.textContent || node.getAttribute("aria-label") || node.getAttribute("title") || ""));
      }) || null;
    } catch (eAdd) {}
    if (!add) return false;
    var beforeCount = Array.from(section.querySelectorAll(".aply-group")).filter(isVisible).length;
    await safeClick(add);
    return !!(await waitUntil(function () {
      var live = Array.from(document.querySelectorAll(".aply-form")).find(function (node) { return /教育经历/.test(normalizeText(node.textContent || "")); });
      return live && Array.from(live.querySelectorAll(".aply-group")).filter(isVisible).length > beforeCount ? true : null;
    }, 5000));
  }

  async function addChinaHrInternshipCardIfNeeded(resume) {
    var rows = resume && Array.isArray(resume.internshipExperience) ? resume.internshipExperience : [];
    if (rows.length < 1) return false;
    var section = null;
    try {
      section = Array.from(document.querySelectorAll(".aply-form")).find(function (node) {
        return /实习工作经历|实习经历/.test(normalizeText(node.textContent || ""));
      });
    } catch (e) {}
    if (!section) return false;
    try {
      if (Array.from(section.querySelectorAll(".aply-group")).filter(isVisible).length >= rows.length) return false;
    } catch (eCount) {}
    var add = null;
    try {
      add = Array.from(section.querySelectorAll(".aply-form-top .aply-form-opt.add, .aply-form-empty, p, button, a, [role='button']")).find(function (node) {
        return isVisible(node) && /添加\s*(?:实习工作经历|实习经历)|添加/.test(normalizeText(node.textContent || node.getAttribute("aria-label") || node.getAttribute("title") || ""));
      }) || null;
    } catch (eAdd) {}
    if (!add) return false;
    var beforeCount = Array.from(section.querySelectorAll(".aply-group")).filter(isVisible).length;
    await safeClick(add);
    return !!(await waitUntil(function () {
      var live = Array.from(document.querySelectorAll(".aply-form")).find(function (node) { return /实习工作经历|实习经历/.test(normalizeText(node.textContent || "")); });
      return live && Array.from(live.querySelectorAll(".aply-group")).filter(isVisible).length > beforeCount ? true : null;
    }, 5000));
  }

  async function fillChinaHrCard(resume, matcher, sectionPattern, category, row, index) {
    if (!row) return false;
    var section = null;
    try {
      section = Array.from(document.querySelectorAll(".aply-form")).find(function (node) {
        return sectionPattern.test(normalizeText(node.textContent || ""));
      });
    } catch (e) {}
    if (!section) return false;
    var card = await waitUntil(function () {
      var liveSection = Array.from(document.querySelectorAll(".aply-form")).find(function (node) {
        return sectionPattern.test(normalizeText(node.textContent || ""));
      });
      if (!liveSection) return null;
      var groups = Array.from(liveSection.querySelectorAll(".aply-group")).filter(isVisible);
      if (index != null && index >= groups.length) return null;
      var candidate = groups[index == null ? groups.length - 1 : index] || (groups.length ? groups[groups.length - 1] : liveSection);
      return candidate && isVisible(candidate) && candidate.querySelector(
        "input:not([type='hidden']), textarea, select, [role='combobox'], .ant-select, .ant-cascader-picker"
      ) ? candidate : null;
    }, 4000);
    if (!card) return false;
    var engine = new AF.FillEngine(
      Object.assign({}, resume || {}, { education: [], internshipExperience: [] }),
      matcher
    );
    engine.shouldStop = isStopRequested;
    var result = await engine.executeVisibleFormFill(card, {
      overwriteExisting: true,
      recordOverride: { category: category, data: row },
    });
    return !!(result && result.success);
  }

  // 中国银行只提供页面字段差异；卡片的打开/新增统一交给通用多经历引擎。
  async function activateChinaHrRepeatCard(category, index, addText) {
    return activateStep({
      name: category === "education" ? "教育经历" : "实习工作经历",
      category: category,
      cardTitle: category === "education" ? "教育经历" : "实习工作经历",
      sectionByTitle: true,
      sectionRootSelector: ".aply-form",
      cardTitleSelector: ".aply-form-tit",
      strictRepeatAddRoot: true,
      readySelector: ".aply-group",
      strictReadyWithinCard: true,
      repeatForCategoryData: true,
      repeatIndex: index,
      forceAddRepeat: true,
      repeatAddText: [addText],
      repeatAddSelector: ".aply-form-empty, .aply-form-top .aply-form-opt.add",
      repeatAddCandidateSelector: "p, button, a, [role='button'], div, span",
      repeatAddOnlyWhenMissing: true,
      repeatAddWaitForRowCount: true,
      rowScopeSelector: ".aply-group",
      timeoutMs: 6000,
      waitAfterClickMs: 300,
    });
  }

  async function fillChinaHrOrderedSection(engine, category, titlePattern) {
    var section = null;
    try {
      section = Array.from(document.querySelectorAll(".aply-form")).find(function (node) {
        var title = node.querySelector(".aply-form-tit, .aply-form-top");
        return title && titlePattern.test(normalizeText(title.textContent || ""));
      });
    } catch (e) {}
    if (!section) return false;
    return !!(await engine.executeVisibleFormFill(section, { overwriteExisting: true }));
  }

  async function transitionSpdbPageAfterSave(currentPage, nextPage) {
    if (!currentPage || !nextPage || !currentPage.nextSelector || !nextPage.url) return false;
    await sleep(currentPage.nextDelayMs == null ? 1200 : currentPage.nextDelayMs);
    var nextButton = await waitUntil(function () {
      try { return Array.from(document.querySelectorAll(currentPage.nextSelector)).find(isVisible) || null; }
      catch (eFindNext) { return null; }
    }, currentPage.nextButtonTimeoutMs == null ? 5000 : currentPage.nextButtonTimeoutMs);
    if (!nextButton) throw new Error("保存成功后未找到浦发下一步按钮");
    var beforeHref = window.location.href;
    try { nextButton.scrollIntoView && nextButton.scrollIntoView({ block: "center", inline: "nearest" }); } catch (eScrollNext) {}
    if (typeof nextButton.click === "function") nextButton.click();
    else await safeClick(nextButton);
    await sleep(currentPage.nextClickVerifyMs == null ? 900 : currentPage.nextClickVerifyMs);
    var expectedHref = new URL(nextPage.url, beforeHref).href;
    try {
      var currentUrl = new URL(window.location.href);
      var expectedUrl = new URL(expectedHref);
      if (currentUrl.origin === expectedUrl.origin && currentUrl.pathname === expectedUrl.pathname) return true;
    } catch (eVerifyNext) {}
    window.location.href = expectedHref;
    return true;
  }

  function countVisibleFields(scope) {
    var root = scope || document;
    var selector = "input:not([type='hidden']), textarea, select, [contenteditable='true'], [role='textbox'], [role='combobox']";
    try {
      return Array.from(root.querySelectorAll(selector)).filter(isVisible).length;
    } catch (e) {
      return 0;
    }
  }

  function describeElement(element) {
    if (!element) return "";
    var tag = String(element.tagName || "").toLowerCase();
    var id = element.id ? "#" + element.id : "";
    var classes = "";
    try {
      classes = Array.from(element.classList || []).slice(0, 4).map(function (name) { return "." + name; }).join("");
    } catch (e) {}
    return tag + id + classes;
  }

  function buildDiagnosticMarkdown(workflow, results, startedAt) {
    var successful = results.filter(function (item) { return item.success; }).length;
    var skipped = results.filter(function (item) { return item.skipped; }).length;
    var executed = results.length - skipped;
    var lines = [
      "# 特殊站点工作流诊断报告",
      "",
      "- 网站：`" + window.location.hostname + "`",
      "- 页面：`" + window.location.href + "`",
      "- 工作流：" + (workflow.name || workflow.id || "未命名工作流"),
      "- 生成时间：" + new Date().toLocaleString(),
      "- 结果：" + successful + "/" + executed + " 个已执行步骤通过，" + skipped + " 个步骤因简历无数据跳过",
      "- 总耗时：" + (Date.now() - startedAt) + "ms",
      "",
    ];
    results.forEach(function (item, index) {
      lines.push("## " + (index + 1) + ". " + item.name);
      lines.push("");
      lines.push("- 状态：" + (item.skipped ? "⏭️ 跳过" : item.success ? "✅ 成功" : "❌ 失败"));
      lines.push("- category：`" + String(item.category || "") + "`");
      if (item.skipped) {
        lines.push("- 跳过原因：" + item.skipReason);
        lines.push("- 点击：未执行（不打开空表单）");
        lines.push("");
        return;
      }
      lines.push("- 入口：" + (item.triggerFound ? "已找到 `" + item.triggerElement + "`" : "未找到"));
      lines.push("- 点击：" + (item.clicked ? "成功" : item.skippedClick ? "当前步骤已就绪，未重复点击" : "未执行/失败"));
      lines.push("- 表单就绪：" + (item.ready ? "成功 `" + item.readyElement + "`" : "失败"));
      lines.push("- 可见字段：" + item.visibleFieldCount);
      lines.push("- 步骤耗时：" + item.duration + "ms");
      lines.push("- URL变化：" + (item.urlChanged ? "是" : "否"));
      lines.push("- 点击前URL：`" + item.urlBefore + "`");
      lines.push("- 点击后URL：`" + item.urlAfter + "`");
      if (item.error) lines.push("- 错误：" + item.error);
      lines.push("");
    });
    lines.push("## 说明", "", "诊断只测试大类导航和表单渲染，没有填写字段、保存表单或提交申请。", "");
    return lines.join("\n");
  }

  function downloadDiagnosticReport(markdown) {
    var timestamp = new Date().toISOString().replace(/[:.]/g, "-");
    var fileName = "特殊工作流诊断_" + window.location.hostname + "_" + timestamp + ".md";
    var blob = new Blob([markdown], { type: "text/markdown;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    var anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = fileName;
    anchor.style.display = "none";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    return fileName;
  }

  function describeWorkflowForError(workflow) {
    try {
      if (!workflow || typeof workflow !== "object") return "";
      return "（id=" + (workflow.id || "") +
        "，name=" + (workflow.name || "") +
        "，keys=" + Object.keys(workflow).slice(0, 12).join(",") + "）";
    } catch (e) {
      return "";
    }
  }

  function ensureWorkflowSteps(workflow) {
    if (workflow && Array.isArray(workflow.steps) && workflow.steps.length > 0) return workflow;
    try {
      if (AF.PrivateSpecialSites && typeof AF.PrivateSpecialSites.getWorkflowForUrl === "function") {
        var privateWorkflow = AF.PrivateSpecialSites.getWorkflowForUrl(window.location.href);
        if (privateWorkflow && Array.isArray(privateWorkflow.steps) && privateWorkflow.steps.length > 0) {
          return privateWorkflow;
        }
      }
    } catch (ePrivateWorkflow) {}
    return workflow;
  }

  async function diagnose(options) {
    options = options || {};
    var workflow = options.workflow;
    var resume = options.resume;
    var onProgress = options.onProgress;
    workflow = ensureWorkflowSteps(workflow);
    if (!workflow || !Array.isArray(workflow.steps) || workflow.steps.length === 0) {
      throw new Error("特殊站点工作流没有配置 steps" + describeWorkflowForError(workflow));
    }
    var steps = workflow.steps.filter(function (step) { return step && step.enabled !== false; });
    // 部分特殊站点每个栏目都是独立页面。此模式下插件只处理当前页实际
    // 已打开的步骤，避免把其它页面的栏目入口当成当前表单并提前结束。
    if (workflow.currentPageOnly === true) {
      var urlMatchedSteps = steps.filter(function (step) {
        if (!step.pageUrlPattern) return true;
        try { return step.pageUrlPattern.test(window.location.href); } catch (eUrlPattern) { return false; }
      });
      if (urlMatchedSteps.length) steps = urlMatchedSteps;
      if (/^job\.spdb\.com\.cn$/i.test(window.location.hostname)) {
        var spdbPageSteps = steps.filter(function (step) { return step && step.pageUrlPattern && step.pageUrlPattern.test(window.location.href); });
        if (spdbPageSteps.length) steps = spdbPageSteps;
      }
      var readyStep = steps.find(function (step) {
        try { return resolveReadyElement(step); } catch (eReadyStep) { return null; }
      });
      if (readyStep) steps = [readyStep];
      else {
        var triggerStep = steps.find(function (step) {
          try { return findTrigger(step); } catch (eTriggerStep) { return null; }
        });
        if (triggerStep) steps = [triggerStep];
      }
    }
    var startedAt = Date.now();
    var results = [];

    for (var i = 0; i < steps.length; i++) {
      var step = steps[i];
      if (typeof onProgress === "function") onProgress(i + 1, steps.length, step);
      var stepStartedAt = Date.now();
      var item = {
        name: step.name || step.category || "未命名步骤",
        category: step.category || "",
        success: false,
        skipped: false,
        skipReason: "",
        triggerFound: false,
        triggerElement: "",
        clicked: false,
        skippedClick: false,
        ready: false,
        readyElement: "",
        visibleFieldCount: 0,
        urlBefore: window.location.href,
        urlAfter: window.location.href,
        urlChanged: false,
        duration: 0,
        error: "",
      };
      var dataDecision = getStepDataDecision(step, resume);
      if (!dataDecision.shouldRun) {
        if (step.runRepeatPrerequisiteWhenNoData && step.repeatAddPrerequisite) {
          var emptyPrerequisiteStep = Object.assign({}, step, {
            repeatForCategoryData: false,
            fieldSequence: [],
            preFieldSequence: [step.repeatAddPrerequisite],
            scopeSelector: step.repeatPrerequisiteScopeSelector || step.scopeSelector,
            dataTransform: step.emptyDataTransform,
            skipSave: true,
          });
          runnableSteps.push(emptyPrerequisiteStep);
        }
        item.skipped = true;
        item.skipReason = dataDecision.reason;
        item.duration = Date.now() - stepStartedAt;
        results.push(item);
        continue;
      }
      if (step.skipWhenUnavailable && !findTrigger(step) && !(step.skipClickWhenReady !== false && resolveReadyElement(step))) {
        item.skipped = true;
        item.skipReason = "当前页面没有可见入口，可能被当前简历类型隐藏";
        item.duration = Date.now() - stepStartedAt;
        results.push(item);
        continue;
      }
      try {
        var readyBefore = resolveReadyElement(step);
        var trigger = findTrigger(step);
        if (!readyBefore && !trigger && /^job\.spdb\.com\.cn$/i.test(window.location.hostname) &&
            String(workflow.id || "") === "spdb-recruitment" && step.pageUrlPattern) {
          try {
            if (step.pageUrlPattern.test(window.location.href)) {
              readyBefore = document.querySelector(step.scopeSelector || ".fromcontainer") || document.querySelector(".fromcontainer");
              if (readyBefore) step.skipClickWhenReady = true;
            }
          } catch (eSpdbReadyFallback) {}
        }
        item.triggerFound = !!trigger;
        item.triggerElement = describeElement(trigger);
        if (!trigger && !(readyBefore && step.skipClickWhenReady !== false)) throw new Error("找不到大类入口");
        if (readyBefore && step.skipClickWhenReady !== false) {
          item.skippedClick = true;
        } else {
    if (step.triggerNativeClick === true && typeof trigger.click === "function") trigger.click();
    else await safeClick(trigger);
          item.clicked = true;
          await sleep(step.waitAfterClickMs == null ? 200 : step.waitAfterClickMs);
          await clickActionAfterTrigger(step, trigger);
        }
        var ready = await waitUntil(function () { return resolveReadyElement(step); }, step.timeoutMs);
        if (!ready) throw new Error("未等到 readySelector/scopeSelector 对应表单出现");
        item.ready = true;
        item.readyElement = describeElement(ready);
        var scope = step.cardAsScope
          ? resolveStepScope(step, ready)
          : (step.scopeSelector ? resolveStepScope(step, ready) : (step.autoDiscovered ? document : ready));
        item.visibleFieldCount = countVisibleFields(scope || document);
        if (item.visibleFieldCount === 0) throw new Error("点击后没有检测到可见表单字段");
        item.success = true;
        if (step.diagnosticCloseSelector) {
          var diagnosticClose = ready.querySelector(step.diagnosticCloseSelector) || document.querySelector(step.diagnosticCloseSelector);
          if (diagnosticClose && isVisible(diagnosticClose)) {
            await safeClick(diagnosticClose);
            await sleep(200);
          }
        }
      } catch (err) {
        item.error = err && err.message ? err.message : String(err);
      }
      item.urlAfter = window.location.href;
      item.urlChanged = item.urlAfter !== item.urlBefore;
      item.duration = Date.now() - stepStartedAt;
      results.push(item);
      if (!item.success && (workflow.continueOnError === false || step.continueOnError === false)) break;
    }

    var markdown = buildDiagnosticMarkdown(workflow, results, startedAt);
    var fileName = downloadDiagnosticReport(markdown);
    var successCount = results.filter(function (item) { return item.success; }).length;
    var skippedCount = results.filter(function (item) { return item.skipped; }).length;
    return {
      workflowName: workflow.name || workflow.id || "特殊站点",
      stepCount: results.length,
      successCount: successCount,
      skippedCount: skippedCount,
      failedCount: results.length - successCount - skippedCount,
      duration: Date.now() - startedAt,
      fileName: fileName,
      results: results,
    };
  }

  async function execute(options) {
    options = options || {};
    var workflow = options.workflow;
    var resume = options.resume;
    var config = options.config;
    var onProgress = options.onProgress;
    workflow = ensureWorkflowSteps(workflow);
    if (!workflow || !Array.isArray(workflow.steps) || workflow.steps.length === 0) {
      throw new Error("特殊站点工作流没有配置 steps" + describeWorkflowForError(workflow));
    }
    if (!config) throw new Error("当前页面没有可用的站点表单配置，请先生成或配置站点选择器");

    // 有些站点只是需要纳入特殊站点权限/识别范围，表单本身仍应完全复用
    // 普通“一键填写”的成熟引擎。此开关必须由站点私有配置显式声明，
    // 不进入任何特殊步骤、入口点击或字段编排逻辑。
    if (workflow.genericAutofill === true) {
      var genericMatcher = new AF.ElementMatcher(config);
      // 先屏蔽通用引擎对中国银行两个同结构联系人输入框的模糊回填，
      // 防止“紧急联系人姓名”被误写进“紧急联系人手机”；随后由下面的
      // labelExact 序列按当前 li 精确纠正。其他字段仍完整复用通用引擎。
      var genericResume = resume;
      if (String(workflow.id || "") === "chinahr-bank-recruitment" && resume && typeof resume === "object") {
        genericResume = Object.assign({}, resume);
        genericResume.basicInfo = Object.assign({}, resume.basicInfo || {});
        if (Array.isArray(resume.education)) {
          genericResume.education = resume.education.filter(function (row) {
            return !/高中|中专/.test(String(row && (row.level || row.educationLevel || "") || ""));
          }).map(function (row) {
            var copy = Object.assign({}, row || {});
            copy.degree = normalizeSpdbDegree(copy.degree || copy.degreeName || copy.degreeType || copy.degreeLevel || copy.academicDegree || copy.level || copy.educationLevel);
            var rank = copy.classRank || copy.ranking || copy.gradeRank;
            if (rank != null && String(rank).trim() !== "") {
              rank = String(rank).replace(/\s+/g, "").replace(/^前(?=\d)/, "前 ");
              copy.classRank = rank;
              copy.ranking = rank;
              copy.gradeRank = rank;
            }
            return copy;
          });
        }
        if (Array.isArray(resume.internshipExperience)) {
          genericResume.internshipExperience = resume.internshipExperience.map(function (row) {
            var copy = Object.assign({}, row || {});
            copy.workType = "实习（未毕业在校生兼职或实习）";
            copy.employmentType = copy.workType;
            copy.jobNature = copy.workType;
            copy.reasonForLeaving = "无";
            copy.phone = "无";
            copy.contactPhone = "无";
            return copy;
          });
        }
        if (Array.isArray(resume.campusActivities)) {
          var activityText = resume.campusActivities.map(function (activity) {
            var name = String(activity && (activity.activityName || activity.name || "") || "").trim();
            var content = String(activity && (activity.description || activity.content || "") || "").trim();
            return [name, content].filter(Boolean).join(" ");
          }).filter(Boolean).join(" ");
          genericResume.campusActivities = activityText ? [{ description: activityText }] : [];
        }
        genericResume.otherInfo = Object.assign({}, resume.otherInfo || {});
        genericResume.otherInfo.professionalCertificates = (resume.certificates || []).map(function (item) {
          return String(item && (item.certificateName || item.name || "") || "").trim();
        }).filter(Boolean).join(" ");
        genericResume.otherInfo.projectExperienceSummary = (resume.projectExperience || []).map(function (item) {
          var time = [item && item.startTime, item && item.endTime].filter(Boolean).join("至");
          return [time, item && (item.name || item.projectName), item && (item.details || item.description), item && (item.contributions || item.role), item && item.result]
            .map(function (value) { return String(value || "").trim(); }).filter(Boolean).join(" ");
        }).filter(Boolean).join(" ");
        genericResume.otherInfo.researchResults = (resume.publications || []).map(function (item) {
          return String(item && (item.paperTitle || item.name || "") || "").trim();
        }).filter(Boolean).join(" ");
        genericResume.otherInfo.awardsSummary = (resume.awards || []).map(function (item) {
          return [item && (item.awardTime || item.time), item && (item.awardName || item.name), item && (item.awardLevel || item.awardGrade || item.level)]
            .map(function (value) { return String(value || "").trim(); }).filter(Boolean).join(" ");
        }).filter(Boolean).join(" ");
        genericResume.degree = normalizeSpdbDegree(genericResume.degree || genericResume.degreeType || genericResume.level || genericResume.educationLevel);
        delete genericResume.workExperience;
        delete genericResume.fullTimeWorkExperience;
        delete genericResume.itSkills;
        delete genericResume.professionalSkills;
        delete genericResume.skills;
        ["name", "idNumber", "gender", "birthDate", "hukouLocation"].forEach(function (key) {
          delete genericResume[key];
          delete genericResume.basicInfo[key];
        });
      }
      var genericEngine = new AF.FillEngine(genericResume, genericMatcher);
      genericEngine.shouldStop = isStopRequested;
      var genericResult = { success: false, filledCount: 0, totalFieldsFound: 0 };
      if (String(workflow.id || "") !== "chinahr-bank-recruitment" &&
          Array.isArray(workflow.genericFieldSequence) && workflow.genericFieldSequence.length) {
        var genericBasic = Object.assign({}, resume && resume.basicInfo || {}, resume || {});
        genericBasic.familyAddress = genericBasic.familyAddress || genericBasic.currentAddressDetail || genericBasic.currentAddress || "";
        genericBasic.emergencyPhone = genericBasic.emergencyPhone || genericBasic.emergencyContactPhone || genericBasic.emergencyContactMobile || "";
        if (resume && resume.selfIntroduction && typeof resume.selfIntroduction === "object") {
          genericBasic.selfIntroduction = resume.selfIntroduction.selfIntroduction || resume.selfIntroduction.description || "";
        }
        await executeFieldSequence(genericEngine, genericMatcher, { id: workflow.id, fieldSequence: workflow.genericFieldSequence }, genericBasic, "basicInfo", document);
      }
      if (String(workflow.id || "") === "chinahr-bank-recruitment") {
        genericResult = await genericEngine.execute();
        if (Array.isArray(workflow.otherInfoFieldSequence) && workflow.otherInfoFieldSequence.length) {
          var otherInfoSection = Array.from(document.querySelectorAll(".aply-form")).find(function (node) {
            return /其他情况/.test(normalizeText(node.textContent || ""));
          });
          await executeFieldSequence(
            genericEngine,
            genericMatcher,
            { fieldSequence: workflow.otherInfoFieldSequence },
            genericResume.otherInfo || {},
            "otherInfo",
            otherInfoSection || document
          );
        }
      }
      return genericResult;
    }

    var runnableSteps = [];
    var skippedRepeatStepDiagnostics = [];
    var executionSteps = workflow.steps;
    var storedTestTargetSection = "";
    try { storedTestTargetSection = window.sessionStorage.getItem("AF_TEST_TARGET_SECTION") || ""; } catch (eTestTargetStorage) {}
    var testTargetSection = String(window.__AF_TEST_TARGET_SECTION__ || storedTestTargetSection || "").trim();
    if (testTargetSection) {
      executionSteps = executionSteps.filter(function (step) {
        return step && normalizeSectionTitle(step.cardTitle || step.name) === normalizeSectionTitle(testTargetSection);
      });
    }
    if (String(workflow.id || "") === "zhaopin-campus-enterprise-resume-v1") {
      var activeSectionState = detectActiveSectionState();
      if (activeSectionState.detectedSection) {
        // 公共模板所有左侧栏目都属于同一条顺序工作流。用户从任意已经打开的
        // 已识别栏目再次点击“一键填写”时，只跳过该栏目之前的步骤，而不是
        // 重新从个人信息开始；这也让高等教育完成后的实习/项目续填可恢复。
        executionSteps = resumeExecutionStepsFromActiveSection(executionSteps, activeSectionState.detectedSection);
      }
      if (activeSectionState.detectedSection === "高等教育经历") {
        writeHigherEducationTrace({ sectionStateTrace: activeSectionState });
      }
    }
    var continuationMarker = null;
    try {
      continuationMarker = JSON.parse(window.sessionStorage.getItem("__afSpecialWorkflowAutoContinue") || "null");
    } catch (eContinuationMarker) {}
    if (
      !continuationMarker ||
      String(continuationMarker.workflowId || "") !== String(workflow.id || workflow.name || "") ||
      continuationMarker.hostname !== window.location.hostname ||
      continuationMarker.pagePath !== window.location.pathname ||
      Date.now() - Number(continuationMarker.startedAt || 0) > 20 * 60 * 1000
    ) continuationMarker = null;
    var manualResumeCheckpoint = await loadManualWorkflowCheckpoint(workflow);
    var recoveryResumeCheckpoint = await loadRecoveryWorkflowCheckpoint(workflow);
    // Build151: a later recovery checkpoint must not be shadowed by an older
    // manual gate from a previous workflow step (the exact BankComm award bug).
    // Prefer the newer checkpoint only when it is at the same/later plan step;
    // otherwise keep the older safety gate authoritative.
    if (manualResumeCheckpoint && recoveryResumeCheckpoint) {
      var manualCheckpointIndex = Number(manualResumeCheckpoint.stepIndex);
      var recoveryCheckpointIndex = Number(recoveryResumeCheckpoint.stepIndex);
      var recoveryIsNewer = Number(recoveryResumeCheckpoint.updatedAt || 0) >= Number(manualResumeCheckpoint.updatedAt || 0);
      var recoveryIsSameOrLater = !Number.isInteger(manualCheckpointIndex) || !Number.isInteger(recoveryCheckpointIndex) || recoveryCheckpointIndex >= manualCheckpointIndex;
      if (recoveryIsNewer && recoveryIsSameOrLater) {
        await clearManualWorkflowCheckpoint();
        manualResumeCheckpoint = null;
      } else {
        recoveryResumeCheckpoint = null;
      }
    }
    var manualResumeStartIndex = -1;
    var manualResumeResolvedStepIndex = -1;
    var manualResumeNotice = "";
    var recoveryResumeStartIndex = -1;
    var recoveryResumeRepeatIndex = -1;
    var recoveryResumeActionCursor = null;
    var recoveryResumeRecordLock = null;
    var recoveryResumeNotice = "";
    var recoveryAcknowledgedCheckpoint = null;
    if (recoveryResumeCheckpoint) {
      var recoveryPlanPosition = resolveRecoveryCheckpointPlanPosition(recoveryResumeCheckpoint, executionSteps, resume);
      if (!recoveryPlanPosition) {
        await clearRecoveryWorkflowCheckpoint();
        recoveryResumeCheckpoint = null;
        recoveryResumeNotice = "[恢复执行] 上次恢复检查点与当前简历/页面不再一致，已安全失效并重新规划。";
      } else {
        // User-acknowledged recovery: clicking one-click fill again is the explicit
        // confirmation that the user has manually handled the interrupted item.
        // Active-section resume can slice/reindex the execution plan, so never trust
        // the old numeric index alone: resolve the step again by stable step identity.
        recoveryAcknowledgedCheckpoint = recoveryResumeCheckpoint;
        recoveryResumeRepeatIndex = Number(recoveryResumeCheckpoint.repeatIndex);
        recoveryResumeActionCursor = normalizedSpecialSequenceCursor(recoveryResumeCheckpoint);
        if (
          !recoveryResumeActionCursor &&
          Number.isInteger(recoveryResumeRepeatIndex) && recoveryResumeRepeatIndex >= 0 &&
          String(recoveryResumeCheckpoint.recordFingerprint || "")
        ) {
          recoveryResumeRecordLock = {
            active: true,
            repeatIndex: recoveryResumeRepeatIndex,
            recordFingerprint: String(recoveryResumeCheckpoint.recordFingerprint || ""),
            repeatGroupKey: String(recoveryResumeCheckpoint.repeatGroupKey || recoveryResumeCheckpoint.stepName || ""),
            reasonCode: String(recoveryResumeCheckpoint.reasonCode || "")
          };
        }
        recoveryResumeStartIndex = Number(recoveryPlanPosition.planIndex) +
          (recoveryResumeActionCursor
            ? 0
            : (Number.isInteger(recoveryResumeRepeatIndex) && recoveryResumeRepeatIndex >= 0 ? 0 : 1));
        recoveryResumeNotice = recoveryResumeActionCursor
          ? "[恢复执行] 已确认人工动作“" + String(recoveryResumeCheckpoint.fieldLabel || recoveryResumeCheckpoint.stepName || "上次中断位置") + "”已处理，将从动作游标之后继续；检查点之前的字段不会重新执行。"
          : "[恢复执行] 已按用户再次运行确认“" + String(recoveryResumeCheckpoint.stepName || "上次中断位置") + "”已手动处理，直接继续后续内容；此前已完成步骤不会重新执行。";
        await clearRecoveryWorkflowCheckpoint();
        recoveryResumeCheckpoint = null;
      }
    }
    if (manualResumeCheckpoint && manualResumeCheckpoint.status === "waiting_manual") {
      var storedStepIndex = Number(manualResumeCheckpoint.stepIndex);
      if (Number.isInteger(storedStepIndex) && storedStepIndex >= 0 && storedStepIndex < executionSteps.length) {
        var storedStep = executionSteps[storedStepIndex];
        var editorStillOpen = isCheckpointStepEditorOpen(storedStep);
        var checkpointPhase = String(manualResumeCheckpoint.phase || "");
        // Checkpoint-first execution: every one-click run starts from the persisted
        // workflow cursor. Earlier steps are never re-planned merely because the page
        // is currently showing them. A manual-step checkpoint can provide an explicit
        // resolver (for example: a saved high-school card now exists). Once resolved,
        // rerun that same step with the manual gate bypassed exactly once; the marker
        // is cleared only after the step itself saves/completes successfully.
        if (checkpointPhase === "before_save") {
          // Re-running one-click fill is the user's explicit confirmation that the
          // manual before-save work is complete. Do not second-guess the user by
          // probing the control again; continue from the next workflow step.
          manualResumeStartIndex = storedStepIndex + 1;
          manualResumeNotice = "[恢复执行] 已按用户再次运行确认“" + String(manualResumeCheckpoint.stepName || "上一模块") + "”人工步骤已处理，从下一检查点继续。";
          await clearManualWorkflowCheckpoint();
          manualResumeCheckpoint = null;
        } else if (checkpointPhase === "manual_step") {
          // A manual gate can still share a base step with later automatic records
          // (Bankcomm education is the canonical case). Acknowledge the manual gate
          // without re-checking it, then run that same base step with the gate
          // bypassed exactly once.
          manualResumeStartIndex = storedStepIndex;
          manualResumeResolvedStepIndex = storedStepIndex;
          manualResumeNotice = "[恢复执行] 已按用户再次运行确认人工检查点“" + String(manualResumeCheckpoint.stepName || "当前模块") + "”已处理，从该检查点继续自动填写。";
        } else {
          manualResumeStartIndex = storedStepIndex;
          manualResumeNotice = "[恢复执行] 从人工检查点“" + String(manualResumeCheckpoint.stepName || "当前模块") + "”继续。";
        }
      }
    }
    if (workflow.currentPageOnly === true) {
      var matchedPageSteps = executionSteps.filter(function (step) {
        if (!step.pageUrlPattern) return true;
        try { return step.pageUrlPattern.test(window.location.href); } catch (ePagePattern) { return false; }
      });
      if (matchedPageSteps.length) executionSteps = matchedPageSteps;
      if (/^job\.spdb\.com\.cn$/i.test(window.location.hostname)) {
        var spdbPageSteps = executionSteps.filter(function (step) { return step && step.pageUrlPattern && step.pageUrlPattern.test(window.location.href); });
        if (spdbPageSteps.length) executionSteps = spdbPageSteps;
      }
    }
    if (/^job\.spdb\.com\.cn$/i.test(window.location.hostname) && /\/mySchoolEdu(?:[?#]|$)/i.test(window.location.pathname)) {
      try {
        var spdbFirstEduCard = document.querySelector(".fromcontainer.formblocksolid .infoline");
        var spdbFirstEduForm = spdbFirstEduCard && spdbFirstEduCard.querySelector(".formblock.formedit");
        if (spdbFirstEduCard && spdbFirstEduForm && getComputedStyle(spdbFirstEduForm).display === "none") {
          var spdbFirstEduEdit = spdbFirstEduCard.querySelector(".toedit");
          if (spdbFirstEduEdit) { await safeClick(spdbFirstEduEdit); await sleep(320); }
        }
      } catch (eSpdbFirstEduOpen) {}
    }
    var orderedContinuationIndex = workflow.orderedContinuation === true && continuationMarker && Number.isInteger(Number(continuationMarker.completedStepBaseIndex))
      ? Number(continuationMarker.completedStepBaseIndex)
      : -1;
    executionSteps.forEach(function (step, stepIndex) {
      if (!step || step.enabled === false) return;
      if (manualResumeStartIndex >= 0 && stepIndex < manualResumeStartIndex) return;
      if (manualResumeStartIndex < 0 && recoveryResumeStartIndex >= 0 && stepIndex < recoveryResumeStartIndex) return;
      if (orderedContinuationIndex >= 0 && stepIndex < orderedContinuationIndex) return;
      var dataDecision = getStepDataDecision(step, resume, {
        // Checkpoint-first state machine: once the persisted manual gate has
        // been positively resolved, this same run must execute the current
        // step instead of recreating the same manual gate. Other validation
        // (including a different rowsValidator failure) still remains active.
        skipManualCheckpoint: manualResumeResolvedStepIndex === stepIndex
      });
      if (!dataDecision.shouldRun) {
        if (dataDecision.manualCheckpoint === true) {
          runnableSteps.push(Object.assign({}, step, {
            __afWorkflowStepIndex: stepIndex,
            manualCheckpointOnly: true,
            manualCheckpointReason: dataDecision.reason || "当前步骤需要人工补充资料",
            repeatForCategoryData: false,
            fieldSequence: [],
            preFieldSequence: [],
            skipSave: true,
            // If the user re-runs while the manual editor is still open, adopt
            // it instead of clicking Add again and creating a duplicate draft.
            skipClickWhenReady: true,
            keepEditorOnError: true
          }));
          return;
        }
        if (step.repeatForCategoryData === true) {
          skippedRepeatStepDiagnostics.push({
            name: step.name || step.cardTitle || step.category || "未命名重复大类",
            reason: dataDecision.reason || "未加入执行计划",
          });
        }
        if (step.navigateWhenNoData || step.wizardNavigateWhenNoData) {
          if (
            orderedContinuationIndex >= 0 &&
            stepIndex === orderedContinuationIndex &&
            continuationMarker.completedStepName === (step.name || step.category || "")
          ) return;
          runnableSteps.push(Object.assign({}, step, { navigationOnly: true, skipSave: true, __afWorkflowStepIndex: stepIndex }));
        }
        return;
      }
      if (!step.repeatForCategoryData) {
        if (orderedContinuationIndex >= 0 && stepIndex === orderedContinuationIndex && continuationMarker.completedStepName === (step.name || step.category || "")) return;
        if (orderedContinuationIndex < 0 && continuationMarker && continuationMarker.completedStepName === (step.name || step.category || "")) return;
        var nonRepeatRuntimeStep = Object.assign({}, step, {
          __afWorkflowStepIndex: stepIndex,
          __afCheckpointActionCursorEnabled: supportedRecoveryCheckpointWorkflow(workflow)
        });
        if (recoveryResumeActionCursor && recoveryAcknowledgedCheckpoint && stepIndex === recoveryResumeStartIndex) {
          nonRepeatRuntimeStep.__afRecoveryActionCursor = recoveryResumeActionCursor;
          nonRepeatRuntimeStep.__afRecoveryFieldStartIndex = recoveryResumeActionCursor.resumeFieldIndex;
          nonRepeatRuntimeStep.__afRecoveryCompletedActions = recoveryResumeActionCursor.completedActions.concat(
            recoveryResumeActionCursor.acknowledgeCurrentActionOnRerun && recoveryResumeActionCursor.currentAction
              ? [recoveryResumeActionCursor.currentAction] : []
          );
          nonRepeatRuntimeStep.skipClickWhenReady = true;
          nonRepeatRuntimeStep.keepEditorOnError = true;
        }
        runnableSteps.push(nonRepeatRuntimeStep);
        return;
      }
      if (orderedContinuationIndex >= 0 && stepIndex > orderedContinuationIndex) {
        continuationMarker = null;
      }
      var categories = Array.isArray(step.category) ? step.category : [step.category];
      var rows = (dataDecision.rows || []).map(function (row, originalIndex) {
        return { row: row, originalIndex: originalIndex };
      });
      if (
        manualResumeStartIndex < 0 && recoveryAcknowledgedCheckpoint &&
        stepIndex === recoveryResumeStartIndex &&
        Number.isInteger(recoveryResumeRepeatIndex) && recoveryResumeRepeatIndex >= 0
      ) {
        if (recoveryResumeActionCursor) {
          // Action-cursor recovery reuses the same record editor, freezes the
          // acknowledged prefix and resumes from the next field action.
          rows = rows.filter(function (entry) { return entry.originalIndex >= recoveryResumeRepeatIndex; });
        } else {
          // Legacy whole-record checkpoint: the failed repeat itself was fully
          // handled by the user, so continue with the following record.
          rows = rows.filter(function (entry) { return entry.originalIndex > recoveryResumeRepeatIndex; });
        }
      }
      // 国开行当前验收阶段只处理用户已经打开的一个高等教育编辑器。
      // 即使资料有硕士/本科两条，也绝不能把两条依次写入同一个可见表单。
      if (step.currentVisibleEditorMode === true && step.higherEducationNavigationAdapter !== true) rows = rows.slice(0, 1);
      if (continuationMarker && continuationMarker.repeatGroupKey === (step.name || step.cardTitle || categories.join("|"))) {
        var completedRepeatIndex = Number(continuationMarker.completedRepeatIndex);
        if (Number.isInteger(completedRepeatIndex)) {
          rows = rows.filter(function (entry) { return entry.originalIndex > completedRepeatIndex; });
        }
      }
      // repeatTotal is the size of the original profile plan, never the number
      // of rows left after checkpoint filtering. Keeping the full count prevents
      // states such as repeatIndex=2/repeatTotal=2 after record 0 was acknowledged.
      var plannedRepeatTotal = Array.isArray(dataDecision.rows) ? dataDecision.rows.length : rows.length;
      var existingCardCount = 0;
      if (step.updateExistingWhenPresent && step.existingCardSelector) {
        try {
          var existingRoot = step.repeatAddRootSelector
            ? document.querySelector(step.repeatAddRootSelector)
            : findStepCard(step, document);
          existingCardCount = existingRoot
            ? resolveExistingRepeatCards(step, existingRoot).length
            : 0;
        } catch (eExistingCount) {}
      }
      // 某些站点的经历必须“填一条→保存→再新增”。再次运行插件时，页面上
      // 已保存的卡片不能被当成空白重新创建。站点可提供 existingRowMatcher，
      // 按业务主键（如公司+职位+时间）识别已存在记录；只为缺少的记录生成步骤。
      // 平安的二次填写采用“按位置覆盖”：页面已有第 N 张卡片时，当前简历
      // 第 N 条必须打开旧卡片修改，不能因为公司/学校/项目名称变了就新增。
      // 只有没有启用位置覆盖，或页面当前没有任何旧卡片时，才使用业务主键
      // 去重逻辑。新用户 existingCardCount=0，原来的新增流程完全不变。
      var overwriteExistingByPosition = step.updateExistingWhenPresent &&
        step.overwriteExistingByPosition === true && existingCardCount > 0;
      if (!overwriteExistingByPosition && typeof step.existingRowMatcher === "function") {
        rows = rows.filter(function (entry) {
          try {
            return step.existingRowMatcher(entry.row, document, step, entry.originalIndex) !== true;
          } catch (e) {
            return true;
          }
        });
      }
      rows.forEach(function (entry, missingIndex) {
        var row = entry.row;
        // repeatIndex 代表原始简历中的顺序，而不是过滤已保存记录后的新序号。
        // 例如本科已存在、只缺硕士时，硕士仍应保留 originalIndex=1，从而
        // 触发“添加下一条”；若重置成 0，流程只点栏目而不会打开新增表单。
        var repeatIndex = entry.originalIndex;
        var updateExistingIndex;
        if (typeof step.existingRowIndexResolver === "function") {
          try {
            var resolvedExistingIndex = Number(step.existingRowIndexResolver(row, document, step, repeatIndex));
            if (Number.isInteger(resolvedExistingIndex) && resolvedExistingIndex >= 0) {
              updateExistingIndex = resolvedExistingIndex;
            }
          } catch (eResolveExistingIndex) {}
        } else if (overwriteExistingByPosition && repeatIndex < existingCardCount) {
          updateExistingIndex = repeatIndex;
        }
        runnableSteps.push(Object.assign({}, step, {
          __afWorkflowStepIndex: stepIndex,
          __afCheckpointActionCursorEnabled: supportedRecoveryCheckpointWorkflow(workflow),
          __afRecoveryActionCursor: recoveryResumeActionCursor && stepIndex === recoveryResumeStartIndex && repeatIndex === recoveryResumeRepeatIndex ? recoveryResumeActionCursor : null,
          __afRecoveryFieldStartIndex: recoveryResumeActionCursor && stepIndex === recoveryResumeStartIndex && repeatIndex === recoveryResumeRepeatIndex ? recoveryResumeActionCursor.resumeFieldIndex : 0,
          __afRecoveryCompletedActions: recoveryResumeActionCursor && stepIndex === recoveryResumeStartIndex && repeatIndex === recoveryResumeRepeatIndex
            ? recoveryResumeActionCursor.completedActions.concat(
                recoveryResumeActionCursor.acknowledgeCurrentActionOnRerun && recoveryResumeActionCursor.currentAction
                  ? [recoveryResumeActionCursor.currentAction] : []
              )
            : [],
          // After the user manually fixed/saved one repeat record, page-card order
          // must no longer be trusted for subsequent rows in the same group. The
          // next rows may only edit an existing card via business identity; otherwise
          // stop for review or add only when the page truly has fewer rows than plan.
          __afRecoveryRecordLock: recoveryResumeRecordLock && stepIndex === recoveryResumeStartIndex && repeatIndex > recoveryResumeRecordLock.repeatIndex
            ? Object.assign({}, recoveryResumeRecordLock) : null,
          __afDisablePositionalRepeatRepair: !!(recoveryResumeRecordLock && stepIndex === recoveryResumeStartIndex && repeatIndex > recoveryResumeRecordLock.repeatIndex),
          name: (step.name || step.cardTitle || categories[0]) + " 第" + (repeatIndex + 1) + "条",
          repeatGroupKey: step.name || step.cardTitle || categories.join("|"),
          repeatIndex: repeatIndex,
          missingRepeatIndex: missingIndex,
          updateExistingIndex: updateExistingIndex,
          // When business-key matching says this row is absent, an existing
          // unrelated card must not make repeatIndex=0 fall into the generic
          // "edit closed section" path. Explicitly open the add editor.
          forceAddRepeat: (
            step.forceAddFirstRepeatWhenNoExisting === true &&
            existingCardCount === 0 && repeatIndex === 0
          ) || (
            !overwriteExistingByPosition && existingCardCount > 0 &&
            typeof step.existingRowMatcher === "function" && !Number.isInteger(updateExistingIndex)
          ),
          // 即使已有记录被 existingRowMatcher 过滤，最终数量仍应按完整简历
          // 计划校验。例如页面已有高中和硕士、只新增本科，目标仍是3张而非1张。
          repeatTotal: plannedRepeatTotal,
          plannedRepeatRows: (dataDecision.rows || []).slice(),
          isLastRepeatStep: missingIndex === rows.length - 1,
          // 每个重复任务持有独立行对象，避免派生字段或后续步骤修改共享引用。
          dataOverride: [Object.assign({}, row)],
          categoryOverride: row.__afCategory || categories[0],
          // 某些原生表单（如中信）允许直接切换模块，明确配置 skipSave 时
          // 必须覆盖重复经历默认的“最后一条保存”规则。
          skipSave: step.skipSave === true || (step.saveEachRepeatStep ? false : missingIndex < rows.length - 1),
          skipClickWhenReady: recoveryResumeActionCursor && stepIndex === recoveryResumeStartIndex && repeatIndex === recoveryResumeRepeatIndex ? true : step.skipClickWhenReady,
          keepEditorOnError: recoveryResumeActionCursor && stepIndex === recoveryResumeStartIndex && repeatIndex === recoveryResumeRepeatIndex ? true : step.keepEditorOnError
        }));
      });
    });
    var recoveryAcknowledgedAtPlanEnd = !!(
      recoveryAcknowledgedCheckpoint && recoveryResumeStartIndex >= executionSteps.length
    );
    if (!runnableSteps.length && !continuationMarker && !recoveryAcknowledgedAtPlanEnd) {
      throw new Error(
        "站点配置和特殊工作流均已命中，但当前插件简历没有可填数据。" +
        "请在“我的简历”中填写或导入简历，并确认已选择正确的简历后重试"
      );
    }

    var summary = {
      success: true,
      filledCount: 0,
      totalFields: 0,
      failedFields: [],
      notices: Array.isArray(workflow.notices) ? workflow.notices.slice() : [],
      workflowName: workflow.name || workflow.id || "特殊站点",
    };
    var recoveryCompletedStepIndexes = [];
    var recoveryCompletedRepeatIndexes = {};
    // Build131 foundation: persistent completion ledger is observability-only.
    // It does not change runnableSteps, resume cursors, ownership or save behavior yet.
    var executionLedger = await checkpointCore().loadExecutionLedger(workflow, window.location);
    // Build117: Bankcomm already has mature site-specific execution. Before
    // changing any of those selectors/workflows again, surface a privacy-safe
    // per-step execution audit so real-site testing can distinguish planning,
    // editor/scope, field-fill, save and verification failures. Counts and
    // state only; never include resume values or arbitrary page text.
    var bankcommExecutionAudit = String(workflow.id || "") === "bankcomm-recruitment" ? {
      schemaVersion: 1,
      workflowId: "bankcomm-recruitment",
      plannedStepCount: runnableSteps.length,
      sourceCounts: {
        education: Array.isArray(resume && resume.education) ? resume.education.length : 0,
        awards: Array.isArray(resume && resume.awards) ? resume.awards.length : 0,
        workExperience: Array.isArray(resume && resume.workExperience) ? resume.workExperience.length : 0,
        internshipExperience: Array.isArray(resume && resume.internshipExperience) ? resume.internshipExperience.length : 0,
        languageSkills: Array.isArray(resume && resume.languageSkills) ? resume.languageSkills.length : 0,
        certificates: Array.isArray(resume && resume.certificates) ? resume.certificates.length : 0,
        familyMembers: Array.isArray(resume && resume.familyMembers) ? resume.familyMembers.length : 0
      },
      manualResumeStartIndex: manualResumeStartIndex,
      manualResumeResolvedStepIndex: manualResumeResolvedStepIndex,
      steps: []
    } : null;
    if (bankcommExecutionAudit) summary.bankcommExecutionAudit = bankcommExecutionAudit;
    if (manualResumeNotice) summary.notices.push(manualResumeNotice);
    if (recoveryResumeNotice) summary.notices.push(recoveryResumeNotice);
    if (manualResumeStartIndex >= 0) {
      summary.resumedFromManualCheckpoint = true;
      summary.manualResumeStepIndex = manualResumeStartIndex;
      summary.manualResumeStep = manualResumeCheckpoint && manualResumeCheckpoint.stepName || "";
      summary.manualResumeResolved = manualResumeResolvedStepIndex >= 0;
      summary.manualResumeResolvedStepIndex = manualResumeResolvedStepIndex;
    }
    if (manualResumeStartIndex < 0 && recoveryResumeStartIndex >= 0 && recoveryAcknowledgedCheckpoint) {
      summary.resumedFromRecoveryCheckpoint = true;
      summary.recoveryCheckpointAcknowledged = true;
      summary.recoveryResumeStepIndex = recoveryResumeStartIndex;
      summary.recoveryResumeRepeatIndex = recoveryResumeRepeatIndex;
      summary.recoveryResumeStep = String(recoveryAcknowledgedCheckpoint.stepName || "");
      summary.recoveryCheckpoint = recoveryAcknowledgedCheckpoint;
      summary.recoveryCheckpointResolved = true;
    }
    if (skippedRepeatStepDiagnostics.length) {
      skippedRepeatStepDiagnostics.forEach(function (item) {
        summary.notices.push("[特殊工作流] " + item.name + "：" + item.reason);
      });
    }
    var skippedRepeatGroups = {};
    var clearedHuaweiPages = {};
    for (var i = 0; i < runnableSteps.length; i++) {
      if (isStopRequested()) {
        summary.success = false;
        summary.stopped = true;
        break;
      }
      var step = runnableSteps[i];
      var activeBankcommAudit = null;
      if (bankcommExecutionAudit) {
        activeBankcommAudit = {
          runIndex: i,
          workflowStepIndex: Number.isInteger(Number(step.__afWorkflowStepIndex)) ? Number(step.__afWorkflowStepIndex) : -1,
          name: String(step.cardTitle || step.name || step.category || ""),
          category: Array.isArray(step.category) ? step.category.join("+") : String(step.categoryOverride || step.category || ""),
          repeatIndex: Number.isInteger(Number(step.repeatIndex)) ? Number(step.repeatIndex) : -1,
          repeatTotal: Number(step.repeatTotal || 0),
          status: "planned",
          triggerFound: false,
          readyBeforeActivation: false,
          scopeResolved: false,
          editableControlCount: 0,
          fillAttempted: false,
          filledCount: 0,
          failedFieldCount: 0,
          saveAttempted: false,
          saved: false,
          reason: ""
        };
        try { activeBankcommAudit.triggerFound = !!findTrigger(step); } catch (eBankcommAuditTrigger) {}
        try { activeBankcommAudit.readyBeforeActivation = !!resolveReadyElement(step); } catch (eBankcommAuditReady) {}
        bankcommExecutionAudit.steps.push(activeBankcommAudit);
      }
      if (step.higherEducationVariant === true) {
        higherEducationRuntimeBindings.clear();
        higherEducationFieldItemIds = typeof WeakMap === "function" ? new WeakMap() : null;
        higherEducationFieldItemIdSeed = 0;
        var initialHigherScope = resolveHigherEducationEditorScope(step);
        var initialHigherControls = [];
        var selectedHigherRow = Array.isArray(step.dataOverride) ? step.dataOverride[0] : null;
        var initialHigherEditorState = detectHigherEducationEditorState(step);
        initialHigherControls = initialHigherScope.scope ? enumerateInteractiveControls(initialHigherScope.scope).filter(function (entry) { return entry.visible; }) : [];
        var activeEditorControlTrace = initialHigherControls.map(function (entry, controlIndex) {
          var node = entry.element;
          var rect = node.getBoundingClientRect();
          var formItem = node.closest && node.closest(".el-form-item");
          var content = node.closest && node.closest(".el-form-item__content");
          return { index: controlIndex, tag: String(node.tagName || "").toLowerCase(), className: String(node.className || ""), role: String(node.getAttribute && node.getAttribute("role") || ""), type: String(node.type || node.getAttribute && node.getAttribute("type") || ""), tabindex: String(node.getAttribute && node.getAttribute("tabindex") || ""), visible: entry.visible, connected: node.isConnected !== false, rect: { x: Number(rect.x || rect.left || 0), y: Number(rect.y || rect.top || 0), width: Number(rect.width || 0), height: Number(rect.height || 0) }, nearestFormItemClass: String(formItem && formItem.className || ""), nearestContentClass: String(content && content.className || ""), hasShadowRoot: !!node.shadowRoot };
        });
        writeHigherEducationTrace({
          scope: { resolved: !!initialHigherScope.scope, strategy: initialHigherScope.strategy || "", visibleLabelCount: initialHigherScope.scope ? higherEducationLabelNodes(initialHigherScope.scope).length : 0, controlCount: initialHigherControls.length, reason: initialHigherScope.scope ? "" : (initialHigherScope.reason || "higher_education_scope_not_resolved") },
          currentVisibleEditorMode: initialHigherEditorState.editorReady,
          records: [],
          higherEducationRecordTrace: { recordIndex: Number.isInteger(step.repeatIndex) ? step.repeatIndex : 0, indexBase: 0, hasResearchDirection: !!(selectedHigherRow && selectedHigherRow.researchDirection), hasDepartment: !!(selectedHigherRow && selectedHigherRow.department), hasMajor: !!(selectedHigherRow && selectedHigherRow.major), hasCourses: !!(selectedHigherRow && ((Array.isArray(selectedHigherRow.courses) && selectedHigherRow.courses.length) || selectedHigherRow.majorCourses)), hasGpa: !!(selectedHigherRow && selectedHigherRow.gpa) },
          currentVisibleEditorExecutionTrace: { enabled: true, selectedProfileRecordIndex: Number.isInteger(step.repeatIndex) ? step.repeatIndex : 0, indexBase: 0, attemptedRecordCount: 1 },
          zhaopinChoiceTrace: []
          ,activeEditorControlTrace: activeEditorControlTrace
        });
      }
      if (step.repeatGroupKey && skippedRepeatGroups[step.repeatGroupKey]) {
        if (activeBankcommAudit) {
          activeBankcommAudit.status = "skipped_previous_repeat_failure";
          activeBankcommAudit.reason = "previous_repeat_failed";
        }
        summary.failedFields.push({
          fieldKey: "specialWorkflow",
          label: "[特殊工作流] " + (step.name || step.category || "未命名步骤"),
          reason: "同一大类前序条目未保存成功，已跳过，避免覆盖上一条未保存内容",
        });
        continue;
      }
      if (typeof onProgress === "function") onProgress(i + 1, runnableSteps.length, step);
      if (step.skipWhenUnavailable && !findTrigger(step) && !(step.skipClickWhenReady !== false && resolveReadyElement(step))) {
        if (activeBankcommAudit) {
          activeBankcommAudit.status = "skipped_unavailable";
          activeBankcommAudit.reason = "trigger_and_ready_missing";
        }
        continue;
      }
      try {
        if (step.waitBeforeActivateCloseSelector) {
          var previousEditorClosed = await waitUntil(function () {
            var visibleEditors = queryVisibleIncludingRoot(document, step.waitBeforeActivateCloseSelector).filter(isVisible);
            return visibleEditors.length ? null : true;
          }, step.waitBeforeActivateCloseTimeoutMs || 2500);
          if (!previousEditorClosed) {
            throw new Error("上一个弹窗尚未关闭，暂停打开下一项：" + (step.name || step.category || "未命名步骤"));
          }
        }
        if (step.handleNavigationSavePrompt) {
          var pendingPrompt = Array.from(document.querySelectorAll(".el-message-box")).filter(isVisible).find(function (node) { return /当前模块还未保存|保存当前模块信息/.test(normalizeText(node.textContent)); });
          if (pendingPrompt) {
            var pendingJump = Array.from(pendingPrompt.querySelectorAll("button, [role='button']")).find(function (node) { return /保存并跳转/.test(normalizeText(node.textContent)); });
            if (pendingJump) { await safeClick(pendingJump); await sleep(400); }
          }
        }
        var activatedReady = null;
        if (step.higherEducationNavigationAdapter === true) {
          writeHigherEducationTrace({ educationRepeatNavigationTrace: createInitialEducationRepeatNavigationTrace(step) });
          var sectionNavigation = await navigateToResumeSection("高等教育经历", step);
          writeHigherEducationTrace({ resumeSectionNavigationTrace: sectionNavigation, moduleTransactionTrace: sectionNavigation.moduleTransactionTrace || {} });
          if (!sectionNavigation.entered) {
            if (sectionNavigation.moduleTransactionTrace && sectionNavigation.moduleTransactionTrace.result === "blocked_by_validation") {
              var blockingNames = sectionNavigation.moduleTransactionTrace.blockingLabels || [];
              summary.notices.push("个人信息仍有必填项未完成，无法进入高等教育经历。" + (blockingNames.length ? "请检查：" + blockingNames.join("、") : ""));
            }
            throw new Error("needs_user_action:" + (sectionNavigation.reason || "section_change_timeout"));
          }
          activatedReady = findResumeSectionRootByTitle("高等教育经历") || resolveReadyElement(step);
        } else if (step.zhaopinRepeatNavigationAdapter === true) {
          var repeatSectionTitle = String(step.cardTitle || step.name || "");
          var repeatSectionNavigation = await navigateToResumeSection(repeatSectionTitle, step);
          if (!repeatSectionNavigation.entered) {
            throw new Error("needs_user_action:" + (repeatSectionNavigation.reason || "section_change_timeout"));
          }
          activatedReady = findResumeSectionRootByTitle(repeatSectionTitle) || findStepCard(step, document);
        } else {
          activatedReady = await activateStep(step);
        }
        if (step.higherEducationVariant === true) {
          var initialEditorState = detectHigherEducationEditorState(step);
          var editorStateTrace = {
            initialState: initialEditorState.state,
            sectionScopeResolved: !!initialEditorState.section,
            editableControlCount: initialEditorState.editableControlCount,
            editButtonFound: !!initialEditorState.editButton,
            editButtonClicked: false,
            stateAfterClick: initialEditorState.state,
            editorReady: initialEditorState.editorReady,
            reason: initialEditorState.reason || ""
          };
          if (initialEditorState.state === "display" && initialEditorState.editButton) {
            await safeClick(initialEditorState.editButton);
            editorStateTrace.editButtonClicked = true;
            var openedEditorState = await waitUntil(function () {
              var nextState = detectHigherEducationEditorState(step);
              return nextState.editorReady ? nextState : null;
            }, step.timeoutMs || 6000);
            var finalEditorState = openedEditorState || detectHigherEducationEditorState(step);
            editorStateTrace.stateAfterClick = finalEditorState.state;
            editorStateTrace.editableControlCount = finalEditorState.editableControlCount;
            editorStateTrace.editorReady = finalEditorState.editorReady;
            editorStateTrace.reason = finalEditorState.editorReady ? "" : (finalEditorState.reason || "higher_education_editor_not_open");
            activatedReady = finalEditorState.editorReady ? (resolveHigherEducationEditorScope(step).scope || activatedReady) : activatedReady;
          }
          writeHigherEducationTrace({ higherEducationEditorStateTrace: editorStateTrace, currentVisibleEditorMode: editorStateTrace.editorReady });
          if (!editorStateTrace.editorReady) throw new Error("needs_user_action:higher_education_editor_not_open");
        }
        if (step.handleNavigationSavePrompt) {
          var navigationPrompt = null;
          try { navigationPrompt = Array.from(document.querySelectorAll(".el-message-box")).filter(isVisible).find(function (node) { return /当前模块还未保存|保存当前模块信息/.test(normalizeText(node.textContent)); }) || null; } catch (eNavigationPrompt) {}
          if (navigationPrompt) {
            var saveAndJump = findByText(navigationPrompt, ["保存并跳转"], "button, [role='button']");
            if (saveAndJump) {
              await safeClick(saveAndJump);
              await sleep(step.waitAfterConfirmMs || 350);
              activatedReady = await waitUntil(function () { return resolveReadyElement(step) || null; }, step.timeoutMs || 6000);
            }
          }
        }
        var readyForScope = step.strictReadyWithinCard === true
          ? activatedReady
          : resolveReadyElement(step);
        var scope = step.cardAsScope
          ? resolveStepScope(step, readyForScope)
          : (step.scopeSelector ? resolveStepScope(step, readyForScope) : null);
        if (activeBankcommAudit) {
          activeBankcommAudit.status = "activated";
          activeBankcommAudit.scopeResolved = !!(scope || readyForScope || activatedReady);
          try {
            var auditScope = scope || readyForScope || activatedReady || document;
            activeBankcommAudit.editableControlCount = enumerateInteractiveControls(auditScope).filter(function (entry) { return entry.visible; }).length;
          } catch (eBankcommAuditControls) {}
        }
        if (step.manualCheckpointOnly === true) {
          summary.manualActionRequired = true;
          summary.pausedForManualAction = true;
          summary.manualActionStep = step.name || step.cardTitle || step.category || "当前步骤";
          summary.manualActionReason = String(step.manualCheckpointReason || "当前步骤需要人工补充资料");
          summary.message = summary.manualActionReason + "。已打开对应编辑区域，请手动填写并保存；完成后再次点击“一键填写”，程序会继续后续步骤。";
          summary.notices.push(
            "[人工检查点] " + summary.manualActionStep + "：" + summary.manualActionReason +
            "。请手动填写并保存，随后再次运行一键填写。"
          );
          await saveManualWorkflowCheckpoint(workflow, step, "manual_step", { reason: summary.manualActionReason });
          if (activeBankcommAudit) {
            activeBankcommAudit.status = "manual_checkpoint";
            activeBankcommAudit.reason = "manual_action_required";
          }
          // This is a deliberate resumable pause, not a workflow failure.
          // Leave the editor open and do not click Save or later sections.
          break;
        }
        if (step.higherEducationNavigationAdapter === true) {
          var editableEducation = await runHigherEducationNavigationAdapter(step);
          var educationRepeatNavigationTrace = {
            enteredSection: !!editableEducation.enteredSection,
            sectionDetected: String(editableEducation.sectionDetected || ""),
            profileRecordCount: Number(editableEducation.profileRecordCount || 0),
            existingPageRecordCount: Number(editableEducation.existingPageRecordCount || 0),
            missingRecordCount: Number(editableEducation.missingRecordCount || 0),
            targetProfileRecordIndex: Number.isInteger(editableEducation.targetProfileRecordIndex) ? editableEducation.targetProfileRecordIndex : -1,
            matchedExistingRecordIndex: Number.isInteger(editableEducation.matchedExistingRecordIndex) ? editableEducation.matchedExistingRecordIndex : -1,
            addButtonFound: !!editableEducation.addButtonFound,
            addButtonClicked: !!editableEducation.addButtonClicked,
            editButtonFound: !!editableEducation.editButtonFound,
            editButtonClicked: !!editableEducation.editButtonClicked,
            action: String(editableEducation.action || ""),
            editorAppeared: !!editableEducation.editorAppeared,
            editorControlCount: Number(editableEducation.editableControlCount || 0),
            genericFillerStarted: false,
            safeToLeave: editableEducation.safeToLeave === true,
            stoppedBecause: String(editableEducation.stoppedBecause || "")
          };
          writeHigherEducationTrace({
            educationRecordIndex: Number.isInteger(step.repeatIndex) ? step.repeatIndex : 0,
            sectionRootFound: !!editableEducation.sectionRootFound,
            editableRootFound: !!editableEducation.editableRootFound,
            editableControlCount: editableEducation.editableControlCount,
            editorState: editableEducation.editorState,
            addButtonFound: !!editableEducation.addButtonFound,
            addButtonClicked: !!editableEducation.addButtonClicked,
            reason: editableEducation.reason || "",
            educationRepeatNavigationTrace: educationRepeatNavigationTrace,
            records: []
          });
          if (!editableEducation.root) {
            if (editableEducation.safeToLeave === true && editableEducation.reason === "education_no_missing_record") {
              educationRepeatNavigationTrace.safeToLeave = true;
              educationRepeatNavigationTrace.stoppedBecause = "education_complete_no_missing_record";
              writeHigherEducationTrace({ educationRepeatNavigationTrace: educationRepeatNavigationTrace });
              summary.notices.push("高等教育经历已与资料库记录匹配，无需新增，继续后续分区。");
              continue;
            }
            summary.notices.push("高等教育经历当前处于查看状态，请点击“添加”或“编辑”后再次运行一键填写。");
            throw new Error("needs_user_action:" + (editableEducation.reason || "higher_education_editor_not_open"));
          }
          scope = editableEducation.root;
        }
        if (step.zhaopinRepeatNavigationAdapter === true) {
          var editableRepeat = await runZhaopinRepeatNavigationAdapter(step);
          step.__afZhaopinRepeatAction = String(editableRepeat.action || "");
          step.__afZhaopinRepeatExcessRecordCount = Number(editableRepeat.excessRecordCount || 0);
          if (editableRepeat.excessRepairMode === "repair_planned_rows_preserve_excess" && Number(step.repeatIndex || 0) === 0) {
            summary.notices.push(
              (step.cardTitle || step.name || "重复经历") + "检测到" + Number(editableRepeat.excessRecordCount || 0) +
              "条明显重复的多余记录；本轮只修复资料库计划范围内的记录，不自动删除多余记录，请人工复核删除。"
            );
          }
          if (!editableRepeat.root) {
            if (editableRepeat.safeToLeave === true && editableRepeat.reason === "repeat_record_already_present") {
              summary.notices.push((step.cardTitle || step.name || "重复经历") + "第" + (Number(step.repeatIndex || 0) + 1) + "条已存在，跳过重复新增。 ");
              continue;
            }
            throw new Error("needs_user_action:" + (editableRepeat.reason || "repeat_editor_not_open"));
          }
          scope = editableRepeat.root;
        }

        if ((step.scopeSelector || step.cardAsScope) && !scope && !step.navigationOnly) {
          throw new Error("找不到表单容器：" + (step.scopeSelector || step.cardTitle || step.name || ""));
        }

        if (step.clearHuaweiPageKey && !clearedHuaweiPages[step.clearHuaweiPageKey]) {
          await clearHuaweiPage(scope || activatedReady || document);
          clearedHuaweiPages[step.clearHuaweiPageKey] = true;
        }

        // 每个大类切换后重新创建 matcher/engine，避免复用已经被 React/Vue 卸载的 DOM。
        if (!step.navigationOnly) {
          var matcher = new AF.ElementMatcher(config);
          var engine = new AF.FillEngine(resume, matcher);
          engine.shouldStop = isStopRequested;
          var result;
          if (step.higherEducationNavigationAdapter === true) {
            educationRepeatNavigationTrace.genericFillerStarted = true;
            writeHigherEducationTrace({ educationRepeatNavigationTrace: educationRepeatNavigationTrace });
          }
          if (/^job\.spdb\.com\.cn$/i.test(window.location.hostname) &&
              String(workflow.id || "") === "spdb-recruitment" &&
              step.wizardAllowPartialFill === true) {
            var spdbFillTimeoutMs = Number(step.fieldSequenceTimeoutMs || 12000);
            result = await Promise.race([
              executeCategoryFill(engine, matcher, step, resume, scope),
              new Promise(function (resolve) {
                setTimeout(function () {
                  resolve({ success: false, timedOut: true, message: "浦发字段填写等待超时，已按部分填写继续保存", failedFields: [{ fieldKey: "specialWorkflow", label: "浦发字段执行", reason: "字段控件未在限定时间内完成" }], filledCount: engine.formHandler.filledFieldsCount || 0 });
                }, spdbFillTimeoutMs);
              }),
            ]);
          } else {
            result = await executeCategoryFill(engine, matcher, step, resume, scope);
          }
          if (step.higherEducationNavigationAdapter === true) {
            var completedHigherFields = {};
            try {
              var liveHigherTrace = JSON.parse(document.documentElement.getAttribute("data-af-zhaopin-higher-education-trace") || "{}");
              (liveHigherTrace.records || []).forEach(function (record) {
                if (record && record.committed === true) completedHigherFields[record.fieldKey] = true;
              });
            } catch (eHigherTraceRead) {}
            // 只用当前 fieldSequence 中真正声明为必填的字段阻断保存。
            // 过去这里维护了一份硬编码列表，把“研究方向 / 院系 / GPA / 学习形式”等
            // optional 字段也当成必填；本科页面本身没有“研究方向”时，即使所有真实
            // 必填项都已填写完成，也会被误判 required_fields_not_committed。
            //
            // 现在以 fieldSequence 的 optional 语义为唯一来源，并以本轮真实
            // failedFields 为阻断依据。页面仍会在 saveStepIfNeeded 中执行站点自身
            // 的必填校验，因此不会因为这里放宽而保存缺失的真实必填项。
            var requiredHigherFields = (Array.isArray(step.fieldSequence) ? step.fieldSequence : [])
              .filter(function (item) {
                return item && item.higherEducationField === true &&
                  item.optional !== true && String(item.field || "").trim();
              })
              .map(function (item) { return String(item.field || ""); });
            var requiredHigherFieldMap = {};
            requiredHigherFields.forEach(function (fieldKey) { requiredHigherFieldMap[fieldKey] = true; });
            var blockingHigherFailures = (result && Array.isArray(result.failedFields) ? result.failedFields : [])
              .filter(function (failure) {
                return failure && requiredHigherFieldMap[String(failure.fieldKey || "")] === true;
              });
            var missingCommittedRequiredFields = requiredHigherFields.filter(function (fieldKey) {
              // 如果 executeCategoryFill 已明确报告该必填字段失败，则一定阻断；
              // 其余情况下仍要求 trace 中有 committed=true，避免静默漏填。
              return completedHigherFields[fieldKey] !== true;
            });
            // 对“fieldSequence 必填但当前页面并未渲染”的站点条件字段，不在这里
            // 直接猜测是否必填；executeCategoryFill 若找不到且 optional=false 会已经
            // 进入 blockingHigherFailures。这样避免 stale/隐藏 DOM 造成二次误判。
            var requiredHigherCommitted = blockingHigherFailures.length === 0 &&
              missingCommittedRequiredFields.every(function (fieldKey) {
                return completedHigherFields[fieldKey] === true;
              });
            educationRepeatNavigationTrace.requiredFieldKeys = requiredHigherFields.slice();
            educationRepeatNavigationTrace.blockingRequiredFieldKeys = blockingHigherFailures
              .map(function (failure) { return String(failure.fieldKey || ""); })
              .filter(Boolean);
            educationRepeatNavigationTrace.missingCommittedRequiredFieldKeys = missingCommittedRequiredFields.slice();
            educationRepeatNavigationTrace.safeToLeave = requiredHigherCommitted;
            educationRepeatNavigationTrace.stoppedBecause = requiredHigherCommitted ? "ready_to_save" : "required_fields_not_committed";
            writeHigherEducationTrace({ educationRepeatNavigationTrace: educationRepeatNavigationTrace });
            if (!requiredHigherCommitted) {
              mergeResult(summary, result);
              throw new Error("field_fill_failed:required_fields_not_committed");
            }
            // 用户触发“一键填写”后，智联的重复经历必须保存当前新增记录，
            // 才能继续后续分区。这里仅放行当前模块保存，不涉及最终投递。
            // 真正的保存动作仍交给通用 saveStepIfNeeded，并由页面校验兜底。
          }
          if (isStopRequested()) {
            summary.success = false;
            summary.stopped = true;
            break;
          }
          var minimumFilledFields = Number(step.minimumFilledFields || 0);
          if (!step.__afRecoveryActionCursor && minimumFilledFields > 0 && Number(result && result.filledCount || 0) < minimumFilledFields) {
            throw new Error(
              "当前大类没有写入任何有效字段，已阻止提交空记录：" +
              (step.name || step.cardTitle || step.category || "未命名步骤")
            );
          }
          if (Array.isArray(step.beforeSaveEnsureFields) && step.beforeSaveEnsureFields.length) {
            var ensureData = Array.isArray(step.dataOverride)
              ? step.dataOverride[0]
              : resume && resume[step.categoryOverride || (Array.isArray(step.category) ? step.category[0] : step.category)];
            if (Array.isArray(ensureData)) ensureData = ensureData[0];
            var ensureCategory = step.categoryOverride || (Array.isArray(step.category) ? step.category[0] : step.category);
            var ensureResult = await ensureFieldsBeforeSave(
              engine, matcher, step, ensureData || {}, ensureCategory, scope
            );
            var ensuredKeyMap = {};
            (ensureResult.ensuredKeys || []).forEach(function (key) { ensuredKeyMap[key] = true; });
            result.failedFields = (result.failedFields || []).filter(function (failure) {
              return !ensuredKeyMap[failure && failure.fieldKey];
            }).concat(ensureResult.failedFields || []);
            result.success = result.failedFields.length === 0;
            if (!ensureResult.success) result.message = "保存前必填字段复核失败";
          }
          mergeResult(summary, result);
          if (activeBankcommAudit) {
            activeBankcommAudit.fillAttempted = true;
            activeBankcommAudit.filledCount = Number(result && result.filledCount || 0);
            activeBankcommAudit.failedFieldCount = Array.isArray(result && result.failedFields) ? result.failedFields.length : 0;
            activeBankcommAudit.status = result && result.success === false ? "fill_partial_or_failed" : "filled";
          }
          if (typeof step.beforeSaveManualCheckpoint === "function") {
            var beforeSaveCheckpoint = null;
            try { beforeSaveCheckpoint = step.beforeSaveManualCheckpoint(scope, resume, result, step); } catch (eBeforeSaveCheckpoint) {}
            if (beforeSaveCheckpoint) {
              if (typeof beforeSaveCheckpoint === "string") beforeSaveCheckpoint = { reason: beforeSaveCheckpoint };
              summary.manualActionRequired = true;
              summary.pausedForManualAction = true;
              summary.manualActionStep = step.name || step.cardTitle || step.category || "当前步骤";
              summary.manualActionReason = String(beforeSaveCheckpoint.reason || "当前步骤存在需要人工完成的页面要求");
              summary.manualActionFields = Array.isArray(beforeSaveCheckpoint.issues) ? beforeSaveCheckpoint.issues.slice(0, 20) : [];
              summary.message = summary.manualActionReason + "。程序已保留当前编辑器且不会点击保存；请手动补充并保存，完成后再次点击“一键填写”继续。";
              summary.notices.push(
                "[人工检查点] " + summary.manualActionStep + "：" + summary.manualActionReason +
                "。请手动补充并保存，随后再次运行一键填写。"
              );
              await saveManualWorkflowCheckpoint(workflow, step, "before_save", beforeSaveCheckpoint);
              if (activeBankcommAudit) {
                activeBankcommAudit.status = "manual_checkpoint_before_save";
                activeBankcommAudit.reason = "manual_action_required_before_save";
              }
              break;
            }
          }
          if (
            result && result.success === false && step.saveOnPartialFill &&
            Array.isArray(step.partialSaveBlockedFields) && step.partialSaveBlockedFields.length
          ) {
            var blockedFailure = (result.failedFields || []).find(function (failure) {
              return failure && step.partialSaveBlockedFields.indexOf(failure.fieldKey) !== -1;
            });
            if (blockedFailure) {
              throw new Error(
                "保存前必填字段未完成：" + (blockedFailure.label || blockedFailure.fieldKey) +
                "；" + (blockedFailure.reason || "必须完成真实候选选择")
              );
            }
          }
          if (result && result.success === false && step.closeOnPartialFill) {
            await closeStepEditor(step);
            continue;
          }
          if (result && result.success === false && !step.wizardAllowPartialFill && !step.saveOnPartialFill) {
            throw new Error(result.message || "当前大类填写失败");
          }
        }
        if (!step.skipSave) {
          if (activeBankcommAudit) activeBankcommAudit.saveAttempted = true;
          await saveStepIfNeeded(step, scope);
          summary.lastStepSaved = true;
          if (activeBankcommAudit) {
            activeBankcommAudit.saved = true;
            activeBankcommAudit.status = "saved";
          }
        } else if (activeBankcommAudit) {
          activeBankcommAudit.status = "completed_without_save";
        }
        if (
          step.verifyRepeatSavedContent === true &&
          Array.isArray(step.dataOverride) && step.dataOverride.length
        ) {
          var savedContentCheck = await verifySavedRepeatContent(step);
          if (!savedContentCheck.success) {
            throw new Error(
              "保存后当前经历内容不匹配：期望“" + savedContentCheck.expected +
              "”，当前栏目未找到对应卡片"
            );
          }
        }
        if (
          step.verifyCurrentRepeatAfterSave === true &&
          Array.isArray(step.dataOverride) && step.dataOverride.length
        ) {
          var savedRepeatExists = false;
          try {
            if (typeof step.existingRowMatcher === "function") {
              savedRepeatExists = step.existingRowMatcher(
                step.dataOverride[0], document, step, step.repeatIndex
              ) === true;
            } else if (typeof step.existingRowIndexResolver === "function") {
              var savedRepeatIndex = Number(step.existingRowIndexResolver(
                step.dataOverride[0], document, step, step.repeatIndex
              ));
              savedRepeatExists = Number.isInteger(savedRepeatIndex) && savedRepeatIndex >= 0;
            }
          } catch (eVerifySavedRepeat) {}
          if (!savedRepeatExists) {
            var savedRepeatName = String(
              step.dataOverride[0].company || step.dataOverride[0].school ||
              step.dataOverride[0].name || "第" + (Number(step.repeatIndex || 0) + 1) + "条"
            );
            throw new Error("保存后未找到对应经历卡片：" + savedRepeatName);
          }
        }
        await removeExtraExistingCardsAfterLast(step);
        if (step.verifyRepeatCountAfterLast === true && step.isLastRepeatStep && step.existingCardSelector) {
          var repeatRoot = step.repeatAddRootSelector ? document.querySelector(step.repeatAddRootSelector) : findStepCard(step, document);
          var missingPlannedRows = [];
          if (typeof step.existingRowMatcher === "function" && Array.isArray(step.plannedRepeatRows)) {
            missingPlannedRows = step.plannedRepeatRows.filter(function (plannedRow, plannedIndex) {
              try { return step.existingRowMatcher(plannedRow, document, step, plannedIndex) !== true; }
              catch (ePlannedMatcher) { return true; }
            });
          }
          var actualRepeatCount = repeatRoot
            ? resolveExistingRepeatCards(step, repeatRoot).length
            : 0;
          var expectedRepeatCount = Number(step.repeatTotal || 0);
          var wrongRepeatCount = step.removeExtraExistingCardsAfterLast === true
            ? actualRepeatCount !== expectedRepeatCount
            : actualRepeatCount < expectedRepeatCount;
          if (missingPlannedRows.length || (!step.existingRowMatcher && wrongRepeatCount)) {
            var missingNames = missingPlannedRows.map(function (plannedRow) {
              return plannedRow.school || plannedRow.company || plannedRow.name || "未命名记录";
            });
            throw new Error(
              "重复经历数量不足：计划填写" + Number(step.repeatTotal || 0) +
              "条，页面实际保存" + actualRepeatCount + "条" +
              (missingNames.length ? "；缺少：" + missingNames.join("、") : "")
            );
          }
        }
        await closeEmptyRepeatEditorAfterLast(step);
        if (activeBankcommAudit) {
          activeBankcommAudit.status = "completed";
          activeBankcommAudit.reason = "";
        }
        var completedBaseIndex = Number(step.__afWorkflowStepIndex);
        if (Number.isInteger(completedBaseIndex) && recoveryCompletedStepIndexes.indexOf(completedBaseIndex) === -1) {
          recoveryCompletedStepIndexes.push(completedBaseIndex);
        }
        if (Number.isInteger(completedBaseIndex) && Number.isInteger(Number(step.repeatIndex)) && Number(step.repeatIndex) >= 0) {
          recoveryCompletedRepeatIndexes[String(completedBaseIndex)] = Math.max(
            Number(recoveryCompletedRepeatIndexes[String(completedBaseIndex)] || -1),
            Number(step.repeatIndex)
          );
        }
        // Ledger records only stable step keys / record fingerprints; never raw resume values.
        checkpointCore().markStepCompleted(executionLedger, step);
        await checkpointCore().saveExecutionLedger(executionLedger);
        if (
          recoveryResumeCheckpoint &&
          Number(recoveryResumeCheckpoint.stepIndex) === completedBaseIndex &&
          (Number(recoveryResumeCheckpoint.repeatIndex) < 0 || Number(recoveryResumeCheckpoint.repeatIndex) === Number(step.repeatIndex))
        ) {
          await clearRecoveryWorkflowCheckpoint();
          summary.notices.push(
            "[恢复执行] 恢复检查点“" + String(recoveryResumeCheckpoint.stepName || step.cardTitle || step.category || "当前模块") + "”已完成。"
          );
          summary.recoveryCheckpointResolved = true;
          recoveryResumeCheckpoint = null;
        }
        var checkpointBaseStepComplete = !step.repeatGroupKey || step.isLastRepeatStep === true;
        if (
          checkpointBaseStepComplete &&
          manualResumeCheckpoint &&
          Number(manualResumeCheckpoint.stepIndex) === Number(step.__afWorkflowStepIndex)
        ) {
          await clearManualWorkflowCheckpoint();
          summary.notices.push(
            "[恢复执行] 人工检查点“" +
            String(manualResumeCheckpoint.stepName || step.cardTitle || step.category || "当前模块") +
            "”已完成。"
          );
          manualResumeCheckpoint = null;
        }
      } catch (err) {
        summary.success = false;
        var errorMessage = err && err.message ? err.message : String(err);
        result = ensureSpecialSequenceCursor(step, result);
        var candidateFailureContext = buildFailureContext(workflow, step, errorMessage, result);
        var keepEditorForRecoverableCursor = supportedRecoveryCheckpointWorkflow(workflow) &&
          candidateFailureContext && candidateFailureContext.recoverability === "RECOVERABLE_MANUAL" &&
          candidateFailureContext.actionCursor;
        if (!step.keepEditorOnError && !keepEditorForRecoverableCursor) await closeStepEditor(step);
        if (activeBankcommAudit) {
          activeBankcommAudit.status = "failed";
          activeBankcommAudit.reason = String(errorMessage || "").slice(0, 240);
        }
        summary.failedFields.push({
          fieldKey: "specialWorkflow",
          label: "[特殊工作流] " + (step.name || step.category || "未命名步骤"),
          reason: errorMessage,
        });
        if (
          supportedRecoveryCheckpointWorkflow(workflow) &&
          candidateFailureContext && candidateFailureContext.recoverability !== "UNSAFE_STOP" &&
          shouldPersistRecoveryCheckpoint(workflow, candidateFailureContext)
        ) {
          summary.failureContext = candidateFailureContext;
          var earlyRecoveryMarker = await saveRecoveryWorkflowCheckpoint(
            workflow, step, candidateFailureContext, {
              stepIndexes: recoveryCompletedStepIndexes,
              repeatIndexes: recoveryCompletedRepeatIndexes
            }
          );
          if (earlyRecoveryMarker) {
            summary.recoveryCheckpointCreated = true;
            summary.recoveryCheckpoint = earlyRecoveryMarker;
            summary.pausedForManualAction = candidateFailureContext.recoverability === "RECOVERABLE_MANUAL";
            if (candidateFailureContext.recoverability === "RECOVERABLE_MANUAL") {
              summary.manualActionRequired = true;
              summary.manualActionStep = candidateFailureContext.stepName;
              summary.manualActionReason = candidateFailureContext.humanSummary;
              summary.manualActionFields = candidateFailureContext.fieldLabel ? [{
                fieldKey: candidateFailureContext.fieldKey,
                label: candidateFailureContext.fieldLabel,
                reason: candidateFailureContext.rawReason
              }] : [];
            }
            summary.message = candidateFailureContext.humanSummary + "。" + candidateFailureContext.suggestedAction;
            summary.notices.push(
              "[恢复检查点] " + candidateFailureContext.stepName + "：" + candidateFailureContext.humanSummary +
              "。手动处理后再次运行将直接从后续内容继续；动作游标之前的字段不会重放。"
            );
            break;
          }
        }
        var continuedAfterExistingRepairFailure = false;
        if (
          step.zhaopinContinueExistingRepairAfterRowError === true &&
          step.repeatGroupKey &&
          /^opened_existing_editor/.test(String(step.__afZhaopinRepeatAction || ""))
        ) {
          var failedRepairCancelled = await cancelZhaopinRepeatFailedExistingRepair(step);
          if (failedRepairCancelled) {
            continuedAfterExistingRepairFailure = true;
            writeZhaopinRepeatSectionTrace({
              section: step.cardTitle || step.name || "",
              category: step.categoryOverride || step.category || "",
              repeatIndex: step.repeatIndex,
              repairFailureCancelled: true,
              continuedAfterRepairFailure: true,
              action: "cancelled_failed_existing_repair_and_continue",
              reason: errorMessage,
            });
            summary.notices.push(
              (step.cardTitle || step.name || "重复经历") + "第" + (Number(step.repeatIndex || 0) + 1) +
              "条修复未完成，已取消本条未保存修改并继续检查后续已有记录。"
            );
          }
        }
        if (step.skipRemainingRepeatsOnError && step.repeatGroupKey && !continuedAfterExistingRepairFailure) {
          skippedRepeatGroups[step.repeatGroupKey] = true;
        }
        if (continuedAfterExistingRepairFailure) {
          continue;
        }
        var failureContext = candidateFailureContext || buildFailureContext(workflow, step, errorMessage, result);
        summary.failureContext = failureContext;
        if (step.stopOnSaveError && /保存|表单仍处于编辑态|找不到保存按钮|保存后未检测|退出编辑|不会自动保存/.test(errorMessage)) {
          // 部分 Vue 页面在“保存并更新”后重绘较慢，等待器可能
          // 先报保存状态异常，但现场编辑器已经关闭。这种情况只结束
          // 当前重复经历组，继续项目经历等下一类目，不能 break
          // 整个工作流。若编辑器仍在，则保持原有停止保护。
          var editorStillOpen = false;
          if (step.activeRepeatEditorSelector) {
            try {
              editorStillOpen = Array.from(document.querySelectorAll(step.activeRepeatEditorSelector)).some(isVisible);
            } catch (eEditorStillOpen) {}
          }
          if (
            step.continueNextGroupAfterClosedSaveError === true &&
            step.repeatGroupKey && !editorStillOpen
          ) {
            skippedRepeatGroups[step.repeatGroupKey] = true;
            continue;
          }
          break;
        }
        if (workflow.continueOnError === false || step.continueOnError === false) break;
      }
    }
    if (summary.success !== false && recoveryResumeCheckpoint) {
      await clearRecoveryWorkflowCheckpoint();
      summary.recoveryCheckpointResolved = true;
      summary.notices.push(
        "[恢复执行] 恢复检查点“" + String(recoveryResumeCheckpoint.stepName || "上次中断位置") + "”已完成。"
      );
      recoveryResumeCheckpoint = null;
    }
    summary.executionLedger = checkpointCore().snapshotExecutionLedger(executionLedger);
    if (bankcommExecutionAudit) {
      bankcommExecutionAudit.completedStepCount = bankcommExecutionAudit.steps.filter(function (entry) { return entry && entry.status === "completed"; }).length;
      bankcommExecutionAudit.failedStepCount = bankcommExecutionAudit.steps.filter(function (entry) { return entry && entry.status === "failed"; }).length;
      bankcommExecutionAudit.manualCheckpointCount = bankcommExecutionAudit.steps.filter(function (entry) { return entry && /^manual_checkpoint/.test(String(entry.status || "")); }).length;
    }
    if (summary.success !== false && (continuationMarker || workflow.clearContinuationOnComplete === true)) {
      try { window.sessionStorage.removeItem("__afSpecialWorkflowAutoContinue"); } catch (eClearContinuation) {}
    }
    if (
      summary.lastStepSaved === true &&
      Array.isArray(workflow.pageSequence) &&
      /^job\.spdb\.com\.cn$/i.test(window.location.hostname) &&
      String(workflow.id || "") === "spdb-recruitment"
    ) {
      var currentPageIndex = workflow.pageSequence.findIndex(function (page) {
        try { return page && page.urlPattern && page.urlPattern.test(window.location.href); }
        catch (ePageSequence) { return false; }
      });
      var currentPage = currentPageIndex >= 0 ? workflow.pageSequence[currentPageIndex] : null;
      var nextPage = currentPageIndex >= 0 ? workflow.pageSequence[currentPageIndex + 1] : null;
      if (nextPage && nextPage.url) {
        try {
          window.sessionStorage.setItem("__afSpecialWorkflowAutoContinue", JSON.stringify({
            workflowId: workflow.id || workflow.name || "",
            hostname: window.location.hostname,
            pagePath: new URL(nextPage.url, window.location.href).pathname,
            startedAt: Date.now(),
          }));
        } catch (eNextPageMarker) {}
        summary.autoContinuing = true;
        summary.nextPageUrl = new URL(nextPage.url, window.location.href).href;
        summary.stepCompleted = true;
        summary.nextPageSelector = currentPage && currentPage.nextSelector || "";
        summary.nextPageClickScheduled = false;
        summary.message = "当前大类填写完成，正在进入下一大类";
      }
    }
    var currentHeading = currentPageHeadingText();
    var noFillNextAllowed = Array.isArray(workflow.autoNextPageHeadings) && workflow.autoNextPageHeadings.some(function (heading) {
      heading = normalizeText(heading);
      return heading && currentHeading && (currentHeading === heading || currentHeading.indexOf(heading) !== -1);
    });
    if (workflow.autoNextAfterFill === true && (summary.filledCount > 0 || noFillNextAllowed) && workflow.nextButtonSelector) {
      var workflowNextButton = null;
      try { workflowNextButton = document.querySelector(workflow.nextButtonSelector); } catch (eNextFind) {}
      if (workflowNextButton && isVisible(workflowNextButton)) {
        if (workflow.autoContinueAcrossPages === true) {
          try {
            window.sessionStorage.setItem("__afSpecialWorkflowAutoContinue", JSON.stringify({
              workflowId: workflow.id || workflow.name || "",
              hostname: window.location.hostname,
              startedAt: Date.now(),
            }));
          } catch (eContinueStore) {}
          summary.autoContinuing = true;
          summary.message = "当前页填写完成，正在进入下一页";
        }
        setTimeout(function () {
          safeClick(workflowNextButton).catch(function () {});
        }, workflow.nextButtonDelayMs == null ? 180 : workflow.nextButtonDelayMs);
      } else if (workflow.autoContinueAcrossPages === true) {
        try { window.sessionStorage.removeItem("__afSpecialWorkflowAutoContinue"); } catch (eContinueClear) {}
      }
    }
    return summary;
  }

  // “测试填当前模块”在特殊站点也必须复用私有步骤中的字段顺序、级联路径和
  // 数据过滤规则。这里只填写已经打开的当前弹窗，不点击栏目、不保存。
  async function executeCurrentStep(options) {
    options = options || {};
    var workflow = options.workflow;
    var resume = options.resume;
    var config = options.config;
    var providedScope = options.scope || null;
    if (!workflow || !Array.isArray(workflow.steps) || !config) return null;

    var matcher = new AF.ElementMatcher(config);
    var titleEl = visibleTitleForScope(matcher, providedScope);
    var visibleName = normalizeText(titleEl && (titleEl.textContent || titleEl.value));
    if (!visibleName) return null;
    var step = workflow.steps.find(function (candidate) {
      if (!candidate || candidate.enabled === false) return false;
      return [candidate.readyText, candidate.cardTitle, candidate.name].some(function (name) {
        var normalized = normalizeText(name);
        return normalized && (visibleName === normalized || visibleName.indexOf(normalized) !== -1 || normalized.indexOf(visibleName) !== -1);
      });
    });
    if (!step) return null;

    var currentStep = Object.assign({}, step);
    if (step.repeatForCategoryData) {
      var categories = Array.isArray(step.category) ? step.category : [step.category];
      var rows = prepareStepRows(step, resume);
      if (!rows.length) {
        return {
          success: true,
          message: "当前模块没有需要填写的数据",
          filledCount: 0,
          failedFields: [],
          totalFieldsFound: providedScope ? countVisibleFields(providedScope) : 0,
        };
      }
      currentStep.dataOverride = [rows[0]];
      currentStep.categoryOverride = rows[0].__afCategory || categories[0];
    }

    var scope = providedScope;
    if (!scope && step.scopeSelector) {
      scope = Array.from(document.querySelectorAll(step.scopeSelector)).find(isVisible) || null;
    }
    var engine = new AF.FillEngine(resume, matcher);
    return executeCategoryFill(engine, matcher, currentStep, resume, scope || document);
  }

  AF.SpecialSiteWorkflow = {
    match: match,
    resolve: resolveWorkflow,
    discoverAndSave: discoverAndSave,
    execute: execute,
    executeCurrentStep: executeCurrentStep,
    diagnose: diagnose,
    _test: {
      resolveFieldBinding: resolveFieldBinding,
      enumerateInteractiveControls: enumerateInteractiveControls,
      classifyHigherEducationEditableRoot: classifyHigherEducationEditableRoot,
      resolveHigherEducationEditableRoot: resolveHigherEducationEditableRoot,
      detectActiveResumeSection: detectActiveResumeSection,
      navigateToResumeSection: navigateToResumeSection,
      findUnsavedResumeNavigationModal: findUnsavedResumeNavigationModal,
      inspectCurrentModuleValidation: inspectCurrentModuleValidation,
      completeModuleSaveAndNavigate: completeModuleSaveAndNavigate,
      runAnalyzedSectionNavigationTransaction: runAnalyzedSectionNavigationTransaction,
      runAnalyzedSectionAddEditorProbe: runAnalyzedSectionAddEditorProbe,
      runAnalyzedResumeSectionEditorSurvey: runAnalyzedResumeSectionEditorSurvey,
      runAnalyzedResumeSectionPreviewBatch: runAnalyzedResumeSectionPreviewBatch,
      runAnalyzedResumeSectionSaveBatch: runAnalyzedResumeSectionSaveBatch,
      runAnalyzedEducationAddEditorProbe: runAnalyzedEducationAddEditorProbe,
      runAnalyzedEducationRecordPreviewFill: runAnalyzedEducationRecordPreviewFill,
      runAnalyzedEducationContinuePreview: runAnalyzedEducationContinuePreview,
      runAnalyzedEducationRepeatSaveTransaction: runAnalyzedEducationRepeatSaveTransaction,
      getManualWorkflowCheckpointForCurrentPage: getManualWorkflowCheckpointForCurrentPage,
      getRecoveryWorkflowCheckpointForCurrentPage: getRecoveryWorkflowCheckpointForCurrentPage,
      buildFailureContext: buildFailureContext,
      supportedRecoveryCheckpointWorkflow: supportedRecoveryCheckpointWorkflow,
      workflowHasDeterministicActionSequence: workflowHasDeterministicActionSequence,
      stepHasDeterministicActionSequence: stepHasDeterministicActionSequence,
      shouldPersistRecoveryCheckpoint: shouldPersistRecoveryCheckpoint,
      deriveSingleFailureSequenceCursor: deriveSingleFailureSequenceCursor,
      ensureSpecialSequenceCursor: ensureSpecialSequenceCursor,
      resolveRecoveryCheckpointPlanPosition: resolveRecoveryCheckpointPlanPosition,
      recoveryCheckpointStepKey: recoveryCheckpointStepKey,
      collectVisibleTextConstraintErrors: collectVisibleTextConstraintErrors,
      classifyRecoverableFailure: classifyRecoverableFailure,
      findHigherEducationAddButton: findHigherEducationAddButton,
      scanHigherEducationExistingIdentities: scanHigherEducationExistingIdentities,
      readHigherEducationDisplayField: readHigherEducationDisplayField,
      parseHigherEducationDisplayText: parseHigherEducationDisplayText,
      runHigherEducationNavigationAdapter: runHigherEducationNavigationAdapter,
      runZhaopinRepeatNavigationAdapter: runZhaopinRepeatNavigationAdapter,
      zhaopinRepeatRowIdentity: zhaopinRepeatRowIdentity,
      zhaopinRepeatCardMatchState: zhaopinRepeatCardMatchState,
      zhaopinRepeatEditorMatchState: zhaopinRepeatEditorMatchState,
      readZhaopinRepeatEditorIdentityValues: readZhaopinRepeatEditorIdentityValues,
      isZhaopinRecoveryRecordLock: isZhaopinRecoveryRecordLock,
      findZhaopinRepeatAddButton: findZhaopinRepeatAddButton,
      classifyZhaopinRepeatEditableRoot: classifyZhaopinRepeatEditableRoot,
      hasObviousDuplicateZhaopinRepeatCards: hasObviousDuplicateZhaopinRepeatCards,
      findZhaopinRepeatEditorSubmitButton: findZhaopinRepeatEditorSubmitButton,
      normalizeFullDateValue: normalizeFullDateValue,
      selectRemainingEducationRecord: selectRemainingEducationRecord,
      createInitialEducationRepeatNavigationTrace: createInitialEducationRepeatNavigationTrace,
      resumeExecutionStepsFromActiveSection: resumeExecutionStepsFromActiveSection,
      resolveSequenceControlByConfiguredType: resolveSequenceControlByConfiguredType,
      resolveZhaopinRepeatLocalControl: resolveZhaopinRepeatLocalControl,
      findZhaopinRepeatLocalLabel: findZhaopinRepeatLocalLabel,
      fillZhaopinCampusDate: fillZhaopinCampusDate,
      fillBankcommResearchCustomValue: fillBankcommResearchCustomValue,
      openBankcommResearchCustomDropdown: openBankcommResearchCustomDropdown,
      findVisibleBankcommResearchCheckbox: findVisibleBankcommResearchCheckbox,
      typeBankcommResearchCustomInputInPage: typeBankcommResearchCustomInputInPage,
      getLastBankcommResearchCustomError: function () { return lastBankcommResearchCustomError; },
      cancelZhaopinRepeatFailedExistingRepair: cancelZhaopinRepeatFailedExistingRepair,
      isActuallyVisible: isActuallyVisible,
      resetHigherEducationBindingContext: function () {
        higherEducationRuntimeBindings.clear();
        higherEducationFieldItemIds = typeof WeakMap === "function" ? new WeakMap() : null;
        higherEducationFieldItemIdSeed = 0;
      },
    },
  };

  async function resumePostbackWorkflow() {
    if (window.__OFFER_SPDB_DESKTOP_CONTROLLER__ === true && /^job\.spdb\.com\.cn$/i.test(window.location.hostname)) {
      spdbLog("resume:runtime-skipped", { reason: "desktop-controller-active" });
      return;
    }
    if (window.top !== window || window.__afSpecialWorkflowAutoResumeRunning) return;
    var marker = null;
    try { marker = JSON.parse(window.sessionStorage.getItem("__afSpecialWorkflowAutoContinue") || "null"); } catch (eMarker) {}
    if (!marker || marker.hostname !== window.location.hostname || Date.now() - Number(marker.startedAt || 0) > 20 * 60 * 1000) {
      if (marker) {
        try { window.sessionStorage.removeItem("__afSpecialWorkflowAutoContinue"); } catch (eClearExpired) {}
      }
      return;
    }
    var workflow = await resolveWorkflow(window.location.href);
    if (!workflow || workflow.autoContinueAcrossPages !== true || String(workflow.id || workflow.name || "") !== String(marker.workflowId || "")) {
      try { window.sessionStorage.removeItem("__afSpecialWorkflowAutoContinue"); } catch (eClearMismatch) {}
      return;
    }
    var dependenciesReady = await waitUntil(function () {
      return AF.SiteLoader && AF.ResumeLoader && AF.FillEngine ? true : null;
    }, 5000);
    if (!dependenciesReady) return;
    window.__afSpecialWorkflowAutoResumeRunning = true;
    try {
      var config = await AF.SiteLoader.loadConfig(window.location.href);
      var resume = await AF.ResumeLoader.getCurrentResume();
      if (!resume || !config) throw new Error("自动续填缺少简历或站点配置");
      var result = await execute({ workflow: workflow, resume: resume, config: config });
      if (!result || result.autoContinuing !== true) {
        window.postMessage({
          type: "FROM_CONTENT_SCRIPT",
          action: "fillComplete",
          filledCount: result && result.filledCount || 0,
          totalFields: result && result.totalFields || 0,
          failedFields: result && result.failedFields || [],
          notices: result && result.notices || [],
          duration: 0,
        }, "*");
      }
    } catch (eResumeWorkflow) {
      try { window.sessionStorage.removeItem("__afSpecialWorkflowAutoContinue"); } catch (eClearFailure) {}
      window.postMessage({
        type: "FROM_CONTENT_SCRIPT",
        action: "fillError",
        error: eResumeWorkflow && eResumeWorkflow.message ? eResumeWorkflow.message : String(eResumeWorkflow),
      }, "*");
    } finally {
      window.__afSpecialWorkflowAutoResumeRunning = false;
    }
  }

  setTimeout(function () {
    resumePostbackWorkflow().catch(function () {});
  }, 700);
})();
