// content/select-adapter/adapters/next.js — Alibaba Next/Fusion UI (.next-select)
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  var H = SA._helpers;

  function normalizeValues(value) {
    if (Array.isArray(value)) return value.filter(function (v) { return v !== null && v !== undefined && v !== ""; });
    if (value === null || value === undefined || value === "") return [];
    var text = String(value);
    if (/浙江省杭州市/.test(text)) return ["中国-浙江-杭州", "浙江-杭州", "杭州", "杭州市", text];
    if (/上海市/.test(text)) return ["中国-上海-上海", "上海-上海", "上海", "上海市", text];
    if (/中国/.test(text)) return ["中国", "中华人民共和国", text];
    return [text];
  }

  function schoolSearchQueries(value) {
    var text = String(value || "").trim();
    var list = [text];
    var withoutSuffix = text.replace(/(大学|学院|学校)$/g, "").trim();
    if (withoutSuffix && withoutSuffix !== text) list.push(withoutSuffix);
    if (/大学$/.test(text) && text.length > 4) list.push(text.slice(0, 2));
    return list.filter(function (item, idx, arr) {
      return item && arr.indexOf(item) === idx;
    });
  }

  async function setSearchText(input, value) {
    if (!input || value === null || value === undefined) return false;
    try {
      input.focus && input.focus();
      var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      if (setter) setter.call(input, String(value));
      else input.value = String(value);
      input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
      input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      input.dispatchEvent(new KeyboardEvent("keydown", { key: String(value).slice(-1) || "a", bubbles: true, cancelable: true }));
      input.dispatchEvent(new KeyboardEvent("keyup", { key: String(value).slice(-1) || "a", bubbles: true, cancelable: true }));
      await AF.Utils.sleep(650);
      return true;
    } catch (e) {
      return false;
    }
  }

  function getCommittedText(container) {
    try {
      return Array.from(container.querySelectorAll(
        ".next-tag-body, .next-select-values em[title], .next-select-value, .next-select-selection-item"
      )).map(function (node) {
        return node.getAttribute && node.getAttribute("title") || node.textContent || "";
      }).join(" ").replace(/\s+/g, " ").trim();
    } catch (e) {
      return "";
    }
  }

  function committedMatches(container, value) {
    var current = getCommittedText(container);
    var target = String(value || "").trim();
    return !!(current && target && (current.indexOf(target) !== -1 || target.indexOf(current) !== -1));
  }

  function cssEscape(value) {
    if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(value);
    return String(value).replace(/["\\]/g, "\\$&");
  }

  function latestContainer(originalContainer, input, config) {
    try {
      var key = input && (input.getAttribute("name") || input.id);
      if (key) {
        var selector = input.getAttribute("name")
          ? 'input[name="' + cssEscape(key) + '"]'
          : 'input[id="' + cssEscape(key) + '"]';
        var latestInput = document.querySelector(selector);
        var latest = latestInput && latestInput.closest && latestInput.closest(config.container);
        if (latest) return latest;
      }
    } catch (e) {}
    return originalContainer;
  }

  async function waitForCommitted(container, input, config, value, timeoutMs) {
    var deadline = Date.now() + (timeoutMs || 1600);
    while (Date.now() < deadline) {
      var latest = latestContainer(container, input, config);
      if (latest && committedMatches(latest, value)) return latest;
      await AF.Utils.sleep(120);
    }
    return null;
  }

  async function pressEnterToCommit(input, container, value) {
    if (!input) return false;
    try {
      input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
      input.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
      await AF.Utils.sleep(420);
      input.dispatchEvent(new Event("blur", { bubbles: true, composed: true }));
      await AF.Utils.sleep(220);
      H.dispatchChangeEvents(container);
      return committedMatches(container, value);
    } catch (e) {
      return false;
    }
  }

  async function searchAndSelectNext(container, value, config) {
    try {
      var trigger = container.querySelector(config.trigger) || container;
      var schoolLike = !!(container.querySelector && container.querySelector("input[name$='.school'], input[id$='.school']"));
      await AF.DomUtils.safeClickElement(trigger);
      var panel = await H.waitForVisibleDropdownNear(container, config.panelSelectors, config.container, schoolLike ? 3200 : 1800);
      var input = container.querySelector("input[role='combobox'], input");
      var queries = schoolLike ? schoolSearchQueries(value) : [value];
      var ok = false;
      for (var qi = 0; qi < queries.length && !ok; qi += 1) {
        if (input && !input.readOnly) {
          await setSearchText(input, queries[qi]);
          for (var wait = 0; wait < (schoolLike ? 42 : 18); wait += 1) {
            panel = H.findVisibleDropdownNear(container, config.panelSelectors, config.container) ||
              await H.waitForVisibleDropdownNear(container, config.panelSelectors, config.container, schoolLike ? 1400 : 800);
            if (panel && !panel.querySelector(".next-select-menu-empty-content")) {
              var nodes = H.getOptionNodes(panel, config.dropdown).filter(function (node) {
                return String(node.textContent || "").trim();
              });
              if (nodes.length) break;
            }
            await AF.Utils.sleep(180);
          }
        }
        if (!panel) continue;
        ok = await H.selectMatchingOption(panel, value, config.dropdown);
      }
      if (!panel) return false;
      if (!ok && schoolLike) return false;
      if (!ok) return await pressEnterToCommit(input, container, value);
      if (input && input.dispatchEvent) {
        input.dispatchEvent(new Event("blur", { bubbles: true, composed: true }));
      }
      if (trigger && trigger.dispatchEvent) {
        trigger.dispatchEvent(new Event("blur", { bubbles: true, composed: true }));
      }
      await AF.Utils.sleep(420);
      var currentContainer = latestContainer(container, input, config);
      H.dispatchChangeEvents(currentContainer);
      if (committedMatches(currentContainer, value)) return true;
      if (await waitForCommitted(container, input, config, value, schoolLike ? 2600 : 1400)) return true;
      if (schoolLike) return false;
      return await pressEnterToCommit(input, currentContainer, value);
    } catch (e) {
      return false;
    }
  }

  async function selectOneNextValue(element, rawValue) {
    var config = SA._config.next;
    var container = element && element.closest && element.closest(config.container) || element;
    if (!container) return false;
    var values = normalizeValues(rawValue);
    for (var i = 0; i < values.length; i += 1) {
      var searchable = container.classList && (container.classList.contains("next-has-search") || container.classList.contains("next-select-tag"));
      var ok = searchable ? await searchAndSelectNext(container, values[i], config) : await H.genericOpenAndSelect(container, values[i], config, {
        clickTarget: "trigger",
        useSearchInput: true,
        alreadyOpenCheck: function (_container, trigger) {
          return !!(trigger && trigger.getAttribute && trigger.getAttribute("aria-expanded") === "true");
        },
      });
      if (ok) return true;
      await AF.Utils.sleep(120);
    }
    return false;
  }

  SA._registry.next = function (element) {
    return {
      selectValue: async function (value) {
        if (Array.isArray(value)) {
          var ok = false;
          for (var i = 0; i < value.length; i += 1) {
            if (await selectOneNextValue(element, value[i])) ok = true;
          }
          return ok;
        }
        return await selectOneNextValue(element, value);
      },
    };
  };
})();
