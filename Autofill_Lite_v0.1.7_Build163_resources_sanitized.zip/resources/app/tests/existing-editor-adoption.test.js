"use strict";
const assert = require("assert");
const path = require("path");
const root = path.resolve(__dirname, "..");

global.window = { AF: {} };
global.location = { hostname: "example.test", href: "https://example.test/resume" };
global.document = { querySelectorAll() { return []; } };
window.AF.Utils = { sleep: async () => {} };
window.AF.DomUtils = {
  isElementVisible(node) { return node && node.visible !== false; },
  safeClickElement: async () => true,
};
window.AF.LabelUtils = { getLabelText() { return ""; } };
window.AF.FormHandler = { fillFormElement: async () => true };

require(path.join(root, "autofill-plugin", "content", "experience-handler.js"));
const ExperienceHandler = window.AF.ExperienceHandler;

function node(opts = {}) {
  const children = opts.children || {};
  return {
    visible: opts.visible !== false,
    isConnected: opts.isConnected !== false,
    innerText: opts.text || "",
    textContent: opts.text || "",
    value: opts.value || "",
    matches(selector) { return Boolean(opts.matches && opts.matches.includes(selector)); },
    contains(示例资料) { return 示例资料 === this || Boolean(opts.contains && opts.contains.includes(示例资料)); },
    querySelector(selector) {
      const list = this.querySelectorAll(selector);
      return list[0] || null;
    },
    querySelectorAll(selector) {
      if (children[selector]) return children[selector];
      if (/input:not\(\[type='hidden'\]\)/.test(selector) || selector.includes("textarea") || selector.includes("[role='combobox']")) return opts.controls || [];
      return [];
    },
    scrollIntoView() {},
    setAttribute() {},
    getAttribute() { return ""; },
  };
}

const input = node({ value: "" });
const inlineCard = node({ controls: [input], children: { ".guard": [input] } });
const container1 = node({ children: { ".card": [inlineCard] }, contains: [inlineCard] });
const matcher = { findLabelsByCard() { return []; } };
const dataMatcher = { resumeData: {}, findFieldByCategory() { return null; } };
const handler1 = new ExperienceHandler(matcher, dataMatcher, {
  experience: { card: { cardSelector: ".card" }, editor: { editModeGuardSelector: ".guard" } },
});
let adopted = handler1.resolveExistingEditorScope(container1, inlineCard, { company: "A" }, "示例资料Experience");
assert(adopted && adopted.scope === inlineCard && adopted.source === "card_guard", "inline existing editor should be adopted without an示例资料 edit click");

const readOnlyCard = node({ text: "Company A Engineer" });
const editor = node({ text: "Company A Engineer", controls: [input], matches: [".active-editor"] });
const container2 = node({
  children: { ".card": [readOnlyCard], ".active-editor": [editor] },
  contains: [readOnlyCard, editor],
});
const handler2 = new ExperienceHandler(matcher, dataMatcher, {
  experience: {
    card: { cardSelector: ".card" },
    editor: { editModeGuardSelector: ".guard", existingEditorScopeSelector: ".active-editor" },
  },
});
adopted = handler2.resolveExistingEditorScope(container2, readOnlyCard, { company: "Company A", position: "Engineer" }, "示例资料Experience");
assert(adopted && adopted.scope === editor && adopted.source === "container_selector", "explicit container editor should be adopted");

const 示例资料Card = node({ text: "Company B Analyst" });
const container3 = node({
  children: { ".card": [readOnlyCard, 示例资料Card], ".active-editor": [editor] },
  contains: [readOnlyCard, 示例资料Card, editor],
});
const handler3 = new ExperienceHandler(matcher, dataMatcher, {
  experience: {
    card: { cardSelector: ".card" },
    editor: { editModeGuardSelector: ".guard", existingEditorScopeSelector: ".active-editor" },
  },
});
adopted = handler3.resolveExistingEditorScope(container3, 示例资料Card, { company: "Missing Co", position: "Missing" }, "示例资料Experience");
assert.strictEqual(adopted, null, "multi-record editor without identity match must not be adopted");

adopted = handler3.resolveExistingEditorScope(container3, readOnlyCard, { company: "Company A", position: "Engineer" }, "示例资料Experience");
assert(adopted && adopted.scope === editor && adopted.identityMatched === true, "multi-record editor may be adopted only after record identity matches");

console.log("existing editor adoption test: PASS");
