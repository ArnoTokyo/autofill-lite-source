// content/date-picker/panel-navigator.js — 日期选择器：通用面板导航器 + 日期解析工具
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   通用面板导航器 w()/x(): 行 28099-28499 (14个位置参数, 见下方逐参数注释)
//   辅助工具 p.findMonthName/findMonth/parseYearFromString/parseEndYear: 行 27340-27425
//   isDateValue 支持的字符串格式参考: content/utils.js AF.DomUtils.isDateValue (行159)
//
// 改造点: 原函数 w()/x() 用 14 个位置参数（容器/日期串/表头选择器/格子选择器/禁用class/...），
// 阅读和调用都很难对齐。这里保留其算法一字不改（年份列表匹配 → 翻页 → 月份匹配(可选打开子面板) →
// 日期格子匹配，带禁用格过滤、可选“容器细化选择器”、可选“月份翻页对象”两种月份导航模式），
// 但改成一个具名 options 对象，见下方逐字段注释与其在原函数中的对应位置。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};

  // 源码 p.STANDARD_DELAY = 30 (deobfuscated.js 行29765: f(p,"STANDARD_DELAY",30))，
  // standardSleep() = sleep(30)。之前误设为 300，导致翻年/翻月/点日期每步慢 10 倍。
  var STANDARD_DELAY = 30;
  var CLICK_EXTRA_DELAY = 20; // 源码 p.CLICK_EXTRA_DELAY = 20 (行29766)

  function sleep(ms) {
    return AF.Utils && AF.Utils.sleep ? AF.Utils.sleep(ms) : new Promise(function (r) { setTimeout(r, ms); });
  }

  // ============ 日期字符串/月份名称解析工具 (源码 p 类, 行27340-27425) ============

  // 源码 findMonth: 从形如 "2024年3月" 或 "3月" 的文本里解析出月份数字字符串
  function findMonth(text) {
    var patterns = [
      { regex: /(\d{4})\s*年\s*(\d{1,2})\s*月/, group: 2 },
      { regex: /(\d{1,2})\s*月/, group: 1 },
    ];
    for (var i = 0; i < patterns.length; i++) {
      var m = text.match(patterns[i].regex);
      if (m && m[patterns[i].group]) return m[patterns[i].group];
    }
    return null;
  }

  // 源码 findMonthName: 月份数字 -> 该月份在各种 UI 里可能显示的文案数组
  function findMonthName(month) {
    if (typeof month === "string") month = parseInt(month, 10);
    var table = {
      1: ["一月", "1月", "01", "1", "Jan", "01月"],
      2: ["二月", "2月", "02", "2", "Feb", "02月"],
      3: ["三月", "3月", "03", "3", "Mar", "03月"],
      4: ["四月", "4月", "04", "4", "Apr", "04月"],
      5: ["五月", "5月", "05", "5", "May", "05月"],
      6: ["六月", "6月", "06", "6", "Jun", "06月"],
      7: ["七月", "7月", "07", "7", "Jul", "07月"],
      8: ["八月", "8月", "08", "8", "Aug", "08月"],
      9: ["九月", "9月", "09", "9", "Sept", "09月"],
      10: ["十月", "10月", "10", "10", "Oct", "10月"],
      11: ["十一月", "11月", "11", "11", "Nov", "11月"],
      12: ["十二月", "12月", "12", "12", "Dec", "12月"],
    };
    return table[month] || [];
  }

  // 源码 parseYearFromString: 从 "2024年" 或 "2024" 里解析出年份
  function parseYearFromString(text) {
    var patterns = [
      { regex: /(\d{4})\s*年/, group: 1 },
      { regex: /(\d{4})\s*/, group: 1 },
    ];
    for (var i = 0; i < patterns.length; i++) {
      var m = String(text).match(patterns[i].regex);
      if (m && m[patterns[i].group]) return m[patterns[i].group];
    }
    return null;
  }

  // 源码 parseEndYear: 从年份列表的"边界项"文案（如 "2020年-2029年" / "2020-2029" / "2024年3月"）
  // 里解析出用于跟目标年份比较大小的边界年份
  function parseEndYear(text) {
    var patterns = [
      { regex: /(\d{4})\s*年\s*-\s*(\d{4})\s*年/, group: 2 },
      { regex: /(\d{4})\s*年/, group: 1 },
      { regex: /(\d{4})\s*-\s*(\d{4})/, group: 2 },
      { regex: /(\d{4})\s*/, group: 1 },
      { regex: /(\d{4})\s*年\s*(\d{1,2})\s*月/, group: 1 },
      { regex: /(\d{1,2})\s*月(\d{4})\s*/, group: 2 },
    ];
    for (var i = 0; i < patterns.length; i++) {
      var m = String(text).match(patterns[i].regex);
      if (m && m[patterns[i].group]) return m[patterns[i].group];
    }
    return null;
  }

  function pad2(n) {
    n = String(n);
    return n.length < 2 ? "0" + n : n;
  }

  // 公开: 把常见的日期字符串解析成 {year, month, day}（day 可能为 null，表示只有年月）
  // 支持格式见 content/utils.js AF.DomUtils.isDateValue: YYYY-M-D / YYYY-M / YYYY年M月D日 / YYYY年M月 / YYYY/M/D
  function parseDateValue(value) {
    if (!value || typeof value !== "string") return null;
    var m;
    if ((m = value.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/))) {
      return { year: parseInt(m[1], 10), month: parseInt(m[2], 10), day: parseInt(m[3], 10) };
    }
    if ((m = value.match(/^(\d{4})-(\d{1,2})$/))) {
      return { year: parseInt(m[1], 10), month: parseInt(m[2], 10), day: null };
    }
    if ((m = value.match(/^(\d{4})年(\d{1,2})月(\d{1,2})日$/))) {
      return { year: parseInt(m[1], 10), month: parseInt(m[2], 10), day: parseInt(m[3], 10) };
    }
    if ((m = value.match(/^(\d{4})年(\d{1,2})月$/))) {
      return { year: parseInt(m[1], 10), month: parseInt(m[2], 10), day: null };
    }
    if ((m = value.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/))) {
      return { year: parseInt(m[1], 10), month: parseInt(m[2], 10), day: parseInt(m[3], 10) };
    }
    return null;
  }

  // 把 {year,month,day} 转回 "Y-M-D"（day 为空时退化成 "Y-M"），供 _navigatePanel 使用
  function toDashString(parsed) {
    if (!parsed) return "";
    if (parsed.day) return parsed.year + "-" + parsed.month + "-" + parsed.day;
    return parsed.year + "-" + parsed.month;
  }

  // ============ 通用面板导航器 (源码 w()/x(), 行28099-28499) ============
  //
  // 原始 14 个位置参数 -> 本实现的具名 options 字段对照 (通过实际调用点如 Ant/Element/iView/
  // LayUI/Kuma/Mtd/Phoenix/Bitable/AntPickerRange 反推确认，非猜测):
  //   位置0  container            options.container            日期面板/下拉容器
  //   位置1  dateString           options.dateString           "Y-M-D" 或 "Y-M"
  //   位置2  headerClickSelector  options.headerClickSelector  开局点一次以切到"年列表"视图(可null)
  //   位置3  yearCellSelector     options.yearCellSelector      年份格子列表选择器
  //   位置4  disabledClassList    options.disabledClassList     数组(祖先class黑名单)/true/null
  //   位置5  yearBoundarySelector options.yearBoundarySelector  年份列表的边界项选择器(可null，取列表最后一项兜底)
  //   位置6  nextYearSelector     options.nextYearSelector      翻到更晚年份的按钮选择器
  //   位置7  prevYearSelector     options.prevYearSelector      翻到更早年份的按钮选择器
  //   位置8  monthPanelSelector   options.monthPanelSelector    月份导航方式(见下)
  //   位置9  monthCellSelector    options.monthCellSelector     月份格子/表头选择器(见下)
  //   位置10 dayCellSelector      options.dayCellSelector       日期格子选择器(falsy则只到年月)
  //   位置11 maxRetries           options.maxRetries = 20       年份翻页最大重试次数
  //   位置12 refineSelector       options.refineSelector = null 用 container.querySelector(x)||container 细化容器
  //   位置13 monthRetries         options.monthRetries = 10     月份翻页最大重试次数
  //
  // monthPanelSelector / monthCellSelector 是一对二态字段(照抄原函数 s/f 的双重语义):
  //   - monthPanelSelector 是字符串: 表示"点击该选择器可以展开一个月份列表子面板"；此时
  //     monthCellSelector 是"月份格子列表"选择器，按月份中文/数字/英文文案匹配后点击。
  //   - monthPanelSelector 是 {nextMonthSelector, prevMonthSelector} 对象: 表示该框架没有单独的
  //     月份列表面板，只能一次翻一个月；此时 monthCellSelector 改当"表头文案"选择器读取当前月份，
  //     不一致就点 next/prevMonthSelector 再重试。
  //   - monthPanelSelector 为 null/falsy: 月份格子列表默认就是可见的，直接用 monthCellSelector 当格子列表。
  async function navigatePanel(options) {
    var container = options.container;
    var refineSelector = options.refineSelector || null;
    var headerClickSelector = options.headerClickSelector || null;
    var yearCellSelector = options.yearCellSelector;
    var disabledClassList = options.disabledClassList != null ? options.disabledClassList : null;
    var yearBoundarySelector = options.yearBoundarySelector || null;
    var nextYearSelector = options.nextYearSelector;
    var prevYearSelector = options.prevYearSelector;
    var monthPanelSelector = options.monthPanelSelector;
    var monthCellSelector = options.monthCellSelector;
    var dayCellSelector = options.dayCellSelector || null;
    var maxRetries = options.maxRetries != null ? options.maxRetries : 20;
    var monthRetries = options.monthRetries != null ? options.monthRetries : 10;

    if (!container || !options.dateString) return false;
    var parts = options.dateString.split("-").map(function (s) { return parseInt(s, 10); });
    var targetYear = parts[0];
    var targetMonth = parts[1];
    var targetDay = parts[2];

    var panel = container;
    function refine() {
      if (refineSelector) panel = container.querySelector(refineSelector) || container;
    }

    async function pickDay() {
      refine();
      if (!dayCellSelector) return true;
      var cells = panel.querySelectorAll(dayCellSelector);
      if (!cells.length) return true;
      if (cells[0].textContent.includes("月")) return true;
      var matches = Array.from(cells).filter(function (c) {
        return parseInt(c.textContent.trim().replace(/\s+/g, ""), 10) === targetDay;
      });
      if (!matches.length) return false;
      var target = targetDay <= 15 ? matches[0] : matches[matches.length - 1];
      await AF.DomUtils.safeClickElement(target);
      await sleep(STANDARD_DELAY);
      return true;
    }

    async function pickMonth(retries) {
      if (retries === undefined) retries = monthRetries;
      refine();
      var isFlipMode = monthPanelSelector && typeof monthPanelSelector === "object";
      if (!isFlipMode) {
        if (monthPanelSelector && !panel.querySelector(monthCellSelector)) {
          var openBtn = panel.querySelector(monthPanelSelector);
          if (openBtn) {
            openBtn.click();
            await sleep(STANDARD_DELAY);
            refine();
          }
        }
        var names = findMonthName(targetMonth);
        var monthCells = panel.querySelectorAll(monthCellSelector);
        var matched = null;
        monthCells.forEach(function (c) {
          if (names.indexOf(c.textContent.trim().replace(/\s+/g, "")) !== -1) matched = c;
        });
        if (!matched) return false;
        matched.click();
        await sleep(STANDARD_DELAY);
        return pickDay();
      }
      // flip 模式: monthCellSelector 在此模式下是"表头文案"选择器
      if (retries <= 0) return false;
      var headerEl = panel.querySelector(monthCellSelector);
      if (!headerEl) return false;
      var headerText = headerEl.textContent.trim();
      var currentMonth = parseInt(findMonth(headerText), 10);
      if (currentMonth === targetMonth) return pickDay();
      var btnSel = targetMonth > currentMonth ? monthPanelSelector.nextMonthSelector : monthPanelSelector.prevMonthSelector;
      panel.querySelectorAll(btnSel).forEach(function (b) { b.click(); });
      await sleep(STANDARD_DELAY);
      return pickMonth(retries - 1);
    }

    async function pickYear(retries) {
      if (retries === undefined) retries = maxRetries;
      refine();
      if (retries <= 0) return false;
      var yearCells = panel.querySelectorAll(yearCellSelector);
      if (!yearCells || !yearCells.length) throw new Error("年份列表为空");
      var matched = null;
      Array.prototype.forEach.call(yearCells, function (cell) {
        var y = parseInt(parseYearFromString(cell.textContent), 10);
        if (y === targetYear) {
          if (Array.isArray(disabledClassList)) {
            var isDisabled = disabledClassList.some(function (cls) {
              return AF.DomUtils.findClosestAncestorWithClass(cell, cls);
            });
            if (!isDisabled) matched = cell;
          } else {
            matched = cell;
          }
        }
      });
      if (matched) {
        matched.click();
        await sleep(STANDARD_DELAY);
        return pickMonth();
      }
      var boundaryEl = yearBoundarySelector ? panel.querySelector(yearBoundarySelector) : null;
      var boundaryText = (boundaryEl && boundaryEl.textContent) ||
        (yearCells[yearCells.length - 1] && yearCells[yearCells.length - 1].textContent.trim());
      var boundaryYear = parseInt(parseEndYear(boundaryText || ""), 10);
      if (!boundaryYear) return false;
      var pageSel = targetYear >= boundaryYear ? nextYearSelector : prevYearSelector;
      // 同一日期弹层可能同时挂着隐藏/备用按钮。全部 click 会让年份一次
      // 跳两页甚至多页，历史日期就可能被填成明显错误的未来年份。
      var pageBtns = pageSel ? Array.from(panel.querySelectorAll(pageSel)).filter(function (button) {
        return !AF.DomUtils || !AF.DomUtils.isElementVisible || AF.DomUtils.isElementVisible(button);
      }) : [];
      // 源码行28410: 翻页按钮找不到时, 先试 UD(飞书多维表格) 专用表头图标兜底
      // (图标≥2个时, 往后翻点最后一个, 往前翻点第一个), 再走月份对象兜底
      var udIcons = pageBtns.length
        ? []
        : panel.querySelectorAll(".ud__picker-panel-header .ud__picker-panel-header-icon:not(.ud__picker-panel-header-collapse)");
      if (pageBtns.length) {
        // 每轮只操作一个当前可见按钮，并在下一轮重新读取面板年份。
        pageBtns[0].click();
      } else if (udIcons.length >= 2) {
        (targetYear >= boundaryYear ? udIcons[udIcons.length - 1] : udIcons[0]).click();
      } else if (monthPanelSelector && typeof monthPanelSelector === "object") {
        var altSel = targetYear >= boundaryYear ? monthPanelSelector.nextMonthSelector : monthPanelSelector.prevMonthSelector;
        var altBtns = panel.querySelectorAll(altSel);
        if (altBtns.length) {
          var visibleAlt = Array.from(altBtns).filter(function (button) {
            return !AF.DomUtils || !AF.DomUtils.isElementVisible || AF.DomUtils.isElementVisible(button);
          });
          (visibleAlt[0] || altBtns[0]).click();
        } else {
          return false;
        }
      } else {
        return false;
      }
      await sleep(STANDARD_DELAY);
      return pickYear(retries - 1);
    }

    try {
      refine();
      if (headerClickSelector) {
        var el = panel.querySelector(headerClickSelector);
        if (el) {
          el.click();
          await sleep(STANDARD_DELAY);
          refine();
        } else {
          await sleep(STANDARD_DELAY);
        }
      }
      var result = await pickYear();
      return !!result;
    } catch (e) {
      return false;
    }
  }

  // ============ 范围日期: 从候选兄弟元素里挑出"结束日期"输入框 (源码 ho(), 行47360-47444) ============
  // 大多数范围日期子类 (Ant/Kuma/Mtd/LayUI/Bitable/Phoenix/iView/native/wdate) 在设置完开始日期后，
  // 用 AF.DomUtils.findSimilarElements 找到一批"看起来像"结束日期输入框的候选元素，再用这个打分函数
  // (关键词 +DOM顺序/位置 + class 重合度 + input type/name 特征) 选出最像"结束日期"的那个。
  function pickEndDateCandidate(referenceEl, candidates) {
    if (!candidates || candidates.length === 0) return null;
    var endKeywords = ["结束", "end", "to", "截止", "终止", "finish", "时间", "止", "截止日期", "结束时间"];
    var startKeywords = ["开始", "start", "from", "起", "起始日期", "开始时间"];
    var scored = candidates.map(function (el) {
      var text = (el.getAttribute("placeholder") || el.getAttribute("aria-label") || el.getAttribute("title") || el.textContent || "").toLowerCase();
      var keywordScore = 0;
      endKeywords.forEach(function (k) { if (text.includes(k.toLowerCase())) keywordScore += 2; });
      startKeywords.forEach(function (k) { if (text.includes(k.toLowerCase())) keywordScore -= 3; });

      var positionScore = 0;
      if (referenceEl) {
        var all = Array.from(document.querySelectorAll("*"));
        var refIdx = all.indexOf(referenceEl);
        var elIdx = all.indexOf(el);
        var domOrderScore = elIdx > refIdx ? Math.min(1, Math.max(0, 1 - Math.log10(elIdx - refIdx + 1) / 2)) : 0;
        var refRect = referenceEl.getBoundingClientRect();
        var elRect = el.getBoundingClientRect();
        var dx = elRect.left - refRect.left;
        var horizScore = dx > 0 ? Math.min(1, 1 / (1 + Math.exp(-dx / 50))) : 0;
        var dy = elRect.top - refRect.top;
        var vertScore = dy > 0 ? Math.min(0.5, 0.5 / (1 + Math.exp(-dy / 30))) : 0;
        var dist = Math.sqrt(Math.pow(refRect.left - elRect.left, 2) + Math.pow(refRect.top - elRect.top, 2));
        positionScore = domOrderScore + horizScore + vertScore + (dist < 300 ? (1 - dist / 300) * 0.5 : 0);
      }

      var classScore = 0;
      if (referenceEl) {
        var refClasses = Array.from(referenceEl.classList);
        classScore = Array.from(el.classList).filter(function (c) { return refClasses.includes(c); }).length;
      }

      var typeScore = 0;
      var type = el.getAttribute("type");
      var name = (el.getAttribute("name") || "").toLowerCase();
      if (type === "date" || type === "datetime-local") typeScore += 2;
      if (name.includes("end")) typeScore += 1;
      if (name.includes("start")) typeScore -= 1;

      return { element: el, score: keywordScore * 3 + positionScore * 2 + classScore * 1.5 + typeScore };
    });
    scored.sort(function (a, b) { return b.score - a.score; });
    return scored[0].score > 0 ? scored[0].element : null;
  }

  AF.DatePicker._registry = AF.DatePicker._registry || {};
  AF.DatePicker._STANDARD_DELAY = STANDARD_DELAY;
  AF.DatePicker._sleep = sleep;
  AF.DatePicker._findMonthName = findMonthName;
  AF.DatePicker._findMonth = findMonth;
  AF.DatePicker._parseYearFromString = parseYearFromString;
  AF.DatePicker._parseEndYear = parseEndYear;
  AF.DatePicker._pad2 = pad2;
  AF.DatePicker._parseDateValue = parseDateValue;
  AF.DatePicker._toDashString = toDashString;
  AF.DatePicker._navigatePanel = navigatePanel;
  AF.DatePicker._pickEndDateCandidate = pickEndDateCandidate;
})();
