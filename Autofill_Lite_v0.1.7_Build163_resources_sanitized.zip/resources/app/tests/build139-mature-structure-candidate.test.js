"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const { compileGraphStructureFromBundle, attachGraphStructureToSiteCandidate } = require("../graph-structure-site-candidate");
const { compileSemanticSiteCandidate } = require("../ai-site-config-candidate");

const bundle = {
  snapshots: [{
    at: "2026-09-18T00:00:00Z",
    fingerprint: "abc",
    analysis: {
      graphCoverage: { linkedRatio: 1 },
      staticScan: { fields: [
        { graphRowId: "r1", label: "工作单位：", graphFieldId: "f1", selectorHint: "#company", controlType: "text" },
        { graphRowId: "r2", label: "职位名称：", graphFieldId: "f2", selectorHint: "#job", controlType: "text" }
      ] },
      formGraph: {
        graphVersion: "1.3.0",
        totals: { sections: 1, rows: 2, controls: 2 },
        sections: [{
          sectionId: "s1", selectorHint: "#resumeJobHistory", title: "实习/工作/入伍经历",
          rows: [
            { rowId: "r1", selectorHint: "#row1", controlCount: 1, controls: [{ fieldId: "f1", selectorHint: "#company", controlType: "text" }] },
            { rowId: "r2", selectorHint: "#row2", controlCount: 1, controls: [{ fieldId: "f2", selectorHint: "#job", controlType: "text" }] }
          ]
        }]
      }
    }
  }]
};
const structure = compileGraphStructureFromBundle(bundle, "https://example.com/web/createResume.html");
assert(structure);
assert.strictEqual(structure.sections.length, 1);
assert.strictEqual(structure.sections[0].rows[0].label, "工作单位：");
assert.strictEqual(structure.summary.aiAuthoredSelectors, false);

const review = { page: { hostname: "example.com", pathname: "/web/createResume.html" }, trustedMappings: [], reviewFields: [] };
const patch = { decisions: [] };
const semantic = compileSemanticSiteCandidate(review, patch, {});
const combined = attachGraphStructureToSiteCandidate(semantic, structure);
assert(combined.configTemplate._graphStructure);
assert.strictEqual(combined.configTemplate._autoConfigStrategy.requiresMatureBaseConfig, false);
assert.strictEqual(combined.configTemplate._autoConfigStrategy.mode, "graph_backed_structure_candidate_v1");
assert.strictEqual(combined.summary.graphStructureSections, 1);
assert.strictEqual(combined.safety.selectorsAuthoredByAi, false);

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const experience = fs.readFileSync(path.join(root, "autofill-plugin/content/experience-handler.js"), "utf8");
const formHandler = fs.readFileSync(path.join(root, "autofill-plugin/content/form-handler.js"), "utf8");
const matcher = fs.readFileSync(path.join(root, "autofill-plugin/content/element-matcher.js"), "utf8");
const loader = fs.readFileSync(path.join(root, "autofill-plugin/content/site-loader.js"), "utf8");
const utils = fs.readFileSync(path.join(root, "autofill-plugin/content/utils.js"), "utf8");

const buildMatch139 = main.match(/const BUILD_ID = "([^"]+)";/);
assert(buildMatch139 && Number((buildMatch139[1].match(/-(\d+)$/) || [])[1] || 0) >= 139);
assert(main.includes('ai_graph_structure_core_apply'));
assert(main.includes('graphStructureAvailable'));
assert(main.includes('compileGraphStructureFromBundle'));
assert(main.includes('attachGraphStructureToSiteCandidate'));
assert(main.includes('requiresMatureBaseConfig: graphBacked ? false : true'));

// Mature Moka ownership: inline React cards must re-resolve their bound card,
// never let a stale Existing Editor scope override card ownership.
assert(experience.includes('var mokaInlineCard = isMokaPage(示例资料Scope) && 示例资料Scope.configAdapter.usesInlinePersistence();'));
assert(experience.includes('stale editor scopes are forbidden'));
assert(formHandler.includes('moka_identity_verify'));
assert(formHandler.includes('readFreshMokaIdentity'));

// Graph-backed SiteConfig uses only locally observed selectors. Core exposes
// graph section/row nodes as synthetic titles/labels and verifies compatibility.
assert(matcher.includes('data-af-graph-section-title'));
assert(matcher.includes('data-af-graph-row-label'));
assert(matcher.includes('data-af-graph-control-selector'));
assert(loader.includes('graph row 命中率过低'));
assert(loader.includes('graphBacked: true'));
assert(utils.includes('data-af-graph-row-label'));

console.log("build139-mature-structure-candidate.test.js PASS");
