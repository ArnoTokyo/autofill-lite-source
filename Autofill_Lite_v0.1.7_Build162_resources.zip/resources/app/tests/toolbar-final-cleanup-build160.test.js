"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const index = fs.readFileSync(path.join(root, "index.html"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
const action = index.slice(index.indexOf('<div class="actionrow">'), index.indexOf('</div>\n  </header>'));
const buildMatch = main.match(/const BUILD_ID = "([^"]+)-(\d+)";/);
assert(buildMatch && Number(buildMatch[2]) >= 160, "Build160+ runtime id missing");
assert(pkg.build === `${buildMatch[1]}-${buildMatch[2]}`, "package build id must match runtime BUILD_ID");
assert(/Autofill Lite · v0\.1\.7 · 测试版 · build \d+/.test(index), "Build160+ document title missing");
for (const id of ["aiSettings", "data", "devtools"]) assert(action.includes(`id="${id}"`), `kept tool missing: ${id}`);
for (const id of ["analyze", "aiMap", "experimentMenu", "sectionTxn", "educationProbe", "educationPreviewFill", "educationContinuePreview", "multiSectionSurvey", "multiSectionPreview", "multiSectionSave", "verifySiteCandidate"]) {
  assert(!action.includes(`id="${id}"`), `obsolete manual tool still exposed: ${id}`);
}
assert(main.includes('ipcMain.handle("lite:analyze-site"'), "internal site-analysis fallback must remain available");
console.log("toolbar-final-cleanup-build160.test.js PASS");
