"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const privateSites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const renderer = fs.readFileSync(path.join(root, "renderer.js"), "utf8");
const indexHtml = fs.readFileSync(path.join(root, "index.html"), "utf8");

const targetUrl = "https://zhaopin.cnpc.com.cn/web/createResume.html?ic=test";
global.window = { AF: {}, location: { href: targetUrl } };
global.document = {
  querySelector(selector) { return selector === "body" ? this.body : null; },
  body: { innerText: "", textContent: "", querySelectorAll() { return []; } },
};
new Function(privateSites)();
assert.strictEqual(window.AF.PrivateSpecialSites.getConfigForUrl(targetUrl), null,
  "CNPC must remain an unknown site until the full workflow has been verified");
assert.strictEqual(window.AF.PrivateSpecialSites.getWorkflowForUrl(targetUrl), null,
  "CNPC must not claim a special workflow before end-to-end verification");

console.log("CNPC no-local-config regression: PASS");
