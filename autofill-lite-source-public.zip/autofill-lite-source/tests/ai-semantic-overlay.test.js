"use strict";
const assert = require("assert");
const { classifyLocalFirstRoute, compileRuntimeSemanticOverlay } = require("../ai-semantic-overlay");

assert.deepStrictEqual(
  classifyLocalFirstRoute({ matchedWorkflowId: "known-flow", builtInConfigFound: false }),
  { strongLocalSupport: true, platformCapabilityAvailable: false, route: "local_first", reasons: ["special_workflow"] }
);
assert.strictEqual(classifyLocalFirstRoute({}).route, "ai_preflight_allowed");
assert.strictEqual(classifyLocalFirstRoute({ domPlatformDetected: true }).strongLocalSupport, false);
assert.strictEqual(classifyLocalFirstRoute({ domPlatformDetected: true }).platformCapabilityAvailable, true);

const review = {
  page: { hostname: "example.com", pathname: "/resume" },
  reviewFields: [
    { fieldId: "fld_gpa", label: "满绩绩点", controlType: "text", patchTarget: { kind: "semantic_label", label: "满绩绩点" } },
    { fieldId: "fld_gender", label: "", controlType: "radio", selectorHitCount: 1, selectorCandidates: [{ selector: 'input[name="gender"]', hitCount: 2, kind: "name" }], patchTarget: { kind: "unique_selector", selector: "#male" } },
    { fieldId: "fld_low", label: "职务描述", controlType: "textarea", patchTarget: { kind: "semantic_label", label: "职务描述" } },
    { fieldId: "fld_small", label: "小语种掌握情况", controlType: "element-select", patchTarget: { kind: "semantic_label", label: "小语种掌握情况" } },
    { fieldId: "fld_phone_select", label: "", controlType: "element-select", patchTarget: { kind: "unique_selector", selector: ".my-selent-phone" } }
  ]
};
const patch = {
  decisions: [
    { fieldId: "fld_gpa", decision: "map", category: "education", fieldKey: "gpaTotal", confidence: 0.91 },
    { fieldId: "fld_gender", decision: "map", category: "basicInfo", fieldKey: "gender", confidence: 0.95 },
    { fieldId: "fld_low", decision: "map", category: "campusLeadership", fieldKey: "description", confidence: 0.7 },
    { fieldId: "fld_small", decision: "map", category: "languageSkills", fieldKey: "name", confidence: 0.95 },
    { fieldId: "fld_phone_select", decision: "map", category: "basicInfo", fieldKey: "phone", confidence: 0.95 }
  ]
};
const overlay = compileRuntimeSemanticOverlay(review, patch, { minConfidence: 0.8 });
assert.strictEqual(overlay.fieldMappings.length, 1);
assert.strictEqual(overlay.selectorMappings.length, 1);
assert.deepStrictEqual(
  { category: overlay.selectorMappings[0].category, fieldKey: overlay.selectorMappings[0].fieldKey, selector: overlay.selectorMappings[0].selector, selectorMode: overlay.selectorMappings[0].selectorMode },
  { category: "basicInfo", fieldKey: "gender", selector: 'input[name="gender"]', selectorMode: "group" }
);
assert.deepStrictEqual(
  { category: overlay.fieldMappings[0].category, fieldKey: overlay.fieldMappings[0].fieldKey, label: overlay.fieldMappings[0].label },
  { category: "education", fieldKey: "gpaTotal", label: "满绩绩点" }
);
const reasons = overlay.skipped.map((x) => x.reason);
assert(!reasons.includes("non_label_target"));
assert(reasons.includes("low_confidence"));
assert(reasons.includes("record_subtype_not_proven"));

const conflictReview = {
  page: review.page,
  reviewFields: [
    { fieldId: "a", label: "状态", controlType: "text", patchTarget: { kind: "semantic_label", label: "状态" } },
    { fieldId: "b", label: "状态", controlType: "text", patchTarget: { kind: "semantic_label", label: "状态" } }
  ]
};
const conflictPatch = { decisions: [
  { fieldId: "a", decision: "map", category: "basicInfo", fieldKey: "healthStatus", confidence: 0.9 },
  { fieldId: "b", decision: "map", category: "basicInfo", fieldKey: "maritalStatus", confidence: 0.9 }
] };
const conflict = compileRuntimeSemanticOverlay(conflictReview, conflictPatch);
assert.strictEqual(conflict.fieldMappings.length, 0);
assert.strictEqual(conflict.skipped.filter((x) => x.reason === "conflicting_label_mapping").length, 2);

console.log("ai-semantic-overlay.test.js PASS");
