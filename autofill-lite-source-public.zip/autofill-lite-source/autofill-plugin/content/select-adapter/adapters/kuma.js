// content/select-adapter/adapters/kuma.js — 阿里 Kuma/uxcore (.kuma-select2*) 适配器
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   KumaSelectAdapter (模块3927):   行 15266-16772
//   triggerKumaSelect (混淆名 v/m): 行 15880-15955
//
// 算法 (对应源码 m() 函数, 行15883-15955):
//   1. 若 element 本身是原生 <select>（部分旧版 kuma 用原生 select 打底），走原生匹配+赋值逻辑
//   2. 否则 container = closest(.kuma-select2) 或配置里的 container；
//      trigger = container 内 .kuma-select2-selection (或配置 trigger)
//   3. 点击 trigger 展开面板，面板类名包含 kuma-select2-dropdown / kuma-select-dropdown /
//      kuma-dropdown-menu 且不带 xxx-hidden 后缀，用 findVisibleDropdownNear 全局搜索
//   4. 找到面板后调用通用 selectMatchingOption
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};
  var H = SA._helpers;
  var CFG = SA._config.kuma;
  var DROPDOWN_PANEL_SELECTOR = [
    ".kuma-select2-dropdown:not(.kuma-select2-dropdown-hidden)",
    ".kuma-select-dropdown:not(.kuma-select-dropdown-hidden)",
    ".kuma-dropdown-menu:not(.kuma-dropdown-menu-hidden)",
  ];

  async function selectOneKumaValue(element, container, trigger, value) {
    await AF.DomUtils.safeClickElement(trigger);
    await AF.Utils.sleep(200);
    var panel = H.findVisibleDropdownNear(element, DROPDOWN_PANEL_SELECTOR, ".kuma-select2");
    if (!panel) {
      panel = await H.waitForVisibleDropdownNear(element, DROPDOWN_PANEL_SELECTOR, ".kuma-select2", 1500);
    }
    if (!panel) return false;
    return await H.selectMatchingOption(panel, value, CFG.dropdown);
  }

  async function triggerKumaSelect(element, value) {
    try {
      if (element.tagName === "SELECT") {
        return await AF.SelectAdapter._setNativeSelectValue(element, value);
      }

      var container = element.closest(".kuma-select2") || element.closest(CFG.container) || element;
      var trigger = container.querySelector(".kuma-select2-selection") || container.querySelector(CFG.trigger) || container;

      var ok;
      if (Array.isArray(value)) {
        ok = false;
        for (var i = 0; i < value.length; i++) {
          var one = await selectOneKumaValue(element, container, trigger, value[i]);
          if (one) ok = true;
          await AF.Utils.sleep(150);
        }
      } else {
        ok = await selectOneKumaValue(element, container, trigger, value);
      }
      H.dispatchChangeEvents(element);
      return ok;
    } catch (e) {
      return false;
    }
  }

  SA._registry["kuma"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        return await triggerKumaSelect(element, value);
      },
    };
  };
})();
