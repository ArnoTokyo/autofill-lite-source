"use strict";
const assert = require("assert");
const path = require("path");

// Load the browser collector in a minimal Node shim. This test calls only the
// pure graph-linking helper; it never scans/mutates a real DOM.
global.location = { href: "https://example.test/resume?token=secret", hostname: "example.test", pathname: "/resume" };
global.document = { body: null };
global.window = { AF: {}, getComputedStyle: () => ({}) };

const collectorPath = path.resolve(__dirname, "..", "autofill-plugin", "content", "site-analysis-collector.js");
delete require.cache[require.resolve(collectorPath)];
require(collectorPath);
const collector = global.window.AF.SiteAnalysisCollector;
assert(collector && typeof collector.attachFormGraphContext === "function", "graph linker API missing");

const scan = {
  controlCount: 3,
  fields: [
    { label: "学校名称", controlType: "text", selectorHint: "#school", widgetSelectorHint: "" },
    { label: "学历", controlType: "element-select", selectorHint: "#degree-internal", widgetSelectorHint: "#degree" },
    { label: "专业名称", controlType: "text", selectorHint: ".non-unique-major", widgetSelectorHint: "" }
  ]
};
const graph = {
  schemaType: "autofill-lite-form-graph",
  schemaVersion: 1,
  graphVersion: "1.3.0",
  totals: { sections: 1, rows: 3, controls: 3 },
  safety: { currentValuesIncluded: false, arbitraryRowTextIncluded: false, queryIncluded: false },
  controls: [
    { fieldId: "fld_school", selectorHint: "#school", label: "学校名称", controlType: "text", sectionId: "sec_edu", sectionTitle: "教育信息", rowId: "row_school", rowLabel: "学校名称" },
    { fieldId: "fld_degree", selectorHint: "#degree", label: "学历", controlType: "custom-select", sectionId: "sec_edu", sectionTitle: "教育信息", rowId: "row_degree", rowLabel: "学历" },
    { fieldId: "fld_major", selectorHint: "#major", label: "专业名称", controlType: "text", sectionId: "sec_edu", sectionTitle: "教育信息", rowId: "row_major", rowLabel: "专业名称" }
  ]
};

const coverage = collector.attachFormGraphContext(scan, graph);
assert.strictEqual(coverage.staticControlCount, 3);
assert.strictEqual(coverage.graphControlCount, 3);
assert.strictEqual(coverage.linkedStaticFieldCount, 3, "selector/widget/label fallback should link all fixture fields");
assert.strictEqual(coverage.unlinkedStaticFieldCount, 0);
assert.strictEqual(coverage.linkedRatio, 1);
assert.strictEqual(scan.fields[0].graphFieldId, "fld_school");
assert.strictEqual(scan.fields[0].graphRowId, "row_school");
assert.strictEqual(scan.fields[0].graphLinkMethod, "unique_control_selector");
assert.strictEqual(scan.fields[1].graphFieldId, "fld_degree");
assert.strictEqual(scan.fields[1].graphLinkMethod, "unique_widget_selector");
assert.strictEqual(scan.fields[2].graphFieldId, "fld_major");
assert.strictEqual(scan.fields[2].graphLinkMethod, "unique_label_type");

const ai = require(path.resolve(__dirname, "..", "site-analysis-ai-input.js"));
const compactField = ai.compactAiField(Object.assign({}, scan.fields[0], {
  section: "教育信息", labelSource: "form_item_label", safeSemanticCandidates: ["学校名称"]
}));
assert.strictEqual(compactField.graphFieldId, "fld_school");
assert.strictEqual(compactField.graphSectionId, "sec_edu");
assert.strictEqual(compactField.graphRowId, "row_school");
assert.strictEqual(compactField.graphRowLabel, "学校名称");

const compactGraph = ai.compactFormGraph({
  schemaType: graph.schemaType,
  schemaVersion: graph.schemaVersion,
  graphVersion: graph.graphVersion,
  totals: graph.totals,
  sections: [{
    sectionId: "sec_edu", title: "教育信息", role: "form_section", rowCount: 1, controlCount: 1,
    rows: [{ rowId: "row_school", role: "field_row", label: "学校名称", controlCount: 1,
      controls: [{ fieldId: "fld_school", label: "学校名称", controlType: "text", widgetFamily: "native", required: true,
        value: "SENSITIVE SHOULD NEVER BE EXPORTED", selectorHint: "#school" }] }]
  }]
});
assert.strictEqual(compactGraph.sections[0].rows[0].controls[0].fieldId, "fld_school");
const serialized = JSON.stringify(compactGraph);
assert(!serialized.includes("SENSITIVE SHOULD NEVER BE EXPORTED"), "FormGraph AI summary leaked a current value");
assert(!serialized.includes("selectorHint"), "Build96 AI graph context should not expose graph selectors");

console.log("form graph analyzer integration: PASS");
