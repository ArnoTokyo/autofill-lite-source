"use strict";

function patchJsonSchema() {
  return {
    type: "object",
    additionalProperties: false,
    required: ["schemaType", "schemaVersion", "decisions"],
    properties: {
      schemaType: { type: "string", enum: ["autofill-lite-ai-semantic-patch"] },
      schemaVersion: { type: "integer", enum: [1] },
      decisions: {
        type: "array",
        items: {
          type: "object",
          additionalProperties: false,
          required: ["fieldId", "decision", "category", "fieldKey", "confidence", "reason"],
          properties: {
            fieldId: { type: "string" },
            decision: { type: "string", enum: ["map", "leave_unmapped", "needs_special_示例资料flow"] },
            category: { type: "string" },
            fieldKey: { type: "string" },
            confidence: { type: "number" },
            reason: { type: "string" }
          }
        }
      }
    }
  };
}

function systemPrompt() {
  return [
    "You are Autofill Lite's semantic mapping analyzer for job application forms.",
    "You receive a privacy-sanitized ai-review JSON. Never infer or invent the user's resume values.",
    "Return ONLY one valid JSON object. Do not use Markdown fences, prose before the JSON, or prose after the JSON.",
    "The JSON object must have schemaType=autofill-lite-ai-semantic-patch, schemaVersion=1, and a decisions array.",
    "For every reviewFields item, return exactly one decision referencing its fieldId.",
    "Each decision object must contain exactly: fieldId, decision, category, fieldKey, confidence, reason.",
    "Use decision=map only when category and fieldKey both exist in profileContract.categories.",
    "For leave_unmapped or needs_special_示例资料flow, category and fieldKey must both be empty strings.",
    "Use leave_unmapped when the site asks for information that has no canonical profile field, is optional/unknown, or cannot be mapped safely.",
    "Use needs_special_示例资料flow only when semantic mapping alone cannot represent the required interaction or binding.",
    "Treat suggestedCoreFieldKey as a hint, not truth. Correct it when semantic evidence conflicts.",
    "Use profileContract.fieldSemantics when present to distinguish current versus desired fields.",
    "Confidence measures semantic mapping certainty only; it must NOT be reduced because the user's current profile value may be absent.",
    "For an exact label or an unambiguous synonym that matches a defined canonical field in the correct section, use high confidence (normally 0.90-1.00).",
    "When a site field asks for a concept that the canonical contract does not represent, prefer leave_unmapped with high confidence rather than forcing a low-confidence map.",
    "Examples: current salary may map to jobIntention.currentSalary when that key exists; desired industry maps to jobIntention.industry; current occupation must not map to desired position; current 示例资料 city must not map to current residence unless the contract explicitly defines that meaning.",
    "Do not output selectors, JavaScript, user values, save/submit/apply/delete/upload actions, or any fields outside the schema.",
    "For duplicate positional date fields, use the provided ordinal and tentative startTime/endTime hint when consistent with the section.",
    "For boolean questions, do not map to a non-boolean canonical field just because labels share words.",
    "Do not map an unlabeled select/cascader to plain phone, email, idNumber, qq, wechat, or homepage based only on a CSS/structural token; country-code and helper selectors are separate controls.",
    "Because resume values and record contents are 示例资料ally absent, do not assume that a generic 示例资料Skills record for 小语种/方言 exists. Prefer leave_unmapped unless a dedicated canonical field represents the requested subtype.",
    "A field asking for one subtype of an array record must not be mapped merely because the category contains a generic name/description field; record identity must be semantically supported.",
    "Keep reason concise and describe only the semantic rationale.",
    "Example JSON shape: {\"schemaType\":\"autofill-lite-ai-semantic-patch\",\"schemaVersion\":1,\"decisions\":[{\"fieldId\":\"fld_example\",\"decision\":\"leave_unmapped\",\"category\":\"\",\"fieldKey\":\"\",\"confidence\":0.8,\"reason\":\"no canonical field\"}]}"
  ].join("\n");
}

function isDeepSeekEndpoint(endpoint) {
  try { return /(^|\.)api\.deepseek\.com$/i.test(new URL(String(endpoint || "")).hostname); }
  catch (_) { return false; }
}

function buildOpenAiResponsesRequest(settings, review, mode, options) {
  const useJsonObject = mode === "json_object";
  const format = useJsonObject ? { type: "json_object" } : {
    type: "json_schema",
    name: "autofill_semantic_patch",
    schema: patchJsonSchema()
  };
  // OpenAI supports strict JSON Schema. DeepSeek's Responses compatibility docs
  // document type/name/schema but do not require a strict flag, so omit it there.
  if (!useJsonObject && !isDeepSeekEndpoint(settings.endpoint)) format.strict = true;
  const payload = {
    model: settings.model,
    input: [
      { role: "system", content: systemPrompt() },
      { role: "user", content: JSON.stringify(review) }
    ],
    store: false,
    max_output_tokens: Number(options && options.maxOutputTokens || settings.maxOutputTokens || 24000),
    text: { format }
  };
  if (settings.reasoningEffort && settings.reasoningEffort !== "none") {
    payload.reasoning = { effort: settings.reasoningEffort };
  }
  return payload;
}

function buildCompatibleChatRequest(settings, review, mode, options) {
  const useJsonObject = mode === "json_object";
  const responseFormat = useJsonObject ? { type: "json_object" } : {
    type: "json_schema",
    json_schema: {
      name: "autofill_semantic_patch",
      strict: true,
      schema: patchJsonSchema()
    }
  };
  if (!useJsonObject && isDeepSeekEndpoint(settings.endpoint)) {
    // DeepSeek Chat Completions documents json_object rather than json_schema.
    return buildCompatibleChatRequest(settings, review, "json_object", options);
  }
  return {
    model: settings.model,
    messages: [
      { role: "system", content: systemPrompt() },
      { role: "user", content: JSON.stringify(review) }
    ],
    max_tokens: Number(options && options.maxOutputTokens || settings.maxOutputTokens || 24000),
    response_format: responseFormat
  };
}

function buildProviderRequest(settings, review, options) {
  if (settings.provider === "openai-compatible-chat") return buildCompatibleChatRequest(settings, review, "schema", options);
  return buildOpenAiResponsesRequest(settings, review, "schema", options);
}

function buildProviderRetryRequest(settings, review, options) {
  if (settings.provider === "openai-compatible-chat") return buildCompatibleChatRequest(settings, review, "json_object", options);
  return buildOpenAiResponsesRequest(settings, review, "json_object", options);
}


function valueCandidateJsonSchema() {
  return {
    type: "object",
    additionalProperties: false,
    required: ["schemaType", "schemaVersion", "decisions"],
    properties: {
      schemaType: { type: "string", enum: ["autofill-lite-ai-value-candidate-patch"] },
      schemaVersion: { type: "integer", enum: [1] },
      decisions: {
        type: "array",
        items: {
          type: "object",
          additionalProperties: false,
          required: ["candidateId", "decision", "value", "mode", "confidence", "sourceFieldKeys", "reason"],
          properties: {
            candidateId: { type: "string" },
            decision: { type: "string", enum: ["candidate", "leave_unmapped"] },
            value: { type: "string" },
            mode: { type: "string", enum: ["extract", "normalize", "synthesize"] },
            confidence: { type: "number" },
            sourceFieldKeys: { type: "array", items: { type: "string" } },
            reason: { type: "string" }
          }
        }
      }
    }
  };
}

function valueCandidateSystemPrompt() {
  return [
    "You are Autofill Lite's candidate-value derivation assistant for job application forms.",
    "You receive only selected, non-sensitive profile facts relevant to fields whose canonical value is currently missing.",
    "Use ONLY the supplied sourceFacts. Never invent employers, dates, scores, achievements, identities, numbers, credentials, or factual claims.",
    "Return ONLY one valid JSON object with schemaType=autofill-lite-ai-value-candidate-patch and schemaVersion=1.",
    "For every target return exactly one decision using its candidateId.",
    "Use mode=extract when the answer is already explicitly contained in sourceFacts.",
    "Use mode=normalize when formatting or deterministic wording normalization is sufficient.",
    "Use mode=synthesize only for conservative rewriting/compression of supplied facts; do not add any new factual content.",
    "If the target cannot be derived solely from sourceFacts, return leave_unmapped with an empty value.",
    "Never decide which 示例资料 record owns a page editor. recordIndex is a locally assigned reference only.",
    "Keep generated text concise and suitable for a resume form; preserve factual meaning.",
    "Do not emit selectors, JavaScript, actions, save/submit/delete/upload instructions, or any extra keys."
  ].join("\n");
}

function buildValueCandidateRequest(settings, valueReview, mode, options) {
  const useJsonObject = mode === "json_object";
  const maxOutputTokens = Number(options && options.maxOutputTokens || settings.maxOutputTokens || 24000);
  if (settings.provider === "openai-compatible-chat") {
    let responseFormat = useJsonObject ? { type: "json_object" } : {
      type: "json_schema",
      json_schema: { name: "autofill_value_candidate_patch", strict: true, schema: valueCandidateJsonSchema() }
    };
    if (!useJsonObject && isDeepSeekEndpoint(settings.endpoint)) responseFormat = { type: "json_object" };
    return {
      model: settings.model,
      messages: [
        { role: "system", content: valueCandidateSystemPrompt() },
        { role: "user", content: JSON.stringify(valueReview) }
      ],
      max_tokens: maxOutputTokens,
      response_format: responseFormat
    };
  }
  const format = useJsonObject ? { type: "json_object" } : {
    type: "json_schema",
    name: "autofill_value_candidate_patch",
    schema: valueCandidateJsonSchema()
  };
  if (!useJsonObject && !isDeepSeekEndpoint(settings.endpoint)) format.strict = true;
  const payload = {
    model: settings.model,
    input: [
      { role: "system", content: valueCandidateSystemPrompt() },
      { role: "user", content: JSON.stringify(valueReview) }
    ],
    store: false,
    max_output_tokens: maxOutputTokens,
    text: { format }
  };
  if (settings.reasoningEffort && settings.reasoningEffort !== "none") payload.reasoning = { effort: settings.reasoningEffort };
  return payload;
}

function validateValueCandidatePatch(valueReview, patch) {
  if (!valueReview || valueReview.schemaType !== "autofill-lite-ai-value-review" || Number(valueReview.schemaVersion) !== 1) {
    throw new Error("AI value review schema 不正确");
  }
  if (!patch || patch.schemaType !== "autofill-lite-ai-value-candidate-patch" || Number(patch.schemaVersion) !== 1 || !Array.isArray(patch.decisions)) {
    throw new Error("AI value candidate patch schema 不正确");
  }
  const targets = new Map((valueReview.targets || []).map((x) => [String(x.candidateId || ""), x]));
  const seen = new Set();
  const decisions = [];
  for (const raw of patch.decisions) {
    const candidateId = String(raw && raw.candidateId || "");
    if (!targets.has(candidateId)) throw new Error("AI value candidate 返回未知 candidateId：" + candidateId);
    if (seen.has(candidateId)) throw new Error("AI value candidate 重复 candidateId：" + candidateId);
    seen.add(candidateId);
    const decision = String(raw && raw.decision || "");
    if (!["candidate", "leave_unmapped"].includes(decision)) throw new Error("AI value candidate decision 非法：" + decision);
    const mode = String(raw && raw.mode || "extract");
    if (!["extract", "normalize", "synthesize"].includes(mode)) throw new Error("AI value candidate mode 非法：" + mode);
    const value = String(raw && raw.value || "").trim().slice(0, 2000);
    if (decision === "candidate" && !value) throw new Error("candidate 决策缺少 value：" + candidateId);
    const confidenceRaw = Number(raw && raw.confidence);
    const confidence = Number.isFinite(confidenceRaw) ? Math.max(0, Math.min(1, confidenceRaw)) : 0;
    const allowedSourceKeys = new Set((targets.get(candidateId).sourceFacts || []).map((x) => String(x.key || "")));
    const sourceFieldKeys = Array.isArray(raw && raw.sourceFieldKeys)
      ? raw.sourceFieldKeys.map(String).filter((x) => allowedSourceKeys.has(x)).slice(0, 12) : [];
    decisions.push({ candidateId, decision, value: decision === "candidate" ? value : "", mode, confidence, sourceFieldKeys, reason: String(raw && raw.reason || "").trim().slice(0, 500), source: "api_value_resolver" });
  }
  for (const candidateId of targets.keys()) {
    if (!seen.has(candidateId)) decisions.push({ candidateId, decision: "leave_unmapped", value: "", mode: "extract", confidence: 0, sourceFieldKeys: [], reason: "model_omitted_target", source: "api_value_resolver" });
  }
  return { schemaType: "autofill-lite-ai-value-candidate-patch", schemaVersion: 1, decisions };
}

function extractOpenAiResponseText(body) {
  if (body && typeof body.output_text === "string" && body.output_text.trim()) return body.output_text.trim();
  const output = Array.isArray(body && body.output) ? body.output : [];
  const chunks = [];
  output.forEach((item) => {
    const content = Array.isArray(item && item.content) ? item.content : [];
    content.forEach((part) => {
      if (part && part.type === "output_text" && typeof part.text === "string") chunks.push(part.text);
      else if (part && typeof part.text === "string" && part.type !== "reasoning_text") chunks.push(part.text);
    });
  });
  return chunks.join("\n").trim();
}

function extractChatResponseText(body) {
  const choice = body && Array.isArray(body.choices) ? body.choices[0] : null;
  const content = choice && choice.message && choice.message.content;
  if (typeof content === "string") return content.trim();
  if (Array.isArray(content)) {
    return content.map((item) => item && (item.text || item.content) || "").filter(Boolean).join("\n").trim();
  }
  return "";
}

function stripMarkdownFence(text) {
  let out = String(text || "").replace(/^\uFEFF/, "").trim();
  const match = out.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  if (match) out = match[1].trim();
  return out;
}

function firstBalancedJsonObject(text) {
  const source = String(text || "");
  let start = -1;
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = 0; i < source.length; i += 1) {
    const ch = source[i];
    if (start < 0) {
      if (ch === "{") { start = i; depth = 1; }
      continue;
    }
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') inString = true;
    else if (ch === "{") depth += 1;
    else if (ch === "}") {
      depth -= 1;
      if (depth === 0) return source.slice(start, i + 1);
    }
  }
  return "";
}

function parseStructuredJsonText(rawText) {
  const cleaned = stripMarkdownFence(rawText);
  if (!cleaned) throw new Error("AI 返回中没有可解析的结构化文本");
  try { return JSON.parse(cleaned); }
  catch (_) {
    const candidate = firstBalancedJsonObject(cleaned);
    if (candidate) {
      try { return JSON.parse(candidate); } catch (_) {}
    }
  }
  throw new Error("AI 返回不是有效 JSON");
}

function providerResponseState(body) {
  const status = String(body && body.status || "").trim();
  const error = body && body.error;
  const incomplete = body && body.incomplete_details;
  if (status === "failed") {
    const message = error && (error.message || error.code) || "provider response failed";
    throw new Error("AI 响应失败：" + String(message).slice(0, 500));
  }
  if (status === "incomplete") {
    const reason = incomplete && incomplete.reason || "unknown";
    throw new Error("AI 响应未完成：" + reason);
  }
}

function parseProviderResponse(provider, body) {
  providerResponseState(body);
  const text = provider === "openai-compatible-chat" ? extractChatResponseText(body) : extractOpenAiResponseText(body);
  return parseStructuredJsonText(text);
}

function responseDebugSummary(provider, body) {
  const text = provider === "openai-compatible-chat" ? extractChatResponseText(body) : extractOpenAiResponseText(body);
  const output = Array.isArray(body && body.output) ? body.output : [];
  const choice = body && Array.isArray(body.choices) ? body.choices[0] : null;
  return {
    status: String(body && body.status || ""),
    responseId: String(body && body.id || ""),
    error: body && body.error ? {
      code: String(body.error.code || ""),
      message: String(body.error.message || "").slice(0, 500)
    } : null,
    incompleteReason: String(body && body.incomplete_details && body.incomplete_details.reason || ""),
    outputItemTypes: output.map((item) => String(item && item.type || "")).slice(0, 20),
    finishReason: String(choice && choice.finish_reason || ""),
    extractedTextLength: text.length,
    extractedTextPreview: text.slice(0, 1800)
  };
}

function validateReview(review) {
  if (!review || review.schemaType !== "autofill-lite-ai-mapping-review-request" || Number(review.schemaVersion) !== 2) {
    throw new Error("当前站点的 AI review 不是 Build49+ v2 格式，请先重新“分析本站”");
  }
  if (!Array.isArray(review.reviewFields)) throw new Error("当前 review 的 reviewFields 格式不正确");
  if (!review.profileContract || !review.profileContract.categories) throw new Error("AI review 缺少 profileContract");
  const ids = new Set();
  review.reviewFields.forEach((field) => {
    const id = String(field && field.fieldId || "");
    if (!id) throw new Error("AI review 存在缺少 fieldId 的字段");
    if (ids.has(id)) throw new Error("AI review 存在重复 fieldId：" + id);
    ids.add(id);
  });
  return review;
}

function validateSemanticPatch(review, patch) {
  validateReview(review);
  if (!patch || patch.schemaType !== "autofill-lite-ai-semantic-patch" || Number(patch.schemaVersion) !== 1) {
    throw new Error("AI 返回的 semantic patch schema 不正确");
  }
  if (!Array.isArray(patch.decisions)) throw new Error("AI 返回缺少 decisions");
  const reviewById = new Map(review.reviewFields.map((field) => [String(field.fieldId), field]));
  const allowed = review.profileContract.categories || {};
  const seen = new Set();
  const normalized = [];

  patch.decisions.forEach((decision) => {
    const fieldId = String(decision && decision.fieldId || "");
    if (!reviewById.has(fieldId)) throw new Error("AI 返回了未知 fieldId：" + fieldId);
    if (seen.has(fieldId)) throw new Error("AI 对同一 fieldId 返回了重复决策：" + fieldId);
    seen.add(fieldId);
    const kind = String(decision && decision.decision || "");
    if (!["map", "leave_unmapped", "needs_special_示例资料flow"].includes(kind)) throw new Error("AI 返回了不允许的 decision：" + kind);
    let category = String(decision && decision.category || "").trim();
    let fieldKey = String(decision && decision.fieldKey || "").trim();
    const confidenceRaw = Number(decision && decision.confidence);
    const confidence = Number.isFinite(confidenceRaw) ? Math.max(0, Math.min(1, confidenceRaw)) : 0;
    const reason = String(decision && decision.reason || "").trim().slice(0, 500);
    if (kind === "map") {
      if (!category || !fieldKey) throw new Error("map 决策必须同时包含 category 与 fieldKey：" + fieldId);
      if (!Array.isArray(allowed[category]) || !allowed[category].includes(fieldKey)) {
        throw new Error(`AI 映射超出 profileContract：${category}.${fieldKey}`);
      }
    } else {
      if (category || fieldKey) throw new Error(kind + " 决策不得携带 category/fieldKey：" + fieldId);
      category = "";
      fieldKey = "";
    }
    normalized.push({ fieldId, decision: kind, category, fieldKey, confidence, reason });
  });

  if (seen.size !== reviewById.size) {
    const missing = Array.from(reviewById.keys()).filter((id) => !seen.has(id));
    throw new Error("AI 未覆盖全部 review 字段：" + missing.slice(0, 6).join(", ") + (missing.length > 6 ? "…" : ""));
  }

  return {
    schemaType: "autofill-lite-ai-semantic-patch",
    schemaVersion: 1,
    decisions: normalized
  };
}

function usageFromResponse(provider, body) {
  const usage = body && body.usage || {};
  if (provider === "openai-compatible-chat") {
    return {
      inputTokens: Number(usage.prompt_tokens || 0),
      outputTokens: Number(usage.completion_tokens || 0),
      totalTokens: Number(usage.total_tokens || 0)
    };
  }
  return {
    inputTokens: Number(usage.input_tokens || 0),
    outputTokens: Number(usage.output_tokens || 0),
    totalTokens: Number(usage.total_tokens || ((usage.input_tokens || 0) + (usage.output_tokens || 0)))
  };
}

function summarizePatch(patch) {
  const out = { mapped: 0, leftUnmapped: 0, needsSpecialWorkflow: 0 };
  (patch && patch.decisions || []).forEach((d) => {
    if (d.decision === "map") out.mapped += 1;
    else if (d.decision === "needs_special_示例资料flow") out.needsSpecialWorkflow += 1;
    else out.leftUnmapped += 1;
  });
  return out;
}

module.exports = {
  patchJsonSchema,
  systemPrompt,
  isDeepSeekEndpoint,
  buildOpenAiResponsesRequest,
  buildCompatibleChatRequest,
  buildProviderRequest,
  buildProviderRetryRequest,
  valueCandidateJsonSchema,
  valueCandidateSystemPrompt,
  buildValueCandidateRequest,
  validateValueCandidatePatch,
  extractOpenAiResponseText,
  extractChatResponseText,
  parseStructuredJsonText,
  parseProviderResponse,
  responseDebugSummary,
  validateReview,
  validateSemanticPatch,
  usageFromResponse,
  summarizePatch
};
