(function () {
  "use strict";

  window.AF = window.AF || {};
  window.AF.Runtime = window.AF.Runtime || {};
  window.AF.Runtime.isElectronAutofill = true;
  window.__OFFER_ELECTRON_AUTOFILL__ = true;

  if (!window.chrome) window.chrome = {};
  if (!window.chrome.runtime) {
    window.chrome.runtime = {
      lastError: null,
      getURL: function (path) { return String(path || ""); }
    };
  } else if (typeof window.chrome.runtime.getURL !== "function") {
    window.chrome.runtime.getURL = function (path) { return String(path || ""); };
  }
  // Electron/Chromium 某些版本会预置一个不可用的 runtime.sendMessage。
  // 不能只在函数缺失时安装桥，否则可信输入请求会被这个空实现吞掉。
  var nativeSendMessage = typeof window.chrome.runtime.sendMessage === "function"
    ? window.chrome.runtime.sendMessage.bind(window.chrome.runtime)
    : null;
  var electronSendMessage = function (message, callback) {
      try { window.chrome.runtime.lastError = null; } catch (_) {}
      var response = { success: false, ignored: true };
      if (message && message.action === "ensureAntMainBridge") {
        response = { success: true, electron: true };
        if (typeof callback === "function") setTimeout(function () { callback(response); }, 0);
        return;
      }
      if (message && (message.action === "trustedElementAutocomplete" || message.action === "trustedTextInput")) {
        var requestId = "offer_trusted_autocomplete_" + Date.now() + "_" + Math.random().toString(16).slice(2);
        var requestNode = document.createElement("span");
        var completed = false;
        var pollTimer = null;
        var timeoutTimer = null;

        function finish(result) {
          if (completed) return;
          completed = true;
          if (pollTimer) clearInterval(pollTimer);
          if (timeoutTimer) clearTimeout(timeoutTimer);
          document.removeEventListener("offer-trusted-autocomplete-response", onResponse, true);
          try { requestNode.remove(); } catch (_) {}
          if (typeof callback === "function") callback(result || { success: false, error: "EMPTY_BRIDGE_RESPONSE" });
        }

        function readResponse() {
          var raw = requestNode.getAttribute("data-response");
          if (!raw) return null;
          try { return JSON.parse(raw); } catch (_) { return { success: false, error: "INVALID_BRIDGE_RESPONSE" }; }
        }

        function onResponse(event) {
          if (event && event.target !== requestNode) return;
          var result = readResponse();
          if (result) finish(result);
        }

        requestNode.hidden = true;
        requestNode.setAttribute("data-offer-trusted-autocomplete-request", requestId);
        requestNode.setAttribute("data-request", JSON.stringify(message));
        (document.documentElement || document.body || document).appendChild(requestNode);
        document.addEventListener("offer-trusted-autocomplete-response", onResponse, true);
        pollTimer = setInterval(function () {
          var result = readResponse();
          if (result) finish(result);
        }, 50);
        timeoutTimer = setTimeout(function () {
          finish({ success: false, error: "ELECTRON_TRUSTED_INPUT_TIMEOUT" });
        }, message.action === "trustedTextInput"
          ? 5000
          : Math.max(8000, Number(message.optionTimeoutMs || 0) + 5000));
        requestNode.dispatchEvent(new Event("offer-trusted-autocomplete-request", { bubbles: true }));
        return;
      }
      if (nativeSendMessage) {
        try { return nativeSendMessage(message, callback); } catch (_) {}
      }
      if (typeof callback === "function") setTimeout(function () { callback(response); }, 0);
    };
  try {
    Object.defineProperty(window.chrome.runtime, "sendMessage", {
      configurable: true,
      writable: true,
      value: electronSendMessage
    });
  } catch (_) {
    try { window.chrome.runtime.sendMessage = electronSendMessage; } catch (_) {}
  }

  if (!window.chrome.storage) window.chrome.storage = {};
  if (!window.chrome.storage.local) {
    var PREFIX = "__offer_autofill_storage__";

    function readAll() {
      try {
        return JSON.parse(window.localStorage.getItem(PREFIX) || "{}") || {};
      } catch (_) {
        return {};
      }
    }

    function writeAll(next) {
      try {
        window.localStorage.setItem(PREFIX, JSON.stringify(next || {}));
      } catch (_) {}
    }

    window.chrome.storage.local = {
      get: function (keys, callback) {
        var all = readAll();
        var result = {};
        if (keys === null || keys === undefined) {
          result = all;
        } else if (Array.isArray(keys)) {
          keys.forEach(function (key) {
            if (Object.prototype.hasOwnProperty.call(all, key)) result[key] = all[key];
          });
        } else if (typeof keys === "string") {
          if (Object.prototype.hasOwnProperty.call(all, keys)) result[keys] = all[keys];
        } else if (typeof keys === "object") {
          Object.keys(keys).forEach(function (key) {
            result[key] = Object.prototype.hasOwnProperty.call(all, key) ? all[key] : keys[key];
          });
        }
        if (typeof callback === "function") setTimeout(function () { callback(result); }, 0);
      },
      set: function (obj, callback) {
        var all = readAll();
        Object.keys(obj || {}).forEach(function (key) { all[key] = obj[key]; });
        writeAll(all);
        if (typeof callback === "function") setTimeout(callback, 0);
      },
      remove: function (keys, callback) {
        var all = readAll();
        (Array.isArray(keys) ? keys : [keys]).forEach(function (key) { delete all[key]; });
        writeAll(all);
        if (typeof callback === "function") setTimeout(callback, 0);
      }
    };
  }
})();
