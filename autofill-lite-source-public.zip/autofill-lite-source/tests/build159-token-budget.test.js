"use strict";
const assert = require("assert");
const { userCeiling, semanticTokenBudget, valueTokenBudget } = require("../ai-token-budget");

assert.strictEqual(userCeiling({}), 24000, "default user ceiling should be 24k");
assert.strictEqual(userCeiling({ maxOutputTokens: 100000 }), 64000, "hard ceiling should be 64k");
assert.strictEqual(userCeiling({ maxOutputTokens: 1000 }), 4000, "minimum ceiling should be 4k");
const small = semanticTokenBudget({ reviewFields: new Array(3).fill({}) }, { maxOutputTokens: 24000 });
const large = semanticTokenBudget({ reviewFields: new Array(60).fill({}) }, { maxOutputTokens: 24000 });
assert(small >= 4000 && small < large, "semantic budget should grow with page complexity");
assert(large <= 24000, "semantic budget must honor user ceiling");
assert.strictEqual(semanticTokenBudget({ reviewFields: new Array(300).fill({}) }, { maxOutputTokens: 64000 }), 48000, "semantic phase should cap at 48k");
const vSmall = valueTokenBudget({ targets: new Array(2).fill({}) }, { maxOutputTokens: 24000 });
const vLarge = valueTokenBudget({ targets: new Array(100).fill({}) }, { maxOutputTokens: 64000 });
assert(vSmall >= 3000 && vSmall < vLarge, "value budget should grow with target count");
assert.strictEqual(vLarge, 24000, "value phase should cap at 24k");
console.log("build159-token-budget.test.js PASS");
