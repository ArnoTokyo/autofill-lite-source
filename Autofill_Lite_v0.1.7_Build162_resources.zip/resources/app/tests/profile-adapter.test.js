"use strict";
const assert = require("assert");
const path = require("path");
const { normalizeProfileBackup, loadProfile } = require("../profile-adapter");
const raw = { profileV2: { sections: {
  basic: { values: { "姓名":"测试用户", "电话":"13800000000", "政治面貌":"共青团员", "最高学历":"硕士" } },
  intention: { items: [
    { values: { "意向岗位":"财务", "期望薪资":"1.2万/月", "期望工作城市":"广州、深圳、北京、重庆", "是否接受调剂":"是" } },
    { values: { "意向岗位":"管培生", "期望薪资":"1.5万/月", "期望工作城市":"广州、深圳、北京、重庆", "是否接受调剂":"是" } }
  ] },
  education: { items: [
    { values: { "学校":"某高中", "学历":"高中", "结束时间":"2021-06" } },
    { values: { "学校":"某大学", "学历":"本科", "学位":"学士", "专业":"财政学", "绩点制":"四分制", "学制":"四年制", "个人绩点":"3.23", "年级排名":"其他", "班级排名":"其他", "是否贯通式培养":"非贯通式培养", "是否有国外、港澳台地区学习经历":"否", "开始时间":"2021-09", "结束时间":"2025-06" } },
    { values: { "学校":"某大学", "学历":"硕士", "学位":"硕士", "专业":"金融", "学位类型":"专业型", "绩点制":"四分制", "研究方向":"证券投资与金融管理", "学制":"两年制", "个人绩点":"3.61", "年级排名":"其他", "班级排名":"其他", "是否贯通式培养":"非贯通式培养", "是否有国外、港澳台地区学习经历":"否", "开始时间":"2025-09", "结束时间":"2027-06" } }
  ] },
  internship: { items: [] }, project: { items: [] },
  student: { items: [{ values: {
    "组织名称":"示例研究生会", "职位":"干事", "开始时间":"2025-09", "结束时间":"2026-04",
    "开始日期":"2025-09-01", "结束日期":"2026-04-30", "本人职责":"负责示例职责"
  } }] },
  awards: { items: [{ values: {
    "奖惩名称":"示例奖学金", "奖惩时间":"2024-12", "奖惩日期":"2024-12-24", "奖励等级":"校级"
  } }] },
  language: { items: [{ values: {
    "外语种类":"英语",
    "证书名称（技能名称）":"雅思",
    "成绩":"6.5",
    "CET4成绩":"616",
    "CET6成绩":"532",
    "其他英语等级考试":"IELTS",
    "其他英语等级考试成绩":"6.5"
  } }] },
  family: { items: [] },
  self: { values: { "自我评价":"测试自评" } }, declarations: { values: { "是否同意背景调查":"是" } }, other: { values:{} }
} } };
const out = normalizeProfileBackup(raw);
assert.strictEqual(out.basicInfo.name, "测试用户");
assert.strictEqual(out.basicInfo.highestDegree, "硕士");
assert.strictEqual(out.education.length, 2);
assert.strictEqual(out.education[0].level, "硕士");
assert.strictEqual(out.education[0].startTime, "2025-09-01");
assert.strictEqual(out.education[0].endTime, "2027-06-30");
assert.strictEqual(out.education[0].majorCategory, "经济学");
assert.strictEqual(out.education[0].schoolAffiliation, "国内高校");
assert.strictEqual(out.education[0].researchDirection, "证券投资与金融管理");
assert.strictEqual(out.education[1].majorCategory, "经济学");
assert.strictEqual(out.education[1].schoolAffiliation, "国内高校");
assert.strictEqual(out.education[1].startTime, "2021-09-01");
assert.strictEqual(out.education[1].endTime, "2025-06-30");
assert.strictEqual(out.education[0].studyLength, "两年制");
assert.strictEqual(out.education[0].gpa, "3.61");
assert.strictEqual(out.education[0].rank, "其他");
assert.strictEqual(out.education[0].cohortRank, "其他");
assert.strictEqual(out.education[0].integratedTraining, "非贯通式培养");
assert.strictEqual(out.education[0].hasOverseasStudy, "否");
assert.strictEqual(out.education[0].gradePointType, "四分制");
assert.strictEqual(out.education[0].degreeType, "专业型");
assert.strictEqual(out.education[0].degreeSimple, "硕士");
assert.strictEqual(out.education[0].degreeDetailed, "经济学硕士");
assert.strictEqual(out.education[1].degreeSimple, "学士");
assert.strictEqual(out.education[1].degreeDetailed, "经济学学士");
assert.strictEqual(out.education[0].majorDirection, "证券投资与金融管理");
assert.strictEqual(out.education[0].isHighestEducation, "是");
assert.strictEqual(out.education[0].isHighestDegree, "是");
assert.strictEqual(out.education[0].isFirstEducation, "否");
assert.strictEqual(out.education[1].studyLength, "四年制");
assert.strictEqual(out.education[1].gpa, "3.23");
assert.strictEqual(out.education[1].rank, "其他");
assert.strictEqual(out.education[1].cohortRank, "其他");
assert.strictEqual(out.education[1].gradePointType, "四分制");
assert.strictEqual(out.education[1].isHighestEducation, "否");
assert.strictEqual(out.education[1].isHighestDegree, "否");
assert.strictEqual(out.education[1].isFirstEducation, "是");

assert.strictEqual(out.basicInfo.graduationDate, "2027-06-30");
assert.strictEqual(out.jobIntention.position, "财务");
assert.strictEqual(out.jobIntention.expectedPosition, "财务");
assert.strictEqual(out.jobIntention.salary, "1.2万/月");
assert.strictEqual(out.jobIntention.expectedSalary, "1.2万/月");
assert.deepStrictEqual(out.jobIntention.positionOptions, ["财务", "管培生"]);
assert.deepStrictEqual(out.jobIntention.salaryOptions, ["1.2万/月", "1.5万/月"]);
assert.strictEqual(out.jobIntention.intentions.length, 2);
assert.strictEqual(out.basicInfo.expectedPosition, "财务");
assert.strictEqual(out.basicInfo.expectedSalary, "1.2万/月");
assert.strictEqual(out.languageSkills.length, 1);
assert.strictEqual(out.languageSkills[0].cet4Score, "616");
assert.strictEqual(out.languageSkills[0].cet6Score, "532");
assert.strictEqual(out.languageSkills[0].otherEnglishExam, "IELTS");
assert.strictEqual(out.languageSkills[0].otherEnglishScore, "6.5");
assert.strictEqual(out.languageSkills[0].ieltsScore, "6.5");

assert.strictEqual(out.campusLeadership.length, 1);
assert.strictEqual(out.campusLeadership[0].startTime, "2025-09");
assert.strictEqual(out.campusLeadership[0].startDate, "2025-09-01");
assert.strictEqual(out.campusLeadership[0].endDate, "2026-04-30");
assert.strictEqual(out.campusLeadership[0].roleDescription, "负责示例职责");
assert.strictEqual(out.awards.length, 1);
assert.strictEqual(out.awards[0].awardTime, "2024-12");
assert.strictEqual(out.awards[0].awardDate, "2024-12-24");
assert.strictEqual(out.selfIntroduction.selfIntroduction, "测试自评");
assert.ok(!Object.prototype.hasOwnProperty.call(out, "declarations"));
// Build 36 regression: the user-approved CDB Learning Committee Member wording
// is persisted in the canonical default profile and stays within the site's
// 50-character 职务描述 limit.
const defaultProfile = loadProfile(path.join(__dirname, "..", "defaults", "candidate-profile-merged.json"));
assert.strictEqual(defaultProfile.education[0].degreeDetailed, "经济学硕士");
assert.strictEqual(defaultProfile.education[0].degreeSimple, "硕士");
assert.strictEqual(defaultProfile.education[1].degreeDetailed, "经济学学士");
assert.strictEqual(defaultProfile.education[1].degreeSimple, "学士");
const learningCommittee = defaultProfile.campusLeadership.find((row) => row.title === "学习委员");
assert(learningCommittee, "canonical profile should contain the Learning Committee Member row");
assert.strictEqual(learningCommittee.description, "对接教务处，完成学校及学院任务，上报学生学习方面的合理诉求，并提供升学、学习和毕业信息指引。");
assert(learningCommittee.description.length <= 50, "Learning Committee Member description must fit the CDB 50-character limit");

console.log("profile-adapter tests: PASS");
