const fs = require('fs');
const path = require('path');
const assert = require('assert');
const vm = require('vm');

const root = path.join(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

const templates = read('autofill-plugin/content/config/site-templates.js');
assert(templates.includes('fieldKey: "position", labels: ["期望从事职业", "期望职位", "目标岗位"]'), 'Phoenix expected-position capability missing');
assert(templates.includes('genericPortalFallback: true, searchWhenEmpty: true'), 'Phoenix expected-position generic portal fallback missing');
assert(templates.includes('fieldKey: "salary"') && templates.includes('preserveSlashValue: true, genericPortalFallback: true'), 'Phoenix salary generic fallback missing');

const phoenix = read('autofill-plugin/content/select-adapter/adapters/phoenix.js');
assert(phoenix.includes('findPhoenixGenericPanel'), 'generic Phoenix portal detection missing');
assert(phoenix.includes('selectPhoenixGenericPortal'), 'generic Phoenix portal selection missing');
assert(phoenix.includes('capability.genericPortalFallback === true'), 'generic fallback capability gate missing');
assert(phoenix.includes('trace.genericOptionCount'), 'safe generic portal trace missing');
assert(phoenix.includes('resultStage'), 'Phoenix trace result stage missing');
assert(phoenix.includes('[class*="item-name" i]'), 'taxonomy item-name fallback selector missing');

const utils = read('autofill-plugin/content/utils.js');
const fnMatch = utils.match(/function normalizeNumericPunctuation\(value\) \{[\s\S]*?\n  \}/);
assert(fnMatch, 'numeric punctuation normalizer missing');
const context = {};
vm.createContext(context);
vm.runInContext(fnMatch[0] + '\nthis.normalizeNumericPunctuation = normalizeNumericPunctuation;', context);
assert.strictEqual(context.normalizeNumericPunctuation('15,000元/月'), '15000元/月');
assert.strictEqual(context.normalizeNumericPunctuation('10，000-20，000元/月'), '10000-20000元/月');
assert.strictEqual(context.normalizeNumericPunctuation('1,2,3'), '1,2,3', 'list commas must not be collapsed as thousands punctuation');
assert(utils.includes('parseOptionRange: function (e) {\n      var r = normalizeNumericPunctuation(e)'), 'range matcher must normalize thousands punctuation');
assert(utils.includes('extractComparableValue: function (e) {\n      var r = normalizeNumericPunctuation(e)'), 'comparable salary value must normalize thousands punctuation');

console.log('mature-phoenix-generic-choice: ok');
