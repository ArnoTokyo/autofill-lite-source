"use strict";

function clampInt(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.round(n)));
}

function userCeiling(settings) {
  return clampInt(settings && settings.maxOutputTokens, 4000, 64000, 24000);
}

function semanticTokenBudget(review, settings) {
  const fields = Array.isArray(review && review.reviewFields) ? review.reviewFields.length : 0;
  // A semantic decision is compact JSON, but large campus forms can easily expose
  // dozens of unresolved fields. Grow with page complexity instead of using one
  // fixed 8k ceiling, while still staying below the user's configured hard limit.
  const estimated = 4000 + fields * 320;
  return Math.min(userCeiling(settings), clampInt(estimated, 4000, 48000, 8000));
}

function valueTokenBudget(valueReview, settings) {
  const targets = Array.isArray(valueReview && valueReview.targets) ? valueReview.targets.length : 0;
  const estimated = 3000 + targets * 300;
  return Math.min(userCeiling(settings), clampInt(estimated, 3000, 24000, 6000));
}

module.exports = {
  clampInt,
  userCeiling,
  semanticTokenBudget,
  valueTokenBudget
};
