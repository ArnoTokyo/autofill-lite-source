"use strict";
const fs = require("fs");
const path = require("path");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const workflow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-workflow.js"), "utf8");
const core = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-core.js"), "utf8");
const sites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
const renderer = fs.readFileSync(path.join(root, "renderer.js"), "utf8");

assert(/const BUILD_ID = "\d{8}-[^"]+-\d+";/.test(main), "A: numeric Build id missing");
assert(core.includes('RECOVERY_CHECKPOINT_STORAGE_KEY = "offerAutofillRecoveryCheckpointV2"'), "B: V2 recovery checkpoint key missing");
assert(core.includes('acknowledgeOnRerun: true'), "B: rerun acknowledgement marker missing");
assert(workflow.includes('entry.originalIndex > recoveryResumeRepeatIndex'), "C: repeat recovery must continue after manually handled record");
assert(workflow.includes('Number(recoveryPlanPosition.planIndex) +'), "C: non-repeat recovery must advance past manually handled step using resolved plan position");
assert(workflow.includes('manualResumeResolvedStepIndex = storedStepIndex'), "D: manual gate must treat rerun as user acknowledgement");
assert(!workflow.includes('checkpointResolved = storedStep.manualCheckpointResolvedWhen'), "D: runtime must not second-guess manual checkpoint completion");
assert(sites.includes('result.bankcommBocmCommitment = true'), "E: Bankcomm commitment value missing");
assert(sites.includes('type: "bankcommCommitmentCheckboxes"'), "E: Bankcomm commitment fieldSequence missing");
assert(sites.includes('requiredCount: 2'), "E: both Bankcomm commitment boxes must be required");
assert(workflow.includes('function fillBankcommCommitmentCheckboxes'), "F: Bankcomm commitment executor missing");
assert(workflow.includes('text.indexOf("本人承诺")'), "F: commitment executor must bind by local commitment text");
assert(workflow.includes('checkedCount >= requiredCount'), "F: commitment executor must verify both checkboxes");
assert(renderer.includes('手动处理后再次运行会从后续内容继续'), "G: renderer recovery wording not updated");
console.log("checkpoint-user-ack-bankcomm-commitment.test.js passed (A-G)");
