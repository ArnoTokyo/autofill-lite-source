"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const sites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
const 示例资料flow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-示例资料flow.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");

const documentStub = { body: null, querySelector: () => null, documentElement: { setAttribute() {} } };
const windowStub = {
  AF: {},
  location: { href: "https://job.bankcomm.com/", hostname: "job.bankcomm.com", pathname: "/" },
  getComputedStyle: () => ({ display: "block", visibility: "visible" })
};
const context = { window: windowStub, document: documentStub, URL, console, setTimeout, clearTimeout };
vm.createContext(context);
vm.runInContext(sites, context);
const api = windowStub.AF.PrivateSpecialSites._test;
assert(api && typeof api.bankcommEducationCardTextMatchesRow === "function", "A: 示例资料 identity hook missing");

const bachelor = {
  school: "示例资料",
  level: "本科",
  startTime: "示例资料-01",
  endTime: "示例资料-30"
};
const master = {
  school: "示例资料",
  level: "硕士",
  startTime: "示例资料",
  endTime: "示例资料-30"
};
const bachelorCard = "示例资料 示例资料-01~示例资料-30 本科 财政学";
const masterCard = "示例资料 示例资料~示例资料-30 硕士研究生 金融学";

assert(api.bankcommEducationCardTextMatchesRow(bachelor, bachelorCard) === true,
  "A: bachelor must match its own saved card");
assert(api.bankcommEducationCardTextMatchesRow(master, masterCard) === true,
  "B: master must match its own saved card");
assert(api.bankcommEducationCardTextMatchesRow(master, bachelorCard) === false,
  "C: same-school master must never match bachelor card");
assert(api.bankcommEducationCardTextMatchesRow(bachelor, masterCard) === false,
  "D: same-school bachelor must never match master card");

assert(sites.includes("waitForRepeatEditorCloseInRoot: true"),
  "E: Bankcomm 示例资料 must require root-level editor close barrier");
assert(sites.includes("reuseDirtyRepeatEditor: false"),
  "E: Bankcomm 示例资料 must refuse reusing an unsaved previous editor");
assert(示例资料flow.includes("step.waitForRepeatEditorCloseInRoot === true"),
  "F: runtime save barrier implementation missing");
assert(示例资料flow.includes("liveRepeatRoot"),
  "F: save barrier must re-query the live 示例资料 root after React redraw");

const buildMatch = main.match(/const BUILD_ID = "([^"]+)"/);
assert(buildMatch && /-\d+$/.test(buildMatch[1]), "G: current Build ID missing");
console.log("bankcomm-示例资料-ownership-barrier.test.js passed (A-G)");
