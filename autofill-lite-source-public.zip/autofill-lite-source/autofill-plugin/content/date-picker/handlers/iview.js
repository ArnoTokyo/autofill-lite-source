// content/date-picker/handlers/iview.js — iView 日期选择器 (.ivu-date-picker)
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   工厂分支 Kn.create() case "ivu": 行 46035-46036 (只有一个子类 bo，字符串/对象都由它处理)
//   bo.setValue: 行 47707-47793 (调用 _n())
//   _n()/jn() (打开面板+调用通用导航器 w()): 行 44568-44622 — 选择器已核实
//
// 重要偏差说明: 源码里 _n() 传给通用导航器 w() 的"年份格子选择器"和"日期格子选择器"是同一个
// `.ivu-date-picker-cells-cell`（day 格子），且没有配单独的年份列表/月份列表面板。通用导航器 w()
// 的第一阶段固定会先按"年份格子"去匹配文本里的4位数年份——但 day 格子文案只是"1"/"2"/"31"这种数字，
// 永远匹配不到年份，也解析不出边界年份，导致这条路径在源码里几乎必然直接失败 (return false)。
// 这看起来是原实现的一个缺陷/未覆盖到的边界情况。为了让 iView 日期选择器真正可用（验收标准里
// 明确要求"iView 日期选择器能选日期"），这里改用 iView 真实、可验证的交互方式重建：
// 读取 .ivu-date-picker-header-label 文案得到当前年月 -> 与目标年月不一致就点前进/后退箭头
// -> 一致后再从 cells 里按数字文本点击目标日期。选择器全部沿用源码里核实过的真实 class 名。
// // 简化重建: 未在源码中定位到能正常工作的逐行对应实现，基于该UI框架公开的DOM结构重建
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  var HEADER_SEL = '.ivu-date-picker-header-label:not([style*="display: none"])';
  var CELL_SEL = '.ivu-date-picker-cells:not([style*="display: none"]) .ivu-date-picker-cells-cell';
  var NEXT_SEL = ".ivu-icon-ios-arrow-forward, .ivu-icon-ios-arrow-right";
  var PREV_SEL = ".ivu-icon-ios-arrow-back, .ivu-icon-ios-arrow-left";

  function parseHeaderYearMonth(text) {
    var m = String(text || "").match(/(\d{4})\D+(\d{1,2})/);
    return m ? { year: parseInt(m[1], 10), month: parseInt(m[2], 10) } : null;
  }

  async function navigateIviewPanel(container, targetYear, targetMonth, targetDay) {
    for (var i = 0; i < 36; i++) {
      var headerEl = container.querySelector(HEADER_SEL);
      if (!headerEl) return false;
      var cur = parseHeaderYearMonth(headerEl.textContent);
      if (!cur) return false;
      if (cur.year === targetYear && cur.month === targetMonth) break;
      var forward = cur.year * 12 + cur.month < targetYear * 12 + targetMonth;
      var btn = container.querySelector(forward ? NEXT_SEL : PREV_SEL);
      if (!btn) return false;
      btn.click();
      await AF.Utils.sleep(200);
    }
    if (targetDay == null) return true;
    var cells = container.querySelectorAll(CELL_SEL);
    var matches = Array.from(cells).filter(function (c) { return parseInt(c.textContent.trim(), 10) === targetDay; });
    if (!matches.length) return false;
    await AF.DomUtils.safeClickElement(matches[0]);
    await AF.Utils.sleep(200);
    return true;
  }

  async function iviewSingleNavigate(triggerEl, dateStr) {
    triggerEl.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    triggerEl.dispatchEvent(new MouseEvent("focus", { bubbles: true }));
    await AF.Utils.sleep(10);
    var container = AF.DomUtils.findClosestAncestorWithClass(triggerEl, "ivu-date-picker");
    if (!container) throw new Error("iView date picker container not found");
    var dropdown = await AF.Utils.waitForElement(function () {
      return container.querySelector('.ivu-select-dropdown:not([style*="display: none"])');
    }, 1000);
    if (!dropdown) throw new Error("iView date picker dropdown not found or not visible");
    var parsed = AF.DatePicker._parseDateValue(dateStr) || (function () {
      var parts = dateStr.split("-").map(function (n) { return parseInt(n, 10); });
      return { year: parts[0], month: parts[1], day: parts[2] };
    })();
    var ok = await navigateIviewPanel(dropdown, parsed.year, parsed.month, parsed.day);
    if (!ok) throw new Error("iView date picker navigation failed");
    return true;
  }

  AF.DatePicker._registry["ivu"] = function (element, valueType) {
    return {
      setValue: async function (value) {
        try {
          if (!value) throw new Error("日期为空");
          if (typeof value === "string" || valueType === "string") {
            return await iviewSingleNavigate(element, value);
          }
          if (typeof value !== "object" || !("startTime" in value) || !("endTime" in value)) {
            throw new Error("dateValue必须包含startTime和endTime属性");
          }
          await iviewSingleNavigate(element, value.startTime);
          await AF.Utils.sleep(500);
          var candidates = AF.DomUtils.findSimilarElements(element, 4, { sameTag: true, sameClass: true, sameParent: false });
          if (candidates.length > 0) {
            var best = AF.DatePicker._pickEndDateCandidate(element, candidates);
            await iviewSingleNavigate(best, value.endTime);
          } else {
            var surrounding = AF.DomUtils.findSurroundingInputs(element);
            if (surrounding.length > 0) await iviewSingleNavigate(surrounding[0], value.endTime);
          }
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
