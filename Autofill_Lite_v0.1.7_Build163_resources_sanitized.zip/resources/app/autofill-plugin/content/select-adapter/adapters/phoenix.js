// content/select-adapter/adapters/phoenix.js — Phoenix UI (人保 PICC, .phoenix-select) 适配器
// 源码参考 (webcrack-output/content/deobfuscated.js, 模块6118):
//   PhoenixSelectAdapter (混淆名 ft):             行 22551-22668
//   openPhoenixPanel (混淆名 G/B):                 行 21558-21611 (点 trigger -> 轮询等
//     .common-unmodeled-layer:not(.common-unmodeled-layer-hidden) 或 .phoenix-selectList 出现)
//   findTopmostLayer (混淆名 M):                   行 21533-21557 (按 data-nc-id 或最大 z-index 取层)
//   triggerPhoenixFlatList (混淆名 X/Q):            行 22029-22101 (单选平铺列表)
//   triggerPhoenixCheckboxMultiSelect (混淆名 tt/et): 行 22102-约22260 (复选框多选列表)
//   triggerPhoenixAreaCascade / triggerPhoenixCascader: 行21947-22028 / 行22261-22290
//
// 改造点: 原版 setValue 里还包含专业字段特判 (ut/ct) 与省市区级联路径解析
// (isInProvinceCity / buildProvinceCityPath / normalizeLocationPath，属于地址数据子系统，
// 不在下拉适配器职责范围)。这里保留了通用骨架：开面板 -> 判断是复选框多选还是平铺单选列表 ->
// 匹配点击 -> 点确认按钮。value 为数组时按"级联路径/多选"两种语义都尝试处理。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};
  var H = SA._helpers;
  var CFG = SA._config.phoenix;
  var LAYER_SELECTOR = CFG.layer; // .common-unmodeled-layer:not(.common-unmodeled-layer-hidden)
  var LIST_CONTAINER_SELECTOR = CFG.listContainer || ".list-data-container, .area-data-container, .phoenix-selectList";
  var LIST_ITEM_SELECTOR = CFG.cascaderOption || ".list-item-container, .area-item-name, .phoenix-selectList__listItem";

  function phoenixFieldLabel(element, capability) {
    try {
      var row = element && element.closest && element.closest(".form-item, [class*='form-item']");
      var label = row && row.querySelector && row.querySelector(".form-item__text, label, [class*='label']");
      var text = String(label && label.textContent || "").replace(/\s+/g, " ").trim();
      if (!text && capability) {
        var labels = Array.isArray(capability.labels) ? capability.labels : [capability.label];
        text = String(labels.filter(Boolean)[0] || "").trim();
      }
      return text.slice(0, 80);
    } catch (e) {
      return "";
    }
  }

  function writePhoenixTrace(record) {
    try {
      var root = document.documentElement;
      var existing = [];
      try { existing = JSON.parse(root.getAttribute("data-af-phoenix-select-trace") || "[]"); } catch (e) { existing = []; }
      if (!Array.isArray(existing)) existing = [];
      existing.push(record || {});
      if (existing.length > 30) existing = existing.slice(existing.length - 30);
      root.setAttribute("data-af-phoenix-select-trace", JSON.stringify(existing));
    } catch (e) {}
  }

  function dispatchMouseSequence(element) {
    if (!element) return false;
    try {
      ["mousedown", "mouseup", "click"].forEach(function (eventName) {
        element.dispatchEvent(new MouseEvent(eventName, { bubbles: true, cancelable: true }));
      });
      return true;
    } catch (e) {
      try {
        element.click();
        return true;
      } catch (err) {
        return false;
      }
    }
  }

  // 源码 M(t): 按 data-nc-id 精确匹配层，否则取 z-index 最大的可见层 (行21533-21557)
  function findTopmostLayer(trigger) {
    var layers = Array.prototype.slice.call(document.querySelectorAll(LAYER_SELECTOR)).filter(AF.DomUtils.isElementVisible);
    if (layers.length === 0) return null;
    var ncId =
      (trigger && trigger.getAttribute && trigger.getAttribute("data-nc-id")) ||
      (trigger && trigger.closest && trigger.closest(CFG.container) && trigger.closest(CFG.container).getAttribute("data-nc-id"));
    if (ncId) {
      var byId = layers.find(function (layer) {
        return layer.getAttribute("data-nc-input-id") === ncId;
      });
      if (byId) return byId;
    }
    return layers.reduce(function (best, cur) {
      var curZ = parseInt(window.getComputedStyle(cur).zIndex || "0", 10);
      var bestZ = best ? parseInt(window.getComputedStyle(best).zIndex || "0", 10) : -1;
      return curZ >= bestZ ? cur : best;
    }, null);
  }

  // 源码 G/B: 点击 trigger 展开面板，轮询等待层或 .phoenix-selectList 出现 (行21558-21611)
  async function openPhoenixPanel(element) {
    var container = element.closest(CFG.container) || element;
    var trigger = container.querySelector(CFG.trigger) || container;
    trigger.focus && trigger.focus();
    await AF.DomUtils.safeClickElement(trigger);
    await AF.Utils.sleep(200);

    var layer = await AF.Utils.waitForElement(function () {
      return findTopmostLayer(trigger) || (AF.DomUtils.isElementVisible(document.querySelector(".phoenix-selectList")) ? document.querySelector(".phoenix-selectList") : null);
    }, 1500);

    var listContainer = layer && (layer.matches && layer.matches(LIST_CONTAINER_SELECTOR) ? layer : layer.querySelector(LIST_CONTAINER_SELECTOR));
    listContainer = listContainer || document.querySelector(LIST_CONTAINER_SELECTOR);
    return { trigger: trigger, layer: layer, listContainer: listContainer };
  }

  function findPhoenixGenericPanel(trigger, knownLayer) {
    try {
      if (knownLayer && AF.DomUtils.isElementVisible(knownLayer)) return knownLayer;
      if (H && H.findVisibleDropdownNear && H.GENERIC_DROPDOWN_SELECTOR) {
        return H.findVisibleDropdownNear(trigger, H.GENERIC_DROPDOWN_SELECTOR, CFG.container);
      }
    } catch (e) {}
    return null;
  }

  function getPhoenixGenericOptions(scope) {
    try {
      var root = scope || document;
      var nodes = H && H.getOptionNodes ? H.getOptionNodes(root, H.GENERIC_OPTION_SELECTOR) : [];
      var extraSelector = '[role="option"], [data-value], [class*="option" i], [class*="item-name" i], [class*="itemName"], [class*="node-name" i], [class*="nodeName"]';
      try {
        Array.prototype.slice.call(root.querySelectorAll(extraSelector)).forEach(function (node) {
          if (nodes.indexOf(node) === -1 && AF.DomUtils.isElementVisible(node)) nodes.push(node);
        });
      } catch (e) {}
      return (nodes || []).filter(function (node, index, arr) {
        if (!node || arr.indexOf(node) !== index) return false;
        var text = String(node.textContent || node.getAttribute && (node.getAttribute("title") || node.getAttribute("data-value")) || "").replace(/\s+/g, " ").trim();
        if (!text || text.length > 120) return false;
        // Prefer leaf-ish option nodes and avoid selecting the whole popup/container.
        var childOption = node.querySelector && node.querySelector('[role="option"], [data-value], li, .option, .dropdown-item, .select-item');
        return !childOption || childOption === node;
      });
    } catch (e) {
      return [];
    }
  }


  // Patch112: Phoenix 多值/薪资字段增强。
  // 适用于 beisen-phoenix 中没有标准 option，但通过 portal 动态渲染的字段。
  async function selectPhoenixPortalValuesFallback(opened, values, capability) {
    var targets = Array.isArray(values) ? values : [values];
    var success = true;
    for (var i = 0; i < targets.length; i++) {
      var result = await selectPhoenixGenericPortal(opened, targets[i], capability || {});
      if (!result || !result.ok) {
        success = false;
        break;
      }
      if (targets.length > 1) {
        await AF.Utils.sleep(120);
      }
    }
    return success;
  }

  async function selectPhoenixGenericPortal(opened, value, capability) {
    var panel = findPhoenixGenericPanel(opened && opened.trigger, opened && opened.layer);
    if (!panel) return { ok: false, optionCount: 0, stage: "generic_panel_missing" };
    var nodes = getPhoenixGenericOptions(panel);
    if ((!nodes || !nodes.length) && capability && capability.searchWhenEmpty) {
      try {
        if (H && H.typeIntoSearchInput) await H.typeIntoSearchInput(panel, String(value == null ? "" : value));
        await AF.Utils.sleep(250);
      } catch (e) {}
      nodes = getPhoenixGenericOptions(panel);
    }
    if (!nodes || !nodes.length) return { ok: false, optionCount: 0, stage: "generic_options_empty" };
    var match = null;
    for (var i = 0; i < nodes.length; i++) {
      var text = String(nodes[i].textContent || "").trim();
      var code = nodes[i].getAttribute && (nodes[i].getAttribute("data-value") || nodes[i].getAttribute("value") || nodes[i].getAttribute("title")) || text;
      if (H.isOptionMatch(text, code, value)) { match = nodes[i]; break; }
    }
    if (!match) {
      var target = String(value == null ? "" : value).trim();
      match = nodes.find(function (node) {
        var text = String(node.textContent || "").replace(/\s+/g, " ").trim();
        return text === target || (text && target && (text.indexOf(target) >= 0 || target.indexOf(text) >= 0));
      }) || null;
    }
    if (!match && capability && capability.fallback === "firstFilteredOption") match = nodes[0] || null;
    if (!match) return { ok: false, optionCount: nodes.length, stage: "generic_no_match" };
    var ok = H.clickOption ? await H.clickOption(match) : dispatchMouseSequence(match);
    await AF.Utils.sleep(100);
    await clickConfirmButton(panel);
    await closePhoenixPanel(opened && opened.trigger);
    return { ok: !!ok, optionCount: nodes.length, stage: "generic_match" };
  }

  async function closePhoenixPanel(trigger) {
    try {
      if (document.querySelector(LAYER_SELECTOR)) {
        document.body.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
        document.body.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
        document.body.click();
      } else if (trigger && trigger.blur) {
        trigger.blur();
      }
      await AF.Utils.sleep(100);
    } catch (e) {}
  }

  function isAreaPanel(listContainer) {
    return !!listContainer && (listContainer.classList.contains("area-data-container") || !!listContainer.querySelector(".area-item-name, .area-text-label, .area-icon-right, .area-breadcrumb"));
  }

  function isCheckboxMultiPanel(listContainer) {
    return !!listContainer && !!listContainer.querySelector(".phoenix-checkbox__input");
  }

  function getPhoenixListItems(listContainer) {
    return Array.prototype.slice.call((listContainer || document).querySelectorAll(LIST_ITEM_SELECTOR)).filter(function (item) {
      return AF.DomUtils.isElementVisible(item);
    });
  }

  function getPhoenixListItemsFromDocument() {
    var selector = [LIST_ITEM_SELECTOR, CFG.dropdown].filter(Boolean).join(",");
    return Array.prototype.slice.call(document.querySelectorAll(selector)).filter(function (item, index, arr) {
      return arr.indexOf(item) === index && AF.DomUtils.isElementVisible(item);
    });
  }

  function getPhoenixItemText(item) {
    if (!item) return "";
    var label =
      item.querySelector(".item-text-label, .area-text-label, .phoenix-checkbox__text, .phoenix-selectList__listItem-text") ||
      item;
    return (label.textContent || item.getAttribute("title") || "").trim();
  }

  function getPhoenixItemValue(item) {
    if (!item) return "";
    var checkbox = item.querySelector(".phoenix-checkbox__input");
    return (
      item.getAttribute("data-value") ||
      item.getAttribute("value") ||
      item.getAttribute("title") ||
      (checkbox && checkbox.value) ||
      getPhoenixItemText(item)
    );
  }

  function findScrollableContainer(root, item) {
    var cursor = item ? item.parentElement : null;
    while (cursor && cursor !== root) {
      var style = window.getComputedStyle(cursor);
      if (/(auto|scroll)/.test(style.overflowY || "")) return cursor;
      cursor = cursor.parentElement;
    }
    if (root === document || root === document.documentElement || root === document.body) {
      return document.scrollingElement || document.documentElement || document.body;
    }
    var rootStyle = root && root.nodeType === 1 && window.getComputedStyle(root);
    if (root && rootStyle && /(auto|scroll)/.test(rootStyle.overflowY || "")) return root;
    return root || null;
  }

  async function scrollPhoenixItemIntoView(listContainer, item) {
    if (!listContainer || !item) return false;
    var scroller = findScrollableContainer(listContainer, item);
    if (!scroller) return AF.DomUtils.isElementVisible(item);
    for (var i = 0; i < 60; i++) {
      if (AF.DomUtils.isElementVisible(item)) return true;
      var itemRect = item.getBoundingClientRect();
      var scrollRect = scroller.getBoundingClientRect();
      if (itemRect.top >= scrollRect.top && itemRect.bottom <= scrollRect.bottom) return true;
      var before = scroller.scrollTop;
      scroller.scrollTop += Math.floor((scroller.clientHeight || 240) * 0.8);
      await AF.Utils.sleep(80);
      if (scroller.scrollTop === before) break;
    }
    return AF.DomUtils.isElementVisible(item);
  }

  async function findPhoenixListItemWithScroll(listContainer, value, strictLocation) {
    var initialItems = listContainer ? getPhoenixListItems(listContainer) : getPhoenixListItemsFromDocument();
    var match = findPhoenixListItem(initialItems, value, strictLocation);
    if (match) return match;

    var allItems = listContainer
      ? Array.prototype.slice.call(listContainer.querySelectorAll(LIST_ITEM_SELECTOR))
      : getPhoenixListItemsFromDocument();
    match = findPhoenixListItem(allItems, value, strictLocation);
    if (match) {
      await scrollPhoenixItemIntoView(listContainer, match);
      return match;
    }

    var scroller = findScrollableContainer(listContainer, null);
    if (!scroller) return null;
    for (var i = 0; i < 60; i++) {
      var before = scroller.scrollTop;
      scroller.scrollTop += Math.floor((scroller.clientHeight || 240) * 0.8);
      await AF.Utils.sleep(80);
      match = findPhoenixListItem(listContainer ? getPhoenixListItems(listContainer) : getPhoenixListItemsFromDocument(), value, strictLocation);
      if (match) return match;
      if (scroller.scrollTop === before) break;
    }
    return null;
  }

  function getListSignature(listContainer) {
    return getPhoenixListItems(listContainer).map(function (item) {
      return (item.textContent || "").trim();
    }).filter(Boolean).join("|");
  }

  function normalizeLocationName(text) {
    return String(text || "")
      .replace(/\s+/g, "")
      .replace(/特别行政区|维吾尔自治区|壮族自治区|回族自治区|自治区|自治州|地区|盟|省|市|区|县|旗|镇|乡|街道/g, "");
  }

  function normalizeExactText(text) {
    return String(text || "").replace(/\s+/g, "").trim();
  }

  function isStrictExactTarget(value) {
    var text = normalizeExactText(value);
    if (!text) return false;
    if (/^(父亲|母亲|父母|父子|母子|夫妻|配偶|丈夫|妻子|兄弟|姐妹|哥哥|姐姐|弟弟|妹妹|儿子|女儿|子女|祖父|祖母|外祖父|外祖母|其他)$/.test(text)) return true;
    if (parseStudyYears(text) !== null) return true;
    return false;
  }

  function parseStudyYears(value) {
    var text = normalizeExactText(value);
    if (!text || /月|日/.test(text)) return null;
    var cnMap = { 一: 1, 二: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9, 十: 10 };
    var numericMatch = text.match(/^(\d{1,2})(?:年|年制)?$/) || text.match(/^学制(\d{1,2})(?:年|年制)?$/);
    if (numericMatch) {
      var numericYears = parseInt(numericMatch[1], 10);
      return numericYears >= 1 && numericYears <= 10 ? numericYears : null;
    }
    var cnMatch = text.match(/^([一二两三四五六七八九十])(?:年|年制)?$/) || text.match(/^学制([一二两三四五六七八九十])(?:年|年制)?$/);
    if (cnMatch) return cnMap[cnMatch[1]] || null;
    return null;
  }

  function findPhoenixExactListItem(items, value) {
    var target = normalizeExactText(value);
    if (!target) return null;
    var targetStudyYears = parseStudyYears(target);
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var checkbox = item.querySelector(".phoenix-checkbox__input");
      if (checkbox && checkbox.value === "checkAll") continue;
      var text = normalizeExactText(getPhoenixItemText(item));
      var optionValue = normalizeExactText(getPhoenixItemValue(item));
      if (text === target || optionValue === target) return item;
      if (targetStudyYears !== null && (parseStudyYears(text) === targetStudyYears || parseStudyYears(optionValue) === targetStudyYears)) return item;
    }
    return null;
  }

  function findPhoenixListItem(items, value, strictLocation) {
    var target = String(value == null ? "" : value).trim();
    if (!target) return null;
    if (isStrictExactTarget(target)) return findPhoenixExactListItem(items, target);
    var targetLocation = normalizeLocationName(target);
    // area-data-container 是 Phoenix 的省/市/区级联面板；这里必须强制
    // 使用地点精确匹配，不能受字段 capability 或普通下拉的模糊策略影响。
    if (strictLocation) {
      if (!targetLocation) return null;
      return items.find(function (item) {
        var checkbox = item.querySelector(".phoenix-checkbox__input");
        if (checkbox && checkbox.value === "checkAll") return false;
        var text = normalizeLocationName(getPhoenixItemText(item));
        var optionValue = normalizeLocationName(getPhoenixItemValue(item));
        return text === targetLocation || optionValue === targetLocation;
      }) || null;
    }
    var bestItem = null;
    var bestScore = 0;
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var checkbox = item.querySelector(".phoenix-checkbox__input");
      if (checkbox && checkbox.value === "checkAll") continue;
      var text = getPhoenixItemText(item);
      var optionValue = getPhoenixItemValue(item);
      if (!text) continue;
      if (H.isOptionMatch(text, optionValue, target)) return item;
      var normalizedText = normalizeLocationName(text);
      var normalizedValue = normalizeLocationName(optionValue);
      if (
        normalizedText &&
        targetLocation &&
        (normalizedText === targetLocation ||
          normalizedValue === targetLocation ||
          text.includes(target) ||
          String(optionValue || "").includes(target) ||
          target.includes(normalizedText))
      ) {
        return item;
      }
      try {
        var score = Math.max(
          AF.DomUtils.calculateSimilarity(text, target),
          AF.DomUtils.calculateSimilarity(optionValue, target),
          normalizedText && targetLocation ? AF.DomUtils.calculateSimilarity(normalizedText, targetLocation) : 0,
          normalizedValue && targetLocation ? AF.DomUtils.calculateSimilarity(normalizedValue, targetLocation) : 0
        );
        if (score > bestScore) {
          bestScore = score;
          bestItem = item;
        }
      } catch (e) {}
    }
    return bestScore >= 0.45 ? bestItem : null;
  }

  function clickPhoenixItem(item) {
    if (!item) return false;
    var arrow = item.querySelector(".area-icon-right");
    var text = item.querySelector(".area-text-label");
    var radioSvg = item.querySelector(".icon-container > svg");
    var checkbox = item.querySelector(".phoenix-checkbox");

    if (arrow && text) {
      if (radioSvg) dispatchMouseSequence(radioSvg);
      dispatchMouseSequence(text);
      return true;
    }
    return dispatchMouseSequence(radioSvg) || dispatchMouseSequence(checkbox) || dispatchMouseSequence(item);
  }

  async function clickConfirmButton(scope) {
    var root = scope || document;
    var button = (root.querySelector && root.querySelector(CFG.confirmButton)) || null;
    if (!button) {
      var content = Array.prototype.slice.call((root.querySelectorAll && root.querySelectorAll(".phoenix-button__content")) || []).find(function (node) {
        return (node.textContent || "").trim() === "确定";
      });
      button = content && (content.closest(".phoenix-button__wraper, .phoenix-button, .phoenix-button__wrapper") || content);
    }
    if (!button) {
      button = Array.prototype.slice.call(document.querySelectorAll("button, .phoenix-button, .phoenix-button__wrapper")).find(function (node) {
        return (node.textContent || "").trim() === "确定" && !node.disabled && AF.DomUtils.isElementVisible(node);
      });
    }
    if (button && AF.DomUtils.isElementVisible(button)) {
      dispatchMouseSequence(button);
      await AF.Utils.sleep(80);
      return true;
    }
    return false;
  }

  async function typePhoenixSearch(opened, value) {
    var root = opened && opened.layer;
    if (!root || !root.querySelector) return false;
    var input = root.querySelector(".phoenix-input__input, input[type='search'], input[type='text']");
    if (!input || !AF.DomUtils.isElementVisible(input)) return false;
    try {
      input.focus && input.focus();
      input.value = String(value == null ? "" : value);
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      await AF.Utils.sleep(250);
      return true;
    } catch (e) {
      return false;
    }
  }

  async function waitForPanelRefresh(layer, previousSignature) {
    var container = null;
    await AF.Utils.waitForElement(function () {
      var containers = Array.prototype.slice.call(((layer || document).querySelectorAll && (layer || document).querySelectorAll(LIST_CONTAINER_SELECTOR)) || []).filter(AF.DomUtils.isElementVisible);
      for (var i = containers.length - 1; i >= 0; i--) {
        var nextSignature = getListSignature(containers[i]);
        if (nextSignature && nextSignature !== previousSignature) {
          container = containers[i];
          return true;
        }
      }
      return false;
    }, 1600);
    return container || (layer && layer.querySelector(LIST_CONTAINER_SELECTOR));
  }

  function phoenixSalaryUnitHint(value) {
    var text = String(value == null ? "" : value).toLowerCase().replace(/\s+/g, "");
    if (!text) return "empty";
    if (/年薪|\/年|每年|annual|peryear/.test(text)) return "annual";
    if (/月薪|\/月|每月|monthly|permonth/.test(text)) return "monthly";
    if (/\bk\b|千|万|w/.test(text)) return "scaled_unspecified";
    if (/\d/.test(text)) return "numeric_unspecified";
    return "text";
  }

  function normalizePhoenixMonthlySalaryValue(value, capability) {
    if (!(capability && capability.salaryMode === "monthlyRange") || typeof value !== "string") return value;
    var text = value.trim();
    if (!text || phoenixSalaryUnitHint(text) !== "annual") return value;
    try {
      var comparable = AF.DomUtils && AF.DomUtils.extractComparableValue && AF.DomUtils.extractComparableValue(text);
      if (comparable && comparable.type === "numeric" && isFinite(comparable.value) && comparable.value > 0) {
        return String(Math.max(1, Math.round(comparable.value / 12))) + "元/月";
      }
    } catch (e) {}
    return value;
  }

  function findPhoenixRangeListItem(items, value) {
    if (!AF.DomUtils || typeof AF.DomUtils.findBestRangeMatch !== "function") return null;
    try {
      var candidates = (items || []).map(function (item, index) {
        return { index: index, text: getPhoenixItemText(item), value: getPhoenixItemValue(item) };
      }).filter(function (item) { return !!item.text; });
      var best = AF.DomUtils.findBestRangeMatch(candidates, value);
      return best && typeof best.index === "number" ? items[best.index] : null;
    } catch (e) {
      return null;
    }
  }

  function countPhoenixParseableRanges(items) {
    if (!AF.DomUtils || typeof AF.DomUtils.parseOptionRange !== "function") return 0;
    return (items || []).reduce(function (count, item) {
      try { return count + (AF.DomUtils.parseOptionRange(getPhoenixItemText(item)) ? 1 : 0); } catch (e) { return count; }
    }, 0);
  }

  function parsePhoenixValue(value, capability) {
    if (Array.isArray(value)) {
      return value.map(function (item) {
        return typeof item === "string" ? item.trim() : item;
      }).filter(Boolean);
    }
    if (value === undefined || value === null) return [];
    if (typeof value !== "string") return [value];
    var text = value.trim();
    if (!text) return [];
    // Comma-like delimiters represent independent preferences/tags. Slash is NOT
    // generally a hierarchy separator: mature range matching expects values such as
    // "示例资料" to reach the option matcher intact. Only split slash for explicit
    // location paths, never for salary/unit strings.
    if (/[、,，;；\n\r]/.test(text)) {
      return text.split(/[、,，;；\n\r]+/).map(function (item) { return item.trim(); }).filter(Boolean);
    }
    if (text.indexOf("/") !== -1 && !(capability && capability.preserveSlashValue === true)) {
      var slashParts = text.split("/").map(function (item) { return item.trim(); }).filter(Boolean);
      var looksLocationPath = slashParts.length > 1 && slashParts.every(function (item) {
        return /省|自治区|特别行政区|市|自治州|地区|盟|区|县|旗|镇|乡|街道/.test(item);
      });
      if (looksLocationPath) return slashParts;
    }
    var match = text.match(/(.+?(?:省|自治区|特别行政区|市))?(.+?(?:市|自治州|地区|盟))?(.+?(?:区|县|市|旗|镇|乡|街道))?/);
    if (match && capability && capability.locationMode) {
      var parts = [match[1], match[2], match[3]].filter(Boolean);
      if (parts.length > 1) return parts;
    }
    return [text];
  }

  // 复选框多选列表: 逐个匹配 value 数组里的每一项，勾上后点确认按钮 (对应源码 tt/et)
  async function selectPhoenixCheckboxMulti(opened, values) {
    var listContainer = opened.listContainer;
    var successCount = 0;
    for (var i = 0; i < values.length; i++) {
      var match = await findPhoenixListItemWithScroll(listContainer, values[i]);
      if (!match && (await typePhoenixSearch(opened, values[i]))) {
        listContainer = opened.listContainer || (opened.layer && opened.layer.querySelector(LIST_CONTAINER_SELECTOR));
        match = await findPhoenixListItemWithScroll(listContainer, values[i]);
      }
      if (!match) continue;
      var checkbox = match.querySelector(".phoenix-checkbox__input");
      if (checkbox && checkbox.checked) {
        successCount++;
        continue;
      }
      if (clickPhoenixItem(match)) {
        successCount++;
        await AF.Utils.sleep(50);
      }
    }
    await clickConfirmButton(opened.layer || document);
    await closePhoenixPanel(opened.trigger);
    return successCount > 0;
  }

  function parseDateLikeTargetDays(value) {
    var text = String(value == null ? "" : value).trim();
    var match = text.match(/^(\d{4})[-/.](\d{1,2})(?:[-/.](\d{1,2}))?$/);
    if (!match) return null;
    var date = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3] || 1));
    if (!isFinite(date.getTime())) return null;
    return Math.max(0, Math.round((date.getTime() - Date.now()) / 86400000));
  }

  function chineseDurationNumber(text) {
    var t = String(text || "");
    var m = t.match(/(\d+(?:\.\d+)?)/);
    if (m) return Number(m[1]);
    if (/一|1/.test(t)) return 1;
    if (/两|二|2/.test(t)) return 2;
    if (/三|3/.test(t)) return 3;
    if (/六|6|半年/.test(t)) return /半年/.test(t) ? 0.5 : 6;
    if (/十二|12|一年/.test(t)) return /一年/.test(t) ? 1 : 12;
    return null;
  }

  function availabilityRangeDays(optionText) {
    var text = String(optionText || "").replace(/\s+/g, "");
    if (!text) return null;
    if (/随时|立即|马上|即刻/.test(text)) return { min: 0, max: 3, kind: "immediate" };
    var range = text.match(/([一二两三四五六七八九十百\d.]+)\s*(天|周|星期|个月|月|年)\s*[~\-–—至到]\s*([一二两三四五六七八九十百\d.]+)\s*(天|周|星期|个月|月|年)/);
    function unitDays(n, unit) {
      if (!isFinite(n)) return null;
      if (/天/.test(unit)) return n;
      if (/周|星期/.test(unit)) return n * 7;
      if (/月|个月/.test(unit)) return n * 30.5;
      if (/年/.test(unit)) return n * 365;
      return null;
    }
    if (range) {
      var a = chineseDurationNumber(range[1]);
      var b = chineseDurationNumber(range[3]);
      var ad = unitDays(a, range[2]);
      var bd = unitDays(b, range[4]);
      if (ad != null && bd != null) return { min: Math.min(ad, bd), max: Math.max(ad, bd), kind: "range" };
    }
    var single = text.match(/([一二两三四五六七八九十百\d.]+|半)\s*(天|周|星期|个月|月|年)/);
    if (single) {
      var n = single[1] === "半" ? 0.5 : chineseDurationNumber(single[1]);
      var days = unitDays(n, single[2]);
      if (days != null) {
        if (/以上|及以上|以后|之后|超过|大于/.test(text)) return { min: days, max: Infinity, kind: "lower_bound" };
        if (/以内|内|以下|不超过|小于/.test(text)) return { min: 0, max: days, kind: "upper_bound" };
        return { min: Math.max(0, days - 3), max: days + 3, kind: "point" };
      }
    }
    if (/面议|面谈|协商|待定|其他|观望/.test(text)) return { min: 0, max: Infinity, kind: "negotiable" };
    return null;
  }

  function findAvailabilityFallbackItem(items, value) {
    var targetText = String(value == null ? "" : value).trim();
    if (!targetText) return null;
    var days = parseDateLikeTargetDays(targetText);
    if (days == null) {
      if (/随时|立即|马上|即刻/.test(targetText)) days = 0;
      else {
        var inputRange = availabilityRangeDays(targetText);
        if (inputRange && inputRange.kind !== "negotiable") days = isFinite(inputRange.max) ? inputRange.max : inputRange.min;
      }
    }
    if (days == null) return null;
    var candidates = (items || []).map(function (item) {
      return { item: item, range: availabilityRangeDays(getPhoenixItemText(item)) };
    }).filter(function (entry) { return !!entry.range; });
    var inRange = candidates.filter(function (entry) {
      return entry.range.kind !== "negotiable" && days >= entry.range.min && days <= entry.range.max;
    });
    if (inRange.length) {
      inRange.sort(function (a, b) {
        var aw = isFinite(a.range.max) ? a.range.max - a.range.min : 1e9;
        var bw = isFinite(b.range.max) ? b.range.max - b.range.min : 1e9;
        return aw - bw;
      });
      return inRange[0].item;
    }
    // A far-future explicit date should not be coerced to an immediate window. Prefer
    // a lower-bound bucket (e.g. 三个月以上) and only then a negotiation/示例资料 option.
    var lower = candidates.filter(function (entry) {
      return entry.range.kind === "lower_bound" && days >= entry.range.min;
    }).sort(function (a, b) { return b.range.min - a.range.min; });
    if (lower.length) return lower[0].item;
    var negotiable = candidates.find(function (entry) { return entry.range.kind === "negotiable"; });
    return negotiable ? negotiable.item : null;
  }

  async function selectPhoenixFlatList(opened, value, capability) {
    var listContainer = opened.listContainer;
    var initialItems = listContainer ? getPhoenixListItems(listContainer) : getPhoenixListItemsFromDocument();
    var match = capability && capability.salaryMode === "monthlyRange"
      ? findPhoenixRangeListItem(initialItems, value)
      : null;
    if (!match) match = await findPhoenixListItemWithScroll(listContainer, value);
    if (!match && (await typePhoenixSearch(opened, value))) {
      listContainer = opened.listContainer || (opened.layer && opened.layer.querySelector(LIST_CONTAINER_SELECTOR));
      var searchedItems = listContainer ? getPhoenixListItems(listContainer) : getPhoenixListItemsFromDocument();
      if (capability && capability.salaryMode === "monthlyRange") match = findPhoenixRangeListItem(searchedItems, value);
      if (!match) match = await findPhoenixListItemWithScroll(listContainer, value);
    }
    if (!match && capability && capability.availabilityMode === "relativeChoice") {
      var availabilityItems = listContainer ? getPhoenixListItems(listContainer) : getPhoenixListItemsFromDocument();
      match = findAvailabilityFallbackItem(availabilityItems, value);
    }
    if (!match) {
      // Keep the popup open when the capability explicitly allows the mature
      // generic-portal fallback. Some Phoenix taxonomy widgets render inside
      // the same portal layer but do not use list-data-container/phoenix-selectList.
      if (!(capability && capability.genericPortalFallback === true)) {
        await closePhoenixPanel(opened.trigger);
      }
      return false;
    }
    clickPhoenixItem(match);
    await AF.Utils.sleep(80);
    await clickConfirmButton(opened.layer || document);
    await closePhoenixPanel(opened.trigger);
    return true;
  }

  async function selectPhoenixAreaCascade(opened, values, capability) {
    var container = opened.listContainer;
    var ok = true;
    if (capability && capability.locationMode === "firstPreferredChinaPath" && values.length) {
      var explicitPath = values.length > 1 && /省|自治区|特别行政区|市$/.test(String(values[0] || "")) && /市|自治州|地区|盟|区|县|旗$/.test(String(values[1] || ""));
      if (!explicitPath && AF.LocationResolver && typeof AF.LocationResolver.resolveChinaPath === "function") {
        var resolved = AF.LocationResolver.resolveChinaPath(values[0]);
        if (resolved && resolved.length) values = resolved;
      }
      // Phoenix area controls observed in the mature product are single logical
      // cascaders. When profile data contains several preferred cities, use the
      // first preference rather than treating all cities as one hierarchy.
      if (!explicitPath && values.length > 2) values = values.slice(0, 2);
    }
    for (var i = 0; i < 4 && container; i++) {
      var target = values[i] == null ? values[values.length - 1] : values[i];
      var signature = getListSignature(container);
      // 地址级联的第一层是省份。若上游只传来“杭州市”这种城市值，
      // 不允许模糊算法在省份表中猜选（曾因此错点“贵州省”）。
      var topLevelItems = i === 0 ? getPhoenixListItems(container) : [];
      var looksLikeProvinceList = topLevelItems.length >= 10 && topLevelItems.filter(function (item) {
        return /省|自治区|特别行政区|香港|澳门|台湾/.test(getPhoenixItemText(item));
      }).length >= 8;
      if (i === 0 && values.length < 2 && looksLikeProvinceList && !/省|自治区|特别行政区|^(北京|上海|天津|重庆)市$|香港|澳门|台湾/.test(String(target))) {
        ok = false;
        break;
      }
      // area-data-container 是 Phoenix 的省/市/区级联面板；这里必须强制
      // 使用地点精确匹配，不能受字段 capability 或普通下拉的模糊策略影响。
      var match = await findPhoenixListItemWithScroll(container, target, true);
      if (!match) {
        ok = false;
        break;
      }
      var hasNext = !!match.querySelector(".area-icon-right");
      if (!clickPhoenixItem(match)) {
        ok = false;
        break;
      }
      await AF.Utils.sleep(80);
      var isLastTarget = i >= values.length - 1;
      if (!hasNext || isLastTarget) break;
      container = await waitForPanelRefresh(opened.layer, signature);
    }
    if (ok) await clickConfirmButton(opened.layer || document);
    await closePhoenixPanel(opened.trigger);
    return ok;
  }

  async function triggerPhoenixSelect(element, value, capability) {
    var trace = {
      label: phoenixFieldLabel(element, capability),
      valueShape: Array.isArray(value) ? "array" : (value && typeof value === "object" ? "object" : typeof value),
      valueCount: Array.isArray(value) ? value.length : 1,
      panelKind: "unknown",
      optionCount: 0,
      genericOptionCount: 0,
      fallbackUsed: false,
      dialogFallbackUsed: false,
      dialogFallbackHandled: false,
      salaryUnitHint: "",
      parseableRangeCount: 0,
      resultStage: "",
      result: false
    };
    try {
      if (value === undefined || value === null || value === "") {
        trace.panelKind = "empty_value";
        writePhoenixTrace(trace);
        return false;
      }
      var effectiveValue = normalizePhoenixMonthlySalaryValue(value, capability);
      if (capability && capability.salaryMode === "monthlyRange") trace.salaryUnitHint = phoenixSalaryUnitHint(value);
      var values = parsePhoenixValue(effectiveValue, capability);
      trace.valueCount = values.length;
      if (!values.length) {
        trace.panelKind = "empty_parsed_value";
        writePhoenixTrace(trace);
        return false;
      }

      var opened = await openPhoenixPanel(element);
      if (!opened.listContainer) opened.listContainer = null;
      var primaryItems = opened.listContainer ? getPhoenixListItems(opened.listContainer) : getPhoenixListItemsFromDocument();
      trace.optionCount = primaryItems.length;
      if (capability && capability.salaryMode === "monthlyRange") trace.parseableRangeCount = countPhoenixParseableRanges(primaryItems);

      var ok;
      if (isAreaPanel(opened.listContainer)) {
        trace.panelKind = "area";
        ok = await selectPhoenixAreaCascade(opened, values, capability);
      } else if (isCheckboxMultiPanel(opened.listContainer)) {
        trace.panelKind = "checkbox_multi";
        ok = await selectPhoenixCheckboxMulti(opened, values);
      } else if (values.length > 1) {
        trace.panelKind = "multi_value";
        ok = await selectPhoenixCheckboxMulti(opened, values);
        if (!ok && capability && capability.genericPortalFallback === true) {
          var multiGenericResult = await selectPhoenixPortalValuesFallback(opened, values, capability);
          trace.fallbackUsed = true;
          trace.resultStage = multiGenericResult ? "multi_generic_portal" : "multi_generic_portal_failed";
          ok = !!multiGenericResult;
        }
      } else {
        trace.panelKind = "flat";
        ok = await selectPhoenixFlatList(opened, values[0], capability);
        if (!ok && capability && capability.genericPortalFallback === true) {
          var genericResult = await selectPhoenixGenericPortal(opened, values[0], capability);
          trace.fallbackUsed = true;
          trace.genericOptionCount = Number(genericResult && genericResult.optionCount || 0);
          trace.resultStage = String(genericResult && genericResult.stage || "");
          ok = !!(genericResult && genericResult.ok);
          if (trace.genericOptionCount > trace.optionCount) trace.optionCount = trace.genericOptionCount;
          if (ok) trace.panelKind = "generic_portal";
        }
        if (!ok && capability && capability.dialogChoiceFallback === true && AF.FormHandler && typeof AF.FormHandler.tryFillDialogChoice === "function") {
          trace.dialogFallbackUsed = true;
          await closePhoenixPanel(opened && opened.trigger);
          var dialogResult = await AF.FormHandler.tryFillDialogChoice(element, values[0], {
            forceProbe: capability.forceDialogProbe === true,
            allowFirstResult: false
          });
          trace.dialogFallbackHandled = !!(dialogResult && dialogResult.handled);
          ok = !!(dialogResult && dialogResult.success);
          trace.resultStage = ok ? "mature_dialog_choice" : (trace.dialogFallbackHandled ? "mature_dialog_choice_failed" : trace.resultStage || "mature_dialog_not_found");
          if (ok) trace.panelKind = "dialog_choice";
        }
      }
      H.dispatchChangeEvents(element);
      trace.result = !!ok;
      if (!trace.resultStage) trace.resultStage = ok ? "primary" : "primary_failed";
      writePhoenixTrace(trace);
      return ok;
    } catch (e) {
      trace.panelKind = trace.panelKind === "unknown" ? "exception" : trace.panelKind;
      trace.result = false;
      writePhoenixTrace(trace);
      return false;
    }
  }

  SA._registry["phoenix"] = function (element, valueType, sectionEl, capability) {
    return {
      selectValue: async function (value) {
        return await triggerPhoenixSelect(element, value, capability || SA._currentCapability || null);
      },
    };
  };
})();
