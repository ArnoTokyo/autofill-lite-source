"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const preload = fs.readFileSync(path.join(root, "ui-preload.js"), "utf8");
const renderer = fs.readFileSync(path.join(root, "renderer.js"), "utf8");
const index = fs.readFileSync(path.join(root, "index.html"), "utf8");
const manifest = JSON.parse(fs.readFileSync(path.join(root, "autofill-plugin", "manifest.json"), "utf8"));
const collector = fs.readFileSync(path.join(root, "autofill-plugin", "content", "site-analysis-collector.js"), "utf8");
const aiInputBuilder = fs.readFileSync(path.join(root, "site-analysis-ai-input.js"), "utf8");

assert(main.includes('ipcMain.handle("lite:analyze-site"'), "site analysis IPC entry missing");
assert(main.includes('const SITE_ANALYSIS_DIR = path.join(DATA_DIR, "site-analysis")'), "site analysis data directory missing");
assert(main.includes("appendSiteAnalysis") && main.includes("fullUrlQueryStored: false"), "analysis persistence/safety metadata missing");
assert(main.includes("updateSiteAnalysisBundle") && main.includes("autofill-lite-site-analysis-bundle"), "same-route snapshot bundle merge missing");
assert(main.includes("siteAnalysisFingerprint") && main.includes("slice(-10)"), "bundle dedupe/bounded history missing");
assert(preload.includes("analyzeSite: (guestId)"), "site analysis API not exposed to renderer");
assert(!index.includes('id="analyze"'), "manual site-analysis toolbar entry must stay removed in Build160");
assert(renderer.includes("showAnalysisReport") && renderer.includes("不会填写、保存或新增记录"), "site analysis UI safety message missing");
assert(renderer.includes("合并快照") && renderer.includes("唯一选择器") && renderer.includes("AI输入包"), "v1.2 analysis report details missing");
assert(manifest.content_scripts[0].js.includes("content/site-analysis-collector.js"), "collector must be injected with Autofill Core");

assert(collector.includes('var VERSION = "2.2.0"') && collector.includes("schemaVersion: 7"), "collector v2.2/schema v7 marker missing");
assert(collector.includes("safeSemanticCandidates") && collector.includes("labelSource") && collector.includes("nearbyTextCandidates") && collector.includes("formItemLabel"), "multi-signal privacy-aware semantic evidence missing");
assert(collector.includes("selectorHitCount") && collector.includes("selectorCandidates") && collector.includes("ancestrySelector"), "selector fingerprint/uniqueness evidence missing");
assert(collector.includes("element-select") && collector.includes("element-date") && collector.includes("element-cascader"), "framework widget type detection missing");
assert(collector.includes("requiredEvidence") && collector.includes("required_container_class") && collector.includes("required_visual_marker") && !collector.includes('normalizeText(container && container.textContent, 200)'), "required detection must be evidence-based, not broad container text");
assert(collector.includes("nearest_preceding_heading") && collector.includes("collectSectionTitles") && collector.includes("基础信息") && collector.includes("意向信息"), "section ownership must use expanded preceding heading evidence");
assert(collector.includes("collectNavigationSnapshot") && collector.includes("hrefPath"), "navigation/module snapshot missing");
assert(collector.includes("NAV_SECTION_TEXT_PATTERN") && collector.includes("semantic_text_fallback") && collector.includes("navigationClusterSize"), "navigation discovery v2 semantic fallback missing");
assert(collector.includes("外语水平") && collector.includes("通讯信息") && collector.includes("其他资格") && collector.includes("附件"), "resume section navigation dictionary incomplete");
assert(collector.includes("discoveryVersion: 3") && collector.includes("clusterSize"), "navigation discovery v3 evidence metadata missing");
assert(collector.includes("interactive.candidates") && collector.includes("configuredRecords.map(summarizeInteractiveCandidate)"), "non-clicked interactive candidates must be retained");
assert(collector.includes("coreFieldKey") && collector.includes("categoryHintForSection") && collector.includes("fieldMappingHint"), "core deterministic mapping evidence missing");
assert(main.includes('require("./site-analysis-ai-input")') && main.includes("buildAiSiteInput"), "AI-ready compact input builder wiring missing");
assert(aiInputBuilder.includes("autofill-lite-ai-site-input"), "AI-ready compact input schema missing");
assert(aiInputBuilder.includes("fieldId") && aiInputBuilder.includes("patchTarget") && aiInputBuilder.includes("AI_PROFILE_FIELD_KEYS"), "AI review v2 stable identity/profile contract missing");
assert(aiInputBuilder.includes("positional_date_pair") && aiInputBuilder.includes("gender_option_pair"), "structural pre-AI hints missing");
assert(aiInputBuilder.includes("nearbyFreeTextExcludedFromAiPacket: true") && aiInputBuilder.includes("currentFieldValuesIncluded: false"), "AI input privacy contract missing");
assert(aiInputBuilder.includes("emptySnapshotCountExcluded") && aiInputBuilder.includes("legacySnapshotCountExcluded") && aiInputBuilder.includes("snapshotHasAiEvidence"), "AI input must filter structure-empty or legacy snapshots");

assert(collector.includes("dictionary_longest_section_label") && collector.includes("dictionary_exact_alias"), "mapping audit must prefer deterministic dictionary evidence");
assert(collector.includes("coreMappingStatus") && collector.includes("coreMappingConfidence") && collector.includes("coreMappingReasons"), "mapping trust metadata missing");
assert(collector.includes("signals && signals.safeSemanticCandidates") && !collector.includes(".concat(signals && signals.semanticCandidates || [])"), "core mapping must not consume nearby free text");
assert(aiInputBuilder.includes("autofill-lite-ai-mapping-review-request") && aiInputBuilder.includes("tentativeCoreMappedFieldCount"), "compact AI review packet / tentative mapping count missing");

assert(collector.includes("allowAddProbe: false"), "analysis must not probe add/new actions");
assert(collector.includes("allowPageNavigation: false") && collector.includes("allowNavigationActions: false"), "analysis must block navigation actions");
assert(collector.includes("if (Number(staticScan.controlCount || 0) > 0) return result;") && collector.includes("if (!result.interactive.detection || !result.interactive.detection.matched) return result;"), "static-first analysis must not click edit actions when a real form is already visible");
assert(collector.includes("currentValuePresent") && !collector.includes("currentValue:"), "analysis may record presence but must not persist field values");
assert(collector.includes("queryCaptured: false") && collector.includes("saveSubmitApplyDeleteUploadAllowed: false"), "collector safety contract missing");

assert(collector.includes("formGraph: formGraph") && collector.includes("graphCoverage") && collector.includes("graphDiagnostics"), "FormGraph analyzer output missing");
assert(collector.includes("graphFieldId") && collector.includes("graphRowId") && collector.includes("graphLinkMethod"), "static fields must receive graph ownership context");
assert(aiInputBuilder.includes("compactFormGraph") && aiInputBuilder.includes("graphRowId") && aiInputBuilder.includes("graphLinkedFieldCount"), "AI input must preserve row/graph context");
assert(aiInputBuilder.includes("schemaVersion: 4"), "AI site input schema v4 marker missing");

console.log("local site analysis AI review-contract regression: PASS");
