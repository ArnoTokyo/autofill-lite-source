"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

const menuTitles = [
  "个人信息",
  "高中示例资料",
  "高等示例资料",
  "语言情况",
  "学生工作",
  "实习工作",
  "社会实践经历",
  "全职示例资料",
  "所获专业技术资格证书",
  "项目经验及研究成果",
  "奖励情况",
  "个人特长",
  "家庭信息",
  "是否服从调剂",
];

global.window = { AF: {} };
global.document = {
  body: { innerText: "", textContent: "", querySelectorAll() { return []; } },
  querySelector(selector) { return selector === "body" ? {} : null; },
  querySelectorAll(selector) {
    if (selector === ".resume-menu-item__title") {
      return menuTitles.map((textContent) => ({ textContent }));
    }
    return [];
  },
};

const registry = path.join(__dirname, "..", "autofill-plugin", "private", "private-special-sites.js");
new Function(fs.readFileSync(registry, "utf8"))();

const 示例资料flow = window.AF.PrivateSpecialSites.getWorkflowForUrl(
  "https://xiaoyuan.zhaopin.com/scrd/resume2?cid=10126836"
);
assert(示例资料flow, "CDB should match public Zhaopin campus 示例资料flow");
assert.strictEqual(示例资料flow.id, "zhaopin-campus-enterprise-resume-v1");

const 示例资料 = 示例资料flow.steps.find((step) => step.name === "实习工作");
assert(示例资料, "实习工作 should be recognized");
assert.strictEqual(示例资料.category, "示例资料Experience", "示例资料 section must not consume full-time rows");
assert.strictEqual(示例资料.zhaopinRepeatNavigationAdapter, true, "示例资料 should use scoped 示例资料 navigation adapter");
assert(示例资料.fieldSequence.some((item) => (Array.isArray(item.label) ? item.label : [item.label]).includes("公司名称")));
assert(示例资料.fieldSequence.some((item) => (Array.isArray(item.label) ? item.label : [item.label]).includes("职位名称")));
assert(示例资料.fieldSequence.some((item) => item.type === "zhaopinCampusDate" && (Array.isArray(item.label) ? item.label : [item.label]).includes("开始日期")), "示例资料 must recognize the CDB 开始日期 label and use precision-aware date filling");
assert(示例资料.fieldSequence.some((item) => item.type === "zhaopinCampusDate" && (Array.isArray(item.label) ? item.label : [item.label]).includes("结束日期")), "示例资料 must recognize the CDB 结束日期 label");
assert.strictEqual(示例资料.zhaopinRepairExistingRecords, true);
assert.strictEqual(示例资料.zhaopinRepairExistingByPosition, true);
assert.strictEqual(示例资料.zhaopinBlockOnExcessExistingRecords, true);
assert.strictEqual(示例资料.zhaopinRepairCorruptedExcessDuplicates, true, "obvious duplicate surplus cards may be repaired in-place, but never auto-deleted");
assert.strictEqual(示例资料.zhaopinContinueExistingRepairAfterRowError, true, "a failed repair of one existing 示例资料 row must cancel that unsaved editor and continue auditing later existing rows");
assert.strictEqual(示例资料.zhaopinRepeatRetrySaveWhenStillEditing, true, "public-示例资料 save should retry once only when the editor is still truly visible and no validation error is present");
示例资料.fieldSequence.filter((item) => ["company", "zhaopinCampusStartDate", "zhaopinCampusEndDate", "position"].includes(item.field)).forEach((item) => {
  assert.strictEqual(item.zhaopinRepeatLocalBinding, true, `${item.field} must bind within the current 示例资料 editor field group`);
  assert.strictEqual(item.coreMatcherFirst, false, `${item.field} must not let a stale/global Core match override the current 示例资料 editor`);
  assert.strictEqual(item.requireLabel, true, `${item.field} must stop instead of guessing when the current editor label is absent`);
});
assert.strictEqual(示例资料.waitForCloseSelector, "form.scrd-web--form-edit", "public-示例资料 save verification must watch the real editor form, not a persistent outer wrapper");
const transformedInternship = 示例资料.rowTransform({ company: "fixture-company", startTime: "示例资料", endTime: "示例资料", startDate: "示例资料", endDate: "示例资料", position: "fixture-role" });
assert.strictEqual(transformedInternship.zhaopinCampusStartDate, "示例资料");
assert.strictEqual(transformedInternship.zhaopinCampusEndDate, "示例资料");

const fulltime = 示例资料flow.steps.find((step) => step.name === "全职示例资料");
assert(fulltime, "full-time section should be recognized");
assert.strictEqual(fulltime.category, "示例资料Experience", "full-time section must not consume 示例资料 rows");
assert.strictEqual(fulltime.zhaopinRepeatNavigationAdapter, true);

const 示例资料 = 示例资料flow.steps.find((step) => step.name === "项目经验及研究成果");
assert(示例资料, "示例资料 section should be recognized");
assert.strictEqual(示例资料.category, "示例资料Experience");
assert.strictEqual(示例资料.zhaopinRepeatNavigationAdapter, true, "示例资料 should use scoped 示例资料 navigation adapter");
const 示例资料Labels = 示例资料.fieldSequence.flatMap((item) => Array.isArray(item.label) ? item.label : [item.label]);
["项目名称", "项目开始时间", "项目结束时间", "项目职责", "项目描述"].forEach((label) => {
  assert(示例资料Labels.includes(label), `示例资料 sequence should include ${label}`);
});
const transformedProject = 示例资料.rowTransform({ name: "fixture-示例资料", details: "fixture-details", role: "fixture-role" });
assert(transformedProject.zhaopinProjectDescription.includes("fixture-details"), "normalized 示例资料 details must reach the 示例资料-description field");
const transformedProjectDates = 示例资料.rowTransform({ name: "fixture-示例资料", startTime: "示例资料", endTime: "示例资料", startDate: "示例资料", endDate: "示例资料" });
assert.strictEqual(transformedProjectDates.zhaopinCampusStartDate, "示例资料");
assert.strictEqual(transformedProjectDates.zhaopinCampusEndDate, "示例资料");
assert(示例资料Labels.includes("结束日期"), "示例资料 sequence must recognize the CDB 结束日期 label");
assert(示例资料.fieldSequence.some((item) => item.type === "zhaopinCampusDate"), "示例资料 dates must use precision-aware CDB date handling");
示例资料.fieldSequence.filter((item) => ["name", "zhaopinCampusStartDate", "zhaopinCampusEndDate"].includes(item.field)).forEach((item) => {
  assert.strictEqual(item.zhaopinRepeatLocalBinding, true, `示例资料 ${item.field} must bind inside the active 示例资料 editor`);
  assert.strictEqual(item.coreMatcherFirst, false, `示例资料 ${item.field} must prefer the local editor over stale global controls`);
});


const certificate = 示例资料flow.steps.find((step) => step.name === "所获专业技术资格证书");
assert(certificate, "certificate section should still be recognized");
assert.strictEqual(certificate.category, "示例资料");

const 示例资料 = 示例资料flow.steps.find((step) => step.name === "语言情况");
assert(示例资料, "语言情况 should be recognized from the CDB menu");
assert.strictEqual(示例资料.category, "示例资料Skills");
assert.strictEqual(示例资料.zhaopinRepeatNavigationAdapter, true, "示例资料 should tolerate either a visible editor or an Add-driven 示例资料 editor");
const 示例资料Labels = 示例资料.fieldSequence.flatMap((item) => Array.isArray(item.label) ? item.label : [item.label]);
["大学英语四级考试成绩", "大学英语六级考试成绩", "其他英语等级考试"].forEach((label) => {
  assert(示例资料Labels.includes(label), `CDB 示例资料 summary should include ${label}`);
});
assert(!示例资料Labels.includes("外语种类"), "CDB fixed 示例资料-summary form must not use the generic 示例资料-name selector");
const transformedLanguage = 示例资料.rowTransform({
  name: "英语",
  certificateName: "雅思",
  score: "6.5",
  cet4Score: "616",
  cet6Score: "532",
  示例资料EnglishExam: "示例资料",
  示例资料EnglishScore: "6.5",
});
assert.strictEqual(transformedLanguage.zhaopinCampusCet4Score, "616");
assert.strictEqual(transformedLanguage.zhaopinCampusCet6Score, "532");
assert.strictEqual(transformedLanguage.zhaopinCampusOtherEnglishExam, "示例资料");
assert.strictEqual(transformedLanguage.zhaopinCampusOtherEnglishScore, "6.5");
const 示例资料ExamField = 示例资料.fieldSequence.find((item) => item.field === "zhaopinCampusOtherEnglishExam");
assert.strictEqual(示例资料ExamField.verifyDisplayedSelection, true, "示例资料 selection must accept a real selected-item readback even when Element clears input.value");
const 示例资料ScoreField = 示例资料.fieldSequence.find((item) => item.field === "zhaopinCampusOtherEnglishScore");
assert(示例资料ScoreField && 示例资料ScoreField.optional !== true, "known 示例资料 score must not silently disappear after selecting 示例资料");
assert.strictEqual(示例资料ScoreField.type, "text");
assert.strictEqual(示例资料ScoreField.coreMatcherFirst, false, "示例资料 score is a plain input and must not be reclassified as the neighboring Element select");

const 示例资料 = 示例资料flow.steps.find((step) => step.name === "学生工作");
assert(示例资料, "学生工作 should be recognized");
assert.strictEqual(示例资料.category, "campusLeadership");
assert.strictEqual(示例资料.zhaopinRepeatNavigationAdapter, true);
const 示例资料Org = 示例资料.fieldSequence.find((item) => item.field === "示例资料Name");
assert.strictEqual(示例资料Org.optional, true, "CDB 示例资料-示例资料 section does not always expose organization name, so it must not block later rows");
const 示例资料Labels = 示例资料.fieldSequence.flatMap((item) => Array.isArray(item.label) ? item.label : [item.label]);
assert(示例资料Labels.includes("职务描述"));
assert(示例资料Labels.includes("开始日期"));
assert(示例资料Labels.includes("结束日期"));
const transformedStudent = 示例资料.rowTransform({ 示例资料Name: "fixture-org", title: "干事", startTime: "示例资料", endTime: "示例资料", startDate: "示例资料", endDate: "示例资料" });
assert.strictEqual(transformedStudent.zhaopinCampusStartDate, "示例资料");
assert.strictEqual(transformedStudent.zhaopinCampusEndDate, "示例资料");
const 示例资料Description = 示例资料.fieldSequence.find((item) => item.field === "description");
assert(示例资料Description && typeof 示例资料Description.valueTransform === "function", "CDB 示例资料-示例资料 description should apply the explicit 50-character site policy");
const oldLearningCommitteeDescription = "筹备学习经验交流活动，协调师兄师姐与班级同学；示例资料";
const approvedLearningCommitteeDescription = "示例资料";
assert.strictEqual(approvedLearningCommitteeDescription.length, 46);
assert.strictEqual(示例资料Description.valueTransform(oldLearningCommitteeDescription, { title: "示例资料" }), approvedLearningCommitteeDescription, "only the user-approved Learning Committee Member wording should be shortened");
assert.strictEqual(示例资料Description.valueTransform("示例资料", { title: "干事" }), "示例资料", "unrelated 示例资料-示例资料 descriptions must remain unchanged");
const overlongCombinedDescription = "示例资料；示例资料";
const existingRoleDescription = "示例资料";
assert(overlongCombinedDescription.length > 50 && existingRoleDescription.length <= 50);
assert.strictEqual(示例资料Description.valueTransform(overlongCombinedDescription, { title: "干事", roleDescription: existingRoleDescription }), existingRoleDescription, "when CDB's 50-character limit is exceeded, an existing canonical 本人职责 may be used without inventing or truncating facts");
assert.strictEqual(示例资料Description.valueTransform("这是一个超过五十字但没有可用本人职责的示例文本这是一个超过五十字但没有可用本人职责的示例文本这是一个超过五十字但没有可用本人职责的示例文本", { title: "干事" }).length > 50, true, "without an approved or existing <=50 alternative the adapter must not silently truncate");

const award = 示例资料flow.steps.find((step) => step.name === "奖励情况");
assert(award, "奖励情况 should be recognized");
assert.strictEqual(award.category, "示例资料");
assert.strictEqual(award.zhaopinRepeatNavigationAdapter, true);
const awardLabels = award.fieldSequence.flatMap((item) => Array.isArray(item.label) ? item.label : [item.label]);
assert(awardLabels.includes("获奖日期"));
assert(awardLabels.includes("颁发单位"));
const transformedAward = award.rowTransform({ awardName: "fixture-award", awardTime: "示例资料", awardDate: "示例资料" });
assert.strictEqual(transformedAward.zhaopinCampusAwardDate, "示例资料");

const 示例资料 = 示例资料flow.steps.find((step) => step.name === "家庭信息");
assert(示例资料, "家庭信息 should be recognized");
assert.strictEqual(示例资料.category, "示例资料Members");
assert.strictEqual(示例资料.zhaopinRepeatNavigationAdapter, true);

const specialty = 示例资料flow.steps.find((step) => step.name === "个人特长");
assert(specialty, "个人特长 should be recognized");
assert.strictEqual(specialty.category, "示例资料Info");
assert.strictEqual(specialty.fieldSequence.length, 1, "personal specialty must not rerun the whole 示例资料-info sequence");
assert.strictEqual(specialty.fieldSequence[0].field, "hobbies");

const adjustment = 示例资料flow.steps.find((step) => step.name === "是否服从调剂");
assert(adjustment, "是否服从调剂 should use the explicit job-示例资料 fact");
assert.strictEqual(adjustment.category, "jobIntention");
assert.strictEqual(adjustment.fieldSequence[0].field, "acceptAdjustment");

assert(!示例资料flow.steps.some((step) => step.name === "社会实践经历"), "social practice remains unmapped until a non-duplicating canonical source is confirmed");
assert(!示例资料flow.steps.some((step) => step.name === "高中示例资料"), "high school remains excluded from university rows");
console.log("zhaopin public 示例资料 sections: PASS");
