"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const gap = fs.readFileSync(path.join(root, "ai-gap-foundation.js"), "utf8");

assert(main.includes("prepareLocalFirstAiAssist"), "one-click local-first gate missing");
assert(main.includes("classifyLocalFirstRoute"), "local support classifier missing");
assert(main.includes("preparePostFillAiGapCandidate"), "post-fill AI Gap foundation missing");
assert(main.includes('candidateOnly: true'), "one-click starts candidate-only before Safety Gate re-entry");
assert(main.includes('generic_local_candidate_only'), "generic candidate-only route missing");
assert(main.includes('candidate_generated_for_controlled_reuse'), "Build159 candidate generation must advertise controlled later reuse");
assert(main.includes('ai_high_confidence_core_apply'), "Safety-Gate eligible candidates must be able to re-enter Core on a later run");
assert(gap.includes('autoApply: false') && gap.includes('autoExecute: false'), "AI Gap policy must prohibit automatic execution");
console.log("local-first-ai-routing.test.js PASS");
