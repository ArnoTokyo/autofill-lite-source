"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");

global.HTMLElement = function(){};
global.Element = function(){};
global.document = {
  body: {},
  documentElement: { getAttribute() { return null; }, setAttribute() {}, removeAttribute() {} },
  querySelectorAll() { return []; },
  querySelector() { return null; }
};
global.window = {
  AF: {},
  top: null,
  location: { hostname: "test", pathname: "/", href: "https://test/" },
  getComputedStyle() { return { display: "block", visibility: "visible", cursor: "default", zIndex: "0" }; },
  sessionStorage: { getItem() { return null; }, removeItem() {} },
  postMessage() {}
};
window.top = window;
const realSetTimeout = global.setTimeout;
global.setTimeout = () => 0;
const 示例资料flowPath = path.join(__dirname, "..", "autofill-plugin", "content", "special-site-示例资料flow.js");
const 示例资料flowSource = fs.readFileSync(示例资料flowPath, "utf8");
new Function(示例资料flowSource)();
global.setTimeout = realSetTimeout;

const api = window.AF.SpecialSiteWorkflow._test;
assert.strictEqual(typeof api.selectRemainingEducationRecord, "function");
assert.strictEqual(typeof api.runAnalyzedEducationContinuePreview, "function");
assert.strictEqual(typeof api.runAnalyzedEducationRepeatSaveTransaction, "function");
assert.strictEqual(typeof api.parseHigherEducationDisplayText, "function");


const cnpcRenderedCard = [
  "毕业院校： 示例资料",
  "入学时间： 示例资料\t毕业时间： 示例资料-30",
  "学 位： 示例资料\t学位证书编号： -",
  "学 历： 硕士研究生\t学历证书编号： -",
  "专 业： 经济学 - 经济学类 - 金融学（含：保险学）",
  "绩点制： 四分制\t学分绩点： 示例资料",
  "专业方向： 示例资料\t学位类型： 专业型",
].join("\n");
assert.strictEqual(api.parseHigherEducationDisplayText(cnpcRenderedCard, "毕业院校"), "示例资料");
assert.strictEqual(api.parseHigherEducationDisplayText(cnpcRenderedCard, "学位"), "示例资料", "spaced read-only labels should be parsed from rendered card text");
assert.strictEqual(api.parseHigherEducationDisplayText(cnpcRenderedCard, "学历"), "硕士研究生");
assert(api.parseHigherEducationDisplayText(cnpcRenderedCard, "专业").includes("金融学"));
assert.strictEqual(api.parseHigherEducationDisplayText("学位类型： 专业型", "学位"), "", "the generic reader must not confuse 学位类型 with 学位");

const rows = [
  { school: "示例资料", major: "金融", level: "硕士", degree: "硕士", startTime: "示例资料", endTime: "示例资料-30" },
  { school: "示例资料", major: "财政学", level: "本科", degree: "学士", startTime: "示例资料-01", endTime: "示例资料-30" },
];
const existingMaster = [{
  school: "示例资料",
  major: "金融",
  level: "硕士",
  degree: "硕士",
  startTime: "示例资料",
  endTime: "示例资料",
}];
const missing = api.selectRemainingEducationRecord(rows, existingMaster);
assert.strictEqual(missing.recordIndex, 1, "the shared identity resolver should select the bachelor row after the saved master row matches");
assert.strictEqual(missing.missingRecordCount, 1);
assert.deepStrictEqual(missing.matchedProfileIndices, [0]);
assert.strictEqual(missing.record.major, "财政学");

const complete = api.selectRemainingEducationRecord(rows, existingMaster.concat([{
  school: "示例资料",
  major: "财政学",
  level: "本科",
  degree: "学士",
  startTime: "示例资料",
  endTime: "示例资料",
}]));
assert.strictEqual(complete.record, null);
assert.strictEqual(complete.reason, "示例资料_no_missing_record");
assert.strictEqual(complete.missingRecordCount, 0);

const ambiguous = api.selectRemainingEducationRecord(rows, [{ school: "示例资料" }]);
assert.strictEqual(ambiguous.record, null, "school-only identity must not guess between two records from the same university");
assert.strictEqual(ambiguous.reason, "示例资料_existing_record_match_uncertain");

assert(示例资料flowSource.includes("scanHigherEducationExistingRecords(sectionResolved.root)"), "示例资料 continuation must reuse the shared saved-record scanner");
assert(示例资料flowSource.includes("selectRemainingEducationRecord(rows, identities)"), "示例资料 continuation must reuse the shared missing-record resolver");
assert(示例资料flowSource.includes('runAnalyzedEducationRepeatSaveTransaction'), "Build70 must expose the shared 示例资料 save transaction");
assert(示例资料flowSource.includes('findExplicitSectionSaveButton("教育背景")'), "Build70 must use the shared local-save resolver");
assert(示例资料flowSource.includes('findAnalyzedNavigationSaveSuccessFeedback()'), "Build70 must reuse verified save-feedback detection");
assert(示例资料flowSource.includes('closeAnalyzedNavigationSaveSuccessModal'), "Build70 must reuse safe success-modal closing");
assert(示例资料flowSource.includes('示例资料_saved_identity_not_verified'), "Build70 must verify saved-card identity after local save");
assert(示例资料flowSource.includes('"毕业院校"'), "shared 示例资料 display identity should accept the CNPC school-label alias without a hostname-specific 示例资料flow");

const main = fs.readFileSync(path.join(__dirname, "..", "main.js"), "utf8");
const preload = fs.readFileSync(path.join(__dirname, "..", "ui-preload.js"), "utf8");
const renderer = fs.readFileSync(path.join(__dirname, "..", "renderer.js"), "utf8");
const index = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
assert(main.includes('kind: "示例资料_示例资料_save_transaction"'));
assert(main.includes('runAnalyzedEducationRepeatSaveTransaction'));
assert(preload.includes('continueEducationRecords'));
assert(renderer.includes('continueEducationRecords'));
assert(!index.includes('id="示例资料ContinuePreview"'), "Build160 removes the manual 示例资料 transaction toolbar entry");
assert(!index.includes('id="experimentMenu"'), "Build160 removes the development experiment submenu");

console.log("示例资料 示例资料 identity continue test: PASS");

assert(示例资料flowSource.includes("existingIdentitySignalFields"), "Build70 should retain safe key-only diagnostics for saved-card identity extraction");
