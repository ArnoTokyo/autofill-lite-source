"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const matcher = fs.readFileSync(path.join(root, "autofill-plugin/content/element-matcher.js"), "utf8");
const siteTemplates = fs.readFileSync(path.join(root, "autofill-plugin/content/config/site-templates.js"), "utf8");

// Tencent deliberately merges generic fallbacks for *field labels* because some
// editor rows expose only native labels while most use `.subtitle`.
assert(siteTemplates.includes('labels: { class: ".subtitle", mergeFallback: true }'));

// That field-label fallback must never leak into section-title discovery. A
// configured `.send_title` selector is authoritative whenever it exists.
const findTitleStart = matcher.indexOf("ElementMatcher.prototype.findTitle = function ()");
const findTitleEnd = matcher.indexOf("// ---------- findAllLabels", findTitleStart);
assert(findTitleStart >= 0 && findTitleEnd > findTitleStart, "findTitle block missing");
const findTitleBlock = matcher.slice(findTitleStart, findTitleEnd);
assert(findTitleBlock.includes("if (byConfig && byConfig.length > 0) return scopeToActiveDialogIfAvailable(byConfig);"), "configured section titles must be authoritative");
assert(!findTitleBlock.includes("this.config.selectors.labels.mergeFallback"), "label mergeFallback must not affect title discovery");
assert(!findTitleBlock.includes("(SELECTORS.labels || []).concat([\"label\"])"), "findTitle must never append field labels to section titles");

// Keep the intended label fallback behavior inside record/section field scans.
const findLabelsStart = matcher.indexOf("ElementMatcher.prototype.findLabelsByCard = function");
const findLabelsEnd = matcher.indexOf("ElementMatcher.prototype", findLabelsStart + 20);
const findLabelsBlock = matcher.slice(findLabelsStart, findLabelsEnd > findLabelsStart ? findLabelsEnd : matcher.length);
assert(findLabelsBlock.includes("this.config.selectors.labels.mergeFallback"), "field-label fallback must remain available");
assert(findLabelsBlock.includes("fallbackSelectors"), "field-label fallback chain must remain intact");

console.log("tencent single-pass title routing test: PASS");
