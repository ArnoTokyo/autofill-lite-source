"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const root = path.join(__dirname, "..");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
assert(/const BUILD_ID = "202609\d{2}-.+-(?:14[7-9]|1[5-9]\d|[2-9]\d{2,})";/.test(main), "Build147+ compatible build ID missing");

const formSource = fs.readFileSync(path.join(root, "autofill-plugin/content/form-handler.js"), "utf8");
assert(formSource.includes('reasonCode: "manual_record_review_required"'), "manual review checkpoint missing");
assert(formSource.includes('acknowledgeMode: "resume_at_action_cursor"'), "Build148 action-cursor review mode missing");
assert(formSource.includes('fieldReplaySuppressed: true'), "review resume must suppress all pre-checkpoint field replay");
assert(formSource.includes('actionCursor: "SAVE"'), "review resume must advance to SAVE action cursor");
assert(formSource.includes('matches.length === 1 ? matches[0] : null'), "save action must require unique scoped match");

const runtimeSource = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-runtime.js"), "utf8");
assert(runtimeSource.includes('acknowledgeMode !== "resume_at_action_cursor"'), "action-cursor checkpoint must not pre-complete record on rerun");
assert(runtimeSource.includes('manualFields:'), "manual field list must persist in checkpoint");

// A. Universal checkpoint semantics: manual-review rerun keeps the record active,
// while the established manual-save checkpoint still acknowledges completion.
const coreSource = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-core.js"), "utf8");
const store = {};
const sandbox = {
  window: { AF: {}, location: { hostname: "example.test", pathname: "/resume", hash: "" } },
  chrome: { storage: { local: {
    get(keys, cb) { const out = {}; keys.forEach(k => { if (Object.prototype.hasOwnProperty.call(store, k)) out[k] = store[k]; }); cb(out); },
    set(payload, cb) { Object.assign(store, payload); cb && cb(); },
    remove(keys, cb) { keys.forEach(k => delete store[k]); cb && cb(); }
  } }, runtime: { lastError: null } },
  console, Date, Math, Promise, Set, setTimeout, clearTimeout
};
vm.createContext(sandbox);
vm.runInContext(coreSource, sandbox, { filename: "checkpoint-core.js" });
vm.runInContext(runtimeSource, sandbox, { filename: "checkpoint-runtime.js" });
const RT = sandbox.window.AF.CheckpointRuntime;
const CC = sandbox.window.AF.CheckpointCore;

(async () => {
  const loc = sandbox.window.location;
  const row = { school: "中国人民大学", level: "硕士", startTime: "2025-09" };
  const recordMeta = {
    category: "education", sectionTitle: "教育背景", repeatIndex: 0, repeatTotal: 1,
    row, recordFingerprint: CC.recordFingerprint(row)
  };

  const first = await RT.begin(loc, { workflowId: RT.WORKFLOW_ID });
  const firstRecord = RT.facade(first, "record");
  await firstRecord.pause(recordMeta, "学校、学位需要人工确认", {
    forceRecoverable: true,
    reasonCode: "manual_record_review_required",
    acknowledgeMode: "resume_at_action_cursor",
    nextAction: "SAVE",
    freezeBeforeCursor: true,
    manualFields: ["school", "degree"],
    committedFields: ["startTime"],
    failureContext: {
      workflowId: "autofill-core-formgraph-v1", stepName: "教育背景 第1条", category: "education",
      repeatIndex: 0, repeatTotal: 1, fieldKey: "repeatRecord", fieldLabel: "教育背景 第1条",
      phase: "manual_review", reasonCode: "manual_record_review_required", rawReason: "学校、学位需要人工确认",
      humanSummary: "教育背景 第1条有字段需要你人工确认", suggestedAction: "修改后再次运行",
      recoverability: "RECOVERABLE_MANUAL", recordFingerprint: recordMeta.recordFingerprint, granularity: "record"
    }
  });
  assert.strictEqual(store[RT.STORAGE_KEY].active.acknowledgeMode, "resume_at_action_cursor");
  assert.strictEqual(store[RT.STORAGE_KEY].active.nextAction, "SAVE");
  assert.strictEqual(store[RT.STORAGE_KEY].active.freezeBeforeCursor, true);
  assert.deepStrictEqual(Array.from(store[RT.STORAGE_KEY].active.manualFields), ["school", "degree"]);
  assert(store[RT.STORAGE_KEY].active.actionCursor, "structured actionCursor must be persisted");
  assert.strictEqual(store[RT.STORAGE_KEY].active.actionCursor.nextAction, "SAVE");

  const second = await RT.begin(loc, { workflowId: RT.WORKFLOW_ID });
  const secondRecord = RT.facade(second, "record");
  assert.strictEqual(secondRecord.shouldSkip(recordMeta), false, "manual-review rerun must keep same record active");
  assert.strictEqual(secondRecord.previousCheckpoint.reasonCode, "manual_record_review_required");

  await CC.markHumanOverride({ category: "education", recordIndex: 0, fieldKey: "school" }, "中国人民大学", "test");
  assert.strictEqual(await CC.hasHumanOverride({ category: "education", recordIndex: 0, fieldKey: "school" }), true, "human override ledger should persist during active recovery");
  await second.finalize();
  assert.strictEqual(await CC.hasHumanOverride({ category: "education", recordIndex: 0, fieldKey: "school" }), false, "human override ledger must clear when recovery chain finishes");

  const saveRun = await RT.begin(loc, { workflowId: RT.WORKFLOW_ID });
  const saveRecord = RT.facade(saveRun, "record");
  await saveRecord.pause(recordMeta, "当前经历已填写，仍需手动保存", { forceRecoverable: true, reasonCode: "manual_record_save_required" });
  const saveResume = await RT.begin(loc, { workflowId: RT.WORKFLOW_ID });
  assert.strictEqual(RT.facade(saveResume, "record").shouldSkip(recordMeta), true, "manual-save checkpoint must preserve existing rerun-acknowledges-completion semantics");

  console.log("build147-human-checkpoint-safe-resume.test.js PASS (runtime semantics)");
})().catch(err => { console.error(err); process.exit(1); });
