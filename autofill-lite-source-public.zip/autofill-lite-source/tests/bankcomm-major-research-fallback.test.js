"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const sites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
const workflow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-workflow.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");

const documentStub = { body: null, querySelector: () => null, documentElement: { setAttribute() {} } };
const windowStub = {
  AF: {},
  location: { href: "https://job.bankcomm.com/", hostname: "job.bankcomm.com", pathname: "/" },
  getComputedStyle: () => ({ display: "block", visibility: "visible" })
};
const context = { window: windowStub, document: documentStub, URL, console, setTimeout, clearTimeout };
vm.createContext(context);
vm.runInContext(sites, context);
const api = windowStub.AF.PrivateSpecialSites._test;
assert(api && typeof api.bankcommMajorPath === "function", "bankcommMajorPath test hook missing");
assert(typeof api.bankcommResearchPath === "function", "bankcommResearchPath test hook missing");
assert(typeof api.enrichBankcommEducationRow === "function", "enrichBankcommEducationRow test hook missing");

// A. User-confirmed Bankcomm major mapping must be deterministic.
const fiscalPath = Array.from(api.bankcommMajorPath("财政学", "", ""));
assert(JSON.stringify(fiscalPath) === JSON.stringify(["财政学类", "财政学"]), "A: 财政学 should map to 财政学类 → 财政学");

// B. An unknown research direction must never be semantically guessed into a different leaf.
const unknownResearch = Array.from(api.bankcommResearchPath({ researchDirection: "证券投资与金融管理", major: "财政学" }));
assert(unknownResearch.length === 0, "B: unknown research text must use official custom fallback instead of guessed 行业研究");

// C. Exact known Bankcomm research leaves remain supported.
const knownResearch = Array.from(api.bankcommResearchPath({ researchDirection: "行业研究" }));
assert(JSON.stringify(knownResearch) === JSON.stringify(["金融类", "研究类金融", "行业研究"]), "C: exact known research leaf should keep deterministic cascader path");

// D. Undergraduate: 财政学 must use the confirmed major path; no explicit research direction => custom “无”.
const enrichedUndergrad = api.enrichBankcommEducationRow({ level: "本科", major: "财政学", gpa: "3.23/4.0" });
assert(JSON.stringify(Array.from(enrichedUndergrad.bankcommMajor)) === JSON.stringify(["财政学类", "财政学"]), "D: undergraduate major path mismatch");
assert(Array.from(enrichedUndergrad.bankcommResearch).length === 0, "D: undergraduate custom research should not carry a guessed path");
assert(enrichedUndergrad.bankcommResearchCustom === "无", "D: undergraduate Bankcomm research custom value should be 无");

// E. Master's: 金融/金融学 must use 金融学类 → 金融学; unknown explicit research direction is preserved verbatim.
const financePath = Array.from(api.bankcommMajorPath("金融", "", ""));
assert(JSON.stringify(financePath) === JSON.stringify(["金融学类", "金融学"]), "E: 金融 should map to 金融学类 → 金融学");
const enrichedMaster = api.enrichBankcommEducationRow({ level: "硕士", major: "金融", researchDirection: "证券投资与金融管理", gpa: "3.61/4.0" });
assert(JSON.stringify(Array.from(enrichedMaster.bankcommMajor)) === JSON.stringify(["金融学类", "金融学"]), "E: master's major path mismatch");
assert(Array.from(enrichedMaster.bankcommResearch).length === 0, "E: master's custom research should not carry a guessed path");
assert(enrichedMaster.bankcommResearchCustom === "证券投资与金融管理", "E: master's custom research text must be preserved");

// F. Production workflow must use the site-provided checkbox branch before generic search/cascader fallback.
assert(workflow.includes("fillBankcommResearchCustomValue"), "F: Bankcomm official research custom filler missing");
assert(workflow.includes("fallbackCheckboxText"), "F: research fallback checkbox contract missing");
assert(workflow.includes("若未找到，请填写研究方向"), "F: site-provided research fallback label missing");
const customBranch = workflow.indexOf("fillBankcommResearchCustomValue(");
const searchBranch = workflow.indexOf("bankcommSchoolTrigger && hasMeaningfulValue(bankcommSchoolName)", customBranch);
assert(customBranch !== -1 && searchBranch > customBranch, "F: official custom branch must run before research search/cascader fallback");

// G. Build assertion must follow the current main.js BUILD_ID rather than pinning a historical patch.
const buildMatch = main.match(/const BUILD_ID = "([^"]+)"/);
assert(buildMatch && /-\d+$/.test(buildMatch[1]), "G: current BUILD_ID missing or malformed");
console.log("bankcomm-major-research-fallback.test.js passed (A-G)");
