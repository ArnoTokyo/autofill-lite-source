"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");

global.HTMLElement = function(){};
global.Element = function(){};
global.document = {
  body: {},
  documentElement: { getAttribute() { return null; }, setAttribute() {}, removeAttribute() {} },
  querySelectorAll() { return []; },
  querySelector() { return null; }
};
global.window = {
  AF: {},
  top: null,
  location: { hostname: "test", pathname: "/", href: "https://test/" },
  getComputedStyle() { return { display: "block", visibility: "visible", cursor: "default", zIndex: "0" }; },
  sessionStorage: { getItem() { return null; }, removeItem() {} },
  postMessage() {}
};
window.top = window;
const realSetTimeout = global.setTimeout;
global.setTimeout = () => 0;
const 示例资料flowPath = path.join(__dirname, "..", "autofill-plugin", "content", "special-site-示例资料flow.js");
const source = fs.readFileSync(示例资料flowPath, "utf8");
new Function(source)();
global.setTimeout = realSetTimeout;

const api = window.AF.SpecialSiteWorkflow._test;
assert.strictEqual(typeof api.runAnalyzedSectionAddEditorProbe, "function", "generic section editor probe must be exported");
assert.strictEqual(typeof api.runAnalyzedResumeSectionEditorSurvey, "function", "multi-section survey must be exported");
assert(source.includes("runAnalyzedSectionAddEditorProbe({"), "survey must reuse the generic section editor probe");
assert(source.includes("partial_stopped_open_editor"), "survey must stop if an editor is left open");

const surveyStart = source.indexOf("async function runAnalyzedResumeSectionEditorSurvey");
const surveyEnd = source.indexOf("function analyzedEducationPreviewNormalizeProvince", surveyStart);
const surveySource = source.slice(surveyStart, surveyEnd);
assert(!surveySource.includes("fillFormElement"), "multi-section survey must not fill values");
assert(!surveySource.includes("保存教育背景"), "multi-section survey must not contain a save action");
assert(!surveySource.includes("findExplicitSectionSaveButton"), "multi-section survey must not resolve or click local save controls");

const main = fs.readFileSync(path.join(__dirname, "..", "main.js"), "utf8");
const preload = fs.readFileSync(path.join(__dirname, "..", "ui-preload.js"), "utf8");
const renderer = fs.readFileSync(path.join(__dirname, "..", "renderer.js"), "utf8");
const index = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
assert(main.includes('kind: "resume_section_editor_survey"'));
assert(main.includes('"外语水平", "通讯信息", "实习/工作/入伍经历", "获奖信息", "家庭成员", "其他资格"'));
assert(main.includes("loadLatestAnalyzedMultiSectionSurveyPlan"));
assert(preload.includes("surveyResumeSectionEditors"));
assert(renderer.includes("surveyResumeSectionEditors"));
assert(!index.includes('id="multiSectionSurvey"'), "Build160 removes the manual survey toolbar entry");
assert(!index.includes('id="experimentMenu"'), "Build160 removes the development experiment submenu");

console.log("multi-section editor survey test: PASS");
