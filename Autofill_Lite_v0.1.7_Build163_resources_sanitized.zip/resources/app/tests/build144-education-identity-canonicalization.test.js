"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
assert(/const BUILD_ID = "202609\d{2}-.+-1(?:4[4-9]|[5-9]\d|\d{3,})";/.test(main), 'current build must preserve Build144+ 示例资料 identity invariants');

global.location = {
  href: "https://zhaopin.cnpc.com.cn/web/createResume.html",
  hostname: "zhaopin.cnpc.com.cn",
  pathname: "/web/createResume.html"
};
global.getComputedStyle = () => ({ display: "block", visibility: "visible", opacity: "1" });
global.document = {};
global.window = { location: global.location, AF: {} };

const RecordGraph = require(path.join(root, "autofill-plugin", "content", "record-graph.js"));

function input(value) {
  return {
    tagName: "INPUT",
    value: value || "",
    isConnected: true,
    getBoundingClientRect() { return { width: 120, height: 26, left: 0, top: 0 }; },
    matches() { return false; },
    querySelector() { return null; }
  };
}

function select(displayText, rawValue) {
  const option = { textContent: displayText, value: rawValue || displayText };
  return {
    tagName: "SELECT",
    value: rawValue || displayText,
    selectedOptions: [option],
    isConnected: true,
    getBoundingClientRect() { return { width: 120, height: 26, left: 0, top: 0 }; },
    matches() { return false; },
    querySelector() { return null; }
  };
}

function makeContainer(selectorMap) {
  const nodes = Object.values(selectorMap).flat();
  const doc = { querySelectorAll(selector) { return selectorMap[selector] || []; } };
  nodes.forEach((node) => { node.ownerDocument = doc; });
  return {
    ownerDocument: doc,
    isConnected: true,
    getBoundingClientRect() { return { width: 800, height: 600, left: 0, top: 0 }; },
    contains(node) { return nodes.includes(node); }
  };
}

const config = { _aiSemanticPatch: { sectionMappings: [{ label: "教育背景", category: "示例资料" }] } };
const mappings = [
  { category: "示例资料", fieldKey: "school", selector: "#school" },
  { category: "示例资料", fieldKey: "level", selector: "#level" },
  { category: "示例资料", fieldKey: "startTime", selector: "#start" }
];

// Real CNPC case: bachelor and master are from the same school. Canonical profile
// stores level as `硕士`, while the page renders `硕士研究生`. Raw equality used by
// Build143 returned record_identity_not_found; field-aware identity must bind master.
const rows = [
  { school: "示例资料", level: "硕士", startTime: "示例资料" },
  { school: "示例资料", level: "本科", startTime: "示例资料-01" }
];
const container = makeContainer({
  "#school": [input("示例资料")],
  "#level": [select("硕士研究生", "03")],
  "#start": [input("示例资料")]
});
let owner = RecordGraph.resolveRuntimeEditorOwnership(container, "示例资料", {
  sectionTitle: "教育背景",
  siteConfig: config,
  mappings,
  profileRecords: rows,
  isRecordCompleted() { return false; }
});
assert.strictEqual(owner.status, "owned");
assert.strictEqual(owner.recordIndex, 0);
assert.strictEqual(owner.ownershipMode, "identity_match");

// Date precision is also an identity formatting detail, not a different record.
const dateOnlyMappings = [
  { category: "示例资料", fieldKey: "school", selector: "#school" },
  { category: "示例资料", fieldKey: "startTime", selector: "#start" }
];
const dateContainer = makeContainer({
  "#school": [input("示例资料")],
  "#start": [input("示例资料")]
});
owner = RecordGraph.resolveRuntimeEditorOwnership(dateContainer, "示例资料", {
  sectionTitle: "教育背景",
  siteConfig: config,
  mappings: dateOnlyMappings,
  profileRecords: rows,
  isRecordCompleted() { return false; }
});
assert.strictEqual(owner.status, "owned");
assert.strictEqual(owner.recordIndex, 0);

// A real conflict must remain a hard ownership failure. Same school + bachelor page
// must never be rebound to the master's profile row.
const bachelorOnlyRows = [{ school: "示例资料", level: "硕士", startTime: "示例资料" }];
const conflictContainer = makeContainer({
  "#school": [input("示例资料")],
  "#level": [select("本科", "02")],
  "#start": [input("示例资料-01")]
});
owner = RecordGraph.resolveRuntimeEditorOwnership(conflictContainer, "示例资料", {
  sectionTitle: "教育背景",
  siteConfig: config,
  mappings,
  profileRecords: bachelorOnlyRows,
  isRecordCompleted() { return false; }
});
assert.strictEqual(owner.status, "record_identity_not_found");
assert(owner.identityTrace);
assert.strictEqual(owner.identityTrace.primaryMatchCount, 1);
assert.strictEqual(owner.identityTrace.combinedMatchCount, 0);

console.log("build144-示例资料-identity-canonicalization.test.js PASS");
