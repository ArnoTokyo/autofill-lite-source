"use strict";

const { ipcRenderer } = require("electron");

function safeParse(raw) {
  try { return JSON.parse(raw); } catch (_) { return null; }
}

function respond(node, payload) {
  try {
    node.setAttribute("data-response", JSON.stringify(payload || { success: false, error: "EMPTY_RESPONSE" }));
    node.dispatchEvent(new Event("offer-trusted-autocomplete-response", { bubbles: true }));
  } catch (_) {}
}

function handleTrustedRequest(event) {
  const node = event && event.target;
  if (!node || !node.getAttribute) return;
  const request = safeParse(node.getAttribute("data-request") || "");
  if (!request || !request.action) return;
  ipcRenderer.invoke("lite:trusted-input", request)
    .then((result) => respond(node, result))
    .catch((error) => respond(node, { success: false, error: String(error && error.message || error) }));
}

document.addEventListener("offer-trusted-autocomplete-request", handleTrustedRequest, true);

window.addEventListener("DOMContentLoaded", () => {
  try {
    document.documentElement.setAttribute("data-autofill-lite-guest", "true");
  } catch (_) {}
});
