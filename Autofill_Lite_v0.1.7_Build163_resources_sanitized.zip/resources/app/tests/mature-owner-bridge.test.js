"use strict";
const assert = require("assert");
const path = require("path");
const root = path.resolve(__dirname, "..");

global.window = { AF: {} };
global.document = { body: null, querySelectorAll: () => [] };
global.location = { href: "https://xiaoyuan.zhaopin.com/scrd/resume2", hostname: "xiaoyuan.zhaopin.com", pathname: "/scrd/resume2" };
const collectorPath = path.join(root, "autofill-plugin", "content", "site-analysis-collector.js");
delete require.cache[require.resolve(collectorPath)];
require(collectorPath);
const collector = global.window.AF.SiteAnalysisCollector;

// SiteLoader private configs may shadow the mature public template. Analyzer
// must recover only the public template's structural EDIT knowledge, preserving
// card ownership so a title-level Add icon is never treated as Edit.
global.window.AF.SITE_TEMPLATES = {
  "xiaoyuan.zhaopin.com": {
    selectors: {
      container: { class: ".apply-module" },
      title: { class: ".form-content--title" }
    },
    experience: {
      container: { containerSelector: ".apply-module" },
      card: { cardSelector: ".apply-form" },
      editor: {
        cardEditButtonSelector: ".icon-box:not(.icon-box-disabled)",
        cardEditButtonText: ["编辑", "Edit", "修改"]
      }
    }
  }
};
const builtIn = {
  name: "xiaoyuan.zhaopin.com/scrd/resume2",
  selectors: {
    container: { class: ".apply-module" },
    title: { class: ".form-content--title" },
    buttons: { edit: { class: ".apply-module button" } }
  }
};
const probe = collector.buildMatureInteractiveProbeOptions(builtIn, null, 0);
assert.strictEqual(probe.publicTemplateOverlay, true);
assert.strictEqual(probe.explicitEditConfig, true);
assert.strictEqual(probe.options.allowSingleModule, true);
assert.strictEqual(probe.options.cardSelector, ".apply-form");
assert(probe.options.openAction.selectors.includes(".apply-form .icon-box:not(.icon-box-disabled)"));
assert(!probe.options.openAction.selectors.includes(".form-content--title-box .icon-box"), "Add surface must not be promoted to EDIT");

// The mature runtime owns a frame示例资料 widget at its wrapper, while the static
// scanner may see the inner input. Containment must bridge them deterministically.
const field = { rect: { x: 419, y: 464, width: 656, height: 26 } };
const controls = [
  { fieldId: "owner", rect: { x: 411, y: 461, width: 695, height: 32 } },
  { fieldId: "示例资料", rect: { x: 411, y: 800, width: 695, height: 32 } }
];
const candidates = collector.logicalOwnerGeometryCandidates(field, controls);
assert.strictEqual(candidates.length, 1);
assert.strictEqual(candidates[0].control.fieldId, "owner");
assert.strictEqual(candidates[0].contains, true);

console.log("mature owner bridge regression: PASS");
