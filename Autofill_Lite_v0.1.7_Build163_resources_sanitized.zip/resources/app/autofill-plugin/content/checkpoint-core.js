// Shared checkpoint/failure/ledger foundation for Autofill Core.
// Build131 extraction only: this module must not decide page actions or expand
// which 示例资料flows are eligible for recovery. Site/runtime code remains the
// authority for execution, ownership and save transactions.
(function () {
  "use strict";

  var AF = (window.AF = window.AF || {});
  if (AF.CheckpointCore) return;

  var MANUAL_CHECKPOINT_STORAGE_KEY = "offerAutofillManualCheckpointV2";
  var RECOVERY_CHECKPOINT_STORAGE_KEY = "offerAutofillRecoveryCheckpointV2";
  var EXECUTION_LEDGER_STORAGE_KEY = "offerAutofillExecutionLedgerV1";
  var FORM_FIELD_CHECKPOINT_STORAGE_KEY = "offerAutofillFormFieldCheckpointV1";
  var FORM_FIELD_LEDGER_STORAGE_KEY = "offerAutofillFormFieldLedgerV1";
  var FORM_RECORD_CHECKPOINT_STORAGE_KEY = "offerAutofillFormRecordCheckpointV1";
  var FORM_RECORD_LEDGER_STORAGE_KEY = "offerAutofillFormRecordLedgerV1";
  // Build135: RECORD checkpoint semantics changed after Build134.  Old v1
  // markers promoted inline-filled records too aggressively and could skip fresh
  // Moka sections on the next run.  Treat record recovery state as a versioned
  // recovery-session artifact rather than a permanent completion cache.
  var FORM_RECORD_POLICY_VERSION = 2;
  var DEFAULT_TTL_MS = 24 * 60 * 60 * 1000;

  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, "").replace(/[：:*＊]/g, "").trim();
  }

  function normalizeSectionTitle(value) {
    return normalizeText(value)
      .replace(/[\uE000-\uF8FF]/g, "")
      .replace(/（必填）|\(必填\)|待完善|已完善|未完善/g, "")
      .replace(/[：:]\s*$/g, "")
      .trim();
  }

  function storageGet(keys) {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(keys, function (result) { resolve(result || {}); });
      } catch (e) { resolve({}); }
    });
  }

  function storageSet(payload) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.storage.local.set(payload, function () {
          if (chrome.runtime && chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve();
        });
      } catch (e) { reject(e); }
    });
  }

  function storageRemove(keys) {
    return new Promise(function (resolve) {
      try { chrome.storage.local.remove(keys, function () { resolve(); }); }
      catch (e) { resolve(); }
    });
  }

  function 示例资料flowId(示例资料flow) {
    return String(示例资料flow && (示例资料flow.id || 示例资料flow.name) || "");
  }

  function routeKey(locationLike) {
    var loc = locationLike || window.location;
    var hash = String(loc && loc.hash || "").split("?")[0];
    return String(loc && loc.pathname || "/") + hash;
  }

  function hash(value) {
    var text = String(value || "");
    var current = 2166136261;
    for (var i = 0; i < text.length; i++) {
      current ^= text.charCodeAt(i);
      current = Math.imul(current, 16777619);
    }
    return ("00000000" + (current >>> 0).toString(16)).slice(-8);
  }

  function recordFingerprint(row) {
    if (!row || typeof row !== "object") return "";
    var keys = [
      "school", "degree", "示例资料Level", "startDate", "endDate", "startTime", "endTime",
      "company", "position", "department", "name", "示例资料Name", "title", "awardName", "示例资料"
    ];
    var parts = keys.map(function (key) {
      return key + "=" + normalizeText(row[key] == null ? "" : row[key]);
    }).filter(function (part) { return !/=\s*$/.test(part); });
    return parts.length ? hash(parts.join("|")) : "";
  }

  function stepRecordFingerprint(step) {
    var row = step && Array.isArray(step.dataOverride) ? step.dataOverride[0] : null;
    return recordFingerprint(row);
  }

  function stepKey(step) {
    if (!step) return "";
    var title = normalizeSectionTitle(step.cardTitle || step.name || "");
    var category = Array.isArray(step.category)
      ? step.category.join("+")
      : String(step.categoryOverride || step.category || "");
    return hash(title + "|" + category);
  }

  function primaryFailureFromResult(result) {
    var failures = result && Array.isArray(result.failedFields) ? result.failedFields : [];
    return failures.find(function (item) { return item && (item.reason || item.label || item.fieldKey); }) || null;
  }

  // Build153: stable failure taxonomy shared by Special Workflow and generic Core.
  // recoverability still decides whether execution may resume; failureClass only
  // explains what kind of gap occurred and must never grant extra execution rights.
  var FAILURE_CLASSES = Object.freeze({
    SEMANTIC_UNKNOWN: "SEMANTIC_UNKNOWN",
    CONTROL_UNSUPPORTED: "CONTROL_UNSUPPORTED",
    VALUE_NOT_AVAILABLE: "VALUE_NOT_AVAILABLE",
    RECORD_OWNER_UNKNOWN: "RECORD_OWNER_UNKNOWN",
    VALIDATION_FAILED: "VALIDATION_FAILED",
    MANUAL_UPLOAD_REQUIRED: "MANUAL_UPLOAD_REQUIRED",
    MANUAL_SELECTION_REQUIRED: "MANUAL_SELECTION_REQUIRED",
    TRANSACTION_UNSAFE: "TRANSACTION_UNSAFE",
    TRANSIENT_CONTROL_STATE: "TRANSIENT_CONTROL_STATE",
    MANUAL_ACTION_REQUIRED: "MANUAL_ACTION_REQUIRED",
    UNKNOWN: "UNKNOWN"
  });

  function classifyFailureClass(step, errorMessage, result, recoverabilityHint) {
    var primary = primaryFailureFromResult(result) || {};
    var reason = String(primary.reason || errorMessage || "");
    var label = String(primary.label || primary.fieldKey || "");
    var combined = reason + " " + String(errorMessage || "") + " " + label;
    if (/ownership|record[_ ]?owner|selector_ownership|identity_not_committed|index_unresolved|duplicate_示例资料_scope|示例资料_section_(?:not_resolved|scope_not_resolved)|current_module_scope_not_resolved|无法安全确认.*记录|记录归属/i.test(combined)) return FAILURE_CLASSES.RECORD_OWNER_UNKNOWN;
    if (/record_save_state_unknown|保存未成功|表单仍处于编辑态|找不到保存按钮|退出编辑|save.*unknown|transaction|提交状态|保存状态/i.test(combined)) return FAILURE_CLASSES.TRANSACTION_UNSAFE;
    if (/上传|附件|upload|attachment/i.test(combined)) return FAILURE_CLASSES.MANUAL_UPLOAD_REQUIRED;
    if (/简历(?:中)?缺少|资料.*缺少|缺少.*资料|没有提供|未提供.*资料|value.*missing/i.test(combined)) return FAILURE_CLASSES.VALUE_NOT_AVAILABLE;
    if (/校验提示|字数|字符数|内容长度|长度超过|不能超过|最多.{0,8}(?:字|字符)|格式|必填字段|validation/i.test(combined)) return FAILURE_CLASSES.VALIDATION_FAILED;
    if (/下拉.*失败|候选未展开|请选择|选项.*失败|人工选择|manual.*select/i.test(combined)) return FAILURE_CLASSES.MANUAL_SELECTION_REQUIRED;
    if (/日期.*失败|控件.*(?:失败|不支持)|unsupported.*control|control.*unsupported|弹层.*失败|picker.*failed/i.test(combined)) return FAILURE_CLASSES.CONTROL_UNSUPPORTED;
    if (/未找到字段标签|语义.*未知|semantic.*unknown|字段.*无法识别|unknown.*field/i.test(combined)) return FAILURE_CLASSES.SEMANTIC_UNKNOWN;
    if (/等待超时|暂时不可用|重绘|popup|transient/i.test(combined)) return FAILURE_CLASSES.TRANSIENT_CONTROL_STATE;
    if (String(recoverabilityHint || "") === "RECOVERABLE_MANUAL") return FAILURE_CLASSES.MANUAL_ACTION_REQUIRED;
    return FAILURE_CLASSES.UNKNOWN;
  }

  function classifyRecoverableFailure(step, errorMessage, result) {
    var primary = primaryFailureFromResult(result);
    var reason = String(primary && primary.reason || errorMessage || "");
    var combined = reason + " " + String(errorMessage || "");
    if (/校验提示|字数|字符数|内容长度|长度超过|超过.{0,8}(?:字|字符)|不能超过|最多.{0,8}(?:字|字符)|格式|必填字段|请选择/i.test(combined)) {
      return { recoverability: "RECOVERABLE_MANUAL", reasonCode: "manual_validation_required" };
    }
    var unsafe = /ownership|duplicate_示例资料_scope|record_count_mismatch|current_module_scope_not_resolved|示例资料_section_not_resolved|示例资料_section_scope_not_resolved|示例资料_record_(?:not_committed|index_unresolved|no_fields_committed|identity_not_committed)|record_save_state_unknown|selector_ownership_ambiguous|找不到表单容器|保存未成功|表单仍处于编辑态|找不到保存按钮|保存后|退出编辑|不会自动保存|未找到对应经历卡片|重复经历数量不足|无法安全确认|editor_not_open|scope_not_resolved/i;
    if (unsafe.test(combined)) {
      return { recoverability: "UNSAFE_STOP", reasonCode: "unsafe_execution_state" };
    }
    if (/等待超时|弹层|popup|重绘|暂时不可用/i.test(combined)) {
      return { recoverability: "SAFE_AUTO_RETRY", reasonCode: "transient_control_state" };
    }
    if (/简历(?:中)?缺少|资料.*缺少|缺少.*资料|上传|附件|验证码|字数|长度|格式|日期.*失败|下拉.*失败|候选未展开|未找到字段标签|依赖字段填写未完成|请选择|必填字段|校验/i.test(combined)) {
      return { recoverability: "RECOVERABLE_MANUAL", reasonCode: "manual_field_completion_required" };
    }
    return { recoverability: "UNSAFE_STOP", reasonCode: "unclassified_failure" };
  }

  function buildFailureContext(示例资料flow, step, errorMessage, result) {
    var primary = primaryFailureFromResult(result) || {};
    var reason = String(primary.reason || errorMessage || "当前步骤未完成");
    var stepName = String(step && (step.cardTitle || step.name || step.category) || "当前步骤");
    var label = String(primary.label || primary.fieldKey || "");
    var classification = classifyRecoverableFailure(step, errorMessage, result);
    var humanSummary = "当前步骤没有成功完成";
    var suggestedAction = "请检查当前打开的表单，确认页面要求后再继续。";
    if (/上传|附件/.test(reason)) {
      humanSummary = (label ? label + "需要人工上传或确认" : "当前步骤需要人工上传文件");
      suggestedAction = "请在网页中完成上传并保存，然后再次点击“一键填写”。";
    } else if (/简历(?:中)?缺少|资料.*缺少|缺少.*资料/.test(reason)) {
      humanSummary = label ? "资料库缺少：“" + label + "”" : "资料库缺少当前步骤需要的信息";
      suggestedAction = "请补充资料库，或在网页中手动填写并保存后再次运行。";
    } else if (/日期.*失败/.test(reason)) {
      humanSummary = label ? label + "没有成功填写" : "日期字段没有成功填写";
      suggestedAction = "请手动选择正确日期并保存当前记录，然后再次点击“一键填写”。";
    } else if (/下拉.*失败|候选未展开|请选择|未找到字段标签/.test(reason)) {
      humanSummary = label ? label + "没有成功选择" : "当前下拉选项没有成功选择";
      suggestedAction = "请手动完成这个选项并保存当前记录，然后再次点击“一键填写”。";
    } else if (/字数|长度|格式|校验/.test(reason)) {
      humanSummary = label ? label + "不符合网站填写要求" : "当前内容不符合网站填写要求";
      suggestedAction = "请按网页提示修改内容并保存，然后再次点击“一键填写”。";
    } else if (/依赖字段填写未完成|必填字段/.test(reason)) {
      humanSummary = stepName + "还有必填项未完成";
      suggestedAction = "请检查当前打开的表单，补齐必填项并保存后再次运行。";
    } else if (classification.recoverability === "SAFE_AUTO_RETRY") {
      humanSummary = stepName + "遇到临时页面状态问题";
      suggestedAction = "可以稍后再次点击“一键填写”，程序会从这个位置重试。";
    } else if (classification.recoverability === "UNSAFE_STOP") {
      humanSummary = stepName + "的页面状态无法安全确认";
      suggestedAction = "为避免覆盖已有内容，程序已停止自动操作；请先人工检查当前页面。";
    }
    var sequenceActionCursor = result && result.sequenceActionCursor && typeof result.sequenceActionCursor === "object"
      ? Object.assign({}, result.sequenceActionCursor)
      : null;
    if (sequenceActionCursor && classification.recoverability === "RECOVERABLE_MANUAL") {
      suggestedAction = label
        ? "请只手动完成“" + label + "”，暂时不要保存当前记录；完成后再次点击“一键填写”，程序会从检查点后的动作继续。"
        : "请只处理当前失败动作，暂时不要保存当前记录；完成后再次点击“一键填写”，程序会从检查点后的动作继续。";
    }
    return {
      示例资料flowId: 示例资料flowId(示例资料flow),
      stepIndex: Number.isInteger(step && step.__afWorkflowStepIndex) ? step.__afWorkflowStepIndex : -1,
      stepName: stepName,
      category: Array.isArray(step && step.category) ? step.category.join("+") : String(step && (step.categoryOverride || step.category) || ""),
      示例资料Index: Number.isInteger(Number(step && step.示例资料Index)) ? Number(step.示例资料Index) : -1,
      示例资料Total: Number(step && step.示例资料Total || 0),
      fieldKey: String(primary.fieldKey || ""),
      fieldLabel: label,
      phase: /保存/.test(String(errorMessage || "")) ? "save" : "fill",
      reasonCode: classification.reasonCode,
      failureClass: classifyFailureClass(step, errorMessage, result, classification.recoverability),
      rawReason: reason.slice(0, 240),
      humanSummary: humanSummary,
      suggestedAction: suggestedAction,
      recoverability: classification.recoverability,
      recordFingerprint: stepRecordFingerprint(step),
      acknowledgeMode: sequenceActionCursor ? "resume_at_action_cursor" : "skip_failed_step",
      actionCursor: sequenceActionCursor
    };
  }

  function validAge(marker, ttlMs) {
    return Date.now() - Number(marker && marker.updatedAt || 0) <= Number(ttlMs || DEFAULT_TTL_MS);
  }

  async function loadManualCheckpoint(示例资料flow, locationLike) {
    try {
      var stored = await storageGet([MANUAL_CHECKPOINT_STORAGE_KEY]);
      var marker = stored && stored[MANUAL_CHECKPOINT_STORAGE_KEY];
      var loc = locationLike || window.location;
      if (!marker || typeof marker !== "object") return null;
      if (String(marker.示例资料flowId || "") !== 示例资料flowId(示例资料flow)) return null;
      if (String(marker.hostname || "") !== String(loc && loc.hostname || "")) return null;
      if (String(marker.pathname || "") !== String(loc && loc.pathname || "")) return null;
      if (!validAge(marker)) { await storageRemove([MANUAL_CHECKPOINT_STORAGE_KEY]); return null; }
      return marker;
    } catch (e) { return null; }
  }

  async function saveManualCheckpoint(示例资料flow, step, phase, detail, locationLike) {
    try {
      var loc = locationLike || window.location;
      var marker = {
        示例资料flowId: 示例资料flowId(示例资料flow),
        hostname: String(loc && loc.hostname || ""),
        pathname: String(loc && loc.pathname || ""),
        stepIndex: Number.isInteger(step && step.__afWorkflowStepIndex) ? step.__afWorkflowStepIndex : -1,
        stepName: String(step && (step.name || step.cardTitle || step.category) || ""),
        category: String(step && step.category || ""),
        phase: String(phase || "manual_step"),
        reason: String(detail && detail.reason || detail || "manual_action_required"),
        status: "waiting_manual",
        updatedAt: Date.now()
      };
      var payload = {}; payload[MANUAL_CHECKPOINT_STORAGE_KEY] = marker;
      await storageSet(payload);
      return marker;
    } catch (e) { return null; }
  }

  async function clearManualCheckpoint() { await storageRemove([MANUAL_CHECKPOINT_STORAGE_KEY]); }

  async function loadRecoveryCheckpoint(示例资料flow, locationLike) {
    try {
      var stored = await storageGet([RECOVERY_CHECKPOINT_STORAGE_KEY]);
      var marker = stored && stored[RECOVERY_CHECKPOINT_STORAGE_KEY];
      var loc = locationLike || window.location;
      if (!marker || typeof marker !== "object") return null;
      if (String(marker.status || "") !== "waiting_recovery") return null;
      if (String(marker.示例资料flowId || "") !== 示例资料flowId(示例资料flow)) return null;
      if (String(marker.hostname || "") !== String(loc && loc.hostname || "")) return null;
      if (String(marker.routeKey || "") !== routeKey(loc)) return null;
      if (!validAge(marker)) { await storageRemove([RECOVERY_CHECKPOINT_STORAGE_KEY]); return null; }
      return marker;
    } catch (e) { return null; }
  }

  async function saveRecoveryCheckpoint(示例资料flow, step, failureContext, completedState, locationLike) {
    try {
      var loc = locationLike || window.location;
      var marker = {
        version: 3,
        acknowledgeOnRerun: true,
        示例资料flowId: 示例资料flowId(示例资料flow),
        hostname: String(loc && loc.hostname || ""),
        routeKey: routeKey(loc),
        stepIndex: Number.isInteger(step && step.__afWorkflowStepIndex) ? step.__afWorkflowStepIndex : -1,
        stepName: String(step && (step.cardTitle || step.name || step.category) || ""),
        stepKey: stepKey(step),
        category: Array.isArray(step && step.category) ? step.category.join("+") : String(step && (step.categoryOverride || step.category) || ""),
        示例资料Index: Number.isInteger(Number(step && step.示例资料Index)) ? Number(step.示例资料Index) : -1,
        示例资料GroupKey: String(step && step.示例资料GroupKey || ""),
        recordFingerprint: String(failureContext && failureContext.recordFingerprint || stepRecordFingerprint(step) || ""),
        reasonCode: String(failureContext && failureContext.reasonCode || "recoverable_failure"),
        failureClass: String(failureContext && failureContext.failureClass || classifyFailureClass(step, failureContext && failureContext.rawReason || "", null, failureContext && failureContext.recoverability)),
        humanSummary: String(failureContext && failureContext.humanSummary || "当前步骤需要人工处理"),
        suggestedAction: String(failureContext && failureContext.suggestedAction || "请处理当前步骤后再次运行"),
        recoverability: String(failureContext && failureContext.recoverability || "RECOVERABLE_MANUAL"),
        acknowledgeMode: String(failureContext && failureContext.acknowledgeMode || "skip_failed_step"),
        actionCursor: failureContext && failureContext.actionCursor && typeof failureContext.actionCursor === "object"
          ? Object.assign({}, failureContext.actionCursor)
          : null,
        completedStepIndexes: Array.isArray(completedState && completedState.stepIndexes) ? completedState.stepIndexes.slice(0, 100) : [],
        completedRepeatIndexes: completedState && completedState.示例资料Indexes && typeof completedState.示例资料Indexes === "object" ? Object.assign({}, completedState.示例资料Indexes) : {},
        status: "waiting_recovery",
        updatedAt: Date.now()
      };
      var payload = {}; payload[RECOVERY_CHECKPOINT_STORAGE_KEY] = marker;
      await storageSet(payload);
      return marker;
    } catch (e) { return null; }
  }

  async function clearRecoveryCheckpoint() { await storageRemove([RECOVERY_CHECKPOINT_STORAGE_KEY]); }

  function newLedger(示例资料flow, locationLike) {
    var loc = locationLike || window.location;
    return {
      version: 1,
      observeOnly: true,
      示例资料flowId: 示例资料flowId(示例资料flow),
      hostname: String(loc && loc.hostname || ""),
      routeKey: routeKey(loc),
      completedStepKeys: [],
      completedRecords: {},
      updatedAt: Date.now()
    };
  }

  async function loadExecutionLedger(示例资料flow, locationLike) {
    try {
      var stored = await storageGet([EXECUTION_LEDGER_STORAGE_KEY]);
      var ledger = stored && stored[EXECUTION_LEDGER_STORAGE_KEY];
      var loc = locationLike || window.location;
      if (!ledger || typeof ledger !== "object") return newLedger(示例资料flow, loc);
      if (String(ledger.示例资料flowId || "") !== 示例资料flowId(示例资料flow) ||
          String(ledger.hostname || "") !== String(loc && loc.hostname || "") ||
          String(ledger.routeKey || "") !== routeKey(loc) || !validAge(ledger)) {
        return newLedger(示例资料flow, loc);
      }
      ledger.observeOnly = true;
      ledger.completedStepKeys = Array.isArray(ledger.completedStepKeys) ? ledger.completedStepKeys.slice(0, 200) : [];
      ledger.completedRecords = ledger.completedRecords && typeof ledger.completedRecords === "object" ? Object.assign({}, ledger.completedRecords) : {};
      return ledger;
    } catch (e) { return newLedger(示例资料flow, locationLike); }
  }

  async function saveExecutionLedger(ledger) {
    if (!ledger || typeof ledger !== "object") return null;
    try {
      ledger.updatedAt = Date.now();
      var payload = {}; payload[EXECUTION_LEDGER_STORAGE_KEY] = ledger;
      await storageSet(payload);
      return ledger;
    } catch (e) { return null; }
  }

  function markStepCompleted(ledger, step) {
    if (!ledger || !step) return ledger;
    var key = stepKey(step);
    if (key && ledger.completedStepKeys.indexOf(key) === -1) ledger.completedStepKeys.push(key);
    var fp = stepRecordFingerprint(step);
    if (fp) {
      ledger.completedRecords[fp] = {
        stepKey: key,
        category: Array.isArray(step.category) ? step.category.join("+") : String(step.categoryOverride || step.category || ""),
        示例资料Index: Number.isInteger(Number(step.示例资料Index)) ? Number(step.示例资料Index) : -1,
        status: "completed",
        updatedAt: Date.now()
      };
    }
    ledger.updatedAt = Date.now();
    return ledger;
  }

  function snapshotExecutionLedger(ledger) {
    if (!ledger || typeof ledger !== "object") return null;
    return {
      version: Number(ledger.version || 1),
      observeOnly: true,
      示例资料flowId: String(ledger.示例资料flowId || ""),
      hostname: String(ledger.hostname || ""),
      routeKey: String(ledger.routeKey || ""),
      completedStepCount: Array.isArray(ledger.completedStepKeys) ? ledger.completedStepKeys.length : 0,
      completedRecordCount: ledger.completedRecords && typeof ledger.completedRecords === "object" ? Object.keys(ledger.completedRecords).length : 0,
      completedStepKeys: Array.isArray(ledger.completedStepKeys) ? ledger.completedStepKeys.slice(0, 100) : [],
      recordFingerprints: ledger.completedRecords && typeof ledger.completedRecords === "object" ? Object.keys(ledger.completedRecords).slice(0, 100) : [],
      updatedAt: Number(ledger.updatedAt || 0)
    };
  }

  // ---- Generic FormGraph field-level checkpoint foundation (Build132) ----
  // Unlike special-示例资料flow checkpoints, these markers are scoped to ordinary
  // scalar fields only. Rerunning Autofill is the user's acknowledgement that
  // the failed field was handled manually; no second-guessing/readback is done.
  function formFieldToken(meta) {
    meta = meta || {};
    var category = String(meta.category || "");
    var fieldKey = String(meta.fieldKey || "");
    var occurrence = Number.isInteger(Number(meta.occurrence)) ? Number(meta.occurrence) : 0;
    return hash(category + "|" + fieldKey + "|" + occurrence);
  }


  function formRecordToken(meta) {
    meta = meta || {};
    var category = String(meta.category || "");
    var fingerprint = String(meta.recordFingerprint || recordFingerprint(meta.row || {}));
    var section = normalizeSectionTitle(meta.sectionTitle || meta.label || "");
    return fingerprint ? hash(category + "|" + fingerprint) : hash(category + "|" + section + "|" + Number(meta.示例资料Index || 0));
  }

  function newFormRecordLedger(locationLike) {
    var loc = locationLike || window.location;
    return {
      version: FORM_RECORD_POLICY_VERSION,
      policyVersion: FORM_RECORD_POLICY_VERSION,
      granularity: "record",
      observeOnly: false,
      示例资料flowId: "autofill-core-formgraph-v1",
      hostname: String(loc && loc.hostname || ""),
      routeKey: routeKey(loc),
      completedRecordTokens: [],
      updatedAt: Date.now()
    };
  }

  async function loadFormRecordCheckpoint(locationLike) {
    try {
      var stored = await storageGet([FORM_RECORD_CHECKPOINT_STORAGE_KEY]);
      var marker = stored && stored[FORM_RECORD_CHECKPOINT_STORAGE_KEY];
      var loc = locationLike || window.location;
      if (!marker || typeof marker !== "object") return null;
      // Build135 migration barrier: Build133/134 record checkpoints/ledgers used
      // policy v1 and may contain tokens for records that were only present in
      // transient React state.  Never resume those markers after the policy
      // change; clear both halves of the old recovery session atomically.
      if (Number(marker.policyVersion || marker.version || 0) !== FORM_RECORD_POLICY_VERSION) {
        await storageRemove([FORM_RECORD_CHECKPOINT_STORAGE_KEY, FORM_RECORD_LEDGER_STORAGE_KEY]);
        return null;
      }
      if (String(marker.status || "") !== "waiting_recovery") return null;
      if (String(marker.hostname || "") !== String(loc && loc.hostname || "")) return null;
      if (String(marker.routeKey || "") !== routeKey(loc)) return null;
      if (!validAge(marker)) { await storageRemove([FORM_RECORD_CHECKPOINT_STORAGE_KEY, FORM_RECORD_LEDGER_STORAGE_KEY]); return null; }
      return marker;
    } catch (e) { return null; }
  }

  async function clearFormRecordCheckpoint() {
    await storageRemove([FORM_RECORD_CHECKPOINT_STORAGE_KEY]);
  }

  async function clearFormRecordLedger() {
    await storageRemove([FORM_RECORD_LEDGER_STORAGE_KEY]);
  }

  async function loadFormRecordLedger(locationLike, preserveExisting) {
    var loc = locationLike || window.location;
    if (!preserveExisting) return newFormRecordLedger(loc);
    try {
      var stored = await storageGet([FORM_RECORD_LEDGER_STORAGE_KEY]);
      var ledger = stored && stored[FORM_RECORD_LEDGER_STORAGE_KEY];
      if (!ledger || typeof ledger !== "object") return newFormRecordLedger(loc);
      if (Number(ledger.policyVersion || ledger.version || 0) !== FORM_RECORD_POLICY_VERSION ||
          String(ledger.hostname || "") !== String(loc && loc.hostname || "") ||
          String(ledger.routeKey || "") !== routeKey(loc) || !validAge(ledger)) {
        await storageRemove([FORM_RECORD_LEDGER_STORAGE_KEY]);
        return newFormRecordLedger(loc);
      }
      ledger.version = FORM_RECORD_POLICY_VERSION;
      ledger.policyVersion = FORM_RECORD_POLICY_VERSION;
      ledger.granularity = "record";
      ledger.observeOnly = false;
      ledger.completedRecordTokens = Array.isArray(ledger.completedRecordTokens) ? ledger.completedRecordTokens.slice(0, 500) : [];
      return ledger;
    } catch (e) { return newFormRecordLedger(loc); }
  }

  async function saveFormRecordLedger(ledger) {
    if (!ledger || typeof ledger !== "object") return null;
    try {
      ledger.updatedAt = Date.now();
      var payload = {}; payload[FORM_RECORD_LEDGER_STORAGE_KEY] = ledger;
      await storageSet(payload);
      return ledger;
    } catch (e) { return null; }
  }

  function markFormRecordCompleted(ledger, meta) {
    if (!ledger || !meta) return ledger;
    var token = formRecordToken(meta);
    if (token && ledger.completedRecordTokens.indexOf(token) === -1) ledger.completedRecordTokens.push(token);
    ledger.updatedAt = Date.now();
    return ledger;
  }

  function buildFormRecordFailureContext(meta, rawReason) {
    meta = meta || {};
    var section = String(meta.sectionTitle || meta.label || meta.category || "当前经历");
    var 示例资料Index = Number.isInteger(Number(meta.示例资料Index)) ? Number(meta.示例资料Index) : -1;
    var display = 示例资料Index >= 0 ? section + " 第" + (示例资料Index + 1) + "条" : section;
    return {
      示例资料flowId: "autofill-core-formgraph-v1",
      stepIndex: -1,
      stepName: display,
      category: String(meta.category || ""),
      示例资料Index: 示例资料Index,
      示例资料Total: Number(meta.示例资料Total || 0),
      fieldKey: "示例资料Record",
      fieldLabel: display,
      phase: "save",
      reasonCode: "manual_record_save_required",
      failureClass: FAILURE_CLASSES.MANUAL_ACTION_REQUIRED,
      rawReason: String(rawReason || "当前经历已填写，仍需手动保存").slice(0, 240),
      humanSummary: "当前经历已填写，但还需要你手动保存",
      suggestedAction: "请保存当前经历；保存完成后再次点击“一键填写”，程序会从后续经历/分区继续。",
      recoverability: "RECOVERABLE_MANUAL",
      recordFingerprint: String(meta.recordFingerprint || recordFingerprint(meta.row || {})),
      granularity: "record",
      recordToken: formRecordToken(meta)
    };
  }

  async function saveFormRecordCheckpoint(meta, failureContext, ledger, locationLike) {
    try {
      var loc = locationLike || window.location;
      var marker = {
        version: FORM_RECORD_POLICY_VERSION,
        policyVersion: FORM_RECORD_POLICY_VERSION,
        acknowledgeOnRerun: true,
        granularity: "record",
        示例资料flowId: "autofill-core-formgraph-v1",
        hostname: String(loc && loc.hostname || ""),
        routeKey: routeKey(loc),
        category: String(meta && meta.category || ""),
        sectionTitle: String(meta && meta.sectionTitle || meta && meta.label || ""),
        示例资料Index: Number.isInteger(Number(meta && meta.示例资料Index)) ? Number(meta.示例资料Index) : -1,
        示例资料Total: Number(meta && meta.示例资料Total || 0),
        recordFingerprint: String(meta && meta.recordFingerprint || recordFingerprint(meta && meta.row || {})),
        recordToken: formRecordToken(meta),
        reasonCode: String(failureContext && failureContext.reasonCode || "manual_record_save_required"),
        failureClass: String(failureContext && failureContext.failureClass || FAILURE_CLASSES.MANUAL_ACTION_REQUIRED),
        humanSummary: String(failureContext && failureContext.humanSummary || "当前经历需要人工保存"),
        suggestedAction: String(failureContext && failureContext.suggestedAction || "请保存当前经历后再次运行"),
        recoverability: "RECOVERABLE_MANUAL",
        completedRecordTokens: ledger && Array.isArray(ledger.completedRecordTokens) ? ledger.completedRecordTokens.slice(0, 500) : [],
        status: "waiting_recovery",
        updatedAt: Date.now()
      };
      var payload = {}; payload[FORM_RECORD_CHECKPOINT_STORAGE_KEY] = marker;
      await storageSet(payload);
      return marker;
    } catch (e) { return null; }
  }

  function snapshotFormRecordLedger(ledger) {
    if (!ledger || typeof ledger !== "object") return null;
    return {
      version: Number(ledger.version || FORM_RECORD_POLICY_VERSION),
      policyVersion: Number(ledger.policyVersion || FORM_RECORD_POLICY_VERSION),
      granularity: "record",
      observeOnly: false,
      示例资料flowId: "autofill-core-formgraph-v1",
      hostname: String(ledger.hostname || ""),
      routeKey: String(ledger.routeKey || ""),
      completedRecordCount: Array.isArray(ledger.completedRecordTokens) ? ledger.completedRecordTokens.length : 0,
      completedRecordTokens: Array.isArray(ledger.completedRecordTokens) ? ledger.completedRecordTokens.slice(0, 100) : [],
      updatedAt: Number(ledger.updatedAt || 0)
    };
  }

  async function beginFormRecordRun(locationLike, options) {
    var loc = locationLike || window.location;
    options = options || {};
    var checkpoint = await loadFormRecordCheckpoint(loc);
    var siblingFieldCheckpoint = await loadFormFieldCheckpoint(loc);
    var ledger = await loadFormRecordLedger(loc, !!checkpoint || !!siblingFieldCheckpoint || !!options.preserveExistingLedger);
    var runtime = {
      enabled: true,
      granularity: "record",
      resumed: !!checkpoint,
      checkpointResolved: !!checkpoint,
      checkpointCreated: false,
      paused: false,
      previousCheckpoint: checkpoint || null,
      resumeRecordToken: String(checkpoint && checkpoint.recordToken || ""),
      resumeRecordSeen: false,
      completedRecordTokens: new Set(Array.isArray(checkpoint && checkpoint.completedRecordTokens) ? checkpoint.completedRecordTokens : (ledger && Array.isArray(ledger.completedRecordTokens) ? ledger.completedRecordTokens : [])),
      ledger: ledger,
      failureContext: null,
      checkpoint: null
    };
    if (checkpoint) await clearFormRecordCheckpoint();
    await saveFormRecordLedger(ledger);
    runtime.tokenFor = formRecordToken;
    runtime.shouldSkip = function (meta) {
      var token = formRecordToken(meta);
      if (!token) return false;
      if (runtime.completedRecordTokens.has(token)) return true;
      if (runtime.resumeRecordToken && token === runtime.resumeRecordToken) {
        runtime.resumeRecordSeen = true;
        // Build134: rerun it示例资料 is the user's acknowledgement that the paused
        // record has been handled. Promote that record into the durable ledger
        // immediately, 示例资料wise a second checkpoint in the same run forgets
        // the first acknowledged record and may execute it again next time.
        runtime.completedRecordTokens.add(token);
        markFormRecordCompleted(runtime.ledger, meta);
        saveFormRecordLedger(runtime.ledger);
        return true;
      }
      return false;
    };
    runtime.markCompleted = async function (meta) {
      var token = formRecordToken(meta);
      if (token) runtime.completedRecordTokens.add(token);
      markFormRecordCompleted(runtime.ledger, meta);
      await saveFormRecordLedger(runtime.ledger);
    };
    runtime.pause = async function (meta, rawReason) {
      if (runtime.paused) return runtime.checkpoint;
      runtime.failureContext = buildFormRecordFailureContext(meta, rawReason);
      runtime.checkpoint = await saveFormRecordCheckpoint(meta, runtime.failureContext, runtime.ledger, loc);
      runtime.checkpointCreated = !!runtime.checkpoint;
      runtime.paused = true;
      return runtime.checkpoint;
    };
    return runtime;
  }

  function snapshotFormRecordRuntime(runtime) {
    if (!runtime || typeof runtime !== "object") return null;
    return {
      enabled: true,
      granularity: "record",
      resumed: !!runtime.resumed,
      checkpointResolved: !!runtime.checkpointResolved,
      checkpointCreated: !!runtime.checkpointCreated,
      paused: !!runtime.paused,
      resumeRecordSeen: !!runtime.resumeRecordSeen,
      ledger: snapshotFormRecordLedger(runtime.ledger)
    };
  }

  function newFormFieldLedger(locationLike) {
    var loc = locationLike || window.location;
    return {
      version: 1,
      granularity: "field",
      observeOnly: false,
      示例资料flowId: "autofill-core-formgraph-v1",
      hostname: String(loc && loc.hostname || ""),
      routeKey: routeKey(loc),
      completedFieldTokens: [],
      updatedAt: Date.now()
    };
  }

  async function loadFormFieldCheckpoint(locationLike) {
    try {
      var stored = await storageGet([FORM_FIELD_CHECKPOINT_STORAGE_KEY]);
      var marker = stored && stored[FORM_FIELD_CHECKPOINT_STORAGE_KEY];
      var loc = locationLike || window.location;
      if (!marker || typeof marker !== "object") return null;
      if (String(marker.status || "") !== "waiting_recovery") return null;
      if (String(marker.hostname || "") !== String(loc && loc.hostname || "")) return null;
      if (String(marker.routeKey || "") !== routeKey(loc)) return null;
      if (!validAge(marker)) { await storageRemove([FORM_FIELD_CHECKPOINT_STORAGE_KEY]); return null; }
      return marker;
    } catch (e) { return null; }
  }

  async function clearFormFieldCheckpoint() {
    await storageRemove([FORM_FIELD_CHECKPOINT_STORAGE_KEY]);
  }

  async function loadFormFieldLedger(locationLike, preserveExisting) {
    var loc = locationLike || window.location;
    if (!preserveExisting) return newFormFieldLedger(loc);
    try {
      var stored = await storageGet([FORM_FIELD_LEDGER_STORAGE_KEY]);
      var ledger = stored && stored[FORM_FIELD_LEDGER_STORAGE_KEY];
      if (!ledger || typeof ledger !== "object") return newFormFieldLedger(loc);
      if (String(ledger.hostname || "") !== String(loc && loc.hostname || "") ||
          String(ledger.routeKey || "") !== routeKey(loc) || !validAge(ledger)) {
        return newFormFieldLedger(loc);
      }
      ledger.granularity = "field";
      ledger.observeOnly = false;
      ledger.completedFieldTokens = Array.isArray(ledger.completedFieldTokens) ? ledger.completedFieldTokens.slice(0, 500) : [];
      return ledger;
    } catch (e) { return newFormFieldLedger(loc); }
  }

  async function saveFormFieldLedger(ledger) {
    if (!ledger || typeof ledger !== "object") return null;
    try {
      ledger.updatedAt = Date.now();
      var payload = {}; payload[FORM_FIELD_LEDGER_STORAGE_KEY] = ledger;
      await storageSet(payload);
      return ledger;
    } catch (e) { return null; }
  }

  function markFormFieldCompleted(ledger, meta) {
    if (!ledger || !meta) return ledger;
    var token = formFieldToken(meta);
    if (token && ledger.completedFieldTokens.indexOf(token) === -1) ledger.completedFieldTokens.push(token);
    ledger.updatedAt = Date.now();
    return ledger;
  }

  function buildFormFieldFailureContext(meta, rawReason) {
    meta = meta || {};
    var label = String(meta.label || meta.fieldKey || "当前字段");
    var reason = String(rawReason || "普通字段没有成功填写");
    return {
      示例资料flowId: "autofill-core-formgraph-v1",
      stepIndex: -1,
      stepName: label,
      category: String(meta.category || ""),
      示例资料Index: -1,
      示例资料Total: 0,
      fieldKey: String(meta.fieldKey || ""),
      fieldLabel: label,
      phase: "fill",
      reasonCode: "manual_field_completion_required",
      failureClass: classifyFailureClass({ category: meta.category || "" }, reason, { failedFields: [{ fieldKey: meta.fieldKey || "", label: label, reason: reason }] }, "RECOVERABLE_MANUAL"),
      rawReason: reason.slice(0, 240),
      humanSummary: label + "没有成功填写",
      suggestedAction: "请手动完成这个字段；处理后再次点击“一键填写”，程序会从后续普通字段继续。",
      recoverability: "RECOVERABLE_MANUAL",
      recordFingerprint: "",
      granularity: "field",
      fieldToken: formFieldToken(meta)
    };
  }

  async function saveFormFieldCheckpoint(meta, failureContext, ledger, locationLike) {
    try {
      var loc = locationLike || window.location;
      var marker = {
        version: 1,
        acknowledgeOnRerun: true,
        granularity: "field",
        示例资料flowId: "autofill-core-formgraph-v1",
        hostname: String(loc && loc.hostname || ""),
        routeKey: routeKey(loc),
        category: String(meta && meta.category || ""),
        fieldKey: String(meta && meta.fieldKey || ""),
        fieldLabel: String(meta && meta.label || ""),
        fieldToken: formFieldToken(meta),
        occurrence: Number.isInteger(Number(meta && meta.occurrence)) ? Number(meta.occurrence) : 0,
        controlType: String(meta && meta.controlType || ""),
        reasonCode: String(failureContext && failureContext.reasonCode || "manual_field_completion_required"),
        failureClass: String(failureContext && failureContext.failureClass || FAILURE_CLASSES.MANUAL_ACTION_REQUIRED),
        humanSummary: String(failureContext && failureContext.humanSummary || "当前字段需要人工处理"),
        suggestedAction: String(failureContext && failureContext.suggestedAction || "请手动处理当前字段后再次运行"),
        recoverability: "RECOVERABLE_MANUAL",
        completedFieldTokens: ledger && Array.isArray(ledger.completedFieldTokens) ? ledger.completedFieldTokens.slice(0, 500) : [],
        status: "waiting_recovery",
        updatedAt: Date.now()
      };
      var payload = {}; payload[FORM_FIELD_CHECKPOINT_STORAGE_KEY] = marker;
      await storageSet(payload);
      return marker;
    } catch (e) { return null; }
  }

  function snapshotFormFieldLedger(ledger) {
    if (!ledger || typeof ledger !== "object") return null;
    return {
      version: Number(ledger.version || 1),
      granularity: "field",
      observeOnly: false,
      示例资料flowId: "autofill-core-formgraph-v1",
      hostname: String(ledger.hostname || ""),
      routeKey: String(ledger.routeKey || ""),
      completedFieldCount: Array.isArray(ledger.completedFieldTokens) ? ledger.completedFieldTokens.length : 0,
      completedFieldTokens: Array.isArray(ledger.completedFieldTokens) ? ledger.completedFieldTokens.slice(0, 100) : [],
      updatedAt: Number(ledger.updatedAt || 0)
    };
  }

  async function beginFormFieldRun(locationLike, options) {
    var loc = locationLike || window.location;
    options = options || {};
    var checkpoint = await loadFormFieldCheckpoint(loc);
    var siblingRecordCheckpoint = await loadFormRecordCheckpoint(loc);
    var ledger = await loadFormFieldLedger(loc, !!checkpoint || !!siblingRecordCheckpoint || !!options.preserveExistingLedger);
    var runtime = {
      enabled: true,
      granularity: "field",
      resumed: !!checkpoint,
      checkpointResolved: !!checkpoint,
      checkpointCreated: false,
      paused: false,
      previousCheckpoint: checkpoint || null,
      resumeFieldToken: String(checkpoint && checkpoint.fieldToken || ""),
      resumeFieldSeen: false,
      completedFieldTokens: new Set(Array.isArray(checkpoint && checkpoint.completedFieldTokens) ? checkpoint.completedFieldTokens : (ledger && Array.isArray(ledger.completedFieldTokens) ? ledger.completedFieldTokens : [])),
      ledger: ledger,
      failureContext: null,
      checkpoint: null
    };
    if (checkpoint) await clearFormFieldCheckpoint();
    // A fresh generic run starts a fresh field ledger. A resumed run preserves
    // exactly the fields completed before the checkpoint.
    await saveFormFieldLedger(ledger);
    runtime.tokenFor = formFieldToken;
    runtime.shouldSkip = function (meta) {
      var token = formFieldToken(meta);
      if (!token) return false;
      if (runtime.completedFieldTokens.has(token)) return true;
      if (runtime.resumeFieldToken && token === runtime.resumeFieldToken) {
        runtime.resumeFieldSeen = true;
        return true;
      }
      return false;
    };
    runtime.markCompleted = async function (meta) {
      var token = formFieldToken(meta);
      if (token) runtime.completedFieldTokens.add(token);
      markFormFieldCompleted(runtime.ledger, meta);
      await saveFormFieldLedger(runtime.ledger);
    };
    runtime.pause = async function (meta, rawReason) {
      if (runtime.paused) return runtime.checkpoint;
      runtime.failureContext = buildFormFieldFailureContext(meta, rawReason);
      runtime.checkpoint = await saveFormFieldCheckpoint(meta, runtime.failureContext, runtime.ledger, loc);
      runtime.checkpointCreated = !!runtime.checkpoint;
      runtime.paused = true;
      return runtime.checkpoint;
    };
    return runtime;
  }

  function snapshotFormFieldRuntime(runtime) {
    if (!runtime || typeof runtime !== "object") return null;
    return {
      enabled: true,
      granularity: "field",
      resumed: !!runtime.resumed,
      checkpointResolved: !!runtime.checkpointResolved,
      checkpointCreated: !!runtime.checkpointCreated,
      paused: !!runtime.paused,
      resumeFieldSeen: !!runtime.resumeFieldSeen,
      ledger: snapshotFormFieldLedger(runtime.ledger)
    };
  }


  // Build146: Human Override Ledger. This ledger records values that were
  // explicitly completed/confirmed by a user after automation paused. It is
  // 示例资料ally separate from completedFieldTokens because automation
  // completion and human confirmation have different meanings.
  var HUMAN_OVERRIDE_STORAGE_KEY = "autofill_lite_human_override_ledger_v1";

  function newHumanOverrideLedger(locationLike) {
    var loc = locationLike || window.location;
    return {
      version: 1,
      示例资料flowId: "autofill-core-human-override-v1",
      hostname: String(loc && loc.hostname || ""),
      routeKey: routeKey(loc),
      items: [],
      updatedAt: Date.now()
    };
  }

  async function loadHumanOverrideLedger(locationLike) {
    try {
      var loc = locationLike || window.location;
      var stored = await storageGet([HUMAN_OVERRIDE_STORAGE_KEY]);
      var ledger = stored && stored[HUMAN_OVERRIDE_STORAGE_KEY];
      if (!ledger || typeof ledger !== "object") return newHumanOverrideLedger(loc);
      if (String(ledger.hostname || "") !== String(loc && loc.hostname || "") ||
          String(ledger.routeKey || "") !== routeKey(loc) || !validAge(ledger)) {
        return newHumanOverrideLedger(loc);
      }
      ledger.items = Array.isArray(ledger.items) ? ledger.items.slice(0, 1000) : [];
      return ledger;
    } catch (e) {
      return newHumanOverrideLedger(locationLike);
    }
  }

  async function saveHumanOverrideLedger(ledger) {
    if (!ledger || typeof ledger !== "object") return null;
    try {
      ledger.updatedAt = Date.now();
      var payload = {};
      payload[HUMAN_OVERRIDE_STORAGE_KEY] = ledger;
      await storageSet(payload);
      return ledger;
    } catch (e) { return null; }
  }

  function humanOverrideToken(meta) {
    meta = meta || {};
    return [
      meta.category || "",
      meta.recordIndex == null ? "" : String(meta.recordIndex),
      meta.fieldKey || meta.label || ""
    ].join("::");
  }

  async function markHumanOverride(meta, value, reason) {
    var ledger = await loadHumanOverrideLedger(window.location);
    var token = humanOverrideToken(meta);
    if (!token) return null;
    var existing = null;
    ledger.items.forEach(function (item) {
      if (item && item.token === token) existing = item;
    });
    var item = existing || { token: token };
    item.category = String(meta.category || "");
    item.recordIndex = Number.isInteger(Number(meta.recordIndex)) ? Number(meta.recordIndex) : -1;
    item.fieldKey = String(meta.fieldKey || "");
    item.label = String(meta.label || "");
    item.value = value;
    item.state = "HUMAN_CONFIRMED";
    item.reason = String(reason || "manual_confirmation");
    item.updatedAt = Date.now();
    if (!existing) ledger.items.push(item);
    await saveHumanOverrideLedger(ledger);
    return item;
  }

  async function getHumanOverride(meta) {
    var ledger = await loadHumanOverrideLedger(window.location);
    var token = humanOverrideToken(meta);
    for (var i = 0; i < ledger.items.length; i++) {
      var item = ledger.items[i];
      if (item && item.token === token && item.state === "HUMAN_CONFIRMED") return item;
    }
    return null;
  }

  async function hasHumanOverride(meta) {
    return !!(await getHumanOverride(meta));
  }

  async function clearHumanOverrideLedger() {
    try {
      await storageRemove([HUMAN_OVERRIDE_STORAGE_KEY]);
      return true;
    } catch (e) { return false; }
  }

  AF.CheckpointCore = {
    version: 1,
    MANUAL_CHECKPOINT_STORAGE_KEY: MANUAL_CHECKPOINT_STORAGE_KEY,
    RECOVERY_CHECKPOINT_STORAGE_KEY: RECOVERY_CHECKPOINT_STORAGE_KEY,
    EXECUTION_LEDGER_STORAGE_KEY: EXECUTION_LEDGER_STORAGE_KEY,
    FORM_FIELD_CHECKPOINT_STORAGE_KEY: FORM_FIELD_CHECKPOINT_STORAGE_KEY,
    FORM_FIELD_LEDGER_STORAGE_KEY: FORM_FIELD_LEDGER_STORAGE_KEY,
    FORM_RECORD_CHECKPOINT_STORAGE_KEY: FORM_RECORD_CHECKPOINT_STORAGE_KEY,
    FORM_RECORD_LEDGER_STORAGE_KEY: FORM_RECORD_LEDGER_STORAGE_KEY,
    FORM_RECORD_POLICY_VERSION: FORM_RECORD_POLICY_VERSION,
    HUMAN_OVERRIDE_STORAGE_KEY: HUMAN_OVERRIDE_STORAGE_KEY,
    loadHumanOverrideLedger: loadHumanOverrideLedger,
    saveHumanOverrideLedger: saveHumanOverrideLedger,
    markHumanOverride: markHumanOverride,
    getHumanOverride: getHumanOverride,
    hasHumanOverride: hasHumanOverride,
    clearHumanOverrideLedger: clearHumanOverrideLedger,
    routeKey: routeKey,
    hash: hash,
    recordFingerprint: recordFingerprint,
    stepRecordFingerprint: stepRecordFingerprint,
    stepKey: stepKey,
    primaryFailureFromResult: primaryFailureFromResult,
    FAILURE_CLASSES: FAILURE_CLASSES,
    classifyFailureClass: classifyFailureClass,
    classifyRecoverableFailure: classifyRecoverableFailure,
    buildFailureContext: buildFailureContext,
    loadManualCheckpoint: loadManualCheckpoint,
    saveManualCheckpoint: saveManualCheckpoint,
    clearManualCheckpoint: clearManualCheckpoint,
    loadRecoveryCheckpoint: loadRecoveryCheckpoint,
    saveRecoveryCheckpoint: saveRecoveryCheckpoint,
    clearRecoveryCheckpoint: clearRecoveryCheckpoint,
    loadExecutionLedger: loadExecutionLedger,
    saveExecutionLedger: saveExecutionLedger,
    markStepCompleted: markStepCompleted,
    snapshotExecutionLedger: snapshotExecutionLedger,
    formFieldToken: formFieldToken,
    formRecordToken: formRecordToken,
    loadFormFieldCheckpoint: loadFormFieldCheckpoint,
    clearFormFieldCheckpoint: clearFormFieldCheckpoint,
    loadFormFieldLedger: loadFormFieldLedger,
    saveFormFieldLedger: saveFormFieldLedger,
    markFormFieldCompleted: markFormFieldCompleted,
    buildFormFieldFailureContext: buildFormFieldFailureContext,
    saveFormFieldCheckpoint: saveFormFieldCheckpoint,
    snapshotFormFieldLedger: snapshotFormFieldLedger,
    beginFormFieldRun: beginFormFieldRun,
    snapshotFormFieldRuntime: snapshotFormFieldRuntime,
    loadFormRecordCheckpoint: loadFormRecordCheckpoint,
    clearFormRecordCheckpoint: clearFormRecordCheckpoint,
    clearFormRecordLedger: clearFormRecordLedger,
    loadFormRecordLedger: loadFormRecordLedger,
    saveFormRecordLedger: saveFormRecordLedger,
    markFormRecordCompleted: markFormRecordCompleted,
    buildFormRecordFailureContext: buildFormRecordFailureContext,
    saveFormRecordCheckpoint: saveFormRecordCheckpoint,
    snapshotFormRecordLedger: snapshotFormRecordLedger,
    beginFormRecordRun: beginFormRecordRun,
    snapshotFormRecordRuntime: snapshotFormRecordRuntime
  };
})();
