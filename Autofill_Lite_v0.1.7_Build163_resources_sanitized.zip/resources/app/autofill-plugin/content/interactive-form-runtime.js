// content/interactive-form-runtime.js
// 普通站点交互式表单发现运行时。
//
// 负责：
//   1. 识别“展示卡片 -> 点击编辑/修改 -> 才出现真实表单”的页面；
//   2. 用事务记录点击前后的 DOM，等待目标表单稳定渲染；
//   3. 采集展开后的表单 DOM，并在能够精准定位时关闭本次打开的编辑面；
//   4. 生成交互式 AI 分析包；
//   5. 向填写引擎提供统一的打开/结束事务接口。
//
// 安全边界：
//   - 静态表单优先，本运行时只做补充；
//   - 默认只预探测“编辑/修改/展开/完善”，不预探测“新增/添加”；
//   - 不点击保存、下一步、提交、投递、删除；
//   - 不使用浏览器历史返回；
//   - 找不到精准关闭动作时宁可保留展开，也不全局寻找“取消/关闭”。
(function () {
  "use strict";

  var AF = (window.AF = window.AF || {});

  var RUNTIME_VERSION = "1.0.6";
  var SCHEMA_VERSION = 1;
  var DEFAULT_OPTIONS = {
    enabled: true,
    staticFirst: true,
    fallbackToLegacy: true,
    allowEditProbe: true,
    allowAddProbe: false,
    allowPageNavigation: false,
    allowNavigationActions: false,
    maxModules: 20,
    maxWaitMs: 10000,
    quietWindowMs: 400,
    fingerprintIntervalMs: 160,
    maxModuleHtmlChars: 18000,
    maxCompositeHtmlChars: 50000,
  };

  var MODULE_TITLE_PATTERN = /示例资料|个人信息|个人资料|示例资料|示例资料|教育背景|学习经历|示例资料|示例资料|工作\/示例资料|项目经历|项目经验|校园经历|校园活动|校内活动|社会实践|示例资料|奖励情况|获奖|荣誉|证书|语言能力|技能|示例资料|家庭成员|亲属|自我评价|自我介绍|示例资料|附加信息|论文|科研/;
  var SAFE_EDIT_PATTERN = /编辑|修改|完善|展开|继续填写|补充信息/;
  var ADD_PATTERN = /添加|新增|新建|增加|创建/;
  var FORBIDDEN_ACTION_PATTERN = /立即投递|一键移除并投递|投递|提交|申请|删除|移除|清空|保存|确定|确认|完成|下一步|上一步|返回|上传|附件|照片|证件照|生活照|选择文件|备案|ICP|公安网安|公网安备/;
  var CANCEL_PATTERN = /取消|关闭|取消编辑|收起/;
  var NON_RESUME_PAGE_PATTERN = /修改志愿|选择志愿|职位列表|岗位列表|职位详情|岗位详情/;
  var NAVIGATION_ACTION_PATTERN = /返回|上一页|下一步|添加志愿|新增志愿|增加志愿|修改志愿|选择志愿|查看职位|查看岗位|职位详情|岗位详情/;
  var SKIPPED_INTERACTIVE_MODULE_PATTERN = /我的意向志愿|意向志愿|求职志愿|志愿信息|投递职位|申请职位/;
  var BLOCKING_SURFACE_SELECTOR = [
    ".el-dialog__wrapper",
    ".el-dialog",
    ".ant-modal-wrap",
    ".ant-modal",
    "[role='dialog']",
    ".el-drawer__wrapper",
    ".el-drawer",
    ".ant-drawer",
    "[class*='drawer']",
  ].join(",");
  var EDITABLE_SELECTOR = [
    "input:not([type='hidden']):not([type='file'])",
    "textarea",
    "select",
    "[contenteditable='true']",
    "[contenteditable='']",
    "[role='textbox']",
    "[role='combobox']",
    "[role='radio']",
    "[role='checkbox']",
  ].join(",");

  var status = {
    runtimeVersion: RUNTIME_VERSION,
    schemaVersion: SCHEMA_VERSION,
    flowType: "legacy",
    mode: "",
    stage: "idle",
    message: "",
    confidence: 0,
    moduleCount: 0,
    openedCount: 0,
    capturedCount: 0,
    skippedCount: 0,
    failedCount: 0,
    fallbackReason: "",
    updatedAt: Date.now(),
  };

  function mergeOptions(overrides) {
    var merged = {};
    Object.keys(DEFAULT_OPTIONS).forEach(function (key) {
      merged[key] = DEFAULT_OPTIONS[key];
    });
    if (overrides && typeof overrides === "object") {
      Object.keys(overrides).forEach(function (key) {
        if (overrides[key] !== undefined) merged[key] = overrides[key];
      });
    }
    return merged;
  }

  function updateStatus(patch) {
    Object.keys(patch || {}).forEach(function (key) {
      status[key] = patch[key];
    });
    status.updatedAt = Date.now();
    try {
      document.dispatchEvent(new CustomEvent("af:interactive-status", {
        detail: JSON.parse(JSON.stringify(status)),
      }));
    } catch (e) {}
    return getStatus();
  }

  function getStatus() {
    return JSON.parse(JSON.stringify(status));
  }

  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function compactText(value) {
    return normalizeText(value).replace(/\s+/g, "");
  }

  function toArray(value) {
    if (Array.isArray(value)) return value.filter(Boolean);
    return value ? [value] : [];
  }

  function isVisible(element) {
    if (!element || !element.isConnected) return false;
    if (AF.DomUtils && typeof AF.DomUtils.isElementVisible === "function") {
      try { return AF.DomUtils.isElementVisible(element); } catch (e) {}
    }
    try {
      var style = window.getComputedStyle(element);
      if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) return false;
      var rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    } catch (e2) {
      return false;
    }
  }

  function isPluginElement(element) {
    return !!(element && element.closest && element.closest(
      "#autofill-panel-root, #autofill-mini-logo, #__af_report_buttons__, #__af_diagnostic_btn__, #__af_fill_current_module_test_btn__"
    ));
  }

  function getEditableControls(root) {
    if (!root || !root.querySelectorAll) return [];
    try {
      return Array.from(root.querySelectorAll(EDITABLE_SELECTOR)).filter(function (element) {
        return !isPluginElement(element) && isVisible(element) && !element.disabled;
      });
    } catch (e) {
      return [];
    }
  }

  function hasEditableControl(root) {
    return getEditableControls(root).length > 0;
  }

  function getActionText(element) {
    if (!element) return "";
    return compactText(
      element.innerText ||
      element.textContent ||
      element.getAttribute("aria-label") ||
      element.getAttribute("title") ||
      element.getAttribute("data-title") ||
      ""
    );
  }

  function classifyAction(element) {
    if (AF.DomUtils && AF.DomUtils.isForbiddenAutoClickAction && AF.DomUtils.isForbiddenAutoClickAction(element)) return "forbidden";
    var text = getActionText(element);
    if (!text || FORBIDDEN_ACTION_PATTERN.test(text)) return "forbidden";
    if (SAFE_EDIT_PATTERN.test(text)) return "edit";
    if (ADD_PATTERN.test(text)) return "add";
    return "unknown";
  }

  function hasNavigationRisk(element) {
    if (!element) return true;
    if (AF.DomUtils && AF.DomUtils.isForbiddenAutoClickAction && AF.DomUtils.isForbiddenAutoClickAction(element)) return true;
    var text = getActionText(element);
    if (NAVIGATION_ACTION_PATTERN.test(text)) return true;
    var link = element.closest && element.closest("a[href]");
    if (link) {
      var href = normalizeText(link.getAttribute("href"));
      if (href && href !== "#" && !/^javascript:/i.test(href)) return true;
    }
    var navigationAttrs = ["data-href", "data-url", "router-link", "to"];
    for (var i = 0; i < navigationAttrs.length; i++) {
      if (normalizeText(element.getAttribute && element.getAttribute(navigationAttrs[i]))) return true;
    }
    var className = String(element.className || "");
    if (/router-link|navigation|page-back|back-button/i.test(className)) return true;
    var onclick = normalizeText(element.getAttribute && element.getAttribute("onclick"));
    return /location\.|history\.|router\.|navigate\(|pushState|replaceState/i.test(onclick);
  }

  function getActionCandidates(root) {
    if (!root || !root.querySelectorAll) return [];
    var selector = [
      "button",
      "a",
      "[role='button']",
      "[onclick]",
      ".custom-button",
      ".addBtn",
      "[class*='edit']",
      "[class*='add']",
    ].join(",");
    try {
      return Array.from(root.querySelectorAll(selector)).filter(function (element) {
        return isVisible(element) && !isPluginElement(element) &&
          !(AF.DomUtils && AF.DomUtils.isForbiddenAutoClickAction && AF.DomUtils.isForbiddenAutoClickAction(element));
      });
    } catch (e) {
      return [];
    }
  }

  function findModuleAction(root, options) {
    options = options || {};
    var configured = options.openAction || {};
    var configuredSelectors = toArray(configured.selectors || configured.selector);
    var configuredTexts = toArray(configured.texts || configured.text).map(compactText);
    for (var configuredIndex = 0; configuredIndex < configuredSelectors.length; configuredIndex++) {
      var configuredNodes = [];
      try { configuredNodes = Array.from(root.querySelectorAll(configuredSelectors[configuredIndex])); } catch (e) {}
      for (var nodeIndex = 0; nodeIndex < configuredNodes.length; nodeIndex++) {
        var configuredNode = configuredNodes[nodeIndex];
        var configuredText = getActionText(configuredNode);
        if (!isVisible(configuredNode) || FORBIDDEN_ACTION_PATTERN.test(configuredText)) continue;
        if (hasNavigationRisk(configuredNode)) continue;
        if (configuredTexts.length && !configuredTexts.some(function (text) { return configuredText.indexOf(text) >= 0; })) continue;
        var configuredType = classifyAction(configuredNode);
        if (configuredType === "edit" || configuredType === "add") {
          return { element: configuredNode, type: configuredType, text: configuredText };
        }
      }
    }
    var candidates = getActionCandidates(root);
    var edit = null;
    var add = null;
    for (var i = 0; i < candidates.length; i++) {
      if (hasNavigationRisk(candidates[i])) continue;
      var type = classifyAction(candidates[i]);
      if (type === "edit" && !edit) edit = candidates[i];
      if (type === "add" && !add) add = candidates[i];
    }
    var element = edit || add;
    return element ? {
      element: element,
      type: edit ? "edit" : "add",
      text: getActionText(element),
    } : null;
  }

  function findModuleTitleElement(module, options) {
    if (!module || !module.querySelector) return null;
    options = options || {};
    var selectors = [
      options.titleSelector,
      ".resume-module-header .title",
      ".module-title",
      ".card-title",
      ".section-title",
      ".titleContainer",
      "[class*='titleContainer']",
      ".createResume-main-inner-box-top .title",
      ":scope > header h1",
      ":scope > header h2",
      ":scope > header h3",
      ":scope > h1",
      ":scope > h2",
      ":scope > h3",
      ":scope > h4",
      ".title",
    ];
    for (var i = 0; i < selectors.length; i++) {
      if (!selectors[i]) continue;
      try {
        var found = module.querySelector(selectors[i]);
        var text = found && normalizeText(found.textContent);
        if (text && text.length <= 50 && MODULE_TITLE_PATTERN.test(text)) return found;
      } catch (e) {}
    }
    return null;
  }

  function getConcreteModuleOwner(element) {
    if (!element || !element.closest) return null;
    return element.closest(
      ".resume-module, .module-container, .createResume-main-inner-box, [data-af-interaction-module]"
    );
  }

  function isSkippedInteractiveModule(element, title) {
    var normalizedTitle = normalizeText(title);
    if (SKIPPED_INTERACTIVE_MODULE_PATTERN.test(normalizedTitle)) return true;
    if (!element) return false;
    try {
      if (element.matches(".resume-module.jobs-wrapper, .jobs-wrapper")) return true;
      if (element.querySelector(".volunteer-tip") && /志愿/.test(normalizeText(element.textContent))) return true;
    } catch (e) {}
    return false;
  }

  function narrowModuleToTitleOwner(candidate, titleElement) {
    var owner = getConcreteModuleOwner(titleElement);
    if (owner && candidate && candidate.contains(owner)) return owner;
    return candidate;
  }

  function findOwningModule(titleElement, options) {
    if (!titleElement) return null;
    var preferred = [
      ".resume-module",
      ".module-container",
      ".createResume-main-inner-box",
      "[class*='resume-module']",
      "[class*='module-container']",
      "[class*='gridContainer']",
      "section",
      "article",
      ".card",
    ];
    for (var i = 0; i < preferred.length; i++) {
      try {
        var direct = titleElement.closest(preferred[i]);
        if (direct && findModuleAction(direct, options)) return direct;
      } catch (e) {}
    }
    var current = titleElement.parentElement;
    for (var depth = 0; current && depth < 7; depth++, current = current.parentElement) {
      if (current === document.body || current === document.documentElement) break;
      if (findModuleAction(current, options)) return current;
    }
    return null;
  }

  function createModuleRecord(element, titleElement, index, options) {
    var action = findModuleAction(element, options);
    var title = normalizeText(titleElement && titleElement.textContent);
    return {
      key: "interactive-module-" + index + "-" + title.replace(/[^\w\u4e00-\u9fa5]+/g, "-").slice(0, 32),
      title: title,
      element: element,
      titleElement: titleElement,
      action: action,
      initialControlCount: getEditableControls(element).length,
    };
  }

  function discoverModules(options) {
    options = options || {};
    var records = [];
    var seen = new Set();
    var knownSelectors = [
      options.moduleSelector,
      ".resume .resume-module",
      ".module-container",
      ".createResume-main-inner-box",
      "[class*='resume-module']",
      "[class*='module-container']",
    ];
    knownSelectors.forEach(function (selector) {
      if (!selector) return;
      var nodes = [];
      try { nodes = Array.from(document.querySelectorAll(selector)); } catch (e) {}
      nodes.forEach(function (node) {
        if (!isVisible(node) || seen.has(node)) return;
        var titleEl = findModuleTitleElement(node, options);
        if (!titleEl) return;
        var concreteModule = narrowModuleToTitleOwner(node, titleEl);
        if (!concreteModule || seen.has(concreteModule) || !isVisible(concreteModule)) return;
        if (isSkippedInteractiveModule(concreteModule, titleEl.textContent)) return;
        if (!findModuleAction(concreteModule, options)) return;
        seen.add(concreteModule);
        records.push(createModuleRecord(concreteModule, titleEl, records.length, options));
      });
    });

    var titleNodes = [];
    try {
      titleNodes = Array.from(document.querySelectorAll(
        "h1, h2, h3, h4, h5, h6, .title, .module-title, .card-title, .section-title, [class*='title'], [class*='Title']"
      )).slice(0, 800);
    } catch (e2) {}
    titleNodes.forEach(function (titleEl) {
      if (!isVisible(titleEl)) return;
      var title = normalizeText(titleEl.textContent);
      if (!title || title.length > 50 || !MODULE_TITLE_PATTERN.test(title)) return;
      if (isSkippedInteractiveModule(module, title)) return;
      var module = findOwningModule(titleEl, options);
      if (!module || seen.has(module) || !isVisible(module)) return;
      seen.add(module);
      records.push(createModuleRecord(module, titleEl, records.length, options));
    });
    return records;
  }

  function summarizeModule(record) {
    return {
      key: record.key,
      title: record.title,
      actionType: record.action && record.action.type || "",
      actionText: record.action && record.action.text || "",
      initialControlCount: record.initialControlCount || 0,
    };
  }

  function detectPage(options) {
    options = mergeOptions(options);
    var modules = discoverModules(options);
    var visibleControls = getEditableControls(document.body).length;
    var actionCount = modules.filter(function (module) { return !!module.action; }).length;
    var displayOnlyCount = modules.filter(function (module) { return Number(module.initialControlCount || 0) <= 1; }).length;
    var visibleFormModuleCount = modules.filter(function (module) {
      return Number(module.initialControlCount || 0) >= 2;
    }).length;
    var visibleBlockingSurfaceCount = getVisibleBlockingSurfaces().length;
    // 交互式的前提是“当前看不到真实表单”。如果多个简历模块已经各自露出
    // 可填写控件，或者整页已有大量可见控件且没有弹窗/抽屉正在编辑，就必须
    // 交给普通表单流程。新增经历按钮不能推翻这个静态表单证据。
    var visibleStaticForm = visibleFormModuleCount >= 2 ||
      (visibleControls >= 12 && visibleBlockingSurfaceCount === 0);
    var pageText = compactText(document.body && document.body.innerText).slice(0, 12000);
    var pageTitle = compactText(document.title);
    var nonResumePage = NON_RESUME_PAGE_PATTERN.test(pageTitle + pageText.slice(0, 1000)) &&
      !/我的简历|简历编辑|完善简历|个人简历/.test(pageTitle + pageText.slice(0, 2000));
    var score = 0;
    if (modules.length >= 2) score += 35;
    else if (modules.length === 1) score += 15;
    if (modules.length === 1 && options.allowSingleModule) score += 20;
    score += Math.min(25, actionCount * 5);
    if (/我的简历|简历编辑|完善简历|简历完整度|个人简历/.test(pageText)) score += 10;
    if (visibleControls <= 3) score += 20;
    else if (visibleControls <= 8) score += 10;
    if (document.querySelector(".resume .resume-module")) score += 15;
    if (displayOnlyCount >= 2) score += 15;
    if (modules.length && displayOnlyCount < Math.ceil(modules.length / 2)) score -= 25;
    if (visibleControls >= 6 && !document.querySelector(".resume .resume-module")) score -= 15;
    if (visibleControls >= 12) score -= 30;
    score = Math.max(0, Math.min(100, score));
    if (nonResumePage) score = 0;
    var matched = Boolean(
      options.enabled &&
      !nonResumePage &&
      !visibleStaticForm &&
      (modules.length >= 2 || (options.allowSingleModule && modules.length >= 1)) &&
      displayOnlyCount >= 2 &&
      actionCount > 0 &&
      score >= (options.allowSingleModule ? 50 : 65)
    );
    var mode = document.querySelector(".resume .resume-module") ? "module-inline-or-dialog" : "module-card";
    return {
      matched: matched,
      interactive: matched,
      confidence: score / 100,
      score: score,
      mode: mode,
      visibleControlCount: visibleControls,
      moduleCount: modules.length,
      actionCount: actionCount,
      displayOnlyCount: displayOnlyCount,
      visibleFormModuleCount: visibleFormModuleCount,
      visibleBlockingSurfaceCount: visibleBlockingSurfaceCount,
      visibleStaticForm: visibleStaticForm,
      nonResumePage: nonResumePage,
      modules: modules.map(summarizeModule),
      _records: modules,
    };
  }

  function getVisibleBlockingSurfaces() {
    var nodes = [];
    try { nodes = Array.from(document.querySelectorAll(BLOCKING_SURFACE_SELECTOR)); } catch (e) {}
    return nodes.filter(function (node) {
      return isVisible(node) && !isPluginElement(node);
    });
  }

  function surfaceType(element, module) {
    if (!element) return "unknown";
    if (module && (element === module || module.contains(element))) return "inline";
    var className = String(element.className || "");
    if (/drawer/i.test(className)) return "drawer";
    return "dialog";
  }

  function structureFingerprint(root) {
    if (!root) return "";
    var controls = getEditableControls(root);
    var labels = [];
    try {
      labels = Array.from(root.querySelectorAll(
        "label, .el-form-item__label, .ant-form-item-label, [class*='label'], [class*='Label']"
      )).filter(isVisible).map(function (label) {
        return normalizeText(label.textContent).slice(0, 50);
      }).filter(Boolean).slice(0, 100);
    } catch (e) {}
    var signature = controls.map(function (control) {
      return [
        control.tagName,
        control.getAttribute("type") || "",
        control.getAttribute("placeholder") || "",
        control.getAttribute("role") || "",
      ].join(":");
    }).slice(0, 120);
    return JSON.stringify({ controls: signature, labels: labels });
  }

  function findChangedSurface(transaction) {
    var configuredSurface = transaction.options && transaction.options.surface || {};
    var configuredSelectors = toArray(configuredSurface.dialogSelectors || configuredSurface.dialogSelector)
      .concat(toArray(configuredSurface.drawerSelectors || configuredSurface.drawerSelector));
    for (var configuredIndex = 0; configuredIndex < configuredSelectors.length; configuredIndex++) {
      var configuredNodes = [];
      try { configuredNodes = Array.from(document.querySelectorAll(configuredSelectors[configuredIndex])); } catch (e) {}
      for (var nodeIndex = configuredNodes.length - 1; nodeIndex >= 0; nodeIndex--) {
        if (!transaction.beforeBlocking.has(configuredNodes[nodeIndex]) && isVisible(configuredNodes[nodeIndex]) && hasEditableControl(configuredNodes[nodeIndex])) {
          return { element: configuredNodes[nodeIndex], type: surfaceType(configuredNodes[nodeIndex], transaction.module.element) };
        }
      }
    }
    var blocking = getVisibleBlockingSurfaces();
    for (var i = blocking.length - 1; i >= 0; i--) {
      var surface = blocking[i];
      if (!transaction.beforeBlocking.has(surface) && hasEditableControl(surface)) {
        return { element: surface, type: surfaceType(surface, transaction.module.element) };
      }
    }
    var inlineSelectors = toArray(configuredSurface.inlineSelectors || configuredSurface.inlineSelector);
    for (var inlineIndex = 0; inlineIndex < inlineSelectors.length; inlineIndex++) {
      var inlineNode = null;
      try { inlineNode = transaction.module.element.querySelector(inlineSelectors[inlineIndex]); } catch (e2) {}
      if (inlineNode && isVisible(inlineNode) && hasEditableControl(inlineNode)) {
        return { element: inlineNode, type: "inline" };
      }
    }
    if (hasEditableControl(transaction.module.element)) {
      var fingerprint = structureFingerprint(transaction.module.element);
      if (fingerprint && fingerprint !== transaction.beforeModuleFingerprint) {
        return { element: transaction.module.element, type: "inline" };
      }
    }
    return null;
  }

  function waitForStableSurface(transaction, options) {
    options = mergeOptions(options);
    return new Promise(function (resolve) {
      var startedAt = Date.now();
      var lastRelevantMutationAt = Date.now();
      var lastFingerprint = "";
      var stableMatches = 0;
      var finished = false;
      var timer = null;
      var observer = null;

      function finish(result) {
        if (finished) return;
        finished = true;
        if (timer) clearTimeout(timer);
        if (observer) observer.disconnect();
        resolve(result);
      }

      function mutationIsRelevant(mutation) {
        if (transaction.surface && transaction.surface.element) {
          return transaction.surface.element.contains(mutation.target) || mutation.target === transaction.surface.element;
        }
        if (transaction.module.element.contains(mutation.target)) return true;
        var added = Array.from(mutation.addedNodes || []);
        return added.some(function (node) {
          return node && node.nodeType === 1 && (
            (node.matches && node.matches(BLOCKING_SURFACE_SELECTOR + "," + EDITABLE_SELECTOR)) ||
            (node.querySelector && node.querySelector(BLOCKING_SURFACE_SELECTOR + "," + EDITABLE_SELECTOR))
          );
        });
      }

      try {
        observer = new MutationObserver(function (mutations) {
          if (mutations.some(mutationIsRelevant)) lastRelevantMutationAt = Date.now();
        });
        observer.observe(document.body, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ["placeholder", "required", "disabled", "type", "role", "readonly"],
        });
      } catch (e) {}

      function poll() {
        if (finished) return;
        if (window.location.href !== transaction.beforeUrl && !options.allowPageNavigation) {
          finish({ success: false, reason: "page_navigation_not_allowed", navigationDetected: true });
          return;
        }
        var changed = findChangedSurface(transaction);
        if (changed) transaction.surface = changed;
        if (transaction.surface && transaction.surface.element) {
          var fingerprint = structureFingerprint(transaction.surface.element);
          if (fingerprint && fingerprint === lastFingerprint) stableMatches++;
          else stableMatches = 0;
          lastFingerprint = fingerprint;
          var quietFor = Date.now() - lastRelevantMutationAt;
          if (getEditableControls(transaction.surface.element).length > 0 && stableMatches >= 2 && quietFor >= options.quietWindowMs) {
            transaction.surface.fingerprint = fingerprint;
            finish({ success: true, surface: transaction.surface });
            return;
          }
        }
        if (Date.now() - startedAt >= options.maxWaitMs) {
          finish({ success: false, reason: "surface_timeout" });
          return;
        }
        timer = setTimeout(poll, options.fingerprintIntervalMs);
      }
      timer = setTimeout(poll, 80);
    });
  }

  async function openModule(moduleRecord, options) {
    options = mergeOptions(options);
    if (!moduleRecord || !moduleRecord.action || !moduleRecord.action.element) {
      return { success: false, reason: "missing_action" };
    }
    if (moduleRecord.action.type === "add" && !options.allowAddProbe) {
      return { success: false, skipped: true, reason: "add_probe_disabled" };
    }
    if (moduleRecord.action.type !== "add" && !options.allowEditProbe) {
      return { success: false, skipped: true, reason: "edit_probe_disabled" };
    }
    if (isSkippedInteractiveModule(moduleRecord.element, moduleRecord.title)) {
      return { success: false, skipped: true, reason: "module_navigation_intent_blocked" };
    }
    if (hasNavigationRisk(moduleRecord.action.element)) {
      return { success: false, skipped: true, reason: "navigation_action_blocked" };
    }
    var transaction = {
      id: "af-interaction-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8),
      module: moduleRecord,
      action: moduleRecord.action,
      beforeUrl: window.location.href,
      beforeBlocking: new Set(getVisibleBlockingSurfaces()),
      beforeModuleFingerprint: structureFingerprint(moduleRecord.element),
      options: options,
      openedAt: Date.now(),
      surface: null,
      state: "OPENING",
    };
    try {
      moduleRecord.action.element.scrollIntoView({ block: "center", inline: "nearest" });
    } catch (e) {}
    try {
      var clicked = AF.DomUtils && AF.DomUtils.safeClickElement
        ? await AF.DomUtils.safeClickElement(moduleRecord.action.element)
        : (moduleRecord.action.element.click(), true);
      if (!clicked) throw new Error("action_click_blocked");
    } catch (error) {
      transaction.state = "FAILED";
      return { success: false, reason: "action_click_failed", error: error, transaction: transaction };
    }
    transaction.state = "WAITING";
    var waitResult = await waitForStableSurface(transaction, options);
    if (!waitResult.success) {
      transaction.state = "FAILED";
      transaction.failureReason = waitResult.reason;
      return { success: false, reason: waitResult.reason, transaction: transaction };
    }
    transaction.state = "CAPTURE_READY";
    return { success: true, transaction: transaction, surface: transaction.surface };
  }

  function sanitizeSurface(root, maxChars) {
    if (!root || !root.cloneNode) return "";
    var clone = root.cloneNode(true);
    try {
      Array.from(clone.querySelectorAll(
        "script, style, link, meta, svg, path, img, video, audio, canvas, noscript, iframe"
      )).forEach(function (node) { node.remove(); });
      Array.from(clone.querySelectorAll("input")).forEach(function (input) {
        input.removeAttribute("value");
        if (input.getAttribute("type") !== "hidden") input.setAttribute("data-current-value", "[已隐藏]");
      });
      Array.from(clone.querySelectorAll("textarea")).forEach(function (textarea) {
        textarea.textContent = "[已隐藏]";
      });
      Array.from(clone.querySelectorAll("[contenteditable]")).forEach(function (node) {
        node.textContent = "[contenteditable]";
      });
      Array.from(clone.querySelectorAll("[style]")).forEach(function (node) {
        node.removeAttribute("style");
      });
    } catch (e) {}
    var html = clone.outerHTML || clone.innerHTML || "";
    html = html.replace(/\s+/g, " ").trim();
    if (html.length > maxChars) html = html.slice(0, maxChars) + "...[module-truncated]";
    return html;
  }

  function captureSurface(transaction, options) {
    options = mergeOptions(options);
    if (!transaction || !transaction.surface || !transaction.surface.element) {
      return { success: false, reason: "missing_surface" };
    }
    var root = transaction.surface.element;
    var controls = getEditableControls(root);
    var labels = [];
    try {
      labels = Array.from(root.querySelectorAll(
        "label, .el-form-item__label, .ant-form-item-label, [class*='label'], [class*='Label']"
      )).filter(isVisible).map(function (element) {
        return normalizeText(element.textContent).slice(0, 80);
      }).filter(Boolean);
      labels = Array.from(new Set(labels)).slice(0, 150);
    } catch (e) {}
    transaction.state = "CAPTURED";
    return {
      success: true,
      moduleKey: transaction.module.key,
      title: transaction.module.title,
      actionType: transaction.action.type,
      actionText: transaction.action.text,
      surfaceType: transaction.surface.type,
      controlCount: controls.length,
      labelCount: labels.length,
      labels: labels,
      cleanedHtml: sanitizeSurface(root, options.maxModuleHtmlChars),
    };
  }

  function findSafeCloseButton(transaction) {
    if (!transaction || !transaction.surface || !transaction.surface.element) return null;
    var root = transaction.surface.element;
    var configured = transaction.options && transaction.options.closeAction || {};
    var configuredSelectors = toArray(configured.selectors || configured.selector);
    var configuredTexts = toArray(configured.texts || configured.text).map(compactText);
    for (var configuredIndex = 0; configuredIndex < configuredSelectors.length; configuredIndex++) {
      var configuredNodes = [];
      try { configuredNodes = Array.from(root.querySelectorAll(configuredSelectors[configuredIndex])); } catch (e) {}
      for (var nodeIndex = configuredNodes.length - 1; nodeIndex >= 0; nodeIndex--) {
        var configuredText = getActionText(configuredNodes[nodeIndex]);
        if (!isVisible(configuredNodes[nodeIndex])) continue;
        if (configuredTexts.length && !configuredTexts.some(function (text) { return configuredText.indexOf(text) >= 0; })) continue;
        if (!hasNavigationRisk(configuredNodes[nodeIndex]) && !/保存|提交|投递|删除|确定|确认/.test(configuredText)) return configuredNodes[nodeIndex];
      }
    }
    var candidates = [];
    try {
      candidates = Array.from(root.querySelectorAll(
        "button, a, [role='button'], .el-button, .ant-btn, .custom-button"
      )).filter(isVisible);
    } catch (e) {}
    for (var i = candidates.length - 1; i >= 0; i--) {
      var text = getActionText(candidates[i]);
      if (text && /^(取消|关闭|取消编辑|收起)$/.test(text) && !hasNavigationRisk(candidates[i])) return candidates[i];
    }
    if (transaction.surface.type !== "inline") {
      try {
        return root.querySelector(
          ".el-dialog__headerbtn, .ant-modal-close, .el-drawer__close-btn, .ant-drawer-close, [aria-label='Close'], [aria-label='关闭']"
        );
      } catch (e2) {}
    }
    return null;
  }

  function waitUntilClosed(transaction, timeoutMs) {
    return new Promise(function (resolve) {
      var startedAt = Date.now();
      function check() {
        var surface = transaction && transaction.surface && transaction.surface.element;
        if (!surface || !surface.isConnected || !isVisible(surface) || !hasEditableControl(surface)) {
          resolve(true);
          return;
        }
        if (Date.now() - startedAt >= timeoutMs) {
          resolve(false);
          return;
        }
        setTimeout(check, 120);
      }
      check();
    });
  }

  async function closeSurface(transaction) {
    if (!transaction || !transaction.surface) return { closed: false, reason: "missing_surface" };
    var button = findSafeCloseButton(transaction);
    if (!button || !isVisible(button)) {
      transaction.state = "LEFT_OPEN";
      return {
        closed: false,
        leftOpen: true,
        blocking: transaction.surface.type !== "inline",
        reason: "safe_close_not_found",
      };
    }
    try { button.click(); } catch (error) {
      transaction.state = "LEFT_OPEN";
      return { closed: false, leftOpen: true, reason: "close_click_failed", error: error };
    }
    var closed = await waitUntilClosed(transaction, 2200);
    transaction.state = closed ? "RESTORED" : "LEFT_OPEN";
    return {
      closed: closed,
      leftOpen: !closed,
      blocking: !closed && transaction.surface.type !== "inline",
      reason: closed ? "closed" : "close_timeout",
    };
  }

  function buildCompositeHtml(baseInfo, analysis, options) {
    options = mergeOptions(options);
    var parts = [
      '<interactive-resume-analysis schema-version="' + SCHEMA_VERSION + '" mode="' + analysis.mode + '">',
    ];
    analysis.modules.forEach(function (module) {
      parts.push(
        '<interaction-module title="' + module.title.replace(/"/g, "&quot;") + '" action-type="' + module.actionType + '" action-text="' + module.actionText.replace(/"/g, "&quot;") + '" surface-type="' + module.surfaceType + '">'
      );
      parts.push(module.cleanedHtml || "");
      parts.push("</interaction-module>");
    });
    analysis.skippedModules.forEach(function (module) {
      parts.push(
        '<interaction-module-skipped title="' + module.title.replace(/"/g, "&quot;") + '" action-type="' + module.actionType + '" reason="' + module.reason + '"></interaction-module-skipped>'
      );
    });
    parts.push("</interactive-resume-analysis>");
    if (baseInfo && baseInfo.cleanedHtml) {
      parts.push("<initial-page-snapshot>" + String(baseInfo.cleanedHtml).slice(0, 10000) + "</initial-page-snapshot>");
    }
    var html = parts.join("\n");
    if (html.length > options.maxCompositeHtmlChars) {
      html = html.slice(0, options.maxCompositeHtmlChars) + "\n...[interactive-analysis-truncated]";
    }
    return html;
  }

  async function analyzePage(options) {
    options = mergeOptions(options);
    var detection = detectPage(options);
    if (!detection.matched) {
      updateStatus({
        flowType: "legacy",
        mode: "",
        stage: "not_interactive",
        confidence: detection.confidence,
        moduleCount: detection.moduleCount,
        fallbackReason: "interactive_score_below_threshold",
      });
      return { matched: false, detection: detection };
    }
    var records = detection._records.slice(0, options.maxModules);
    var captured = [];
    var skipped = [];
    var failed = [];
    updateStatus({
      flowType: "interactive_analysis",
      mode: detection.mode,
      stage: "discovering",
      message: "发现 " + records.length + " 个交互式简历模块",
      confidence: detection.confidence,
      moduleCount: records.length,
      openedCount: 0,
      capturedCount: 0,
      skippedCount: 0,
      failedCount: 0,
      fallbackReason: "",
    });

    for (var i = 0; i < records.length; i++) {
      var record = records[i];
      updateStatus({
        stage: "opening",
        message: "正在打开：" + record.title,
        currentModule: record.title,
        currentIndex: i + 1,
      });
      var opened = await openModule(record, options);
      if (!opened.success) {
        var item = {
          title: record.title,
          actionType: record.action && record.action.type || "",
          actionText: record.action && record.action.text || "",
          reason: opened.reason || "open_failed",
        };
        if (opened.skipped) skipped.push(item);
        else failed.push(item);
        updateStatus({
          skippedCount: skipped.length,
          failedCount: failed.length,
          message: opened.skipped ? "已跳过：" + record.title : "打开失败：" + record.title,
        });
        continue;
      }
      updateStatus({
        openedCount: status.openedCount + 1,
        stage: "capturing",
        message: "正在采集：" + record.title,
      });
      var capture = captureSurface(opened.transaction, options);
      if (capture.success) captured.push(capture);
      else failed.push({ title: record.title, reason: capture.reason || "capture_failed" });
      updateStatus({
        capturedCount: captured.length,
        failedCount: failed.length,
      });
      var closeResult = await closeSurface(opened.transaction);
      if (!closeResult.closed && closeResult.blocking) {
        updateStatus({
          stage: "blocked_open_surface",
          message: "当前编辑面无法安全关闭，停止继续探测",
          fallbackReason: closeResult.reason,
        });
        break;
      }
    }

    var analysis = {
      schemaType: "interactive-resume-analysis",
      schemaVersion: SCHEMA_VERSION,
      runtimeVersion: RUNTIME_VERSION,
      matched: true,
      confidence: detection.confidence,
      mode: detection.mode,
      moduleCount: records.length,
      modules: captured,
      skippedModules: skipped,
      failedModules: failed,
      collectedAt: new Date().toISOString(),
    };
    updateStatus({
      stage: captured.length ? "analysis_ready" : "fallback_legacy",
      message: captured.length ? "交互式表单采集完成" : "未采集到可分析表单，回退原流程",
      capturedCount: captured.length,
      skippedCount: skipped.length,
      failedCount: failed.length,
      fallbackReason: captured.length ? "" : "no_interactive_surface_captured",
    });
    return analysis;
  }

  async function collectPageInfo(baseCollector, options) {
    var baseInfo = typeof baseCollector === "function" ? baseCollector() : (baseCollector || {});
    var detection = detectPage(options);
    baseInfo.interactiveFormPage = detection.matched;
    baseInfo.interactiveDetection = {
      matched: detection.matched,
      confidence: detection.confidence,
      mode: detection.mode,
      moduleCount: detection.moduleCount,
      actionCount: detection.actionCount,
      visibleControlCount: detection.visibleControlCount,
      modules: detection.modules,
      runtimeVersion: RUNTIME_VERSION,
    };
    if (!detection.matched) return baseInfo;
    var analysis = await analyzePage(options);
    baseInfo.interactiveFormPage = true;
    if (analysis && analysis.modules && analysis.modules.length) {
      baseInfo.cleanedHtml = buildCompositeHtml(baseInfo, analysis, options);
      baseInfo.interactiveAnalysis = {
        schemaType: analysis.schemaType,
        schemaVersion: analysis.schemaVersion,
        runtimeVersion: analysis.runtimeVersion,
        matched: analysis.matched,
        confidence: analysis.confidence,
        mode: analysis.mode,
        moduleCount: analysis.moduleCount,
        modules: analysis.modules.map(function (module) {
          return {
            moduleKey: module.moduleKey,
            title: module.title,
            actionType: module.actionType,
            actionText: module.actionText,
            surfaceType: module.surfaceType,
            controlCount: module.controlCount,
            labelCount: module.labelCount,
            labels: module.labels,
          };
        }),
        skippedModules: analysis.skippedModules,
        failedModules: analysis.failedModules,
        collectedAt: analysis.collectedAt,
      };
      var interactiveControlCount = analysis.modules.reduce(function (sum, module) {
        return sum + Number(module.controlCount || 0);
      }, 0);
      var interactiveLabels = [];
      analysis.modules.forEach(function (module) {
        interactiveLabels = interactiveLabels.concat(module.labels || []);
      });
      baseInfo.inputCount = Math.max(Number(baseInfo.inputCount || 0), interactiveControlCount);
      baseInfo.labels = Array.from(new Set((baseInfo.labels || []).concat(interactiveLabels)));
      baseInfo.labelCount = baseInfo.labels.length;
      baseInfo.analysisType = "interactive";
    } else {
      baseInfo.interactiveAnalysis = analysis;
    }
    return baseInfo;
  }

  async function openForLiveFill(moduleRecord, options) {
    var liveOptions = mergeOptions(options);
    if (moduleRecord && moduleRecord.action && moduleRecord.action.type === "add") {
      liveOptions.allowAddProbe = true;
    }
    updateStatus({
      flowType: "interactive_live_fill",
      stage: "opening_for_fill",
      currentModule: moduleRecord && moduleRecord.title || "",
      message: "正在打开交互式表单",
    });
    return openModule(moduleRecord, liveOptions);
  }

  async function finishTransaction(transaction, result) {
    result = result || {};
    if (result.leaveOpen) return { closed: false, leftOpen: true, reason: "requested_leave_open" };
    if (result.save === true) {
      return { closed: false, leftOpen: true, reason: "save_owned_by_fill_engine" };
    }
    return closeSurface(transaction);
  }

  AF.InteractiveFormRuntime = {
    version: RUNTIME_VERSION,
    schemaVersion: SCHEMA_VERSION,
    defaults: DEFAULT_OPTIONS,
    detectPage: detectPage,
    discoverModules: discoverModules,
    analyzePage: analyzePage,
    collectPageInfo: collectPageInfo,
    openModule: openModule,
    openForLiveFill: openForLiveFill,
    waitForStableSurface: waitForStableSurface,
    captureSurface: captureSurface,
    closeSurface: closeSurface,
    finishTransaction: finishTransaction,
    buildCompositeHtml: buildCompositeHtml,
    getStatus: getStatus,
    updateStatus: updateStatus,
  };
})();
