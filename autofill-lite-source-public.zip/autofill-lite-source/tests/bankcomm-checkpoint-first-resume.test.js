"use strict";
const fs = require("fs");
const path = require("path");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const workflow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-workflow.js"), "utf8");
const sites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
assert(main.includes("resumeStartsAfterBasic"), "one-click must honor persisted checkpoint before Bankcomm basic preflight");
assert(main.includes("checkpointStepIndex: resumeStepIndex"), "checkpoint diagnostic cursor missing");
assert(workflow.includes("manualResumeResolvedStepIndex"), "resolved manual checkpoint cursor missing");
assert(workflow.includes("skipManualCheckpoint: manualResumeResolvedStepIndex === stepIndex"), "resolved checkpoint must bypass the manual gate exactly for its step");
assert(workflow.includes("已按用户再次运行确认人工检查点"), "user-ack manual checkpoint resume notice missing");
assert(sites.includes("manualCheckpointResolvedWhen: bankcommHasSavedPreHigherEducation"), "Bankcomm compatibility resolver config missing");
assert(workflow.includes("manualResumeResolvedStepIndex = storedStepIndex"), "rerun must acknowledge manual gate without re-probing it");
assert(sites.includes("bankcommCollectEducationReadOnlyCandidates"), "record-scoped saved education scanner missing");
assert(sites.includes("Number(signal.dateCount || 0) >= 2"), "saved high-school fallback must require a real date range");
assert(sites.includes("excludedBecauseEditor"), "education editor exclusion signal missing");
console.log("bankcomm-checkpoint-first-resume.test.js passed");
