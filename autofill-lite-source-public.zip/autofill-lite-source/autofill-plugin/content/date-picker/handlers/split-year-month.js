// content/date-picker/handlers/split-year-month.js — 自封装 年/月 双下拉日期选择器
// 适配形态:
//   .required-year + .small-select-ul .small-select-li
//   .required-month + .splicing-select-ul .splicing-select-li
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  function parseYearMonth(value) {
    var raw = value;
    if (value && typeof value === "object") raw = value.startTime || value.endTime;
    var text = String(raw || "").trim();
    var match = text.match(/(\d{4})\D+(\d{1,2})/);
    if (!match) return null;
    return {
      year: match[1],
      month: String(parseInt(match[2], 10)).padStart(2, "0"),
    };
  }

  function isCurrentEndValue(value) {
    return typeof value === "string" && /^(至今|目前|现在|当前|仍在职|在职|仍在进行)$/.test(value.trim());
  }

  function parseRange(value) {
    if (!value) return null;
    if (typeof value === "object") {
      return {
        start: parseYearMonth(value.startTime),
        end: parseYearMonth(value.endTime),
        current: isCurrentEndValue(value.endTime),
      };
    }
    var text = String(value || "");
    var parts = text.split("~");
    return {
      start: parseYearMonth(parts[0]),
      end: parseYearMonth(parts[1]),
      current: /至今|目前|现在|当前|仍在职|在职|仍在进行/.test(text),
    };
  }

  function closestSide(element) {
    if (!element || !element.closest) return null;
    var known = (
      element.closest(".resume-module-left, .resume-module-right, .end-time") ||
      element.closest(".start-time-module")
    );
    return known || closestInputScope(element) || element;
  }

  function closestInputScope(element) {
    try {
      var range = element && element.closest && element.closest(".month-range-select.date_info, .month-range-select, .date_info");
      if (range && collectYearMonthInputs(range).length >= 2) return range;
    } catch (e) {}
    var cur = element;
    for (var depth = 0; cur && depth < 8; depth++) {
      if (cur.querySelectorAll) {
        var inputs = collectYearMonthInputs(cur);
        if (inputs.length >= 2 && inputs.length <= 6) return cur;
      }
      cur = cur.parentElement;
    }
    return null;
  }

  function collectYearMonthInputs(scope) {
    if (!scope || !scope.querySelectorAll) return [];
    var inputs = Array.from(scope.querySelectorAll("input")).filter(function (input) {
      var hint = String([input.placeholder, input.name, input.id, input.getAttribute("aria-label")].filter(Boolean).join(" "));
      return (!AF.DomUtils || AF.DomUtils.isElementVisible(input)) && /(年|月|year|month)/i.test(hint);
    });
    if (inputs.length >= 2) return inputs;
    if (scope.matches && scope.matches(".month-range-select, .date_info, [class*='date_info']")) {
      return Array.from(scope.querySelectorAll("[class^='sd-Dropdown-container'] input, [class*=' sd-Dropdown-container'] input")).filter(function (input) {
        return !AF.DomUtils || AF.DomUtils.isElementVisible(input);
      });
    }
    return inputs;
  }

  function findTrigger(scope, kind) {
    if (!scope || !scope.querySelector) return null;
    return kind === "year"
      ? scope.querySelector(".required-year, .select-left")
      : scope.querySelector(".required-month, .select-right");
  }

  function findItem(scope, kind, target) {
    if (!scope || !scope.querySelectorAll) return null;
    var selector = kind === "year"
      ? ".small-select-li, .small-select-ul li"
      : ".splicing-select-li, .splicing-select-ul li";
    var items = Array.from(scope.querySelectorAll(selector));
    return items.find(function (item) {
      var text = String(item.textContent || "").trim();
      if (kind === "year") return text === target;
      var month = String(parseInt(text, 10)).padStart(2, "0");
      return month === target || text === target || text === String(parseInt(target, 10));
    }) || null;
  }

  async function clickOption(scope, kind, target) {
    var trigger = findTrigger(scope, kind);
    if (!trigger) return false;
    var currentText = String(trigger.textContent || "").trim();
    if (kind === "year" && currentText === target) return true;
    if (kind === "month") {
      var currentMonth = String(parseInt(currentText, 10)).padStart(2, "0");
      if (currentMonth === target) return true;
    }
    await AF.DomUtils.safeClickElement(trigger);
    await AF.Utils.sleep(80);
    var item = findItem(scope, kind, target);
    if (!item) return false;
    await AF.DomUtils.safeClickElement(item);
    await AF.Utils.sleep(80);
    trigger = findTrigger(scope, kind) || trigger;
    var afterText = String(trigger.textContent || "").trim();
    if (kind === "year") return afterText === target || afterText.indexOf(target) !== -1;
    var afterMonth = String(parseInt(afterText, 10)).padStart(2, "0");
    return afterMonth === target || afterText === target;
  }

  async function setInputValue(input, value) {
    if (!input || value == null || value === "") return false;
    input.focus && input.focus();
    try {
      var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      if (setter) setter.call(input, String(value));
      else input.value = String(value);
    } catch (e) {
      input.value = String(value);
    }
    input.setAttribute && input.setAttribute("value", String(value));
    input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    input.dispatchEvent(new Event("blur", { bubbles: true, composed: true }));
    await AF.Utils.sleep(80);
    return String(input.value || "").indexOf(String(value)) !== -1;
  }

  function closestSelectControl(input) {
    if (!input || !input.closest) return input;
    return input.closest(
      "[class^='sd-Dropdown-container'], [class*=' sd-Dropdown-container'], [class^='sd-Select-container'], [class*=' sd-Select-container'], .ant-select, .el-select, .rocket-select, select"
    ) || input;
  }

  function readControlDisplay(control, input) {
    try {
      var display = control && control.querySelector && control.querySelector('[class*="sd-Input-display-value"]');
      var displayText = String(display && display.textContent || "").trim();
      if (displayText) return displayText;
    } catch (e) {}
    return String(input && input.value || "").trim();
  }

  function valueLooksSelected(text, value) {
    var actual = String(text || "").replace(/\s+/g, "");
    var target = String(value || "").replace(/\s+/g, "");
    if (!actual || !target) return false;
    if (actual === target || actual.indexOf(target) !== -1) return true;
    var aNum = actual.match(/\d+/);
    var tNum = target.match(/\d+/);
    return !!(aNum && tNum && parseInt(aNum[0], 10) === parseInt(tNum[0], 10));
  }

  async function setYearMonthControl(input, value, kind) {
    var control = closestSelectControl(input);
    var candidates = [String(value)];
    if (kind === "month") {
      var month = parseInt(value, 10);
      if (!isNaN(month)) {
        candidates.push(String(month).padStart(2, "0"));
        candidates.push(String(month) + "月");
      }
    }
    if (control && control !== input && AF.SelectAdapter && AF.SelectAdapter.create) {
      for (var i = 0; i < candidates.length; i++) {
        try {
          var adapter = AF.SelectAdapter.create(control, "string");
          if (adapter && adapter.selectValue && await adapter.selectValue(candidates[i])) return true;
          if (valueLooksSelected(readControlDisplay(control, input), candidates[i])) return true;
        } catch (e) {}
        await AF.Utils.sleep(120);
      }
    }
    return await setInputValue(input, value);
  }

  async function fillInputStyle(scope, value) {
    var range = parseRange(value);
    if (!range || !range.start) return false;
    var inputs = collectYearMonthInputs(scope);
    if (inputs.length < 2) return false;
    var values = [range.start.year, String(parseInt(range.start.month, 10))];
    if (range.end) values.push(range.end.year, String(parseInt(range.end.month, 10)));
    var ok = true;
    for (var i = 0; i < inputs.length && i < values.length; i++) {
      ok = (await setYearMonthControl(inputs[i], values[i], i % 2 === 0 ? "year" : "month")) && ok;
    }
    if (range.current) {
      try {
        var currentControls = Array.from(scope.querySelectorAll(
          "input[type='checkbox'], input[type='radio'], [role='checkbox'], [role='switch'], button, label"
        ));
        var target = currentControls.find(function (node) {
          var text = String(node.textContent || node.getAttribute("aria-label") || node.getAttribute("title") || "").replace(/[\s:：*]/g, "");
          return /^(至今|目前|现在|当前|仍在职|在职|仍在进行)$/.test(text);
        });
        if (target) await AF.DomUtils.safeClickElement(target);
      } catch (e) {}
    }
    return ok;
  }

  AF.DatePicker._registry.splitYearMonth = function (element) {
    return {
      setValue: async function (value) {
        try {
          var scope = closestSide(element);
          if (!scope) return false;
          if (collectYearMonthInputs(scope).length >= 2) {
            return await fillInputStyle(scope, value);
          }
          var ym = parseYearMonth(value);
          if (!ym) return false;
          var yearOk = await clickOption(scope, "year", ym.year);
          scope = closestSide(element) || scope;
          var monthOk = await clickOption(scope, "month", ym.month);
          return !!(yearOk && monthOk);
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
