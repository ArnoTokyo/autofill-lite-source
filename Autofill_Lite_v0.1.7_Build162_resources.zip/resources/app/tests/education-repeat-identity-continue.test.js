"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");

global.HTMLElement = function(){};
global.Element = function(){};
global.document = {
  body: {},
  documentElement: { getAttribute() { return null; }, setAttribute() {}, removeAttribute() {} },
  querySelectorAll() { return []; },
  querySelector() { return null; }
};
global.window = {
  AF: {},
  top: null,
  location: { hostname: "test", pathname: "/", href: "https://test/" },
  getComputedStyle() { return { display: "block", visibility: "visible", cursor: "default", zIndex: "0" }; },
  sessionStorage: { getItem() { return null; }, removeItem() {} },
  postMessage() {}
};
window.top = window;
const realSetTimeout = global.setTimeout;
global.setTimeout = () => 0;
const workflowPath = path.join(__dirname, "..", "autofill-plugin", "content", "special-site-workflow.js");
const workflowSource = fs.readFileSync(workflowPath, "utf8");
new Function(workflowSource)();
global.setTimeout = realSetTimeout;

const api = window.AF.SpecialSiteWorkflow._test;
assert.strictEqual(typeof api.selectRemainingEducationRecord, "function");
assert.strictEqual(typeof api.runAnalyzedEducationContinuePreview, "function");
assert.strictEqual(typeof api.runAnalyzedEducationRepeatSaveTransaction, "function");
assert.strictEqual(typeof api.parseHigherEducationDisplayText, "function");


const cnpcRenderedCard = [
  "毕业院校： 中国人民大学",
  "入学时间： 2025-09-01\t毕业时间： 2027-06-30",
  "学 位： 经济学硕士\t学位证书编号： -",
  "学 历： 硕士研究生\t学历证书编号： -",
  "专 业： 经济学 - 经济学类 - 金融学（含：保险学）",
  "绩点制： 四分制\t学分绩点： 3.61",
  "专业方向： 证券投资与金融管理\t学位类型： 专业型",
].join("\n");
assert.strictEqual(api.parseHigherEducationDisplayText(cnpcRenderedCard, "毕业院校"), "中国人民大学");
assert.strictEqual(api.parseHigherEducationDisplayText(cnpcRenderedCard, "学位"), "经济学硕士", "spaced read-only labels should be parsed from rendered card text");
assert.strictEqual(api.parseHigherEducationDisplayText(cnpcRenderedCard, "学历"), "硕士研究生");
assert(api.parseHigherEducationDisplayText(cnpcRenderedCard, "专业").includes("金融学"));
assert.strictEqual(api.parseHigherEducationDisplayText("学位类型： 专业型", "学位"), "", "the generic reader must not confuse 学位类型 with 学位");

const rows = [
  { school: "中国人民大学", major: "金融", level: "硕士", degree: "硕士", startTime: "2025-09-01", endTime: "2027-06-30" },
  { school: "中国人民大学", major: "财政学", level: "本科", degree: "学士", startTime: "2021-09-01", endTime: "2025-06-30" },
];
const existingMaster = [{
  school: "中国人民大学",
  major: "金融",
  level: "硕士",
  degree: "硕士",
  startTime: "2025-09",
  endTime: "2027-06",
}];
const missing = api.selectRemainingEducationRecord(rows, existingMaster);
assert.strictEqual(missing.recordIndex, 1, "the shared identity resolver should select the bachelor row after the saved master row matches");
assert.strictEqual(missing.missingRecordCount, 1);
assert.deepStrictEqual(missing.matchedProfileIndices, [0]);
assert.strictEqual(missing.record.major, "财政学");

const complete = api.selectRemainingEducationRecord(rows, existingMaster.concat([{
  school: "中国人民大学",
  major: "财政学",
  level: "本科",
  degree: "学士",
  startTime: "2021-09",
  endTime: "2025-06",
}]));
assert.strictEqual(complete.record, null);
assert.strictEqual(complete.reason, "education_no_missing_record");
assert.strictEqual(complete.missingRecordCount, 0);

const ambiguous = api.selectRemainingEducationRecord(rows, [{ school: "中国人民大学" }]);
assert.strictEqual(ambiguous.record, null, "school-only identity must not guess between two records from the same university");
assert.strictEqual(ambiguous.reason, "education_existing_record_match_uncertain");

assert(workflowSource.includes("scanHigherEducationExistingRecords(sectionResolved.root)"), "education continuation must reuse the shared saved-record scanner");
assert(workflowSource.includes("selectRemainingEducationRecord(rows, identities)"), "education continuation must reuse the shared missing-record resolver");
assert(workflowSource.includes('runAnalyzedEducationRepeatSaveTransaction'), "Build70 must expose the shared education save transaction");
assert(workflowSource.includes('findExplicitSectionSaveButton("教育背景")'), "Build70 must use the shared local-save resolver");
assert(workflowSource.includes('findAnalyzedNavigationSaveSuccessFeedback()'), "Build70 must reuse verified save-feedback detection");
assert(workflowSource.includes('closeAnalyzedNavigationSaveSuccessModal'), "Build70 must reuse safe success-modal closing");
assert(workflowSource.includes('education_saved_identity_not_verified'), "Build70 must verify saved-card identity after local save");
assert(workflowSource.includes('"毕业院校"'), "shared education display identity should accept the CNPC school-label alias without a hostname-specific workflow");

const main = fs.readFileSync(path.join(__dirname, "..", "main.js"), "utf8");
const preload = fs.readFileSync(path.join(__dirname, "..", "ui-preload.js"), "utf8");
const renderer = fs.readFileSync(path.join(__dirname, "..", "renderer.js"), "utf8");
const index = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
assert(main.includes('kind: "education_repeat_save_transaction"'));
assert(main.includes('runAnalyzedEducationRepeatSaveTransaction'));
assert(preload.includes('continueEducationRecords'));
assert(renderer.includes('continueEducationRecords'));
assert(!index.includes('id="educationContinuePreview"'), "Build160 removes the manual education transaction toolbar entry");
assert(!index.includes('id="experimentMenu"'), "Build160 removes the development experiment submenu");

console.log("education repeat identity continue test: PASS");

assert(workflowSource.includes("existingIdentitySignalFields"), "Build70 should retain safe key-only diagnostics for saved-card identity extraction");
