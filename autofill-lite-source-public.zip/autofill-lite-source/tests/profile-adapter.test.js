"use strict";

const assert = require("assert");
const { normalizeProfileBackup } = require("../profile-adapter");

const raw = { profileV2: { sections: {
  basic: { values: { "姓名": "示例用户", "电话": "13800000000", "最高学历": "硕士" } },
  intention: { items: [{ values: { "意向岗位": "示例岗位", "期望薪资": "面议", "期望工作城市": "示例城市" } }] },
  education: { items: [
    { values: { "学校": "示例大学甲", "学历": "本科", "学位": "学士", "专业": "示例专业", "开始时间": "2018-09", "结束时间": "2022-06" } },
    { values: { "学校": "示例大学乙", "学历": "硕士", "学位": "硕士", "专业": "示例专业", "开始时间": "2022-09", "结束时间": "2024-06" } }
  ] },
  internship: { items: [{ values: { "公司": "示例机构", "开始时间": "2023-04", "结束时间": "2023-06", "开始日期": "2023-04-30", "结束日期": "2023-06-30" } }] },
  project: { items: [{ values: { "项目名称": "示例项目", "开始时间": "2022-10", "结束时间": "2023-01", "开始日期": "2022-10-01", "结束日期": "2023-01-31" } }] },
  student: { items: [{ values: { "组织名称": "示例组织", "职位": "成员", "开始时间": "2022-09", "结束时间": "2023-06", "开始日期": "2022-09-01", "结束日期": "2023-06-30", "本人职责": "示例职责" } }] },
  awards: { items: [] }, language: { items: [] }, family: { items: [] }, self: { values: {} }, other: { values: {} }
} } };

const profile = normalizeProfileBackup(raw);
assert.strictEqual(profile.basicInfo.name, "示例用户");
assert.strictEqual(profile.education.length, 2);
assert.strictEqual(profile.education[0].level, "硕士");
assert.strictEqual(profile.education[0].startTime, "2022-09-01");
assert.strictEqual(profile.education[0].endTime, "2024-06-30");
assert.strictEqual(profile.education[1].startTime, "2018-09-01");
assert.strictEqual(profile.education[1].endTime, "2022-06-30");
assert.strictEqual(profile.education[0].schoolAffiliation, "国内高校");
assert.strictEqual(profile.basicInfo.graduationDate, "2024-06-30");
assert.strictEqual(profile.internshipExperience[0].startTime, "2023-04");
assert.strictEqual(profile.internshipExperience[0].startDate, "2023-04-30");
assert.strictEqual(profile.projectExperience[0].endTime, "2023-01");
assert.strictEqual(profile.projectExperience[0].endDate, "2023-01-31");
assert.strictEqual(profile.campusLeadership[0].roleDescription, "示例职责");
console.log("profile-adapter tests: PASS");
