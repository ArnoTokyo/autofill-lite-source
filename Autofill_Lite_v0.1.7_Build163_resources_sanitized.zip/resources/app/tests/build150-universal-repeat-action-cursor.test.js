"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
assert(/const BUILD_ID = \"\d{8}-[^\"]+-(?:15\d|1[6-9]\d|[2-9]\d{2,})\";/.test(main), "Build150+ ID missing");
const formSource = fs.readFileSync(path.join(root, "autofill-plugin/content/form-handler.js"), "utf8");
const runtimeSource = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-runtime.js"), "utf8");
for (const category of ["示例资料", "示例资料Experience", "示例资料Experience", "示例资料Members", "示例资料"]) {
  assert(formSource.includes(category + ": true"), `universal cursor capability missing ${category}`);
}
assert(formSource.includes('reasonCode: "manual_record_action_required"'), "mid-record action checkpoint missing");
assert(formSource.includes('nextGraphRepeatAction'), "next action resolver missing");
assert(formSource.includes('saveAction || universalCursorCategory'), "unfamiliar-site manual SAVE boundary missing");
assert(runtimeSource.includes('actionCursor: pauseOptions.nextAction ? createActionCursor'), "checkpoint must persist structured actionCursor");
assert(runtimeSource.includes('completedActions:'), "checkpoint must persist completed action prefix");

global.location = { href: "https://generic.example/resume", hostname: "generic.example", pathname: "/resume" };
global.document = { body: { click() {} } };
global.getComputedStyle = () => ({ display: "block", visibility: "visible", opacity: "1" });
global.window = {
  location: global.location,
  AF: {
    CheckpointCore: { recordFingerprint(row) { return JSON.stringify(row || {}); } },
    DomUtils: {
      isElementVisible(node) { return !!node && node.visible !== false && node.isConnected !== false; },
      isDateValue() { return false; }, isDatePicker() { return false; }, isSearchSelect() { return false; }, isNormalSelect() { return false; }
    },
    Utils: { async sleep() {} },
    FillTrace: { setFieldContext() {}, event() {}, readElementValue(el) { return String(el && el.value || ""); } },
    SelectAdapter: { _registry: { custom: true }, detectType() { return null; } }
  }
};
require(path.join(root, "autofill-plugin/content/form-handler.js"));
const AF = window.AF;

function node(value) {
  return { tagName: "INPUT", value: value || "", visible: true, isConnected: true, matches() { return false; }, getBoundingClientRect() { return { width: 100, height: 20 }; } };
}

const cases = [
  { category: "示例资料", title: "教育背景", row: { school: "人大", researchDirection: "财政", startTime: "示例资料" }, fields: ["school", "researchDirection", "startTime"], identity: { primary: "school", secondary: "startTime", requireSecondary: false } },
  { category: "示例资料Experience", title: "示例资料", row: { company: "甲公司", department: "研究部", startTime: "2026-01" }, fields: ["company", "department", "startTime"], identity: { primary: "company", secondary: "startTime", requireSecondary: false } },
  { category: "示例资料Experience", title: "项目经历", row: { 示例资料Name: "项目甲", detailedContent: "内容", startTime: "示例资料" }, fields: ["示例资料Name", "detailedContent", "startTime"], identity: { primary: "示例资料Name", secondary: "startTime", requireSecondary: false } },
  { category: "示例资料Members", title: "家庭成员", row: { name: "父亲", company: "某单位", relationship: "父子" }, fields: ["name", "company", "relationship"], identity: { primary: "name", secondary: "relationship", requireSecondary: true } },
  { category: "示例资料", title: "获奖信息", row: { awardName: "奖项甲", awardDescription: "说明", awardTime: "示例资料" }, fields: ["awardName", "awardDescription", "awardTime"], identity: { primary: "awardName", secondary: "awardTime", requireSecondary: false } }
];

(async () => {
  for (const c of cases) {
    const elements = c.fields.map(() => node(""));
    // Education school is a strict choice in the current generic bridge. Start it
    // with the target text so exact readback succeeds and the test can fail on the
    // second action like every 示例资料 category.
    if (c.category === "示例资料") elements[0].value = c.row.school;
    const mappings = c.fields.map((fieldKey, i) => ({ fieldId: `${c.category}-${fieldKey}`, category: c.category, fieldKey, selector: `#f${i}`, controlType: "text" }));
    const selectorMap = Object.fromEntries(mappings.map((m, i) => [m.selector, [elements[i]]]));
    const doc = { querySelectorAll(sel) { return selectorMap[sel] || []; } };
    const editor = { ownerDocument: doc, visible: true, isConnected: true, contains(el) { return elements.includes(el); }, querySelectorAll() { return []; } };
    elements.forEach(el => { el.ownerDocument = doc; });

    AF.RuntimeSemanticPatch = { hostname: location.hostname, pathname: location.pathname, recordSelectorMappings: mappings };
    AF.RecordGraph = { resolveRuntimeEditorOwnership() { return { status: "owned", confidence: 1, editorScope: editor, recordIndex: 0, mappings, ownershipMode: "identity_match", identityFieldKeys: c.identity }; } };
    const matcher = { config: { _aiSemanticPatch: { fieldMappings: mappings.map(m => ({ fieldId: m.fieldId, label: m.fieldKey })) } }, findContainerByTitle() { return editor; } };
    const dm = { resumeData: { [c.category]: [c.row] }, getCategoryByTitle() { return { category: c.category, type: "array", data: [c.row] }; } };

    let pause1 = null;
    const h1 = new AF.FormHandler(matcher, dm);
    h1.recordCheckpointRuntime = { resumed: false, previousCheckpoint: null, shouldSkip() { return false; }, async pause(meta, reason, opts) { pause1 = Object.assign({}, opts.failureContext || {}, { category: meta.category, 示例资料Index: meta.示例资料Index, 示例资料Total: meta.示例资料Total, recordFingerprint: meta.recordFingerprint, acknowledgeMode: opts.acknowledgeMode, nextAction: opts.nextAction, manualFields: opts.manualFields, committedFields: opts.committedFields, completedActions: opts.completedActions, actionCursor: { nextAction: opts.nextAction, completedActions: opts.completedActions || [] } }); return pause1; } };
    h1.fieldCheckpointRuntime = { async pause() { throw new Error("unexpected field checkpoint"); } };
    let call = 0;
    AF.FormHandler.fillFormElement = async function(el, value) { call++; if (call === 2) return false; el.value = String(value); return true; };
    const r1 = await h1.fillGraphBackedRepeatRecord({}, c.title, { specificCategory: c.category });
    assert.strictEqual(r1.success, false, `${c.category}: first run should pause`);
    assert.strictEqual(pause1.reasonCode, "manual_record_action_required", `${c.category}: wrong pause reason`);
    assert.deepStrictEqual(pause1.manualFields, [c.fields[1]], `${c.category}: wrong manual field`);
    assert.strictEqual(pause1.nextAction, `FIELD:${c.fields[2]}:${c.category}-${c.fields[2]}`, `${c.category}: cursor must point to third action`);

    // User manually fixes action 2. Rerun must execute only action 3, then stop at
    // a manual SAVE boundary even though this generic test site has no recognizable
    // save button.
    elements[1].value = String(c.row[c.fields[1]]);
    let pause2 = null;
    const h2 = new AF.FormHandler(matcher, dm);
    h2.recordCheckpointRuntime = { resumed: true, previousCheckpoint: pause1, shouldSkip() { return false; }, async pause(meta, reason, opts) { pause2 = Object.assign({}, opts.failureContext || {}, { category: meta.category, 示例资料Index: meta.示例资料Index, 示例资料Total: meta.示例资料Total, recordFingerprint: meta.recordFingerprint, acknowledgeMode: opts.acknowledgeMode, nextAction: opts.nextAction, committedFields: opts.committedFields, completedActions: opts.completedActions }); return pause2; } };
    h2.fieldCheckpointRuntime = { async pause() { throw new Error("unexpected field checkpoint"); } };
    const called = [];
    AF.FormHandler.fillFormElement = async function(el, value) { called.push(el); el.value = String(value); return true; };
    const r2 = await h2.fillGraphBackedRepeatRecord({}, c.title, { specificCategory: c.category });
    assert.strictEqual(r2.success, false, `${c.category}: resume should stop at SAVE`);
    assert.deepStrictEqual(called, [elements[2]], `${c.category}: only third action may execute after cursor`);
    assert.strictEqual(pause2.reasonCode, "manual_record_save_required", `${c.category}: must reach manual SAVE boundary`);
    assert.strictEqual(pause2.nextAction, "NEXT_RECORD", `${c.category}: SAVE acknowledgement should advance to next record`);
    assert.strictEqual(h2.lastExperienceResult.universalActionCursor, true, `${c.category}: universal cursor flag missing`);
    assert.strictEqual(h2.lastExperienceResult.saveActionObserved, false, `${c.category}: generic site should not invent save button`);
  }

  console.log("build150-universal-示例资料-action-cursor.test.js PASS");
})().catch(err => { console.error(err); process.exit(1); });
