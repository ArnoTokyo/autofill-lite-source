// Universal checkpoint runtime (Build136).
// One recovery session spans FIELD / RECORD / SECTION / WORKFLOW granularities.
// The persisted ledger exists only while an active checkpoint exists. A normal
// run starts clean, so old completion tokens can never become a permanent skip cache.
(function () {
  "use strict";

  var AF = (window.AF = window.AF || {});
  if (AF.CheckpointRuntime) return;

  var STORAGE_KEY = "offerAutofillUniversalCheckpointV1";
  var POLICY_VERSION = 1;
  var TTL_MS = 24 * 60 * 60 * 1000;
  var WORKFLOW_ID = "autofill-core-universal-v1";
  var GRANULARITIES = ["field", "record", "section", "workflow"];

  function core() { return AF.CheckpointCore || {}; }
  function routeKey(locationLike) {
    if (core().routeKey) return core().routeKey(locationLike || window.location);
    var loc = locationLike || window.location;
    var h = String(loc && loc.hash || "").split("?")[0];
    return String(loc && loc.pathname || "/") + h;
  }
  function hash(value) {
    if (core().hash) return core().hash(value);
    var text = String(value || ""); var current = 2166136261;
    for (var i = 0; i < text.length; i++) { current ^= text.charCodeAt(i); current = Math.imul(current, 16777619); }
    return ("00000000" + (current >>> 0).toString(16)).slice(-8);
  }
  function normalize(value) {
    return String(value == null ? "" : value).replace(/[\s：:*?？（）()【】\[\]「」'"“”‘’.,，。;；、]/g, "").toLowerCase();
  }
  function storageGet(keys) {
    return new Promise(function (resolve) {
      try { chrome.storage.local.get(keys, function (result) { resolve(result || {}); }); }
      catch (e) { resolve({}); }
    });
  }
  function storageSet(payload) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.storage.local.set(payload, function () {
          if (chrome.runtime && chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve();
        });
      } catch (e) { reject(e); }
    });
  }
  function storageRemove(keys) {
    return new Promise(function (resolve) {
      try { chrome.storage.local.remove(keys, function () { resolve(); }); }
      catch (e) { resolve(); }
    });
  }

  function fieldToken(meta) {
    if (core().formFieldToken) return core().formFieldToken(meta || {});
    meta = meta || {};
    return hash(String(meta.category || "") + "|" + String(meta.fieldKey || "") + "|" + Number(meta.occurrence || 0));
  }
  function recordToken(meta) {
    if (core().formRecordToken) return core().formRecordToken(meta || {});
    meta = meta || {};
    return hash(String(meta.category || "") + "|" + String(meta.recordFingerprint || "") + "|" + Number(meta.repeatIndex || 0));
  }
  function sectionToken(meta) {
    meta = meta || {};
    return hash("section|" + normalize(meta.sectionTitle || meta.label || "") + "|" + normalize(meta.category || ""));
  }
  function workflowToken(meta) {
    meta = meta || {};
    return hash("workflow|" + normalize(meta.workflowId || WORKFLOW_ID) + "|" + normalize(meta.name || meta.sectionTitle || ""));
  }
  function tokenFor(meta, granularity) {
    granularity = String(granularity || meta && meta.granularity || "field");
    if (granularity === "record") return recordToken(meta);
    if (granularity === "section") return sectionToken(meta);
    if (granularity === "workflow") return workflowToken(meta);
    return fieldToken(meta);
  }

  function sectionTokenForMeta(meta) {
    meta = meta || {};
    if (meta.sectionToken) return String(meta.sectionToken);
    if (meta.sectionTitle) return sectionToken(meta);
    return "";
  }

  function blankCompleted() {
    return { field: [], record: [], section: [], workflow: [] };
  }
  function cloneCompleted(raw) {
    var out = blankCompleted();
    GRANULARITIES.forEach(function (g) {
      out[g] = Array.isArray(raw && raw[g]) ? raw[g].slice(0, g === "field" || g === "record" ? 500 : 200) : [];
    });
    return out;
  }
  function toSets(completed) {
    var sets = {};
    GRANULARITIES.forEach(function (g) { sets[g] = new Set(Array.isArray(completed[g]) ? completed[g] : []); });
    return sets;
  }
  function fromSets(sets) {
    var out = blankCompleted();
    GRANULARITIES.forEach(function (g) { out[g] = Array.from(sets[g] || []).slice(0, g === "field" || g === "record" ? 500 : 200); });
    return out;
  }

  function validSession(session, loc, workflowId) {
    if (!session || typeof session !== "object") return false;
    if (Number(session.policyVersion || 0) !== POLICY_VERSION) return false;
    if (String(session.status || "") !== "waiting_recovery") return false;
    if (String(session.workflowId || "") !== String(workflowId || WORKFLOW_ID)) return false;
    if (String(session.hostname || "") !== String(loc && loc.hostname || "")) return false;
    if (String(session.routeKey || "") !== routeKey(loc)) return false;
    if (Date.now() - Number(session.updatedAt || 0) > TTL_MS) return false;
    return !!(session.active && session.active.token && GRANULARITIES.indexOf(String(session.active.granularity || "")) >= 0);
  }

  async function loadSession(locationLike, workflowId) {
    var loc = locationLike || window.location;
    try {
      var stored = await storageGet([STORAGE_KEY]);
      var session = stored && stored[STORAGE_KEY];
      if (!validSession(session, loc, workflowId)) {
        if (session) await storageRemove([STORAGE_KEY]);
        return null;
      }
      return session;
    } catch (e) { return null; }
  }

  async function clearSession() { await storageRemove([STORAGE_KEY]); }

  function buildGenericFailure(meta, rawReason, options) {
    meta = meta || {}; options = options || {};
    var granularity = String(meta.granularity || options.granularity || "section");
    if (granularity === "field" && core().buildFormFieldFailureContext) return core().buildFormFieldFailureContext(meta, rawReason);
    if (granularity === "record" && core().buildFormRecordFailureContext) return core().buildFormRecordFailureContext(meta, rawReason);

    var title = String(meta.sectionTitle || meta.label || meta.name || (granularity === "workflow" ? "当前流程" : "当前分区"));
    var classification = core().classifyRecoverableFailure
      ? core().classifyRecoverableFailure({ cardTitle: title, category: meta.category || "" }, rawReason, options.result || null)
      : { recoverability: "UNSAFE_STOP", reasonCode: "unclassified_failure" };
    if (options.forceRecoverable) classification = { recoverability: "RECOVERABLE_MANUAL", reasonCode: options.reasonCode || "manual_completion_required" };
    var recoverable = classification.recoverability;
    var summary = granularity === "workflow" ? title + "需要人工处理" : title + "没有完全自动完成";
    var action = "请处理当前页面后再次点击“一键填写”，程序会从后续内容继续。";
    if (recoverable === "SAFE_AUTO_RETRY") {
      summary = title + "遇到临时页面状态问题";
      action = "请稍后再次点击“一键填写”，程序会从这里继续。";
    } else if (recoverable === "UNSAFE_STOP") {
      summary = title + "的页面状态无法安全确认";
      action = "为避免覆盖已有内容，程序已停止自动操作；请先人工检查当前页面。";
    }
    return {
      workflowId: String(meta.workflowId || WORKFLOW_ID),
      stepIndex: -1,
      stepName: title,
      category: String(meta.category || ""),
      repeatIndex: Number.isInteger(Number(meta.repeatIndex)) ? Number(meta.repeatIndex) : -1,
      repeatTotal: Number(meta.repeatTotal || 0),
      fieldKey: granularity === "section" ? "section" : "workflow",
      fieldLabel: title,
      phase: String(options.phase || "fill"),
      reasonCode: String(options.reasonCode || classification.reasonCode || "manual_completion_required"),
      failureClass: String(options.failureClass || (core().classifyFailureClass ? core().classifyFailureClass({ cardTitle: title, category: meta.category || "" }, rawReason, options.result || null, recoverable) : "UNKNOWN")),
      rawReason: String(rawReason || "当前内容需要人工处理").slice(0, 240),
      humanSummary: summary,
      suggestedAction: action,
      recoverability: recoverable,
      recordFingerprint: String(meta.recordFingerprint || ""),
      granularity: granularity,
      unitToken: tokenFor(meta, granularity),
      sectionToken: sectionTokenForMeta(meta)
    };
  }

  async function begin(locationLike, options) {
    var loc = locationLike || window.location;
    options = options || {};
    var workflowId = String(options.workflowId || WORKFLOW_ID);
    var previous = await loadSession(loc, workflowId);
    // Build136 migration: generic FormGraph recovery is now session-scoped in one
    // store.  Legacy field/record stores are never authoritative after this point.
    try {
      await storageRemove([
        "offerAutofillFormFieldCheckpointV1", "offerAutofillFormFieldLedgerV1",
        "offerAutofillFormRecordCheckpointV1", "offerAutofillFormRecordLedgerV1"
      ]);
    } catch (eLegacy) {}

    var completed = cloneCompleted(previous && previous.completed);
    var sets = toSets(completed);
    var active = previous && previous.active || null;
    var acknowledgeMode = String(active && active.acknowledgeMode || "complete_on_rerun");
    if (active && active.granularity && active.token && sets[active.granularity] && acknowledgeMode !== "review_then_save" && acknowledgeMode !== "resume_at_action_cursor") {
      // Most checkpoints keep the established Build136 contract: rerun itself is
      // the user's acknowledgement that the paused unit is finished. A manual
      // field-review checkpoint is different: rerun means "I corrected the
      // fields; protect them and finish this same record safely", so the record
      // must NOT be pre-completed here.
      sets[active.granularity].add(String(active.token));
    }
    await clearSession();
    if (!previous && core().clearHumanOverrideLedger) {
      try { await core().clearHumanOverrideLedger(); } catch (eHumanClear) {}
    }

    var runtime = {
      enabled: true,
      workflowId: workflowId,
      resumed: !!previous,
      checkpointResolved: !!previous,
      previousCheckpoint: active,
      activeGranularity: String(active && active.granularity || ""),
      completed: sets,
      paused: false,
      checkpointCreated: false,
      checkpoint: null,
      failureContext: null,
      startedAt: Date.now(),
      location: loc
    };

    runtime.tokenFor = function (meta, granularity) { return tokenFor(meta, granularity); };
    runtime.shouldSkip = function (meta, granularity) {
      granularity = String(granularity || meta && meta.granularity || "field");
      var token = tokenFor(meta, granularity);
      return !!(token && runtime.completed[granularity] && runtime.completed[granularity].has(token));
    };
    runtime.markCompleted = async function (meta, granularity) {
      granularity = String(granularity || meta && meta.granularity || "field");
      var token = tokenFor(meta, granularity);
      if (token && runtime.completed[granularity]) runtime.completed[granularity].add(token);
      return token;
    };
    runtime.pause = async function (meta, rawReason, pauseOptions) {
      if (runtime.paused) return runtime.checkpoint;
      pauseOptions = pauseOptions || {};
      var granularity = String(meta && meta.granularity || pauseOptions.granularity || "section");
      var context = pauseOptions.failureContext || buildGenericFailure(meta, rawReason, pauseOptions);
      if (!context || (context.recoverability === "UNSAFE_STOP" && !pauseOptions.forceRecoverable)) return null;
      var token = tokenFor(meta, granularity);
      var sectionTok = sectionTokenForMeta(meta);
      var marker = {
        version: 1,
        policyVersion: POLICY_VERSION,
        acknowledgeOnRerun: true,
        workflowId: workflowId,
        hostname: String(loc && loc.hostname || ""),
        routeKey: routeKey(loc),
        status: "waiting_recovery",
        active: {
          granularity: granularity,
          token: token,
          sectionToken: sectionTok,
          sectionTitle: String(meta && meta.sectionTitle || ""),
          category: String(meta && meta.category || ""),
          fieldKey: String(meta && meta.fieldKey || ""),
          fieldLabel: String(meta && meta.label || meta && meta.fieldLabel || ""),
          recordFingerprint: String(meta && meta.recordFingerprint || ""),
          repeatIndex: Number.isInteger(Number(meta && meta.repeatIndex)) ? Number(meta.repeatIndex) : -1,
          repeatTotal: Number(meta && meta.repeatTotal || 0),
          reasonCode: String(context.reasonCode || "manual_completion_required"),
          failureClass: String(context.failureClass || "UNKNOWN"),
          humanSummary: String(context.humanSummary || "当前内容需要人工处理"),
          suggestedAction: String(context.suggestedAction || "请手动处理后再次运行"),
          acknowledgeMode: String(pauseOptions.acknowledgeMode || "complete_on_rerun"),
          nextAction: String(pauseOptions.nextAction || ""),
          freezeBeforeCursor: !!pauseOptions.freezeBeforeCursor,
          manualFields: Array.isArray(pauseOptions.manualFields) ? pauseOptions.manualFields.map(String).filter(Boolean).slice(0, 100) : [],
          committedFields: Array.isArray(pauseOptions.committedFields) ? pauseOptions.committedFields.map(String).filter(Boolean).slice(0, 100) : [],
          completedActions: Array.isArray(pauseOptions.completedActions) ? pauseOptions.completedActions.map(String).filter(Boolean).slice(0, 200) : [],
          actionCursor: pauseOptions.nextAction ? createActionCursor({
            recordToken: granularity === "record" ? token : "",
            recordFingerprint: String(meta && meta.recordFingerprint || ""),
            nextAction: String(pauseOptions.nextAction || ""),
            completedActions: Array.isArray(pauseOptions.completedActions) ? pauseOptions.completedActions : []
          }) : null
        },
        completed: fromSets(runtime.completed),
        updatedAt: Date.now()
      };
      var payload = {}; payload[STORAGE_KEY] = marker;
      await storageSet(payload);
      runtime.paused = true;
      runtime.checkpointCreated = true;
      runtime.checkpoint = marker;
      runtime.failureContext = context;
      return marker;
    };
    runtime.finalize = async function () {
      // If no new pause was created, the recovery chain is complete. Nothing is
      // persisted: normal later runs must re-scan the current page from scratch.
      if (!runtime.paused) {
        await clearSession();
        if (core().clearHumanOverrideLedger) {
          try { await core().clearHumanOverrideLedger(); } catch (eHumanFinalize) {}
        }
      }
    };
    return runtime;
  }

  function facade(runtime, granularity) {
    granularity = String(granularity || "field");
    var previous = runtime && runtime.previousCheckpoint;
    var sameResume = !!(runtime && runtime.resumed && previous && previous.granularity === granularity);
    var out = {
      enabled: !!runtime,
      granularity: granularity,
      resumed: sameResume,
      checkpointResolved: sameResume,
      previousCheckpoint: sameResume ? previous : null,
      resumeFieldSeen: sameResume && granularity === "field",
      resumeRecordSeen: sameResume && granularity === "record",
      resumeSectionSeen: sameResume && granularity === "section",
      resumeWorkflowSeen: sameResume && granularity === "workflow",
      tokenFor: function (meta) { return tokenFor(meta, granularity); },
      shouldSkip: function (meta) { return runtime ? runtime.shouldSkip(meta, granularity) : false; },
      markCompleted: function (meta) { return runtime ? runtime.markCompleted(meta, granularity) : Promise.resolve(""); },
      pause: function (meta, rawReason, opts) {
        meta = Object.assign({}, meta || {}, { granularity: granularity });
        return runtime ? runtime.pause(meta, rawReason, opts || {}) : Promise.resolve(null);
      },
      snapshotLedger: function () {
        var tokens = runtime && runtime.completed && runtime.completed[granularity] ? Array.from(runtime.completed[granularity]) : [];
        var countKey = granularity === "field" ? "completedFieldCount" : granularity === "record" ? "completedRecordCount" : granularity === "section" ? "completedSectionCount" : "completedWorkflowCount";
        var listKey = granularity === "field" ? "completedFieldTokens" : granularity === "record" ? "completedRecordTokens" : granularity === "section" ? "completedSectionTokens" : "completedWorkflowTokens";
        var snap = { version: 3, policyVersion: POLICY_VERSION, granularity: granularity, observeOnly: false, workflowId: runtime && runtime.workflowId || WORKFLOW_ID, hostname: String(runtime && runtime.location && runtime.location.hostname || ""), routeKey: routeKey(runtime && runtime.location), updatedAt: Date.now() };
        snap[countKey] = tokens.length; snap[listKey] = tokens.slice(0, 100); return snap;
      }
    };
    Object.defineProperties(out, {
      paused: { get: function () { return !!(runtime && runtime.paused && runtime.failureContext && runtime.failureContext.granularity === granularity); } },
      checkpointCreated: { get: function () { return !!(runtime && runtime.checkpointCreated && runtime.failureContext && runtime.failureContext.granularity === granularity); } },
      checkpoint: { get: function () { return out.paused ? runtime.checkpoint : null; } },
      failureContext: { get: function () { return out.paused ? runtime.failureContext : null; } },
      ledger: { get: function () { return out.snapshotLedger(); } }
    });
    return out;
  }

  function snapshot(runtime) {
    if (!runtime) return null;
    var completed = fromSets(runtime.completed || {});
    return {
      version: 3,
      policyVersion: POLICY_VERSION,
      workflowId: String(runtime.workflowId || WORKFLOW_ID),
      resumed: !!runtime.resumed,
      checkpointResolved: !!runtime.checkpointResolved,
      checkpointCreated: !!runtime.checkpointCreated,
      paused: !!runtime.paused,
      activeGranularity: String(runtime.failureContext && runtime.failureContext.granularity || runtime.activeGranularity || ""),
      previousGranularity: String(runtime.previousCheckpoint && runtime.previousCheckpoint.granularity || ""),
      completedFieldCount: completed.field.length,
      completedRecordCount: completed.record.length,
      completedSectionCount: completed.section.length,
      completedWorkflowCount: completed.workflow.length,
      updatedAt: Date.now()
    };
  }


  // Build153: normalize action ids into a small execution vocabulary. The
  // cursor remains metadata-only; execution owners decide whether an action is
  // safe. Keeping both the raw id and parsed shape preserves Build149-152 data.
  function parseActionId(actionId) {
    var raw = String(actionId || "");
    if (!raw) return { raw: "", type: "NONE", fieldKey: "", fieldId: "" };
    if (raw.indexOf("FIELD:") === 0) {
      var parts = raw.split(":");
      return { raw: raw, type: "FIELD", fieldKey: String(parts[1] || ""), fieldId: parts.slice(2).join(":") };
    }
    if (/^(SAVE|NEXT_RECORD|OPEN_NEXT_RECORD|FILL_NEXT_RECORD|SECTION_DONE|WORKFLOW_DONE)$/.test(raw)) {
      return { raw: raw, type: raw, fieldKey: "", fieldId: "" };
    }
    return { raw: raw, type: "CUSTOM", fieldKey: "", fieldId: "" };
  }

  function createActionCursor(meta) {
    meta = meta || {};
    var parsed = parseActionId(meta.nextAction);
    return {
      version: 2,
      recordToken: String(meta.recordToken || ""),
      recordFingerprint: String(meta.recordFingerprint || ""),
      nextAction: parsed.raw,
      nextActionType: parsed.type,
      nextFieldKey: parsed.fieldKey,
      nextFieldId: parsed.fieldId,
      completedActions: Array.isArray(meta.completedActions) ? meta.completedActions.map(String).filter(Boolean) : [],
      frozenBeforeCursor: true,
      createdAt: Date.now()
    };
  }

  function shouldResumeFromCursor(checkpoint, actionId) {
    if (!checkpoint || !checkpoint.active) return false;
    if (!checkpoint.active.actionCursor) return false;
    var next = String(checkpoint.active.actionCursor.nextAction || "");
    return !!next && String(actionId || "") === next;
  }

  function snapshotActionCursor(checkpoint) {
    var cursor = checkpoint && checkpoint.active && checkpoint.active.actionCursor;
    return cursor ? {
      nextAction: String(cursor.nextAction || ""),
      nextActionType: String(cursor.nextActionType || parseActionId(cursor.nextAction).type),
      nextFieldKey: String(cursor.nextFieldKey || parseActionId(cursor.nextAction).fieldKey),
      nextFieldId: String(cursor.nextFieldId || parseActionId(cursor.nextAction).fieldId),
      completedActions: Array.isArray(cursor.completedActions) ? cursor.completedActions.slice() : [],
      frozenBeforeCursor: !!cursor.frozenBeforeCursor
    } : null;
  }

  AF.CheckpointRuntime = {
    version: 3,
    POLICY_VERSION: POLICY_VERSION,
    STORAGE_KEY: STORAGE_KEY,
    WORKFLOW_ID: WORKFLOW_ID,
    begin: begin,
    facade: facade,
    snapshot: snapshot,
    tokenFor: tokenFor,
    fieldToken: fieldToken,
    recordToken: recordToken,
    sectionToken: sectionToken,
    workflowToken: workflowToken,
    buildFailureContext: buildGenericFailure,
    clear: clearSession,
    parseActionId: parseActionId,
    createActionCursor: createActionCursor,
    shouldResumeFromCursor: shouldResumeFromCursor,
    snapshotActionCursor: snapshotActionCursor
  };
})();
