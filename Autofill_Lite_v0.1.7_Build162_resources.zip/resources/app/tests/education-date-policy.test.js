"use strict";
const assert = require("assert");
const { normalizeProfileBackup } = require("../profile-adapter");

const raw = { profileV2: { sections: {
  basic: { values: { "姓名": "测试用户" } },
  intention: { items: [] },
  education: { items: [
    { values: { "学校": "A大学", "学历": "本科", "开始时间": "2021-09", "结束时间": "2025-06" } },
    { values: { "学校": "B大学", "学历": "硕士", "开始日期": "2025-09-18", "结束日期": "2027-06-15" } }
  ] },
  internship: { items: [{ values: { "公司": "X", "开始时间": "2026-05", "结束时间": "2026-08" } }] },
  project: { items: [] }, student: { items: [] }, awards: { items: [] }, language: { items: [] }, family: { items: [] },
  self: { values: {} }, other: { values: {} }
} } };

const out = normalizeProfileBackup(raw);
assert.strictEqual(out.education[0].school, "B大学");
assert.strictEqual(out.education[0].startTime, "2025-09-01");
assert.strictEqual(out.education[0].endTime, "2027-06-30");
assert.strictEqual(out.education[1].startTime, "2021-09-01");
assert.strictEqual(out.education[1].endTime, "2025-06-30");
assert.strictEqual(out.basicInfo.graduationDate, "2027-06-30");
assert.strictEqual(out.internshipExperience[0].startTime, "2026-05");
assert.strictEqual(out.internshipExperience[0].endTime, "2026-08");
console.log("education-date-policy tests: PASS");
