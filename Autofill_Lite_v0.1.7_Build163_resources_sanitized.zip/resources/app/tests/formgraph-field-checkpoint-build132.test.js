"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const coreSource = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-core.js"), "utf8");
const handler = fs.readFileSync(path.join(root, "autofill-plugin/content/form-handler.js"), "utf8");
const engine = fs.readFileSync(path.join(root, "autofill-plugin/content/fill-engine.js"), "utf8");
const adapter = fs.readFileSync(path.join(root, "autofill-plugin/content/electron-adapter.js"), "utf8");

assert(/const BUILD_ID = \"202609\d{2}-[^\"]+-\d+\";/.test(main), "A: current numeric Build id missing");
assert(main.includes("formFieldCheckpoint:"), "A: generic field checkpoint diagnostic missing");
assert(coreSource.includes('FORM_FIELD_CHECKPOINT_STORAGE_KEY = "offerAutofillFormFieldCheckpointV1"'), "B: FIELD checkpoint storage missing");
assert(coreSource.includes('FORM_FIELD_LEDGER_STORAGE_KEY = "offerAutofillFormFieldLedgerV1"'), "B: FIELD ledger storage missing");
assert(coreSource.includes('granularity: "field"'), "B: field checkpoint granularity missing");
assert(coreSource.includes('acknowledgeOnRerun: true'), "B: user-ack recovery semantic missing");
assert(handler.includes("this.fieldCheckpointRuntime = null"), "C: FormHandler field checkpoint runtime missing");
assert(handler.includes("isSafeFormFieldCheckpointControl"), "C: scalar checkpoint safety gate missing");
assert(handler.includes('tag === "select" && type === "select"'), "C: native select eligibility missing");
assert(!/isSafeFormFieldCheckpointControl[\s\S]{0,1200}type === "search"/.test(handler), "C: search/cascader must not be generic field-checkpoint eligible");
assert(handler.includes('fieldCheckpointRuntime.shouldSkip(fieldCheckpointMeta)'), "C: resumed fields must be skipped by stable token");
assert(handler.includes('fieldCheckpointRuntime.pause(fieldCheckpointMeta'), "C: safe scalar failure must create field checkpoint");
assert(engine.includes("beginFormFieldCheckpointRuntime"), "D: FillEngine must initialize generic FIELD runtime");
assert(engine.includes("applyFormFieldCheckpointResult"), "D: FIELD checkpoint must be surfaced in result");
assert(engine.includes("runtime.resumeFieldSeen"), "D: final-field recovery completion guard missing");
assert(adapter.includes("!result.manualActionRequired"), "D: server fallback must not override a paused field checkpoint");

const store = {};
const sandbox = {
  window: { AF: {}, location: { hostname: "generic.example", pathname: "/resume", hash: "" } },
  chrome: {
    storage: { local: {
      get(keys, cb) { const out = {}; keys.forEach(k => { if (Object.prototype.hasOwnProperty.call(store, k)) out[k] = store[k]; }); cb(out); },
      set(payload, cb) { Object.assign(store, payload); cb && cb(); },
      remove(keys, cb) { keys.forEach(k => delete store[k]); cb && cb(); }
    } },
    runtime: { lastError: null }
  },
  console, Date, Math, Promise, Set, setTimeout, clearTimeout
};
vm.createContext(sandbox);
vm.runInContext(coreSource, sandbox, { filename: "checkpoint-core.js" });
const core = sandbox.window.AF.CheckpointCore;

(async () => {
  const loc = sandbox.window.location;
  const meta1 = { category: "示例资料Info", fieldKey: "name", label: "姓名", occurrence: 0, controlType: "text" };
  const meta2 = { category: "示例资料Info", fieldKey: "hukouLocation", label: "户口所在地", occurrence: 0, controlType: "select" };
  const fresh = await core.beginFormFieldRun(loc);
  assert.strictEqual(fresh.resumed, false, "E: fresh FormGraph run must not resume");
  await fresh.markCompleted(meta1);
  const cp = await fresh.pause(meta2, "普通字段填写失败");
  assert(cp && cp.granularity === "field", "E: field checkpoint not persisted");
  assert.strictEqual(cp.acknowledgeOnRerun, true, "E: field checkpoint must use user acknowledgement");
  assert(cp.completedFieldTokens.includes(core.formFieldToken(meta1)), "E: completed field token not saved");

  const resumed = await core.beginFormFieldRun(loc);
  assert.strictEqual(resumed.resumed, true, "F: rerun must acknowledge previous field checkpoint");
  assert.strictEqual(resumed.checkpointResolved, true, "F: rerun must surface checkpoint as resolved");
  assert.strictEqual(resumed.shouldSkip(meta1), true, "F: completed pre-checkpoint field must skip");
  assert.strictEqual(resumed.shouldSkip(meta2), true, "F: manually handled failed field must skip");
  assert.strictEqual(resumed.resumeFieldSeen, true, "F: failed-field token should be observed on resume");
  const cleared = await core.loadFormFieldCheckpoint(loc);
  assert.strictEqual(cleared, null, "F: acknowledged field checkpoint must be cleared before continuing");

  const snap = core.snapshotFormFieldRuntime(resumed);
  assert.strictEqual(snap.granularity, "field", "G: field runtime snapshot granularity incorrect");
  assert.strictEqual(snap.ledger.completedFieldCount, 1, "G: FIELD ledger should contain only pre-checkpoint completed field");
  console.log("formgraph-field-checkpoint-build132.test.js passed (A-G)");
})().catch(err => { console.error(err); process.exit(1); });
