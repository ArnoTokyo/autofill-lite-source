"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const workflow = fs.readFileSync(path.join(root, "autofill-plugin", "content", "special-site-workflow.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");

assert(workflow.includes("function analyzedBatchSaveFindOpenEditor"), "save batch must be able to adopt a visible pre-opened editor");
assert(workflow.includes('acquisition: "adopted_existing_editor"'), "adopted-editor acquisition trace missing");
assert(workflow.includes('trace.editorAcquisition = opened.acquisition'), "save trace must expose editor acquisition path");
assert(workflow.includes("existingEditorFieldMatchCount"), "save trace must expose matched visible editor fields");
assert(workflow.includes("analyzedBatchPreviewAwardNameAliases(row.awardName)"), "award identity should accept the normalized fixed-list category as an alias");
console.log("open editor resume test: PASS");
