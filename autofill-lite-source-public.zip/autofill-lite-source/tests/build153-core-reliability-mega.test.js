"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const root = path.join(__dirname, "..");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const recordSource = fs.readFileSync(path.join(root, "autofill-plugin/content/record-graph.js"), "utf8");
const experienceSource = fs.readFileSync(path.join(root, "autofill-plugin/content/experience-handler.js"), "utf8");
const formSource = fs.readFileSync(path.join(root, "autofill-plugin/content/form-handler.js"), "utf8");
const matcherSource = fs.readFileSync(path.join(root, "autofill-plugin/content/data-matcher.js"), "utf8");
const coreSource = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-core.js"), "utf8");
const runtimeSource = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-runtime.js"), "utf8");

const buildMatch = main.match(/const BUILD_ID = "([^"]+)-(\d+)";/);
assert(buildMatch && Number(buildMatch[2]) >= 153, "A: Build153+ id missing");

// RecordGraph/ExperienceHandler share one browser identity contract.
const graph = require(path.join(root, "autofill-plugin/content/record-graph.js"));
const expectedCategories = [
  "education", "workExperience", "internshipExperience", "projectExperience",
  "campusLeadership", "campusActivities", "trainingExperience", "awards",
  "certificates", "publications", "patents", "languageSkills", "familyMembers"
];
assert.deepStrictEqual(graph.supportedCategories.slice().sort(), expectedCategories.slice().sort(), "B: repeat category contract mismatch");
expectedCategories.forEach(c => assert(graph.identityRules[c], "B: missing identity rule " + c));
assert(experienceSource.includes("AF.RecordGraph && AF.RecordGraph.identityRules"), "B: ExperienceHandler must consume RecordGraph identity rules");
assert(formSource.includes('typeof AF.RecordGraph.supportsCategory === "function"'), "B: Action Cursor capability must follow RecordGraph");
expectedCategories.forEach(c => assert(formSource.includes(c + ": true"), "B: generic cursor fallback missing " + c));

// DataMatcher must treat every array resume module as a repeat/experience category.
const expListMatch = matcherSource.match(/this\.EXPERIENCE_CATEGORIES\s*=\s*\[([^\]]+)\]/);
assert(expListMatch, "C: EXPERIENCE_CATEGORIES missing");
expectedCategories.forEach(c => assert(expListMatch[1].includes('"' + c + '"'), "C: DataMatcher missing repeat category " + c));
assert(matcherSource.includes("Build153 local-first semantic vetoes"), "C: local semantic veto layer missing");

// Failure taxonomy remains orthogonal to recoverability.
const store = {};
const sandbox = {
  window: { AF: {}, location: { hostname: "example.test", pathname: "/resume", hash: "" } },
  chrome: { storage: { local: {
    get(keys, cb) { const out = {}; keys.forEach(k => { if (Object.prototype.hasOwnProperty.call(store, k)) out[k] = store[k]; }); cb(out); },
    set(payload, cb) { Object.assign(store, payload); cb && cb(); },
    remove(keys, cb) { keys.forEach(k => delete store[k]); cb && cb(); }
  } }, runtime: { lastError: null } },
  console, Date, Math, Promise, setTimeout, clearTimeout
};
vm.createContext(sandbox);
vm.runInContext(coreSource, sandbox, { filename: "checkpoint-core.js" });
vm.runInContext(runtimeSource, sandbox, { filename: "checkpoint-runtime.js" });
const core = sandbox.window.AF.CheckpointCore;
const runtime = sandbox.window.AF.CheckpointRuntime;
assert(core.FAILURE_CLASSES && core.classifyFailureClass, "D: failure taxonomy API missing");
assert.strictEqual(core.classifyFailureClass(null, "内容长度超过限制", null, "RECOVERABLE_MANUAL"), "VALIDATION_FAILED");
assert.strictEqual(core.classifyFailureClass(null, "请上传附件", null, "RECOVERABLE_MANUAL"), "MANUAL_UPLOAD_REQUIRED");
assert.strictEqual(core.classifyFailureClass(null, "record ownership 无法安全确认", null, "UNSAFE_STOP"), "RECORD_OWNER_UNKNOWN");
assert.strictEqual(core.classifyFailureClass(null, "record_save_state_unknown", null, "UNSAFE_STOP"), "TRANSACTION_UNSAFE");
assert.strictEqual(core.classifyRecoverableFailure(null, "record ownership 无法安全确认", {}).recoverability, "UNSAFE_STOP", "D: taxonomy must not relax recoverability");
const failure = core.buildFailureContext({ id: "wf" }, { name: "奖项", category: "awards" }, "日期控件填写失败", { failedFields: [{ fieldKey: "awardTime", label: "获奖时间", reason: "日期控件填写失败" }] });
assert.strictEqual(failure.failureClass, "CONTROL_UNSUPPORTED", "D: failure context taxonomy missing");

// Action Cursor v2 must preserve raw ids while exposing a parsed execution shape.
assert(runtime.parseActionId, "E: action parser missing");
assert.deepStrictEqual(JSON.parse(JSON.stringify(runtime.parseActionId("FIELD:awardTime:field-7"))), { raw: "FIELD:awardTime:field-7", type: "FIELD", fieldKey: "awardTime", fieldId: "field-7" });
assert.strictEqual(runtime.parseActionId("SAVE").type, "SAVE");
const cursor = runtime.createActionCursor({ recordToken: "r1", recordFingerprint: "fp", nextAction: "FIELD:degree:edu-degree", completedActions: ["FIELD:school:edu-school"] });
assert.strictEqual(cursor.version, 2, "E: action cursor schema must advance");
assert.strictEqual(cursor.nextAction, "FIELD:degree:edu-degree");
assert.strictEqual(cursor.nextActionType, "FIELD");
assert.strictEqual(cursor.nextFieldKey, "degree");
assert.strictEqual(cursor.nextFieldId, "edu-degree");
assert.deepStrictEqual(cursor.completedActions, ["FIELD:school:edu-school"]);

console.log("build153-core-reliability-mega.test.js PASS");
