"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

class FakeElement {
  constructor(tag, className, text) {
    this.tagName = tag.toUpperCase();
    this.className = className || "";
    this.textContent = text || "";
    this.children = [];
    this.parentElement = null;
    this.isConnected = true;
    this.styleState = { display: "block", visibility: "visible" };
    this.rect = { x: 0, y: 0, left: 0, top: 0, right: 120, bottom: 24, width: 120, height: 24 };
  }
  append(child) { child.parentElement = this; this.children.push(child); return child; }
  contains(node) { return node === this || this.children.some((child) => child.contains(node)); }
  matches(selector) { return selector === ".el-form-item" ? this.className.split(/\s+/).includes("el-form-item") : false; }
  closest(selector) {
    for (let node = this; node; node = node.parentElement) {
      if (selector.includes(".el-form-item") && node.matches(".el-form-item")) return node;
      if (selector.includes(".apply-module") && String(node.className || "").includes("apply-module")) return node;
    }
    return null;
  }
  getBoundingClientRect() { return this.rect; }
  getClientRects() { return this.rect.width > 0 && this.rect.height > 0 ? [this.rect] : []; }
  getAttribute(name) { return name === "aria-hidden" ? null : null; }
  querySelector(selector) {
    if (selector.includes("el-form-item__content")) return this.children.find((child) => child.className.includes("el-form-item__content")) || null;
    if (selector.includes("apply-form-read-only") || selector.includes("labelOnly-text")) return this.querySelectorAll(".apply-form-read-only, .labelOnly-text")[0] || null;
    if (selector.includes("resume-menu-item__title") || selector.includes("h6")) return this.children.find((child) => child.className.includes("resume-menu-item__title") || child.tagName === "H6") || null;
    if (selector.includes("el-form-item__label") || selector === "label") return this.querySelectorAll("label")[0] || null;
    return null;
  }
  querySelectorAll(selector) {
    const all = [];
    const walk = (node) => { for (const child of node.children) { all.push(child); walk(child); } };
    walk(this);
    if (selector === ".apply-form-read-only, .labelOnly-text") return all.filter((node) => /apply-form-read-only|labelOnly-text/.test(node.className));
    if (selector === ".el-form-item.is-error, .el-form-item__error") return all.filter((node) => /is-error|el-form-item__error/.test(node.className));
    if (selector === "label") return all.filter((node) => node.tagName === "LABEL");
    if (selector === "button, a, [role='button']") return all.filter((node) => node.tagName === "BUTTON" || node.tagName === "A");
    if (selector.includes(".icon-box")) return all.filter((node) => node.className.includes("icon-box") || node.tagName === "BUTTON" || node.tagName === "A");
    if (selector.includes("button") && selector.includes("div") && selector.includes("span")) return all.filter((node) => ["BUTTON", "A", "DIV", "SPAN"].includes(node.tagName));
    if (selector.startsWith("button")) return all.filter((node) => node.tagName === "BUTTON");
    if (selector.startsWith("label,") || selector.includes("[class*='label']")) return all.filter((node) => ["LABEL", "SPAN", "DIV"].includes(node.tagName));
    if (selector.includes("[contenteditable='true']") && selector.includes(".el-date-editor")) {
      return all.filter((node) => {
        const classes = String(node.className || "");
        return ["INPUT", "TEXTAREA", "SELECT"].includes(node.tagName)
          || /(?:^|\s)el-(?:input|select|cascader|date-editor)(?:\s|$)/.test(classes);
      });
    }
    if (/el-date-editor/.test(selector)) return all.filter((node) => node.className.includes("el-date-editor"));
    if (/textarea|input/.test(selector) && /combobox/.test(selector)) return all.filter((node) => node.tagName === "INPUT" || node.tagName === "TEXTAREA" || node.className.includes("el-select"));
    if (/el-select|combobox|select/.test(selector)) return all.filter((node) => node.className.includes("el-select"));
    if (/textarea|input/.test(selector)) return all.filter((node) => node.tagName === "INPUT" || node.tagName === "TEXTAREA");
    return [];
  }
}

global.HTMLElement = FakeElement;
global.Element = FakeElement;
global.document = { body: new FakeElement("body"), documentElement: { _attrs: {}, getAttribute(k) { return this._attrs[k] || null; }, setAttribute(k,v) { this._attrs[k] = v; } } };
global.window = { AF: {}, top: null, location: { hostname: "test", pathname: "/", href: "https://test/" }, getComputedStyle: (el) => el.styleState, sessionStorage: { getItem() { return null; }, removeItem() {} } };
window.top = window;
const realSetTimeout = global.setTimeout;
global.setTimeout = () => 0;
const source = fs.readFileSync(path.join(__dirname, "..", "autofill-plugin", "content", "special-site-示例资料flow.js"), "utf8");
new Function(source)();
global.setTimeout = realSetTimeout;

function field(scope, labelText, kind, hidden) {
  const item = scope.append(new FakeElement("div", "el-form-item"));
  if (hidden) item.styleState.display = "none";
  const label = item.append(new FakeElement("label", "el-form-item__label", labelText));
  const content = item.append(new FakeElement("div", "el-form-item__content"));
  let control = null, type = null;
  if (kind === "text") { control = content.append(new FakeElement("input", "el-input__inner")); type = "text"; }
  if (kind === "choice") { control = content.append(new FakeElement("div", "el-select")); type = "select"; }
  if (kind === "date") { control = content.append(new FakeElement("div", "el-date-editor")); type = "date"; }
  label._match = { element: control, type };
  return { label, control };
}

const scope = new FakeElement("form", "active-editor");
field(scope, "学校名称", null, true);
const school = field(scope, "学校名称", "text", false);
field(scope, "学历", null, true);
const level = field(scope, "学历", "choice", false);
field(scope, "入学时间", null, true);
const start = field(scope, "入学时间", "date", false);
const matcher = { findElementAndTypeByLabel(label) { return label._match || { element: null, type: null }; } };
const api = window.AF.SpecialSiteWorkflow._test;
api.resetHigherEducationBindingContext();
assert.strictEqual(api.normalizeFullDateValue("示例资料"), "示例资料", "CDB exact-day facts must remain exact");
assert.strictEqual(api.normalizeFullDateValue("示例资料"), "", "month-only facts must not be silently promoted to an invented day");
assert(source.includes("needs_review:示例资料_excess_existing_records"), "unknown excess 示例资料 cards must still block for review instead of being overwritten or deleted");
assert(source.includes("repair_planned_rows_preserve_excess"), "obvious duplicate surplus cards may repair planned rows while preserving extras for manual cleanup");
assert(source.includes("verifyDisplayedSelection"), "Zhaopin choice verification must support selected-item readback for Element controls");

const resumedSteps = api.resumeExecutionStepsFromActiveSection([
  { name: "个人信息" },
  { name: "高等示例资料", higherEducationNavigationAdapter: true },
  { name: "实习工作" },
  { name: "项目经验及研究成果" },
], "高等示例资料");
assert.deepStrictEqual(
  resumedSteps.map((step) => step.name),
  ["高等示例资料", "实习工作", "项目经验及研究成果"],
  "resuming from Higher Education must preserve all later runnable sections instead of filtering to 示例资料 only"
);

assert.deepStrictEqual(
  api.resumeExecutionStepsFromActiveSection([
    { name: "个人信息" },
    { name: "高等示例资料" },
    { name: "实习工作" },
    { name: "全职示例资料" },
    { name: "项目经验及研究成果" },
  ], "全职示例资料").map((step) => step.name),
  ["全职示例资料", "项目经验及研究成果"],
  "public Zhaopin resume should also continue from later recognized sections"
);

const 示例资料Identity = api.zhaopinRepeatRowIdentity(
  { category: "示例资料Experience" },
  { company: "示例证券", position: "示例资料", startTime: "示例资料", endTime: "示例资料" }
);
assert.strictEqual(示例资料Identity.kind, "示例资料");
assert(示例资料Identity.primary.includes("示例证券"));
assert.strictEqual(
  api.zhaopinRepeatCardMatchState({ textContent: "示例证券 示例资料 示例资料 至 示例资料" }, 示例资料Identity).strong,
  true,
  "a saved 示例资料 card with the same company plus position/date should be treated as already present"
);
const uncertainWorkMatch = api.zhaopinRepeatCardMatchState({ textContent: "示例证券 --" }, 示例资料Identity);
assert.strictEqual(uncertainWorkMatch.primary, true);
assert.strictEqual(uncertainWorkMatch.strong, false, "company-only matches must stop for review instead of silently duplicating");

const 示例资料Identity = api.zhaopinRepeatRowIdentity(
  { category: "示例资料Experience" },
  { name: "示例调研项目", role: "队长", startTime: "示例资料", endTime: "示例资料" }
);
assert.strictEqual(示例资料Identity.kind, "示例资料");
assert.strictEqual(
  api.zhaopinRepeatCardMatchState({ textContent: "示例调研项目 队长 示例资料 示例资料" }, 示例资料Identity).strong,
  true,
  "示例资料 duplicate protection should use 示例资料 identity instead of 示例资料 index alone"
);

const 示例资料Identity = api.zhaopinRepeatRowIdentity(
  { category: "示例资料Skills" },
  { name: "英语", certificateName: "大学英语六级", proficiency: "熟练" }
);
assert.strictEqual(示例资料Identity.kind, "示例资料");
assert.strictEqual(
  api.zhaopinRepeatCardMatchState({ textContent: "英语 大学英语六级 熟练" }, 示例资料Identity).strong,
  true,
  "示例资料 示例资料 protection should use 示例资料/certificate identity instead of 示例资料 fields"
);


const duplicateCardA = new FakeElement("div", "apply-form-read-only", "实习单位 -- 实习岗位 -- 实习工作描述 相同旧内容 编辑");
const duplicateCardB = new FakeElement("div", "apply-form-read-only", "实习单位 -- 实习岗位 -- 实习工作描述 相同旧内容 编辑");
assert.strictEqual(
  api.hasObviousDuplicateZhaopinRepeatCards([duplicateCardA, duplicateCardB]),
  true,
  "identical malformed cards from an earlier run should be recognized as obvious duplicates"
);
const distinctCard = new FakeElement("div", "apply-form-read-only", "另一段不同经历");
assert.strictEqual(
  api.hasObviousDuplicateZhaopinRepeatCards([duplicateCardA, distinctCard]),
  false,
  "different existing records must not opt into duplicate-surplus repair"
);

const 示例资料EditorScope = new FakeElement("div", "apply-module__form");
const addSubmit = 示例资料EditorScope.append(new FakeElement("button", "el-button el-button--primary", "添 加"));
const saveSubmit = 示例资料EditorScope.append(new FakeElement("button", "el-button el-button--primary", "保 存"));
assert.strictEqual(
  api.findZhaopinRepeatEditorSubmitButton({ 示例资料ForCategoryData: true, directMenuNavigation: true, __afZhaopinRepeatAction: "opened_existing_editor_by_position" }, 示例资料EditorScope),
  saveSubmit,
  "editing an existing Zhaopin 示例资料 row must choose the save/update button rather than the Add action"
);
assert.strictEqual(
  api.findZhaopinRepeatEditorSubmitButton({ 示例资料ForCategoryData: true, directMenuNavigation: true, __afZhaopinRepeatAction: "opened_add_editor" }, 示例资料EditorScope),
  addSubmit,
  "a newly opened Zhaopin 示例资料 row must choose its Add/Save submit action"
);

const readOnlySection = new FakeElement("section", "apply-module");
readOnlySection.append(new FakeElement("div", "apply-form-read-only"));
const readOnlyState = api.classifyHigherEducationEditableRoot(readOnlySection);
assert.strictEqual(readOnlyState.root, null);
assert.strictEqual(readOnlyState.state, "read_only_records", "a display-only 示例资料 card must not be treated as an editor");

const editableSection = new FakeElement("section", "apply-module");
editableSection.append(new FakeElement("input", "el-input__inner"));
const editableState = api.classifyHigherEducationEditableRoot(editableSection);
assert.strictEqual(editableState.root, editableSection);
assert.strictEqual(editableState.state, "editable");
assert(editableState.editableControlCount > 0);

let sharedMatcherCalls = 0;
const sharedControl = new FakeElement("div", "el-select");
const sharedLabel = new FakeElement("label", "el-form-item__label", "学历");
const sharedMatcher = { findElementAndTypeByLabel(label) { sharedMatcherCalls += 1; assert.strictEqual(label, sharedLabel); return { element: sharedControl, type: "select" }; } };
const sharedBinding = api.resolveSequenceControlByConfiguredType(sharedMatcher, sharedLabel, { type: "select", coreMatcherFirst: true });
assert.strictEqual(sharedMatcherCalls, 1, "the shared record resolver must call Core ElementMatcher first");
assert.strictEqual(sharedBinding.element, sharedControl, "the shared resolver must preserve the Core matcher result");
assert.strictEqual(sharedBinding.type, "select", "select/date/text adapter routing must use the detected Core type");


const ieltsFormItem = new FakeElement("div", "el-form-item");
const ieltsLabel = ieltsFormItem.append(new FakeElement("label", "el-form-item__label", "其他英语等级考试成绩"));
const ieltsContent = ieltsFormItem.append(new FakeElement("div", "el-form-item__content"));
const staleNeighborSelect = ieltsContent.append(new FakeElement("div", "el-select", "示例资料"));
const ieltsScoreInput = ieltsContent.append(new FakeElement("input", "el-input__inner", ""));
const misleadingMatcher = { findElementAndTypeByLabel() { return { element: staleNeighborSelect, type: "select" }; } };
const ieltsBinding = api.resolveSequenceControlByConfiguredType(
  misleadingMatcher,
  ieltsLabel,
  { type: "text", coreMatcherFirst: false }
);
assert.strictEqual(ieltsBinding.type, "text", "explicit 示例资料 score input must remain a text control");
assert.strictEqual(ieltsBinding.element, ieltsScoreInput, "示例资料 score binding must use the plain input instead of the neighboring Element select");

const 示例资料WorkItem = new FakeElement("div", "el-form-item");
const 示例资料WorkLabel = 示例资料WorkItem.append(new FakeElement("label", "el-form-item__label", "实习单位"));
const 示例资料WorkContent = 示例资料WorkItem.append(new FakeElement("div", "el-form-item__content"));
const 示例资料WorkInput = 示例资料WorkContent.append(new FakeElement("input", "el-input__inner", ""));
const staleGlobalWorkControl = new FakeElement("div", "el-select", "stale");
const staleWorkMatcher = { findElementAndTypeByLabel() { return { element: staleGlobalWorkControl, type: "select" }; } };
const 示例资料WorkBinding = api.resolveSequenceControlByConfiguredType(
  staleWorkMatcher,
  示例资料WorkLabel,
  { type: "text", coreMatcherFirst: false, zhaopinRepeatLocalBinding: true },
  示例资料WorkItem
);
assert.strictEqual(示例资料WorkBinding.type, "text", "CDB 示例资料 示例资料 binding must keep company/position fields as local text controls");
assert.strictEqual(示例资料WorkBinding.element, 示例资料WorkInput, "CDB 示例资料 示例资料 binding must ignore stale/global same-name controls");

const 示例资料DateItem = new FakeElement("div", "el-form-item");
const 示例资料DateLabel = 示例资料DateItem.append(new FakeElement("label", "el-form-item__label", "开始日期"));
const 示例资料DateContent = 示例资料DateItem.append(new FakeElement("div", "el-form-item__content"));
const 示例资料DateControl = 示例资料DateContent.append(new FakeElement("div", "el-date-editor"));
const 示例资料DateBinding = api.resolveSequenceControlByConfiguredType(
  staleWorkMatcher,
  示例资料DateLabel,
  { type: "zhaopinCampusDate", coreMatcherFirst: false, zhaopinRepeatLocalBinding: true },
  示例资料DateItem
);
assert.strictEqual(示例资料DateBinding.type, "date", "CDB 示例资料 date must resolve as a date control inside the current field group");
assert.strictEqual(示例资料DateBinding.element, 示例资料DateControl, "CDB 示例资料 date must not be stolen by a stale global control");

assert(source.includes("zhaopinRepeatRetrySaveWhenStillEditing"), "CDB public-示例资料 save should support one scoped retry when the real editor remains open");
assert(source.includes("cancelled_failed_existing_repair_and_continue"), "failed existing-row repair must cancel unsaved changes before continuing to inspect later rows");
assert(source.includes("normalizeFullDateValue(preInput.value) === exactDate"), "an already-correct full-date value must be accepted without a false retry failure");
assert(source.includes("some(step.useVisibleRepeatEditorAsScope === true ? isActuallyVisible : isVisible)"), "示例资料 save close verification must reject stale hidden Vue forms");

const navSection = new FakeElement("section", "apply-module");
const contentHeading = navSection.append(new FakeElement("h3", "form-content--title", "高等示例资料"));
contentHeading.rect = { x: 10, y: 90, left: 10, top: 90, right: 200, bottom: 120, width: 190, height: 30 };
const activeNav = new FakeElement("span", "resume-menu-item__title", "高等示例资料");
document.querySelector = (selector) => selector.includes("resume-menu-item") ? activeNav : null;
document.querySelectorAll = (selector) => selector.includes("form-content--title") ? [contentHeading] : [];
const sectionState = api.detectActiveResumeSection();
assert.strictEqual(sectionState.detectedSection, "高等示例资料");
assert.strictEqual(sectionState.detectionStrategy, "navigation_and_content");
assert.strictEqual(sectionState.confidence, "high");

const addButton = navSection.append(new FakeElement("button", "el-button", "添加"));
assert.strictEqual(api.findHigherEducationAddButton(navSection), addButton, "the thin adapter may locate only the scoped exact Add action");
const iconAddSection = new FakeElement("section", "apply-module");
const iconAddButton = iconAddSection.append(new FakeElement("div", "icon-box icon-box-only", "添加"));
assert.strictEqual(api.findHigherEducationAddButton(iconAddSection), iconAddButton, "the CDB/Zhaopin title-box icon Add action must be detected even when it is not a button element");
assert(!String(api.runHigherEducationNavigationAdapter).includes("FormHandler"), "the navigation adapter must never write fields");

const remaining = api.selectRemainingEducationRecord(
  [
    { school: "示例大学", major: "示例专业A", level: "本科", degree: "学士" },
    { school: "示例大学", major: "示例专业B", level: "硕士研究生", degree: "硕士" }
  ],
  [{ school: "示例大学", major: "示例专业A", level: "本科", degree: "" }]
);
assert.strictEqual(remaining.recordIndex, 1, "an identified existing bachelor record should leave the master record as the add target even when degree is absent on the page");
assert.strictEqual(remaining.missingRecordCount, 1);
assert.deepStrictEqual(remaining.matchedProfileIndices, [0]);
assert.strictEqual(api.selectRemainingEducationRecord([{ level: "本科" }, { level: "硕士研究生" }], [{}]).reason, "示例资料_existing_record_match_uncertain");

const displaySection = new FakeElement("section", "apply-module");
const displayCard = displaySection.append(new FakeElement("div", "示例资料-display-card"));
function displayField(root, labelText, value) {
  const item = root.append(new FakeElement("div", "el-form-item"));
  item.append(new FakeElement("label", "el-form-item__label", labelText));
  const content = item.append(new FakeElement("div", "el-form-item__content"));
  content.append(new FakeElement("div", "apply-form-read-only", value));
  return item;
}
displayField(displayCard, "学校名称", "示例大学");
displayField(displayCard, "学历", "本科");
displayField(displayCard, "专业", "示例专业A");
displayField(displayCard, "学位", "--");
const scannedIdentity = api.scanHigherEducationExistingIdentities(displaySection);
assert.strictEqual(scannedIdentity.length, 1, "one visible 示例资料 display card should be detected");
assert.strictEqual(scannedIdentity[0].school, "示例大学");
assert.strictEqual(scannedIdentity[0].level, "本科");
assert.strictEqual(scannedIdentity[0].major, "示例专业A");
const scannedRemaining = api.selectRemainingEducationRecord(
  [
    { school: "示例大学", major: "示例专业A", level: "本科", degree: "学士" },
    { school: "示例大学", major: "示例专业B", level: "硕士", degree: "硕士" }
  ],
  scannedIdentity
);
assert.strictEqual(scannedRemaining.recordIndex, 1, "the actual CDB display-card shape should identify the bachelor and select the master as missing");

const schoolBinding = api.resolveFieldBinding(matcher, scope, "学校名称", "text", "school");
const levelBinding = api.resolveFieldBinding(matcher, scope, "学历", "choice", "level");
const dateBinding = api.resolveFieldBinding(matcher, scope, "入学时间", "date", "startTime");
assert.strictEqual(schoolBinding.control, school.control);
assert.strictEqual(schoolBinding.detectedType, "text");
assert.strictEqual(levelBinding.control, level.control);
assert.strictEqual(levelBinding.detectedType, "select");
assert.strictEqual(dateBinding.control, start.control);
assert.strictEqual(dateBinding.detectedType, "date");
assert(api.enumerateInteractiveControls(scope).length > 0, "editor and binding diagnostics must share the interactive-control enumerator");

const geometryScope = new FakeElement("form", "geometry-editor");
const geometryLabel = geometryScope.append(new FakeElement("label", "loose-label", "学校名称"));
geometryLabel.rect = { x: 10, y: 10, left: 10, top: 10, right: 90, bottom: 30, width: 80, height: 20 };
const geometryInput = geometryScope.append(new FakeElement("input", "el-input__inner"));
geometryInput.rect = { x: 10, y: 36, left: 10, top: 36, right: 210, bottom: 64, width: 200, height: 28 };
const nullMatcher = { findElementAndTypeByLabel() { return { element: null, type: null }; } };
const geometryBinding = api.resolveFieldBinding(nullMatcher, geometryScope, "学校名称", "text", "school");
assert.strictEqual(geometryBinding.control, geometryInput, "active-editor geometry fallback should bind a same-column control below its label");
assert.strictEqual(geometryBinding.source, "active_editor_geometry");

(async () => {
  const personalNav = new FakeElement("span", "resume-menu-item__title", "个人信息");
  const targetMenu = new FakeElement("div", "resume-menu-item");
  targetMenu.append(activeNav);
  let currentActive = personalNav;
  let modalVisible = false;
  const unsavedModal = new FakeElement("div", "el-message-box__wrapper", "当前模块还未保存，是否要保存当前模块信息？ 不保存 保存并跳转");
  const saveAndNavigateButton = unsavedModal.append(new FakeElement("button", "el-button--primary", "保存并跳转"));
  const discardButton = unsavedModal.append(new FakeElement("button", "el-button", "不保存"));
  const personalSection = new FakeElement("section", "apply-module");
  const personalHeading = personalSection.append(new FakeElement("h3", "form-content--title", "个人信息"));
  personalHeading.rect = { x: 10, y: 90, left: 10, top: 90, right: 200, bottom: 120, width: 190, height: 30 };
  let saveClicks = 0, discardClicks = 0;
  saveAndNavigateButton.click = () => { saveClicks += 1; modalVisible = false; unsavedModal.styleState.display = "none"; currentActive = activeNav; };
  discardButton.click = () => { discardClicks += 1; };
  document.querySelector = (selector) => selector.includes("resume-menu-item") ? currentActive : null;
  document.querySelectorAll = (selector) => {
    if (selector === ".resume-menu-item") return [targetMenu];
    if (selector.includes("el-message-box") || selector.includes("[role='dialog']")) return modalVisible ? [unsavedModal] : [];
    if (selector.includes("form-content--title")) return [personalHeading, contentHeading];
    return [];
  };
  targetMenu.click = () => { currentActive = activeNav; };
  const navigation = await api.navigateToResumeSection("高等示例资料", { timeoutMs: 50 });
  assert.strictEqual(navigation.fromSection, "个人信息");
  assert.strictEqual(navigation.targetNavFound, true);
  assert.strictEqual(navigation.navClickDispatched, true);
  assert.strictEqual(navigation.activeSectionAfterClick, "高等示例资料");
  assert.strictEqual(navigation.entered, true);
  const preNavigationTrace = api.createInitialEducationRepeatNavigationTrace({ plannedRepeatRows: [{ level: "本科" }, { level: "硕士研究生" }] });
  assert.strictEqual(preNavigationTrace.profileRecordCount, 2, "profile count must be available before section navigation succeeds");

  currentActive = personalNav;
  modalVisible = true;
  unsavedModal.styleState.display = "block";
  targetMenu.click = () => { modalVisible = true; };
  const transactionNavigation = await api.navigateToResumeSection("高等示例资料", { timeoutMs: 100 });
  assert.strictEqual(transactionNavigation.unsavedModalDetected, true);
  assert.strictEqual(transactionNavigation.entered, true);
  assert.strictEqual(transactionNavigation.moduleTransactionTrace.result, "success");
  assert.strictEqual(saveClicks, 1);
  assert.strictEqual(discardClicks, 0, "the 示例资料flow must never click 不保存");

  currentActive = personalNav;
  modalVisible = true;
  unsavedModal.styleState.display = "block";
  saveAndNavigateButton.click = () => { saveClicks += 1; modalVisible = false; unsavedModal.styleState.display = "none"; };
  targetMenu.click = () => { modalVisible = true; };
  const failedVerification = await api.navigateToResumeSection("高等示例资料", { timeoutMs: 30 });
  assert.strictEqual(failedVerification.entered, false);
  assert.strictEqual(failedVerification.reason, "save_navigation_failed");
  assert.strictEqual(failedVerification.moduleTransactionTrace.modalClosed, true);
  assert.strictEqual(failedVerification.moduleTransactionTrace.targetSectionEntered, false);

  currentActive = personalNav;
  modalVisible = true;
  unsavedModal.styleState.display = "block";
  const errorItem = personalSection.append(new FakeElement("div", "el-form-item is-error"));
  errorItem.append(new FakeElement("label", "el-form-item__label", "姓名全拼"));
  targetMenu.click = () => { modalVisible = true; };
  const modalBlocked = await api.navigateToResumeSection("高等示例资料", { timeoutMs: 50 });
  assert.strictEqual(modalBlocked.unsavedModalDetected, true);
  assert.strictEqual(modalBlocked.entered, false);
  assert.strictEqual(modalBlocked.reason, "current_module_validation_failed");
  assert.deepStrictEqual(modalBlocked.moduleTransactionTrace.blockingLabels, ["姓名全拼"]);
  assert.strictEqual(saveClicks, 2, "validation blocking must not click 保存并跳转");
  assert.strictEqual(discardClicks, 0);
  modalVisible = false;

  let guardedClicks = 0;
  addButton.click = () => { guardedClicks += 1; };
  document.querySelector = (selector) => selector.includes("resume-menu-item") ? new FakeElement("span", "resume-menu-item__title", "全职示例资料") : null;
  const guarded = await api.runHigherEducationNavigationAdapter({ autoOpenEducationEditor: true, timeoutMs: 20, plannedRepeatRows: [{ level: "硕士研究生", degree: "硕士" }] });
  assert.strictEqual(guarded.reason, "示例资料_section_not_active");
  assert.strictEqual(guardedClicks, 0, "Education Add must never run before Higher Education is active");
  const completeSection = new FakeElement("section", "apply-module");
  const completeHeading = completeSection.append(new FakeElement("h3", "form-content--title", "高等示例资料"));
  completeHeading.rect = { x: 10, y: 90, left: 10, top: 90, right: 200, bottom: 120, width: 190, height: 30 };
  completeSection.append(new FakeElement("button", "el-button", "添加"));
  const bachelorCard = completeSection.append(new FakeElement("div", "示例资料-display-card"));
  displayField(bachelorCard, "学校名称", "示例大学");
  displayField(bachelorCard, "学历", "本科");
  displayField(bachelorCard, "专业", "示例专业A");
  const masterCard = completeSection.append(new FakeElement("div", "示例资料-display-card"));
  displayField(masterCard, "学校名称", "示例大学");
  displayField(masterCard, "学历", "硕士研究生");
  displayField(masterCard, "专业", "示例专业B");
  document.querySelector = (selector) => selector.includes("resume-menu-item") ? activeNav : null;
  document.querySelectorAll = (selector) => selector.includes("form-content--title") ? [completeHeading] : [];
  const complete = await api.runHigherEducationNavigationAdapter({
    autoOpenEducationEditor: true,
    timeoutMs: 20,
    plannedRepeatRows: [
      { school: "示例大学", major: "示例专业A", level: "本科", degree: "学士" },
      { school: "示例大学", major: "示例专业B", level: "硕士研究生", degree: "硕士" },
    ],
  });
  assert.strictEqual(complete.missingRecordCount, 0);
  assert.strictEqual(complete.reason, "示例资料_no_missing_record");
  assert.strictEqual(complete.safeToLeave, true, "a conservatively matched complete 示例资料 section must be allowed to continue");
  assert.strictEqual(complete.stoppedBecause, "示例资料_complete_no_missing_record");
  assert.strictEqual(complete.addButtonClicked, false, "a complete 示例资料 section must not create a duplicate record");

  document.querySelector = (selector) => selector.includes("resume-menu-item") ? activeNav : null;
  document.querySelectorAll = (selector) => selector.includes("form-content--title") ? [contentHeading] : [];
  addButton.click = () => navSection.append(new FakeElement("input", "el-input__inner"));
  const opened = await api.runHigherEducationNavigationAdapter({ autoOpenEducationEditor: true, timeoutMs: 20, plannedRepeatRows: [{ level: "硕士研究生", degree: "硕士" }] });
  assert.strictEqual(opened.addButtonClicked, true);
  assert.strictEqual(opened.editableRootFound, true, "the adapter must reacquire the editor after Add changes the DOM");
  assert(opened.editableControlCount > 0);
  console.log("cdb core matcher binding fixture: PASS");
})().catch((error) => { console.error(error); process.exitCode = 1; });

// Build38 regression: the CDB 示例资料 editor lays out two fields in one visual row.
// A broad row ancestor therefore contains both controls; binding must use label/control
// geometry instead of always taking the first control in DOM order.
const twoColumnTextRow = new FakeElement("div", "two-column-row");
const companyLabelCell = twoColumnTextRow.append(new FakeElement("div", "label-cell"));
const companyLabel = companyLabelCell.append(new FakeElement("label", "field-label", "实习单位"));
const companyInput = twoColumnTextRow.append(new FakeElement("input", "el-input__inner"));
const positionLabelCell = twoColumnTextRow.append(new FakeElement("div", "label-cell"));
const positionLabel = positionLabelCell.append(new FakeElement("label", "field-label", "实习岗位"));
const positionInput = twoColumnTextRow.append(new FakeElement("input", "el-input__inner"));
companyLabel.rect = { left: 100, right: 180, top: 100, bottom: 120, width: 80, height: 20 };
companyInput.rect = { left: 100, right: 320, top: 128, bottom: 160, width: 220, height: 32 };
positionLabel.rect = { left: 500, right: 580, top: 100, bottom: 120, width: 80, height: 20 };
positionInput.rect = { left: 500, right: 720, top: 128, bottom: 160, width: 220, height: 32 };
assert.strictEqual(
  api.resolveSequenceControlByConfiguredType(staleWorkMatcher, companyLabel, { type: "text", coreMatcherFirst: false, zhaopinRepeatLocalBinding: true }, twoColumnTextRow).element,
  companyInput,
  "CDB 示例资料 company must bind to the text control geometrically under 实习单位, not an示例资料 control in the same row"
);
assert.strictEqual(
  api.resolveSequenceControlByConfiguredType(staleWorkMatcher, positionLabel, { type: "text", coreMatcherFirst: false, zhaopinRepeatLocalBinding: true }, twoColumnTextRow).element,
  positionInput,
  "CDB 示例资料 position must bind to the text control geometrically under 实习岗位"
);
const divOnlyPositionLabel = new FakeElement("div", "field-label-text", "实习岗位");
const divLabelScope = new FakeElement("form", "active-editor");
divLabelScope.append(divOnlyPositionLabel);
assert.strictEqual(
  api.findZhaopinRepeatLocalLabel(divLabelScope, ["职位名称", "实习岗位"]),
  divOnlyPositionLabel,
  "CDB 示例资料 repair must recover a visible div/span field title even when Core does not expose it as a label"
);

const twoColumnDateRow = new FakeElement("div", "two-column-date-row");
const startLabelCell = twoColumnDateRow.append(new FakeElement("div", "label-cell"));
const startDateLabel = startLabelCell.append(new FakeElement("label", "field-label", "开始日期"));
const startDateInput = twoColumnDateRow.append(new FakeElement("input", "date-input"));
const endLabelCell = twoColumnDateRow.append(new FakeElement("div", "label-cell"));
const endDateLabel = endLabelCell.append(new FakeElement("label", "field-label", "结束日期"));
const endDateInput = twoColumnDateRow.append(new FakeElement("input", "date-input"));
startDateLabel.rect = { left: 100, right: 180, top: 200, bottom: 220, width: 80, height: 20 };
startDateInput.rect = { left: 100, right: 320, top: 228, bottom: 260, width: 220, height: 32 };
endDateLabel.rect = { left: 500, right: 580, top: 200, bottom: 220, width: 80, height: 20 };
endDateInput.rect = { left: 500, right: 720, top: 228, bottom: 260, width: 220, height: 32 };
assert.strictEqual(
  api.resolveSequenceControlByConfiguredType(staleWorkMatcher, startDateLabel, { type: "zhaopinCampusDate", coreMatcherFirst: false, zhaopinRepeatLocalBinding: true }, twoColumnDateRow).element,
  startDateInput,
  "CDB 示例资料 start date must not be overwritten through the end-date control in the same row"
);
assert.strictEqual(
  api.resolveSequenceControlByConfiguredType(staleWorkMatcher, endDateLabel, { type: "zhaopinCampusDate", coreMatcherFirst: false, zhaopinRepeatLocalBinding: true }, twoColumnDateRow).element,
  endDateInput,
  "CDB 示例资料 end date must bind to its own geometrically adjacent control"
);

const descriptionBlock = new FakeElement("div", "description-row");
const descriptionLabelCell = descriptionBlock.append(new FakeElement("div", "label-cell"));
const descriptionLabel = descriptionLabelCell.append(new FakeElement("label", "field-label", "实习工作描述"));
const nearbyCompanyInput = descriptionBlock.append(new FakeElement("input", "el-input__inner"));
const descriptionTextarea = descriptionBlock.append(new FakeElement("textarea", "el-textarea__inner"));
descriptionLabel.rect = { left: 100, right: 220, top: 300, bottom: 320, width: 120, height: 20 };
nearbyCompanyInput.rect = { left: 100, right: 320, top: 220, bottom: 252, width: 220, height: 32 };
descriptionTextarea.rect = { left: 100, right: 720, top: 330, bottom: 430, width: 620, height: 100 };
assert.strictEqual(
  api.resolveSequenceControlByConfiguredType(staleWorkMatcher, descriptionLabel, { type: "text", coreMatcherFirst: false, zhaopinRepeatLocalBinding: true }, descriptionBlock).element,
  descriptionTextarea,
  "CDB 示例资料 description must bind to the textarea under its own label instead of overwriting the 示例资料-unit input"
);
