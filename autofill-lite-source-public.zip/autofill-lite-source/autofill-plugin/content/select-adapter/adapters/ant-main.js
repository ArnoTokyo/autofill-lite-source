// content/select-adapter/adapters/ant-main.js
// Runs in the page's main world. Ant Design/rc-select components often keep
// search and selected state inside React; content-script value mutations can
// update the DOM input without committing the actual selected value.
(function () {
  "use strict";
  var BRIDGE_VERSION = "0.1.240";
  if (window.__AFAntMainBridgeVersion === BRIDGE_VERSION) return;
  window.__AFAntMainBridge = true;
  window.__AFAntMainBridgeVersion = BRIDGE_VERSION;
  try { document.documentElement.setAttribute("data-af-ant-main-bridge", BRIDGE_VERSION); } catch (eBridgeMarker) {}

  function sleep(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, ms);
    });
  }

  function cssEscape(value) {
    if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(String(value));
    return String(value).replace(/['"\\]/g, "\\$&");
  }

  function setNativeValue(input, value) {
    var text = String(value == null ? "" : value);
    input.removeAttribute && input.removeAttribute("readonly");
    input.readOnly = false;
    var previous = input.value;
    var descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
    if (descriptor && descriptor.set) descriptor.set.call(input, text);
    else input.value = text;
    if (input._valueTracker && typeof input._valueTracker.setValue === "function") {
      input._valueTracker.setValue(previous);
    }
    input.setAttribute && input.setAttribute("value", text);
  }

  function key(input, type, value, extra) {
    var opts = {
      bubbles: true,
      cancelable: true,
      composed: true,
      key: value || "",
      code: value && value.length === 1 ? "Key" + value.toUpperCase() : value || "",
      keyCode: value && value.length === 1 ? value.charCodeAt(0) : 0,
      which: value && value.length === 1 ? value.charCodeAt(0) : 0,
    };
    if (extra) {
      Object.keys(extra).forEach(function (name) {
        opts[name] = extra[name];
      });
    }
    input.dispatchEvent(new window.KeyboardEvent(type, opts));
  }

  function inputEvent(input, inputType, data) {
    try {
      input.dispatchEvent(new window.InputEvent("beforeinput", {
        bubbles: true,
        cancelable: true,
        composed: true,
        inputType: inputType,
        data: data || null,
      }));
    } catch (e) {}
    input.dispatchEvent(new window.InputEvent("input", {
      bubbles: true,
      cancelable: true,
      composed: true,
      inputType: inputType,
      data: data || null,
    }));
  }

  async function openOwningSelect(input) {
    try {
      var antSelect = input && input.closest && input.closest(".ant-select");
      if (!antSelect) return input;
      var triggers = Array.prototype.slice.call(antSelect.querySelectorAll(
        ".ant-select-selection, .ant-select-selector, .ant-select-selection__rendered, .ant-select-arrow, [role='combobox']"
      ));
      triggers.push(antSelect);
      for (var i = 0; i < triggers.length; i++) {
        var trigger = triggers[i];
        if (!trigger || !trigger.getBoundingClientRect) continue;
        await clickLikeUser(trigger);
        await sleep(260);
        var visibleInput = Array.prototype.slice.call(antSelect.querySelectorAll(".ant-select-search__field, input")).filter(function (node) {
          return node && !node.disabled && !node.readOnly && isVisible(node);
        })[0];
        if (visibleInput || antSelect.classList.contains("ant-select-open")) return visibleInput || input;
      }
      return input;
    } catch (e) {
      return input;
    }
  }

  function findLatestVisibleInputById(id, fallback) {
    if (!id) return fallback || null;
    var candidates = [];
    try {
      candidates = Array.prototype.slice.call(document.querySelectorAll("input[id='" + cssEscape(id) + "']")).filter(isVisible);
    } catch (e) {}
    return candidates[candidates.length - 1] || fallback || null;
  }

  async function typeSearch(input, value, skipOpen) {
    var text = String(value == null ? "" : value);
    var token = input && input.getAttribute && input.getAttribute("data-af-ant-token");
    // 特殊站点可能已经打开外层 Cascader，并把真正的远程搜索框直接渲染在
    // 弹层内部。此时再次打开 owning select 会把现有弹层切换关闭；允许调用方
    // 明确跳过二次打开，直接在当前可见 input 上触发 React onSearch。
    if (!skipOpen) input = await openOwningSelect(input);
    if (token && input && input.setAttribute) input.setAttribute("data-af-ant-token", token);
    input.removeAttribute && input.removeAttribute("readonly");
    input.readOnly = false;
    input.focus && input.focus();
    input.dispatchEvent(new window.FocusEvent("focus", { bubbles: true, composed: true }));
    input.dispatchEvent(new window.MouseEvent("mousedown", { bubbles: true, cancelable: true, composed: true, view: window }));
    input.dispatchEvent(new window.MouseEvent("mouseup", { bubbles: true, cancelable: true, composed: true, view: window }));
    input.dispatchEvent(new window.MouseEvent("click", { bubbles: true, cancelable: true, composed: true, view: window }));

    if (skipOpen) {
      // 交行 Cascader 内嵌的远程搜索框是 React 受控节点。逐字触发 onChange
      // 时它会在第一个字符后重渲染 input，原引用随即失效，后续字符实际写在
      // 已脱离 DOM 的旧节点上。这里仿照一次真实的完整输入，只提交一次完整值。
      try { document.documentElement.setAttribute("data-af-ant-direct-status", "focused"); } catch (eDirectStatus0) {}
      // execCommand 会走浏览器自身的编辑管线，产生更接近真实键盘输入的
      // beforeinput/input 过程。交行 rc-select 对这条路径的接受度高于纯合成事件。
      try {
        input.focus && input.focus();
        input.select && input.select();
        if (document.execCommand && document.execCommand("insertText", false, text)) {
          await sleep(220);
          var editedInput = findLatestVisibleInputById(input.id, input);
          if (editedInput && String(editedInput.value || "") === text) {
            try { document.documentElement.setAttribute("data-af-ant-direct-status", "exec-command-ok:" + text); } catch (eDirectStatus1) {}
            return editedInput.value;
          }
        }
      } catch (eExecCommand) {}
      try { document.documentElement.setAttribute("data-af-ant-direct-status", "native-fallback"); } catch (eDirectStatus2) {}
      setNativeValue(input, "");
      inputEvent(input, "deleteContentBackward", null);
      invokeReactInputHandlers(input, ["onInput", "onChange"], "");
      await sleep(60);
      if (!input.isConnected && input.id) {
        input = findLatestVisibleInputById(input.id, input);
        if (token && input.setAttribute) input.setAttribute("data-af-ant-token", token);
      }
      input.focus && input.focus();
      setNativeValue(input, text);
      inputEvent(input, "insertText", text);
      input.dispatchEvent(new window.Event("search", { bubbles: true, cancelable: true, composed: true }));
      input.dispatchEvent(new window.Event("change", { bubbles: true, cancelable: true, composed: true }));
      invokeReactInputHandlers(input, ["onInput", "onChange"], "");
      await sleep(220);
      var currentInput = findLatestVisibleInputById(input.id, input);
      var finalValue = currentInput && currentInput.value || input.value;
      try { document.documentElement.setAttribute("data-af-ant-direct-status", "native-result:" + finalValue); } catch (eDirectStatus3) {}
      return finalValue;
    }

    setNativeValue(input, "");
    key(input, "keydown", "Backspace", { code: "Backspace", keyCode: 8, which: 8 });
    inputEvent(input, "deleteContentBackward", null);
    invokeReactInputHandlers(input, ["onKeyDown", "onInput", "onChange"], "Backspace");
    key(input, "keyup", "Backspace", { code: "Backspace", keyCode: 8, which: 8 });
    await sleep(80);

    input.dispatchEvent(new window.CompositionEvent("compositionstart", { bubbles: true, composed: true, data: "" }));
    invokeReactInputHandlers(input, ["onCompositionStart"], "");
    var composed = "";
    for (var i = 0; i < text.length; i++) {
      var ch = text.charAt(i);
      composed += ch;
      key(input, "keydown", ch);
      key(input, "keypress", ch);
      input.dispatchEvent(new window.CompositionEvent("compositionupdate", { bubbles: true, composed: true, data: composed }));
      setNativeValue(input, composed);
      inputEvent(input, "insertCompositionText", ch);
      inputEvent(input, "insertText", ch);
      invokeReactInputHandlers(input, ["onKeyDown", "onKeyPress", "onCompositionUpdate", "onInput", "onChange"], ch);
      key(input, "keyup", ch);
      invokeReactInputHandlers(input, ["onKeyUp"], ch);
      await sleep(70);
    }
    input.dispatchEvent(new window.CompositionEvent("compositionend", { bubbles: true, composed: true, data: text }));
    invokeReactInputHandlers(input, ["onCompositionEnd"], "");
    setNativeValue(input, text);
    inputEvent(input, "insertText", text);
    input.dispatchEvent(new window.Event("search", { bubbles: true, cancelable: true, composed: true }));
    input.dispatchEvent(new window.Event("change", { bubbles: true, cancelable: true, composed: true }));
    invokeReactInputHandlers(input, ["onInput", "onChange", "onSearch"], "");
    await sleep(120);
    return input.value;
  }

  async function commitActiveOption(inputToken, value) {
    var input = document.querySelector("[data-af-ant-token='" + cssEscape(inputToken) + "']");
    if (!input) throw new Error("input_not_found");
    var text = String(value || input.value || "").trim();
    if (text) {
      setNativeValue(input, text);
      inputEvent(input, "insertText", text);
      invokeReactInputHandlers(input, ["onInput", "onChange", "onSearch"], "");
    }
    input.focus && input.focus();
    await sleep(120);
    key(input, "keydown", "ArrowDown", { code: "ArrowDown", keyCode: 40, which: 40 });
    invokeReactInputHandlers(input, ["onKeyDown"], "ArrowDown");
    key(input, "keyup", "ArrowDown", { code: "ArrowDown", keyCode: 40, which: 40 });
    invokeReactInputHandlers(input, ["onKeyUp"], "ArrowDown");
    await sleep(160);
    key(input, "keydown", "Enter", { code: "Enter", keyCode: 13, which: 13 });
    invokeReactInputHandlers(input, ["onKeyDown"], "Enter");
    key(input, "keypress", "Enter", { code: "Enter", keyCode: 13, which: 13 });
    key(input, "keyup", "Enter", { code: "Enter", keyCode: 13, which: 13 });
    invokeReactInputHandlers(input, ["onKeyUp"], "Enter");
    input.dispatchEvent(new window.Event("change", { bubbles: true, cancelable: true, composed: true }));
    await sleep(300);
    return input.value;
  }

  function textOf(node) {
    return String(
      node && (node.textContent || node.getAttribute && (node.getAttribute("title") || node.getAttribute("aria-label") || node.getAttribute("data-value") || node.getAttribute("value"))) || ""
    ).replace(/\s+/g, " ").trim();
  }

  function normalized(value) {
    return String(value == null ? "" : value).replace(/\s+/g, "").toLowerCase();
  }

  function isVisible(node) {
    if (!node || !node.getBoundingClientRect) return false;
    var style = window.getComputedStyle ? window.getComputedStyle(node) : null;
    if (style && (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0)) return false;
    var rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isNearInput(node, input) {
    if (!node || !input || !node.getBoundingClientRect || !input.getBoundingClientRect) return true;
    var nr = node.getBoundingClientRect();
    var ir = input.getBoundingClientRect();
    var horizontalOverlap = Math.min(nr.right, ir.right + 120) - Math.max(nr.left, ir.left - 120);
    var belowOrSamePanel = nr.bottom >= ir.top - 20 && nr.top <= ir.bottom + 520;
    return horizontalOverlap > 0 && belowOrSamePanel;
  }

  function reactPropsOf(node) {
    if (!node) return null;
    var keys = Object.keys(node);
    for (var i = 0; i < keys.length; i++) {
      if (keys[i].indexOf("__reactProps$") === 0 || keys[i].indexOf("__reactEventHandlers$") === 0) {
        return node[keys[i]];
      }
      if (keys[i].indexOf("__reactFiber$") === 0 || keys[i].indexOf("__reactInternalInstance$") === 0) {
        var fiber = node[keys[i]];
        for (var depth = 0; fiber && depth < 8; depth++) {
          if (fiber.memoizedProps) return fiber.memoizedProps;
          if (fiber.pendingProps) return fiber.pendingProps;
          if (fiber._currentElement && fiber._currentElement.props) return fiber._currentElement.props;
          fiber = fiber.return || fiber._hostParent || fiber._renderedComponent || null;
        }
      }
    }
    if (node._reactInternalFiber && node._reactInternalFiber.memoizedProps) return node._reactInternalFiber.memoizedProps;
    if (node._reactInternalInstance && node._reactInternalInstance._currentElement) {
      return node._reactInternalInstance._currentElement.props || null;
    }
    return null;
  }

  function makeSyntheticLikeEvent(type, target, x, y) {
    return {
      type: type,
      target: target,
      currentTarget: target,
      nativeEvent: {
        type: type,
        target: target,
        currentTarget: target,
        clientX: x,
        clientY: y,
        button: 0,
        buttons: /down|move/.test(type) ? 1 : 0,
      },
      clientX: x,
      clientY: y,
      button: 0,
      buttons: /down|move/.test(type) ? 1 : 0,
      bubbles: true,
      cancelable: true,
      defaultPrevented: false,
      isPropagationStopped: function () { return false; },
      isDefaultPrevented: function () { return false; },
      persist: function () {},
      preventDefault: function () {
        this.defaultPrevented = true;
        if (this.nativeEvent) this.nativeEvent.defaultPrevented = true;
      },
      stopPropagation: function () {},
    };
  }

  function makeSyntheticInputLikeEvent(type, input, keyValue) {
    var keyCodeMap = { Enter: 13, ArrowDown: 40, Down: 40, Backspace: 8 };
    var keyCode = keyCodeMap[keyValue] || (keyValue && keyValue.length === 1 ? keyValue.charCodeAt(0) : 0);
    return {
      type: type,
      target: input,
      currentTarget: input,
      nativeEvent: {
        type: type,
        target: input,
        currentTarget: input,
        key: keyValue || "",
        code: keyValue || "",
        keyCode: keyCode,
        which: keyCode,
        data: input.value,
      },
      key: keyValue || "",
      code: keyValue || "",
      keyCode: keyCode,
      which: keyCode,
      data: input.value,
      bubbles: true,
      cancelable: true,
      defaultPrevented: false,
      isPropagationStopped: function () { return false; },
      isDefaultPrevented: function () { return false; },
      persist: function () {},
      preventDefault: function () {
        this.defaultPrevented = true;
        if (this.nativeEvent) this.nativeEvent.defaultPrevented = true;
      },
      stopPropagation: function () {},
    };
  }

  function invokeReactInputHandlers(input, names, keyValue) {
    var props = reactPropsOf(input);
    if (!props) return false;
    var called = false;
    names.forEach(function (name) {
      if (typeof props[name] !== "function") return;
      try {
        props[name](makeSyntheticInputLikeEvent(name.slice(2).toLowerCase(), input, keyValue));
        called = true;
      } catch (e) {}
    });
    return called;
  }

  function invokeReactOptionHandlers(node, x, y) {
    var option = (node && node.closest && node.closest(".ant-select-dropdown-menu-item, .ant-select-item-option, [role='option'], [data-value], li")) || node;
    var chain = [];
    var cur = node;
    var stopAtOption = option && option !== node;
    while (cur && chain.length < 6) {
      chain.push(cur);
      if (stopAtOption && cur === option) break;
      cur = cur.parentElement;
    }
    if (option && chain.indexOf(option) === -1) chain.push(option);
    var handlerNames = ["onMouseEnter", "onMouseMove", "onPointerDown", "onMouseDown", "onPointerUp", "onMouseUp", "onClick"];
    var called = false;
    chain.forEach(function (el) {
      var props = reactPropsOf(el);
      if (!props) return;
      handlerNames.forEach(function (name) {
        if (typeof props[name] !== "function") return;
        try {
          props[name](makeSyntheticLikeEvent(name.slice(2).toLowerCase(), el, x, y));
          called = true;
        } catch (e) {}
      });
    });
    return called;
  }

  async function clickLikeUser(node) {
    if (!node) return false;
    node = (node.closest && node.closest(".ant-select-dropdown-menu-item, .ant-select-item-option, [role='option'], [data-value], li")) || node;
    try {
      node.scrollIntoView({ block: "nearest", behavior: "auto" });
    } catch (e) {}
    await sleep(60);
    var rect = node.getBoundingClientRect && node.getBoundingClientRect();
    var x = rect ? rect.left + Math.max(2, Math.min(rect.width / 2, rect.width - 2)) : 0;
    var y = rect ? rect.top + Math.max(2, Math.min(rect.height / 2, rect.height - 2)) : 0;
    var target = (x && y && document.elementFromPoint) ? document.elementFromPoint(x, y) : node;
    target = target || node;
    invokeReactOptionHandlers(target, x, y);
    invokeReactOptionHandlers(node, x, y);
    await sleep(50);
    var chain = [target, node];
    var parent = node.parentElement;
    var hops = 0;
    while (parent && hops < 2) {
      chain.push(parent);
      parent = parent.parentElement;
      hops++;
    }
    chain = chain.filter(function (item, index, arr) {
      return item && arr.indexOf(item) === index;
    });
    for (var i = 0; i < chain.length; i++) {
      var el = chain[i];
      ["pointerover", "mouseover", "mousemove", "pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach(function (type) {
        var ev;
        if (type.indexOf("pointer") === 0 && window.PointerEvent) {
          ev = new window.PointerEvent(type, {
            view: window,
            bubbles: true,
            cancelable: true,
            composed: true,
            pointerType: "mouse",
            isPrimary: true,
            clientX: x,
            clientY: y,
            button: 0,
            buttons: /down|move/.test(type) ? 1 : 0,
          });
        } else {
          ev = new window.MouseEvent(type, {
            view: window,
            bubbles: true,
            cancelable: true,
            composed: true,
            clientX: x,
            clientY: y,
            button: 0,
            which: 1,
            buttons: /down|move/.test(type) ? 1 : 0,
          });
        }
        el.dispatchEvent(ev);
      });
      invokeReactOptionHandlers(el, x, y);
      try {
        if (typeof el.click === "function") el.click();
      } catch (e) {}
      await sleep(70);
    }
    return true;
  }

  async function clickCascaderOnce(node) {
    if (!node) return false;
    var option = node.closest && node.closest(".ant-cascader-menu-item, .ant-cascader-menu li, .ant-cascader-menus li");
    node = option || node;
    try { node.scrollIntoView({ block: "nearest", behavior: "auto" }); } catch (e) {}
    await sleep(80);
    var rect = node.getBoundingClientRect && node.getBoundingClientRect();
    var x = rect ? rect.left + Math.max(2, Math.min(rect.width / 2, rect.width - 2)) : 0;
    var y = rect ? rect.top + Math.max(2, Math.min(rect.height / 2, rect.height - 2)) : 0;
    // 级联框一次只允许一组事件。clickLikeUser 会沿祖先链重复派发，
    // 对 rc-cascader 等价于连续开关多次，菜单会闪开后立刻关闭。
    var props = reactPropsOf(node);
    var usedReactHandler = false;
    var isChinaHr = /^applyjob\.chinahr\.com$/i.test(String(window.location && window.location.hostname || ""));
    var chinaHrChoiceRow = node.closest && node.closest(".aply-field-li");
    var chinaHrChoiceLabel = chinaHrChoiceRow && chinaHrChoiceRow.querySelector && chinaHrChoiceRow.querySelector(".aply-field-label");
    var isChinaHrDegreeOrWorkType = isChinaHr && /^(?:学位|工作类别)\s*[：:]?$/.test(
      String(chinaHrChoiceLabel && chinaHrChoiceLabel.textContent || "").replace(/\s+/g, "")
    );
    if ((!isChinaHr || isChinaHrDegreeOrWorkType) && props && typeof props.onClick === "function") {
      try {
        props.onClick(makeSyntheticLikeEvent("click", node, x, y));
        usedReactHandler = true;
      } catch (eReactClick) {}
    }
    // React 处理器和 DOM click 二选一。两套事件都发，会让需要懒加载
    // 下一级的户口/现居省份被重复选择，刚加载出的城市状态又被冲掉。
    if (!usedReactHandler) {
      ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach(function (type) {
        var init = {
          view: window, bubbles: true, cancelable: true, composed: true,
          clientX: x, clientY: y, button: 0, buttons: /down$/.test(type) ? 1 : 0,
        };
        var event = type.indexOf("pointer") === 0 && window.PointerEvent
          ? new window.PointerEvent(type, Object.assign({ pointerType: "mouse", isPrimary: true }, init))
          : new window.MouseEvent(type, init);
        node.dispatchEvent(event);
      });
    }
    await sleep(220);
    return true;
  }

  function cascaderCommitted(wrapper, expected) {
    if (!wrapper) return false;
    var target = normalized(expected);
    var label = wrapper.querySelector && wrapper.querySelector(".ant-cascader-picker-label");
    var input = wrapper.querySelector && wrapper.querySelector("input.ant-cascader-input, input[placeholder='请选择']");
    var labelText = normalized(textOf(label));
    var inputText = normalized(input && input.value);
    return !!target && (labelText === target || inputText === target ||
      labelText.indexOf(target) !== -1 || inputText.indexOf(target) !== -1);
  }

  function chinaHrChoiceCommitted(wrapper, expected) {
    if (!wrapper) return false;
    var target = normalized(expected);
    var label = wrapper.querySelector && wrapper.querySelector(".ant-cascader-picker-label");
    var labelText = normalized(textOf(label));
    return !!target && (labelText === target || labelText.indexOf(target) !== -1);
  }

  async function nativeCascaderClick(node) {
    if (!node) return false;
    try { node.scrollIntoView({ block: "nearest", behavior: "auto" }); } catch (e) {}
    var rect = node.getBoundingClientRect && node.getBoundingClientRect();
    var init = {
      view: window,
      bubbles: true,
      cancelable: true,
      composed: true,
      clientX: rect ? rect.left + rect.width / 2 : 0,
      clientY: rect ? rect.top + rect.height / 2 : 0,
      button: 0,
      buttons: 1,
    };
    ["mousedown", "mouseup", "click"].forEach(function (type) {
      node.dispatchEvent(new window.MouseEvent(type, init));
    });
    try { if (typeof node.click === "function") node.click(); } catch (eNativeClick) {}
    await sleep(320);
    return true;
  }

  function isChinaHrDegreeCascader(wrapper) {
    if (!wrapper || !wrapper.closest) return false;
    var row = wrapper.closest(".aply-field-li");
    var label = row && row.querySelector && row.querySelector(".aply-field-label");
    return /^applyjob\.chinahr\.com$/i.test(String(window.location && window.location.hostname || "")) &&
      normalized(textOf(label)).replace(/[：:*]/g, "") === "学位";
  }

  function isChinaHrDegreeOrWorkTypeCascader(wrapper) {
    if (!wrapper || !wrapper.closest) return false;
    var row = wrapper.closest(".aply-field-li");
    var label = row && row.querySelector && row.querySelector(".aply-field-label");
    return /^applyjob\.chinahr\.com$/i.test(String(window.location && window.location.hostname || "")) &&
      /^(?:学位|工作类别)$/.test(normalized(textOf(label)).replace(/[：:*]/g, ""));
  }

  async function reactCascaderClick(node) {
    if (!node) return false;
    try {
      var rect = node.getBoundingClientRect && node.getBoundingClientRect();
      var x = rect ? rect.left + Math.max(2, Math.min(rect.width / 2, rect.width - 2)) : 0;
      var y = rect ? rect.top + Math.max(2, Math.min(rect.height / 2, rect.height - 2)) : 0;
      // ChinaHR 的旧 rc-cascader 把 onMouseDown/onMouseUp 与 onClick
      // 连续调用视为两次开关，菜单会“一闪而过”。这里只调用真正提交
      // 选项的 onClick，其他站点仍走原有完整事件链。
      var option = (node.closest && node.closest(".ant-cascader-menu-item, .ant-cascader-menu li, .ant-cascader-menus li")) || node;
      var chain = [];
      var cur = option;
      while (cur && chain.length < 6) {
        chain.push(cur);
        cur = cur.parentElement;
      }
      for (var i = 0; i < chain.length; i++) {
        var props = reactPropsOf(chain[i]);
        if (!props || typeof props.onClick !== "function") continue;
        props.onClick(makeSyntheticLikeEvent("click", chain[i], x, y));
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  async function keyboardCommitCascader(wrapper, expected) {
    var input = wrapper && wrapper.querySelector && wrapper.querySelector("input.ant-cascader-input, input[placeholder='请选择']");
    if (!input) return false;
    try {
      input.focus && input.focus();
      ["keydown", "keypress", "keyup"].forEach(function (type) {
        input.dispatchEvent(new window.KeyboardEvent(type, {
          view: window, bubbles: true, cancelable: true, composed: true,
          key: "ArrowDown", code: "ArrowDown", keyCode: 40, which: 40,
        }));
      });
      await sleep(120);
      ["keydown", "keypress", "keyup"].forEach(function (type) {
        input.dispatchEvent(new window.KeyboardEvent(type, {
          view: window, bubbles: true, cancelable: true, composed: true,
          key: "Enter", code: "Enter", keyCode: 13, which: 13,
        }));
      });
      await sleep(420);
      return cascaderCommitted(wrapper, expected);
    } catch (e) {
      return false;
    }
  }

  async function openCascaderOnce(opener, wrapper) {
    var candidates = [];
    [opener, wrapper].forEach(function (node) {
      if (!node) return;
      [
        node,
        node.querySelector && node.querySelector("[role='combobox']"),
        node.querySelector && node.querySelector(".ant-select-selection-search"),
        node.querySelector && node.querySelector(".ant-select-selector"),
      ].filter(Boolean).forEach(function (candidate) {
        if (candidates.indexOf(candidate) === -1) candidates.push(candidate);
      });
    });
    for (var i = 0; i < candidates.length; i++) {
      var candidate = candidates[i];
      var props = reactPropsOf(candidate);
      if (!props) continue;
      var handlerName = typeof props.onMouseDown === "function" ? "onMouseDown" :
        (typeof props.onClick === "function" ? "onClick" : "");
      if (!handlerName) continue;
      var rect = candidate.getBoundingClientRect && candidate.getBoundingClientRect();
      var x = rect ? rect.left + Math.max(2, Math.min(rect.width / 2, rect.width - 2)) : 0;
      var y = rect ? rect.top + Math.max(2, Math.min(rect.height / 2, rect.height - 2)) : 0;
      try {
        props[handlerName](makeSyntheticLikeEvent(handlerName === "onMouseDown" ? "mousedown" : "click", candidate, x, y));
        await sleep(220);
        return true;
      } catch (eReactOpen) {}
    }
    // 当前交行生产页不一定把 React 私有 props 挂在 DOM 节点上。此时打开
    // 级联框只派发一次 mousedown：rc-select 的打开动作绑定在这里；若继续
    // 补发 click，会把刚打开的弹层再次关闭。
    var fallback = (wrapper && wrapper.querySelector && wrapper.querySelector("[role='combobox']")) || opener || wrapper;
    if (!fallback) return false;
    try { fallback.scrollIntoView({ block: "center", inline: "nearest" }); } catch (eScrollOpen) {}
    var fallbackRect = fallback.getBoundingClientRect && fallback.getBoundingClientRect();
    var fallbackX = fallbackRect ? fallbackRect.left + Math.max(2, Math.min(fallbackRect.width / 2, fallbackRect.width - 2)) : 0;
    var fallbackY = fallbackRect ? fallbackRect.top + Math.max(2, Math.min(fallbackRect.height / 2, fallbackRect.height - 2)) : 0;
    try {
      fallback.dispatchEvent(new window.MouseEvent("mousedown", {
        view: window, bubbles: true, cancelable: true, composed: true,
        clientX: fallbackX, clientY: fallbackY, button: 0, buttons: 1,
      }));
      await sleep(220);
      return true;
    } catch (eDomOpen) {
      return false;
    }
  }

  function collectOptionScopes(input) {
    var scopes = [];
    var listIds = [];
    if (input) {
      var idSources = [input];
      var antSelect = input.closest && input.closest(".ant-select");
      if (antSelect) {
        Array.prototype.slice.call(antSelect.querySelectorAll("[aria-controls], [aria-owns], [aria-activedescendant]")).forEach(function (node) {
          idSources.push(node);
        });
      }
      idSources.forEach(function (source) {
        ["aria-controls", "aria-owns", "aria-activedescendant"].forEach(function (name) {
          var id = source.getAttribute && source.getAttribute(name);
          if (id && listIds.indexOf(id) === -1) listIds.push(id);
        });
      });
    }
    listIds.forEach(function (id) {
      var node = document.getElementById(id);
      if (node) scopes.push(node);
      var parentList = node && node.closest && node.closest(".ant-select-dropdown, .ant-select-dropdown-menu, .rc-virtual-list, .rc-virtual-list-holder, [role='listbox']");
      if (parentList && scopes.indexOf(parentList) === -1) scopes.push(parentList);
    });
    Array.prototype.slice.call(document.querySelectorAll(
      ".ant-select-dropdown:not(.ant-select-dropdown-hidden), .ant-select-dropdown-placement-bottomLeft, .ant-select-dropdown-placement-bottomRight, .ant-select-dropdown:not([style*='display: none']), .ant-select-dropdown-menu, .rc-virtual-list:not([style*='display: none']), .rc-virtual-list-holder:not([style*='display: none']), .rc-virtual-list-holder-inner, [role='listbox'], [id$='_list']"
    )).forEach(function (scope) {
      if (isVisible(scope) && scopes.indexOf(scope) === -1) scopes.push(scope);
    });
    return scopes;
  }

  function findOptionByToken(token) {
    return document.querySelector("[data-af-ant-option-token='" + cssEscape(token) + "']");
  }

  function findOptionByInputAndValue(inputToken, value) {
    var input = document.querySelector("[data-af-ant-token='" + cssEscape(inputToken) + "']");
    var target = normalized(value);
    var candidates = [];
    var optionSelector = ".ant-select-dropdown-menu-item, .ant-select-item-option, .rc-virtual-list-holder-inner div[title], [role='option'], [data-value], li, div[title], div, span";
    collectOptionScopes(input).forEach(function (scope) {
      Array.prototype.slice.call(scope.querySelectorAll(optionSelector)).forEach(function (node) {
        var text = textOf(node);
        if (!text || /暂无数据|无匹配结果|loading|加载中|没有找到/i.test(text)) return;
        if (!isVisible(node) || !isNearInput(node, input)) return;
        if (candidates.indexOf(node) === -1) candidates.push(node);
      });
    });
    Array.prototype.slice.call(document.querySelectorAll(".rc-virtual-list-holder-inner div[title], div[title], div,span,li,[role='option'],[data-value]")).forEach(function (node) {
      var text = textOf(node);
      if (!text || normalized(text) !== target) return;
      if (!isVisible(node) || !isNearInput(node, input)) return;
      if (node.closest && node.closest(".ant-select")) return;
      if (candidates.indexOf(node) === -1) candidates.push(node);
    });
    if (candidates.length === 0) {
      Array.prototype.slice.call(document.querySelectorAll(".ant-select-dropdown:not(.ant-select-dropdown-hidden), .ant-select-dropdown:not([style*='display: none'])")).forEach(function (dropdown) {
        if (!isVisible(dropdown)) return;
        Array.prototype.slice.call(dropdown.querySelectorAll(optionSelector)).forEach(function (node) {
          var text = textOf(node);
          if (!text || normalized(text) !== target) return;
          if (!isVisible(node)) return;
          if (node.getAttribute && node.getAttribute("aria-disabled") === "true") return;
          if (node.classList && node.classList.contains("ant-select-dropdown-menu-item-disabled")) return;
          if (candidates.indexOf(node) === -1) candidates.push(node);
        });
      });
    }
    for (var i = 0; i < candidates.length; i++) {
      if (normalized(textOf(candidates[i])) === target) return candidates[i];
    }
    for (var j = 0; j < candidates.length; j++) {
      var text = normalized(textOf(candidates[j]));
      if (text && target && text.indexOf(target) !== -1 && text.length <= target.length + 4) return candidates[j];
    }
    for (var k = 0; k < candidates.length; k++) {
      var partial = normalized(textOf(candidates[k]));
      if (partial && target && target.indexOf(partial) !== -1 && partial.length >= 4) return candidates[k];
    }
    return null;
  }

  async function waitOptionByInputAndValue(inputToken, value, timeoutMs) {
    var timeoutAt = Date.now() + (timeoutMs || 5000);
    var option = null;
    while (Date.now() < timeoutAt) {
      option = findOptionByInputAndValue(inputToken, value);
      if (option) return option;
      await sleep(180);
    }
    return findOptionByInputAndValue(inputToken, value);
  }

  async function clickFirstOptionByPoint(inputToken, value) {
    var input = document.querySelector("[data-af-ant-token='" + cssEscape(inputToken) + "']");
    if (!input || !input.getBoundingClientRect || !document.elementsFromPoint) throw new Error("input_not_found");
    var targetText = normalized(value);
    var rect = input.getBoundingClientRect();
    var x = Math.max(2, Math.min(window.innerWidth - 2, rect.left + Math.min(70, Math.max(28, rect.width / 3))));
    var ys = [rect.bottom + 26, rect.bottom + 38, rect.bottom + 52, rect.bottom + 68];
    for (var round = 0; round < 14; round++) {
      var option = findOptionByInputAndValue(inputToken, value);
      if (option) {
        await clickLikeUser(option);
        return textOf(option);
      }
      for (var i = 0; i < ys.length; i++) {
        var y = Math.max(2, Math.min(window.innerHeight - 2, ys[i]));
        var stack = document.elementsFromPoint(x, y);
        for (var s = 0; s < stack.length; s++) {
          var node = stack[s];
          var text = normalized(textOf(node));
          if (!text || /暂无数据|无匹配结果|loading|加载中|没有找到/i.test(text)) continue;
          if (targetText && (text === targetText || text.indexOf(targetText) !== -1 || targetText.indexOf(text) !== -1)) {
            await clickLikeUser(node);
            return textOf(node);
          }
        }
      }
      await sleep(160);
    }
    var fallbackY = Math.max(2, Math.min(window.innerHeight - 2, rect.bottom + 34));
    var target = document.elementFromPoint(x, fallbackY);
    if (!target) throw new Error("point_target_not_found");
    await clickLikeUser(target);
    return textOf(target);
  }

  async function clickAddSchoolFullName(inputToken, value) {
    var input = document.querySelector("[data-af-ant-token='" + cssEscape(inputToken) + "']");
    if (!input) throw new Error("input_not_found");
    var targetText = String(value || input.value || "").trim();
    var candidates = Array.prototype.slice.call(document.querySelectorAll("a,button,span,div")).filter(function (node) {
      if (!isVisible(node) || !isNearInput(node, input)) return false;
      var text = textOf(node);
      return /添加学校全称|新增学校|添加院校|添加学校|新增院校/.test(text);
    });
    candidates.sort(function (a, b) {
      var ar = a.getBoundingClientRect();
      var br = b.getBoundingClientRect();
      return ar.width * ar.height - br.width * br.height;
    });
    var target = candidates[0];
    if (!target) throw new Error("add_school_link_not_found");
    setNativeValue(input, targetText);
    inputEvent(input, "insertText", targetText);
    await clickLikeUser(target);
    return textOf(target);
  }

  function comparableCascaderText(value) {
    return normalized(value).replace(/相关/g, "").replace(/类$/g, "");
  }

  function visibleCascaderPanelNear(wrapper) {
    // 中国银行旧版 rc-cascader 可能直接把列表渲染成 .ant-cascader-menu，
    // 没有外层 .ant-cascader-menus；仅对中国银行学位分支放宽容器识别。
    var panelSelector = isChinaHrDegreeCascader(wrapper)
      ? ".ant-cascader-menus, .ant-cascader-menu"
      : ".ant-cascader-menus";
    var panels = Array.prototype.slice.call(document.querySelectorAll(panelSelector))
      .filter(function (panel) { return isVisible(panel); });
    if (!panels.length) return null;
    // ChinaHR 的旧 rc-cascader 将浮层直接 portal 到 body；不要用触发器与
    // 浮层的几何距离过滤，否则页面滚动/浮层向上展开时会误判为未打开。
    if (isChinaHrDegreeOrWorkTypeCascader(wrapper)) return panels[panels.length - 1];
    if (!wrapper || !wrapper.getBoundingClientRect) return panels[panels.length - 1];
    var wr = wrapper.getBoundingClientRect();
    panels.sort(function (a, b) {
      var ar = a.getBoundingClientRect();
      var br = b.getBoundingClientRect();
      var ad = Math.abs(ar.left - wr.left) + Math.min(Math.abs(ar.top - wr.bottom), Math.abs(ar.bottom - wr.top));
      var bd = Math.abs(br.left - wr.left) + Math.min(Math.abs(br.top - wr.bottom), Math.abs(br.bottom - wr.top));
      return ad - bd;
    });
    var best = panels[0];
    var rect = best.getBoundingClientRect();
    var horizontalDistance = Math.abs(rect.left - wr.left);
    var verticalDistance = Math.min(Math.abs(rect.top - wr.bottom), Math.abs(rect.bottom - wr.top));
    return horizontalDistance <= Math.max(420, wr.width + 120) && verticalDistance <= 240 ? best : null;
  }

  function findVisibleCascaderOption(value, wrapper) {
    var target = normalized(value);
    var comparableTarget = comparableCascaderText(value);
    var scope = visibleCascaderPanelNear(wrapper) || document;
    var chinaHrDegreeField = isChinaHrDegreeOrWorkTypeCascader(wrapper) && (function () {
      var row = wrapper && wrapper.closest && wrapper.closest(".aply-field-li");
      var label = row && row.querySelector && row.querySelector(".aply-field-label");
      return /^学位/.test(normalized(textOf(label)));
    }());
    var candidates = Array.prototype.slice.call(scope.querySelectorAll(
      ".ant-cascader-menu-item, .ant-cascader-menu li, .ant-cascader-menus li, .ant-cascader-dropdown .ant-select-item-option, .ant-select-dropdown .ant-cascader-menu-item"
    )).filter(function (node) {
      return isVisible(node) && !/disabled/.test(String(node.className || ""));
    });
    if (target === normalized("__AF_FIRST_OPTION__")) return candidates[0] || null;
    for (var i = 0; i < candidates.length; i++) {
      if (normalized(textOf(candidates[i])) === target) return candidates[i];
    }
    for (var j = 0; j < candidates.length; j++) {
      var text = normalized(textOf(candidates[j]));
      if (text && target && (text.indexOf(target) !== -1 || target.indexOf(text) !== -1)) return candidates[j];
    }
    for (var k = 0; k < candidates.length; k++) {
      var comparableText = comparableCascaderText(textOf(candidates[k]));
      if (comparableText && comparableTarget && (
        comparableText === comparableTarget ||
        comparableText.indexOf(comparableTarget) !== -1 ||
        comparableTarget.indexOf(comparableText) !== -1
      )) return candidates[k];
    }
    if (chinaHrDegreeField) {
      var degreeRank = function (text) {
        text = String(text || "");
        if (/博士/.test(text)) return "博士";
        if (/硕士|研究生|MBA|EMBA/i.test(text)) return "硕士";
        if (/学士|本科|大学/.test(text)) return "学士";
        if (/无学位|未取得|未获得|^无$/.test(text)) return "无学位";
        return "";
      };
      var wantedRank = degreeRank(value);
      if (wantedRank) {
        for (var d = 0; d < candidates.length; d++) {
          if (degreeRank(textOf(candidates[d])) === wantedRank) return candidates[d];
        }
      }
    }
    return null;
  }

  function hasVisibleCascaderOptions(wrapper) {
    var panel = visibleCascaderPanelNear(wrapper);
    if (!panel) return false;
    return Array.prototype.slice.call(panel.querySelectorAll(
      ".ant-cascader-menu-item, .ant-cascader-menu li, .ant-cascader-menus li"
    )).some(function (node) {
      return isVisible(node) && !/disabled/.test(String(node.className || ""));
    });
  }

  async function ensureCascaderOpen(opener, wrapper) {
    try { wrapper.scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" }); } catch (eScroll) {}
    await sleep(180);
    if (hasVisibleCascaderOptions(wrapper)) return true;

    // 中国银行学位是旧版 rc-cascader：真正的开关绑定在
    // `.ant-cascader-picker` 根节点，而不是内部的 label/input。旧组件对
    // mousedown 后紧接 click 会再次关闭弹层，因此这里先只发一次
    // mousedown，并在事件后立即确认；只有仍未打开时才补发 click。
    if (isChinaHrDegreeCascader(wrapper) || isChinaHrDegreeOrWorkTypeCascader(wrapper)) {
      try {
        wrapper.focus && wrapper.focus();
        var rootRect = wrapper.getBoundingClientRect && wrapper.getBoundingClientRect();
        var rootInit = {
          view: window, bubbles: true, cancelable: true, composed: true,
          clientX: rootRect ? rootRect.left + rootRect.width / 2 : 0,
          clientY: rootRect ? rootRect.top + rootRect.height / 2 : 0,
          button: 0, buttons: 1,
        };
        wrapper.dispatchEvent(new window.MouseEvent("mousedown", rootInit));
        await sleep(180);
        if (hasVisibleCascaderOptions(wrapper)) return true;
        wrapper.dispatchEvent(new window.MouseEvent("click", rootInit));
        await sleep(220);
        if (hasVisibleCascaderOptions(wrapper)) return true;
      } catch (eChinaHrRootOpen) {}
    }

    await openCascaderOnce(opener, wrapper);
    var timeoutAt = Date.now() + 1600;
    while (Date.now() < timeoutAt) {
      if (hasVisibleCascaderOptions(wrapper)) return true;
      await sleep(120);
    }
    // ChinaHR 使用 Ant Design 3.x 的旧 Cascader，点击内部 label 有时只获得
    // focus 不会展开菜单；补点外层 picker 本身，触发 rc-cascader 的 toggle。
    if (wrapper && wrapper !== opener) {
      try {
        wrapper.dispatchEvent(new window.MouseEvent("mousedown", { bubbles: true, cancelable: true, composed: true, view: window }));
        wrapper.dispatchEvent(new window.MouseEvent("mouseup", { bubbles: true, cancelable: true, composed: true, view: window }));
        wrapper.dispatchEvent(new window.MouseEvent("click", { bubbles: true, cancelable: true, composed: true, view: window }));
        if (typeof wrapper.click === "function") wrapper.click();
      } catch (eChinaHrOpen) {}
      await sleep(260);
      if (hasVisibleCascaderOptions(wrapper)) return true;
    }
    // 208 方案仍是“一次点击一组事件”。这里只在第一次确实没有打开时，
    // 改点外层 Ant Cascader 容器再试一次，不触碰已经打开的弹层。
    if (wrapper && wrapper !== opener) await openCascaderOnce(wrapper, wrapper);
    timeoutAt = Date.now() + 2200;
    while (Date.now() < timeoutAt) {
      if (hasVisibleCascaderOptions(wrapper)) return true;
      await sleep(120);
    }
    return false;
  }

  function findVisibleCascaderSearchInput() {
    var candidates = Array.prototype.slice.call(document.querySelectorAll(
      ".ant-cascader-menus input:not([type='hidden']), .ant-cascader-dropdown input:not([type='hidden']), .ant-select-dropdown input:not([type='hidden'])"
    )).filter(function (node) {
      if (!node || node.disabled || !isVisible(node)) return false;
      var placeholder = String(node.getAttribute("placeholder") || "");
      return /搜索|学校|院校|名称/i.test(placeholder) || !node.readOnly;
    });
    return candidates[0] || null;
  }

  async function tryCascaderPanelSearch(finalValue) {
    var searchInput = findVisibleCascaderSearchInput();
    if (!searchInput || !finalValue) return false;
    try {
      var oldReadOnly = searchInput.readOnly;
      searchInput.removeAttribute && searchInput.removeAttribute("readonly");
      searchInput.readOnly = false;
      searchInput.focus && searchInput.focus();
      setNativeValue(searchInput, "");
      inputEvent(searchInput, "deleteContentBackward", null);
      await sleep(80);
      setNativeValue(searchInput, finalValue);
      inputEvent(searchInput, "insertText", finalValue);
      searchInput.dispatchEvent(new window.Event("search", { bubbles: true, cancelable: true, composed: true }));
      searchInput.dispatchEvent(new window.Event("change", { bubbles: true, cancelable: true, composed: true }));
      invokeReactInputHandlers(searchInput, ["onInput", "onChange", "onSearch"], "");
      await sleep(750);
      var matched = findVisibleCascaderOption(finalValue);
      if (matched) {
        await clickLikeUser(matched);
        await sleep(260);
        return true;
      }
      searchInput.readOnly = oldReadOnly;
    } catch (e) {}
    return false;
  }

  async function typeChinaHrCascaderValue(wrapper, value) {
    if (!wrapper || !value) return false;
    var input = wrapper.querySelector && wrapper.querySelector("input.ant-cascader-input, input[placeholder='请选择']");
    if (!input) return false;
    try {
      input.removeAttribute && input.removeAttribute("readonly");
      input.readOnly = false;
      input.focus && input.focus();
      input.select && input.select();
      var text = String(value);
      var inserted = false;
      try {
        inserted = !!(document.execCommand && document.execCommand("insertText", false, text));
      } catch (eExec) {}
      if (!inserted || String(input.value || "") !== text) {
        setNativeValue(input, "");
        inputEvent(input, "deleteContentBackward", null);
        invokeReactInputHandlers(input, ["onInput", "onChange"], "");
        await sleep(60);
        setNativeValue(input, text);
        inputEvent(input, "insertText", text);
        input.dispatchEvent(new window.Event("change", { bubbles: true, cancelable: true, composed: true }));
        invokeReactInputHandlers(input, ["onInput", "onChange", "onSearch"], "");
      }
      await sleep(520);
      return true;
    } catch (e) {
      return false;
    }
  }

  async function fillAntCascader(token, values) {
    try { document.documentElement.setAttribute("data-af-ant-cascader-status", "running"); } catch (eStatus) {}
    var trigger = document.querySelector("[data-af-ant-cascader-token='" + cssEscape(token) + "']");
    if (!trigger) throw new Error("cascader_trigger_not_found");
    var wrapper = trigger.closest && trigger.closest(".ant-cascader-picker, .ant-select.ant-cascader, .ant-cascader") || trigger;
    var opener = wrapper.querySelector && wrapper.querySelector(".ant-select-selector, .ant-cascader-picker-label, [role='combobox']") || wrapper;
    if (!await ensureCascaderOpen(opener, wrapper)) throw new Error("cascader_panel_not_open");
    var isChinaHr = /^applyjob\.chinahr\.com$/i.test(String(window.location && window.location.hostname || ""));
    var isChinaHrDegree = isChinaHr && isChinaHrDegreeCascader(wrapper);
    var isChinaHrWorkType = isChinaHr && isChinaHrDegreeOrWorkTypeCascader(wrapper) && !isChinaHrDegree;
    var isChinaHrDegreeOrWorkType = isChinaHr && isChinaHrDegreeOrWorkTypeCascader(wrapper);
    for (var i = 0; i < values.length; i++) {
      // ChinaHR 工作类别仍使用搜索输入；中国银行“学位”的 input 为
      // tabindex=-1，学位分支直接打开菜单并点击真实选项。
      // 工作类别不向 tabindex=-1 的输入框写字，直接使用已展开的首项。
      var option = null;
      // 中行实习“工作类别”固定选第一个选项，避免受简历中的工作类别
      // 文本或旧版 Cascader 搜索状态影响。
      if (isChinaHrWorkType && values.length === 1) {
        option = findVisibleCascaderOption("__AF_FIRST_OPTION__", wrapper);
      }
      var timeoutAt = Date.now() + (isChinaHrDegree ? 1600 : 7000);
      while (Date.now() < timeoutAt && !option) {
        option = findVisibleCascaderOption(values[i], wrapper);
        if (!option) await sleep(220);
      }
      // 中行新页面的学位是单层旧版 rc-cascader。输入框虽然带
      // `ant-cascader-picker-show-search`，但实际 input 为 tabindex=-1，
      // 先改写搜索值会让候选列表进入“已过滤但未提交”状态。单层学位先
      // 直接点击首屏真实选项；只有首屏没有该项时才启用搜索输入。
      if (!option && isChinaHrDegree && values.length === 1 && normalized(values[i]) !== normalized("__AF_FIRST_OPTION__")) {
        await typeChinaHrCascaderValue(wrapper, values[i]);
        timeoutAt = Date.now() + 7000;
        while (Date.now() < timeoutAt && !option) {
          option = findVisibleCascaderOption(values[i], wrapper);
          if (!option) await sleep(220);
        }
      }
      if (!option) throw new Error("cascader_option_not_found:" + values[i]);
      if (isChinaHrDegreeOrWorkType) {
        await reactCascaderClick(option);
        await sleep(260);
        if (!chinaHrChoiceCommitted(wrapper, normalized(values[i]))) {
          await clickCascaderOnce(option);
        }
      } else {
        await clickCascaderOnce(option);
      }
      var commitExpected = normalized(values[i]) === normalized("__AF_FIRST_OPTION__")
        ? textOf(option)
        : values[i];
      // 某些 Ant Design 3.x 页面会吞掉直接调用的 React onClick：
      // 菜单看似点过，但 `.ant-cascader-picker-label` 仍为空。此时只对
      // 当前真实选项补发一次原生点击，并以页面提交状态作为成功条件。
      if (i === values.length - 1) {
        if (isChinaHrDegreeOrWorkTypeCascader(wrapper) && !chinaHrChoiceCommitted(wrapper, commitExpected)) {
          // ChinaHR 使用旧版 rc-cascader 时，原生事件可能只改变 hover/焦点，
          // 而选项的 React onClick 才真正写入表单状态。仅在原生路径未提交时
          // 补发一次 React 处理器，避免对已成功的级联重复点击而关闭菜单。
          await reactCascaderClick(option);
          await sleep(260);
        }
        if (!chinaHrChoiceCommitted(wrapper, commitExpected)) {
          await nativeCascaderClick(option);
        }
        if (!chinaHrChoiceCommitted(wrapper, commitExpected)) {
          // ChinaHR 旧版 rc-cascader 有时会吞掉 li.click，但保留键盘导航状态；
          // 对单层学位用 ArrowDown + Enter 触发组件自身的 onChange。
          await keyboardCommitCascader(wrapper, commitExpected);
        }
        if (!chinaHrChoiceCommitted(wrapper, commitExpected)) {
          if (await ensureCascaderOpen(opener, wrapper)) {
            var retryOption = findVisibleCascaderOption(commitExpected, wrapper);
            if (retryOption) {
              await clickCascaderOnce(retryOption);
              await sleep(500);
            }
          }
        }
        if (!chinaHrChoiceCommitted(wrapper, commitExpected)) {
          throw new Error("cascader_value_not_committed:" + values[i]);
        }
      }
      if (i < values.length - 1) {
        var nextValue = values[i + 1];
        var nextTimeoutAt = Date.now() + 7000;
        while (Date.now() < nextTimeoutAt && !findVisibleCascaderOption(nextValue, wrapper)) await sleep(220);
        if (!findVisibleCascaderOption(nextValue, wrapper)) throw new Error("cascader_next_level_not_ready:" + nextValue);
      } else {
        await sleep(500);
      }
    }
    return true;
  }

  async function clickAntAction(token) {
    var element = document.querySelector("[data-af-ant-action-token='" + cssEscape(token) + "']");
    if (!element) throw new Error("action_not_found");
    try { element.scrollIntoView({ block: "center", inline: "nearest" }); } catch (eScroll) {}
    var chain = [element];
    var parent = element.parentElement;
    while (parent && chain.length < 5) {
      chain.push(parent);
      parent = parent.parentElement;
    }
    for (var i = 0; i < chain.length; i++) {
      var props = reactPropsOf(chain[i]);
      if (!props || typeof props.onClick !== "function") continue;
      var rect = element.getBoundingClientRect && element.getBoundingClientRect();
      var x = rect ? rect.left + Math.max(2, Math.min(rect.width / 2, rect.width - 2)) : 0;
      var y = rect ? rect.top + Math.max(2, Math.min(rect.height / 2, rect.height - 2)) : 0;
      props.onClick(makeSyntheticLikeEvent("click", element, x, y));
      await sleep(250);
      return true;
    }
    if (typeof element.click !== "function") throw new Error("action_click_unavailable");
    element.click();
    await sleep(250);
    return true;
  }

  window.addEventListener("message", async function (event) {
    if (event.source !== window) return;
    var data = event.data || {};
    if (!data || ["AF_ANT_TYPE_REQUEST_V2", "AF_ANT_DIRECT_TYPE_REQUEST_V2", "AF_ANT_CLICK_REQUEST_V2", "AF_ANT_POINT_CLICK_REQUEST_V2", "AF_ANT_ADD_SCHOOL_REQUEST_V2", "AF_ANT_COMMIT_REQUEST_V2", "AF_ANT_CASCADER_REQUEST_V2", "AF_ANT_ACTION_CLICK_REQUEST_V2"].indexOf(data.type) === -1) return;
    if ((data.type === "AF_ANT_TYPE_REQUEST_V2" || data.type === "AF_ANT_DIRECT_TYPE_REQUEST_V2") && !data.token) return;
    var ok = false;
    var error = "";
    var value = "";
    try {
      if (data.type === "AF_ANT_TYPE_REQUEST_V2" || data.type === "AF_ANT_DIRECT_TYPE_REQUEST_V2") {
        var input = document.querySelector("[data-af-ant-token='" + cssEscape(data.token) + "']");
        if (!input) throw new Error("input_not_found");
        value = await typeSearch(input, data.value || "", data.type === "AF_ANT_DIRECT_TYPE_REQUEST_V2");
        if (data.forceReactCommit === true) {
          // 交行研究方向“若未找到”输入框是 React 受控输入。execCommand 可以
          // 让 DOM 显示正确文本，却不保证组件 state 已同步；而旁边“提交”读取
          // 的正是 state。显式触发 React onInput/onChange，并在重绘后重新取当前
          // input，确保提交读取到真实值。
          var committedInput = findLatestVisibleInputById(input.id, input);
          if (committedInput) {
            setNativeValue(committedInput, data.value || "");
            inputEvent(committedInput, "insertText", data.value || "");
            committedInput.dispatchEvent(new window.Event("change", { bubbles: true, cancelable: true, composed: true }));
            invokeReactInputHandlers(committedInput, ["onInput", "onChange"], "");
            await sleep(180);
            committedInput = findLatestVisibleInputById(input.id, committedInput);
            value = committedInput && committedInput.value || value;
          }
        }
      } else if (data.type === "AF_ANT_CLICK_REQUEST_V2") {
        var option = findOptionByToken(data.token) || await waitOptionByInputAndValue(data.inputToken, data.value, 5000);
        if (!option) throw new Error("option_not_found");
        value = textOf(option);
        await clickLikeUser(option);
      } else if (data.type === "AF_ANT_POINT_CLICK_REQUEST_V2") {
        value = await clickFirstOptionByPoint(data.inputToken, data.value);
      } else if (data.type === "AF_ANT_ADD_SCHOOL_REQUEST_V2") {
        value = await clickAddSchoolFullName(data.inputToken, data.value);
      } else if (data.type === "AF_ANT_COMMIT_REQUEST_V2") {
        value = await commitActiveOption(data.inputToken, data.value);
      } else if (data.type === "AF_ANT_CASCADER_REQUEST_V2") {
        value = await fillAntCascader(data.token, Array.isArray(data.values) ? data.values : []);
      } else if (data.type === "AF_ANT_ACTION_CLICK_REQUEST_V2") {
        value = await clickAntAction(data.token);
      }
      // 必须透传动作真实结果。此前这里无条件写 true，导致 Cascader
      // 即使没有把“硕士/学士”提交到 React 状态，也被填写引擎当成成功。
      ok = value === true || value === "true";
    } catch (e) {
      error = e && e.message ? e.message : String(e);
    }
    if (data.type === "AF_ANT_CASCADER_REQUEST_V2") {
      try { document.documentElement.setAttribute("data-af-ant-cascader-status", ok ? "ok" : ("error:" + error)); } catch (eStatusResult) {}
    }
    window.postMessage({
      type: data.type === "AF_ANT_ACTION_CLICK_REQUEST_V2" ? "AF_ANT_ACTION_CLICK_RESULT_V2" : (data.type === "AF_ANT_CASCADER_REQUEST_V2" ? "AF_ANT_CASCADER_RESULT_V2" : (data.type === "AF_ANT_COMMIT_REQUEST_V2" ? "AF_ANT_COMMIT_RESULT_V2" : (data.type === "AF_ANT_ADD_SCHOOL_REQUEST_V2" ? "AF_ANT_ADD_SCHOOL_RESULT_V2" : (data.type === "AF_ANT_POINT_CLICK_REQUEST_V2" ? "AF_ANT_POINT_CLICK_RESULT_V2" : (data.type === "AF_ANT_CLICK_REQUEST_V2" ? "AF_ANT_CLICK_RESULT_V2" : "AF_ANT_TYPE_RESULT_V2"))))),
      id: data.id,
      ok: ok,
      value: value,
      error: error,
    }, "*");
  });
})();
