// content/utils.js — 公共工具函数
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   DomUtils 静态类 (混淆名 p, webpack模块744):  行 674-2134 (isElementVisible ~ findExperienceToggle)
//   智能下拉匹配引擎 (混淆名 k, 同一模块744内, 行2135-4283, 导出别名 aZ/n.c，
//     与上面的 p 类同属模块744对外暴露的公共接口，供全部18个SelectAdapter调用):
//     - 省市/学历/CET/获奖等级/GPA区间等专项匹配 (isInProvinceCity~scoreEducationTypeOption): 行2146-2630
//     - 获奖等级 + GPA/薪资区间匹配 (getAwardGradeKey~findBestRangeMatch):     行2632-2912
//     - isOptionMatch 总入口 (综合调用上面所有专项匹配):                        行2913-2944
//     - Jaro/Jaro-Winkler/字符频率/最长公共子序列 相似度算法:                  行3719-3863
//     - extractNumbers/matchByNumbers/determineScoreTrend:                    行4016-4156
//     - intelligentOptionMatch 智能兜底匹配总入口:                            行4157-4283
//   全局CSS选择器配置 (混淆名 n.D, webpack模块3499): 行 7545-7559
//   LabelUtils 静态类 (混淆名 a, 导出 Rt.T):       行 4340-4470+
//   findFieldKeyByMapping():                       行 10358-10386
//   waitForElement() (ElementMatcher模块内的通用版): 行 69334-69389
//   enhancedClick()/dispatchEvents() (日期模块内):   行 27300-27338
//   cleanHtml(): 见 content/clean-html.js (改用 autofill-test-extension 已验证版本)
//
// 改造点: 纯工具函数，无会员/配额逻辑，原样保留一行不改（仅变量名从单字母改为语义名）。
// 智能下拉匹配引擎里 isInProvinceCity/resolveProvinceCity/normalizeLocationPath/
// buildProvinceCityPath (省市地址级联) 依赖一份省市数据表(源码变量x)，属于独立的地址
// 选择器功能，本次未移植；getCategoryByMajorFromBackend 依赖远程 /majors/search 接口，
// 同样未移植。这两处不影响 GPA/薪资区间/CET/获奖等级/模糊匹配这条核心链路。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});

  function sleep(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, ms);
    });
  }

  // 文件选择必须始终由用户本人完成。这里只识别控件自身和很近的按钮包装层，
  // 不扫描整个表单祖先的文本，避免因为页面其他位置存在“上传简历”而误伤普通字段。
  function isManualUploadAction(el) {
    try {
      if (!el || !el.closest) return false;
      if (el.matches && el.matches('input[type="file"]')) return true;
      var action = el.closest("button, label, a, [role='button'], [onclick], [class*='button' i], [class*='btn' i]") || el;
      var actionText = String([
        action.textContent,
        action.getAttribute && action.getAttribute("aria-label"),
        action.getAttribute && action.getAttribute("title"),
        action.getAttribute && action.getAttribute("name"),
      ].filter(Boolean).join(" ")).replace(/\s+/g, "").toLowerCase();
      if (/上传|附件|选择文件|照片|证件照|生活照|upload|attachment|choosefile/.test(actionText)) return true;
      var current = action;
      for (var depth = 0; current && depth < 4; depth++, current = current.parentElement) {
        var cls = String(current.className || "").toLowerCase();
        if (/upload|attachment|file[_-]?picker|portrait[_-]?upload/.test(cls)) return true;
        if (depth < 2 && current.querySelector && current.querySelector('input[type="file"]')) return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  function isFilingLinkAction(el) {
    try {
      if (!el || !el.closest) return false;
      var action = el.closest("a[href], button, [role='button'], [onclick]") || el;
      var text = String([
        action.textContent,
        action.getAttribute && action.getAttribute("aria-label"),
        action.getAttribute && action.getAttribute("title"),
        action.getAttribute && action.getAttribute("href"),
      ].filter(Boolean).join(" ")).replace(/\s+/g, "");
      var href = String(action.getAttribute && action.getAttribute("href") || "");
      return /备案|ICP备|ICP|公安网安|公网安备|beian|miit/i.test(text + " " + href);
    } catch (e) {
      return false;
    }
  }

  function isForbiddenAutoClickAction(el) {
    return isManualUploadAction(el) || isFilingLinkAction(el);
  }

  // ============ 全局 CSS 选择器配置 (源码模块3499, 行7545-7559) ============
  var SELECTORS = {
    date: [
      'input[type="date"]', ".ant-calendar-picker", ".el-date-editor", ".mtd-date-picker",
      ".kuma-calendar-picker-input", ".atsx-date-picker-period-month-label", ".atsx-date-picker",
      ".mtd-date-picker ", '[class^="sd-picker-input"]', ".month-range-select", ".el-date-editor",
      ".ant-picker-range", ".ant-picker-input", ".ant-calendar-picker", ".brick-date-picker",
      ".brick-date-picker-trigger", ".phoenix-date-picker", ".el-date-editor.el-range-editor",
      ".phoenix-select", ".ant-calendar-range-picker-input", ".sel_date_year", ".Wdate",
      ".ivu-date-picker", ".bitable-date-time-editor", ".bitable-reminder-date-picker-input",
      ".bitable-reminder-date-picker", ".bitable-3356de__calendar-picker",
      ".ud__picker", ".ud__picker-input", ".ud__picker-range", ".ud-datepicker",
      ".throne-biz-date-range-picker-wrapper", ".throne-biz-date-range-picker-input",
      '[data-tag="we-datepicker"]', '.picker[data-tag="we-datepicker"]', ".aui-date-picker", ".aui-picker",
      ".required-year", ".required-month", ".small-select-ul", ".splicing-select-ul",
      ".date-ipt", ".mdf-cal",
      ".next-range-picker", ".next-date-picker", ".next-month-picker",
    ],
    select: [
      ".ant-select-selection__rendered", ".el-select-search", ".mtd-select",
      ".kuma-select2-selection__rendered", ".atsx-select-selection__rendered",
      '[class^="sd-Select-container"]', ".ant-cascader-picker", ".brick-select", ".phoenix-select",
      ".el-cascader", ".el-select", ".layui-form-select", ".ivu-select-selection",
      ".bitable-single-selector-editor", ".bitable-multi-selector-editor", ".bitable-3356de__select",
      ".b-select-dropdown-menu", ".ud__select", ".ud__select__selector", ".aui-select",
      ".rocket-select", ".rocket-select-selector", ".select-wrapper",
      ".next-select", ".next-select-trigger",
    ],
    radio: ["input[type=\"radio\"]", ".ant-radio", ".el-radio", ".kuma-radio", ".el-radio__input", ".phoenix-radio__wrapper", ".aui-radio", ".aui-radio-group"],
    addButton: [
      ".add-button", ".add-btn", ".add-icon", ".add-new", ".btn-add", ".btn-new", ".create-button",
      ".create-btn", ".add-more-btn-link", ".bili-form-add", ".addMore-add",
      ".sd-Button-content-1nfPb", ".add-one__afqKP",
    ],
    containers: [
      ".uxcore-card", ".bili-resume-card", ".createFormSection__3y6MP,.createFormSection-container",
      ".base_info_edit, .model_edit", ".ant-card", ".apply-block-KRDTLLb5hU", ".send_box",
      ".applyFormModuleWrapper-windows",
    ],
    titles: [
      ".uxcore-card-title-text", ".bili-form-card-header", ".createFormSection-title", ".model_title",
      ".text-JHHb1llnzL.theme-border-color", ".ant-card-head-title", ".send_title",
      ".applyFormModuleWrapper-title",
    ],
    labels: [".label", ".title-IWWQ0Xa4L7", ".subtitle", ".atsx-form-item-label"],
    edit: [".module-title__edit"],
  };

  function normalizeNumericPunctuation(value) {
    var text = String(value == null ? "" : value);
    var previous = null;
    // Only collapse comma-like punctuation when it is a thousands separator.
    // This keeps list delimiters intact while allowing mature GPA/salary range
    // matching to understand values such as 15,000元/月 and 10，000-20，000元.
    while (previous !== text) {
      previous = text;
      text = text.replace(/(\d)[,，](\d{3})(?=\D|$)/g, "$1$2");
    }
    return text;
  }

  // ============ DomUtils (源码 p 类, 行663-1364) ============
  var DomUtils = {
    normalizeNumericPunctuation: normalizeNumericPunctuation,

    isElementVisible: function (el) {
      if (!el) return false;
      try {
        var style = window.getComputedStyle(el);
        if (style.display === "none" || style.visibility === "hidden") return false;
        for (var p = el.parentElement; p; ) {
          var ps = window.getComputedStyle(p);
          if (ps.display === "none" || ps.visibility === "hidden") return false;
          p = p.parentElement;
        }
        return true;
      } catch (e) {
        return true;
      }
    },

    findClosestAncestorWithClass: function (el, className) {
      if (!(el instanceof HTMLElement)) return null;
      if (typeof className !== "string" || className.trim() === "") return null;
      var cur = el;
      var depth = 0;
      while (cur && depth < 50) {
        if (cur.classList.contains(className)) return cur;
        cur = cur.parentElement;
        depth++;
      }
      return null;
    },

    hasClassSubstring: function (el, substr) {
      return !!el && !!substr && Array.from(el.classList).some(function (c) {
        return c.includes(substr);
      });
    },

    matchesAnySelector: function (el, selectors) {
      return !!el && !!selectors && selectors.length !== 0 && selectors.some(function (sel) {
        try {
          return el.matches(sel);
        } catch (e) {
          return false;
        }
      });
    },

    // 地址字段统一读取规则：结构化 path 是权威值，普通字符串只作为旧数据兜底。
    // 不在这里把籍贯回退到生源地/户口所在地，避免不同语义的地址互相污染。
    resolveAddressValue: function (record, fieldKey) {
      if (!record || !fieldKey) return "";
      var pathFields = {
        nativePlace: "nativePlacePath",
        birthOrigin: "birthOriginPath",
        hukouLocation: "hukouLocationPath",
        archiveLocation: "archiveLocationPath",
        currentAddress: "currentAddressPath",
        familyLocation: "familyLocationPath",
        schoolLocation: "schoolLocationPath",
        expectedLocation: "expectedLocationPath",
      };
      var pathField = pathFields[fieldKey];
      var rawPath = pathField ? record[pathField] : null;
      var parts = Array.isArray(rawPath)
        ? rawPath.filter(Boolean)
        : String(rawPath || "").split(/\s*(?:\/|>|＞|,|，|\|)\s*/).filter(Boolean);
      if (parts.length) {
        return parts.filter(function (part) { return !/^(市辖区|县)$/.test(String(part)); }).join("");
      }
      return record[fieldKey] == null ? "" : record[fieldKey];
    },

    // 教育记录把省、市拆开保存；北森 Phoenix 的“院校所在城市”实际是
    // 地址级联，必须把两者按层级传入，不能只把城市拿去匹配第一层省份。
    resolveEducationLocationPath: function (record) {
      if (!record) return [];
      var rawPath = record.schoolLocationPath;
      var parts = Array.isArray(rawPath)
        ? rawPath.filter(Boolean)
        : String(rawPath || "").split(/\s*(?:\/|>|＞|,|，|\|)\s*/).filter(Boolean);
      if (parts.length >= 2) return parts.filter(function (part) { return !/^(市辖区|县)$/.test(String(part)); });
      var province = String(record.schoolProvince || "").trim();
      var city = String(record.city || record.schoolCity || "").trim();
      if (province && city) return [province, city];
      return [];
    },

    isSearchSelect: function (el, config) {
      if (!el) return false;
      // Hotjob 的学校/专业等联想选择框没有 placeholder，也没有常见的
      // search/select 类名，但 school-or-subject="2" 明确表示“输入后选择候选项”。
      // 将它路由到现有搜索选择能力，避免只写入表面文本而没有提交真实值。
      if (el.matches && el.matches("input[school-or-subject='2']")) return true;
      if (el.closest && el.closest(".bitable-single-selector-editor, .bitable-multi-selector-editor")) {
        return false;
      }
      if (config && config.selectors && config.selectors.address && config.selectors.address.class) {
        if (el.matches(config.selectors.address.class) || el.closest(config.selectors.address.class)) {
          return true;
        }
      }
      var elSelectContainer = (el.closest && el.closest(".el-select")) || (DomUtils.hasClassSubstring(el, "el-select") ? el : null);
      var elCascaderContainer = (el.closest && el.closest(".el-cascader")) || (DomUtils.hasClassSubstring(el, "el-cascader") ? el : null);
      var elAutocompleteContainer = (el.closest && el.closest(".el-autocomplete")) || (DomUtils.hasClassSubstring(el, "el-autocomplete") ? el : null);
      if (elSelectContainer || elCascaderContainer || elAutocompleteContainer) {
        var input = (elSelectContainer || elCascaderContainer || elAutocompleteContainer).querySelector("input");
        return !!input && !input.readOnly && !input.disabled;
      }
      return (
        DomUtils.hasClassSubstring(el, "search") ||
        DomUtils.hasClassSubstring(el, "cascader") ||
        DomUtils.hasClassSubstring(el.parentElement, "select-filter-input") ||
        DomUtils.hasClassSubstring(el.parentElement, "sd-Select-container")
      );
    },

    isNormalSelect: function (el, config) {
      if (config && config.selectors && config.selectors.select && config.selectors.select.class) {
        if (el.matches(config.selectors.select.class) || el.closest(config.selectors.select.class)) {
          return !DomUtils.isSearchSelect(el, config);
        }
      }
      return (
        SELECTORS.select.some(function (sel) {
          return el.matches(sel) || el.closest(sel);
        }) ||
        el.tagName.toLowerCase() === "select" ||
        !!el.closest(".el-select") ||
        !!el.closest(".ant-select")
      );
    },

    isDatePicker: function (el, config) {
      if (config && config.selectors && config.selectors.datePicker && config.selectors.datePicker.class) {
        if (el.matches(config.selectors.datePicker.class) || el.closest(config.selectors.datePicker.class)) {
          return true;
        }
      }
      return SELECTORS.date.some(function (sel) {
        return el.matches(sel) || el.closest(sel);
      });
    },

    isDateValue: function (val) {
      if (!val) return false;
      if (typeof val === "object" && (Object.prototype.hasOwnProperty.call(val, "startTime") || Object.prototype.hasOwnProperty.call(val, "endTime"))) {
        return true;
      }
      if (typeof val === "string") {
        if (/^\d{4}[-\/年]\d{1,2}(?:[-\/月]\d{1,2}日?)?\s*~\s*(?:\d{4}[-\/年]\d{1,2}(?:[-\/月]\d{1,2}日?)?|至今|目前|现在|当前)$/.test(val)) return true;
        if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(val)) return true;
        if (/^\d{4}-\d{1,2}$/.test(val)) return true;
        if (/^\d{4}年\d{1,2}月\d{1,2}日$/.test(val)) return true;
        if (/^\d{4}年\d{1,2}月$/.test(val)) return true;
        if (/^\d{4}\/\d{1,2}\/\d{1,2}$/.test(val)) return true;
      }
      return false;
    },

    isRadioGroup: function (el, config) {
      if (config && config.selectors && config.selectors.radio && config.selectors.radio.class) {
        if (el.matches(config.selectors.radio.class) || el.closest(config.selectors.radio.class)) return true;
      }
      return (
        SELECTORS.radio.some(function (sel) {
          return el.matches(sel) || el.closest(sel);
        }) ||
        el.type === "radio" ||
        !!el.closest(".el-radio-group") ||
        !!el.closest(".ant-radio-group") ||
        !!el.closest(".phoenix-radio-group")
      );
    },

    isCheckbox: function (el, config) {
      if (config && config.selectors && config.selectors.checkbox && config.selectors.checkbox.class) {
        if (el.matches(config.selectors.checkbox.class) || el.closest(config.selectors.checkbox.class)) return true;
      }
      return (
        el.type === "checkbox" ||
        el.getAttribute("role") === "checkbox" ||
        el.classList.contains("checkbox") ||
        !!el.closest(".el-checkbox") ||
        !!el.closest(".ant-checkbox-wrapper") ||
        !!el.closest('[class*="checkbox"]')
      );
    },

    isClickable: function (el) {
      if (!el) return false;
      if (["button", "a", "input", "select"].includes(el.tagName.toLowerCase())) return true;
      if (el.getAttribute("role") === "button") return true;
      var keywords = ["button", "btn", "clickable", "add", "create", "new"];
      for (var i = 0; i < keywords.length; i++) {
        if (el.classList.contains(keywords[i])) return true;
      }
      return (
        window.getComputedStyle(el).cursor === "pointer" ||
        !!el.querySelector('svg[data-icon="plus"], svg[data-icon="plus-circle"], .fa-plus, .icon-plus')
      );
    },

    findVisibleButton: function (candidates) {
      if (!candidates || candidates.length === 0) return null;
      var list = Array.isArray(candidates) ? candidates : Array.from(candidates);
      for (var i = 0; i < list.length; i++) {
        if (DomUtils.isElementVisible(list[i])) return list[i];
      }
      return list[0];
    },

    isSimilarText: function (a, b) {
      if (!a || !b) return false;
      var ta = a.toLowerCase();
      var tb = b.toLowerCase();
      var split = function (t) {
        return {
          chinese: t.replace(/[^一-龥]+/g, ""),
          english: t.replace(/[^a-zA-Z]+/g, "").replace(/\s+/g, ""),
        };
      };
      var pa = split(ta);
      var pb = split(tb);
      if (pa.chinese && pb.chinese && pa.chinese === pb.chinese) return true;

      if (ta.includes("|") || tb.includes("|")) {
        var partsA = ta.split("|").map(function (s) { return s.trim(); });
        var partsB = tb.split("|").map(function (s) { return s.trim(); });
        for (var i = 0; i < partsA.length; i++) {
          for (var j = 0; j < partsB.length; j++) {
            if (partsA[i] === partsB[j] && partsA[i]) return true;
          }
        }
      }

      var na = ta.replace(/\s+/g, "");
      var nb = tb.replace(/\s+/g, "");
      if (Math.abs(na.length - nb.length) > 30) return false;
      if (na.includes(nb) || nb.includes(na)) return true;

      var overlapRatio = function (x, y) {
        if (!x || !y) return 0;
        var setX = Array.from(new Set(x));
        return setX.filter(function (ch) { return y.includes(ch); }).length / Math.max(x.length, y.length);
      };
      var chineseScore = overlapRatio(pa.chinese, pb.chinese);
      var englishScore = overlapRatio(pa.english, pb.english);
      var chineseWeight = (pa.chinese.length + pb.chinese.length) / (na.length + nb.length + 0.1);
      return chineseScore * chineseWeight + englishScore * (1 - chineseWeight) > 0.5;
    },

    // 源码行1073-1160，逐行照搬 (向上找共同祖先、逐层扫子孙元素打分、评分>=3才收录，
    // 找不到再退化成"同 class 容器"里找同标签元素、评分>=2即可)。
    // 唯一差异: 末尾用 Set 去重返回，源码不去重——纯防御性改进，不影响筛选结果。
    findSimilarElements: function (el, maxDepth, options) {
      maxDepth = maxDepth === undefined ? 4 : maxDepth;
      options = options || {};
      if (!el) return [];
      var sameTag = options.sameTag === undefined || options.sameTag;
      var sameClass = options.sameClass === undefined || options.sameClass;
      var sameParent = options.sameParent !== undefined && options.sameParent;
      var results = [];
      try {
        var tag = el.tagName.toLowerCase();
        var classes = Array.from(el.classList);
        var score = function (candidate) {
          if (!candidate || candidate === el) return 0;
          var s = 0;
          if (candidate.tagName.toLowerCase() === tag) {
            s += 3;
          } else if (sameTag) {
            return 0;
          }
          var candClasses = Array.from(candidate.classList);
          if (candClasses.length > 0 && classes.length > 0) {
            var shared = classes.filter(function (c) { return candClasses.includes(c); });
            if (shared.length > 0) {
              s += (shared.length / Math.max(classes.length, candClasses.length)) * 2;
            } else if (sameClass) {
              return 0;
            }
          }
          var attrsEl = Array.from(el.attributes).map(function (a) { return a.name; });
          var attrsCand = Array.from(candidate.attributes).map(function (a) { return a.name; });
          s += attrsEl.filter(function (a) { return attrsCand.includes(a); }).length / Math.max(attrsEl.length, attrsCand.length);
          if (el.textContent && candidate.textContent && DomUtils.isSimilarText(el.textContent, candidate.textContent)) s += 1;
          if (el.placeholder && candidate.placeholder && DomUtils.isSimilarText(el.placeholder, candidate.placeholder)) s += 1;
          if (el.parentNode === candidate.parentNode) s += 2;
          return s;
        };
        var walk = function (node, depth) {
          if (!node || depth > maxDepth) return;
          if (node.children && node.children.length > 0) {
            for (var i = 0; i < node.children.length; i++) {
              var child = node.children[i];
              if (child !== el) {
                if (score(child) >= 3) results.push(child);
                if (child.children && child.children.length > 0) {
                  var descendants = Array.from(child.querySelectorAll("*"));
                  for (var j = 0; j < descendants.length; j++) {
                    if (score(descendants[j]) >= 3) results.push(descendants[j]);
                  }
                }
              }
            }
          }
          if (!sameParent && node.parentElement) walk(node.parentElement, depth + 1);
        };
        walk(el.parentElement, 0);

        if (results.length === 0) {
          var cur = el;
          for (var d = 0; d < 3 && (cur = cur.parentElement); d++) {
            if (cur.classList.contains("form-item") || cur.classList.contains("field-container") || cur.classList.contains("input-group")) {
              var siblings = Array.from(document.querySelectorAll("." + Array.from(cur.classList).join(".")));
              for (var k = 0; k < siblings.length; k++) {
                if (siblings[k] !== cur) {
                  var matches = Array.from(siblings[k].querySelectorAll(tag));
                  for (var m = 0; m < matches.length; m++) {
                    if (score(matches[m]) >= 2) results.push(matches[m]);
                  }
                }
              }
              break;
            }
          }
        }
        return Array.from(new Set(results));
      } catch (e) {
        return [];
      }
    },

    findSurroundingInputs: function (el, maxLevels) {
      maxLevels = maxLevels === undefined ? 3 : maxLevels;
      if (!el) return [];
      try {
        var cur = el.parentElement;
        var depth = 0;
        while (cur && depth < maxLevels) {
          var found = Array.from(cur.querySelectorAll("input, select, textarea")).filter(function (e) {
            return e !== el;
          });
          if (found.length > 0) return found;
          cur = cur.parentElement;
          depth++;
        }
        return [];
      } catch (e) {
        return [];
      }
    },

    // 找"是否有实习/工作经历"这类开关，源码行1206
    findExperienceToggle: function (container) {
      if (!container) return null;
      var visible = Array.from(container.querySelectorAll("*")).filter(function (e) {
        return DomUtils.isElementVisible(e);
      });
      var textOf = function (el) {
        var t = (el.textContent || "").trim();
        if (el.getAttribute("placeholder")) t += " " + el.getAttribute("placeholder");
        if (el.getAttribute("title")) t += " " + el.getAttribute("title");
        if (el.getAttribute("aria-label")) t += " " + el.getAttribute("aria-label");
        return t;
      };

      // 先找 radio 型开关
      var radios = Array.from(container.querySelectorAll('input[type="radio"]'));
      var ariaRadios = Array.from(container.querySelectorAll('[role="radio"]'));
      var radioGroups = visible.filter(function (e) {
        return (
          DomUtils.isRadioGroup(e) ||
          e.getAttribute("role") === "radiogroup" ||
          e.classList.contains("radio-group") ||
          e.classList.contains("phoenix-radio-group") ||
          e.querySelectorAll('input[type="radio"], [role="radio"]').length > 1
        );
      });
      var allRadioLike = [].concat(radios, ariaRadios);

      for (var i = 0; i < radioGroups.length; i++) {
        var group = radioGroups[i];
        var t = textOf(group).toLowerCase().trim();
        if ((t.includes("经验") || t.includes("经历")) && (t.includes("有") || t.includes("没有"))) {
          var options = Array.from(group.querySelectorAll('input[type="radio"], [role="radio"], .el-radio, .ant-radio-wrapper, .phoenix-radio'));
          var yesEl = null;
          var noEl = null;
          for (var j = 0; j < options.length; j++) {
            var opt = options[j];
            var ot = textOf(opt);
            if ((ot === "是" || ot.includes("有")) && !ot.includes("没有") && ot !== "否") {
              yesEl = opt;
            } else if (ot === "否" || ot.includes("没有") || ot.includes("无")) {
              noEl = opt;
            }
            if (yesEl && yesEl.tagName.toLowerCase() !== "input") {
              var innerInput = yesEl.querySelector('input[type="radio"]');
              if (innerInput) yesEl = innerInput;
            }
          }
          if (yesEl && noEl) {
            return { type: "radio", element: yesEl, parent: group };
          }
        }
      }

      for (var k = 0; k < allRadioLike.length; k++) {
        var el = allRadioLike[k];
        var own = textOf(el);
        var ctx = "";
        var p = el.parentElement;
        for (var lvl = 0; lvl < 3 && p; lvl++) {
          ctx += " " + textOf(p);
          p = p.parentElement;
        }
        var combined = (own + " " + ctx).toLowerCase();
        if (combined.includes("有") && !combined.includes("没有") && (combined.includes("经验") || combined.includes("经历"))) {
          return { type: "radio", element: el, parent: el.parentElement };
        }
      }

      // 再找 checkbox 型开关（"没有相关经历"这种反向勾选框）
      var checkboxCandidates = Array.from(container.querySelectorAll('input[type="checkbox"]'))
        .concat(Array.from(container.querySelectorAll('[role="checkbox"]')))
        .concat(Array.from(container.querySelectorAll('[class*="checkbox" i], .el-checkbox, .ant-checkbox-wrapper')));
      for (var c = 0; c < checkboxCandidates.length; c++) {
        var cb = checkboxCandidates[c];
        var cbOwn = textOf(cb);
        var cbCtx = "";
        var cp = cb.parentElement;
        for (var l2 = 0; l2 < 3 && cp; l2++) {
          cbCtx += " " + textOf(cp);
          cp = cp.parentElement;
        }
        var cbCombined = (cbOwn + " " + cbCtx).toLowerCase();
        if (cbCombined.includes("没有") && (cbCombined.includes("经验") || cbCombined.includes("经历"))) {
          var target = cb;
          if (cb.tagName.toLowerCase() !== "input") {
            var inner = cb.querySelector('input[type="checkbox"], [role="checkbox"]');
            if (inner) target = inner;
          }
          return { type: "checkbox", element: target, parent: cb };
        }
      }
      return null;
    },

    getEnterEvent: function () {
      return new KeyboardEvent("keydown", { key: "Enter", bubbles: true, cancelable: true, composed: true });
    },

    getBackspaceEvent: function () {
      return new KeyboardEvent("keydown", {
        key: "Backspace", code: "Backspace", keyCode: 8, charCode: 8, which: 8,
        bubbles: true, cancelable: true, composed: true,
      });
    },

    dispatchEvents: function (el, eventNames) {
      try {
        eventNames.forEach(function (name) {
          el.dispatchEvent(new MouseEvent(name, { bubbles: true, cancelable: true, view: window }));
        });
      } catch (e) {}
    },

    // Experience 所有新增入口的最终安全闸门。选择器即使命中，只要按钮属于
    // 页面级简历管理、上传、提交、投递、导航或删除动作，就绝不允许点击。
    isSafeExperienceAddAction: function (el, scope) {
      if (!el) return false;
      try {
        if (scope && scope !== document && scope.contains && !scope.contains(el)) return false;
        if (isForbiddenAutoClickAction(el)) return false;
        // 文件上传永远是用户手动动作。即使站点把上传按钮也做成“+ 添加”样式，
        // 经历引擎也不能把它当作新增卡片入口，更不能触发隐藏 file input。
        if (el.matches && el.matches('input[type="file"]')) return false;
        if (el.closest && el.closest(
          '[class*="upload" i], [class*="attachment" i], [data-upload], [data-testid*="upload" i]'
        )) return false;
        var uploadOwner = el.parentElement;
        if (uploadOwner && uploadOwner.querySelector && uploadOwner.querySelector('input[type="file"]')) return false;
        var text = String([
          el.textContent,
          el.getAttribute && el.getAttribute("aria-label"),
          el.getAttribute && el.getAttribute("title"),
          el.getAttribute && el.getAttribute("name"),
        ].filter(Boolean).join(" ")).replace(/\s+/g, "").toLowerCase();
        if (/简历|resume|上传|附件|提交|投递|申请|报名|志愿|职位|岗位|下一步|返回首页|删除|移除|upload|attachment|submit|apply|next|delete|remove/.test(text)) {
          return false;
        }
        var ownerModule = el.closest && el.closest(".resume-module, .module-container, .createResume-main-inner-box, [class*='resume-module'], [class*='module-container']");
        var ownerTitle = "";
        if (ownerModule) {
          var ownerTitleEl = ownerModule.querySelector(".resume-module-header .title, .module-title, .section-title, .createResume-main-inner-box-top .title, :scope > .title");
          ownerTitle = String(ownerTitleEl && ownerTitleEl.textContent || "").replace(/\s+/g, "").toLowerCase();
        }
        if (/意向志愿|求职志愿|志愿信息|投递职位|申请职位/.test(ownerTitle)) return false;
        var scopedModuleHeaderAdd = Boolean(
          scope && scope !== document &&
          /^(添加|新增|增加|继续添加)$/.test(text) &&
          el.closest && el.closest(".module-container") &&
          el.closest(".module-header-title-icon")
        );
        if (!scopedModuleHeaderAdd && el.closest && el.closest(
          "#autofill-panel-root, header, nav, [role='navigation'], [class*='header' i], [class*='navbar' i], [class*='sidebar' i]"
        )) return false;
        var classText = String(el.className || "").toLowerCase();
        var hasAddMeaning = /新增|添加|新建|增加|继续添加|add|new|create/.test(text) ||
          /(^|[-_\s])(add|new|create)([-_\s]|$)/.test(classText) ||
          Boolean(el.querySelector && el.querySelector(
            'svg[data-icon*="plus" i], svg[data-icon*="add" i], .anticon-plus, .el-icon-plus, i.fa-plus, i.icon-plus'
          ));
        return hasAddMeaning;
      } catch (e) {
        return false;
      }
    },

    // 安全点击: mousedown → mouseup → click，每步间隔10ms (源码行982)
    safeClickElement: async function (el) {
      if (!el) return false;
      try {
        if (isForbiddenAutoClickAction(el)) {
          if (AF.FillTrace) AF.FillTrace.event("forbidden_auto_click_blocked", String(el.textContent || "受保护控件").trim(), "skipped");
          return false;
        }
        var events = ["mousedown", "mouseup", "click"];
        for (var i = 0; i < events.length; i++) {
          el.dispatchEvent(new MouseEvent(events[i], { view: window, bubbles: true, cancelable: true, buttons: 1 }));
          await sleep(10);
        }
        return true;
      } catch (e) {
        return false;
      }
    },

    // 增强点击: focus→mousedown→click→mouseup，用于打开下拉/日期面板 (源码行27300)
    enhancedClick: async function (el) {
      try {
        DomUtils.dispatchEvents(el, ["focus", "mousedown", "click", "mouseup"]);
        await sleep(50);
      } catch (e) {}
    },
    isForbiddenAutoClickAction: isForbiddenAutoClickAction,

    sleep: sleep,

    // ============================================================
    // 智能下拉匹配引擎 (源码模块744 类k, 行2135-4283, 见文件头注释)
    // ============================================================

    // ---------- normalizeForMatch (源码行2529-2532) ----------
    normalizeForMatch: function (t) {
      return String(t || "").toLowerCase().replace(/[（()）\s\-_·.，,、/\\|]/g, "").replace(/大学英语/g, "英语");
    },

    // 学制在简历和站点选项中常混用“四年制 / 四年 / 4年制 / 4年 / 4 / 48个月”。
    // 只接受完整的学制表达，避免把“工作4年经验”等普通文本误当成学制。
    parseStudyYears: function (value) {
      var text = String(value == null ? "" : value)
        .replace(/[０-９]/g, function (char) { return String(char.charCodeAt(0) - 65296); })
        .replace(/\s+/g, "")
        .toLowerCase()
        .trim();
      if (!text || /日/.test(text)) return null;
      var cnMap = { 一: 1, 二: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9, 十: 10 };
      var prefix = "(?:学制|学习年限|修业年限|培养年限|就读年限)?[:：]?";
      var numeric = text.match(new RegExp("^" + prefix + "(\\d{1,2}(?:\\.5)?)(?:年|年制)?(?:学制)?$"));
      if (numeric) {
        var numericYears = Number(numeric[1]);
        return numericYears >= 0.5 && numericYears <= 10 ? numericYears : null;
      }
      var months = text.match(new RegExp("^" + prefix + "(\\d{1,3})(?:个)?月(?:制)?$"));
      if (months) {
        var monthYears = Number(months[1]) / 12;
        return monthYears >= 0.5 && monthYears <= 10 && monthYears * 2 === Math.round(monthYears * 2) ? monthYears : null;
      }
      var chineseHalf = text.match(new RegExp("^" + prefix + "([一二两三四五六七八九])年半(?:制)?$"));
      if (chineseHalf) return (cnMap[chineseHalf[1]] || 0) + 0.5;
      var chinese = text.match(new RegExp("^" + prefix + "([一二两三四五六七八九十])(?:年|年制)?(?:学制)?$"));
      if (chinese) return cnMap[chinese[1]] || null;
      var english = text.match(/^(\d{1,2}(?:\.5)?)(?:-?year|years?)$/);
      if (english) {
        var englishYears = Number(english[1]);
        return englishYears >= 0.5 && englishYears <= 10 ? englishYears : null;
      }
      return null;
    },

    // ---------- extractCetLevel / matchCetLevel (源码行2534-2551) ----------
    extractCetLevel: function (t) {
      var e = String(t || "").toLowerCase().replace(/[\s\-_]/g, "");
      // 先判六级，覆盖 CET-6、CET6、大学英语六级、英语六级证书等写法。
      if (/(?:cet(?:band)?|collegeenglishtest(?:band)?)?6级?|六级|英语六级|大学英语六级/.test(e)) return 6;
      if (/(?:cet(?:band)?|collegeenglishtest(?:band)?)?4级?|四级|英语四级|大学英语四级/.test(e)) return 4;
      return null;
    },
    matchCetLevel: function (e, r) {
      var n = DomUtils.extractCetLevel(e);
      var o = DomUtils.extractCetLevel(r);
      return n !== null && o !== null && n === o;
    },

    normalizeDegreeValue: function (value) {
      var text = String(value == null ? "" : value).trim();
      if (!text) return "";
      var compact = text.replace(/学位/g, "").replace(/[\s（）()\-_/]/g, "");
      if (/^(?:无|无学位|未取得|未获得|未获)/.test(compact)) return "无学位";
      if (/双学士/.test(compact)) return "双学士";
      if (/双硕士/.test(compact)) return "双硕士";
      if (/博士|博研|博士研究生/.test(compact)) return "博士";
      if (/硕士|硕研|研究生|mba|emba|dba|mem|mpa|mpacc/i.test(compact)) return "硕士";
      if (/学士|本科|大学/.test(compact)) return "学士";
      if (/专科|大专|专科学历/.test(compact)) return "大专";
      return text;
    },

    // 学位字段在不同招聘系统中的叫法和选项经常不同：
    // “学士学位/本科”、“硕士学位/硕士研究生”、“博士学位/博士研究生”应视为同一档。
    // 仅在明确的学位词之间归一化，避免把学历层次或专业名称误选成学位。
    matchDegree: function (optionText, targetValue) {
      var option = String(optionText || "").toLowerCase().replace(/[\s（）()\-_]/g, "");
      var target = String(targetValue || "").toLowerCase().replace(/[\s（）()\-_]/g, "");
      if (!option || !target) return false;
      var canonical = function (value) {
        var normalized = DomUtils.normalizeDegreeValue(value);
        if (normalized === "无学位") return "无";
        if (normalized === "双学士") return "双学士";
        if (normalized === "双硕士") return "双硕士";
        if (normalized === "博士") return "博士";
        if (normalized === "硕士") return "硕士";
        if (normalized === "学士") return "学士";
        if (normalized === "大专") return "大专";
        return "";
      };
      var optionKey = canonical(option);
      var targetKey = canonical(target);
      return Boolean(optionKey && targetKey && optionKey === targetKey);
    },

    // ---------- isSpecificEducationFormOption / matchEducationType (源码行2553-2604) ----------
    isSpecificEducationFormOption: function (t) {
      return /专升本|自学考试|成人高等教育|网络教育|开放教育|海外留学生|业余|函授|成教|在职/.test(t);
    },
    matchEducationType: function (e, r) {
      var n = String(e || "").toLowerCase().trim();
      var o = String(r || "").toLowerCase().trim();
      var i = /非全日制|非统招|在职|自考|成教|函授|业余|网络教育|开放教育|自学考试|成人|留学生/.test(o);
      if (!i && /全日制|统招|脱产|普通全日制/.test(o)) {
        return (
          !n.includes("非全日制") &&
          !DomUtils.isSpecificEducationFormOption(n) &&
          (!!/全国普通高等学校全日制|普通高等学校全日制/.test(n) ||
            !!/全日制/.test(n) ||
            !!/^(是|yes|y|有|true|1)$/.test(n) ||
            (!!/统招/.test(n) && !/非统招|专升本/.test(n)))
        );
      }
      if (i) {
        if (n.includes("非全日制")) return true;
        if (/自学考试|成人高等教育|网络教育|开放教育|业余|函授|成教|在职/.test(n)) return true;
        if (/非统招/.test(n)) return true;
        if (/^(否|no|n|无|false|0)$/.test(n)) return true;
        if (/^(是|yes|y|有|true|1)$/.test(n) && /非|在职|自考/.test(o)) return true;
      }
      return false;
    },

    // ---------- scoreEducationTypeOption (源码行2606-2630) ----------
    scoreEducationTypeOption: function (e, r) {
      if (!DomUtils.matchEducationType(e, r)) return -1;
      var n = String(e || "").toLowerCase().trim();
      var o = String(r || "").toLowerCase().trim();
      var i = 0;
      if (/全国普通高等学校全日制|普通高等学校全日制/.test(n)) i += 100;
      if (n.includes(o)) i += 50;
      if (o.includes("全日制") && n.includes("全日制")) i += 30;
      if (DomUtils.isSpecificEducationFormOption(n)) i -= 80;
      if (n.includes("非全日制")) i -= 100;
      return i;
    },

    // ---------- getAwardGradeKey / matchAwardGrade (源码行2632-2657) ----------
    getAwardGradeKey: function (t) {
      var e = String(t || "").toLowerCase().trim();
      var table = [
        [/国家级|全国级|^国家$|全国/, "national"],
        [/省级|全区级|^省$|省部级/, "provincial"],
        [/市级|地市级|^市$/, "city"],
        [/校级|学校级|院级|^校$/, "school"],
        [/特等奖|特等/, "special"],
        [/一等奖|一等|1等|金奖|金牌|冠军|第一名/, "first"],
        [/二等奖|二等|2等|银奖|银牌|亚军|第二名/, "second"],
        [/三等奖|三等|3等|铜奖|铜牌|季军|第三名/, "third"],
        [/优秀奖|优胜奖|优秀|优胜/, "excellent"],
      ];
      for (var i = 0; i < table.length; i++) {
        if (table[i][0].test(e)) return table[i][1];
      }
      return null;
    },
    matchAwardGrade: function (e, r) {
      var n = DomUtils.getAwardGradeKey(e);
      var o = DomUtils.getAwardGradeKey(r);
      if (n && o && n === o) return true;
      var i = DomUtils.normalizeForMatch(e);
      var a = DomUtils.normalizeForMatch(r);
      return !!i && !!a && (i === a || (i.length >= 2 && a.length >= 2 && (i.includes(a) || a.includes(i))));
    },

    // ---------- isGpaScaleRatio / extractGpaValue (源码行2658-2697) ----------
    isGpaScaleRatio: function (t, e) {
      var r = parseFloat(t);
      var n = parseFloat(e);
      return !Number.isNaN(r) && !Number.isNaN(n) && n > 0 && r >= 0 && n <= 5.5 && r <= n;
    },
    extractGpaValue: function (e) {
      var r = String(e || "").toLowerCase().trim();
      if (!r || /薪|月薪|年薪|k|千|万|w|元/.test(r)) return null;
      var isGpaLabeled = /gpa|绩点|绩分|平均成绩|平均分|grade\s*point|学分绩点/.test(r);
      var ratioMatch = r.match(/(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)/);
      if (ratioMatch && DomUtils.isGpaScaleRatio(ratioMatch[1], ratioMatch[2])) {
        return parseFloat(ratioMatch[1]);
      }
      var nums = DomUtils.extractNumbers(r).filter(function (n) {
        return n >= 0 && n <= 5.5;
      });
      if (nums.length === 0) return null;
      if (isGpaLabeled) {
        var le5 = nums.filter(function (n) {
          return n <= 5;
        });
        return le5.length > 0 ? Math.max.apply(Math, le5) : null;
      }
      if (/^\d\.\d+$/.test(r.replace(/\s/g, "")) || (nums.length === 1 && nums[0] <= 5)) {
        return nums[0];
      }
      return null;
    },

    // ---------- classifyRangeType / parseOptionRange (源码行2699-2794) ----------
    classifyRangeType: function (t, e, r) {
      var n = String(r || "").toLowerCase();
      if (/薪|月薪|年薪|k|千|万|w|元/.test(n)) return "numeric";
      var isGpaLabeled = /gpa|绩点|绩分|平均成绩|平均分|grade\s*point|学分绩点/.test(n);
      var upperBound = Number.isFinite(e) ? e : t;
      var looksLikeGpa = t >= 0 && t <= 5.5 && upperBound <= 5.5 && /\d\.\d/.test(n);
      return isGpaLabeled || looksLikeGpa ? "gpa" : "numeric";
    },
    parseOptionRange: function (e) {
      var r = normalizeNumericPunctuation(e).toLowerCase().trim();
      if (!r) return null;
      var toNumber = function (raw, ctx) {
        var v = parseFloat(raw);
        if (Number.isNaN(v)) return null;
        if (/k|千/.test(ctx) && v < 1000) return v * 1000;
        if (/万|w/.test(ctx) && v < 1000) return v * 10000;
        return v;
      };
      var rangeMatch = r.match(/(\d+(?:\.\d+)?)\s*(?:k|千|万|w)?\s*[~\-–—至到]\s*(\d+(?:\.\d+)?)\s*(?:k|千|万|w)?/);
      if (rangeMatch) {
        var v1 = toNumber(rangeMatch[1], r);
        var v2 = toNumber(rangeMatch[2], r);
        if (v1 !== null && v2 !== null) {
          var min = Math.min(v1, v2);
          var max = Math.max(v1, v2);
          return { min: min, max: max, type: DomUtils.classifyRangeType(min, max, r) };
        }
      }
      var belowMatch = r.match(/(\d+(?:\.\d+)?)\s*(?:k|千|万|w)?\s*(?:以下|以内|不超过|低于|小于)|(?:以下|低于|小于)\s*(\d+(?:\.\d+)?)\s*(?:k|千|万|w)?/);
      if (belowMatch) {
        var belowVal = toNumber(belowMatch[1] || belowMatch[2], r);
        if (belowVal !== null) return { min: 0, max: belowVal, type: DomUtils.classifyRangeType(0, belowVal, r) };
      }
      var aboveMatch = r.match(/(\d+(?:\.\d+)?)\s*(?:k|千|万|w)?\s*(?:以上|不低于|高于|大于|及以上)|(?:以上|高于|大于)\s*(\d+(?:\.\d+)?)\s*(?:k|千|万|w)?/);
      if (aboveMatch) {
        var aboveVal = toNumber(aboveMatch[1] || aboveMatch[2], r);
        if (aboveVal !== null) return { min: aboveVal, max: Infinity, type: DomUtils.classifyRangeType(aboveVal, aboveVal, r) };
      }
      var topPercentMatch = r.match(/前\s*(\d+(?:\.\d+)?)\s*%|top\s*(\d+(?:\.\d+)?)\s*%|排名前\s*(\d+(?:\.\d+)?)\s*%/);
      if (topPercentMatch) {
        var topVal = parseFloat(topPercentMatch[1] || topPercentMatch[2] || topPercentMatch[3]);
        if (!Number.isNaN(topVal)) return { min: 0, max: topVal, type: "topPercent" };
      }
      var percentRangeMatch = r.match(/(\d+(?:\.\d+)?)\s*%?\s*[~\-–—至到]\s*(\d+(?:\.\d+)?)\s*%/);
      if (percentRangeMatch) {
        var p1 = parseFloat(percentRangeMatch[1]);
        var p2 = parseFloat(percentRangeMatch[2]);
        if (!Number.isNaN(p1) && !Number.isNaN(p2)) return { min: Math.min(p1, p2), max: Math.max(p1, p2), type: "percent" };
      }
      return null;
    },

    // ---------- extractComparableValue (源码行2795-2875) ----------
    extractComparableValue: function (e) {
      var r = normalizeNumericPunctuation(e).toLowerCase().trim();
      if (!r) return null;
      var gpaVal = DomUtils.extractGpaValue(e);
      if (gpaVal !== null) return { value: gpaVal, type: "gpa" };
      var ratioMatch = r.match(/(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)/);
      if (ratioMatch) {
        var num = parseFloat(ratioMatch[1]);
        var den = parseFloat(ratioMatch[2]);
        if (den > 0 && !DomUtils.isGpaScaleRatio(num, den)) {
          return { value: (num / den) * 100, type: "topPercent" };
        }
      }
      var topPercentMatch = r.match(/前\s*(\d+(?:\.\d+)?)\s*%|top\s*(\d+(?:\.\d+)?)\s*%|排名前\s*(\d+(?:\.\d+)?)\s*%/);
      if (topPercentMatch) {
        var topVal = parseFloat(topPercentMatch[1] || topPercentMatch[2] || topPercentMatch[3]);
        if (!Number.isNaN(topVal)) return { value: topVal, type: "topPercent" };
      }
      var wanMatch = r.match(/(\d+(?:\.\d+)?)\s*(?:万|w)/);
      if (wanMatch) {
        var wanVal = parseFloat(wanMatch[1]) * 10000;
        var wanRangeMatch = r.match(/(\d+(?:\.\d+)?)\s*(?:万|w)?\s*[~\-–—至到]\s*(\d+(?:\.\d+)?)\s*(?:万|w)/);
        if (wanRangeMatch) wanVal = ((parseFloat(wanRangeMatch[1]) + parseFloat(wanRangeMatch[2])) / 2) * 10000;
        return { value: wanVal, type: "numeric" };
      }
      var kMatch = r.match(/(\d+(?:\.\d+)?)\s*k/);
      if (kMatch) {
        var kVal = parseFloat(kMatch[1]) * 1000;
        var kRangeMatch = r.match(/(\d+(?:\.\d+)?)\s*k?\s*[~\-–—至到]\s*(\d+(?:\.\d+)?)\s*k/);
        if (kRangeMatch) kVal = ((parseFloat(kRangeMatch[1]) + parseFloat(kRangeMatch[2])) / 2) * 1000;
        return { value: kVal, type: "numeric" };
      }
      var percentMatch = r.match(/(\d+(?:\.\d+)?)\s*%/);
      if (percentMatch && !/k|千|万|w/.test(r)) {
        return { value: parseFloat(percentMatch[1]), type: "percent" };
      }
      var nums = DomUtils.extractNumbers(r);
      if (nums.length === 0) return null;
      if (nums.length >= 2 && /[~\-–—至到]/.test(r)) return { value: (nums[0] + nums[1]) / 2, type: "numeric" };
      return { value: nums[0], type: "numeric" };
    },

    // ---------- valueInOptionRange / findBestRangeMatch (源码行2876-2912) ----------
    valueInOptionRange: function (e, r) {
      var optionRange = DomUtils.parseOptionRange(e);
      var comparable = DomUtils.extractComparableValue(r);
      if (!optionRange || !comparable) return false;
      var valueLooksGpaLike = comparable.type === "gpa" || (comparable.type === "numeric" && comparable.value <= 5.5);
      var optionIsGpa = optionRange.type === "gpa";
      if (optionIsGpa && valueLooksGpaLike) {
        return comparable.value >= optionRange.min && comparable.value <= optionRange.max;
      }
      if (optionIsGpa || comparable.type === "gpa") return false;
      if (optionRange.type === "numeric" && comparable.type === "numeric") {
        return comparable.value >= optionRange.min && comparable.value <= optionRange.max;
      }
      if (optionRange.type === "topPercent") {
        if (comparable.type === "topPercent" || comparable.type === "percent") {
          return comparable.value <= optionRange.max;
        }
        return false;
      }
      if (optionRange.type === "percent" && (comparable.type === "percent" || comparable.type === "topPercent")) {
        return comparable.value >= optionRange.min && comparable.value <= optionRange.max;
      }
      return false;
    },
    findBestRangeMatch: function (options, targetValue) {
      if (!Array.isArray(options) || !targetValue) return null;
      var matched = options.filter(function (opt) {
        return DomUtils.valueInOptionRange(opt.text, targetValue);
      });
      if (matched.length === 0) return null;
      if (matched.length === 1) return matched[0];
      return matched.sort(function (a, b) {
        var ra = DomUtils.parseOptionRange(a.text);
        var rb = DomUtils.parseOptionRange(b.text);
        return (ra ? ra.max - ra.min : Infinity) - (rb ? rb.max - rb.min : Infinity);
      })[0];
    },

    // ---------- isOptionMatch 完整版 (源码行2913-2944, 逐行照搬)。
    // select-adapter/base.js 的 isOptionMatch 已改为直接调用这里，不再自己维护简化版。----------
    isOptionMatch: function (optionText, optionCode, targetValue) {
      try {
        if (!optionText || targetValue === undefined || targetValue === null || targetValue === "") return false;
        var canonical = function (value) {
          return String(value == null ? "" : value).toLowerCase().trim().replace(/其它/g, "其他");
        };
        var o = canonical(optionText);
        var i = canonical(optionCode);
        var a = canonical(targetValue);
        var educationLevel = function (value) {
          var text = String(value || "").toLowerCase().replace(/[\s（）()\-_/]/g, "");
          if (/博士|博研|博士研究生/.test(text)) return "博士";
          if (/硕士|硕研|硕士研究生/.test(text)) return "硕士";
          if (/本科|大学本科|本科生|学士/.test(text)) return "本科";
          if (/大专|专科|大学专科/.test(text)) return "大专";
          if (/中专|中技|技校|职高|职业高中/.test(text)) return "中专";
          if (/高中/.test(text)) return "高中";
          if (/初中|初中及以下/.test(text)) return "初中及以下";
          return "";
        };
        var targetEducationLevel = educationLevel(a);
        var optionEducationLevel = educationLevel(o) || educationLevel(i);
        if (targetEducationLevel) return targetEducationLevel === optionEducationLevel;
        var targetStudyYears = DomUtils.parseStudyYears(a);
        if (targetStudyYears !== null) {
          return DomUtils.parseStudyYears(o) === targetStudyYears || DomUtils.parseStudyYears(i) === targetStudyYears;
        }
        if (["本科", "硕士", "博士", "大专", "高中", "中专", "专科", "研究生"].includes(a)) {
          return (
            o === a ||
            (a === "硕士" && (o.includes("硕士") || o === "研究生")) ||
            (a === "博士" && o.includes("博士")) ||
            ((a === "大专" || a === "专科") && (o.includes("大专") || o.includes("专科"))) ||
            (a === "本科" && (o === "本科" || o.includes("学士") || o.includes("全日制") || o.includes("统招"))) ||
            (/\d+/.test(o) && o.includes(a)) ||
            o.includes(a) ||
            a.includes(o)
          );
        }
        if (DomUtils.matchCetLevel(o, a) || DomUtils.matchCetLevel(i, a)) return true;
        if (DomUtils.matchDegree(o, a) || DomUtils.matchDegree(i, a)) return true;
        if (DomUtils.matchEducationType(o, a) || DomUtils.matchEducationType(i, a)) return true;
        if (DomUtils.matchAwardGrade(o, a) || DomUtils.matchAwardGrade(i, a)) return true;
        if (DomUtils.valueInOptionRange(o, a) || DomUtils.valueInOptionRange(i, a)) return true;
        var c = DomUtils.normalizeForMatch(o);
        var u = DomUtils.normalizeForMatch(i);
        var l = DomUtils.normalizeForMatch(a);
        return (
          (!!c && !!l && (c === l || c.includes(l) || l.includes(c))) ||
          (!!u && !!l && (u === l || u.includes(l) || l.includes(u))) ||
          o === a ||
          o.includes(a) ||
          a.includes(o) ||
          i === a ||
          i.includes(a) ||
          a.includes(i)
        );
      } catch (e) {
        return false;
      }
    },

    // ---------- Jaro / Jaro-Winkler / 字符频率 / 最长公共子序列 相似度 (源码行3719-3863) ----------
    jaroSimilarity: function (t, e) {
      var r = t.length;
      var n = e.length;
      if (r === 0 && n === 0) return 1;
      if (r === 0 || n === 0) return 0;
      var matchWindow = Math.floor(Math.max(r, n) / 2) - 1;
      if (matchWindow < 0) return 0;
      var tMatches = new Array(r).fill(false);
      var eMatches = new Array(n).fill(false);
      var matches = 0;
      for (var i = 0; i < r; i++) {
        var start = Math.max(0, i - matchWindow);
        var end = Math.min(i + matchWindow + 1, n);
        for (var j = start; j < end; j++) {
          if (!eMatches[j] && t[i] === e[j]) {
            tMatches[i] = eMatches[j] = true;
            matches++;
            break;
          }
        }
      }
      if (matches === 0) return 0;
      var transpositions = 0;
      var k = 0;
      for (var idx = 0; idx < r; idx++) {
        if (tMatches[idx]) {
          while (!eMatches[k]) k++;
          if (t[idx] !== e[k]) transpositions++;
          k++;
        }
      }
      return (matches / r + matches / n + (matches - transpositions / 2) / matches) / 3;
    },
    jaroWinklerSimilarity: function (t, e) {
      var jaro = DomUtils.jaroSimilarity(t, e);
      if (jaro < 0.7) return jaro;
      var prefixLen = 0;
      for (var i = 0; i < Math.min(t.length, e.length, 4) && t[i] === e[i]; i++) prefixLen++;
      return jaro + prefixLen * 0.1 * (1 - jaro);
    },
    characterFrequencySimilarity: function (t, e) {
      var freqT = {};
      var freqE = {};
      for (var i = 0; i < t.length; i++) freqT[t[i]] = (freqT[t[i]] || 0) + 1;
      for (var j = 0; j < e.length; j++) freqE[e[j]] = (freqE[e[j]] || 0) + 1;
      var dot = 0;
      var normT = 0;
      var normE = 0;
      var allChars = new Set(Object.keys(freqT).concat(Object.keys(freqE)));
      allChars.forEach(function (ch) {
        var a = freqT[ch] || 0;
        var b = freqE[ch] || 0;
        dot += a * b;
        normT += a * a;
        normE += b * b;
      });
      return dot / (Math.sqrt(normT) * Math.sqrt(normE));
    },
    longestCommonSubsequence: function (t, e) {
      var r = t.length;
      var n = e.length;
      var dp = Array(r + 1)
        .fill()
        .map(function () {
          return Array(n + 1).fill(0);
        });
      for (var i = 1; i <= r; i++) {
        for (var j = 1; j <= n; j++) {
          dp[i][j] = t[i - 1] === e[j - 1] ? dp[i - 1][j - 1] + 1 : Math.max(dp[i - 1][j], dp[i][j - 1]);
        }
      }
      return dp[r][n];
    },

    // ---------- calculateSimilarity (源码行3719-3737): 完全相等/互相包含短路，否则综合打分 ----------
    calculateSimilarity: function (t, e) {
      if (!t || !e) return 0;
      var a = String(t).toLowerCase().trim();
      var b = String(e).toLowerCase().trim();
      if (a === b) return 1;
      if (a.length === 0 || b.length === 0) return 0;
      if (a.includes(b) || b.includes(a)) {
        var longer = a.length > b.length ? a : b;
        var shorter = a.length <= b.length ? a : b;
        return (shorter.length / longer.length) * 0.9;
      }
      return (
        DomUtils.jaroWinklerSimilarity(a, b) * 0.5 +
        DomUtils.characterFrequencySimilarity(a, b) * 0.3 +
        ((DomUtils.longestCommonSubsequence(a, b) * 2) / (a.length + b.length)) * 0.2
      );
    },

    // ---------- extractNumbers / matchByNumbers (源码行4016-4058) ----------
    extractNumbers: function (t) {
      if (!t || typeof t !== "string") return [];
      t = normalizeNumericPunctuation(t);
      var m = t.match(/\d+(\.\d+)?/g);
      return m ? m.map(Number) : [];
    },
    matchByNumbers: function (target, options, opts) {
      opts = opts || {};
      try {
        var exact = !!opts.exact;
        var allowMultiple = opts.allowMultiple === undefined || opts.allowMultiple;
        if (!target || !options || !Array.isArray(options)) return null;
        var targetNums = DomUtils.extractNumbers(target);
        if (!targetNums.length) return null;
        var found = options.find(function (opt) {
          var optNums = DomUtils.extractNumbers(opt);
          if (!optNums.length) return false;
          if (!allowMultiple) return targetNums[0] === optNums[0];
          if (exact) {
            return (
              targetNums.length === optNums.length &&
              targetNums.every(function (n, i) {
                return n === optNums[i];
              })
            );
          }
          return targetNums.some(function (n) {
            return optNums.some(function (m) {
              return n === m;
            });
          });
        });
        return found || null;
      } catch (e) {
        return null;
      }
    },

    // ---------- determineScoreTrend (源码行4059-4156): 判断一组选项文案是"升序"还是"降序"
    // (用于语言能力"入门→精通"这类等级选项，帮助 performIntelligentScoring 按位置换算) ----------
    determineScoreTrend: function (items) {
      try {
        if (!Array.isArray(items) || items.length < 2) return "mixed";
        var levelTable = {
          母语: 10, 本族语: 10, 精通: 9, 流利: 9, 优秀: 9, 卓越: 9,
          无障碍沟通: 8, 专业: 8, 熟练: 8, 很好: 8,
          商务会话: 7, 商务: 7, 工作交流: 7, 良好: 7,
          日常会话: 6, 日常: 6, 交流: 6, 中等: 6,
          基础: 5, 基本: 5, 简单: 5, 一般: 5,
          入门: 4, 初级: 4, 新手: 4, 较差: 4,
          初学: 3, 初步: 3, 差: 3,
          优: 9, 良: 7, 中: 5,
          a: 9, b: 7, c: 5, d: 3,
          掌握: 7, 了解: 5, 略懂: 4,
        };
        var scores = [];
        for (var i = 0; i < items.length; i++) {
          var text = String(items[i].text || items[i].value || "").trim();
          var lower = text.toLowerCase();
          var matched = null;
          var entries = Object.keys(levelTable);
          for (var j = 0; j < entries.length; j++) {
            if (lower.includes(entries[j].toLowerCase())) {
              matched = levelTable[entries[j]];
              break;
            }
          }
          if (matched !== null) {
            scores.push(matched);
          } else {
            var nums = DomUtils.extractNumbers(text);
            scores.push(nums.length > 0 ? nums[0] : text.length);
          }
        }
        if (scores.length < 2) return "mixed";
        var delta = scores[scores.length - 1] - scores[0];
        var ascCount = 0;
        var descCount = 0;
        for (var k = 1; k < scores.length; k++) {
          if (scores[k] > scores[k - 1]) ascCount++;
          else if (scores[k] < scores[k - 1]) descCount++;
        }
        var steps = scores.length - 1;
        var ascRatio = ascCount / steps;
        var descRatio = descCount / steps;
        if (delta > 0 && ascRatio >= 0.5) return "ascending";
        if (delta < 0 && descRatio >= 0.5) return "descending";
        if (ascRatio >= 0.6) return "ascending";
        if (descRatio >= 0.6) return "descending";
        return delta >= 0 ? "ascending" : "descending";
      } catch (e) {
        return "mixed";
      }
    },

    // ---------- normalizeOptions / findBestSimilarityMatch / performIntelligentScoring /
    // intelligentOptionMatch (源码行4157-4283): 找不到规则匹配时的智能兜底 ----------
    normalizeOptions: function (options) {
      return options.map(function (opt, i) {
        var text = String(opt.text || opt.value || "").trim();
        var val = String(opt.value || opt.text || "").trim();
        return {
          originalOption: opt,
          normalizedText: text.toLowerCase(),
          normalizedValue: val.toLowerCase(),
          originalText: text,
          originalValue: val,
          index: i,
        };
      });
    },
    findBestSimilarityMatch: function (normalized, target) {
      if (!Array.isArray(normalized) || normalized.length === 0 || !target) return null;
      var best = null;
      var bestScore = 0;
      for (var i = 0; i < normalized.length; i++) {
        var score = DomUtils.calculateSimilarity(normalized[i].normalizedText, target);
        if (score > bestScore) {
          bestScore = score;
          best = normalized[i].originalOption;
        }
      }
      if (bestScore === 0 && normalized.length > 0) return normalized[0].originalOption;
      if (bestScore > 0.1) return best;
      if (normalized.length > 0) return normalized[0].originalOption;
      return null;
    },
    performIntelligentScoring: function (allOptions, candidateSubset, target) {
      try {
        var bestInSubset = DomUtils.findBestSimilarityMatch(candidateSubset, target);
        if (!bestInSubset) return DomUtils.findBestSimilarityMatch(allOptions, target);
        var subsetIdx = candidateSubset.findIndex(function (o) {
          return o.originalOption === bestInSubset;
        });
        if (subsetIdx === -1) return DomUtils.findBestSimilarityMatch(allOptions, target);
        var subsetTrend = DomUtils.determineScoreTrend(
          candidateSubset.map(function (o) {
            return o.originalOption;
          })
        );
        var allTrend = DomUtils.determineScoreTrend(
          allOptions.map(function (o) {
            return o.originalOption;
          })
        );
        var mappedIdx;
        var subsetRatio = subsetIdx / (candidateSubset.length - 1);
        if (subsetTrend === allTrend && subsetTrend !== "mixed") {
          mappedIdx = Math.round(subsetRatio * (allOptions.length - 1));
        } else if (subsetTrend === "ascending" && allTrend === "descending") {
          mappedIdx = Math.round((1 - subsetRatio) * (allOptions.length - 1));
        } else if (subsetTrend === "descending" && allTrend === "ascending") {
          mappedIdx = Math.round((1 - subsetRatio) * (allOptions.length - 1));
        } else {
          mappedIdx = Math.round(subsetRatio * (allOptions.length - 1));
        }
        mappedIdx = Math.max(0, Math.min(mappedIdx, allOptions.length - 1));
        var mapped = allOptions[mappedIdx];
        return mapped ? mapped.originalOption : null;
      } catch (e) {
        return DomUtils.findBestSimilarityMatch(candidateSubset, target);
      }
    },
    // 总入口: allOptions=页面全部选项, candidateSubset=预筛选后的候选子集(通常等于全部)，
    // target=resume值。规则匹配都失败时，按"选项等级排序趋势"把子集内命中位置换算回
    // 全量选项的位置，兜底选出"看起来最合理"的一个。
    intelligentOptionMatch: function (allOptions, candidateSubset, target) {
      try {
        if (!Array.isArray(allOptions) || !Array.isArray(candidateSubset) || !target) return null;
        if (allOptions.length === 0) return null;
        var normalizedAll = DomUtils.normalizeOptions(allOptions);
        var normalizedSubset = DomUtils.normalizeOptions(candidateSubset);
        var targetLower = String(target).toLowerCase().trim();
        return DomUtils.performIntelligentScoring(normalizedAll, normalizedSubset, targetLower);
      } catch (e) {
        return null;
      }
    },
  };

  // ============ LabelUtils (源码 Rt.T 类, 行4340-4470) ============
  var LabelUtils = {
    // 提取标签文字: 删除 * : ： 必填 选填 空格 (不删 ?)，源码行4354
    getLabelText: function (el) {
      if (!el) return "";
      try {
        var graphLabel = el.getAttribute && el.getAttribute("data-af-graph-row-label");
        if (graphLabel) return String(graphLabel).replace(/[*:：]|必填|选填|\s+/g, "").trim().toLowerCase();
      } catch (_) {}
      var text = "";
      try {
        var source = el;
        if (el.cloneNode) {
          source = el.cloneNode(true);
          Array.from(source.querySelectorAll(".blue, .required, .labelRequired, .explain-text, .error-text, .error-msg, .ant-form-explain, [aria-hidden='true']")).forEach(function (node) {
            node.remove();
          });
          Array.from(source.querySelectorAll("[style]")).forEach(function (node) {
            var style = String(node.getAttribute("style") || "").replace(/\s+/g, "").toLowerCase();
            if (style.indexOf("display:none") !== -1 || style.indexOf("visibility:hidden") !== -1) {
              node.remove();
            }
          });
        }
        text = source.textContent || source.innerText || "";
      } catch (e) {
        text = el.textContent || el.innerText || "";
      }
      if (!text) return "";
      return text.replace(/[*:：]|必填|选填|\s+/g, "").trim().toLowerCase();
    },

    isSimilarLabel: function (a, b) {
      var classesA = Array.from(a.classList);
      var classesB = Array.from(b.classList);
      if (classesA.some(function (c) { return classesB.includes(c); })) return true;

      var stripTrailingDigits = function (s) { return s.replace(/\d+$/, ""); };
      var leadingDigitSuffix = function (s) {
        var m = s.match(/^\d+(.+)$/);
        return m ? m[1] : "";
      };

      var sameSuffix = classesA.some(function (ca) {
        var na = stripTrailingDigits(ca);
        return classesB.some(function (cb) { return na === stripTrailingDigits(cb) && na.length > 3; });
      });
      var samePrefix = classesA.some(function (ca) {
        var na = leadingDigitSuffix(ca);
        return classesB.some(function (cb) { return na === leadingDigitSuffix(cb) && na.length > 3; });
      });
      var hasCommonSubstring = classesA.some(function (ca) {
        return classesB.some(function (cb) {
          return (function (x, y, n) {
            n = n || 4;
            if (x.length < n || y.length < n) return false;
            for (var i = 0; i <= x.length - n; i++) {
              if (y.includes(x.substring(i, i + n))) return true;
            }
            return false;
          })(ca, cb);
        });
      });

      var requiredKeywords = ["required", "must", "必填", "mandatory"];
      var aRequired = classesA.some(function (c) { return requiredKeywords.some(function (k) { return c.toLowerCase().includes(k); }); });
      var bRequired = classesB.some(function (c) { return requiredKeywords.some(function (k) { return c.toLowerCase().includes(k); }); });

      return (aRequired && bRequired) || ((sameSuffix || samePrefix || hasCommonSubstring) && aRequired === bRequired);
    },

    hasMultipleSimilarLabels: function (labels, target) {
      if (labels.length <= 1) return false;
      if (target) {
        var count = 0;
        for (var i = 0; i < labels.length; i++) {
          if (labels[i] !== target && LabelUtils.isSimilarLabel(labels[i], target) && ++count >= 1) return true;
        }
        return false;
      }
      for (var a = 0; a < labels.length; a++) {
        for (var b = a + 1; b < labels.length; b++) {
          if (LabelUtils.isSimilarLabel(labels[a], labels[b])) return true;
        }
      }
      return false;
    },

    findUnlabeledInputs: function () {
      var withPlaceholder = document.querySelectorAll("input[placeholder], select[placeholder], textarea[placeholder]");
      return Array.from(withPlaceholder).filter(function (el) {
        return !el.id || !document.querySelector('label[for="' + el.id + '"]');
      });
    },

    isPhoneOrIdCardLabel: function (text) {
      if (/证件签发|证件类型|证件类别/.test(String(text || ""))) return false;
      return ["电话", "手机", "号码", "证件号码", "身份证", "身份证号", "证件"].some(function (k) {
        return text.includes(k);
      });
    },

    isDateRelatedLabel: function (text) {
      return (
        text.includes("时间") || text.includes("日期") || text.includes("日期时间") ||
        text.includes("生日") || text.includes("出生日期") || text.includes("出生年月") || text.includes("年月")
      );
    },
  };

  // ============ 通用工具函数 ============

  // 双向 includes 字段匹配 (源码行10358-10386)
  function findFieldKeyByMapping(labelText, mapping) {
    var normalized = String(labelText).toLowerCase().trim();
    // 先做全局完全相等匹配，避免 duration 中的“时间”抢先吃掉
    // “开始时间/结束时间”这类更具体的字段。
    for (var key in mapping) {
      if (!Object.prototype.hasOwnProperty.call(mapping, key)) continue;
      var aliases = mapping[key];
      if (Array.isArray(aliases)) {
        var exactHit = aliases.some(function (alias) {
          var a = String(alias).toLowerCase().trim();
          return a !== "" && a === normalized;
        });
        if (exactHit) return key;
      } else if (typeof aliases === "string") {
        var single = aliases.toLowerCase().trim();
        if (single !== "" && single === normalized) return key;
      }
    }

    // 完全匹配失败后再做包含匹配，并选最长别名，越具体的规则优先。
    var best = null;
    for (var fuzzyKey in mapping) {
      if (!Object.prototype.hasOwnProperty.call(mapping, fuzzyKey)) continue;
      var fuzzyAliases = Array.isArray(mapping[fuzzyKey]) ? mapping[fuzzyKey] : [mapping[fuzzyKey]];
      fuzzyAliases.forEach(function (alias) {
        var a = String(alias == null ? "" : alias).toLowerCase().trim();
        if (!a || (!normalized.includes(a) && !a.includes(normalized))) return;
        var score = Math.min(a.length, normalized.length);
        if (normalized.indexOf(a) === 0) score += 1000;
        if (!best || score > best.score) best = { key: fuzzyKey, score: score };
      });
    }
    return best ? best.key : null;
  }

  // 等待元素出现且可见 (源码行69334, 泛化为传入查找函数)
  function waitForElement(findFn, timeoutMs) {
    timeoutMs = timeoutMs === undefined ? 5000 : timeoutMs;
    var start = Date.now();
    return new Promise(function (resolve) {
      (function poll() {
        var el;
        try {
          el = findFn();
        } catch (e) {
          el = null;
        }
        if (el && DomUtils.isElementVisible(el)) {
          resolve(el);
          return;
        }
        if (Date.now() - start >= timeoutMs) {
          resolve(null);
          return;
        }
        setTimeout(poll, 100);
      })();
    });
  }

  // 所有自动化点击的最终导航保险丝。招聘网页自己的人工点击 event.isTrusted=true，
  // 不受影响；插件通过 click()/dispatchEvent 产生的点击为 false。即使旧站点配置
  // 或某条旧填写路径把“添加志愿”认成经历新增，也在网页路由处理前直接阻断。
  function installAutomatedNavigationClickGuard() {
    if (window.__AF_AUTOMATED_NAVIGATION_GUARD_INSTALLED__) return;
    window.__AF_AUTOMATED_NAVIGATION_GUARD_INSTALLED__ = true;
    var riskyActionPattern = /添加志愿|新增志愿|增加志愿|修改志愿|选择志愿|投递职位|申请职位|职位详情|岗位详情/;
    var riskyModulePattern = /我的意向志愿|意向志愿|求职志愿|志愿信息|投递职位|申请职位/;

    function blockRiskyAutomatedAction(event) {
      if (!event || event.isTrusted !== false) return;
      var target = event.target;
      if (!target || !target.closest) return;
      var action = target.closest("button, a, [role='button'], [onclick], .custom-button, [class*='button'], [class*='btn']") || target;
      var actionText = String([
        action.textContent,
        action.getAttribute && action.getAttribute("aria-label"),
        action.getAttribute && action.getAttribute("title"),
      ].filter(Boolean).join(" ")).replace(/\s+/g, "");
      var owner = action.closest && action.closest(".resume-module, .module-container, [class*='resume-module'], [class*='module-container']");
      var titleEl = owner && owner.querySelector(".resume-module-header .title, .module-title, .section-title, :scope > .title");
      var ownerTitle = String(titleEl && titleEl.textContent || "").replace(/\s+/g, "");
      if (!riskyActionPattern.test(actionText) && !riskyModulePattern.test(ownerTitle)) return;

      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
      try {
        if (AF.FillTrace) AF.FillTrace.event("navigation_action_blocked", ownerTitle + " / " + actionText, "skipped");
        document.dispatchEvent(new CustomEvent("af:autofill-navigation-blocked", {
          detail: { moduleTitle: ownerTitle, actionText: actionText, eventType: event.type },
        }));
      } catch (e) {}
    }

    ["mousedown", "mouseup", "click"].forEach(function (eventName) {
      document.addEventListener(eventName, blockRiskyAutomatedAction, true);
    });
  }

  installAutomatedNavigationClickGuard();

  AF.SELECTORS = SELECTORS;
  AF.DomUtils = DomUtils;
  AF.LabelUtils = LabelUtils;
  AF.Utils = {
    findFieldKeyByMapping: findFieldKeyByMapping,
    waitForElement: waitForElement,
    sleep: sleep,
  };
})();
