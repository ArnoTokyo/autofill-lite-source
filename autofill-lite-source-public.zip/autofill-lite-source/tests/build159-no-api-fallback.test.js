"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { buildLocalSemanticFallbackPatch } = require("../ai-local-fallback");
const root = path.join(__dirname, "..");

const review = {
  profileContract: { categories: { basicInfo: ["researchDirection", "name"] } },
  reviewFields: [
    { fieldId: "a", coreCategory: "basicInfo", suggestedCoreFieldKey: "researchDirection", suggestedCoreMappingConfidence: 0.72, reviewReasons: ["local hint"] },
    { fieldId: "b", coreCategory: "basicInfo", suggestedCoreFieldKey: "notInContract", suggestedCoreMappingConfidence: 0.99 }
  ]
};
const patch = buildLocalSemanticFallbackPatch(review, { minCandidateConfidence: 0.50 });
assert.strictEqual(patch.decisions[0].decision, "map");
assert.strictEqual(patch.decisions[0].fieldKey, "researchDirection");
assert.strictEqual(patch.decisions[1].decision, "leave_unmapped");

const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
assert(main.includes('provider = "local-fallback"'), "no-Key/API failure must use local fallback");
assert(main.includes('apiFallbackReason = "no_api_key"'), "no-Key reason must be explicit");
assert(main.includes('fallbackApplied: true'), "API request failure must record fallback rather than disable autofill");
assert(main.includes('local_candidate_generated_no_api'), "post-fill AI Gap must support no-API candidate generation");
assert(!main.includes('尚未配置 API Key，因此只记录 Gap，不调用 AI'), "old no-Key early-exit behavior must be removed");
console.log("build159-no-api-fallback.test.js PASS");
