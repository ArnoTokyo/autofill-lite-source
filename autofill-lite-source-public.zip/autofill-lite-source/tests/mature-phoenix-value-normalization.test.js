const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const APP = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(APP, p), 'utf8');

// The generic China location resolver is deliberately built from the already-bundled
// authoritative region tree instead of adding tenant-specific city selectors.
{
  const context = { window: { AF: {} } };
  vm.createContext(context);
  vm.runInContext(read('autofill-plugin/content/location-resolver.js'), context);
  const resolver = context.window.AF.LocationResolver;
  assert(resolver && typeof resolver.resolveChinaPath === 'function');
  assert.deepStrictEqual(Array.from(resolver.resolveChinaPath('广州')), ['广东省', '广州市']);
  assert.deepStrictEqual(Array.from(resolver.resolveChinaPath('深圳')), ['广东省', '深圳市']);
  assert.deepStrictEqual(Array.from(resolver.resolveChinaPath('北京')), ['北京市']);
  assert.deepStrictEqual(Array.from(resolver.resolveChinaPath('重庆')), ['重庆市']);
  assert.deepStrictEqual(Array.from(resolver.resolveChinaPath('广东省/广州市')), ['广东省', '广州市']);
}

const manifest = JSON.parse(read('autofill-plugin/manifest.json'));
const scripts = manifest.content_scripts.flatMap((x) => x.js || []);
const resolverIndex = scripts.indexOf('content/location-resolver.js');
const phoenixIndex = scripts.indexOf('content/select-adapter/adapters/phoenix.js');
assert(resolverIndex >= 0, 'location resolver must be injected');
assert(phoenixIndex >= 0 && resolverIndex < phoenixIndex, 'location resolver must load before Phoenix adapter');

const templates = read('autofill-plugin/content/config/site-templates.js');
assert(templates.includes('locationMode: "firstPreferredChinaPath"'));
assert(templates.includes('preserveSlashValue: true'));
assert(templates.includes('availabilityMode: "relativeChoice"'));
assert(templates.includes('preserveDateLikeSelect: true'));

const formHandler = read('autofill-plugin/content/form-handler.js');
assert(formHandler.includes('preserveChoiceAdapterForDateLike'));
assert(formHandler.includes('!preserveChoiceAdapterForDateLike'));

const phoenix = read('autofill-plugin/content/select-adapter/adapters/phoenix.js');
assert(phoenix.includes('parsePhoenixValue(value, capability)'));
assert(phoenix.includes('capability.preserveSlashValue === true'));
assert(phoenix.includes('AF.LocationResolver.resolveChinaPath'));
assert(phoenix.includes('findAvailabilityFallbackItem'));
assert(phoenix.includes('capability.availabilityMode === "relativeChoice"'));
assert(phoenix.includes('SA._registry["phoenix"] = function (element, valueType, sectionEl, capability)'));

console.log('mature-phoenix-value-normalization: ok');
