"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { compileSemanticSiteCandidate } = require("../ai-site-config-candidate");

const review = {
  page: { hostname: "example.zhiye.com", pathname: "/form" },
  trustedMappings: [
    {
      fieldId: "t1",
      category: "jobIntention",
      fieldKey: "city",
      label: "期望工作城市",
      confidence: 1,
      graphSectionTitle: "求职意向",
      graphLinkConfidence: 0.99
    }
  ],
  reviewFields: [
    { fieldId: "u1", label: "现从事职业", patchTarget: { label: "现从事职业" } },
    { fieldId: "u2", label: "现工作城市", patchTarget: { label: "现工作城市" } }
  ]
};
const patch = {
  decisions: [
    { fieldId: "u1", decision: "leave_unmapped", confidence: 0.96 },
    { fieldId: "u2", decision: "leave_unmapped", confidence: 0.96 }
  ]
};
const out = compileSemanticSiteCandidate(review, patch, { minConfidence: 0.8 });
assert.strictEqual(out.semanticPatch.fieldMappings.length, 1);
assert.strictEqual(out.semanticPatch.blockedLabels.length, 2, "high-confidence leave_unmapped labels must persist as negative site knowledge");
assert.ok(out.semanticPatch.blockedLabels.some((x) => x.label === "现从事职业"));
assert.ok(out.semanticPatch.blockedLabels.some((x) => x.label === "现工作城市"));
assert.strictEqual(out.summary.acceptedBlockedLabels, 2);

const matcher = fs.readFileSync(path.join(__dirname, "..", "autofill-plugin", "content", "data-matcher.js"), "utf8");
assert.ok(matcher.includes("isBlockedBySemanticPatch"), "Core matcher must honor candidate blocked labels before generic matching");
assert.ok(matcher.includes("if (isBlockedBySemanticPatch(this.siteConfig, labelText)) return null;"));

const templates = fs.readFileSync(path.join(__dirname, "..", "autofill-plugin", "content", "config", "site-templates.js"), "utf8");
assert.ok(templates.includes('labels: ["期望工作城市", "期望城市", "期望工作地点"]'), "Phoenix mature city capability bridge missing");
assert.ok(templates.includes('labels: ["期望月薪(税前)", "期望薪资", "期望薪酬"]'), "Phoenix salary capability bridge missing");
assert.ok(templates.includes('labels: ["到岗时间", "入职时间"]'), "Phoenix availability capability bridge missing");
assert.ok(templates.includes('adapter: "phoenix", forceAdapter: true'), "Phoenix choice controls must force the mature adapter");

const phoenix = fs.readFileSync(path.join(__dirname, "..", "autofill-plugin", "content", "select-adapter", "adapters", "phoenix.js"), "utf8");
assert.ok(phoenix.includes("data-af-phoenix-select-trace"), "safe Phoenix execution trace must be emitted for follow-up diagnosis");

console.log("mature Phoenix execution bridge regression: PASS");
