const fs = require('fs');
const path = require('path');
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, '..');
const main = fs.readFileSync(path.join(root, 'main.js'), 'utf8');
const renderer = fs.readFileSync(path.join(root, 'renderer.js'), 'utf8');
const index = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const workflow = fs.readFileSync(path.join(root, 'autofill-plugin/content/special-site-workflow.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'autofill-plugin/content/checkpoint-core.js'), 'utf8');
const sites = fs.readFileSync(path.join(root, 'autofill-plugin/private/private-special-sites.js'), 'utf8');

assert(core.includes('MANUAL_CHECKPOINT_STORAGE_KEY = "offerAutofillManualCheckpointV2"'), 'persistent checkpoint key missing');
assert(workflow.includes('saveManualWorkflowCheckpoint(workflow, step, "before_save"'), 'before-save checkpoint is not persisted');
assert(workflow.includes('saveManualWorkflowCheckpoint(workflow, step, "manual_step"'), 'manual-step checkpoint is not persisted');
assert(workflow.includes('manualResumeStartIndex = storedStepIndex + 1'), 'closed before-save checkpoint must resume after completed step');
assert(workflow.includes('manualResumeStartIndex = storedStepIndex;'), 'open/manual-step checkpoint must rerun current step');
assert(workflow.includes('[恢复执行]'), 'resume diagnostics missing');
assert(sites.includes('function hasUploadedAsset(container)'), 'uploaded asset detector missing');
assert(sites.includes('backgroundImage'), 'uploaded background-image fallback missing');
assert(sites.includes('localUploadShell'), 'photo sibling-shell fallback missing');
console.log('bankcomm-persistent-checkpoint.test.js passed');
