"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const coreSource = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-core.js"), "utf8");
const handler = fs.readFileSync(path.join(root, "autofill-plugin/content/form-handler.js"), "utf8");
const engine = fs.readFileSync(path.join(root, "autofill-plugin/content/fill-engine.js"), "utf8");
const experience = fs.readFileSync(path.join(root, "autofill-plugin/content/experience-handler.js"), "utf8");
const templates = fs.readFileSync(path.join(root, "autofill-plugin/content/config/site-templates.js"), "utf8");

assert(/const BUILD_ID = \"202609\d{2}-[^\"]+-\d+\";/.test(main), "A: current numeric Build id missing");
assert(templates.includes('inlinePersistence: true'), "B: Moka inline-persistence declaration missing");
assert(experience.includes('ConfigAdapter.prototype.usesInlinePersistence'), "B: inline persistence adapter missing");
assert(experience.includes('this.configAdapter.isAutoSaveAllowed() || this.configAdapter.usesInlinePersistence()'), "B: Moka must not invent manual-save checkpoint");
assert(handler.includes('adapter.usesInlinePersistence()'), "C: 示例资料 save probe must respect inline persistence");
assert(handler.includes('inlineEducationPersistence || !示例资料CardIsBlank'), "C: inline 示例资料 record completion rule missing");
assert(engine.includes('section_checkpoint_skip'), "D: universal SECTION resume barrier missing");
assert(engine.includes('makeSectionMeta'), "D: Structured sections must use generic section tokens");
assert(coreSource.includes('Promote that record into the durable ledger'), "E: user-ack record promotion missing");

const store = {};
const sandbox = {
  window: { AF: {}, location: { hostname: "app.mokahr.com", pathname: "/campus-recruitment/muyuan/70116", hash: "#/candidateHome/resume" } },
  chrome: {
    storage: { local: {
      get(keys, cb) { const out = {}; keys.forEach(k => { if (Object.prototype.hasOwnProperty.call(store, k)) out[k] = store[k]; }); cb(out); },
      set(payload, cb) { Object.assign(store, payload); cb && cb(); },
      remove(keys, cb) { keys.forEach(k => delete store[k]); cb && cb(); }
    } },
    runtime: { lastError: null }
  },
  console, Date, Math, Promise, Set, setTimeout, clearTimeout
};
vm.createContext(sandbox);
vm.runInContext(coreSource, sandbox, { filename: "checkpoint-core.js" });
const core = sandbox.window.AF.CheckpointCore;

(async () => {
  const loc = sandbox.window.location;
  const row1 = { company: "公司A", position: "实习生", startTime: "示例资料", endTime: "2025-02" };
  const row2 = { company: "公司B", position: "实习生", startTime: "2025-03", endTime: "2025-04" };
  const meta1 = { category: "示例资料Experience", sectionTitle: "示例资料", 示例资料Index: 0, 示例资料Total: 3, row: row1, recordFingerprint: core.recordFingerprint(row1) };
  const meta2 = { category: "示例资料Experience", sectionTitle: "示例资料", 示例资料Index: 1, 示例资料Total: 3, row: row2, recordFingerprint: core.recordFingerprint(row2) };

  const fresh = await core.beginFormRecordRun(loc);
  await fresh.pause(meta1, "等待人工处理");

  const resumed = await core.beginFormRecordRun(loc, { preserveExistingLedger: true });
  assert.strictEqual(resumed.resumed, true, "F: record run should resume");
  assert.strictEqual(resumed.shouldSkip(meta1), true, "F: user-acknowledged record should skip");
  assert.strictEqual(resumed.resumeRecordSeen, true, "F: resume record should be observed");
  assert(resumed.ledger.completedRecordTokens.includes(core.formRecordToken(meta1)), "F: acknowledged record must enter durable ledger immediately");

  const secondCheckpoint = await resumed.pause(meta2, "第二条等待人工处理");
  assert(secondCheckpoint.completedRecordTokens.includes(core.formRecordToken(meta1)), "G: next checkpoint must remember first acknowledged record");

  const third = await core.beginFormRecordRun(loc, { preserveExistingLedger: true });
  assert.strictEqual(third.shouldSkip(meta1), true, "G: first acknowledged record must remain skipped on later rerun");
  assert.strictEqual(third.shouldSkip(meta2), true, "G: second acknowledged record must skip");
  assert.strictEqual(core.snapshotFormRecordRuntime(third).ledger.completedRecordCount, 2, "G: durable ledger should contain both acknowledged records");
  console.log("moka-inline-record-resume-build134.test.js passed (A-G)");
})().catch(err => { console.error(err); process.exit(1); });
