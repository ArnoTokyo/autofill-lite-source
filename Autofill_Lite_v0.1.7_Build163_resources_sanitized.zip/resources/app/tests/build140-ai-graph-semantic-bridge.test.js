"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const gate = fs.readFileSync(path.join(root, "ai-candidate-safety-gate.js"), "utf8");
const input = fs.readFileSync(path.join(root, "site-analysis-ai-input.js"), "utf8");
const settings = fs.readFileSync(path.join(root, "ai-settings-store.js"), "utf8");
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");

assert(/const BUILD_ID = "202609\d{2}-.+-1(?:4\d|[5-9]\d|\d{3,})";/.test(main));
assert(main.includes('semanticOnlyReasons'));
assert(main.includes('示例资料_record_requires_recordgraph_ownership'));
assert(main.includes('overlayInstall = await installRuntimeSemanticOverlay'));
assert(main.includes('recordSelectorMappings'), 'RepeatRecord semantics must remain metadata-only until RecordGraph ownership');
assert(main.includes('RecordGraph'), 'AI graph route must keep RecordGraph as RepeatRecord owner');
assert(gate.includes('semanticPolicy = "site_config_semantics_only"'));
assert(input.includes('示例资料Members: ['));
assert(input.includes('"示例资料Members.relationship"'));
assert(input.includes('graph_section_category_override'));
assert(input.includes('mergeFieldIdentity'));
assert(settings.includes('clampInt(raw.maxOutputTokens, 4000, 64000, 24000)'));
assert(html.includes('max="64000"'));

// Requiring RecordGraph ownership is a semantic-only allowance, not direct AI DOM permission.
const gateModule = require(path.join(root, "ai-candidate-safety-gate.js"));
const review = {
  reviewFields: [{
    fieldId: "f1", label: "", graphRowLabel: "name", controlType: "text",
    patchTarget: { kind: "unique_selector", selector: "#name" }
  }],
  trustedMappings: []
};
const patch = { decisions: [{ fieldId: "f1", decision: "map", category: "示例资料Members", fieldKey: "name", confidence: 0.95, reason: "示例资料 member name" }] };
const result = gateModule.compileAiCandidateSafetyGate(review, patch, {});
assert.strictEqual(result.executableCandidates.length, 0);
assert.strictEqual(result.reviewOnlyCandidates.length, 1);
assert.strictEqual(result.reviewOnlyCandidates[0].semanticPolicy, "site_config_semantics_only");
assert(result.reviewOnlyCandidates[0].reasons.includes("示例资料_record_requires_recordgraph_ownership"));

console.log("build140-ai-graph-semantic-bridge.test.js PASS");
