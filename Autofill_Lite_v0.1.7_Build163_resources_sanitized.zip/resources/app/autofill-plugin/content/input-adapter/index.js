// input-adapter/index.js — Build157 text input strategy layer
(function(){
"use strict";
var AF = window.AF = window.AF || {};
var IA = AF.InputAdapter = AF.InputAdapter || {};

IA.normalize = function(value){
  return String(value == null ? "" : value);
};

IA.isTextLike = function(el){
  if(!el) return false;
  var tag=String(el.tagName||"").toLowerCase();
  return tag==="input" || tag==="textarea" || el.isContentEditable;
};

IA.getStrategy = function(el, context){
  var tag=String(el && el.tagName || "").toLowerCase();
  if(el && el.isContentEditable) return "contenteditable";
  if(tag==="textarea") return "textarea";
  try{
    if(el && (el.closest('[contenteditable="true"]'))) return "contenteditable";
  }catch(e){}
  if(context && context.inputMode) return String(context.inputMode);
  return "controlled-safe-text";
};

IA.shouldDispatchFrame示例资料Events = function(el){
  try{
    return !!(el && (el._valueTracker ||
      /react|vue|angular|ant|element/i.test(String(el.className||""))));
  }catch(e){ return false; }
};

IA.verify = function(el, expected){
  if(!el) return false;
  var current="";
  try{
    current = el.value != null ? el.value : el.textContent;
  }catch(e){}
  return IA.normalize(current).trim() === IA.normalize(expected).trim();
};

})();
