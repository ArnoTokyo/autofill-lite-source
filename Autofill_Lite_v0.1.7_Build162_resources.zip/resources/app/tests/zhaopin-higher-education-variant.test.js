"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

const menuTitles = ["个人信息", "高中教育经历", "高等教育经历", "语言情况"];
global.window = { AF: {} };
global.document = {
  body: { innerText: "", textContent: "", querySelectorAll() { return []; } },
  querySelector(selector) { return selector === "body" ? {} : null; },
  querySelectorAll(selector) {
    if (selector === ".resume-menu-item__title") {
      return menuTitles.map((textContent) => ({ textContent }));
    }
    return [];
  },
};

const registry = path.join(__dirname, "..", "autofill-plugin", "private", "private-special-sites.js");
new Function(fs.readFileSync(registry, "utf8"))();

const workflow = window.AF.PrivateSpecialSites.getWorkflowForUrl(
  "https://xiaoyuan.zhaopin.com/scrd/resume2?cid=10126836"
);
assert(workflow, "CDB page should match the shared Zhaopin campus workflow");
assert.strictEqual(workflow.id, "zhaopin-campus-enterprise-resume-v1");

const higher = workflow.steps.find((step) => step.name === "高等教育经历");
assert(higher, "higher education menu should create a workflow step");
assert.strictEqual(higher.category, "education");
assert.strictEqual(higher.higherEducationNavigationAdapter, true);
assert.strictEqual(higher.higherEducationVariant, undefined, "the CDB-specific DOM executor must be disabled");
assert.strictEqual(higher.uniqueFieldOwner, undefined, "Higher Education must not suppress the generic owner");
assert.strictEqual(higher.sharedRepeatScope, true);
assert.strictEqual(higher.currentVisibleEditorMode, false, "shared Higher Education flow must iterate every profile row instead of truncating to one visible editor");
assert.strictEqual(higher.forceAddFirstRepeatWhenNoExisting, false, "the user opens the current education editor manually");
assert.strictEqual(higher.autoOpenEducationEditor, true, "the workflow must open a missing record only after entering Higher Education");
assert.strictEqual(higher.repairExistingEducationRecords, true, "matching saved education cards must be reopened and audited instead of being treated as complete by count alone");
assert.strictEqual(higher.handleNavigationSavePrompt, false, "Education must never click save-and-jump or discard prompts");
assert.strictEqual(higher.editExistingSectionWhenClosed, false);
assert.strictEqual(higher.skipSave, false, "a completed education record must be saved so the workflow can continue");
assert.strictEqual(higher.keepEditorOnError, true, "a failed generic fill must remain in the education editor");
assert.strictEqual(higher.continueOnError, false, "a failed education editor must stop the workflow");

const fieldForLabel = (label) => higher.fieldSequence.find((item) => (Array.isArray(item.label) ? item.label : [item.label]).includes(label));
[
  "学校名称", "办学属地", "该段教育经历内是否有国外、港澳台地区学习经历", "学历", "研究方向", "院系", "专业", "专业课程",
  "学科属性", "学位", "学习形式", "学制", "是否贯通式培养", "培养方式", "个人绩点",
  "年级排名", "班级排名", "入学时间", "毕业时间",
].forEach((label) => assert(fieldForLabel(label), `sequence should contain ${label}`));
assert.strictEqual(fieldForLabel("办学属地").field, "zhaopinHigherSchoolLocation");
assert.strictEqual(fieldForLabel("研究方向").field, "zhaopinHigherResearchDirection");
assert.strictEqual(fieldForLabel("学校名称").type, "text", "school should use the shared record executor");
assert.strictEqual(fieldForLabel("学历").type, "select");
assert.strictEqual(fieldForLabel("入学时间").type, "date");
assert(higher.fieldSequence.every((item) => item.coreMatcherFirst === true));
assert.strictEqual(fieldForLabel("学习形式").field, "zhaopinHigherStudyMode");
assert.strictEqual(fieldForLabel("是否贯通式培养").field, "zhaopinHigherIntegratedTraining");
assert.strictEqual(fieldForLabel("该段教育经历内是否有国外、港澳台地区学习经历").field, "zhaopinHigherHasOverseasStudy");
assert.strictEqual(fieldForLabel("学制").field, "zhaopinHigherStudyLength");
assert.strictEqual(fieldForLabel("班级排名").field, "zhaopinHigherClassRank");
assert.strictEqual(fieldForLabel("培养方式").field, "zhaopinHigherTrainingMode");

const transformed = higher.rowTransform({
  school: "中国人民大学",
  schoolLocation: "北京",
  level: "硕士",
  majorCategory: "经济学",
  degree: "硕士",
  educationType: "全日制",
  studyMode: "全日制",
  trainingMode: "非定向就业",
  schoolAffiliation: "国内高校",
  researchDirection: "证券投资与金融管理",
  department: "财政金融学院",
  major: "金融",
  courses: ["投资学", "公司金融"],
  integratedTraining: "非贯通式培养",
  hasOverseasStudy: "否",
  studyLength: "两年制",
  gpa: "3.61",
  rank: "其他",
  cohortRank: "其他",
  classRank: "40%",
  startTime: "2025-09-01",
  endTime: "2027-06-30",
});
assert.strictEqual(transformed.zhaopinHigherSchoolLocation, "国内高校");
assert.strictEqual(transformed.zhaopinHigherLevel, "硕士研究生");
assert.strictEqual(transformed.zhaopinHigherDiscipline, "经济学");
assert.strictEqual(transformed.zhaopinHigherDegree, "硕士");
assert.strictEqual(transformed.schoolLocation, "北京");
assert.strictEqual(transformed.schoolAffiliation, "国内高校");
assert.strictEqual(transformed.zhaopinHigherStudyMode, "全日制");
assert.strictEqual(transformed.zhaopinHigherTrainingMode, "非定向就业");
assert.strictEqual(transformed.zhaopinHigherCourses, "投资学、公司金融");
assert.strictEqual(transformed.zhaopinHigherHasOverseasStudy, "否");
assert.strictEqual(transformed.zhaopinHigherStudyLength, "两年制");
assert.strictEqual(transformed.zhaopinHigherIntegratedTraining, "非贯通式培养");
assert.strictEqual(transformed.zhaopinHigherRank, "其他");
assert.strictEqual(transformed.zhaopinHigherClassRank, "其他");

assert(!workflow.steps.some((step) => step.name === "高中教育经历"), "high-school menu must not consume university education rows");

const workflowSource = fs.readFileSync(path.join(__dirname, "..", "autofill-plugin", "content", "special-site-workflow.js"), "utf8");
const privateSource = fs.readFileSync(path.join(__dirname, "..", "autofill-plugin", "private", "private-special-sites.js"), "utf8");
const mainSource = fs.readFileSync(path.join(__dirname, "..", "main.js"), "utf8");
assert(workflowSource.includes("step.currentVisibleEditorMode === true && step.higherEducationNavigationAdapter !== true"), "the shared Higher Education navigation adapter must not be truncated to one row by the legacy visible-editor guard");
assert(workflowSource.includes("scanHigherEducationExistingRecords"), "Higher Education must retain record/card identity so an existing card can be reopened safely");
assert(workflowSource.includes("matchHigherEducationExistingRecord"), "Higher Education must match the current profile row to one saved card before repair");
assert(workflowSource.includes('result.action = result.root ? "opened_existing_editor" : ""'), "a matched education card must reopen its existing editor instead of being silently skipped");
assert(workflowSource.includes("resolveHigherEducationEditableRoot"), "navigation adapter must require a real editable root");
assert(workflowSource.includes("runHigherEducationNavigationAdapter"), "the thin adapter must stop after opening and reacquiring the editor");
assert(workflowSource.includes("navigateToResumeSection"), "Higher Education must navigate before its Add guard runs");
assert(workflowSource.includes("awaiting_save_before_navigation"), "an unsaved dialog must enter the module transaction state");
assert(workflowSource.includes("inspectCurrentModuleValidation"), "save-and-navigate must be gated by visible page validation");
assert(workflowSource.includes("completeModuleSaveAndNavigate"), "module transitions must share one transaction helper");
assert(workflowSource.includes("current_module_validation_failed"));
assert(workflowSource.includes("createInitialEducationRepeatNavigationTrace"), "profile education count must be traced before navigation succeeds");
assert(workflowSource.includes("__AF_TEST_TARGET_SECTION__"), "development target mode must be opt-in");
assert(workflowSource.includes("MutationObserver"), "editor opening must reacquire DOM after mutation");
assert(workflowSource.includes("higherEducationInteractiveControls"), "editor readiness must depend on real interactive controls");
assert(workflowSource.includes("higher_education_editor_not_open"), "an unopened editor must stop with a user-action reason");
assert(workflowSource.includes("active_navigation"), "current-section detection must prefer the active navigation item");
assert(workflowSource.includes("coreMatcherFirst"), "shared record fields must delegate to the Core matcher first");
assert(workflowSource.includes("genericMatcherFound"), "stable diagnostics must report generic matcher results");
assert(workflowSource.includes("resolveHigherEducationNavigationControl"), "Higher Education must bind controls from the active editor before falling back to the generic matcher");
assert(workflowSource.includes("resolveLiveHigherEducationFormScope"), "Higher Education must reacquire the live edit form after Add/Vue rerenders");
assert(workflowSource.includes("resolveHigherEducationDirectFieldControl"), "Higher Education must bind controls inside the live form-item before generic fallback");
assert(workflowSource.includes("ready_to_save"), "completed Higher Education must flow into the shared save path");
assert(workflowSource.includes("education_complete_no_missing_record"), "an already-complete Higher Education section must become a safe continuation state");
assert(workflowSource.includes("resumeExecutionStepsFromActiveSection"), "starting from Higher Education must preserve later workflow sections");
assert(!workflowSource.includes("executionSteps = executionSteps.filter(function (step) { return step && (step.higherEducationNavigationAdapter === true || step.higherEducationVariant === true); });"), "Higher Education must not truncate the workflow to education only");
assert(!workflowSource.includes("needs_user_action:education_review_before_save"), "the old manual-review stop must be removed from the workflow path");
assert(mainSource.includes("requiredLabels.length > 0"), "empty required-label coverage must not be complete");
assert(mainSource.includes("genericOwnerSuppressed: false"), "Higher Education must never suppress the generic owner");
assert(mainSource.includes("generic-scoped-record-filler"), "ownership diagnostics must name the shared executor");
assert(mainSource.includes("trace.records = []"), "trace must always expose a records array");
assert(mainSource.includes("mappingCoverageComplete"), "mapping coverage must be named separately from fill coverage");
assert(mainSource.includes("sectionStateTrace"), "final diagnostics must export active-section detection");
assert(mainSource.includes("20260914-education-bachelor-study-length-29"));
assert(mainSource.includes("educationRepeatNavigationTrace"));
assert(mainSource.includes("resumeSectionNavigationTrace"));
assert(mainSource.includes("moduleTransactionTrace"));

// Build 29: bachelor study length is canonicalized to “四年制”; the shared
// study-year matcher accepts 4年/四年/4年制/4/48个月 as the same meaning.
const bachelorTransformed = higher.rowTransform({
  school: "中国人民大学", level: "本科", degree: "学士", major: "财政学",
  studyLength: "四年制", startTime: "2021-09-01", endTime: "2025-06-30"
});
assert.strictEqual(bachelorTransformed.zhaopinHigherStudyLength, "四年制");
const utilsSource = fs.readFileSync(path.join(__dirname, "..", "autofill-plugin", "content", "utils.js"), "utf8");
assert(utilsSource.includes("parseStudyYears"), "shared semantic study-year matcher must remain enabled");

console.log("zhaopin higher education variant test: PASS");

// Build 22: dynamic Element Selects may commit their value even when the panel
// closes before the generic adapter reports success. The education path must
// read back the live value and then use the strict current-control fallback.
assert(workflowSource.includes("higherEducationAlreadyCorrect"));
assert(workflowSource.includes("strictCurrentControl: true"));
assert(workflowSource.includes("elementChoiceValueMatches(higherSelectContainer, itemValue)"));

// Build 24: rank/select fields can use the exact Element aria-linked popper,
// then the shared save path may persist the completed education record.
assert(workflowSource.includes("forceCommitElementChoiceViaAria"));
assert(workflowSource.includes("findAriaLinkedElementChoicePanel"));
assert(workflowSource.includes("ready_to_save"));

assert(workflowSource.includes("fillPersistentElementSelectChoice"), "高等教育必填下拉应使用持久化候选点击路径");
assert(workflowSource.includes("clickElementSelectNodeOnce"), "严格 Element Select 提交不得双击开关控件");
assert(privateSource.includes("requirePersistentSelectCommit: true"), "年级排名必须启用严格持久化提交");
assert(privateSource.includes("beforeSaveEnsureFields: zhaopinHigherEducationBeforeSaveFields()"), "保存前必须再次复核年级排名");

// Build 27: Element Plus may render the committed single-select value only in
// .el-select__selected-item while input.value stays empty. Save-time validation
// must read the rendered selection and must not reopen an already-valid rank select.
assert(workflowSource.includes(".el-select__selected-item"), "保存前复核必须读取 Element Plus 的真实 selected item");
assert(privateSource.includes("alwaysRefillBeforeSave: false"), "已稳定选中的年级排名保存前不得强制重选");

// Build 30: optional education fields (notably 研究方向 on本科) must never
// block save/navigation merely because their control is absent on that page.
// The save gate must derive blockers from fieldSequence.optional rather than
// a hard-coded list of every known education field.
assert.strictEqual(fieldForLabel("研究方向").optional, true, "本科没有研究方向时不应阻断保存");
assert.strictEqual(fieldForLabel("院系").optional, true);
assert.strictEqual(fieldForLabel("专业课程").optional, true);
assert(workflowSource.includes("item.optional !== true"), "高等教育保存门槛必须遵循fieldSequence optional语义");
assert(workflowSource.includes("blockingRequiredFieldKeys"), "保存门槛诊断必须暴露真正阻断的必填字段");
assert(!workflowSource.includes('"zhaopinHigherResearchDirection",\n              "zhaopinHigherDepartment"'), "不得再用包含研究方向的硬编码必填列表");
