"use strict";

function classifySiteSupport(input) {
  const x = input && typeof input === "object" ? input : {};
  const matchedWorkflowId = String(x.matchedWorkflowId || "");
  const localConfigFound = !!x.localConfigFound;
  const builtInConfigFound = !!x.builtInConfigFound;
  const domPlatformDetected = !!x.domPlatformDetected;
  const controls = Math.max(0, Number(x.visibleEditableControlCount || 0));
  const labels = Math.max(0, Number(x.visibleLabelLikeCount || 0));
  const total = Math.max(0, Number(x.totalFieldsFound || 0));
  const filled = Math.max(0, Number(x.filledCount || 0));

  if (matchedWorkflowId) {
    return {
      code: "special_示例资料flow",
      summary: "已命中特殊站点工作流",
      recommendation: "按现有工作流继续验证；若失败，优先查看工作流诊断。"
    };
  }
  if (localConfigFound) {
    return {
      code: "local_config",
      summary: "已命中本地站点配置",
      recommendation: "配置入口已建立；若失败，继续区分语义映射、控件执行和网页校验。"
    };
  }
  if (builtInConfigFound) {
    return {
      code: "built_in_config",
      summary: "已命中 Autofill Core 内置站点配置",
      recommendation: "优先复用现有平台适配，不要另造整站 DOM 引擎。"
    };
  }
  if (domPlatformDetected) {
    return {
      code: "dom_platform_detected",
      summary: "未命中精确站点配置，但识别到可复用平台",
      recommendation: "优先补薄入口或字段别名，复用平台级控件能力。"
    };
  }
  if (total > 0 && filled > 0) {
    return {
      code: "generic_scan_示例资料ing",
      summary: "未命中站点配置，但通用表单扫描正在工作",
      recommendation: "只针对失败字段补语义映射或控件适配。"
    };
  }
  if (total > 0) {
    return {
      code: "generic_scan_semantic_gap",
      summary: "DOM 已被扫描，但语义匹配或控件执行不足",
      recommendation: "先检查字段扫描、语义映射和控件绑定，不要先写站点硬编码。"
    };
  }
  if (controls > 0 && labels > 0) {
    return {
      code: "generic_scan_entry_gap",
      summary: "未命中站点配置，但页面存在可扫描表单",
      recommendation: "通用 Core 很可能可复用；优先补扫描入口、label 选择器或 示例资料/structured 模式。"
    };
  }
  if (controls > 0) {
    return {
      code: "new_adapter_likely",
      summary: "检测到可编辑控件，但缺少稳定字段标签",
      recommendation: "可能需要新的薄适配或平台结构识别；先采集脱敏 DOM 结构再决定。"
    };
  }
  return {
    code: "no_form_detected",
    summary: "当前页面未检测到可填表单",
    recommendation: "确认已进入真实简历编辑页；若已进入，才考虑新增适配。"
  };
}

function classifyAutofillGap(input) {
  const x = input && typeof input === "object" ? input : {};
  const completionStatus = String(x.completionStatus || "");
  const siteSupportCode = String(x.siteSupportCode || "");
  const failedCount = Math.max(0, Number(x.failedCount || 0));
  const unhandledCount = Math.max(0, Number(x.unhandledCount || 0));
  const missingProfileFields = Array.isArray(x.missingProfileFields) ? x.missingProfileFields : [];
  const failedFields = Array.isArray(x.failedFields) ? x.failedFields : [];
  const reasons = failedFields.map((f) => String(f && f.reason || "")).join(" | ");

  if (completionStatus === "complete" && failedCount === 0 && unhandledCount === 0) {
    return { code: "none", summary: "本地填写已完成", aiSemanticRecommended: false };
  }
  if (missingProfileFields.length) {
    return {
      code: "profile_data_gap",
      summary: "存在资料库明确缺少的字段",
      aiSemanticRecommended: false,
      recommendation: "先补充真实资料；AI 不应猜测个人事实。"
    };
  }
  if (/element not found|fill failed|selection|retained|timeout|保存|save|示例资料|editor|date|控件|候选|面板/i.test(reasons)) {
    return {
      code: "control_or_示例资料flow_gap",
      summary: "失败更像控件执行或流程问题",
      aiSemanticRecommended: false,
      recommendation: "优先检查控件适配、重复经历或保存事务，不要先调用语义 AI。"
    };
  }
  if (unhandledCount > 0) {
    return {
      code: "semantic_gap_possible",
      summary: "存在未处理字段，可能是语义映射缺口",
      aiSemanticRecommended: true,
      recommendation: "可进行脱敏站点分析并让 AI 只复核未映射字段；不要对已填经历整页重跑。"
    };
  }
  if (completionStatus === "failed" && (siteSupportCode === "new_adapter_likely" || siteSupportCode === "generic_scan_entry_gap")) {
    return {
      code: "structure_gap_possible",
      summary: "页面有可编辑控件，但通用 Core 缺少稳定分区/标题入口",
      aiSemanticRecommended: true,
      recommendation: "优先使用脱敏站点分析生成结构候选或薄适配，不要把它误判成字段值问题。"
    };
  }
  return {
    code: "mixed_or_unknown",
    summary: "仍有未完成项，原因混合或不足以判断",
    aiSemanticRecommended: false,
    recommendation: "先看失败字段与页面剩余必填项，再决定是语义、控件还是资料缺口。"
  };
}

module.exports = { classifySiteSupport, classifyAutofillGap };
