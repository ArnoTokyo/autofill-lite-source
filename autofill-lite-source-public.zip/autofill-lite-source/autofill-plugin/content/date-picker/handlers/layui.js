// content/date-picker/handlers/layui.js — LayUI 日期选择器 (.layui-input / [lay-key], 面板 .layui-laydate)
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   工厂分支 Kn.create() case "layui": 有 lay-range/range 属性或页面存在 .layui-laydate-range
//     时用 uo(范围), 否则 co(单选)。行 46019-46024
//   co.setValue (单选): 行 46985-47072 (调用 br())
//   br()/gr() (单选打开面板+通用导航器 w()): 行 39094-39166 — 选择器已核实
//   uo.setValue (范围): 行 47074-47122 (调用 Sr())
//   Sr()/Lr() (范围, 面板内两个 .layui-laydate-main 子面板各自导航): 行 39702-39775 — 结构已核实
//     (Or() 具体逐字段实现未在源码中单独定位到, 这里对每个子面板复用跟单选完全相同的
//     年/月/日选择器集合，是同一 laydate 组件在双栏模式下的标准 DOM 结构)
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  var PANEL_SEL = '.layui-laydate:not([style*="display: none"])';

  function laydatePanelOptions(container, dateStr) {
    return {
      container: container,
      dateString: dateStr,
      headerClickSelector: '.laydate-set-ym span[lay-type="year"]',
      yearCellSelector: ".laydate-year-list li",
      disabledClassList: null,
      yearBoundarySelector: ".laydate-set-ym span:first-child",
      nextYearSelector: ".laydate-next-y",
      prevYearSelector: ".laydate-prev-y",
      monthPanelSelector: '.laydate-set-ym span[lay-type="month"]',
      monthCellSelector: "li[lay-ym]",
      dayCellSelector: "td:not(.laydate-day-prev):not(.laydate-day-next)",
      maxRetries: 20,
    };
  }

  // ---- 单选 (源码 br()/gr(), 行39094) ----
  async function layuiSingleNavigate(triggerEl, dateStr) {
    var input = (triggerEl.querySelector && triggerEl.querySelector("input")) || triggerEl;
    await AF.DomUtils.enhancedClick(input);
    await AF.Utils.sleep(300);
    var panel = document.querySelector(PANEL_SEL);
    if (!panel) throw new Error("无法打开Layui日期选择器");
    var ok = await AF.DatePicker._navigatePanel(laydatePanelOptions(panel, dateStr));
    var confirmBtn = panel.querySelector(".laydate-btns-confirm");
    if (confirmBtn) {
      await AF.DomUtils.enhancedClick(confirmBtn);
      await AF.Utils.sleep(200);
    }
    if (!ok) throw new Error("无法打开Layui日期选择器");
    return true;
  }

  // ---- 范围 (源码 Sr()/Lr(), 行39702) ----
  async function layuiRangeNavigate(triggerEl, startStr, endStr) {
    triggerEl.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    await AF.Utils.sleep(300);
    var panel = document.querySelector(PANEL_SEL);
    if (!panel) throw new Error("无法打开Layui日期范围选择器");
    var mains = panel.querySelectorAll(".layui-laydate-main");
    if (mains.length !== 2) throw new Error("不是日期范围选择器");
    var ok1 = await AF.DatePicker._navigatePanel(laydatePanelOptions(mains[0], startStr));
    var ok2 = await AF.DatePicker._navigatePanel(laydatePanelOptions(mains[1], endStr));
    var confirmBtn = panel.querySelector(".laydate-btns-confirm");
    if (confirmBtn) {
      confirmBtn.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    }
    await AF.Utils.sleep(200);
    return !!(ok1 && ok2);
  }

  AF.DatePicker._registry["layui"] = function (element, valueType) {
    return {
      setValue: async function (value) {
        try {
          if (!value) throw new Error("日期为空");
          var isRange = element.getAttribute("lay-range") === "true" || element.getAttribute("range") === "true" ||
            element.hasAttribute("range") || !!document.querySelector(".layui-laydate-range");

          if (isRange) {
            if (typeof value !== "object" || !("startTime" in value) || !("endTime" in value)) {
              throw new Error("dateValue必须包含startTime和endTime属性");
            }
            return await layuiRangeNavigate(element, value.startTime, value.endTime);
          }

          if (typeof value === "string" || valueType === "string") {
            return await layuiSingleNavigate(element, value);
          }
          if (typeof value !== "object" || !("startTime" in value) || !("endTime" in value)) {
            throw new Error("当option为对象时，dateValue必须包含startTime和endTime属性");
          }
          await layuiSingleNavigate(element, value.startTime);
          await AF.Utils.sleep(500);
          var candidates = AF.DomUtils.findSimilarElements(element, 4, { sameTag: true, sameClass: true, sameParent: false });
          if (candidates.length > 0) {
            var best = AF.DatePicker._pickEndDateCandidate(element, candidates);
            await layuiSingleNavigate(best, value.endTime);
          } else {
            var surrounding = AF.DomUtils.findSurroundingInputs(element);
            if (surrounding.length > 0) await layuiSingleNavigate(surrounding[0], value.endTime);
          }
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
