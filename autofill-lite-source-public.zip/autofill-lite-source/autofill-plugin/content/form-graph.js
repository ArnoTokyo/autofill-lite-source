// content/form-graph.js
// Read-only structural graph builder for Autofill Lite.
// Builds section -> row -> control relationships without reading current field values.
(function (rootFactory) {
  "use strict";
  var api = rootFactory(typeof window !== "undefined" ? window : globalThis);
  if (typeof window !== "undefined") {
    window.AF = window.AF || {};
    window.AF.FormGraph = api;
  }
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(function (global) {
  "use strict";

  var VERSION = "1.3.0";
  var SCHEMA_VERSION = 1;

  var CONTROL_SELECTOR = [
    "input:not([type='hidden']):not([type='button']):not([type='submit']):not([type='reset'])",
    "select",
    "textarea",
    "[contenteditable='true']",
    "[contenteditable='']",
    ".ant-select",
    ".ant-cascader-picker",
    ".ant-picker",
    ".ant-calendar-picker",
    ".el-select",
    ".el-cascader",
    ".el-date-editor",
    ".phoenix-select",
    ".phoenix-date-picker",
    ".phoenix-radio-group",
    ".ant-radio-group",
    ".el-radio-group",
    "[role='radiogroup']",
    "[role='combobox']",
    "[role='textbox']"
  ].join(",");

  var SECTION_CONTAINER_SELECTOR = [
    "section",
    "fieldset",
    ".ant-card",
    ".el-card",
    ".ant-collapse-item",
    ".el-collapse-item",
    "[class*='section']",
    "[class*='module']",
    "[class*='panel']",
    "[class*='card']",
    "[class*='resume']",
    "form"
  ].join(",");

  var ROW_CONTAINER_SELECTOR = [
    ".ant-form-item",
    ".el-form-item",
    ".van-field",
    ".van-cell",
    ".form-item",
    "[class~='form-item']",
    "[class*='form_item']",
    "[class*='formItem']",
    "[class*='field-row']",
    "[class*='fieldRow']",
    "[class*='form-row']",
    "[class*='formRow']",
    "dl",
    "tr",
    "li"
  ].join(",");

  var SECTION_TITLE_SELECTOR = [
    "h1", "h2", "h3", "h4", "h5", "h6", "legend",
    ".ant-card-head-title", ".el-card__header",
    ".ant-collapse-header", ".el-collapse-item__title",
    "[class*='section-title']", "[class*='module-title']",
    "[class*='panel-title']", "[class*='card-title']",
    "[class*='block-title']", "[class*='form-title']",
    "[class*='part-title']", "[class*='part__title']",
    "[class*='group-title']", "[class*='step-title']"
  ].join(",");

  var LABEL_SELECTOR = [
    "label", "dt", "th",
    ".ant-form-item-label", ".ant-form-item-label > label",
    ".el-form-item__label", ".form-item__label", ".form-item-label",
    ".van-field__label", ".van-cell__title",
    "[class*='item__label']", "[class*='label']"
  ].join(",");

  function normalizeText(value, max) {
    return String(value || "")
      .replace(/[＊*]/g, "")
      .replace(/[：:]/g, "")
      .replace(/[（(]?(必填|选填|可选|required|optional)[）)]?/gi, "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, Number(max || 100));
  }

  function safeAttr(value, max) {
    var text = normalizeText(value, max || 100);
    if (!text) return "";
    if (/\b(token|session|credential|authorization|cookie)\b/i.test(text)) return "";
    if (/https?:\/\//i.test(text)) {
      try {
        var u = new URL(text, global.location && global.location.href || "https://local.invalid/");
        return u.protocol + "//" + u.host + u.pathname;
      } catch (_) {
        return text.split(/[?#]/)[0];
      }
    }
    return text;
  }

  function safePath(value) {
    try {
      var u = new URL(String(value || ""), global.location && global.location.href || "https://local.invalid/");
      return u.pathname || "/";
    } catch (_) {
      return String(value || "").split(/[?#]/)[0] || "/";
    }
  }

  function hashText(value) {
    var text = String(value || "");
    var hash = 2166136261;
    for (var i = 0; i < text.length; i++) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }

  function stableId(prefix, parts) {
    return prefix + "_" + hashText((parts || []).map(function (part) {
      return normalizeText(part, 220);
    }).join("|"));
  }

  function isVisible(element) {
    if (!element) return false;
    if (element.isConnected === false) return false;
    try {
      var style = global.getComputedStyle ? global.getComputedStyle(element) : { display: "", visibility: "", opacity: "1" };
      if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) < 0.01) return false;
      var rect = element.getBoundingClientRect ? element.getBoundingClientRect() : { width: 1, height: 1 };
      return Number(rect.width || 0) > 0 || Number(rect.height || 0) > 0;
    } catch (_) {
      return false;
    }
  }

  function rectOf(element) {
    try {
      var rect = element.getBoundingClientRect();
      return {
        x: Math.round(rect.left || rect.x || 0),
        y: Math.round(rect.top || rect.y || 0),
        width: Math.round(rect.width || 0),
        height: Math.round(rect.height || 0)
      };
    } catch (_) {
      return { x: 0, y: 0, width: 0, height: 0 };
    }
  }

  function cssEscape(value) {
    if (global.CSS && typeof global.CSS.escape === "function") return global.CSS.escape(String(value || ""));
    return String(value || "").replace(/([^A-Za-z0-9_-])/g, "\\$1");
  }

  function acceptableId(value) {
    var id = String(value || "").trim();
    if (!id || id.length > 90) return false;
    if (/\b(token|session|credential|authorization|cookie)\b/i.test(id)) return false;
    if (/^[0-9a-f]{20,}$/i.test(id) || /\d{10,}/.test(id)) return false;
    return /^[A-Za-z_][A-Za-z0-9_:\-.]*$/.test(id);
  }

  function selectorCount(selector, doc) {
    try { return (doc || global.document).querySelectorAll(selector).length; }
    catch (_) { return 0; }
  }

  function stableSelector(element, doc) {
    if (!element || element.nodeType !== 1) return "";
    doc = doc || global.document;
    if (acceptableId(element.id)) {
      var idSelector = "#" + cssEscape(element.id);
      if (selectorCount(idSelector, doc) === 1) return idSelector;
    }

    var tag = String(element.tagName || "").toLowerCase() || "*";
    var attrs = ["name", "data-field", "data-key", "aria-label", "autocomplete"];
    for (var i = 0; i < attrs.length; i++) {
      var raw = element.getAttribute && element.getAttribute(attrs[i]);
      var value = safeAttr(raw, 80);
      if (!value || /[\r\n<>]/.test(value)) continue;
      var escaped = String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
      var attrSelector = tag + "[" + attrs[i] + "=\"" + escaped + "\"]";
      if (selectorCount(attrSelector, doc) === 1) return attrSelector;
    }

    var parts = [];
    var current = element;
    for (var depth = 0; current && current.nodeType === 1 && depth < 6; depth++, current = current.parentElement) {
      if (acceptableId(current.id)) {
        parts.unshift("#" + cssEscape(current.id));
        break;
      }
      var currentTag = String(current.tagName || "").toLowerCase() || "*";
      var classes = Array.from(current.classList || []).filter(function (cls) {
        return cls && cls.length < 36 && /^[A-Za-z_-][A-Za-z0-9_-]*$/.test(cls) &&
          !/active|selected|focused|focus|error|open|hover|disabled|^css-/i.test(cls);
      }).slice(0, 2);
      var part = currentTag + classes.map(function (cls) { return "." + cssEscape(cls); }).join("");
      var parent = current.parentElement;
      if (parent && parent.children) {
        var sameTag = Array.from(parent.children).filter(function (sibling) {
          return sibling && String(sibling.tagName || "").toLowerCase() === currentTag;
        });
        if (sameTag.length > 1) part += ":nth-of-type(" + (sameTag.indexOf(current) + 1) + ")";
      }
      parts.unshift(part);
      var candidate = parts.join(" > ");
      if (selectorCount(candidate, doc) === 1) return candidate;
    }
    return parts.join(" > ");
  }

  function detectControlType(element) {
    var tag = String(element && element.tagName || "").toLowerCase();
    var type = String(element && (element.type || (element.getAttribute && element.getAttribute("type"))) || "").toLowerCase();
    var cls = String(element && element.className || "");
    var role = String(element && element.getAttribute && element.getAttribute("role") || "").toLowerCase();

    if (type === "file") return "file-upload";
    if (/ant-cascader|el-cascader/i.test(cls)) return "cascader";
    if (/ant-picker|ant-calendar-picker|el-date-editor|phoenix-date-picker/i.test(cls)) return "date-picker";
    if (/ant-radio-group|el-radio-group|phoenix-radio-group/i.test(cls) || role === "radiogroup") return "radio-group";
    if (/ant-select|el-select|phoenix-select/i.test(cls) || role === "combobox" ||
        (element && element.closest && element.closest(".phoenix-select"))) return "custom-select";
    if (tag === "select") return "native-select";
    if (tag === "textarea") return "textarea";
    if (element && element.getAttribute && (element.getAttribute("contenteditable") === "true" || element.getAttribute("contenteditable") === "")) return "contenteditable";
    if (type === "radio") return "radio";
    if (type === "checkbox") return "checkbox";
    if (["date", "month", "time", "datetime-local"].indexOf(type) >= 0) return type;
    if (role === "textbox") return "textbox";
    return "text";
  }

  function detectWidgetFamily(element) {
    var cls = String(element && element.className || "");
    if (/\bant-|ant\b/i.test(cls)) return "ant";
    if (/\bel-|element\b/i.test(cls)) return "element";
    if (/\bvan-|vant\b/i.test(cls)) return "vant";
    if (/\bivu-|iview\b/i.test(cls)) return "iview";
    if (/\blayui\b/i.test(cls)) return "layui";
    if (/\bkuma\b/i.test(cls)) return "kuma";
    if (/\bphoenix-|phoenix\b/i.test(cls) || (element && element.closest && element.closest(".phoenix-select,.phoenix-input,.phoenix-textarea"))) return "phoenix";
    return "native";
  }

  function selectorText(slot) {
    if (!slot) return "";
    if (typeof slot === "string") return slot.trim();
    if (typeof slot === "object") return String(slot.class || slot.selector || "").trim();
    return "";
  }

  function pushSelector(list, value) {
    String(value || "").split(",").map(function (part) { return part.trim(); }).filter(Boolean).forEach(function (part) {
      if (list.indexOf(part) < 0) list.push(part);
    });
  }

  // Mature-product-first structural hints. The mature app already knows how to
  // recognize reusable UI platforms (notably Beisen Phoenix) and exact built-in
  // sites (notably xiaoyuan.zhaopin.com). FormGraph consumes those assets instead
  // of inventing a second, competing platform detector.
  function resolveStructureHints() {
    var hints = {
      source: "generic",
      configName: "",
      sectionSelectors: [],
      rowSelectors: [],
      titleSelectors: [],
      labelSelectors: []
    };
    try {
      var AF = global.AF || {};
      var loader = AF.SiteLoader || {};
      var builtIn = typeof loader._getConfigForUrl === "function" ? loader._getConfigForUrl(global.location && global.location.href || "") : null;
      var platform = typeof loader._detectSiteType === "function" ? loader._detectSiteType() : null;
      var config = builtIn || platform || null;
      if (!config) return hints;
      hints.source = builtIn ? "built_in_config" : "dom_platform";
      hints.configName = String(config.name || "");
      var selectors = config.selectors || {};
      pushSelector(hints.sectionSelectors, typeof selectors.section === "string" ? selectors.section : "");
      pushSelector(hints.sectionSelectors, selectorText(selectors.container));
      pushSelector(hints.titleSelectors, selectorText(selectors.title));
      pushSelector(hints.labelSelectors, selectorText(selectors.labels));
      var experience = config.experience || {};
      if (experience.container) pushSelector(hints.sectionSelectors, experience.container.containerSelector || experience.container.selector || "");

      var name = hints.configName.toLowerCase();
      if (name === "beisen-phoenix" || name.indexOf("phoenix") >= 0) {
        // These are the mature product's stable semantic wrappers. In particular,
        // do NOT use inner .form-part as a section boundary: ExperienceHandler
        // explicitly warns that it loses the outer card/add-action ownership.
        pushSelector(hints.rowSelectors, ".form-item");
        pushSelector(hints.rowSelectors, ".ant-form-item");
        pushSelector(hints.rowSelectors, ".el-form-item");
        pushSelector(hints.labelSelectors, ".form-item__text");
        pushSelector(hints.sectionSelectors, ".sc-cTAqQK");
        pushSelector(hints.sectionSelectors, ".sc-iAKWXU");
      } else if (/xiaoyuan\.zhaopin\.com|zhaopin/.test(name) || /xiaoyuan\.zhaopin\.com$/i.test(String(global.location && global.location.hostname || ""))) {
        pushSelector(hints.rowSelectors, ".el-form-item");
        pushSelector(hints.rowSelectors, ".form-item");
        pushSelector(hints.sectionSelectors, ".apply-module");
        pushSelector(hints.titleSelectors, ".form-content--title");
        pushSelector(hints.labelSelectors, ".el-form-item__label");
      }
    } catch (_) {}
    return hints;
  }

  function closestWithin(control, selectors, root) {
    if (!control || !control.closest) return null;
    for (var i = 0; i < (selectors || []).length; i++) {
      try {
        var hit = control.closest(selectors[i]);
        if (hit && (!root || hit === root || (root.contains && root.contains(hit)))) return hit;
      } catch (_) {}
    }
    return null;
  }

  function controlCount(container) {
    if (!container || !container.querySelectorAll) return 0;
    try { return container.querySelectorAll(CONTROL_SELECTOR).length; }
    catch (_) { return 0; }
  }

  function findSectionContainer(control, root, hints) {
    if (!control) return root;
    var hinted = closestWithin(control, hints && hints.sectionSelectors, root);
    if (hinted) return hinted;
    var direct = control.closest && control.closest(SECTION_CONTAINER_SELECTOR);
    if (direct && (!root || root.contains(direct) || direct === root)) return direct;
    return root || (global.document && global.document.body) || control.parentElement;
  }

  function findRowContainer(control, section, hints) {
    if (!control) return section;
    var hinted = closestWithin(control, hints && hints.rowSelectors, section);
    if (hinted) return hinted;
    var direct = control.closest && control.closest(ROW_CONTAINER_SELECTOR);
    if (direct && section && section.contains && section.contains(direct)) return direct;
    if (direct && !section) return direct;

    var current = control.parentElement;
    for (var depth = 0; current && current !== section && depth < 5; depth++, current = current.parentElement) {
      var count = controlCount(current);
      if (count > 0 && count <= 4) return current;
    }
    return control.parentElement || section;
  }

  function firstVisibleText(nodes, max) {
    for (var i = 0; i < nodes.length; i++) {
      if (!isVisible(nodes[i])) continue;
      var text = normalizeText(nodes[i].textContent, max || 80);
      if (text) return text;
    }
    return "";
  }

  function findLabel(control, row, doc, hints) {
    if (!control) return "";
    doc = doc || global.document;
    var id = control.id;
    if (id && doc && doc.querySelector) {
      try {
        var explicit = doc.querySelector("label[for=\"" + String(id).replace(/"/g, '\\"') + "\"]");
        var explicitText = normalizeText(explicit && explicit.textContent, 80);
        if (explicitText) return explicitText;
      } catch (_) {}
    }

    if (row && row.querySelectorAll) {
      try {
        var selector = ((hints && hints.labelSelectors && hints.labelSelectors.length) ? hints.labelSelectors.join(",") + "," : "") + LABEL_SELECTOR;
        var labels = Array.from(row.querySelectorAll(selector)).filter(function (label) {
          return label !== control && !(label.contains && label.contains(control));
        });
        var labelText = firstVisibleText(labels, 80);
        if (labelText) return labelText;
      } catch (_) {}
    }

    var attrs = ["aria-label", "data-label", "placeholder", "name"];
    for (var i = 0; i < attrs.length; i++) {
      var text = normalizeText(control.getAttribute && control.getAttribute(attrs[i]), 80);
      if (text) return text;
    }

    var prev = control.previousElementSibling;
    for (var depth = 0; prev && depth < 3; depth++, prev = prev.previousElementSibling) {
      var prevText = normalizeText(prev.textContent, 80);
      if (prevText) return prevText;
    }
    return "";
  }

  function semanticTitleFromStableSectionIdentity(section) {
    if (!section) return "";
    var identity = String([
      section.id || "",
      section.getAttribute && section.getAttribute("data-section") || "",
      section.getAttribute && section.getAttribute("data-module") || "",
      section.getAttribute && section.getAttribute("name") || ""
    ].join(" ")).toLowerCase();
    if (!identity) return "";
    if (/resumejobhistory|jobhistory|workhistory|workexperience|internshiphistory/.test(identity)) return "实习/工作/入伍经历";
    if (/resumerelatives|relativesinfo|familymembers|familyinfo/.test(identity)) return "家庭成员";
    if (/resumeeducation|educationinfo|educationhistory/.test(identity)) return "教育背景";
    if (/resumelanguage|foreignlanguage|languageinfo/.test(identity)) return "外语水平";
    if (/resumecontact|contactinfo|communicationinfo/.test(identity)) return "通讯信息";
    if (/resumeaward|awardinfo|honorinfo/.test(identity)) return "获奖信息";
    if (/resumequalification|qualificationinfo|certificateinfo/.test(identity)) return "其他资格";
    if (/resumebasic|basicinfo|personalinfo/.test(identity)) return "基本信息";
    return "";
  }

  function findSectionTitle(section, hints) {
    if (!section) return "";
    try {
      var selector = ((hints && hints.titleSelectors && hints.titleSelectors.length) ? hints.titleSelectors.join(",") + "," : "") + SECTION_TITLE_SELECTOR;
      var headings = Array.from(section.querySelectorAll(selector));
      var heading = firstVisibleText(headings, 80);
      if (heading) return heading;
    } catch (_) {}
    var explicit = normalizeText(section.getAttribute && (section.getAttribute("aria-label") || section.getAttribute("title")), 80);
    if (explicit) return explicit;
    return semanticTitleFromStableSectionIdentity(section);
  }

  function collectOptions(control, controlType) {
    var result = [];
    if (!control) return result;
    if (controlType === "native-select" && control.options) {
      Array.from(control.options).forEach(function (option) {
        var text = normalizeText(option && option.textContent, 60);
        if (text && result.indexOf(text) < 0) result.push(text);
      });
      return result.slice(0, 20);
    }

    if (controlType === "radio" || controlType === "radio-group") {
      var scope = controlType === "radio-group" ? control : (control.closest && control.closest("[role='radiogroup'],.ant-radio-group,.el-radio-group")) || control.parentElement;
      if (scope && scope.querySelectorAll) {
        try {
          Array.from(scope.querySelectorAll("label,.ant-radio-wrapper,.el-radio,[role='radio']")).forEach(function (node) {
            var text = normalizeText(node.textContent, 60);
            if (text && result.indexOf(text) < 0) result.push(text);
          });
        } catch (_) {}
      }
    }
    return result.slice(0, 20);
  }

  function requiredInfo(control, row) {
    var reasons = [];
    if (control && control.required) reasons.push("native_required");
    if (control && control.getAttribute && control.getAttribute("aria-required") === "true") reasons.push("aria_required");
    if (row && row.classList) {
      var cls = Array.from(row.classList || []).join(" ");
      if (/\brequired\b|is-required|ant-form-item-required/i.test(cls)) reasons.push("required_container_class");
    }
    return { required: reasons.length > 0, evidence: reasons };
  }

  function normalizeRoot(root) {
    if (root && root.querySelectorAll) return root;
    return global.document && global.document.body ? global.document.body : null;
  }

  function logicalControlHost(control, root) {
    if (!control || !control.closest) return control;
    var selector = [
      ".ant-select", ".el-select",
      ".ant-cascader-picker", ".el-cascader",
      ".ant-picker", ".ant-calendar-picker", ".el-date-editor", ".phoenix-date-picker",
      ".phoenix-select",
      ".phoenix-radio-group", ".ant-radio-group", ".el-radio-group", "[role='radiogroup']"
    ].join(",");
    try {
      var host = control.closest(selector);
      if (host && host !== control && isVisible(host) && (!root || host === root || (root.contains && root.contains(host)))) return host;
    } catch (_) {}
    return control;
  }

  function collectControls(root) {
    if (!root || !root.querySelectorAll) return [];
    try {
      var raw = Array.from(root.querySelectorAll(CONTROL_SELECTOR)).filter(isVisible);
      var seen = new Set();
      var result = [];
      raw.forEach(function (control) {
        var logical = logicalControlHost(control, root);
        if (!logical || seen.has(logical)) return;
        seen.add(logical);
        result.push(logical);
      });
      return result;
    } catch (_) {
      return [];
    }
  }

  function scan(root, options) {
    options = options || {};
    var doc = options.document || global.document;
    root = normalizeRoot(root);
    if (!root || !doc) {
      return {
        schemaType: "autofill-lite-form-graph",
        schemaVersion: SCHEMA_VERSION,
        graphVersion: VERSION,
        page: { hostname: "", pathname: "/" },
        totals: { sections: 0, rows: 0, controls: 0 },
        sections: [],
        controls: [],
        safety: { currentValuesIncluded: false, arbitraryRowTextIncluded: false, queryIncluded: false }
      };
    }

    var hints = resolveStructureHints();
    var controls = collectControls(root);
    var sectionMap = new Map();

    controls.forEach(function (control) {
      var sectionEl = findSectionContainer(control, root, hints);
      if (!sectionMap.has(sectionEl)) sectionMap.set(sectionEl, { el: sectionEl, controls: [] });
      sectionMap.get(sectionEl).controls.push(control);
    });

    var pathname = safePath(global.location && global.location.href || "/");
    var hostname = String(global.location && global.location.hostname || "");
    var sections = [];
    var flattened = [];

    Array.from(sectionMap.values()).forEach(function (sectionEntry) {
      if (!sectionEntry.controls.length) return;
      var sectionEl = sectionEntry.el;
      var sectionTitle = findSectionTitle(sectionEl, hints);
      var sectionSelector = stableSelector(sectionEl, doc);
      var sectionId = stableId("sec", [hostname, pathname, sectionSelector, sectionTitle]);
      var rowMap = new Map();

      sectionEntry.controls.forEach(function (control) {
        var rowEl = findRowContainer(control, sectionEl, hints);
        if (!rowMap.has(rowEl)) rowMap.set(rowEl, { el: rowEl, controls: [] });
        rowMap.get(rowEl).controls.push(control);
      });

      var rows = [];
      var rowSignatureCounts = new Map();
      var fieldSignatureCounts = new Map();
      Array.from(rowMap.values()).forEach(function (rowEntry) {
        var rowEl = rowEntry.el;
        var rowSelector = stableSelector(rowEl, doc);
        var primaryLabel = "";
        var controlNodes = rowEntry.controls;
        var rowSignatureBase = rowSelector || stableSelector(rowEl && rowEl.parentElement, doc) || "row";
        var rowOccurrenceIndex = Number(rowSignatureCounts.get(rowSignatureBase) || 0);
        rowSignatureCounts.set(rowSignatureBase, rowOccurrenceIndex + 1);
        var controlModels = controlNodes.map(function (control) {
          var controlType = detectControlType(control);
          var label = findLabel(control, rowEl, doc, hints);
          if (!primaryLabel && label) primaryLabel = label;
          var controlSelector = stableSelector(control, doc);
          var required = requiredInfo(control, rowEl);
          var fieldSignatureBase = [sectionId, rowSelector, label, controlSelector, controlType].join("|");
          var fieldOccurrenceIndex = Number(fieldSignatureCounts.get(fieldSignatureBase) || 0);
          fieldSignatureCounts.set(fieldSignatureBase, fieldOccurrenceIndex + 1);
          var fieldId = stableId("fld", [sectionId, rowSelector, label, controlSelector, controlType, "occ:" + fieldOccurrenceIndex]);
          var model = {
            fieldId: fieldId,
            occurrenceIndex: fieldOccurrenceIndex,
            selectorHint: controlSelector,
            label: label,
            tagName: String(control.tagName || "").toLowerCase(),
            inputType: String(control.type || (control.getAttribute && control.getAttribute("type")) || "").toLowerCase(),
            controlType: controlType,
            widgetFamily: detectWidgetFamily(control),
            placeholder: normalizeText(control.getAttribute && control.getAttribute("placeholder"), 80),
            name: safeAttr(control.getAttribute && control.getAttribute("name"), 80),
            required: required.required,
            requiredEvidence: required.evidence,
            options: collectOptions(control, controlType),
            rect: rectOf(control),
            currentValuePresent: !!(control && ((typeof control.value === "string" && control.value.length > 0) || control.checked === true))
          };
          flattened.push(model);
          return model;
        });
        var rowId = stableId("row", [sectionId, rowSelector, primaryLabel, "occ:" + rowOccurrenceIndex, controlModels.map(function (c) { return c.fieldId; }).join(",")]);
        controlModels.forEach(function (model) {
          model.sectionId = sectionId;
          model.sectionTitle = sectionTitle;
          model.rowId = rowId;
          model.rowLabel = primaryLabel;
        });
        rows.push({
          rowId: rowId,
          selectorHint: rowSelector,
          role: "field_row",
          label: primaryLabel,
          rect: rectOf(rowEl),
          controlCount: controlModels.length,
          controls: controlModels
        });
      });

      rows.sort(function (a, b) { return a.rect.y - b.rect.y || a.rect.x - b.rect.x || a.rowId.localeCompare(b.rowId); });
      sections.push({
        sectionId: sectionId,
        selectorHint: sectionSelector,
        title: sectionTitle,
        role: "form_section",
        rect: rectOf(sectionEl),
        rowCount: rows.length,
        controlCount: sectionEntry.controls.length,
        rows: rows
      });
    });

    sections.sort(function (a, b) { return a.rect.y - b.rect.y || a.rect.x - b.rect.x || a.sectionId.localeCompare(b.sectionId); });
    flattened.sort(function (a, b) {
      var sa = sections.findIndex(function (s) { return s.sectionId === a.sectionId; });
      var sb = sections.findIndex(function (s) { return s.sectionId === b.sectionId; });
      if (sa !== sb) return sa - sb;
      return a.rect.y - b.rect.y || a.rect.x - b.rect.x || a.fieldId.localeCompare(b.fieldId);
    });

    return {
      schemaType: "autofill-lite-form-graph",
      schemaVersion: SCHEMA_VERSION,
      graphVersion: VERSION,
      page: { hostname: hostname, pathname: pathname },
      totals: {
        sections: sections.length,
        rows: sections.reduce(function (sum, section) { return sum + section.rows.length; }, 0),
        controls: flattened.length
      },
      sections: sections,
      controls: flattened,
      structureHints: {
        source: hints.source || "generic",
        configName: safeAttr(hints.configName || "", 80),
        sectionSelectorCount: (hints.sectionSelectors || []).length,
        rowSelectorCount: (hints.rowSelectors || []).length,
        labelSelectorCount: (hints.labelSelectors || []).length
      },
      safety: {
        currentValuesIncluded: false,
        arbitraryRowTextIncluded: false,
        queryIncluded: false,
        fileContentIncluded: false
      }
    };
  }

  return {
    version: VERSION,
    schemaVersion: SCHEMA_VERSION,
    scan: scan,
    constants: {
      CONTROL_SELECTOR: CONTROL_SELECTOR,
      SECTION_CONTAINER_SELECTOR: SECTION_CONTAINER_SELECTOR,
      ROW_CONTAINER_SELECTOR: ROW_CONTAINER_SELECTOR
    },
    __test: {
      normalizeText: normalizeText,
      hashText: hashText,
      stableId: stableId,
      detectControlType: detectControlType,
      detectWidgetFamily: detectWidgetFamily,
      logicalControlHost: logicalControlHost,
      resolveStructureHints: resolveStructureHints
    }
  };
});
