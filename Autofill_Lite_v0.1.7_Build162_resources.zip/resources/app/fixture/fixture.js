(() => {
  const input = document.getElementById("school");
  const hidden = document.getElementById("school-id");
  const state = document.getElementById("school-state");
  let timer = null;
  let panel = null;

  function removePanel(){ if(panel){panel.remove(); panel=null;} }
  function showOptions(keyword){
    removePanel();
    if(!keyword) return;
    panel=document.createElement("div");
    panel.className="el-autocomplete-suggestion el-popper my-autocomplete";
    const ul=document.createElement("ul");
    [
      ["中国人民大学","RUC"],
      ["中国人民大学附属中学","RUC-HS"],
      ["中国人民大学苏州校区","RUC-SZ"]
    ].forEach(([name,id])=>{
      if(!name.includes(keyword) && !keyword.includes("中国人民大学")) return;
      const li=document.createElement("li");
      li.setAttribute("role","option");
      li.textContent=name;
      li.addEventListener("mouseenter",()=>li.dataset.highlighted="1");
      li.addEventListener("click",()=>{
        input.value=name; hidden.value=id; state.textContent=`已选择：${name} / ${id}`; removePanel();
        input.dispatchEvent(new Event("change",{bubbles:true}));
      });
      ul.appendChild(li);
    });
    panel.appendChild(ul);
    const r=input.getBoundingClientRect();
    panel.style.left=(r.left+window.scrollX)+"px";
    panel.style.top=(r.bottom+window.scrollY+3)+"px";
    panel.style.width=Math.max(r.width,320)+"px";
    document.body.appendChild(panel);
  }
  input.addEventListener("input",()=>{
    hidden.value=""; state.textContent="正在远程搜索…";
    clearTimeout(timer); timer=setTimeout(()=>showOptions(input.value.trim()),300);
  });
  input.addEventListener("blur",()=>setTimeout(()=>{if(!hidden.value){input.value="";state.textContent="未选择有效候选，已清空";} removePanel();},180));
})();
