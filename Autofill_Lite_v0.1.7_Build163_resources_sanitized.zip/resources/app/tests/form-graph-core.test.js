"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const manifest = JSON.parse(fs.readFileSync(path.join(root, "autofill-plugin", "manifest.json"), "utf8"));
const graphPath = path.join(root, "autofill-plugin", "content", "form-graph.js");
const source = fs.readFileSync(graphPath, "utf8");
const graph = require(graphPath);

assert(manifest.content_scripts[0].js.includes("content/form-graph.js"), "FormGraph must be injected");
assert(manifest.content_scripts[0].js.indexOf("content/form-graph.js") < manifest.content_scripts[0].js.indexOf("content/site-analysis-collector.js"), "FormGraph must load before SiteAnalysisCollector");
assert.strictEqual(graph.version, "1.3.0", "unexpected FormGraph version");
assert.strictEqual(graph.schemaVersion, 1, "unexpected FormGraph schema");
assert.strictEqual(typeof graph.scan, "function", "scan API missing");
assert(source.includes("section -> row -> control"), "structural graph contract missing");
assert(source.includes('role: "field_row"'), "field_row role missing");
assert(source.includes('currentValuesIncluded: false'), "privacy contract missing");
assert(source.includes('arbitraryRowTextIncluded: false'), "broad row text must remain excluded");
assert(source.includes('queryIncluded: false'), "query privacy contract missing");
assert(!source.includes("localStorage.setItem"), "FormGraph must be read-only");
assert(!/\.click\s*\(/.test(source), "FormGraph must not click");
assert(!/\.dispatchEvent\s*\(/.test(source), "FormGraph must not mutate controls");

const a = graph.__test.stableId("fld", ["示例资料", "学校名称", "#school"]);
const b = graph.__test.stableId("fld", ["示例资料", "学校名称", "#school"]);
const c = graph.__test.stableId("fld", ["示例资料", "专业名称", "#major"]);
assert.strictEqual(a, b, "stable IDs must be deterministic");
assert.notStrictEqual(a, c, "different field fingerprints should not share IDs");
assert.strictEqual(graph.__test.normalizeText("* 学校名称： (必填)"), "学校名称", "label normalization regression");

console.log("form graph core contract: PASS");
