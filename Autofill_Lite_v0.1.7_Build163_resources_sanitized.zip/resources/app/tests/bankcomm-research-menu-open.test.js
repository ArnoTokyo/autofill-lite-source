"use strict";
const fs = require("fs");
const path = require("path");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const 示例资料flow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-示例资料flow.js"), "utf8");

// A. Open the actual Ant3 cascader trigger, not just the outer wrapper.
const openStart = 示例资料flow.indexOf("async function openBankcommResearchCustomDropdown");
const openEnd = 示例资料flow.indexOf("\n  function findVisibleBankcommResearchDropdown", openStart);
assert(openStart !== -1 && openEnd > openStart, "A: research menu opener missing");
const openFn = 示例资料flow.slice(openStart, openEnd);
assert(openFn.includes('".ant-cascader-picker input"'), "A: cascader input trigger missing");
assert(openFn.includes('".ant-cascader-picker-label"'), "A: cascader label trigger missing");
assert(openFn.includes('".ant-select-selection"'), "A: Ant3 selection trigger missing");
assert(openFn.includes("clickCascaderElement(trigger, true)"), "A: full pointer/mousedown click sequence missing");

// B. Menu-open success is determined by the unique visible custom-research checkbox.
assert(openFn.includes("findVisibleBankcommResearchCheckbox(checkboxText)"), "B: checkbox visibility gate missing");
assert(示例资料flow.includes("resolveBankcommResearchPopupFromCheckbox"), "B: popup reverse ownership resolver missing");

// C. The custom transaction must use the opener before typing/submitting.
const fillStart = 示例资料flow.indexOf("async function fillBankcommResearchCustomValue");
const fillEnd = 示例资料flow.indexOf("\n  // 兴业银行学校名称", fillStart);
const fillFn = 示例资料flow.slice(fillStart, fillEnd);
assert(fillFn.includes("openBankcommResearchCustomDropdown(formItem, checkboxText, item)"), "C: custom filler does not use robust opener");
assert(fillFn.includes("research_custom_menu_not_opened"), "C: menu-open stage diagnostic missing");
assert(fillFn.includes("typeBankcommResearchCustomInputInPage"), "C: React input commit path regressed");
assert(fillFn.includes("fallbackSubmitButtonText"), "C: submit transaction regressed");

console.log("bankcomm-research-menu-open.test.js passed (A-C)");
