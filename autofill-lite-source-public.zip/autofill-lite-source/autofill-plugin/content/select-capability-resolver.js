// Build158 Select Capability Resolver
// 统一选择器能力判断入口。
// 不替代已有 SelectAdapter，只负责在调用前提供能力提示，避免站点代码散落。

(function () {
  "use strict";
  var AF = window.AF = window.AF || {};
  AF.SelectCapabilityResolver = AF.SelectCapabilityResolver || {};

  function safeClassName(el) {
    try {
      if (!el) return "";
      if (typeof el.className === "string") return el.className;
      if (el.className && el.className.baseVal) return el.className.baseVal;
      return Array.from(el.classList || []).join(" ");
    } catch (e) {
      return "";
    }
  }

  function resolve(element) {
    var cls = safeClassName(element).toLowerCase();
    var tag = String(element && element.tagName || "").toLowerCase();

    var searchable = !!(
      (element && element.getAttribute && (
        element.getAttribute("role") === "combobox" ||
        element.getAttribute("aria-haspopup") === "listbox"
      )) ||
      cls.indexOf("search") >= 0 ||
      cls.indexOf("select") >= 0 ||
      cls.indexOf("autocomplete") >= 0
    );

    var panel = !!(
      cls.indexOf("dropdown") >= 0 ||
      cls.indexOf("popover") >= 0 ||
      cls.indexOf("menu") >= 0 ||
      cls.indexOf("listbox") >= 0
    );

    return {
      tagName: tag,
      searchable: searchable,
      panelBased: panel,
      preferKeyboard: searchable,
      verifyAfterSelect: true
    };
  }

  AF.SelectCapabilityResolver.resolve = resolve;
})();
