# Autofill Lite v0.1.7

Autofill Lite is a local-only Electron/Chromium test shell for recruitment-form autofill. v0.1.7 keeps the known-示例资料ing v0.1.6 autofill baseline and adds a local personal-data maintenance 示例资料flow.

## Main 示例资料flow
1. Open a recruitment page in the built-in browser.
2. Click **一键填写**.
3. Review the result and any “资料库明确缺少 / 页面仍待处理” reminders.
4. Click **资料库** to edit existing facts or add new Q&A entries discovered on a website.
5. Click **岗位库** to save the current recruitment URL, name it, and organize it with nested folders.
5. Re-run autofill. Final save/submission is always manual.

## Profile editor
The **岗位库** is a local bookmark manager stored under `autofill-lite-data/bookmarks/bookmarks.json`. It supports named URLs, an optional free-form **状态** field (blank by default, no preset options), nested folders, search, rename, move, delete, and opening a saved URL back in the main Autofill Lite browser.

The **资料库** window reads and writes:

`autofill-lite-data/profile/candidate-profile-merged.json`

It supports:
- editing existing values in each profile section;
- adding a new structured field;
- adding 示例资料 records (示例资料/示例资料/etc.);
- adding arbitrary **question + answer** pairs to the custom Q&A bank.

Every save creates a timestamped backup in the same profile directory.

## Custom Q&A behavior
Unknown future questions should preferably be stored under **自定义问答**. The fallback is 示例资料ally conservative:
- normalized question text must match exactly;
- the target control must currently be empty;
- consent/privacy/declaration/background-check/final-submit prompts are excluded;
- the feature is a fallback for generic/示例资料/current-visible forms, not a replacement for site-specific 示例资料flow adapters.

## Missing-information feedback
After autofill the app distinguishes:
- **资料库明确缺少**: the Autofill Core explicitly reported that the resume/profile has no value for a required field;
- **页面仍待处理**: a required visible field is still empty. This can mean missing personal information or an autofill/control failure, so it is not automatically treated as a profile fact gap.

## Confirmed profile policies
- Education periods use Sep 1 as start date and Jun 30 as end date.
- The current finance master's and fiscal-studies bachelor's use `经济学` as the degree discipline category.
- Final submission and sensitive 示例资料 remain manual.

## Build 49: API-ready AI review contract

The **分析本站** pipeline now prepares review packets for a direct model API instead of a manual file round-trip.

The deterministic layer was tightened using the real Tencent and Zhaopin review packets:

- common aliases such as `证件号码类型 → idType`, `办学属地 → 示例资料.schoolAffiliation`, `学科属性 → 示例资料.majorCategory`, `个人绩点 → 示例资料.gpa`, CET-4/CET-6 fixed-score fields, 示例资料-示例资料 dates/descriptions, 示例资料/示例资料 company/name/description fields are now exact dictionary mappings;
- bad fuzzy anchors are removed before AI sees them, including boolean questions mapped to non-boolean keys and 示例资料 “score/level” fields anchored to `name`;
- ambiguous 示例资料ed date fields receive ordinal evidence and a conservative `startTime` / `endTime` suggestion instead of being silently trusted;
- unlabeled controls get a stable `fieldId`, structural tokens and a unique-selector patch target where available.

`ai-review__<host>__<path>.json` is now schema v2 and includes a normalized **profile contract**. Future API output must reference the stable `fieldId`; mapped category/key pairs must come from the contract, unknown keys are forbidden, and category correction is allowed when section detection was wrong.

The review packet still contains no resume values, current field values, URL query/hash, cookies/tokens/sessions, or nearby free text. No AI API and no original remote site-config server are enabled in this build.

### Build 50 AI contract hardening
AI review patch targets now exclude transient UI-state selectors. Ambiguous controls retain a stable fieldId and use field_id_only rather than a selector that can change after clicking.

### Build 51 AI API bridge

Build51 adds a direct provider API path for the local site analyzer. Use `AI设置` to configure an OpenAI Responses endpoint or an OpenAI-compatible Chat Completions endpoint, then run `分析本站` followed by `AI映射`. The API receives only the privacy-sanitized `ai-review v2` packet. A successful result is locally schema-validated and saved as `autofill-lite-data/site-analysis/ai-patch__<host>__<route>.json`.

API keys are never returned to the renderer. Electron `safeStorage` is used when available; 示例资料wise the key remains memory-only and must be re-entered after restart. Build51 deliberately stops before automatically applying the patch to Autofill Core so that the API transport and semantic contract can be tested independently.

### Build 52 DeepSeek / compatible-provider recovery

Build52 hardens the API transport after the first real DeepSeek Responses test returned text that Build51 could not parse as JSON. The parser now accepts a valid JSON object wrapped in Markdown fences or harmless surrounding prose, while still running the same strict local semantic-patch validator afterward.

For `api.deepseek.com` Responses endpoints the request follows DeepSeek's documented `json_schema` shape without the OpenAI-specific `strict` flag. If the first structured-output response still cannot be parsed or validated, Autofill Lite retries once using provider JSON-object mode and then applies the same local schema/fieldId/profileContract checks. Chat Completions endpoints on DeepSeek use `json_object` directly.

Final failures now create `autofill-lite-data/site-analysis/ai-error__<host>__<route>.json` with stage, provider/model, HTTP/result shape and a capped model-output preview. The API key and resume values are never written to this diagnostic. A successful retry removes the stale error file. If local analysis reports zero AI mapping gaps, `AI映射` skips the API call entirely.

### Build 53 local-first AI overlay

The first successful DeepSeek patches showed why a validated model response still must not be treated as an automatically trusted site adapter. Build53 compiles the raw patch into an `ai-candidate__<host>__<route>.json` runtime overlay and automatically applies only high-confidence, label-addressable semantic mappings. Selector-only/field-id-only mappings, low-confidence decisions, conflicting label mappings, and 示例资料-record subtype guesses remain audit-only.

**一键填写 is now local-first.** A matched special 示例资料flow, explicit local config, or built-in site config runs without an AI call. For a site without strong local support, Autofill Lite first checks for a cached validated candidate; if none exists it performs the local privacy-sanitized analysis. The API is called only when semantic gaps remain. A detected platform adapter can still be reused for widget operation while AI supplies only missing semantics.

AI output is installed only as an in-memory `AF.RuntimeSemanticPatch` for the current host/path and then executed by the existing Autofill Core. The raw AI patch never writes resume values or arbitrary page actions. After a local fill, failures are classified so semantic gaps are separated from profile-data gaps and control/示例资料flow failures; known adapters are not automatically rerun end-to-end with AI because doing so could duplicate 示例资料 experiences.

### Build 54 示例资料 flow reintegration

Build54 fixes an integration regression found after the new local-first router was tested on Tencent and the shared Zhaopin campus 示例资料flow. The router was correct: both sites should stay on local Core without an AI call. The failure was inside the local 示例资料 owner.

For Zhaopin campus pages, an existing saved 示例资料 card is no longer considered complete merely because its identity matches one profile row. Each uniquely matched saved card is reopened and audited/refilled by the existing Higher Education field sequence before the 示例资料flow continues to 示例资料, 示例资料 示例资料, 示例资料s, 示例资料s, and later sections. Missing records still use the Add path; ambiguous matches stop for review rather than overwriting an uncertain card.

For Tencent `join.qq.com` / `careers.qq.com`, the sequential 示例资料 executor now recognizes the site's real `.info_list` / `.experience_box` 示例资料 record scopes using multiple 示例资料-specific placeholder signals. This restores the dedicated sequential 示例资料 owner without reintroducing the old problem where multiple profile rows could share one DOM scope.

## Build55 Tencent single-pass routing fix

Build55 fixes a Tencent-only traversal regression exposed by the Build54 live smoke test. Tencent needs `labels.mergeFallback` so field scans can combine `.subtitle` with native/generic labels, but `ElementMatcher.findTitle()` was incorrectly using that **label** setting to append all field labels to the **section-title** list. Structured mode consequently ran the real `.send_title` modules and then revisited field labels as pseudo-modules, which could return to Basic Info and later flip already-filled experience sections to `无…经历`.

A configured title selector is now authoritative when it matches. Label fallback remains unchanged inside field scans. The Build54 示例资料 reintegration is preserved.

## Build57: AI selector current-section executor

Unknown static pages may now use validated AI mappings to fill safe scalar controls directly by stable selectors. This is a generic Core capability, not a CNPC site adapter. Repeat arrays and composite address controls remain gated for later 示例资料flow/control handling.

## Build58: read-only navigation discovery v2

The site analyzer can now passively detect resume-section navigation rails even when a recruitment site renders them with arbitrary `div/span/li` classes instead of semantic `nav/menu/tab` markup. The fallback is constrained to known resume-section titles, filters form labels, and requires either an interactive target or a nearby cluster of multiple section titles. It only records structure; it does not click, save, navigate, add records, or submit anything.

CNPC remains 示例资料ally unregistered as a local site adapter until the complete 示例资料flow is validated on the real site. Build58 also overwrites the old `cnpc-示例资料-config.test.js` filename so incremental ZIP overlays no longer leave a stale test that expects the removed provisional adapter.
