// content/date-picker/handlers/brick.js — Brick UI 日期选择器 (.brick-date-picker)
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   工厂分支 Kn.create() case "brick": 行 46018 -> oo
//   oo.setValue: 行 46749-46837 (调用 Te())
//   Te()/Ae() (直接清空+填入"年-月"文本, 无需点击日历面板): 行 35831-35904 — 已核实
//     注意: 源码按 "-" 切出日期串的前两段 (年,月)，即便传入完整 "年-月-日" 也只取年月两段填入，
//     Brick 这个日期字段本身就是"年月"粒度的输入框。
//   Pe()/Ce() (填完后如果还残留一个可见的 .brick-date-picker-panel-wrapper 弹层就把它隐藏掉): 行 35905-35936
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  function hideLingeringPanel() {
    try {
      var panel = document.querySelector('.brick-date-picker-panel-wrapper:not([style*="display: none"])');
      if (panel) panel.style.display = "none";
    } catch (e) {}
  }

  async function brickSingleNavigate(triggerEl, dateStr) {
    var input = triggerEl.querySelector("input");
    if (!input) throw new Error("未找到日期输入框元素");
    var parts = String(dateStr).split("-");
    if (parts.length < 2) throw new Error("日期格式不正确: " + dateStr);
    var year = parts[0];
    var month = parts[1];
    var combined = year + "-" + month;
    input.focus();
    await AF.Utils.sleep(100);
    input.value = "";
    input.dispatchEvent(new Event("input", { bubbles: true }));
    await AF.Utils.sleep(100);
    input.value = combined;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    await AF.Utils.sleep(50);
    input.dispatchEvent(new Event("change", { bubbles: true }));
    await AF.Utils.sleep(100);
    hideLingeringPanel();
    return input.value.includes(year) && input.value.includes(month);
  }

  AF.DatePicker._registry["brick"] = function (element, valueType) {
    return {
      setValue: async function (value) {
        try {
          if (!value) throw new Error("日期为空");
          if (typeof value === "string" || valueType === "string") {
            await brickSingleNavigate(element, value);
            return true;
          }
          if (typeof value !== "object" || !("startTime" in value) || !("endTime" in value)) {
            throw new Error("当option为对象时，dateValue必须包含startTime和endTime属性");
          }
          await brickSingleNavigate(element, value.startTime);
          await AF.Utils.sleep(500);
          var candidates = AF.DomUtils.findSimilarElements(element, 4, { sameTag: true, sameClass: true, sameParent: false });
          if (candidates.length > 0) {
            var best = AF.DatePicker._pickEndDateCandidate(element, candidates);
            await brickSingleNavigate(best, value.endTime);
          } else {
            var surrounding = AF.DomUtils.findSurroundingInputs(element);
            if (surrounding.length > 0) await brickSingleNavigate(surrounding[0], value.endTime);
          }
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
