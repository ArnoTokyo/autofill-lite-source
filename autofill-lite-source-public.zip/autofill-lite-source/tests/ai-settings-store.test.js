"use strict";
const assert = require("assert");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { AiSettingsStore, sanitizeEndpoint } = require("../ai-settings-store");

const dir = fs.mkdtempSync(path.join(os.tmpdir(), "af-ai-settings-"));
const file = path.join(dir, "ai-settings.json");
const fakeCrypto = {
  isAvailable: () => true,
  encrypt: (text) => Buffer.from("enc:" + text, "utf8"),
  decrypt: (buf) => String(buf).replace(/^enc:/, "")
};
const store = new AiSettingsStore(file, fakeCrypto);
let publicSettings = store.save({
  provider: "openai-responses",
  endpoint: "https://api.openai.com/v1/responses",
  model: "gpt-test",
  reasoningEffort: "low",
  maxOutputTokens: 5000,
  apiKey: "sk-secret-test"
});
assert.strictEqual(publicSettings.hasApiKey, true);
assert.strictEqual(publicSettings.apiKeyStorage, "encrypted");
assert.strictEqual(store.getApiKey(), "sk-secret-test");
const disk = fs.readFileSync(file, "utf8");
assert(!disk.includes("sk-secret-test"), "API key must never be stored plaintext");
store.save({ ...publicSettings, clearApiKey: true });
assert.strictEqual(store.getApiKey(), "");

const memoryFile = path.join(dir, "memory.json");
const memoryStore = new AiSettingsStore(memoryFile, { isAvailable: () => false });
publicSettings = memoryStore.save({ provider: "openai-responses", apiKey: "session-only" });
assert.strictEqual(publicSettings.apiKeyStorage, "memory");
assert.strictEqual(memoryStore.getApiKey(), "session-only");
assert(!fs.readFileSync(memoryFile, "utf8").includes("session-only"));

assert.strictEqual(sanitizeEndpoint("http://127.0.0.1:11434/v1/chat/completions", "openai-compatible-chat"), "http://127.0.0.1:11434/v1/chat/completions");
assert.throws(() => sanitizeEndpoint("http://example.com/v1", "openai-compatible-chat"), /HTTPS/);
console.log("ai-settings-store.test.js PASS");
