"use strict";
const assert = require("assert");
const fs = require("fs");
const os = require("os");
const path = require("path");

const root = path.resolve(__dirname, "..");

// Collector: Graph context must be able to promote a previously-unmapped static field
// using a high-confidence linked section, without touching trusted mappings.
global.window = {
  AF: {
    FieldDictionary: {
      示例资料Info: {
        labels: ["个人信息", "示例资料"],
        fields: { name: ["姓名", "名字"] }
      },
      示例资料: {
        labels: ["示例资料", "高等示例资料"],
        fields: { school: ["学校名称", "学校"] }
      }
    }
  }
};
global.document = { body: null, querySelectorAll: () => [] };
global.location = { href: "https://example.com/form", hostname: "example.com", pathname: "/form" };
const collectorPath = path.join(root, "autofill-plugin", "content", "site-analysis-collector.js");
delete require.cache[require.resolve(collectorPath)];
require(collectorPath);
const collector = global.window.AF.SiteAnalysisCollector;

const scan = {
  fields: [{
    label: "姓名",
    explicitLabel: "",
    formItemLabel: "姓名",
    ariaLabel: "",
    safeSemanticCandidates: ["姓名"],
    coreCategory: "",
    coreFieldKey: "",
    coreMappingStatus: "unmapped",
    graphSectionTitle: "个人信息",
    graphLinkConfidence: 0.99
  }]
};
const promoted = collector.applyGraphSemanticContext(scan, null);
assert.strictEqual(promoted, 1);
assert.strictEqual(scan.fields[0].coreCategory, "示例资料Info");
assert.strictEqual(scan.fields[0].coreFieldKey, "name");
assert.strictEqual(scan.fields[0].coreMappingStatus, "trusted");
assert(scan.fields[0].coreMappingMethod.startsWith("form_graph_context+"));

// AI packet: only unique, category-consistent interactive evidence should become
// first-class semantic evidence. Duplicate surfaces and mis-owned surfaces remain
// diagnostic only and must not contaminate mapping counts.
const {
  buildAiSiteInput,
  compactTrustedInteractiveModules
} = require("../site-analysis-ai-input");

function 示例资料Field() {
  return {
    section: "高等示例资料",
    label: "学校名称",
    labelSource: "form_item_label",
    safeSemanticCandidates: ["学校名称"],
    semanticCandidates: ["学校名称"],
    controlType: "element-autocomplete",
    widgetFamily: "element",
    selectorHint: "#school",
    selectorHitCount: 1,
    coreCategory: "示例资料",
    coreFieldKey: "school",
    coreMappingStatus: "trusted",
    coreMappingMethod: "dictionary_exact_alias",
    coreMappingConfidence: 1,
    coreMappingReasons: [],
    graphFieldId: "fld_graph_school",
    graphSectionId: "sec_示例资料",
    graphSectionTitle: "高等示例资料",
    graphRowId: "row_school",
    graphRowLabel: "学校名称",
    graphLinkMethod: "unique_control_selector",
    graphLinkConfidence: 1
  };
}

function 示例资料Fields() {
  const school = 示例资料Field();
  const level = Object.assign({}, 示例资料Field(), {
    label: "学历", safeSemanticCandidates: ["学历"], semanticCandidates: ["学历"],
    selectorHint: "#level", coreFieldKey: "level", graphFieldId: "fld_graph_level",
    graphRowId: "row_level", graphRowLabel: "学历"
  });
  return [school, level];
}

const interactive = {
  modules: [
    {
      title: "高等示例资料 必填",
      actionType: "edit",
      actionText: "编辑",
      surfaceType: "inline",
      scan: { fields: 示例资料Fields() },
      formGraph: { schemaType: "autofill-lite-form-graph", schemaVersion: 1, graphVersion: "1.3.0", totals: { sections: 1, rows: 1, controls: 1 }, sections: [], controls: [], safety: { currentValuesIncluded: false, arbitraryRowTextIncluded: false, queryIncluded: false } },
      graphCoverage: { staticControlCount: 1, graphControlCount: 1, linkedStaticFieldCount: 1, unlinkedStaticFieldCount: 0, graphOnlyControlCount: 0, linkedRatio: 1 }
    },
    {
      title: "高等示例资料 必填添加",
      actionType: "edit",
      actionText: "编辑",
      surfaceType: "inline",
      scan: { fields: 示例资料Fields() },
      formGraph: { schemaType: "autofill-lite-form-graph", schemaVersion: 1, graphVersion: "1.3.0", totals: { sections: 1, rows: 1, controls: 1 }, sections: [], controls: [], safety: { currentValuesIncluded: false, arbitraryRowTextIncluded: false, queryIncluded: false } },
      graphCoverage: { staticControlCount: 1, graphControlCount: 1, linkedStaticFieldCount: 1, unlinkedStaticFieldCount: 0, graphOnlyControlCount: 0, linkedRatio: 1 }
    },
    {
      title: "个人信息",
      actionType: "edit",
      actionText: "编辑",
      surfaceType: "inline",
      scan: { fields: 示例资料Fields() },
      formGraph: { schemaType: "autofill-lite-form-graph", schemaVersion: 1, graphVersion: "1.3.0", totals: { sections: 1, rows: 1, controls: 1 }, sections: [], controls: [], safety: { currentValuesIncluded: false, arbitraryRowTextIncluded: false, queryIncluded: false } },
      graphCoverage: { staticControlCount: 1, graphControlCount: 1, linkedStaticFieldCount: 1, unlinkedStaticFieldCount: 0, graphOnlyControlCount: 0, linkedRatio: 1 }
    }
  ]
};

const compact = compactTrustedInteractiveModules(interactive);
assert.strictEqual(compact.length, 3);
assert.strictEqual(compact[0].trusted, true);
assert.strictEqual(compact[1].trusted, false);
assert.strictEqual(compact[1].duplicateOfIndex, 0);
assert.strictEqual(compact[2].trusted, false);
assert.strictEqual(compact[2].categoryMismatch, true);
assert.strictEqual(compact[2].expectedCategory, "示例资料Info");
assert.strictEqual(compact[2].dominantCategory, "示例资料");

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "af-interactive-ai-"));
const bundleFile = path.join(tmp, "bundle__example.com__resume.json");
const bundle = {
  schemaType: "autofill-lite-site-analysis-bundle",
  schemaVersion: 1,
  hostname: "example.com",
  pathname: "/resume",
  observed: { sections: [], navigationItems: ["高等示例资料"], controlTypes: [] },
  snapshots: [{
    fingerprint: "interactive-only",
    at: "2026-09-16T00:00:00Z",
    analysis: {
      schemaVersion: 6,
      configProbe: { serverConfigEnabled: false, builtInConfig: { name: "example", type: "structured" }, specialWorkflowId: "" },
      staticScan: { controlCount: 0, sections: [], fields: [] },
      formGraph: { schemaType: "autofill-lite-form-graph", schemaVersion: 1, graphVersion: "1.3.0", totals: { sections: 0, rows: 0, controls: 0 }, sections: [], controls: [], safety: { currentValuesIncluded: false, arbitraryRowTextIncluded: false, queryIncluded: false } },
      graphCoverage: { staticControlCount: 0, graphControlCount: 0, linkedStaticFieldCount: 0, unlinkedStaticFieldCount: 0, graphOnlyControlCount: 0, linkedRatio: 1 },
      graphDiagnostics: { available: true, source: "document_body", graphVersion: "1.3.0", schemaVersion: 1, sectionCount: 0, rowCount: 0, controlCount: 0, linkedRatio: 1, privacySafe: true },
      navigation: { items: [] },
      interactive
    }
  }]
};
fs.writeFileSync(bundleFile, JSON.stringify(bundle, null, 2));
const result = buildAiSiteInput(bundleFile, "https://example.com/resume", tmp);
const out = JSON.parse(fs.readFileSync(result.file, "utf8"));
assert.strictEqual(out.snapshots.length, 1);
assert.strictEqual(out.snapshots[0].interactiveModules.length, 3);
assert.strictEqual(out.snapshots[0].interactiveModules.filter((m) => m.trusted).length, 1);
assert.strictEqual(out.mappingSummary.trustedInteractiveModuleCount, 1);
assert.strictEqual(out.mappingSummary.rejectedInteractiveModuleCount, 2);
assert.strictEqual(out.mappingSummary.totalFields, 2);
assert.strictEqual(out.mappingSummary.trustedCoreMappedFieldCount, 2);

console.log("mature interactive evidence bridge regression: PASS");
