"use strict";
const assert = require("assert");
const { normalizeProfileBackup } = require("../profile-adapter");

const raw = { profileV2: { sections: {
  basic: { values: { "姓名": "测试用户" } },
  intention: { items: [] },
  education: { items: [
    { values: { "学校": "A大学", "学历": "本科", "专业": "财政学", "专业描述": "应用经济学专业", "开始时间": "2021-09", "结束时间": "2025-06" } },
    { values: { "学校": "B大学", "学历": "硕士", "专业": "金融（专硕）", "开始时间": "2025-09", "结束时间": "2027-06" } },
    { values: { "学校": "C大学", "学历": "硕士", "专业": "计算机科学", "学位所属学科门类": "工学", "开始时间": "2024-09", "结束时间": "2026-06" } }
  ] },
  internship: { items: [] }, project: { items: [] }, student: { items: [] }, awards: { items: [] }, language: { items: [] }, family: { items: [] },
  self: { values: {} }, other: { values: {} }
} } };

const out = normalizeProfileBackup(raw);
const bySchool = Object.fromEntries(out.education.map((row) => [row.school, row]));
assert.strictEqual(bySchool["A大学"].majorCategory, "经济学");
assert.strictEqual(bySchool["B大学"].majorCategory, "经济学");
assert.strictEqual(bySchool["C大学"].majorCategory, "工学");
console.log("education-discipline-policy tests: PASS");
