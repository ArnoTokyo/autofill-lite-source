"use strict";
const assert = require("assert");
const { buildValueReview, buildLocalValueCandidatePatch, classifyValueCandidates } = require("../ai-value-candidate");

const review = { reviewFields: [
  { fieldId: "salary", label: "期望薪资", patchTarget: { kind: "semantic_label", label: "期望薪资" } },
  { fieldId: "degree", label: "学位", patchTarget: { kind: "semantic_label", label: "学位" } }
] };
const semanticPatch = { decisions: [
  { fieldId: "salary", decision: "map", category: "jobIntention", fieldKey: "expectedSalary", confidence: 0.9 },
  { fieldId: "degree", decision: "map", category: "education", fieldKey: "degreeSimple", confidence: 0.9 }
] };
const profile = {
  jobIntention: { salary: "20k" },
  education: [{ degreeDetailed: "经济学硕士" }]
};
const vr = buildValueReview(review, semanticPatch, profile);
const local = buildLocalValueCandidatePatch(vr);
assert.ok(local.decisions.some(x => x.fieldId === "salary" && x.value === "20k"), "scalar alias should be locally derived");
assert.ok(local.decisions.some(x => x.fieldId === "degree" && x.value === "硕士"), "degree normalization should be locally derived");

const manualReview = { targets: [
  { candidateId: "s", fieldId: "s", category: "basicInfo", fieldKey: "selfIntroduction", repeatRecord: false },
  { candidateId: "r", fieldId: "r", category: "education", fieldKey: "degreeSimple", repeatRecord: true, recordIndex: 0 },
  { candidateId: "h", fieldId: "h", category: "basicInfo", fieldKey: "email", repeatRecord: false },
  { candidateId: "n", fieldId: "n", category: "jobIntention", fieldKey: "expectedSalary", repeatRecord: false }
] };
const candidatePatch = { decisions: [
  { candidateId: "s", decision: "candidate", value: "生成的新文本", mode: "synthesize", confidence: 0.99 },
  { candidateId: "r", decision: "candidate", value: "硕士", mode: "normalize", confidence: 0.99 },
  { candidateId: "h", decision: "candidate", value: "x@example.com", mode: "extract", confidence: 0.99 },
  { candidateId: "n", decision: "candidate", value: "20k", mode: "normalize", confidence: 0.86 }
] };
const semanticGate = { executableCandidates: [{ fieldId: "s" }, { fieldId: "h" }, { fieldId: "n" }] };
const gate = classifyValueCandidates(manualReview, candidatePatch, semanticGate);
assert.ok(gate.reviewOnlyCandidates.some(x => x.candidateId === "s" && x.reasons.includes("synthesized_text_requires_review")));
assert.ok(gate.reviewOnlyCandidates.some(x => x.candidateId === "r" && x.reasons.includes("repeat_record_value_candidate_requires_recordgraph_owner")));
assert.ok(gate.reviewOnlyCandidates.some(x => x.candidateId === "h" && x.reasons.includes("high_risk_value_candidate_requires_review")));
assert.ok(gate.executableCandidates.some(x => x.candidateId === "n"), "safe scalar extract/normalize >=0.70 should enter Core");
assert.strictEqual(gate.policy.synthesizeAutoFillAllowed, false);
assert.strictEqual(gate.policy.repeatRecordOwnerByAi, false);
console.log("build159-value-candidate.test.js PASS");
