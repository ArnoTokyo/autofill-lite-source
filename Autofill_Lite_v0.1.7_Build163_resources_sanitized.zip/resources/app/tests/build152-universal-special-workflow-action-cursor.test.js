"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const 示例资料flowSource = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-示例资料flow.js"), "utf8");
const privateSourceRaw = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");

assert(/const BUILD_ID = \"202609\d{2}-[^\"]+-(?:15[2-9]|1[6-9]\d|[2-9]\d{2,})\";/.test(main), "A: Build152+ id missing");
assert(示例资料flowSource.includes("function 示例资料flowHasDeterministicActionSequence"), "B: structural 示例资料flow capability helper missing");
assert(示例资料flowSource.includes("function shouldPersistRecoveryCheckpoint"), "B: safe checkpoint persistence gate missing");
assert(示例资料flowSource.includes("function deriveSingleFailureSequenceCursor"), "C: single-failure fallback cursor missing");
assert(示例资料flowSource.includes("fallbackDerivedFromSingleFailure: true"), "C: fallback cursor diagnostic missing");
assert(示例资料flowSource.includes("shouldPersistRecoveryCheckpoint(示例资料flow, candidateFailureContext)"), "D: generalized persistence gate not wired into failure path");
assert(示例资料flowSource.includes('return legacyRecoveryCheckpointWorkflow(示例资料flow) || 示例资料flowHasDeterministicActionSequence(示例资料flow);'), "E: supported recovery must combine legacy compatibility with structural capability");

// Load the public helper surface without running timers.
global.HTMLElement = function(){};
global.Element = function(){};
global.document = {
  body: {},
  documentElement: { getAttribute() { return null; }, setAttribute() {}, removeAttribute() {} },
  querySelectorAll() { return []; },
  querySelector() { return null; }
};
global.window = {
  AF: {}, top: null,
  location: { hostname: "test", pathname: "/", href: "https://test/" },
  getComputedStyle() { return { display: "block", visibility: "visible", cursor: "default", zIndex: "0" }; },
  sessionStorage: { getItem() { return null; }, removeItem() {} },
  postMessage() {}
};
window.top = window;
const realSetTimeout = global.setTimeout;
global.setTimeout = () => 0;
new Function(示例资料flowSource)();
global.setTimeout = realSetTimeout;
const api = window.AF.SpecialSiteWorkflow._test;

const genericWorkflow = {
  id: "generic-bank",
  steps: [{ name: "奖项", fieldSequence: [{ field: "name" }, { field: "date" }] }]
};
assert.strictEqual(api.supportedRecoveryCheckpointWorkflow(genericWorkflow), true, "F: deterministic 示例资料flow must get action-cursor recovery");
assert.strictEqual(api.supportedRecoveryCheckpointWorkflow({ id: "opaque", steps: [{ customFill: "opaque" }] }), false, "F: opaque 示例资料flow must not be generalized");
assert.strictEqual(api.supportedRecoveryCheckpointWorkflow({ id: "off", disableActionCursorCheckpoint: true, steps: [{ fieldSequence: [{ field: "x" }] }] }), false, "F: explicit opt-out must win");
assert.strictEqual(api.shouldPersistRecoveryCheckpoint(genericWorkflow, { recoverability: "RECOVERABLE_MANUAL", actionCursor: null }), false, "G: generalized 示例资料flow must not save an unproven whole-step checkpoint");
assert.strictEqual(api.shouldPersistRecoveryCheckpoint(genericWorkflow, { recoverability: "RECOVERABLE_MANUAL", actionCursor: { nextAction: "SAVE" } }), true, "G: proven cursor must be persistable");
assert.strictEqual(api.shouldPersistRecoveryCheckpoint(genericWorkflow, { recoverability: "UNSAFE_STOP", actionCursor: { nextAction: "SAVE" } }), false, "G: unsafe stop must never become resumable");

const step = {
  __afCheckpointActionCursorEnabled: true,
  fieldSequence: [
    { field: "awardName", label: "奖项名称" },
    { field: "awardDate", label: "获奖时间" },
    { field: "grantor", label: "授予单位" }
  ]
};
const result = { failedFields: [{ fieldKey: "awardDate", label: "获奖时间", reason: "日期失败" }] };
const cursor = api.deriveSingleFailureSequenceCursor(step, result);
assert(cursor, "H: exactly one failed deterministic action must derive a cursor");
assert.strictEqual(cursor.currentAction, "FIELD:awardDate:1", "H: cursor current action mismatch");
assert.strictEqual(cursor.nextAction, "SAVE", "H: fallback recovery must freeze all already-attempted actions and go to SAVE");
assert.strictEqual(cursor.resumeFieldIndex, 3, "H: fallback resume index must be end of sequence");
assert.strictEqual(api.deriveSingleFailureSequenceCursor(step, { failedFields: [{ fieldKey: "awardDate" }, { fieldKey: "grantor" }] }), null, "H: multiple failures must not guess a fallback cursor");

// Audit current private registry: every deterministic 示例资料flow must be covered by
// the structural rule, without maintaining a site-by-site whitelist.
let privateSource = privateSourceRaw.replace("  deepFreeze(entries);", "  window.__entries = entries;\n  deepFreeze(entries);");
const sandbox = {
  window: { AF: {} },
  document: { body: { innerText: "", textContent: "", querySelectorAll() { return []; } }, querySelector() { return null; } },
  URL, Object, Array, String, RegExp, Number, Boolean, Math, Date, console
};
vm.createContext(sandbox);
vm.runInContext(privateSource, sandbox, { timeout: 5000 });
const entries = sandbox.window.__entries || [];
function hasSequence(step) {
  return ["fieldSequence", "rowFieldSequence", "preFieldSequence", "extraFieldSequence"].some(k => Array.isArray(step && step[k]) && step[k].length > 0);
}
const capable = entries.filter(entry => ((entry.示例资料flow && entry.示例资料flow.steps) || []).some(hasSequence));
assert(capable.length >= 20, "I: expected broad deterministic private-示例资料flow coverage");
const ids = capable.map(entry => entry.示例资料flow && entry.示例资料flow.id || entry.id);
[
  "iguopin-resume-v1", "spdb-recruitment", "citicbank-recruitment", "sf-express-campus-resume",
  "huawei-campus-resume", "hsbank-recruitment", "bankcomm-recruitment", "pingan-talent-resume",
  "pingan-campus-resume", "job51-resume-center", "czbank-recruitment", "zhaopin-campus-resume",
  "icbc-recruitment", "abc-recruitment", "ccb-recruitment", "cmbchina-recruitment",
  "cib-recruitment", "cmbc-recruitment"
].forEach(id => assert(ids.includes(id), "I: deterministic 示例资料flow missing from audit: " + id));

console.log("build152-universal-special-示例资料flow-action-cursor.test.js passed (A-I), deterministic 示例资料flows=" + capable.length);
