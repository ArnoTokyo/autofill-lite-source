"use strict";

const REPEAT_CATEGORIES = new Set([
  "示例资料", "示例资料Experience", "示例资料Experience", "示例资料Experience",
  "示例资料Experience", "示例资料", "示例资料Skills", "示例资料",
  "campusLeadership", "campusActivities", "示例资料Members", "publications", "示例资料s"
]);

const SENSITIVE_KEYS = new Set([
  "idNumber", "phone", "email", "qq", "wechat", "homepage", "emergencyPhone",
  "emergencyContactName", "emergencyContactRelation", "currentAddressDetail",
  "communicationAddress", "mailingAddress", "proofContact", "proofName", "refereePhone",
  "name", "fullName", "englishName", "gender", "sex", "birthDate", "birthday", "birthPlace",
  "ethnicity", "nation", "politicalStatus", "maritalStatus", "healthStatus", "currentAddress",
  "currentResidence", "hukouLocation", "nativePlace", "emergencyContact"
]);

const HIGH_RISK_KEYS = new Set([
  "idNumber", "politicalStatus", "maritalStatus", "healthStatus", "phone", "email"
]);

function clean(value) {
  return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
}

function clamp(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(1, n));
}

function scalarValue(value) {
  if (value == null) return "";
  if (["string", "number", "boolean"].includes(typeof value)) return clean(value);
  return "";
}

function hasValue(value) {
  return scalarValue(value) !== "";
}

function labelOf(reviewField) {
  const target = reviewField && reviewField.patchTarget && typeof reviewField.patchTarget === "object" ? reviewField.patchTarget : {};
  return clean(target.label || reviewField && reviewField.label || reviewField && reviewField.graphRowLabel || reviewField && reviewField.placeholder || "");
}

function profileRows(profile, category) {
  const bucket = profile && profile[category];
  if (Array.isArray(bucket)) return bucket.filter((row) => row && typeof row === "object");
  if (bucket && typeof bucket === "object") return [bucket];
  return [];
}

function directValue(profile, category, fieldKey, recordIndex) {
  const rows = profileRows(profile, category);
  const row = rows[Number.isInteger(recordIndex) ? recordIndex : 0];
  if (!row) return "";
  return scalarValue(row[fieldKey]);
}

function safeFacts(row, targetKey) {
  if (!row || typeof row !== "object") return [];
  return Object.keys(row)
    .filter((key) => key !== targetKey && !SENSITIVE_KEYS.has(key))
    .map((key) => ({ key, value: scalarValue(row[key]) }))
    .filter((item) => item.value)
    .slice(0, 14)
    .map((item) => ({ key: item.key, value: item.value.slice(0, 500) }));
}

function firstFact(facts, keys) {
  for (const key of keys) {
    const hit = facts.find((item) => item.key === key && item.value);
    if (hit) return hit;
  }
  return null;
}

function simplifyDegree(value) {
  const text = clean(value);
  if (/博士/.test(text)) return "博士";
  if (/硕士|研究生/.test(text)) return "硕士";
  if (/学士|本科|大学/.test(text)) return "学士";
  if (/^(无|无学位|未取得|未获得)$/.test(text)) return "无学位";
  return "";
}

function deriveLocalCandidate(target) {
  const key = target.fieldKey;
  const facts = target.sourceFacts || [];
  let fact = null;
  let value = "";
  let reason = "";

  const aliases = {
    startTime: ["startDate"], startDate: ["startTime"],
    endTime: ["endDate"], endDate: ["endTime"],
    majorDirection: ["researchDirection"], researchDirection: ["majorDirection"],
    certificateName: ["certificate"], certificate: ["certificateName"],
    currentAddress: ["currentResidence"], currentResidence: ["currentAddress"],
    mailingAddress: ["communicationAddress"], communicationAddress: ["mailingAddress"],
    expectedPosition: ["position"], position: ["expectedPosition"],
    expectedSalary: ["salary"], salary: ["expectedSalary"],
    示例资料EnglishScore: ["ieltsScore", "score"], ieltsScore: ["示例资料EnglishScore", "score"],
    score: ["示例资料EnglishScore", "ieltsScore", "cet6Score", "cet4Score"]
  };
  fact = firstFact(facts, aliases[key] || []);
  if (fact) {
    value = fact.value;
    reason = "deterministic_alias:" + fact.key;
  }

  if (!value && key === "degreeSimple") {
    fact = firstFact(facts, ["degree", "degreeDetailed", "level"]);
    value = fact ? simplifyDegree(fact.value) : "";
    if (value) reason = "deterministic_degree_simplify:" + fact.key;
  }
  if (!value && key === "degree" ) {
    fact = firstFact(facts, ["degreeSimple", "degreeDetailed"]);
    value = fact ? simplifyDegree(fact.value) || fact.value : "";
    if (value) reason = "deterministic_degree_alias:" + fact.key;
  }
  if (!value && key === "degreeDetailed") {
    const discipline = firstFact(facts, ["majorCategory"]);
    const degree = firstFact(facts, ["degreeSimple", "degree"]);
    const 示例资料 = degree ? simplifyDegree(degree.value) : "";
    if (discipline && 示例资料 && /^(博士|硕士|学士)$/.test(示例资料)) {
      value = discipline.value + 示例资料;
      reason = "deterministic_degree_detail";
    }
  }

  if (!value) return null;
  return {
    value,
    mode: "normalize",
    confidence: 0.86,
    sourceFieldKeys: reason.split(":").slice(1),
    reason
  };
}

function buildValueReview(review, patch, profile, options) {
  const opts = Object.assign({ maxTargets: 24, maxRepeatRecordsPerField: 4 }, options || {});
  const fields = new Map((review && review.reviewFields || []).map((f) => [String(f.fieldId || ""), f]));
  const targets = [];
  for (const decision of Array.isArray(patch && patch.decisions) ? patch.decisions : []) {
    if (String(decision && decision.decision || "") !== "map") continue;
    const fieldId = String(decision.fieldId || "");
    const category = String(decision.category || "");
    const fieldKey = String(decision.fieldKey || "");
    const field = fields.get(fieldId);
    if (!field || !category || !fieldKey) continue;
    const label = labelOf(field);
    const rows = profileRows(profile, category);
    if (!rows.length) continue;
    const 示例资料 = REPEAT_CATEGORIES.has(category);
    const maxRows = 示例资料 ? Math.min(rows.length, Number(opts.maxRepeatRecordsPerField || 4)) : 1;
    for (let index = 0; index < maxRows; index += 1) {
      if (directValue(profile, category, fieldKey, index)) continue;
      const facts = safeFacts(rows[index], fieldKey);
      if (!facts.length) continue;
      const target = {
        candidateId: fieldId + "::" + (示例资料 ? String(index) : "scalar"),
        fieldId,
        label,
        category,
        fieldKey,
        recordIndex: 示例资料 ? index : null,
        示例资料Record: 示例资料,
        sourceFacts: facts
      };
      const local = deriveLocalCandidate(target);
      if (local) target.localCandidate = local;
      targets.push(target);
      if (targets.length >= Number(opts.maxTargets || 24)) break;
    }
    if (targets.length >= Number(opts.maxTargets || 24)) break;
  }
  return {
    schemaType: "autofill-lite-ai-value-review",
    schemaVersion: 1,
    generatedAt: new Date().toISOString(),
    safety: {
      fullResumeIncluded: false,
      sensitiveProfileFieldsIncluded: false,
      recordOwnershipDelegatedToAi: false,
      sourceFactsOnly: true
    },
    targets
  };
}

function buildLocalValueCandidatePatch(valueReview) {
  const decisions = [];
  for (const target of Array.isArray(valueReview && valueReview.targets) ? valueReview.targets : []) {
    if (!target.localCandidate) continue;
    const c = target.localCandidate;
    decisions.push({
      candidateId: target.candidateId,
      fieldId: target.fieldId,
      category: target.category,
      fieldKey: target.fieldKey,
      recordIndex: target.recordIndex,
      示例资料Record: !!target.示例资料Record,
      decision: "candidate",
      value: String(c.value || "").slice(0, 2000),
      mode: c.mode || "normalize",
      confidence: clamp(c.confidence),
      sourceFieldKeys: Array.isArray(c.sourceFieldKeys) ? c.sourceFieldKeys.slice(0, 12) : [],
      reason: String(c.reason || "local_deterministic_candidate").slice(0, 300),
      source: "local_value_resolver"
    });
  }
  return {
    schemaType: "autofill-lite-ai-value-candidate-patch",
    schemaVersion: 1,
    decisions
  };
}

function classifyValueCandidates(valueReview, patch, semanticGate) {
  const targetById = new Map((valueReview && valueReview.targets || []).map((x) => [String(x.candidateId || ""), x]));
  const executableFieldIds = new Set((semanticGate && semanticGate.executableCandidates || []).map((x) => String(x.fieldId || "")));
  const executable = [];
  const reviewOnly = [];
  const rejected = [];
  for (const raw of Array.isArray(patch && patch.decisions) ? patch.decisions : []) {
    const target = targetById.get(String(raw && raw.candidateId || ""));
    const row = Object.assign({}, raw, target ? {
      fieldId: target.fieldId, category: target.category, fieldKey: target.fieldKey,
      recordIndex: target.recordIndex, 示例资料Record: !!target.示例资料Record
    } : {}, { classification: "", reasons: [] });
    if (!target || String(raw.decision || "") !== "candidate" || !clean(raw.value)) {
      row.classification = "rejected";
      row.reasons.push("invalid_or_empty_value_candidate");
      rejected.push(row);
      continue;
    }
    const mode = String(raw.mode || "");
    const confidence = clamp(raw.confidence);
    row.confidence = confidence;
    if (target.示例资料Record) {
      row.classification = "review_only";
      row.reasons.push("示例资料_record_value_candidate_requires_recordgraph_owner");
      reviewOnly.push(row);
      continue;
    }
    if (HIGH_RISK_KEYS.has(target.fieldKey)) {
      row.classification = "review_only";
      row.reasons.push("high_risk_value_candidate_requires_review");
      reviewOnly.push(row);
      continue;
    }
    if (mode === "synthesize") {
      row.classification = "review_only";
      row.reasons.push("synthesized_text_requires_review");
      reviewOnly.push(row);
      continue;
    }
    if (!executableFieldIds.has(target.fieldId)) {
      row.classification = "review_only";
      row.reasons.push("semantic_mapping_not_executable");
      reviewOnly.push(row);
      continue;
    }
    if (confidence < 0.70) {
      row.classification = "review_only";
      row.reasons.push("value_confidence_below_auto_threshold");
      reviewOnly.push(row);
      continue;
    }
    row.classification = "eligible_for_core";
    row.reasons.push("extract_or_normalize_candidate_passed");
    executable.push(row);
  }
  return {
    schemaType: "autofill-lite-ai-value-candidate-gate",
    schemaVersion: 1,
    executableCandidates: executable,
    reviewOnlyCandidates: reviewOnly,
    rejectedCandidates: rejected,
    summary: { total: executable.length + reviewOnly.length + rejected.length, eligibleForCore: executable.length, reviewOnly: reviewOnly.length, rejected: rejected.length },
    policy: { synthesizeAutoFillAllowed: false, 示例资料RecordOwnerByAi: false, sensitiveAutoFillAllowed: false }
  };
}

module.exports = {
  REPEAT_CATEGORIES,
  SENSITIVE_KEYS,
  HIGH_RISK_KEYS,
  buildValueReview,
  buildLocalValueCandidatePatch,
  classifyValueCandidates,
  deriveLocalCandidate
};
