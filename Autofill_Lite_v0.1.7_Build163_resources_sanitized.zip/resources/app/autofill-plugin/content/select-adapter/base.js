// content/select-adapter/base.js — 下拉选择器适配器公共基础设施
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   SelectAdapter 基类 (混淆名 f, 模块7830):        行 23347-23596
//   isOptionMatch / findVisibleDropdownNear /
//   waitForVisibleDropdownNear / selectMatchingOption /
//   simulateClick / safeScrollIntoView (混淆名 aZ, 模块744): 行 2913-3450 附近
//   全局框架选择器配置表 (混淆名 n.n, 模块9772):     行 56205-56298
//   triggerGenericSelect / triggerChakraSelect (模块3620): 行 14586-14685
//
// 改造点: 18 个适配器共用的"点击展开 → 等面板 → 找选项 → 点击 → 关闭"模板
// 抽成这里的静态辅助函数，每个 adapters/*.js 只需要提供框架特定的选择器/开面板方式。
// 下拉面板绝大多数情况下会被 portal 到 document.body，而不是嵌套在 select 容器内部，
// 所以这里所有的"找面板/找选项"辅助函数默认都搜索整个 document，而不是只搜索 element 内部。
//
// 示例资料 更新: isOptionMatch 之前是"学历特判+includes+isSimilarText"的简化版，遗漏了
// 源码里 GPA/薪资区间匹配、CET四六级匹配、获奖等级匹配这一整套规则匹配子系统 (源码模块744
// 类k, 见 content/utils.js 顶部注释)。现已把完整算法移植进 AF.DomUtils，这里的 isOptionMatch
// 改为直接转调 AF.DomUtils.isOptionMatch；clickBestMatch 还新增了第4级 Jaro-Winkler 智能
// 兜底 (AF.DomUtils.intelligentOptionMatch)，对应源码 selectMatchingOption 在规则匹配全部
// 失败后的兜底路径。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};

  // ============ 框架选择器配置表 (源码模块9772, 行56209-56297) ============
  // 源码定位手册 6.5 给出了 ant / element 两个精确条目，这里补全其余全部框架条目
  // (与源码 n.n 常量逐字段核对一致)。
  SA._config = {
    kuma: {
      container: ".kuma-select2-selection",
      trigger: ".kuma-select2-selection_rendered",
      dropdown: ".kuma-select2-dropdown-menu-item",
      selected: ".kuma-select2-selected",
    },
    ant: {
      container: ".ant-select",
      trigger: '.ant-select-selector, .ant-select-selection, [role="combobox"]',
      dropdown: '.ant-select-item-option,.ant-select-dropdown-menu-item,[role="option"].ant-select-dropdown-menu-item',
      selected: ".ant-select-item-option-selected,.ant-select-dropdown-menu-item-selected",
    },
    element: {
      container: ".el-select",
      trigger: ".el-input__inner, .el-select__input",
      dropdown: ".el-select-dropdown__item",
      selected: ".selected",
      popper: ".el-select__popper",
      option: '[class*="el-select-dropdown"][class*="__item"]',
    },
    "element-cascader": {
      container: ".el-cascader",
      trigger: ".el-input__inner",
      dropdown: ".el-cascader__suggestion-item, .el-cascader-node, .el-cascader-menu__item, .el-cascader__dropdown li",
      selected: ".is-active, .in-checked-path, .is-selected",
      popper: ".el-cascader__dropdown, .el-cascader-panel, .el-cascader-menus, .el-popper",
    },
    iview: {
      container: ".ivu-select",
      trigger: ".ivu-select-selection",
      dropdown: ".ivu-select-item",
      selected: ".ivu-select-item-selected",
    },
    layui: {
      container: ".layui-form-select",
      trigger: ".layui-select-title",
      dropdown: ".layui-anim-upbit dd",
      selected: ".layui-this",
    },
    bootstrap: {
      container: ".selectpicker, .form-select",
      trigger: ".selectpicker, .form-select",
      dropdown: ".dropdown-item, .bs-select-option",
      selected: ".selected",
    },
    material: {
      container: ".mdc-select, .mdc-select__menu",
      trigger: ".mdc-select__anchor, .mdc-select__selected-text",
      dropdown: ".mdc-list-item, .mdc-select__item",
      selected: ".mdc-list-item--selected",
    },
    chakra: {
      container: '.chakra-select, [role="combobox"]',
      trigger: '.chakra-select__field, [role="combobox"]',
      dropdown: '.chakra-select__option, [role="option"]',
      selected: ".chakra-select__option--selected",
    },
    vuetify: {
      container: ".v-select, .v-menu",
      trigger: ".v-select__slot, .v-input__slot",
      dropdown: ".v-list-item, .v-select__item",
      selected: ".v-list-item--active",
    },
    semantic: {
      container: ".ui.dropdown, .ui.selection.dropdown",
      trigger: ".ui.dropdown, .ui.selection.dropdown",
      dropdown: ".item, .ui.dropdown .menu .item",
      selected: ".selected.item",
    },
    jquery: {
      container: ".select2-container, .chosen-container",
      trigger: ".select2-selection, .chosen-single",
      dropdown: ".select2-results__option, .chosen-results li",
      selected: ".select2-results__option--selected, .chosen-results li.active-result",
    },
    phoenix: {
      container: ".phoenix-select",
      trigger: ".phoenix-select__input",
      dropdown: ".phoenix-selectList__listItem",
      selected: ".phoenix-selectList__listItem--isSelected",
      // Phoenix 新版租户使用 phoenix-unmodeled-layer，旧租户仍使用
      // common-unmodeled-layer；两者都要纳入弹层定位。
      layer: ".common-unmodeled-layer:not(.common-unmodeled-layer-hidden), .phoenix-unmodeled-layer:not(.phoenix-unmodeled-layer-hidden)",
      listContainer: ".list-data-container, .area-data-container, .phoenix-selectList",
      cascaderMenu: ".list-data-container, .area-data-container, .phoenix-selectList",
      cascaderOption: ".list-item-container, .area-item-name, .phoenix-selectList__listItem",
      cascaderLabel: ".item-text-label, .area-text-label, .phoenix-checkbox__text",
      cascaderRadio: ".area-radio, input[type=radio], .el-radio__input, .ant-radio-input, .radio, .icon-radio, .RadioUnchecked, .area-icon-RadioUnchecked, .area-icon-RadioChecked, svg.area-icon-RadioUnchecked, svg.area-icon-RadioChecked, .icon-container svg",
      confirmButton: ".phoenix-button__wraper--primary, .phoenix-button--primary",
    },
    aui: {
      container: ".aui-select",
      trigger: ".aui-select__tags-group, .aui-input__inner, .aui-select__caret",
      dropdown: ".aui-select-dropdown__item, .aui-select-dropdown li, .aui-select-option, .aui-option, .aui-dropdown-item, [class*='aui-select'][class*='item'], [class*='aui-option']",
      selected: ".is-selected, .selected, .active",
      panelSelectors: ".aui-select-dropdown:not([style*='display: none']), .aui-dropdown:not([style*='display: none']), .aui-popper:not([style*='display: none']), [class*='aui-select'][class*='dropdown']:not([style*='display: none'])",
    },
    rocket: {
      container: ".rocket-select",
      trigger: ".rocket-select-selector, .rocket-select-arrow, [role='combobox']",
      dropdown: ".rocket-select-item-option, .rocket-select-dropdown-menu-item, .rocket-select-option, [id$='_list'] [role='option'], [class*='rocket-select'][class*='option'], [role='option']",
      selected: ".rocket-select-selection-item, .rocket-select-selection-selected-value",
      panelSelectors: ".rocket-select-dropdown:not([style*='display: none']), .rocket-select-dropdown-menu:not([style*='display: none']), [id$='_list']:not([style*='display: none']), [class*='rocket-select'][class*='dropdown']:not([style*='display: none'])",
    },
    sd: {
      container: '[class^="sd-Select-container"], [class*=" sd-Select-container"], [class*="sd-Select"]',
      trigger: '[class^="sd-Select"], [class*="sd-Select"], [role="combobox"], input',
      dropdown: '[class*="sd-Select"][class*="option"], [class*="sd-Select"][class*="item"], [role="option"], li',
      selected: '[class*="sd-Select"][class*="selected"], [class*="sd-Select"][class*="value"], [class*="sd-Select"][class*="single"], [class*="sd-Select"][class*="content"]',
      panelSelectors: '[class*="sd-Select"][class*="dropdown"]:not([style*="display: none"]), [class*="sd-Dropdown-container"]:not([style*="display: none"]), [role="listbox"]:not([aria-hidden="true"])',
    },
    next: {
      container: ".next-select",
      trigger: ".next-select-inner, .next-select-trigger, [role='combobox'], input",
      dropdown: ".next-menu-item, .next-select-menu-item, [role='option'], [data-value], li",
      selected: ".next-selected, .next-menu-item-selected, .next-select-values",
      panelSelectors: ".next-overlay-wrapper:not([style*='display: none']), .next-menu:not([style*='display: none']), .next-select-menu:not([style*='display: none']), [role='listbox']:not([aria-hidden='true'])",
    },
  };

  // 通用兜底"选项"选择器 (源码 selectMatchingOption 内联常量, 行3306)
  var GENERIC_OPTION_SELECTOR = [
    'li[role="option"]', ".option", ".dropdown-item", ".select-item", ".item", "li", "dd",
    "div[data-value]", ".ant-select-item-option", ".ant-select-dropdown-menu-item",
    ".el-select-dropdown__item", ".kuma-select2-dropdown-menu-item", '[role="option"]',
    ".select-option", ".chakra-select__option", ".rc-virtual-list-holder-inner div[title]", "div[title]", "[aria-selected]",
    "[data-option-index]", "[data-value]", ".ud__select__list__item",
    ".el-cascader__suggestion-item", ".el-cascader-node", ".el-cascader-menu__item",
    ".aui-select-dropdown__item", ".aui-select-dropdown li", ".aui-select-option", ".aui-option", ".aui-dropdown-item", "[class*='aui-option']",
    ".rocket-select-item-option", ".rocket-select-dropdown-menu-item", ".rocket-select-option",
    "[class*='sd-Select'][class*='option']", "[class*='sd-Select'][class*='item']",
    ".next-menu-item", ".next-select-menu-item", "[class*='next-'][class*='option']",
  ].join(",");

  // 通用兜底"下拉面板"选择器 (源码 findDropdown 内联常量, 行3114)
  var GENERIC_DROPDOWN_SELECTOR = [
    ".kuma-select2-dropdown:not(.kuma-select2-dropdown-hidden)",
    ".ant-select-dropdown:not(.ant-select-dropdown-hidden)",
    ".ant-select-dropdown-placement-bottomLeft",
    ".ant-select-dropdown-placement-bottomRight",
    ".ant-select-dropdown:not([style*='display: none'])",
    ".el-select-dropdown:not(.is-hidden)",
    ".el-cascader__dropdown:not([style*='display: none'])",
    ".el-cascader__dropdown:not([aria-hidden='true'])",
    ".aui-select-dropdown:not([style*='display: none'])",
    ".aui-dropdown:not([style*='display: none'])",
    ".aui-popper:not([style*='display: none'])",
    ".rocket-select-dropdown:not([style*='display: none'])",
    ".rocket-select-dropdown-menu:not([style*='display: none'])",
    '[class*="sd-Select"][class*="dropdown"]:not([style*="display: none"])',
    '[class*="sd-Dropdown-container"]:not([style*="display: none"])',
    ".next-overlay-wrapper:not([style*='display: none'])",
    ".next-menu:not([style*='display: none'])",
    ".next-select-menu:not([style*='display: none'])",
    '[role="listbox"]:not([aria-hidden="true"])',
    ".dropdown-menu:not(.hidden)",
    ".select-dropdown:not(.hidden)",
    '[role="menu"]:not([aria-hidden="true"])',
    ".chakra-menu:not([hidden])",
    ".v-menu__content",
    ".menu:not(.hidden)",
    ".options:not(.hidden)",
    ".rc-virtual-list:not([style*='display: none'])",
    ".rc-virtual-list-holder:not([style*='display: none'])",
    '[class*="dropdown"]:not([style*="display: none"]):not(.hidden)',
    '[class*="select-dropdown"]:not([style*="display: none"]):not(.hidden)',
    '[class*="options"]:not([style*="display: none"]):not(.hidden)',
    '[class*="popup"]:not([style*="display: none"]):not(.hidden)',
    '[class*="popup-content"]:not([style*="display: none"]):not(.hidden)',
  ].join(",");

  var HIDDEN_DROPDOWN_CLASSES = ["is-hidden", "ant-select-dropdown-hidden", "kuma-select2-dropdown-hidden", "kuma-select-dropdown-hidden"];

  function normalize(s) {
    return String(s == null ? "" : s).toLowerCase().trim();
  }

  // 源码 isOptionMatch (模块744, 行2913-2944) 完整版现已移植到 AF.DomUtils.isOptionMatch
  // (content/utils.js)，内部依次尝试: 学历别名 → CET四六级 → 学历类型(全日制/统招) →
  // 获奖等级 → GPA/薪资区间匹配 → 归一化文本互相包含。这里直接转调，不再自己维护简化版。
  function isOptionMatch(optionText, optionCode, targetValue) {
    if (AF.DomUtils.isOptionMatch(optionText, optionCode, targetValue)) return true;
    // 兜底: 完整版覆盖不到时，再退一步用分词加权相似度 (isSimilarText) 试一次
    try {
      return AF.DomUtils.isSimilarText(optionText, String(targetValue));
    } catch (e) {
      return false;
    }
  }

  // 源码 findVisibleDropdownNear (模块744, 行2946-2969):
  // 全局搜索所有匹配 selector 的元素，过滤掉隐藏态的，若有多个候选取离 refEl 最近的一个。
  function findVisibleDropdownNear(refEl, selector, containerSelector) {
    try {
      var sel = Array.isArray(selector) ? selector.join(",") : selector;
      var candidates = Array.prototype.slice.call(document.querySelectorAll(sel)).filter(function (el) {
        return (
          !!el &&
          !HIDDEN_DROPDOWN_CLASSES.some(function (cls) {
            return el.classList.contains(cls);
          }) &&
          el.getAttribute("aria-hidden") !== "true" &&
          AF.DomUtils.isElementVisible(el)
        );
      });
      if (candidates.length === 0) return null;
      if (candidates.length === 1) return candidates[0];
      var refRect = ((containerSelector && refEl && refEl.closest && refEl.closest(containerSelector)) || refEl).getBoundingClientRect();
      candidates.sort(function (a, b) {
        var ra = a.getBoundingClientRect();
        var rb = b.getBoundingClientRect();
        var da = Math.abs(ra.left - refRect.left) + Math.abs(ra.top - refRect.bottom);
        var db = Math.abs(rb.left - refRect.left) + Math.abs(rb.top - refRect.bottom);
        return da - db;
      });
      return candidates[0];
    } catch (e) {
      return null;
    }
  }

  // 源码 waitForVisibleDropdownNear (模块744, 行2971-3013): 轮询版 findVisibleDropdownNear
  function waitForVisibleDropdownNear(refEl, selector, containerSelector, timeoutMs) {
    return AF.Utils.waitForElement(function () {
      return findVisibleDropdownNear(refEl, selector, containerSelector);
    }, timeoutMs || 1500);
  }

  // 源码 findDropdown (模块744, 行3099-3170) 简化版：优先用框架专属 dropdown 选择器，
  // 否则退化为通用面板选择器列表，全部在整个 document 里搜(下拉面板经常被 portal 到 body)。
  function findDropdown(refEl, frame示例资料Key) {
    try {
      if (frame示例资料Key && SA._config[frame示例资料Key] && SA._config[frame示例资料Key].dropdown) {
        var byFrame示例资料 = document.querySelector(SA._config[frame示例资料Key].dropdown);
        if (byFrame示例资料 && AF.DomUtils.isElementVisible(byFrame示例资料)) return byFrame示例资料;
      }
      return findVisibleDropdownNear(refEl, GENERIC_DROPDOWN_SELECTOR);
    } catch (e) {
      return null;
    }
  }

  // 从指定作用域 (面板元素或 document) 内取出可见/可交互的选项节点
  function getOptionNodes(scopeEl, optionSelector) {
    try {
      var sel = optionSelector || GENERIC_OPTION_SELECTOR;
      var scope = scopeEl || document;
      return Array.prototype.slice.call(scope.querySelectorAll(sel)).filter(function (el) {
        var style = window.getComputedStyle(el);
        return style.display !== "none" && style.visibility !== "hidden" && !el.classList.contains("disabled") && !el.disabled;
      });
    } catch (e) {
      return [];
    }
  }

  // 四段式匹配 + 点击 (源码 selectMatchingOption 核心逻辑, 模块744, 行3349-3444):
  // 1) 精确文字匹配  2) 双向 includes 匹配  3) isOptionMatch 规则匹配(学历/CET/获奖等级/
  // GPA薪资区间等) 4) 前三段都没命中时，用 Jaro-Winkler 智能兜底 (intelligentOptionMatch)
  // 挑一个"看起来最合理"的选项 —— 对应源码 selectMatchingOption 在规则匹配失败后
  // 继续调用 intelligentOptionMatch 的兜底路径 (行3622/22377)。
  async function clickBestMatch(nodes, value) {
    if (!nodes || nodes.length === 0 || value === undefined || value === null || value === "") return false;
    var capability = SA._currentCapability || null;
    var matchMode = capability && String(capability.matchMode || "").trim();
    var fallback = capability && String(capability.fallback || "").trim();
    var target = String(value);
    var targetLower = target.toLowerCase();
    var 示例资料Level = function (raw) {
      var text = String(raw || "").toLowerCase().replace(/[\s（）()\-_/]/g, "");
      if (/博士|博研/.test(text)) return "博士";
      if (/硕士|硕研/.test(text)) return "硕士";
      if (/本科|大学本科|本科生|学士/.test(text)) return "本科";
      if (/大专|专科|大学专科/.test(text)) return "大专";
      if (/中专|中技|技校|职高|职业高中/.test(text)) return "中专";
      if (/高中/.test(text)) return "高中";
      if (/初中/.test(text)) return "初中及以下";
      return "";
    };
    // 具体学位类型（如“管理学硕士/管理学学士”）也包含学历层次词，
    // 必须先精确命中，不能被学历层次规则提前选成列表第一项。
    for (var i = 0; i < nodes.length; i++) {
      if (nodes[i].textContent.trim().toLowerCase() === targetLower) {
        return await clickOption(nodes[i]);
      }
    }
    var targetEducationLevel = 示例资料Level(target);
    if (targetEducationLevel) {
      for (var 示例资料Index = 0; 示例资料Index < nodes.length; 示例资料Index++) {
        if (示例资料Level(nodes[示例资料Index].textContent.trim()) === targetEducationLevel) {
          return await clickOption(nodes[示例资料Index]);
        }
      }
      return false;
    }
    if (matchMode === "exact") {
      return fallback === "firstFilteredOption" && nodes.length ? await clickOption(nodes[0]) : false;
    }
    for (var j = 0; j < nodes.length; j++) {
      var text = nodes[j].textContent.trim().toLowerCase();
      if (text && (text.includes(targetLower) || targetLower.includes(text))) {
        return await clickOption(nodes[j]);
      }
    }
    if (matchMode === "exactOrContains") {
      return fallback === "firstFilteredOption" && nodes.length ? await clickOption(nodes[0]) : false;
    }
    if (capability && capability.preferFirstOptionOnNoMatch && fallback === "firstFilteredOption" && nodes.length) {
      return await clickOption(nodes[0]);
    }
    for (var k = 0; k < nodes.length; k++) {
      var code = nodes[k].getAttribute("data-value") || nodes[k].getAttribute("value") || nodes[k].getAttribute("code") || nodes[k].textContent.trim();
      if (isOptionMatch(nodes[k].textContent.trim(), code, target)) {
        return await clickOption(nodes[k]);
      }
    }
    // 学制属于严格数值语义。若没有相同年数的选项，宁可不填，也不能进入
    // 通用相似度兜底后因为所有选项都有“年”字而误选第一项（通常是“1年”）。
    if (AF.DomUtils.parseStudyYears && AF.DomUtils.parseStudyYears(target) !== null) return false;
    try {
      var optionObjs = nodes.map(function (n) {
        return { text: n.textContent.trim(), value: n.getAttribute("data-value") || n.getAttribute("value") || "" };
      });
      var best = AF.DomUtils.intelligentOptionMatch(optionObjs, optionObjs, target);
      if (best) {
        var bestIdx = optionObjs.indexOf(best);
        if (bestIdx !== -1) return await clickOption(nodes[bestIdx]);
      }
    } catch (e) {}
    if (fallback === "firstFilteredOption" && nodes.length) return await clickOption(nodes[0]);
    return false;
  }

  async function clickOption(el) {
    try {
      el.scrollIntoView({ block: "nearest", behavior: "auto" });
    } catch (e) {}
    // Keep this deliberately small. The original product commits custom
    // dropdown options with one mousedown -> mouseup -> click sequence on the
    // matched option it示例资料. Extra pointer events or a final el.click() can
    // make controlled selects process the same option twice.
    await AF.Utils.sleep(200);
    try {
      var rect = el.getBoundingClientRect();
      var init = {
        view: window,
        bubbles: true,
        cancelable: true,
        clientX: rect.left + rect.width / 2,
        clientY: rect.top + rect.height / 2,
        button: 0,
      };
      el.dispatchEvent(new MouseEvent("mousedown", init));
      await AF.Utils.sleep(2);
      el.dispatchEvent(new MouseEvent("mouseup", init));
      await AF.Utils.sleep(2);
      el.dispatchEvent(new MouseEvent("click", init));
      await AF.Utils.sleep(2);
      return true;
    } catch (e) {
      return await AF.DomUtils.safeClickElement(el);
    }
  }

  // 在给定面板/文档范围内查找匹配选项并点击 (源码 selectMatchingOption 对外接口)
  async function selectMatchingOption(scopeEl, value, optionSelector) {
    var nodes = getOptionNodes(scopeEl, optionSelector);
    return await clickBestMatch(nodes, value);
  }

  // 往容器内的搜索框输入文字，用于触发框架自身的过滤逻辑 (ant/element/brick/chakra 等)
  async function typeIntoSearchInput(containerEl, text) {
    try {
      if (!containerEl) return false;
      var input = containerEl.tagName === "INPUT" ? containerEl : containerEl.querySelector('input[type="text"], input[type="search"], input:not([type])');
      if (!input || input.disabled || input.readOnly) return false;
      input.focus();
      input.value = text;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      await AF.Utils.sleep(200);
      return true;
    } catch (e) {
      return false;
    }
  }

  // 提取 labelText (源码基类构造函数, 行23358-23366)
  function extractLabelText(element) {
    try {
      if (!element) return null;
      var formEl = element.closest('div[class*="form"], div[class*="field"]');
      var labelEl = formEl && formEl.querySelector('label, div[class*="label"], span[class*="label"]');
      return labelEl ? labelEl.textContent.trim() : null;
    } catch (e) {
      return null;
    }
  }

  // 给原始 element 补发 input/change，让监听那个具体元素的框架代码也能感知到变化
  function dispatchChangeEvents(element) {
    try {
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } catch (e) {}
  }

  // 通用"点击展开 → 等面板 → 匹配点击"模板 (源码 triggerGenericSelect 及各框架专属 trigger* 函数的共性抽象)
  // config: { container, trigger, dropdown, panelSelectors? }
  // opts:   { clickTarget: "trigger"|"element", useSearchInput: bool, alreadyOpenCheck: fn(container,trigger)->bool }
  async function genericOpenAndSelect(element, value, config, opts) {
    opts = opts || {};
    try {
      var container = (config.container && element.closest(config.container)) || element;
      var trigger = (config.trigger && container.querySelector(config.trigger)) || container;
      var clickTarget = opts.clickTarget === "element" ? element : trigger;

      if (opts.useSearchInput && typeof value === "string") {
        await typeIntoSearchInput(container, value);
      }

      var alreadyOpen = typeof opts.alreadyOpenCheck === "function" && opts.alreadyOpenCheck(container, trigger);
      var panel = null;
      var panelSelectors = config.panelSelectors || GENERIC_DROPDOWN_SELECTOR;
      if (alreadyOpen) {
        panel = findVisibleDropdownNear(element, panelSelectors, config.container);
      }
      if (!panel) {
        if (clickTarget && clickTarget.focus) {
          try {
            clickTarget.focus();
          } catch (e) {}
        }
        await AF.DomUtils.safeClickElement(clickTarget);
        panel = await waitForVisibleDropdownNear(element, panelSelectors, config.container, 1500);
      }
      if (!panel) return false;

      var ok;
      if (Array.isArray(value)) {
        ok = false;
        for (var i = 0; i < value.length; i++) {
          var one = await selectMatchingOption(panel, value[i], config.dropdown);
          if (one) ok = true;
          await AF.Utils.sleep(150);
        }
      } else {
        ok = await selectMatchingOption(panel, value, config.dropdown);
      }
      dispatchChangeEvents(element);
      return ok;
    } catch (e) {
      return false;
    }
  }

  // 源码 triggerGenericSelect (模块3620, 行14587-14625): 直接点击 element 本身 (不做
  // container/trigger 定位)，等 200ms 后用通用面板选择器全局搜索最近的可见下拉，
  // 再调用 selectMatchingOption 通用匹配。Bootstrap / Material / Semantic / Vuetify /
  // JQuery(select2/chosen) / IView 六个适配器在源码里都是直接继承这个函数，没有任何框架特化。
  async function triggerGenericSelect(element, value) {
    try {
      async function selectOne(val) {
        await AF.DomUtils.safeClickElement(element);
        await AF.Utils.sleep(200);
        var panel = findDropdown(element) || (await waitForVisibleDropdownNear(element, GENERIC_DROPDOWN_SELECTOR, null, 1200));
        if (!panel) return false;
        return await selectMatchingOption(panel, val);
      }
      var ok;
      if (Array.isArray(value)) {
        ok = false;
        for (var i = 0; i < value.length; i++) {
          var one = await selectOne(value[i]);
          if (one) ok = true;
          await AF.Utils.sleep(150);
        }
      } else {
        ok = await selectOne(value);
      }
      dispatchChangeEvents(element);
      return ok;
    } catch (e) {
      return false;
    }
  }

  SA._helpers = {
    isOptionMatch: isOptionMatch,
    triggerGenericSelect: triggerGenericSelect,
    findVisibleDropdownNear: findVisibleDropdownNear,
    waitForVisibleDropdownNear: waitForVisibleDropdownNear,
    findDropdown: findDropdown,
    getOptionNodes: getOptionNodes,
    clickBestMatch: clickBestMatch,
    clickOption: clickOption,
    selectMatchingOption: selectMatchingOption,
    typeIntoSearchInput: typeIntoSearchInput,
    extractLabelText: extractLabelText,
    dispatchChangeEvents: dispatchChangeEvents,
    genericOpenAndSelect: genericOpenAndSelect,
    GENERIC_OPTION_SELECTOR: GENERIC_OPTION_SELECTOR,
    GENERIC_DROPDOWN_SELECTOR: GENERIC_DROPDOWN_SELECTOR,
  };
})();
