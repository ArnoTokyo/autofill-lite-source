"use strict";
const assert = require("assert");
const path = require("path");
const root = path.join(__dirname, "..");

global.location = { href: "https://generic.example/resume", hostname: "generic.example", pathname: "/resume" };
global.document = { body: { click() {} } };
global.getComputedStyle = () => ({ display: "block", visibility: "visible", opacity: "1" });
global.window = {
  location: global.location,
  AF: {
    CheckpointCore: { recordFingerprint(row) { return JSON.stringify(row || {}); } },
    DomUtils: {
      isElementVisible(node) { return !!node && node.visible !== false && node.isConnected !== false; },
      isDateValue() { return false; }, isDatePicker() { return false; }, isSearchSelect() { return false; }, isNormalSelect() { return false; }
    },
    Utils: { async sleep() {} },
    FillTrace: { setFieldContext() {}, event() {}, readElementValue(el) { return String(el && el.value || ""); } },
    SelectAdapter: { _registry: { custom: true }, detectType() { return null; } }
  }
};
require(path.join(root, "autofill-plugin/content/form-handler.js"));
const AF = window.AF;
function node(value) { return { tagName: "INPUT", value: value || "", visible: true, isConnected: true, matches() { return false; }, getBoundingClientRect() { return { width: 100, height: 20 }; } }; }
const cases = [
  { category: "workExperience", title: "工作经历", row: { company: "甲公司", department: "财务部", startTime: "2024-01" }, fields: ["company", "department", "startTime"], identity: { primary: "company", secondary: "startTime", requireSecondary: false } },
  { category: "campusLeadership", title: "学生工作", row: { projectName: "学生会", title: "部长", startTime: "2023-09" }, fields: ["projectName", "title", "startTime"], identity: { primary: "projectName", secondary: "startTime", requireSecondary: false } },
  { category: "campusActivities", title: "校园活动", row: { activityName: "实践活动", role: "成员", startTime: "2023-07" }, fields: ["activityName", "role", "startTime"], identity: { primary: "activityName", secondary: "startTime", requireSecondary: false } },
  { category: "trainingExperience", title: "培训经历", row: { name: "培训甲", organization: "机构甲", startTime: "2024-02" }, fields: ["name", "organization", "startTime"], identity: { primary: "name", secondary: "startTime", requireSecondary: false } },
  { category: "certificates", title: "证书", row: { certificateName: "证书甲", description: "说明", obtainedTime: "2024-06" }, fields: ["certificateName", "description", "obtainedTime"], identity: { primary: "certificateName", secondary: "obtainedTime", requireSecondary: false } },
  { category: "publications", title: "论文", row: { paperTitle: "论文甲", journal: "期刊甲", publishTime: "2025-01" }, fields: ["paperTitle", "journal", "publishTime"], identity: { primary: "paperTitle", secondary: "publishTime", requireSecondary: false } },
  { category: "patents", title: "专利", row: { patentName: "专利甲", description: "说明", grantDate: "2025-02" }, fields: ["patentName", "description", "grantDate"], identity: { primary: "patentName", secondary: "grantDate", requireSecondary: false } },
  { category: "languageSkills", title: "语言能力", row: { name: "英语", score: "600", level: "CET6" }, fields: ["name", "score", "level"], identity: { primary: "name", secondary: "level", requireSecondary: false } }
];
(async () => {
  for (const c of cases) {
    const elements = c.fields.map(() => node(""));
    const mappings = c.fields.map((fieldKey, i) => ({ fieldId: `${c.category}-${fieldKey}`, category: c.category, fieldKey, selector: `#f${i}`, controlType: "text" }));
    const selectorMap = Object.fromEntries(mappings.map((m, i) => [m.selector, [elements[i]]]));
    const doc = { querySelectorAll(sel) { return selectorMap[sel] || []; } };
    const editor = { ownerDocument: doc, visible: true, isConnected: true, contains(el) { return elements.includes(el); }, querySelectorAll() { return []; } };
    elements.forEach(el => { el.ownerDocument = doc; });
    AF.RuntimeSemanticPatch = { hostname: location.hostname, pathname: location.pathname, recordSelectorMappings: mappings };
    AF.RecordGraph = {
      supportsCategory(category) { return cases.some(x => x.category === category); },
      resolveRuntimeEditorOwnership() { return { status: "owned", confidence: 1, editorScope: editor, recordIndex: 0, mappings, ownershipMode: "identity_match", identityFieldKeys: c.identity }; }
    };
    const matcher = { config: { _aiSemanticPatch: { fieldMappings: mappings.map(m => ({ fieldId: m.fieldId, label: m.fieldKey })) } }, findContainerByTitle() { return editor; } };
    const dm = { resumeData: { [c.category]: [c.row] }, getCategoryByTitle() { return { category: c.category, type: "array", data: [c.row] }; } };

    let pause1 = null; let calls = 0;
    const h1 = new AF.FormHandler(matcher, dm);
    h1.recordCheckpointRuntime = { resumed: false, previousCheckpoint: null, shouldSkip() { return false; }, async pause(meta, reason, opts) { pause1 = Object.assign({}, opts.failureContext || {}, { category: meta.category, repeatIndex: meta.repeatIndex, repeatTotal: meta.repeatTotal, recordFingerprint: meta.recordFingerprint, acknowledgeMode: opts.acknowledgeMode, nextAction: opts.nextAction, manualFields: opts.manualFields, committedFields: opts.committedFields, completedActions: opts.completedActions, actionCursor: { nextAction: opts.nextAction, completedActions: opts.completedActions || [] } }); return pause1; } };
    h1.fieldCheckpointRuntime = { async pause() { throw new Error("unexpected field checkpoint"); } };
    AF.FormHandler.fillFormElement = async function(el, value) { calls++; if (calls === 2) return false; el.value = String(value); return true; };
    const r1 = await h1.fillGraphBackedRepeatRecord({}, c.title, { specificCategory: c.category });
    assert.strictEqual(r1.success, false, `${c.category}: first run should pause`);
    assert(pause1, `${c.category}: checkpoint missing`);
    assert.strictEqual(pause1.reasonCode, "manual_record_action_required", `${c.category}: expected action checkpoint`);
    assert.strictEqual(pause1.nextAction, `FIELD:${c.fields[2]}:${c.category}-${c.fields[2]}`, `${c.category}: resume cursor must point after failed action`);

    elements[1].value = String(c.row[c.fields[1]]);
    let pause2 = null; const called = [];
    const h2 = new AF.FormHandler(matcher, dm);
    h2.recordCheckpointRuntime = { resumed: true, previousCheckpoint: pause1, shouldSkip() { return false; }, async pause(meta, reason, opts) { pause2 = Object.assign({}, opts.failureContext || {}, { nextAction: opts.nextAction, completedActions: opts.completedActions }); return pause2; } };
    h2.fieldCheckpointRuntime = { async pause() { throw new Error("unexpected field checkpoint"); } };
    AF.FormHandler.fillFormElement = async function(el, value) { called.push(el); el.value = String(value); return true; };
    const r2 = await h2.fillGraphBackedRepeatRecord({}, c.title, { specificCategory: c.category });
    assert.strictEqual(r2.success, false, `${c.category}: resume should stop at SAVE boundary`);
    assert.deepStrictEqual(called, [elements[2]], `${c.category}: only action after cursor may replay`);
    assert(pause2, `${c.category}: save checkpoint missing`);
    assert.strictEqual(pause2.reasonCode, "manual_record_save_required", `${c.category}: should reach manual save boundary`);
    assert.strictEqual(pause2.nextAction, "NEXT_RECORD", `${c.category}: save acknowledgement must advance`);
  }
  console.log("build153-repeat-action-cursor-expanded.test.js PASS");
})().catch(err => { console.error(err); process.exit(1); });
