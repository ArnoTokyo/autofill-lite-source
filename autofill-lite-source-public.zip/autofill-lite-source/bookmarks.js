"use strict";

const $ = (id) => document.getElementById(id);
let snapshot = { library: null, folders: [] };
let currentFolderId = "root";
let currentPrefill = { name: "", url: "" };
let editorState = { mode: "bookmark-add", id: null };
let moveNodeId = null;
let searchToken = 0;

function showError(error) {
  const bar = $("errorBar");
  const text = String(error && error.message || error || "操作失败");
  bar.textContent = text;
  bar.classList.remove("hidden");
  clearTimeout(showError.timer);
  showError.timer = setTimeout(() => bar.classList.add("hidden"), 5000);
}

function nodeById(id, node = snapshot.library && snapshot.library.root) {
  if (!node) return null;
  if (node.id === id) return node;
  if (node.type !== "folder") return null;
  for (const child of node.children || []) {
    const found = nodeById(id, child);
    if (found) return found;
  }
  return null;
}

function parentOf(id, node = snapshot.library && snapshot.library.root) {
  if (!node || node.type !== "folder") return null;
  for (const child of node.children || []) {
    if (child.id === id) return node;
    if (child.type === "folder") {
      const found = parentOf(id, child);
      if (found) return found;
    }
  }
  return null;
}

function pathForFolder(id) {
  if (id === "root") return "岗位库";
  const parts = [];
  let node = nodeById(id);
  while (node && node.id !== "root") {
    parts.unshift(node.name);
    node = parentOf(node.id);
  }
  return `岗位库 / ${parts.join(" / ")}`;
}

function sortChildren(children) {
  return [...(children || [])].sort((a, b) => {
    if (a.type !== b.type) return a.type === "folder" ? -1 : 1;
    return String(a.name || "").localeCompare(String(b.name || ""), "zh-CN");
  });
}

function renderFolderTree() {
  const root = $("folderTree");
  root.textContent = "";
  const render = (folder, depth) => {
    const row = document.createElement("div");
    row.className = `folder-node${folder.id === currentFolderId ? " active" : ""}`;
    row.style.paddingLeft = `${8 + depth * 16}px`;
    const icon = document.createElement("span");
    icon.className = "folder-icon";
    icon.textContent = "📁";
    const label = document.createElement("span");
    label.className = "folder-label";
    label.textContent = folder.name;
    row.append(icon, label);
    row.addEventListener("click", () => {
      currentFolderId = folder.id;
      $("search").value = "";
      renderAll();
    });
    root.appendChild(row);
    sortChildren((folder.children || []).filter((x) => x.type === "folder")).forEach((child) => render(child, depth + 1));
  };
  if (snapshot.library && snapshot.library.root) render(snapshot.library.root, 0);
}

function actionButton(text, onClick, className = "") {
  const button = document.createElement("button");
  button.textContent = text;
  if (className) button.className = className;
  button.addEventListener("click", (event) => {
    event.stopPropagation();
    onClick();
  });
  return button;
}

function renderNormalList() {
  const folder = nodeById(currentFolderId) || snapshot.library.root;
  currentFolderId = folder.id;
  $("breadcrumb").textContent = pathForFolder(folder.id);
  const children = sortChildren(folder.children || []);
  $("contentHint").textContent = `${children.filter((x) => x.type === "folder").length} 个文件夹 · ${children.filter((x) => x.type === "bookmark").length} 个网址`;
  const list = $("itemList");
  list.textContent = "";
  $("emptyState").classList.toggle("hidden", children.length !== 0);
  children.forEach((node) => {
    const row = document.createElement("div");
    row.className = "item-row";
    const nameCell = document.createElement("div");
    nameCell.className = "item-name";
    const icon = document.createElement("span");
    icon.textContent = node.type === "folder" ? "📁" : "🔗";
    const name = document.createElement("span");
    name.textContent = node.name;
    nameCell.append(icon, name);

    const status = document.createElement("div");
    status.className = `item-status${node.type === "bookmark" && node.status ? " has-status" : ""}`;
    status.textContent = node.type === "bookmark" ? (node.status || "—") : "—";

    const meta = document.createElement("div");
    meta.className = "item-meta";
    meta.textContent = node.type === "folder" ? `${(node.children || []).length} 项` : node.url;

    const actions = document.createElement("div");
    actions.className = "item-actions";
    if (node.type === "folder") {
      actions.append(
        actionButton("打开", () => { currentFolderId = node.id; renderAll(); }),
        actionButton("重命名", () => openEditor("folder-edit", node)),
        actionButton("移动", () => openMove(node.id)),
        actionButton("删除", () => removeNode(node), "danger-link")
      );
      row.addEventListener("dblclick", () => { currentFolderId = node.id; renderAll(); });
    } else {
      actions.append(
        actionButton("打开", () => openBookmark(node)),
        actionButton("编辑", () => openEditor("bookmark-edit", node)),
        actionButton("移动", () => openMove(node.id)),
        actionButton("删除", () => removeNode(node), "danger-link")
      );
      row.addEventListener("dblclick", () => openBookmark(node));
    }
    row.append(nameCell, status, meta, actions);
    list.appendChild(row);
  });
}

async function renderSearchList(query) {
  const token = ++searchToken;
  let results = [];
  try { results = await window.lite.searchBookmarks(query); } catch (error) { showError(error); }
  if (token !== searchToken) return;
  $("breadcrumb").textContent = `搜索：${query}`;
  $("contentHint").textContent = `${results.length} 个结果`;
  const list = $("itemList");
  list.textContent = "";
  $("emptyState").classList.toggle("hidden", results.length !== 0);
  $("emptyState").textContent = results.length ? "" : "没有找到匹配的网址。";
  results.forEach((node) => {
    const row = document.createElement("div");
    row.className = "item-row";
    const nameCell = document.createElement("div");
    nameCell.className = "item-name";
    const icon = document.createElement("span"); icon.textContent = "🔗";
    const wrap = document.createElement("div");
    const name = document.createElement("div"); name.textContent = node.name;
    const path = document.createElement("div"); path.className = "search-result-path"; path.textContent = node.folderPath || "岗位库";
    wrap.append(name, path); nameCell.append(icon, wrap);
    const status = document.createElement("div"); status.className = `item-status${node.status ? " has-status" : ""}`; status.textContent = node.status || "—";
    const meta = document.createElement("div"); meta.className = "item-meta"; meta.textContent = node.url;
    const actions = document.createElement("div"); actions.className = "item-actions";
    actions.append(
      actionButton("打开", () => openBookmark(node)),
      actionButton("编辑", () => openEditor("bookmark-edit", node)),
      actionButton("移动", () => openMove(node.id)),
      actionButton("删除", () => removeNode(node), "danger-link")
    );
    row.append(nameCell, status, meta, actions);
    list.appendChild(row);
  });
}

function renderCurrentPage() {
  const visible = !!currentPrefill.url;
  $("currentPageBar").classList.toggle("hidden", !visible);
  if (!visible) return;
  $("currentPageName").textContent = currentPrefill.name || "当前招聘页面";
  $("currentPageUrl").textContent = currentPrefill.url;
}

function renderAll() {
  renderFolderTree();
  renderCurrentPage();
  const query = $("search").value.trim();
  if (query) renderSearchList(query);
  else renderNormalList();
}

function fillFolderSelect(select, selectedId) {
  select.textContent = "";
  (snapshot.folders || []).forEach((folder) => {
    const option = document.createElement("option");
    option.value = folder.id;
    option.textContent = folder.path;
    option.selected = folder.id === selectedId;
    select.appendChild(option);
  });
}

function openEditor(mode, node = null, prefill = null) {
  editorState = { mode, id: node && node.id || null };
  const isFolder = mode.startsWith("folder");
  const isEdit = mode.endsWith("edit");
  $("editorTitle").textContent = isFolder ? (isEdit ? "重命名文件夹" : "新建文件夹") : (isEdit ? "编辑网址" : "新增网址");
  $("urlLabel").classList.toggle("hidden", isFolder);
  $("statusLabel").classList.toggle("hidden", isFolder);
  $("folderLabel").classList.toggle("hidden", isEdit && isFolder);
  $("editorName").value = node ? node.name : String(prefill && prefill.name || "");
  $("editorUrl").value = node && node.type === "bookmark" ? node.url : String(prefill && prefill.url || "");
  $("editorStatus").value = node && node.type === "bookmark" ? String(node.status || "") : "";
  const parent = node ? parentOf(node.id) : null;
  const folderId = isEdit ? (parent && parent.id || currentFolderId) : currentFolderId;
  fillFolderSelect($("editorFolder"), folderId);
  $("editorModal").classList.remove("hidden");
  setTimeout(() => $("editorName").focus(), 0);
}

function closeEditor() { $("editorModal").classList.add("hidden"); }

async function saveEditor() {
  const mode = editorState.mode;
  const name = $("editorName").value.trim();
  const status = $("editorStatus").value.trim();
  if (!name) return showError("请输入名称");
  try {
    if (mode === "folder-add") {
      snapshot = await window.lite.addBookmarkFolder({ parentId: $("editorFolder").value, name });
    } else if (mode === "folder-edit") {
      snapshot = await window.lite.updateBookmarkNode({ id: editorState.id, patch: { name } });
    } else if (mode === "bookmark-add") {
      snapshot = await window.lite.addBookmark({ parentId: $("editorFolder").value, name, url: $("editorUrl").value.trim(), status });
    } else if (mode === "bookmark-edit") {
      const oldParent = parentOf(editorState.id);
      snapshot = await window.lite.updateBookmarkNode({ id: editorState.id, patch: { name, url: $("editorUrl").value.trim(), status } });
      const targetFolderId = $("editorFolder").value;
      if (targetFolderId && (!oldParent || oldParent.id !== targetFolderId)) {
        snapshot = await window.lite.moveBookmarkNode({ id: editorState.id, targetFolderId });
      }
    }
    closeEditor();
    renderAll();
  } catch (error) { showError(error); }
}

function openMove(id) {
  moveNodeId = id;
  const parent = parentOf(id);
  fillFolderSelect($("moveFolder"), parent && parent.id || "root");
  $("moveModal").classList.remove("hidden");
}

function closeMove() { $("moveModal").classList.add("hidden"); moveNodeId = null; }

async function saveMove() {
  if (!moveNodeId) return closeMove();
  try {
    snapshot = await window.lite.moveBookmarkNode({ id: moveNodeId, targetFolderId: $("moveFolder").value });
    closeMove();
    renderAll();
  } catch (error) { showError(error); }
}

async function removeNode(node) {
  const detail = node.type === "folder" && (node.children || []).length
    ? `文件夹“${node.name}”中还有 ${(node.children || []).length} 项，删除会一并删除其中内容。确定继续吗？`
    : `确定删除“${node.name}”吗？`;
  if (!window.confirm(detail)) return;
  try {
    snapshot = await window.lite.deleteBookmarkNode({ id: node.id });
    if (!nodeById(currentFolderId)) currentFolderId = "root";
    renderAll();
  } catch (error) { showError(error); }
}

async function openBookmark(node) {
  try { await window.lite.openBookmarkUrl(node.url); } catch (error) { showError(error); }
}

async function load() {
  try {
    snapshot = await window.lite.getBookmarkLibrary();
    currentPrefill = await window.lite.getBookmarkPrefill();
    renderAll();
  } catch (error) { showError(error); }
}

$("newFolder").addEventListener("click", () => openEditor("folder-add"));
$("folderHere").addEventListener("click", () => openEditor("folder-add"));
$("newBookmark").addEventListener("click", () => openEditor("bookmark-add"));
$("bookmarkHere").addEventListener("click", () => openEditor("bookmark-add"));
$("saveCurrent").addEventListener("click", () => openEditor("bookmark-add", null, currentPrefill));
$("editorCancel").addEventListener("click", closeEditor);
$("editorSave").addEventListener("click", saveEditor);
$("moveCancel").addEventListener("click", closeMove);
$("moveSave").addEventListener("click", saveMove);
$("search").addEventListener("input", renderAll);
$("editorModal").addEventListener("click", (event) => { if (event.target === $("editorModal")) closeEditor(); });
$("moveModal").addEventListener("click", (event) => { if (event.target === $("moveModal")) closeMove(); });
window.addEventListener("keydown", (event) => {
  if (event.key === "Escape") { closeEditor(); closeMove(); }
});
if (window.lite && typeof window.lite.onBookmarkPrefill === "function") {
  window.lite.onBookmarkPrefill((payload) => {
    currentPrefill = payload || { name: "", url: "" };
    renderCurrentPage();
  });
}

load();
