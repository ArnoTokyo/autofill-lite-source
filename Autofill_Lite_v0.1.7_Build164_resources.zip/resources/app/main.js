"use strict";

const { app, BrowserWindow, ipcMain, webContents, shell, safeStorage, net, screen, clipboard } = require("electron");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { URL } = require("url");
const { loadProfile, summarizeResumeData } = require("./profile-adapter");
const { classifySiteSupport, classifyAutofillGap } = require("./site-support-diagnostic");
const { buildAiSiteInput } = require("./site-analysis-ai-input");
const { AiSettingsStore } = require("./ai-settings-store");
const { buildProviderRequest, buildProviderRetryRequest, buildValueCandidateRequest, parseProviderResponse, responseDebugSummary, validateReview, validateSemanticPatch, validateValueCandidatePatch, usageFromResponse, summarizePatch } = require("./ai-semantic-api");
const { classifyLocalFirstRoute, compileRuntimeSemanticOverlay, compileRepeatRecordSelectorMetadata } = require("./ai-semantic-overlay");
const { compileSemanticSiteCandidate } = require("./ai-site-config-candidate");
const { compileGraphStructureFromBundle, attachGraphStructureToSiteCandidate, reconcileSemanticMappingsWithGraphStructure } = require("./graph-structure-site-candidate");
const { candidateMatchesUrl, buildVerifiedSiteCandidate } = require("./semantic-site-candidate-lifecycle");
const { buildAiGapFoundation, summarizeCandidateMappings } = require("./ai-gap-foundation");
const { compileAiCandidateSafetyGate } = require("./ai-candidate-safety-gate");
const { buildLocalSemanticFallbackPatch } = require("./ai-local-fallback");
const { semanticTokenBudget, valueTokenBudget } = require("./ai-token-budget");
const { buildValueReview, buildLocalValueCandidatePatch, classifyValueCandidates, HIGH_RISK_KEYS: HIGH_RISK_VALUE_KEYS } = require("./ai-value-candidate");
const {
  ROOT_ID,
  createEmptyLibrary,
  normalizeLibrary,
  cleanUrl,
  addFolder,
  addBookmark,
  updateNode,
  moveNode,
  deleteNode,
  folderOptions,
  searchBookmarks
} = require("./bookmark-store");

const BUILD_ID = "20260921-docked-profile-sidebar-164";
const BUILD_SHORT = (BUILD_ID.match(/-(\d+)$/) || [])[1] || BUILD_ID;

const APP_ROOT = __dirname;
const PORTABLE_BASE = process.defaultApp ? APP_ROOT : path.dirname(process.execPath);
const DATA_DIR = path.join(PORTABLE_BASE, "autofill-lite-data");
const PROFILE_DIR = path.join(DATA_DIR, "profile");
const CONFIG_DIR = path.join(DATA_DIR, "configs");
const LOG_DIR = path.join(DATA_DIR, "logs");
const BOOKMARK_DIR = path.join(DATA_DIR, "bookmarks");
const SITE_ANALYSIS_DIR = path.join(DATA_DIR, "site-analysis");
const AI_DIR = path.join(DATA_DIR, "ai");
const ELECTRON_PROFILE_DIR = path.join(DATA_DIR, "browser-profile");

for (const dir of [DATA_DIR, PROFILE_DIR, CONFIG_DIR, LOG_DIR, BOOKMARK_DIR, SITE_ANALYSIS_DIR, AI_DIR, ELECTRON_PROFILE_DIR]) {
  fs.mkdirSync(dir, { recursive: true });
}
try { app.setPath("userData", ELECTRON_PROFILE_DIR); } catch (_) {}
try { app.setAppUserModelId("Autofill.Lite"); } catch (_) {}

const PROFILE_FILE = path.join(PROFILE_DIR, "candidate-profile-merged.json");
const LEDGER_FILE = path.join(PROFILE_DIR, "candidate-profile-ledger.json");
const DEFAULT_PROFILE = path.join(APP_ROOT, "defaults", "candidate-profile-merged.json");
const DEFAULT_LEDGER = path.join(APP_ROOT, "defaults", "candidate-profile-ledger.json");
const BOOKMARK_FILE = path.join(BOOKMARK_DIR, "bookmarks.json");
const AI_SETTINGS_FILE = path.join(AI_DIR, "ai-settings.json");
const aiSettingsStore = new AiSettingsStore(AI_SETTINGS_FILE, {
  isAvailable: () => { try { return !!(safeStorage && safeStorage.isEncryptionAvailable()); } catch (_) { return false; } },
  encrypt: (text) => safeStorage.encryptString(String(text || "")),
  decrypt: (buffer) => safeStorage.decryptString(buffer)
});

function copyIfMissing(src, dest) {
  if (!fs.existsSync(dest) && fs.existsSync(src)) fs.copyFileSync(src, dest);
}
copyIfMissing(DEFAULT_PROFILE, PROFILE_FILE);
copyIfMissing(DEFAULT_LEDGER, LEDGER_FILE);
copyIfMissing(path.join(APP_ROOT, "default-config-127.json"), path.join(CONFIG_DIR, "127.0.0.1.json"));
copyIfMissing(path.join(APP_ROOT, "CONFIGS_README.txt"), path.join(CONFIG_DIR, "README.txt"));

function safeUrl(raw) {
  try {
    const u = new URL(raw);
    return `${u.protocol}//${u.host}${u.pathname}`;
  } catch (_) {
    return String(raw || "").split(/[?#]/)[0];
  }
}

function timestampName() {
  return new Date().toISOString().replace(/[:.]/g, "-");
}

function appendDiagnostic(record) {
  const file = path.join(LOG_DIR, `${timestampName()}.json`);
  fs.writeFileSync(file, JSON.stringify(record, null, 2), "utf8");
  return file;
}

function safeAnalysisHost(rawUrl) {
  try { return new URL(rawUrl).hostname.toLowerCase().replace(/[^a-z0-9.-]+/g, "_").slice(0, 120) || "site"; }
  catch (_) { return "site"; }
}


function aiReviewFileForUrl(rawUrl) {
  return path.join(SITE_ANALYSIS_DIR, `ai-review__${safeAnalysisHost(rawUrl)}__${safeAnalysisRoute(rawUrl)}.json`);
}

function aiPatchFileForUrl(rawUrl) {
  return path.join(SITE_ANALYSIS_DIR, `ai-patch__${safeAnalysisHost(rawUrl)}__${safeAnalysisRoute(rawUrl)}.json`);
}

function aiErrorFileForUrl(rawUrl) {
  return path.join(SITE_ANALYSIS_DIR, `ai-error__${safeAnalysisHost(rawUrl)}__${safeAnalysisRoute(rawUrl)}.json`);
}

function aiCandidateFileForUrl(rawUrl) {
  return path.join(SITE_ANALYSIS_DIR, `ai-candidate__${safeAnalysisHost(rawUrl)}__${safeAnalysisRoute(rawUrl)}.json`);
}

function aiValueCandidateFileForUrl(rawUrl) {
  return path.join(SITE_ANALYSIS_DIR, `ai-value-candidate__${safeAnalysisHost(rawUrl)}__${safeAnalysisRoute(rawUrl)}.json`);
}

function aiSiteCandidateFileForUrl(rawUrl) {
  return path.join(SITE_ANALYSIS_DIR, `site-candidate__${safeAnalysisHost(rawUrl)}__${safeAnalysisRoute(rawUrl)}.json`);
}

function aiVerifiedSiteCandidateFileForUrl(rawUrl) {
  return path.join(SITE_ANALYSIS_DIR, `site-verified__${safeAnalysisHost(rawUrl)}__${safeAnalysisRoute(rawUrl)}.json`);
}

function readJsonFile(file) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); }
  catch (error) { throw new Error(`无法读取 JSON：${path.basename(file)}（${error && error.message || error}）`); }
}

function profileFingerprint(profile) {
  try { return crypto.createHash("sha256").update(JSON.stringify(profile || {})).digest("hex").slice(0, 24); }
  catch (_) { return ""; }
}

function readCurrentProfileFingerprint() {
  try { return profileFingerprint(loadProfile(PROFILE_FILE)); } catch (_) { return ""; }
}

function requestJsonViaElectron(rawUrl, apiKey, payload, timeoutMs) {
  return new Promise((resolve, reject) => {
    let done = false;
    const timer = setTimeout(() => {
      if (done) return;
      done = true;
      try { request.abort(); } catch (_) {}
      reject(new Error("AI API 请求超时"));
    }, Math.max(10000, Number(timeoutMs || 90000)));
    let request;
    try {
      request = net.request({ method: "POST", url: rawUrl });
      request.setHeader("Content-Type", "application/json");
      request.setHeader("Accept", "application/json");
      request.setHeader("Authorization", `Bearer ${apiKey}`);
      request.on("response", (response) => {
        const chunks = [];
        response.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
        response.on("end", () => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          const text = Buffer.concat(chunks).toString("utf8");
          let body = null;
          try { body = text ? JSON.parse(text) : {}; }
          catch (_) { return reject(new Error(`AI API 返回非 JSON（HTTP ${response.statusCode}）`)); }
          if (response.statusCode < 200 || response.statusCode >= 300) {
            const message = body && body.error && (body.error.message || body.error.code) || body && body.message || `HTTP ${response.statusCode}`;
            return reject(new Error("AI API 请求失败：" + String(message).slice(0, 500)));
          }
          resolve({ body, statusCode: response.statusCode });
        });
      });
      request.on("error", (error) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        reject(new Error("AI API 网络错误：" + (error && error.message || error)));
      });
      request.write(JSON.stringify(payload));
      request.end();
    } catch (error) {
      clearTimeout(timer);
      reject(error);
    }
  });
}

function appendSiteAnalysis(record, rawUrl) {
  const file = path.join(SITE_ANALYSIS_DIR, `${timestampName()}__${safeAnalysisHost(rawUrl)}.json`);
  fs.writeFileSync(file, JSON.stringify(record, null, 2), "utf8");
  return file;
}

function safeAnalysisRoute(rawUrl) {
  try {
    const pathname = new URL(rawUrl).pathname || "/";
    const slug = pathname.replace(/[^a-z0-9._-]+/gi, "_").replace(/^_+|_+$/g, "").slice(0, 100);
    return slug || "root";
  } catch (_) {
    return "root";
  }
}

function siteAnalysisFingerprint(record) {
  const analysis = record && record.analysis || {};
  const staticScan = analysis.staticScan || {};
  const interactive = analysis.interactive || {};
  const navigation = analysis.navigation || {};
  const compact = {
    page: analysis.page || {},
    configProbe: analysis.configProbe || {},
    sections: Array.isArray(staticScan.sections) ? staticScan.sections.map((section) => ({
      title: String(section && section.title || ""),
      fieldCount: Number(section && section.fieldCount || 0),
      labels: Array.isArray(section && section.labels) ? section.labels.slice(0, 80) : [],
      controlTypes: Array.isArray(section && section.controlTypes) ? section.controlTypes.slice(0, 30) : []
    })) : [],
    fields: Array.isArray(staticScan.fields) ? staticScan.fields.map((field) => ({
      section: String(field && field.section || ""),
      label: String(field && field.label || ""),
      controlType: String(field && field.controlType || ""),
      name: String(field && field.name || ""),
      id: String(field && field.id || ""),
      placeholder: String(field && field.placeholder || ""),
      selectorHint: String(field && field.selectorHint || ""),
      selectorHitCount: Number(field && field.selectorHitCount || 0)
    })) : [],
    navigation: Array.isArray(navigation.items) ? navigation.items.map((item) => ({
      text: String(item && item.text || ""),
      active: !!(item && item.active),
      hrefPath: String(item && item.hrefPath || "")
    })) : [],
    candidates: Array.isArray(interactive.candidates) ? interactive.candidates.map((item) => ({
      title: String(item && item.title || ""),
      actionType: String(item && item.actionType || ""),
      initialControlCount: Number(item && item.initialControlCount || 0)
    })) : []
  };
  return crypto.createHash("sha256").update(JSON.stringify(compact)).digest("hex").slice(0, 20);
}

function siteAnalysisBundleFileForUrl(rawUrl) {
  return path.join(SITE_ANALYSIS_DIR, `bundle__${safeAnalysisHost(rawUrl)}__${safeAnalysisRoute(rawUrl)}.json`);
}

function stableAnalyzedNavigationSelector(selector) {
  const text = String(selector || "").trim();
  if (!text) return false;
  if (/(?:^|[.\s:#\[])(?:on|active|selected|current|checked|is-active|is-selected|is-current)(?:$|[.\s:#\]])/i.test(text)) return false;
  return !/[{};]/.test(text);
}

function loadLatestAnalyzedNavigationPlan(rawUrl) {
  const bundleFile = siteAnalysisBundleFileForUrl(rawUrl);
  if (!fs.existsSync(bundleFile)) throw new Error("尚无站点分析快照，请先点击“分析本站”");
  const bundle = readJsonFile(bundleFile);
  const snapshots = Array.isArray(bundle && bundle.snapshots) ? bundle.snapshots.slice().reverse() : [];
  const snapshot = snapshots.find((item) => {
    const nav = item && item.analysis && item.analysis.navigation;
    return nav && Number(nav.discoveryVersion || 0) >= 3 && Array.isArray(nav.items) && nav.items.length >= 2;
  });
  if (!snapshot) throw new Error("没有可用于事务测试的 canonical navigation 快照，请重新“分析本站”");
  const items = snapshot.analysis.navigation.items.filter((item) => item && item.text);
  const activeItems = items.filter((item) => item.active === true);
  if (activeItems.length !== 1) throw new Error(`当前导航 active 状态不唯一（${activeItems.length} 项），拒绝执行事务`);
  const active = activeItems[0];
  const activeIndex = items.indexOf(active);
  const target = activeIndex >= 0 ? items[activeIndex + 1] : null;
  if (!target) throw new Error("当前已经是分析快照中的最后一个分区，没有下一分区可测试");
  for (const [label, item] of [["当前分区", active], ["目标分区", target]]) {
    if (Number(item.selectorHitCount || 0) !== 1) throw new Error(`${label} selector 不是唯一命中，拒绝执行事务`);
    if (!stableAnalyzedNavigationSelector(item.selectorHint)) throw new Error(`${label} selector 含动态/不安全状态，拒绝执行事务`);
    if (String(item.source || "") !== "semantic_text_fallback" || Number(item.clusterSize || 0) < 3) {
      throw new Error(`${label} 不是 canonical resume rail 项，拒绝执行事务`);
    }
  }
  // Build65 仍只验证第一跳；教育编辑器探测使用独立、用户触发的只读结构探针。
  if (String(active.text) !== "基本信息" || String(target.text) !== "教育背景") {
    throw new Error(`Build65 仅允许测试“基本信息 → 教育背景”，当前为“${active.text} → ${target.text}”`);
  }
  return {
    bundleFile,
    snapshotAt: String(snapshot.at || ""),
    from: {
      text: String(active.text || ""),
      selectorHint: String(active.selectorHint || ""),
      selectorHitCount: Number(active.selectorHitCount || 0)
    },
    target: {
      text: String(target.text || ""),
      selectorHint: String(target.selectorHint || ""),
      selectorHitCount: Number(target.selectorHitCount || 0)
    }
  };
}


function loadLatestAnalyzedSectionProbePlan(rawUrl, sectionText) {
  const bundleFile = siteAnalysisBundleFileForUrl(rawUrl);
  if (!fs.existsSync(bundleFile)) throw new Error("尚无站点分析快照，请先点击“分析本站”");
  const bundle = readJsonFile(bundleFile);
  const snapshots = Array.isArray(bundle && bundle.snapshots) ? bundle.snapshots.slice().reverse() : [];
  const wanted = String(sectionText || "").trim();
  const snapshot = snapshots.find((item) => {
    const nav = item && item.analysis && item.analysis.navigation;
    return nav && Number(nav.discoveryVersion || 0) >= 3 && Array.isArray(nav.items) && nav.items.some((entry) => String(entry && entry.text || "") === wanted);
  });
  if (!snapshot) throw new Error(`没有包含“${wanted}”的 canonical navigation 快照，请重新“分析本站”`);
  const items = snapshot.analysis.navigation.items.filter((item) => item && item.text);
  const matches = items.filter((item) => String(item.text || "") === wanted);
  if (matches.length !== 1) throw new Error(`分析快照中的“${wanted}”导航项不唯一（${matches.length} 项），拒绝探测`);
  const item = matches[0];
  if (Number(item.selectorHitCount || 0) !== 1) throw new Error(`“${wanted}” selector 不是唯一命中，拒绝探测`);
  if (!stableAnalyzedNavigationSelector(item.selectorHint)) throw new Error(`“${wanted}” selector 含动态/不安全状态，拒绝探测`);
  if (String(item.source || "") !== "semantic_text_fallback" || Number(item.clusterSize || 0) < 3) {
    throw new Error(`“${wanted}”不是 canonical resume rail 项，拒绝探测`);
  }
  return {
    bundleFile,
    snapshotAt: String(snapshot.at || ""),
    section: {
      text: String(item.text || ""),
      selectorHint: String(item.selectorHint || ""),
      selectorHitCount: Number(item.selectorHitCount || 0)
    }
  };
}


function loadLatestAnalyzedMultiSectionSurveyPlan(rawUrl, sectionTexts) {
  const bundleFile = siteAnalysisBundleFileForUrl(rawUrl);
  if (!fs.existsSync(bundleFile)) throw new Error("尚无站点分析快照，请先点击“分析本站”");
  const bundle = readJsonFile(bundleFile);
  const wanted = Array.isArray(sectionTexts) ? sectionTexts.map((x) => String(x || "").trim()).filter(Boolean) : [];
  const snapshots = Array.isArray(bundle && bundle.snapshots) ? bundle.snapshots.slice().reverse() : [];
  const snapshot = snapshots.find((item) => {
    const nav = item && item.analysis && item.analysis.navigation;
    if (!nav || Number(nav.discoveryVersion || 0) < 3 || !Array.isArray(nav.items)) return false;
    const names = nav.items.map((entry) => String(entry && entry.text || ""));
    return wanted.every((name) => names.includes(name));
  });
  if (!snapshot) throw new Error("没有同时包含后续简历分区的 canonical navigation 快照，请重新“分析本站”");
  const items = snapshot.analysis.navigation.items.filter((item) => item && item.text);
  const sections = wanted.map((name) => {
    const matches = items.filter((item) => String(item.text || "") === name);
    if (matches.length !== 1) throw new Error(`分析快照中的“${name}”导航项不唯一（${matches.length} 项），拒绝批量探测`);
    const item = matches[0];
    if (Number(item.selectorHitCount || 0) !== 1) throw new Error(`“${name}” selector 不是唯一命中，拒绝批量探测`);
    if (!stableAnalyzedNavigationSelector(item.selectorHint)) throw new Error(`“${name}” selector 含动态/不安全状态，拒绝批量探测`);
    if (String(item.source || "") !== "semantic_text_fallback" || Number(item.clusterSize || 0) < 3) {
      throw new Error(`“${name}”不是 canonical resume rail 项，拒绝批量探测`);
    }
    return {
      text: String(item.text || ""),
      selectorHint: String(item.selectorHint || ""),
      selectorHitCount: Number(item.selectorHitCount || 0)
    };
  });
  return { bundleFile, snapshotAt: String(snapshot.at || ""), sections };
}

function updateSiteAnalysisBundle(record, rawUrl, analysisFile) {
  let hostname = "site";
  let pathname = "/";
  try {
    const u = new URL(rawUrl);
    hostname = u.hostname.toLowerCase();
    pathname = u.pathname || "/";
  } catch (_) {}
  const bundleFile = siteAnalysisBundleFileForUrl(rawUrl);
  let bundle = {
    schemaType: "autofill-lite-site-analysis-bundle",
    schemaVersion: 1,
    hostname,
    pathname,
    updatedAt: new Date().toISOString(),
    snapshots: [],
    observed: { sections: [], navigationItems: [], controlTypes: [] }
  };
  if (fs.existsSync(bundleFile)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(bundleFile, "utf8"));
      if (parsed && parsed.schemaType === bundle.schemaType && Array.isArray(parsed.snapshots)) bundle = parsed;
    } catch (_) {}
  }
  const fingerprint = siteAnalysisFingerprint(record);
  const snapshot = {
    fingerprint,
    at: String(record && record.at || new Date().toISOString()),
    buildId: String(record && record.buildId || BUILD_ID),
    fileName: path.basename(analysisFile || ""),
    summary: record && record.summary || {},
    siteSupportProbe: record && record.siteSupportProbe || {},
    analysis: record && record.analysis || {}
  };
  const existingIndex = bundle.snapshots.findIndex((item) => item && item.fingerprint === fingerprint);
  if (existingIndex >= 0) bundle.snapshots.splice(existingIndex, 1);
  bundle.snapshots.push(snapshot);
  bundle.snapshots = bundle.snapshots.slice(-10);

  const sectionSet = new Set();
  const navSet = new Set();
  const typeSet = new Set();
  bundle.snapshots.forEach((item) => {
    const a = item && item.analysis || {};
    const scan = a.staticScan || {};
    (Array.isArray(scan.sections) ? scan.sections : []).forEach((section) => {
      const title = String(section && section.title || "").trim();
      if (title) sectionSet.add(title);
    });
    (Array.isArray(scan.fields) ? scan.fields : []).forEach((field) => {
      const type = String(field && field.controlType || "").trim();
      if (type) typeSet.add(type);
    });
    const navigation = a.navigation || {};
    (Array.isArray(navigation.items) ? navigation.items : []).forEach((nav) => {
      const text = String(nav && nav.text || "").trim();
      if (text) navSet.add(text);
    });
  });
  bundle.updatedAt = new Date().toISOString();
  bundle.hostname = hostname;
  bundle.pathname = pathname;
  bundle.observed = {
    sections: Array.from(sectionSet).slice(0, 120),
    navigationItems: Array.from(navSet).slice(0, 120),
    controlTypes: Array.from(typeSet).slice(0, 80)
  };
  fs.writeFileSync(bundleFile, JSON.stringify(bundle, null, 2), "utf8");
  return { file: bundleFile, snapshotCount: bundle.snapshots.length, fingerprint };
}


function readBookmarkLibrary() {
  if (!fs.existsSync(BOOKMARK_FILE)) {
    const initial = createEmptyLibrary();
    fs.writeFileSync(BOOKMARK_FILE, JSON.stringify(initial, null, 2), "utf8");
    return initial;
  }
  try {
    return normalizeLibrary(JSON.parse(fs.readFileSync(BOOKMARK_FILE, "utf8")));
  } catch (error) {
    const broken = path.join(BOOKMARK_DIR, `bookmarks.${timestampName()}.broken.json`);
    try { fs.copyFileSync(BOOKMARK_FILE, broken); } catch (_) {}
    const initial = createEmptyLibrary();
    fs.writeFileSync(BOOKMARK_FILE, JSON.stringify(initial, null, 2), "utf8");
    return initial;
  }
}

function writeBookmarkLibrary(library) {
  const normalized = normalizeLibrary(library);
  if (fs.existsSync(BOOKMARK_FILE)) {
    const backup = path.join(BOOKMARK_DIR, `bookmarks.${timestampName()}.bak.json`);
    try { fs.copyFileSync(BOOKMARK_FILE, backup); } catch (_) {}
  }
  const tmp = BOOKMARK_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(normalized, null, 2), "utf8");
  fs.copyFileSync(tmp, BOOKMARK_FILE);
  fs.unlinkSync(tmp);
  return normalized;
}

function sanitizeBookmarkPrefill(payload) {
  const raw = payload && typeof payload === "object" ? payload : {};
  let url = "";
  try { url = raw.url ? cleanUrl(raw.url) : ""; } catch (_) { url = ""; }
  return {
    name: String(raw.name || "").replace(/\s+/g, " ").trim().slice(0, 200),
    url
  };
}


function readRawProfile() {
  return JSON.parse(fs.readFileSync(PROFILE_FILE, "utf8"));
}

function validateRawProfile(raw) {
  if (!raw || typeof raw !== "object" || !raw.profileV2 || !raw.profileV2.sections) {
    throw new Error("资料结构无效：缺少 profileV2.sections");
  }
  return raw;
}

function writeRawProfile(raw) {
  validateRawProfile(raw);
  const next = JSON.parse(JSON.stringify(raw));
  if (next.profileV2 && typeof next.profileV2 === "object") {
    next.profileV2.updatedAt = new Date().toISOString();
  }
  const backupName = `candidate-profile-merged.${timestampName()}.bak.json`;
  const backupPath = path.join(PROFILE_DIR, backupName);
  if (fs.existsSync(PROFILE_FILE)) fs.copyFileSync(PROFILE_FILE, backupPath);
  const tmp = PROFILE_FILE + ".tmp";
  const serialized = JSON.stringify(next, null, 2);
  fs.writeFileSync(tmp, serialized, "utf8");
  fs.copyFileSync(tmp, PROFILE_FILE);
  fs.unlinkSync(tmp);

  // Build161: saving the library is only considered successful after the exact
  // runtime file used by one-click autofill can be read back and normalized.
  const readBack = readRawProfile();
  const normalized = loadProfile(PROFILE_FILE);
  const savedSerialized = JSON.stringify(readBack, null, 2);
  if (savedSerialized !== serialized) {
    throw new Error("资料已写入但读回内容不一致；为避免使用旧资料，本次保存视为失败");
  }
  return {
    ok: true,
    backupName,
    profileFile: PROFILE_FILE,
    updatedAt: String(readBack && readBack.profileV2 && readBack.profileV2.updatedAt || ""),
    profileHash: crypto.createHash("sha256").update(savedSerialized).digest("hex").slice(0, 16),
    summary: summarizeResumeData(normalized)
  };
}

// Build 23: refresh the education option wording to the exact values used by the
// current Zhaopin higher-education form while preserving the previously confirmed facts.
// Existing portable installs keep a persistent profile, so this migration uses a new id
// and writes through the normal backup path exactly once.
function applyBuild23EducationOptionWordingMigration() {
  const migrationId = "20260914-education-option-wording-23";
  try {
    const raw = readRawProfile();
    const profileV2 = raw && raw.profileV2;
    if (!profileV2 || !profileV2.sections || !profileV2.sections.education) return;
    const migrations = Array.isArray(profileV2.migrations) ? profileV2.migrations : [];
    if (migrations.includes(migrationId)) return;
    const items = Array.isArray(profileV2.sections.education.items) ? profileV2.sections.education.items : [];
    let changed = false;
    items.forEach((item) => {
      const values = item && item.values;
      if (!values || typeof values !== "object") return;
      const level = String(values["学历"] || item.title || "");
      let patch = null;
      if (/本科/.test(level)) {
        patch = {
          "专业课程": "财政学、税收学、金融学",
          "成绩": "3.23",
          "个人绩点": "3.23",
          "年级排名": "其他",
          "班级排名": "其他",
          "是否贯通式培养": "非贯通式培养",
          "是否有国外、港澳台地区学习经历": "否",
          "是否为海外教育经历": "否",
          "培养方式": "非定向就业",
          "学制": "四年制"
        };
      } else if (/硕士|研究生/.test(level)) {
        patch = {
          "专业": "金融",
          "研究方向": "证券投资与金融管理",
          "专业课程": "金融学、投资学、公司金融",
          "成绩": "3.61",
          "个人绩点": "3.61",
          "年级排名": "其他",
          "班级排名": "其他",
          "是否贯通式培养": "非贯通式培养",
          "是否有国外、港澳台地区学习经历": "否",
          "是否为海外教育经历": "否",
          "培养方式": "非定向就业",
          "学制": "两年制"
        };
      }
      if (!patch) return;
      Object.keys(patch).forEach((key) => {
        if (values[key] !== patch[key]) {
          values[key] = patch[key];
          changed = true;
        }
      });
    });
    profileV2.migrations = migrations.concat([migrationId]);
    changed = true;
    if (changed) writeRawProfile(raw);
  } catch (error) {
    // A profile migration must never prevent the app from starting. The user can still
    // edit the local profile through the built-in profile editor if migration fails.
    console.warn("Build 23 education option wording migration skipped:", error && error.message ? error.message : error);
  }
}

applyBuild23EducationOptionWordingMigration();


// Build 29: canonicalize the confirmed bachelor study length to “四年制”.
// Matching remains semantic: 四年制 / 四年 / 4年制 / 4年 / 4 / 48个月 all
// resolve to the same 4-year meaning through DomUtils.parseStudyYears/isOptionMatch.
// Existing portable profiles are persistent, so migrate them once with backup.
function applyBuild29BachelorStudyLengthMigration() {
  const migrationId = "20260914-education-bachelor-study-length-29";
  try {
    const raw = readRawProfile();
    const profileV2 = raw && raw.profileV2;
    if (!profileV2 || !profileV2.sections || !profileV2.sections.education) return;
    const migrations = Array.isArray(profileV2.migrations) ? profileV2.migrations : [];
    if (migrations.includes(migrationId)) return;
    const items = Array.isArray(profileV2.sections.education.items) ? profileV2.sections.education.items : [];
    let changed = false;
    items.forEach((item) => {
      const values = item && item.values;
      if (!values || typeof values !== "object") return;
      const level = String(values["学历"] || item.title || "");
      if (!/本科/.test(level)) return;
      if (values["学制"] !== "四年制") {
        values["学制"] = "四年制";
        changed = true;
      }
    });
    profileV2.migrations = migrations.concat([migrationId]);
    changed = true;
    if (changed) writeRawProfile(raw);
  } catch (error) {
    console.warn("Build 29 bachelor study-length migration skipped:", error && error.message ? error.message : error);
  }
}

applyBuild29BachelorStudyLengthMigration();

// Build 33: persist the user-confirmed English exam facts into existing portable
// profiles. Defaults alone do not update an already-created autofill-lite-data
// profile, so migrate exactly once through writeRawProfile (which creates a backup).
function applyBuild33LanguageExamMigration() {
  const migrationId = "20260914-cdb-language-exams-33";
  try {
    const raw = readRawProfile();
    const profileV2 = raw && raw.profileV2;
    if (!profileV2 || !profileV2.sections) return;
    const migrations = Array.isArray(profileV2.migrations) ? profileV2.migrations : [];
    if (migrations.includes(migrationId)) return;
    const language = profileV2.sections.language || (profileV2.sections.language = {
      key: "language", title: "外语能力", kind: "repeat", items: []
    });
    const items = Array.isArray(language.items) ? language.items : (language.items = []);
    let item = items.find((row) => {
      const values = row && row.values || {};
      const text = [values["外语种类"], values["证书名称（技能名称）"]].filter(Boolean).join(" ");
      return /英语|雅思|IELTS/i.test(text);
    });
    if (!item) {
      item = { title: "英语", values: {}, custom: [] };
      items.push(item);
    }
    const values = item.values && typeof item.values === "object" ? item.values : (item.values = {});
    const patch = {
      "外语种类": "英语",
      "CET4成绩": "616",
      "CET6成绩": "532",
      "证书名称（技能名称）": "雅思",
      "成绩": "6.5",
      "其他英语等级考试": "IELTS",
      "其他英语等级考试成绩": "6.5"
    };
    Object.keys(patch).forEach((key) => { values[key] = patch[key]; });
    profileV2.migrations = migrations.concat([migrationId]);
    writeRawProfile(raw);
  } catch (error) {
    console.warn("Build 33 language exam migration skipped:", error && error.message ? error.message : error);
  }
}

applyBuild33LanguageExamMigration();

// Build 36: the CDB student-work description field is capped at 50 Chinese
// characters. The user explicitly approved removing the first clause from the
// Learning Committee Member description. Persist that exact approved wording
// into existing portable profiles; do not truncate any other description.
function applyBuild36StudentDescriptionMigration() {
  const migrationId = "20260914-cdb-student-description-limit-36";
  const oldDescription = "筹备学习经验交流活动，协调师兄师姐与班级同学；对接教务处，完成学校及学院任务，上报学生学习方面的合理诉求，并提供升学、学习和毕业信息指引。";
  const approvedDescription = "对接教务处，完成学校及学院任务，上报学生学习方面的合理诉求，并提供升学、学习和毕业信息指引。";
  try {
    const raw = readRawProfile();
    const profileV2 = raw && raw.profileV2;
    if (!profileV2 || !profileV2.sections) return;
    const migrations = Array.isArray(profileV2.migrations) ? profileV2.migrations : [];
    if (migrations.includes(migrationId)) return;
    const student = profileV2.sections.student;
    const items = student && Array.isArray(student.items) ? student.items : [];
    items.forEach((item) => {
      const values = item && item.values;
      if (!values || typeof values !== "object") return;
      if (String(values["职位"] || "").trim() !== "学习委员") return;
      if (String(values["工作内容"] || "").trim() !== oldDescription) return;
      values["工作内容"] = approvedDescription;
    });
    profileV2.migrations = migrations.concat([migrationId]);
    writeRawProfile(raw);
  } catch (error) {
    console.warn("Build 36 student description migration skipped:", error && error.message ? error.message : error);
  }
}

applyBuild36StudentDescriptionMigration();

// Build 107: the 2026-09-12 merged profile already contains two confirmed
// job-intention records (财务 / 管培生, with expected salary and city preferences).
// Portable installs keep their own persistent profile, so defaults alone cannot
// repair an older copy. Merge only missing intention fields and never overwrite
// a non-empty user-edited value.
function applyBuild107JobIntentionLibraryMigration() {
  const migrationId = "20260917-job-intention-library-107";
  const seeds = [
    {
      title: "求职意向 1",
      values: {
        "意向岗位": "财务",
        "预计入职时间": "2027-07",
        "当前薪资": "0",
        "期望工作城市": "广州、深圳、北京、重庆",
        "期望薪资": "1.2万/月",
        "面试城市": "北京",
        "是否接受调剂": "是"
      }
    },
    {
      title: "求职意向 2",
      values: {
        "意向岗位": "管培生",
        "预计入职时间": "2027-07",
        "当前薪资": "0",
        "期望工作城市": "广州、深圳、北京、重庆",
        "期望薪资": "1.5万/月",
        "面试城市": "北京",
        "是否接受调剂": "是"
      }
    }
  ];
  try {
    const raw = readRawProfile();
    const profileV2 = raw && raw.profileV2;
    if (!profileV2 || !profileV2.sections) return;
    const migrations = Array.isArray(profileV2.migrations) ? profileV2.migrations : [];
    if (migrations.includes(migrationId)) return;
    const intention = profileV2.sections.intention || (profileV2.sections.intention = {
      key: "intention", title: "求职意向", kind: "repeat", items: []
    });
    intention.key = intention.key || "intention";
    intention.title = intention.title || "求职意向";
    intention.kind = "repeat";
    const items = Array.isArray(intention.items) ? intention.items : (intention.items = []);
    const hasValue = (value) => value !== undefined && value !== null && String(value).trim() !== "";
    seeds.forEach((seed, index) => {
      let item = items.find((row) => String(row && row.title || "").trim() === seed.title) || items[index];
      if (!item) {
        item = { title: seed.title, values: {}, custom: [] };
        items.push(item);
      }
      if (!item.title) item.title = seed.title;
      if (!Array.isArray(item.custom)) item.custom = [];
      const values = item.values && typeof item.values === "object" ? item.values : (item.values = {});
      Object.keys(seed.values).forEach((key) => {
        if (!hasValue(values[key])) values[key] = seed.values[key];
      });
    });
    profileV2.migrations = migrations.concat([migrationId]);
    profileV2.updatedAt = new Date().toISOString();
    writeRawProfile(raw);
  } catch (error) {
    console.warn("Build 107 job intention migration skipped:", error && error.message ? error.message : error);
  }
}

applyBuild107JobIntentionLibraryMigration();

// Build145: persist the user-confirmed dual degree wording into existing portable
// profiles as well as fresh defaults. Detailed wording is used by sites whose
// dropdown options are discipline-specific; the simple wording remains available
// for sites that expose only 硕士/学士. Never overwrite a non-empty user edit.
function applyBuild145EducationDegreeVariantMigration() {
  const migrationId = "20260918-education-degree-variants-145";
  try {
    const raw = readRawProfile();
    const profileV2 = raw && raw.profileV2;
    if (!profileV2 || !profileV2.sections) return;
    const migrations = Array.isArray(profileV2.migrations) ? profileV2.migrations : [];
    if (migrations.includes(migrationId)) return;
    const education = profileV2.sections.education;
    const items = education && Array.isArray(education.items) ? education.items : [];
    const hasValue = (value) => value !== undefined && value !== null && String(value).trim() !== "";
    items.forEach((item) => {
      const values = item && item.values;
      if (!values || typeof values !== "object") return;
      const level = String(values["学历"] || item.title || "");
      if (/硕士|研究生/.test(level)) {
        if (!hasValue(values["详细学位"])) values["详细学位"] = "经济学硕士";
        if (!hasValue(values["简化学位"])) values["简化学位"] = "硕士";
      } else if (/本科|学士/.test(level)) {
        if (!hasValue(values["详细学位"])) values["详细学位"] = "经济学学士";
        if (!hasValue(values["简化学位"])) values["简化学位"] = "学士";
      }
    });
    profileV2.migrations = migrations.concat([migrationId]);
    profileV2.updatedAt = new Date().toISOString();
    writeRawProfile(raw);
  } catch (error) {
    console.warn("Build 145 education degree variant migration skipped:", error && error.message ? error.message : error);
  }
}

applyBuild145EducationDegreeVariantMigration();

function normalizeQuestionText(value) {
  return String(value || "")
    .replace(/[\s：:*?？（）()【】\[\]「」'"“”‘’.,，。;；、]/g, "")
    .replace(/必填|选填|请输入|请选择/g, "")
    .toLowerCase();
}

function profileKnownQuestionSet(raw) {
  const set = new Set();
  const add = (label, value) => {
    const key = normalizeQuestionText(label);
    if (key && value !== undefined && value !== null && String(value).trim() !== "") set.add(key);
  };
  try {
    const p2 = raw && raw.profileV2 || {};
    const sections = p2.sections || {};
    Object.values(sections).forEach((section) => {
      if (!section || typeof section !== "object") return;
      Object.entries(section.values || {}).forEach(([k,v]) => add(k,v));
      (section.custom || []).forEach((row) => add(row && row.label, row && row.value));
      (section.items || []).forEach((item) => {
        Object.entries(item && item.values || {}).forEach(([k,v]) => add(k,v));
        (item && item.custom || []).forEach((row) => add(row && row.label, row && row.value));
      });
    });
    (p2.questionBank || []).forEach((row) => add(row && row.question, row && row.answer));
  } catch (_) {}
  return set;
}

async function scanVisibleRequiredFields(wc) {
  try {
    return await runIsolated(wc, `(() => {
      const visible = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const st = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && st.display !== "none" && st.visibility !== "hidden";
      };
      const norm = (s) => String(s || "").replace(/\s+/g," ").replace(/^[*\s]+|[*\s]+$/g,"").trim();
      const labels = Array.from(document.querySelectorAll("label, .el-form-item__label, .ant-form-item-label label, .field-label, .form-label, [class*='label']"));
      const out = [];
      const seen = new Set();
      const add = (label, source) => {
        const key = norm(label).replace(/[：:]+$/g, "").trim();
        if (key && !seen.has(key)) { seen.add(key); out.push({ label: key, source }); }
      };
      for (const label of labels) {
        if (!visible(label)) continue;
        const text = norm(label.innerText || label.textContent);
        if (!text || text.length > 80) continue;
        const holder = label.closest(".el-form-item, .ant-form-item, .form-item, .field-item, .apply-form-item, .floor_view_editor_item") || label.parentElement;
        const required = /\*/.test(label.innerText || label.textContent || "") || !!(holder && (holder.classList.contains("is-required") || holder.querySelector("[required], [aria-required='true']")));
        if (!required || !holder) continue;
        const controls = Array.from(holder.querySelectorAll("input:not([type='hidden']):not([type='file']), textarea, select, [contenteditable='true']")).filter(visible);
        let hasValue = false;
        if (controls.length) {
          hasValue = controls.some((el) => {
            const type = String(el.type || "").toLowerCase();
            if (type === "radio" || type === "checkbox") return !!el.checked;
            if (el.isContentEditable) return !!String(el.innerText || "").trim();
            return !!String(el.value || "").trim();
          });
        } else {
          const selected = holder.querySelector(".el-select__selected-item, .el-input__inner, .ant-select-selection-item, .ant-picker-input input, .selected, [class*='selected']");
          if (selected && visible(selected)) hasValue = !!String(selected.value || selected.innerText || selected.textContent || "").trim();
        }
        if (!hasValue) {
          add(text, "required-empty");
        }
      }
      // Element UI may have rendered a red validation message although the
      // label itself carries neither * nor a required attribute. This remains
      // a page-state signal, not evidence that the profile lacks the value.
      for (const errorNode of Array.from(document.querySelectorAll(".el-form-item.is-error, .el-form-item__error"))) {
        const item = errorNode.classList && errorNode.classList.contains("el-form-item")
          ? errorNode : errorNode.closest(".el-form-item");
        if (!item || !visible(item)) continue;
        const labelNode = item.querySelector(".el-form-item__label, label, .field-label, .form-label, [class*='label']");
        const label = norm(labelNode && (labelNode.innerText || labelNode.textContent));
        if (label) add(label, "element-validation");
      }
      return out.slice(0, 80);
    })()`);
  } catch (_) { return []; }
}

function routeInfoForUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    const hostname = url.hostname.toLowerCase();
    return { hostname, pathname: url.pathname, cid: hostname === "xiaoyuan.zhaopin.com" ? (url.searchParams.get("cid") || "") : "" };
  } catch (_) {
    return { hostname: "", pathname: "", cid: "" };
  }
}

async function collectZhaopinPageDebug(wc) {
  try {
    return await runIsolated(wc, `(() => {
      const normalize = (value) => String(value || "").replace(/\\s+/g, "").trim();
      const titles = Array.from(document.querySelectorAll(".resume-menu-item__title")).map((node) => normalize(node.textContent)).filter(Boolean);
      const isRecognized = (title) => /^(?:个人信息|教育经历|高等教育经历)$/.test(title)
        || /^(?:投递信息|求职意向|是否服从调剂)$/.test(title)
        || /^(?:实习工作|实习工作经历|实习经历|全职工作经历|正式工作经历|工作经历)$/.test(title)
        || /实习\s*[\/／]\s*工作经历|工作\s*[\/／]\s*实习经历/.test(title)
        || /项目经历|项目经验/.test(title)
        || /^(?:学生工作|学生工作经历|学生干部经历)$/.test(title)
        || /^(?:奖励情况|奖励荣誉|荣誉奖励|获奖经历)$/.test(title)
        || /^(?:语言情况|语言能力|语言技能)$/.test(title)
        || /^(?:家庭信息|家庭情况|家庭关系|个人特长)$/.test(title)
        || /专业技能|资格证书/.test(title)
        || /自我评价|其他信息|其他说明/.test(title);
      const activeMenu = document.querySelector(".resume-menu-item.active .resume-menu-item__title, .resume-menu-item.is-active .resume-menu-item__title, .resume-menu-item.current .resume-menu-item__title, .resume-menu-item[class*='active'] .resume-menu-item__title, .resume-menu-item[class*='selected'] .resume-menu-item__title, .resume-menu-item[aria-current='true'] .resume-menu-item__title, [aria-current='page'].resume-menu-item__title, .resume-menu-item__title.active, .resume-menu-item__title.is-active, .resume-menu-item__title[class*='selected']");
      const visibleTitles = Array.from(document.querySelectorAll(".apply-module .form-content--title, [class*='section-title'], [class*='module-title'], h1, h2, h3, h4, h5, h6")).filter((node) => { const r = node.getBoundingClientRect(), s = getComputedStyle(node); return r.width > 0 && r.height > 0 && r.bottom > 0 && r.top < innerHeight && s.display !== 'none' && s.visibility !== 'hidden'; }).map((node) => ({ node, distance: Math.abs(node.getBoundingClientRect().top - 100) })).sort((a,b) => a.distance - b.distance);
      const visibleTitle = visibleTitles.length ? visibleTitles[0].node : null;
      return {
        menuTitles: titles,
        recognizedModules: titles.filter(isRecognized),
        unrecognizedModules: titles.filter((title) => !isRecognized(title)),
        currentSectionTitle: normalize((activeMenu || visibleTitle) && (activeMenu || visibleTitle).textContent).replace(/必填/g, "")
      };
    })()`);
  } catch (_) {
    return { menuTitles: [], recognizedModules: [], unrecognizedModules: [], currentSectionTitle: "" };
  }
}

async function collectZhaopinHigherEducationDebug(wc, enabled) {
  const empty = { trace: { scope: { resolved: false, strategy: "", visibleLabelCount: 0, controlCount: 0, reason: "workflow_not_enabled" }, records: [] }, coverage: { state: "scope_not_resolved", visibleLabels: [], requiredLabels: [], mappedLabels: [], unmappedRequiredLabels: [], complete: false }, ownership: { owner: "fallback", specialReady: false, genericOwnerSuppressed: false, reason: "higher_education_scope_not_resolved" }, currentVisibleEditorMode: false };
  if (!enabled) return empty;
  try {
    return await runIsolated(wc, `(() => {
      const norm = (s) => String(s || '').replace(/\\s+/g, '').replace(/必填/g, '').replace(/[＊*：:]/g, '').trim();
      const visible = (el) => { if (!el) return false; const r = el.getBoundingClientRect(), s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden'; };
      const mapped = ['学校名称','办学属地','该段教育经历内是否有国外、港澳台地区学习经历','学历','研究方向','院系','专业','专业课程','学习形式','学制','学科属性','学位','是否贯通式培养','是否本硕连读','培养方式','个人绩点','年级排名','班级排名','入学时间','毕业时间'];
      const safeLabels = (root) => Array.from((root || document).querySelectorAll("label,.el-form-item__label,[class*='label'],[class*='title'],span,div")).filter((n) => visible(n) && mapped.includes(norm(n.textContent)));
      const title = Array.from(document.querySelectorAll('.form-content--title,.resume-menu-item__title,[class*=title]')).filter(visible).find((n) => norm(n.textContent) === '高等教育经历');
      const section = title && title.closest('.apply-module');
      const root = section || document;
      const allLabels = safeLabels(root);
      const keys = ['学校名称','学历','学位'];
      const secondary = ['专业','学科属性','入学时间','毕业时间','办学属地'];
      const anchors = allLabels.filter((n) => keys.includes(norm(n.textContent)));
      const valid = (scope) => { if (!scope || scope === document || !visible(scope)) return false; const texts=safeLabels(scope).map((n)=>norm(n.textContent)); const controls=Array.from(scope.querySelectorAll("input:not([type=hidden]):not([type=file]),textarea,select,.el-select,.el-date-editor,[role=combobox]")).filter(visible); return keys.every((x)=>texts.includes(x)) && secondary.some((x)=>texts.includes(x)) && controls.length>=3; };
      let scope=null, strategy='';
      const configured = section ? Array.from(section.querySelectorAll('.apply-module__form')).filter(visible).find(valid) : null;
      if(configured){scope=configured;strategy='configured_selector';}
      if(!scope && anchors.length>=3){ let node=anchors[0]; for(let d=0;node&&node!==document.body&&d<10;d++,node=node.parentElement){ if(anchors.every((a)=>node.contains(a))&&valid(node)){scope=node;strategy='semantic_common_ancestor';break;} } }
      const labelNodes = scope ? safeLabels(scope) : [];
      const visibleLabels = Array.from(new Set(labelNodes.map((n) => norm(n.textContent)).filter(Boolean)));
      const requiredLabels = Array.from(new Set(labelNodes.filter((n) => {
        const item = n.closest('.el-form-item');
        return /\\*/.test(n.textContent || '') || !!(item && (item.classList.contains('is-required') || item.classList.contains('is-error')));
      }).map((n) => norm(n.textContent)).filter(Boolean)));
      let trace = {};
      try { trace = JSON.parse(document.documentElement.getAttribute('data-af-zhaopin-higher-education-trace') || '{}'); } catch (_) {}
      const controlCount = scope ? Array.from(scope.querySelectorAll("input:not([type=hidden]),textarea,select,.el-select,.el-date-editor,[role=combobox]")).filter(visible).length : 0;
      const scopeResolved = !!scope || !!(trace && trace.scope && trace.scope.resolved);
      if (!trace || typeof trace !== 'object') trace = {};
      if (!trace.scope) trace.scope = { resolved: !!scope, strategy, visibleLabelCount: visibleLabels.length, controlCount, reason: scope ? '' : 'higher_education_scope_not_resolved' };
      if (!Array.isArray(trace.records)) trace.records = [];
      const unmappedRequiredLabels = requiredLabels.filter((label) => !mapped.includes(label));
      const complete = scopeResolved && requiredLabels.length > 0 && unmappedRequiredLabels.length === 0;
      const editorReady = !!(trace && trace.editableRootFound);
      return {
        trace,
        coverage: { state: !scopeResolved || visibleLabels.length === 0 ? 'scope_not_resolved' : (complete ? 'complete' : 'incomplete'), visibleLabels, requiredLabels, mappedLabels: mapped.filter((label) => visibleLabels.includes(label)), unmappedRequiredLabels, complete },
        ownership: { category: 'education', section: '高等教育经历', owner: editorReady ? 'generic-scoped-record-filler' : 'fallback', specialReady: false, genericOwnerSuppressed: false, reason: editorReady ? '' : 'higher_education_editor_not_open' },
        currentVisibleEditorMode: editorReady
      };
    })()`);
  } catch (_) { return empty; }
}

async function collectTencentTextareaDebug(wc, rawUrl) {
  if (!/^https?:\/\/join\.qq\.com\/resumeedit\.html/i.test(String(rawUrl || ""))) return {};
  try {
    return await runIsolated(wc, `(() => {
      const visible = (el) => { const r = el.getBoundingClientRect(), s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden'; };
      const controls = Array.from(document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]')).filter(visible);
      const items = controls.map((el) => { const card = el.closest('.send_box, .el-form-item, [class*="experience"], [class*="intern"], [class*="project"]'); const hint = card ? Array.from(card.querySelectorAll('.send_title, .subtitle, label, .el-form-item__label')).map((node) => String(node.textContent || '').replace(/\s+/g, ' ').trim()).filter(Boolean).slice(0, 3).join(' ') : ''; const internship = /实习|公司.*职位|职位.*公司/.test(hint); const project = /项目名称|项目中担任|项目经历/.test(hint); return { placeholder: el.getAttribute('placeholder') || '', ariaLabel: el.getAttribute('aria-label') || '', className: String(el.className || ''), visible: true, closestSectionTextHint: hint, closestCardClass: String(card && card.className || ''), insideInternshipSection: internship, insideProjectSection: !internship && project, tag: el.tagName.toLowerCase(), controlType: el.isContentEditable ? 'contenteditable' : (el.getAttribute('role') === 'textbox' ? 'role-textbox' : 'textarea') }; });
      return { pageVisibleTextareaCount: items.filter(x => x.controlType === 'textarea').length, experienceVisibleTextareaCount: items.filter(x => x.insideInternshipSection || x.insideProjectSection).length, items };
    })()`);
  } catch (_) { return {}; }
}

async function collectZhiyeEducationDebug(wc, rawUrl, profileEducationCount) {
  if (!/(^|\.)zhiye\.com$/i.test(new URL(rawUrl).hostname) || new URL(rawUrl).pathname !== "/form") return {};
  try {
    return await runIsolated(wc, `(() => {
      const visible = (el) => { const r=el.getBoundingClientRect(),s=getComputedStyle(el); return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'; };
      const norm = (s) => String(s||'').replace(/[\\s:*：]/g,'');
      const schoolLabels = Array.from(document.querySelectorAll('label,.form-item__text,.el-form-item__label,[class*=label]')).filter(el => visible(el) && /^(学校名称|学校|毕业院校)$/.test(norm(el.textContent)));
      const cards = [];
      for (const label of schoolLabels) {
        let node=label.parentElement, best=null;
        for(let d=0;node&&d<8;d++,node=node.parentElement){ const t=norm(Array.from(node.querySelectorAll('label,.form-item__text,.el-form-item__label,[class*=label]')).map(x=>x.textContent).join(' ')); if(/学校/.test(t)&&/专业/.test(t)&&/学历/.test(t)&&/学位/.test(t)){best=node;break;} }
        if(best&&!cards.includes(best)) cards.push(best);
      }
      const details = cards.map((card,index)=>{ const labels=norm(Array.from(card.querySelectorAll('label,.form-item__text,.el-form-item__label,[class*=label]')).map(x=>x.textContent).join(' ')); const controls=Array.from(card.querySelectorAll('input,select,textarea,[role=combobox]')).filter(visible); const editable=controls.filter(x=>!x.disabled&&!x.readOnly); const nonBlank=controls.some(x=>String(x.value||'').trim()||x.getAttribute('aria-selected')==='true'); return {pageIndex:index,inputCount:controls.filter(x=>x.tagName==='INPUT').length,selectCount:controls.filter(x=>x.tagName==='SELECT'||x.getAttribute('role')==='combobox').length,dateControlCount:controls.filter(x=>/date|time|日期|时间/i.test([x.type,x.placeholder,x.className].join(' '))).length,hasSchool:/学校/.test(labels),hasMajor:/专业/.test(labels),hasLevel:/学历/.test(labels),hasDegree:/学位/.test(labels),isBlankBefore:!nonBlank,editableControlCount:editable.length}; });
      return {profileEducationCount:${Number(profileEducationCount || 0)},educationContainerFound:cards.length>0,candidateCardCount:cards.length,visibleCardCount:cards.filter(visible).length,addButtonFound:Array.from(document.querySelectorAll('button,a,[role=button]')).filter(visible).some(x=>/添加.*教育|新增.*教育/.test(norm(x.textContent))),cards:details};
    })()`);
  } catch (_) { return {}; }
}

function readManifestScripts() {
  const manifest = JSON.parse(fs.readFileSync(path.join(APP_ROOT, "autofill-plugin", "manifest.json"), "utf8"));
  const isolated = [];
  const main = [];
  for (const item of manifest.content_scripts || []) {
    const target = String(item.world || "").toUpperCase() === "MAIN" ? main : isolated;
    for (const rel of item.js || []) target.push(rel);
  }
  return { isolated, main };
}

const SCRIPT_LIST = readManifestScripts();
const AUTOFILL_WORLD_ID = 1004;
const injectedDocuments = new Map();

function readCoreScript(rel) {
  const file = path.join(APP_ROOT, "autofill-plugin", rel);
  if (!file.startsWith(path.join(APP_ROOT, "autofill-plugin"))) throw new Error("非法脚本路径");
  return fs.readFileSync(file, "utf8") + `\n//# sourceURL=autofill-lite://${rel}`;
}

async function runIsolated(wc, code) {
  return wc.executeJavaScriptInIsolatedWorld(AUTOFILL_WORLD_ID, [{ code }], true);
}

async function coreReady(wc) {
  try {
    return !!(await runIsolated(wc, `Boolean(window.OfferAutofill && window.AF && window.AF.SiteLoader && window.AF.FillEngine)`));
  } catch (_) {
    return false;
  }
}

async function injectAutofillCore(wc) {
  if (!wc || wc.isDestroyed()) throw new Error("网页已关闭");
  if (await coreReady(wc)) return { injected: false, alreadyReady: true };

  for (const rel of SCRIPT_LIST.isolated) {
    await runIsolated(wc, readCoreScript(rel));
  }
  for (const rel of SCRIPT_LIST.main) {
    await wc.executeJavaScript(readCoreScript(rel), true);
  }
  const ready = await coreReady(wc);
  if (!ready) throw new Error("Autofill Core 注入完成但未就绪");
  injectedDocuments.set(wc.id, { url: safeUrl(wc.getURL()), at: Date.now() });
  return { injected: true, alreadyReady: false };
}

function configCandidatesForUrl(rawUrl) {
  try {
    const u = new URL(rawUrl);
    const host = u.hostname.toLowerCase();
    const safeRoute = u.pathname.replace(/^\/+|\/+$/g, "").replace(/[^a-zA-Z0-9._-]+/g, "_").slice(0, 100);
    return [
      safeRoute ? path.join(CONFIG_DIR, `${host}__${safeRoute}.json`) : null,
      path.join(CONFIG_DIR, `${host}.json`)
    ].filter(Boolean);
  } catch (_) {
    return [];
  }
}

function readLocalConfig(rawUrl) {
  for (const file of configCandidatesForUrl(rawUrl)) {
    if (!fs.existsSync(file)) continue;
    try {
      return { file, config: JSON.parse(fs.readFileSync(file, "utf8")) };
    } catch (error) {
      return { file, error: error.message };
    }
  }
  return null;
}

async function installLocalConfig(wc, rawUrl) {
  const found = readLocalConfig(rawUrl);
  if (!found) return { found: false };
  if (found.error) return { found: true, ok: false, error: found.error, file: found.file };
  const u = new URL(rawUrl);
  const payload = JSON.stringify(found.config);
  const host = JSON.stringify(u.hostname.toLowerCase());
  const urlJson = JSON.stringify(rawUrl);
  const ok = await runIsolated(wc, `(() => {
    try {
      if (!window.AF || !AF.SiteLoader || typeof AF.SiteLoader.setPrefetchedConfig !== "function") return false;
      const cfg = ${payload};
      cfg._source = cfg._source || "autofill_lite_local";
      return AF.SiteLoader.setPrefetchedConfig(${host}, cfg, ${urlJson});
    } catch (e) { return false; }
  })()`);
  return { found: true, ok: !!ok, file: found.file };
}


async function collectSiteSupportProbe(wc, rawUrl) {
  const urlJson = JSON.stringify(rawUrl);
  try {
    const probe = await runIsolated(wc, `(async () => {
      try {
        const AF0 = window.AF || {};
        const loader = AF0.SiteLoader || {};
        const visible = (el) => {
          if (!el || !el.isConnected) return false;
          const style = window.getComputedStyle ? window.getComputedStyle(el) : null;
          if (style && (style.display === "none" || style.visibility === "hidden" || style.opacity === "0")) return false;
          const rect = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
          return !rect || (rect.width > 0 && rect.height > 0);
        };
        let builtIn = null;
        let detected = null;
        try { builtIn = typeof loader._getConfigForUrl === "function" ? loader._getConfigForUrl(${urlJson}) : null; } catch (_) {}
        try { detected = typeof loader._detectSiteType === "function" ? loader._detectSiteType() : null; } catch (_) {}
        const controls = Array.from(document.querySelectorAll("input:not([type='hidden']), textarea, select, [contenteditable='true'], [role='combobox']")).filter(visible);
        const labels = Array.from(document.querySelectorAll("label, .el-form-item__label, .ant-form-item-label, .layui-form-label, .form-label, .control-label, [data-label], [aria-label]")).filter(visible);
        return {
          serverConfigEnabled: !!(AF0.ServerConfig && AF0.ServerConfig.baseUrl),
          builtInConfigFound: !!builtIn,
          builtInConfigType: builtIn && builtIn.type ? String(builtIn.type).slice(0, 40) : "",
          builtInConfigName: builtIn && builtIn.name ? String(builtIn.name).slice(0, 80) : "",
          domPlatformDetected: !!detected,
          domPlatformType: detected && detected.type ? String(detected.type).slice(0, 40) : "",
          domPlatformName: detected && detected.name ? String(detected.name).slice(0, 80) : "",
          visibleEditableControlCount: controls.length,
          visibleLabelLikeCount: labels.length
        };
      } catch (_) {
        return { serverConfigEnabled: false, builtInConfigFound: false, domPlatformDetected: false, visibleEditableControlCount: 0, visibleLabelLikeCount: 0 };
      }
    })()`);
    return probe && typeof probe === "object" ? probe : {};
  } catch (_) {
    return {};
  }
}

function getGuest(id) {
  const wc = webContents.fromId(Number(id));
  if (!wc || wc.isDestroyed()) throw new Error("找不到当前浏览器页面，请刷新后重试");
  return wc;
}

async function ensureDebugger(wc) {
  if (!wc.debugger.isAttached()) {
    try { wc.debugger.attach("1.3"); }
    catch (error) {
      if (!wc.debugger.isAttached()) throw error;
    }
  }
}

function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

async function mouseClick(wc, x, y) {
  await ensureDebugger(wc);
  await wc.debugger.sendCommand("Input.dispatchMouseEvent", { type: "mouseMoved", x, y, button: "none" });
  await wc.debugger.sendCommand("Input.dispatchMouseEvent", { type: "mousePressed", x, y, button: "left", buttons: 1, clickCount: 1 });
  await wc.debugger.sendCommand("Input.dispatchMouseEvent", { type: "mouseReleased", x, y, button: "left", buttons: 0, clickCount: 1 });
}

async function pressKey(wc, key, code, vk, modifiers = 0) {
  await ensureDebugger(wc);
  await wc.debugger.sendCommand("Input.dispatchKeyEvent", { type: "rawKeyDown", key, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk, modifiers });
  await wc.debugger.sendCommand("Input.dispatchKeyEvent", { type: "keyUp", key, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk, modifiers });
}

async function selectAllAndClear(wc) {
  await ensureDebugger(wc);
  await wc.debugger.sendCommand("Input.dispatchKeyEvent", { type: "rawKeyDown", key: "Control", code: "ControlLeft", windowsVirtualKeyCode: 17, nativeVirtualKeyCode: 17, modifiers: 2 });
  await wc.debugger.sendCommand("Input.dispatchKeyEvent", { type: "rawKeyDown", key: "a", code: "KeyA", windowsVirtualKeyCode: 65, nativeVirtualKeyCode: 65, modifiers: 2 });
  await wc.debugger.sendCommand("Input.dispatchKeyEvent", { type: "keyUp", key: "a", code: "KeyA", windowsVirtualKeyCode: 65, nativeVirtualKeyCode: 65, modifiers: 2 });
  await wc.debugger.sendCommand("Input.dispatchKeyEvent", { type: "keyUp", key: "Control", code: "ControlLeft", windowsVirtualKeyCode: 17, nativeVirtualKeyCode: 17, modifiers: 0 });
  await pressKey(wc, "Backspace", "Backspace", 8, 0);
}

function markerSelector(kind, marker) {
  const safe = String(marker || "").replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  return kind === "text"
    ? `[data-af-trusted-text-id="${safe}"]`
    : `[data-af-trusted-autocomplete-id="${safe}"]`;
}

async function getMarkedInputInfo(wc, kind, marker) {
  const selector = JSON.stringify(markerSelector(kind, marker));
  return wc.executeJavaScript(`(() => {
    const el = document.querySelector(${selector});
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return { value: String(el.value || ""), x: r.left + r.width / 2, y: r.top + r.height / 2, width: r.width, height: r.height };
  })()`, true);
}

async function typeTrustedText(wc, text, intervalMs) {
  await ensureDebugger(wc);
  const chars = Array.from(String(text || ""));
  for (const ch of chars) {
    await wc.debugger.sendCommand("Input.insertText", { text: ch });
    if (intervalMs > 0) await sleep(intervalMs);
  }
}

async function trustedTextInput(wc, req) {
  const marker = String(req.marker || "");
  const target = String(req.value == null ? "" : req.value);
  if (!marker) return { success: false, error: "MISSING_MARKER" };
  const info = await getMarkedInputInfo(wc, "text", marker);
  if (!info) return { success: false, error: "MARKED_INPUT_NOT_FOUND" };
  if (info.width <= 0 || info.height <= 0) return { success: false, error: "MARKED_INPUT_NOT_VISIBLE" };
  await mouseClick(wc, info.x, info.y);
  await sleep(30);
  await selectAllAndClear(wc);
  await typeTrustedText(wc, target, 20);
  await sleep(120);
  const after = await getMarkedInputInfo(wc, "text", marker);
  const success = !!after && String(after.value || "") === target;
  return { success, error: success ? undefined : "VALUE_NOT_COMMITTED", finalValueLength: after ? String(after.value || "").length : 0 };
}

async function trustedTextInputBySelector(wc, selector, value) {
  const target = String(value == null ? "" : value);
  if (!selector || !target) return { success: false, skipped: true, error: "MISSING_SELECTOR_OR_VALUE" };
  const marker = `af-main-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
  const selectorJson = JSON.stringify(String(selector));
  const markerJson = JSON.stringify(marker);
  const prepared = await wc.executeJavaScript(`(() => {
    const el = document.querySelector(${selectorJson});
    if (!el) return { ok:false, reason:"NOT_FOUND" };
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    const visible = r.width > 0 && r.height > 0 && st.display !== "none" && st.visibility !== "hidden";
    if (!visible) return { ok:false, reason:"NOT_VISIBLE" };
    if (el.disabled || el.readOnly) return { ok:false, reason:"NOT_EDITABLE" };
    const current = String(el.value || "");
    if (current === ${JSON.stringify(target)}) return { ok:true, alreadyCorrect:true };
    try { el.scrollIntoView({ behavior: "auto", block: "center", inline: "nearest" }); } catch (_) {}
    el.setAttribute("data-af-trusted-text-id", ${markerJson});
    return { ok:true, alreadyCorrect:false };
  })()`, true);
  if (!prepared || !prepared.ok) return { success: false, skipped: true, error: prepared && prepared.reason || "PREPARE_FAILED" };
  if (prepared.alreadyCorrect) return { success: true, alreadyCorrect: true };
  await sleep(120);
  try {
    return await trustedTextInput(wc, { marker, value: target });
  } finally {
    try {
      await wc.executeJavaScript(`(() => { const el=document.querySelector(${selectorJson}); if (el) el.removeAttribute("data-af-trusted-text-id"); })()`, true);
    } catch (_) {}
  }
}

function normalizeTrustedChoiceText(value) {
  return String(value == null ? "" : value)
    .replace(/\s+/g, "")
    .replace(/[：:]/g, "")
    .replace(/其它/g, "其他")
    .replace(/[（(].*?[）)]/g, "")
    .trim()
    .toLowerCase();
}

async function trustedAntSelectByLabel(wc, rootSelector, labelText, value) {
  const target = String(value == null ? "" : value).trim();
  if (!target) return { success: false, skipped: true, error: "MISSING_VALUE" };
  const rootJson = JSON.stringify(String(rootSelector || "body"));
  const labelJson = JSON.stringify(String(labelText || ""));
  const targetJson = JSON.stringify(target);
  const prepared = await wc.executeJavaScript(`(() => {
    const norm = (v) => String(v == null ? "" : v).replace(/\\s+/g, "").replace(/[：:]/g, "").replace(/其它/g, "其他").replace(/[（(].*?[）)]/g, "").trim().toLowerCase();
    const visible = (el) => { if (!el) return false; const r=el.getBoundingClientRect(); const s=getComputedStyle(el); return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"; };
    const root = document.querySelector(${rootJson}) || document;
    const wanted = norm(${labelJson});
    const labels = Array.from(root.querySelectorAll(".ant-form-item-label > label, .ant-form-item-label, label")).filter(visible);
    const label = labels.find((el) => norm(el.textContent) === wanted) || labels.find((el) => norm(el.textContent).includes(wanted) || wanted.includes(norm(el.textContent)));
    if (!label) return { ok:false, reason:"LABEL_NOT_FOUND" };
    const item = label.closest(".ant-form-item") || label.parentElement;
    if (!item) return { ok:false, reason:"FORM_ITEM_NOT_FOUND" };
    const select = Array.from(item.querySelectorAll(".ant-select:not(.ant-select-disabled):not(.ant-cascader)")).find(visible);
    if (!select) return { ok:false, reason:"SELECT_NOT_FOUND" };
    const selected = select.querySelector(".ant-select-selection-item, .ant-select-selection-selected-value");
    const current = String(selected && selected.textContent || "").trim();
    const target = ${targetJson};
    if (norm(current) === norm(target)) return { ok:true, alreadyCorrect:true, current };
    const trigger = select.querySelector(".ant-select-selector") || select;
    try { trigger.scrollIntoView({ behavior: "auto", block: "center", inline: "nearest" }); } catch (_) {}
    const r = trigger.getBoundingClientRect();
    return { ok:true, alreadyCorrect:false, x:r.left+r.width/2, y:r.top+r.height/2, current };
  })()`, true);
  if (!prepared || !prepared.ok) return { success: false, error: prepared && prepared.reason || "PREPARE_FAILED" };
  if (prepared.alreadyCorrect) return { success: true, alreadyCorrect: true, current: prepared.current || "" };
  await sleep(120);
  await mouseClick(wc, Number(prepared.x || 0), Number(prepared.y || 0));
  await sleep(140);
  const deadline = Date.now() + 2500;
  let option = null;
  while (Date.now() < deadline) {
    option = await wc.executeJavaScript(`(() => {
      const norm = (v) => String(v == null ? "" : v).replace(/\\s+/g, "").replace(/[：:]/g, "").replace(/其它/g, "其他").replace(/[（(].*?[）)]/g, "").trim().toLowerCase();
      const visible = (el) => { if (!el) return false; const r=el.getBoundingClientRect(); const s=getComputedStyle(el); return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"; };
      const target = ${targetJson};
      const t = norm(target);
      const nodes = Array.from(document.querySelectorAll(".ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-item-option:not(.ant-select-item-option-disabled), .ant-select-dropdown:not(.ant-select-dropdown-hidden) [role='option']")).filter(visible);
      let best = null;
      let bestScore = -1;
      for (const node of nodes) {
        const raw = String(node.textContent || "").trim();
        const n = norm(raw);
        let score = 0;
        if (n === t) score = 1000;
        else if (n && t && (n.includes(t) || t.includes(n))) score = 800 - Math.abs(n.length - t.length);
        if (score > bestScore) { best = node; bestScore = score; }
      }
      if (!best || bestScore < 700) return null;
      const r=best.getBoundingClientRect();
      return { x:r.left+r.width/2, y:r.top+r.height/2, text:String(best.textContent||"").trim(), score:bestScore };
    })()`, true);
    if (option) break;
    await sleep(80);
  }
  if (!option) {
    try { await pressKey(wc, "Escape", "Escape", 27, 0); } catch (_) {}
    return { success: false, error: "OPTION_NOT_FOUND" };
  }
  await mouseClick(wc, Number(option.x || 0), Number(option.y || 0));
  await sleep(180);
  const verify = await wc.executeJavaScript(`(() => {
    const norm = (v) => String(v == null ? "" : v).replace(/\\s+/g, "").replace(/[：:]/g, "").replace(/其它/g, "其他").replace(/[（(].*?[）)]/g, "").trim().toLowerCase();
    const visible = (el) => { if (!el) return false; const r=el.getBoundingClientRect(); const s=getComputedStyle(el); return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"; };
    const root = document.querySelector(${rootJson}) || document;
    const wanted = norm(${labelJson});
    const labels = Array.from(root.querySelectorAll(".ant-form-item-label > label, .ant-form-item-label, label")).filter(visible);
    const label = labels.find((el) => norm(el.textContent) === wanted) || labels.find((el) => norm(el.textContent).includes(wanted) || wanted.includes(norm(el.textContent)));
    const item = label && (label.closest(".ant-form-item") || label.parentElement);
    const select = item && Array.from(item.querySelectorAll(".ant-select:not(.ant-select-disabled):not(.ant-cascader)")).find(visible);
    const selected = select && select.querySelector(".ant-select-selection-item, .ant-select-selection-selected-value");
    const current = String(selected && selected.textContent || "").trim();
    const target = ${targetJson};
    return { current, success: !!current && (norm(current) === norm(target) || norm(current).includes(norm(target)) || norm(target).includes(norm(current))) };
  })()`, true);
  return { success: !!(verify && verify.success), current: verify && verify.current || "", optionText: option.text || "", error: verify && verify.success ? "" : "VALUE_NOT_COMMITTED" };
}

function inferBankcommStudentTypeFromResume(resumeData) {
  const basic = resumeData && resumeData.basicInfo || {};
  const explicit = String(basic.studentType || basic.sourceType || "").trim();
  if (/应届|在校/.test(explicit)) return "应届生";
  if (/社会|在职|离职|待业/.test(explicit)) return "社会经验人士";
  const currentStatus = String(basic.currentStatus || basic.currentIdentity || "").trim();
  if (/应届|在校/.test(currentStatus) || basic.isFreshGraduate === "是") return "应届生";
  if (/社会|在职|离职|待业/.test(currentStatus) || basic.isFreshGraduate === "否") return "社会经验人士";
  // 当前用户已明确确认：交通银行该字段应填“应届生”。
  // 这里只作为 Bankcomm 本地 workflow 的缺省值，不反向改写 canonical profile。
  return "应届生";
}

async function prepareBankcommBasicForTrustedInput(wc, resumeData) {
  const basic = resumeData && resumeData.basicInfo || {};
  const intention = resumeData && resumeData.jobIntention || {};
  const name = String(basic.name || "").trim();
  if (!name) return { attempted: false, success: false, reason: "profile_name_missing" };
  // The Bankcomm page is React/Ant controlled. Open the basic editor first if
  // necessary, then use the Chromium input/mouse pipeline for the controls that
  // have stable semantic targets. The normal workflow still owns the rest.
  const state = await wc.executeJavaScript(`(() => {
    const visible = (el) => { if (!el) return false; const r=el.getBoundingClientRect(); const s=getComputedStyle(el); return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"; };
    const input = document.querySelector("#name");
    if (input && visible(input) && !input.disabled && !input.readOnly) return { ready:true };
    const root = document.querySelector("#basic") || document;
    const edit = Array.from(root.querySelectorAll(".anticon-form[title='编辑'], span[title='编辑'], [title='编辑']")).find(visible);
    if (edit) { try { edit.click(); return { ready:false, clicked:true }; } catch (_) {} }
    return { ready:false, clicked:false };
  })()`, true);
  if (state && state.clicked) {
    const deadline = Date.now() + 3500;
    while (Date.now() < deadline) {
      const ready = await wc.executeJavaScript(`(() => { const el=document.querySelector("#name"); if(!el)return false; const r=el.getBoundingClientRect(); const s=getComputedStyle(el); return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"&&!el.disabled&&!el.readOnly; })()`, true);
      if (ready) break;
      await sleep(100);
    }
  }
  const fields = {};
  fields.name = await trustedTextInputBySelector(wc, "#name", name);
  if (basic.emergencyPhone) fields.emergencyPhone = await trustedTextInputBySelector(wc, "#phone", String(basic.emergencyPhone));
  const studentType = inferBankcommStudentTypeFromResume(resumeData);
  const rawCurrentSalary = intention.currentSalary != null && String(intention.currentSalary).trim() !== ""
    ? intention.currentSalary
    : (basic.currentSalary != null && String(basic.currentSalary).trim() !== "" ? basic.currentSalary : "");
  const currentSalary = String(rawCurrentSalary !== "" ? rawCurrentSalary : (studentType === "应届生" ? "0" : "")).trim();
  if (currentSalary) fields.currentSalary = await trustedTextInputBySelector(wc, "#currentSalary", currentSalary);
  const choiceSpecs = [
    ["民族", basic.ethnicity],
    ["婚姻状况", basic.maritalStatus],
    ["政治面貌", basic.politicalStatus],
    ["生源类型", studentType]
  ];
  for (const [label, value] of choiceSpecs) {
    if (!String(value || "").trim()) continue;
    try { fields[label] = await trustedAntSelectByLabel(wc, "#basic", label, value); }
    catch (error) { fields[label] = { success: false, error: String(error && error.message || error).slice(0, 240) }; }
  }
  const attempted = Object.values(fields).filter(Boolean);
  const successful = attempted.filter((entry) => entry && entry.success).length;
  return {
    attempted: true,
    success: !!(fields.name && fields.name.success),
    alreadyCorrect: !!(fields.name && fields.name.alreadyCorrect),
    attemptedFieldCount: attempted.length,
    successfulFieldCount: successful,
    fields,
    reason: fields.name && fields.name.success ? "" : String(fields.name && fields.name.error || "NAME_NOT_COMMITTED")
  };
}

async function findAutocompleteOption(wc, req) {
  const target = String(req.value || "");
  const panelSelector = String(req.panelSelector || "");
  const optionSelector = String(req.optionSelector || "[role='option'], li");
  const fallback = !!req.fallbackToFirstOption;
  const script = `(() => {
    const target = ${JSON.stringify(target)};
    const panelSelector = ${JSON.stringify(panelSelector)};
    const optionSelector = ${JSON.stringify(optionSelector)};
    const fallback = ${JSON.stringify(fallback)};
    const norm = (s) => String(s || "").replace(/\\s+/g, "").replace(/[（(].*?[）)]/g, "").trim().toLowerCase();
    const t = norm(target);
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const st = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && st.display !== "none" && st.visibility !== "hidden";
    };
    let roots = [document];
    if (panelSelector) {
      const panels = Array.from(document.querySelectorAll(panelSelector)).filter(visible);
      if (panels.length) roots = panels;
    }
    const seen = new Set();
    const options = [];
    for (const root of roots) {
      for (const el of Array.from(root.querySelectorAll(optionSelector))) {
        if (seen.has(el) || !visible(el)) continue;
        seen.add(el);
        const text = String(el.textContent || el.innerText || "").trim();
        if (!text) continue;
        const n = norm(text);
        let score = 0;
        if (n === t) score = 1000;
        else if (n.startsWith(t) || t.startsWith(n)) score = 900 - Math.abs(n.length - t.length);
        else if (n.includes(t) || t.includes(n)) score = 800 - Math.abs(n.length - t.length);
        if (/分校|分院|校区/.test(text) && !/分校|分院|校区/.test(target)) score -= 120;
        const r = el.getBoundingClientRect();
        options.push({ el, text, score, x: r.left + r.width / 2, y: r.top + r.height / 2 });
      }
    }
    options.sort((a,b) => b.score - a.score);
    let best = options.find((x) => x.score >= 800) || null;
    if (!best && fallback) best = options[0] || null;
    if (!best) return { found: false, count: options.length, candidates: options.slice(0,5).map(x => x.text) };
    return { found: true, count: options.length, text: best.text, score: best.score, x: best.x, y: best.y };
  })()`;
  return wc.executeJavaScript(script, true);
}

async function trustedElementAutocomplete(wc, req) {
  const marker = String(req.marker || "");
  const target = String(req.value == null ? "" : req.value);
  if (!marker || !target) return { success: false, error: "MISSING_MARKER_OR_VALUE" };
  let info = await getMarkedInputInfo(wc, "autocomplete", marker);
  if (!info) return { success: false, error: "MARKED_INPUT_NOT_FOUND" };
  if (info.width <= 0 || info.height <= 0) return { success: false, error: "MARKED_INPUT_NOT_VISIBLE" };

  await mouseClick(wc, info.x, info.y);
  await sleep(40);
  const same = String(info.value || "").replace(/\s+/g, "") === target.replace(/\s+/g, "");
  if (!(req.preserveExistingInput && same)) {
    await selectAllAndClear(wc);
    await sleep(Number(req.waitAfterClearMs || 30));
    await typeTrustedText(wc, target, Number(req.typeIntervalMs == null ? 45 : req.typeIntervalMs));
  }
  await sleep(Math.max(340, Number(req.waitAfterInputMs || 0)));

  const timeout = Math.max(1000, Number(req.optionTimeoutMs || 4500));
  const started = Date.now();
  let option = null;
  while (Date.now() - started < timeout) {
    option = await findAutocompleteOption(wc, req);
    if (option && option.found) break;
    await sleep(100);
  }
  if (!option || !option.found) {
    return { success: false, error: "OPTION_NOT_FOUND", detail: option || null };
  }

  await sleep(Number(req.waitBeforeOptionClickMs || 50));
  await mouseClick(wc, option.x, option.y);
  await sleep(Number(req.waitAfterSelectMs || 420));
  if (req.requireBlurAfterSelect) {
    await pressKey(wc, "Tab", "Tab", 9, 0);
    await sleep(Number(req.waitAfterBlurMs || 160));
  }

  info = await getMarkedInputInfo(wc, "autocomplete", marker);
  const finalValue = info ? String(info.value || "") : "";
  const n = (s) => String(s || "").replace(/\s+/g, "").toLowerCase();
  const success = !!finalValue && (n(finalValue) === n(target) || n(finalValue).includes(n(target)));
  return {
    success,
    error: success ? undefined : "SELECTION_NOT_RETAINED",
    selectedText: option.text,
    finalValueLength: finalValue.length
  };
}

ipcMain.handle("lite:trusted-input", async (event, req) => {
  const wc = event.sender;
  try {
    if (!req || typeof req !== "object") return { success: false, error: "INVALID_REQUEST" };
    if (req.action === "trustedTextInput") return await trustedTextInput(wc, req);
    if (req.action === "trustedElementAutocomplete") return await trustedElementAutocomplete(wc, req);
    return { success: false, error: "UNSUPPORTED_TRUSTED_ACTION" };
  } catch (error) {
    return { success: false, error: String(error && error.message || error) };
  }
});

async function prepareLocalFirstAiAssist(wc, rawUrl, context) {
  // Build138: one-click remains local-first. On pages with no mature local owner,
  // a cached AI candidate may re-enter Autofill Core only through the Safety Gate
  // and only as high-confidence scalar unique-selector mappings. RepeatRecord,
  // complex controls and all page actions remain outside AI execution permission.
  // A user-verified semantic SiteConfig is treated as local configuration and
  // may still be loaded because it has already crossed the explicit review gate.
  await clearRuntimeSemanticOverlay(wc);
  const gate = classifyLocalFirstRoute(context || {});
  const base = {
    route: gate.route,
    strongLocalSupport: gate.strongLocalSupport,
    platformCapabilityAvailable: !!gate.platformCapabilityAvailable,
    localReasons: gate.reasons,
    aiInvoked: false,
    cachedPatchUsed: false,
    cachedCandidateAvailable: false,
    runtimeMappingsApplied: 0,
    candidateSkippedMappings: 0,
    analysisGenerated: false,
    candidateOnly: true,
    message: ""
  };

  if (gate.strongLocalSupport) {
    try {
      const cached = loadValidatedAiCandidate(rawUrl);
      if (cached) {
        base.cachedCandidateAvailable = true;
        base.cachedPatchUsed = true;
        base.candidateSkippedMappings = Number(cached.overlay && cached.overlay.summary && cached.overlay.summary.skippedDecisions || 0);
      }
    } catch (error) {
      base.cachedPatchError = String(error && error.message || error).slice(0, 500);
    }
    base.route = base.cachedCandidateAvailable ? "local_first_candidate_available" : "local_first";
    base.message = base.cachedCandidateAvailable
      ? "已命中本地适配；发现已有 AI 语义候选，当前版本仅记录候选，不参与本轮填写；同时执行 Safety Gate 分类。"
      : "已命中本地适配/平台能力，按 local-first 直接使用 Autofill Core；AI 仅在本地执行后分析剩余语义 Gap。";
    return base;
  }

  try {
    const verified = loadVerifiedSemanticSiteCandidate(rawUrl);
    if (verified) {
      const siteInstalled = await installPrefetchedSemanticCandidate(wc, rawUrl, verified.siteCandidate);
      base.siteCandidateInstalled = !!(siteInstalled && siteInstalled.installed);
      base.siteCandidateInstall = siteInstalled || {};
      base.verifiedSiteCandidateUsed = base.siteCandidateInstalled;
      base.verifiedSiteCandidateFile = verified.file ? path.basename(verified.file) : "";
      if (base.siteCandidateInstalled) {
        base.route = "verified_semantic_site_candidate";
        base.message = `已加载人工验证过的本地 semantic SiteConfig（字段 ${Number(siteInstalled.fieldMappingCount || 0)}、分区 ${Number(siteInstalled.sectionMappingCount || 0)}）；后续新候选仍需通过风险分级 Safety Gate 才能回到 Core。`;
        return base;
      }
    }
  } catch (error) {
    base.verifiedCandidateError = String(error && error.message || error).slice(0, 500);
  }

  try {
    const cached = loadValidatedAiCandidate(rawUrl);
    if (cached) {
      base.cachedCandidateAvailable = true;
      base.cachedPatchUsed = true;
      base.candidateSkippedMappings = Number(cached.overlay && cached.overlay.summary && cached.overlay.summary.skippedDecisions || 0);

      const gateResult = compileAiCandidateSafetyGate(cached.review || {}, cached.patch || {}, {
        matchedWorkflowId: String(context && context.matchedWorkflowId || ""),
        localSupport: false
      });
      base.safetyGateSummary = gateResult && gateResult.summary || {};
      // Build141: compute once in the outer cached-candidate scope. Build140 declared
      // another `const eligibleIds` later in this same block; the graph branch closed
      // over that later declaration and hit JavaScript TDZ before initialization.
      const eligibleIds = new Set((gateResult && gateResult.executableCandidates || []).map((item) => String(item && item.fieldId || "")).filter(Boolean));

      const graphStructureAvailable = !!(cached.siteCandidate && cached.siteCandidate.configTemplate && cached.siteCandidate.configTemplate._graphStructure && Array.isArray(cached.siteCandidate.configTemplate._graphStructure.sections) && cached.siteCandidate.configTemplate._graphStructure.sections.length);
      base.graphStructureAvailable = graphStructureAvailable;
      if (graphStructureAvailable) {
        // Structure selectors come from local FormGraph analysis, never from the model.
        // The semantic layer is still filtered through the Build137 Safety Gate so a
        // graph-backed SiteConfig cannot become a side door around RepeatRecord rules.
        let guardedStructureCandidate = cached.siteCandidate;
        try {
          guardedStructureCandidate = JSON.parse(JSON.stringify(cached.siteCandidate));
          // Build140: graph-backed SiteConfig may consume AI *semantics* more broadly
          // than direct runtime execution. RepeatRecord fields remain review-only for
          // direct selector execution, but their category/fieldKey mapping is safe to
          // expose to DataMatcher because RecordGraph/ExperienceHandler still owns the
          // record identity. Existing adapters likewise remain the only control writer.
          const semanticOnlyReasons = new Set([
            "repeat_record_requires_recordgraph_ownership",
            "control_requires_existing_adapter_or_manual_review",
            "confidence_below_auto_eligible_threshold"
          ]);
          const semanticOnlyIds = new Set();
          (gateResult && gateResult.reviewOnlyCandidates || []).forEach((item) => {
            const reasons = Array.isArray(item && item.reasons) ? item.reasons : [];
            if (!reasons.length || !reasons.every((reason) => semanticOnlyReasons.has(String(reason || "")))) return;
            if (Number(item && item.confidence || 0) < 0.65) return;
            const id = String(item && item.fieldId || "");
            if (id) semanticOnlyIds.add(id);
          });
          const semanticAllowedIds = new Set([...eligibleIds, ...semanticOnlyIds]);
          const semanticAllowedCategories = new Set();
          (gateResult && gateResult.executableCandidates || []).concat(gateResult && gateResult.reviewOnlyCandidates || []).forEach((item) => {
            const id = String(item && item.fieldId || "");
            if (semanticAllowedIds.has(id) && item && item.category) semanticAllowedCategories.add(String(item.category));
          });
          const semantic = guardedStructureCandidate.configTemplate && guardedStructureCandidate.configTemplate._aiSemanticPatch || {};
          semantic.fieldMappings = (Array.isArray(semantic.fieldMappings) ? semantic.fieldMappings : []).filter((item) => {
            return String(item && item.source || "") === "local_core_trusted" || semanticAllowedIds.has(String(item && item.fieldId || ""));
          });
          // Section semantics never choose a RepeatRecord owner. They only tell the
          // local Core which canonical category a locally observed section represents.
          semantic.sectionMappings = (Array.isArray(semantic.sectionMappings) ? semantic.sectionMappings : []).filter((item) => {
            return item && item.category && semanticAllowedCategories.has(String(item.category));
          });
          guardedStructureCandidate.configTemplate._aiSemanticPatch = semantic;
          // Graph rows carry the actual visible labels Core will read. AI review may
          // have used an id/name/placeholder (e.g. `name`, `birthday`,
          // `relativesPhoneNumber`). Reconcile by stable fieldId so DataMatcher sees
          // the same label that ElementMatcher emits, without giving AI selector or
          // Record ownership authority.
          guardedStructureCandidate = reconcileSemanticMappingsWithGraphStructure(guardedStructureCandidate);
        } catch (semanticBridgeError) {
          base.graphSemanticBridgeError = String(semanticBridgeError && semanticBridgeError.message || semanticBridgeError).slice(0, 500);
        }
        const structureInstall = await installPrefetchedSemanticCandidate(wc, rawUrl, guardedStructureCandidate);
        base.structureCandidateInstall = structureInstall || {};
        base.siteCandidateInstalled = !!(structureInstall && structureInstall.installed);
        base.graphStructureSections = Number(structureInstall && structureInstall.graphSectionCount || 0);
        if (base.siteCandidateInstalled) {
          // Structure and scalar execution are complementary. Build139 returned here,
          // which meant the graph config was installed but the four scalar candidates
          // already cleared by the Safety Gate never reached RuntimeSemanticPatch.
          const safeSelectorMappings = (cached.overlay && Array.isArray(cached.overlay.selectorMappings) ? cached.overlay.selectorMappings : []).filter((item) => {
            return eligibleIds.has(String(item && item.fieldId || ""));
          });
          // Build142: RepeatRecord selectors stay metadata-only. They originate from
          // local analysis (id/name/placeholder selector candidates), while AI only
          // supplies category/fieldKey semantics. Content-side RecordGraph must prove
          // the active editor owner before any of these selectors can be written.
          const repeatSelectorMetadata = compileRepeatRecordSelectorMetadata(cached.review || {}, gateResult || {}, { minConfidence: 0.65 });
          const recordSelectorMappings = repeatSelectorMetadata && Array.isArray(repeatSelectorMetadata.recordSelectorMappings)
            ? repeatSelectorMetadata.recordSelectorMappings : [];
          const safeValueCandidates = cached.overlay && Array.isArray(cached.overlay.valueCandidates) ? cached.overlay.valueCandidates : [];
          base.controlledApplyEligible = safeSelectorMappings.length;
          base.repeatRecordSemanticMappings = recordSelectorMappings.length;
          base.valueCandidateEligible = safeValueCandidates.length;
          if (safeSelectorMappings.length || recordSelectorMappings.length || safeValueCandidates.length) {
            const overlayInstall = await installRuntimeSemanticOverlay(wc, rawUrl, {
              fieldMappings: [],
              selectorMappings: safeSelectorMappings,
              recordSelectorMappings,
              valueCandidates: safeValueCandidates
            });
            base.controlledApplyAttempted = safeSelectorMappings.length > 0 || safeValueCandidates.length > 0;
            base.runtimeMappingsApplied = Number(overlayInstall && overlayInstall.selectorMappingCount || 0);
            base.valueCandidatesInstalled = Number(overlayInstall && overlayInstall.valueCandidateCount || 0);
            base.repeatRecordMappingsInstalled = Number(overlayInstall && overlayInstall.recordSelectorMappingCount || 0);
            base.controlledApplyInstall = overlayInstall || {};
          }
          base.candidateOnly = false;
          base.route = "ai_graph_structure_core_apply";
          base.message = `未命中成熟本地适配；已安装基于本地 FormGraph 结构证据的 SiteConfig candidate（${base.graphStructureSections} 个分区），${base.runtimeMappingsApplied} 个普通字段 selector 与 ${Number(base.valueCandidatesInstalled || 0)} 个安全候选值可受控回到 Autofill Core；另安装 ${Number(base.repeatRecordMappingsInstalled || 0)} 个 RepeatRecord 本地 selector 语义元数据，只有 RecordGraph 证明当前 editor owner 后才允许填写。`;
          return base;
        }
      }
      const safeSelectorMappings = (cached.overlay && Array.isArray(cached.overlay.selectorMappings) ? cached.overlay.selectorMappings : []).filter((item) => {
        return eligibleIds.has(String(item && item.fieldId || ""));
      });
      const safeValueCandidates = cached.overlay && Array.isArray(cached.overlay.valueCandidates) ? cached.overlay.valueCandidates : [];
      base.controlledApplyEligible = safeSelectorMappings.length;
      base.valueCandidateEligible = safeValueCandidates.length;
      if (safeSelectorMappings.length || safeValueCandidates.length) {
        const install = await installRuntimeSemanticOverlay(wc, rawUrl, { fieldMappings: [], selectorMappings: safeSelectorMappings, valueCandidates: safeValueCandidates });
        base.controlledApplyAttempted = true;
        base.runtimeMappingsApplied = Number(install && install.selectorMappingCount || 0);
        base.valueCandidatesInstalled = Number(install && install.valueCandidateCount || 0);
        base.controlledApplyInstall = install || {};
        if (base.runtimeMappingsApplied > 0 || base.valueCandidatesInstalled > 0) {
          base.candidateOnly = false;
          base.route = "ai_high_confidence_core_apply";
          base.message = `未命中成熟本地适配；${base.runtimeMappingsApplied} 个普通字段 selector 与 ${Number(base.valueCandidatesInstalled || 0)} 个安全候选值已通过风险分级 Safety Gate，并重新进入 Autofill Core。RepeatRecord/复杂控件仍不会由 AI 执行。`;
          return base;
        }
      }
    }
  } catch (error) {
    base.cachedPatchError = String(error && error.message || error).slice(0, 500);
  }

  if (base.cachedPatchError) {
    base.route = "ai_candidate_bridge_error";
    base.message = `AI candidate 已加载，但受控回送 Core 的执行桥发生错误：${String(base.cachedPatchError || "unknown").slice(0, 220)}。本轮不会把该错误伪装成“没有安全候选”。`;
    return base;
  }
  base.route = base.cachedCandidateAvailable ? "generic_local_candidate_available" : "generic_local_candidate_only";
  base.message = base.cachedCandidateAvailable
    ? "未命中成熟本地适配；已有 AI candidate 已完成 Safety Gate，但没有可安全直接回送 Core 的普通 selector 字段，本轮仍由通用 Core 独立执行。"
    : "未命中成熟本地适配；先运行通用 Core，执行后若确认是语义/结构 Gap，再生成 AI candidate；只有后续通过 Safety Gate 的普通 selector 字段才可回送 Core。";
  return base;
}

function buildAiSafetyGateContext(sanitized) {
  const x = sanitized && typeof sanitized === "object" ? sanitized : {};
  return {
    matchedWorkflowId: String(x.matchedWorkflowId || ""),
    localSupport: !!(x.aiAssist && x.aiAssist.strongLocalSupport)
  };
}

async function detectMatchedWorkflowIdForAiGate(wc, rawUrl) {
  try {
    return await runIsolated(wc, `(() => {
      try {
        const api = window.AF && AF.PrivateSpecialSites;
        const workflow = api && typeof api.getWorkflowForUrl === "function" ? api.getWorkflowForUrl(${JSON.stringify(String(rawUrl || ""))}) : null;
        return workflow && workflow.id ? String(workflow.id) : "";
      } catch (_) { return ""; }
    })()`);
  } catch (_) {
    return "";
  }
}

function compileLoadedCandidateSafetyGate(loaded, sanitized) {
  if (!loaded || !loaded.review || !loaded.patch) return null;
  try {
    return compileAiCandidateSafetyGate(loaded.review, loaded.patch, buildAiSafetyGateContext(sanitized));
  } catch (error) {
    return {
      schemaType: "autofill-lite-ai-candidate-safety-gate",
      schemaVersion: 1,
      mode: "decision_only",
      status: "gate_error",
      error: String(error && error.message || error).slice(0, 500),
      summary: { totalDecisions: 0, eligibleForCore: 0, reviewOnly: 0, rejected: 0 },
      policy: { autoApply: false, autoExecute: false, build137ExecutionPermission: "disabled" }
    };
  }
}

async function preparePostFillAiGapCandidate(wc, rawUrl, sanitized) {
  const foundation = buildAiGapFoundation(sanitized || {});
  if (!foundation.eligible) return foundation;

  let cached = null;
  try { cached = loadValidatedAiCandidate(rawUrl); } catch (error) {
    foundation.cachedCandidateError = String(error && error.message || error).slice(0, 500);
  }
  if (cached) {
    foundation.candidateAvailable = true;
    foundation.candidateFileName = cached.file ? path.basename(cached.file) : "";
    foundation.candidateSummary = cached.siteCandidate && cached.siteCandidate.summary || cached.overlay && cached.overlay.summary || {};
    foundation.candidates = summarizeCandidateMappings(cached.siteCandidate, foundation, 20);
    foundation.safetyGate = compileLoadedCandidateSafetyGate(cached, sanitized);
    foundation.status = "candidate_available_for_controlled_reuse";
    foundation.message = "已发现 AI 语义/值候选并完成风险分级 Safety Gate；低风险安全候选可在后续一键填写中重新进入 Autofill Core，其他候选继续人工兜底。";
    return foundation;
  }

  const hasApiKey = !!aiSettingsStore.getApiKey();

  try {
    const analysis = await analyzeSiteInternal(wc, rawUrl);
    foundation.analysisGenerated = true;
    foundation.analysisFileName = String(analysis && analysis.analysisFileName || "");
    foundation.reviewFileName = String(analysis && analysis.aiReviewFileName || "");
    foundation.aiInvoked = hasApiKey;
    foundation.localFallbackUsed = !hasApiKey;
    const aiResult = await runAiMappingInternal(wc, rawUrl);
    foundation.candidateGenerated = true;
    foundation.candidateAvailable = true;
    foundation.candidateFileName = String(aiResult && (aiResult.siteCandidateFileName || aiResult.candidateFileName) || "");
    foundation.candidateSummary = aiResult && (aiResult.siteCandidateSummary || aiResult.candidateSummary || aiResult.summary) || {};
    const compiled = loadValidatedAiCandidate(rawUrl);
    foundation.candidates = compiled ? summarizeCandidateMappings(compiled.siteCandidate, foundation, 20) : [];
    foundation.safetyGate = compiled ? compileLoadedCandidateSafetyGate(compiled, sanitized) : null;
    foundation.status = aiResult && aiResult.provider === "local-fallback"
      ? "local_candidate_generated_no_api"
      : "candidate_generated_for_controlled_reuse";
    foundation.message = aiResult && aiResult.provider === "local-fallback"
      ? "已使用无 API 本地降级生成语义/值候选；本地 Core 结果保持不变，候选可在后续运行受控使用。"
      : "AI 已生成语义/值候选并完成风险分级 Safety Gate；候选将在后续运行通过 Autofill Core/Checkpoint 受控使用。";
  } catch (error) {
    foundation.status = "candidate_generation_failed";
    foundation.error = String(error && error.message || error).slice(0, 700);
    foundation.message = "AI 候选生成失败；已保留本地填写结果，不影响本次 Core 执行。";
  }
  return foundation;
}

ipcMain.handle("lite:test-next-section", async (_event, guestId) => {
  const wc = getGuest(guestId);
  const rawUrl = wc.getURL();
  if (!/^https?:\/\//i.test(rawUrl)) throw new Error("当前页面不是 http/https 网页");
  await injectAutofillCore(wc);
  const plan = loadLatestAnalyzedNavigationPlan(rawUrl);
  const payload = JSON.stringify({
    from: plan.from,
    target: plan.target,
    requireFromActive: true,
    requireSaveFeedback: true,
    saveFeedbackTimeoutMs: 5000,
    saveModalCloseTimeoutMs: 2500,
    navigationTimeoutMs: 3500
  });
  const result = await runIsolated(wc, `(() => {
    const api = window.AF && AF.SpecialSiteWorkflow && AF.SpecialSiteWorkflow._test;
    if (!api || typeof api.runAnalyzedSectionNavigationTransaction !== "function") {
      throw new Error("SectionNavigationTransaction runtime unavailable");
    }
    return api.runAnalyzedSectionNavigationTransaction(${payload});
  })()`);
  const diagnostic = {
    at: new Date().toISOString(),
    buildId: BUILD_ID,
    kind: "section_navigation_transaction_probe",
    url: safeUrl(rawUrl),
    sourceAnalysisSnapshotAt: plan.snapshotAt,
    fromSection: plan.from.text,
    targetSection: plan.target.text,
    result: result && typeof result === "object" ? result : {}
  };
  const file = appendDiagnostic(diagnostic);
  return Object.assign({}, diagnostic, { logFileName: path.basename(file) });
});


ipcMain.handle("lite:probe-education-editor", async (_event, guestId) => {
  const wc = getGuest(guestId);
  const rawUrl = wc.getURL();
  if (!/^https?:\/\//i.test(rawUrl)) throw new Error("当前页面不是 http/https 网页");
  await injectAutofillCore(wc);
  const plan = loadLatestAnalyzedSectionProbePlan(rawUrl, "教育背景");
  const payload = JSON.stringify({
    section: plan.section,
    requireSectionActive: true,
    editorOpenTimeoutMs: 4500,
    editorCloseTimeoutMs: 2500
  });
  const result = await runIsolated(wc, `(() => {
    const api = window.AF && AF.SpecialSiteWorkflow && AF.SpecialSiteWorkflow._test;
    if (!api || typeof api.runAnalyzedEducationAddEditorProbe !== "function") {
      throw new Error("EducationAddEditorProbe runtime unavailable");
    }
    return api.runAnalyzedEducationAddEditorProbe(${payload});
  })()`);
  const diagnostic = {
    at: new Date().toISOString(),
    buildId: BUILD_ID,
    kind: "education_add_editor_probe",
    url: safeUrl(rawUrl),
    sourceAnalysisSnapshotAt: plan.snapshotAt,
    section: plan.section.text,
    result: result && typeof result === "object" ? result : {}
  };
  const file = appendDiagnostic(diagnostic);
  return Object.assign({}, diagnostic, { logFileName: path.basename(file) });
});


ipcMain.handle("lite:preview-fill-education-record", async (_event, guestId) => {
  const wc = getGuest(guestId);
  const rawUrl = wc.getURL();
  if (!/^https?:\/\//i.test(rawUrl)) throw new Error("当前页面不是 http/https 网页");
  await injectAutofillCore(wc);
  const plan = loadLatestAnalyzedSectionProbePlan(rawUrl, "教育背景");
  const resumeData = loadProfile(PROFILE_FILE);
  const educationRows = Array.isArray(resumeData && resumeData.education) ? resumeData.education : [];
  if (!educationRows.length) throw new Error("资料库没有可用于预览的高等教育记录");
  const payload = JSON.stringify({
    section: plan.section,
    requireSectionActive: true,
    record: educationRows[0],
    profileRecordIndex: 0,
    profileRecordCount: educationRows.length,
    editorOpenTimeoutMs: 4500,
    dynamicOptionTimeoutMs: 2200
  });
  const result = await runIsolated(wc, `(() => {
    const api = window.AF && AF.SpecialSiteWorkflow && AF.SpecialSiteWorkflow._test;
    if (!api || typeof api.runAnalyzedEducationRecordPreviewFill !== "function") {
      throw new Error("EducationRecordPreviewFill runtime unavailable");
    }
    return api.runAnalyzedEducationRecordPreviewFill(${payload});
  })()`);
  const diagnostic = {
    at: new Date().toISOString(),
    buildId: BUILD_ID,
    kind: "education_record_preview_fill",
    url: safeUrl(rawUrl),
    sourceAnalysisSnapshotAt: plan.snapshotAt,
    section: plan.section.text,
    profileRecordIndex: 0,
    profileRecordCount: educationRows.length,
    result: result && typeof result === "object" ? result : {}
  };
  const file = appendDiagnostic(diagnostic);
  return Object.assign({}, diagnostic, { logFileName: path.basename(file) });
});

ipcMain.handle("lite:continue-preview-education-records", async (_event, guestId) => {
  const wc = getGuest(guestId);
  const rawUrl = wc.getURL();
  if (!/^https?:\/\//i.test(rawUrl)) throw new Error("当前页面不是 http/https 网页");
  await injectAutofillCore(wc);
  const plan = loadLatestAnalyzedSectionProbePlan(rawUrl, "教育背景");
  const resumeData = loadProfile(PROFILE_FILE);
  const educationRows = Array.isArray(resumeData && resumeData.education) ? resumeData.education : [];
  if (!educationRows.length) throw new Error("资料库没有高等教育记录");
  const payload = JSON.stringify({
    section: plan.section,
    requireSectionActive: true,
    records: educationRows,
    editorOpenTimeoutMs: 4500,
    dynamicOptionTimeoutMs: 2200
  });
  const result = await runIsolated(wc, `(() => {
    const api = window.AF && AF.SpecialSiteWorkflow && AF.SpecialSiteWorkflow._test;
    if (!api || typeof api.runAnalyzedEducationContinuePreview !== "function") {
      throw new Error("EducationContinuePreview runtime unavailable");
    }
    return api.runAnalyzedEducationContinuePreview(${payload});
  })()`);
  const diagnostic = {
    at: new Date().toISOString(),
    buildId: BUILD_ID,
    kind: "education_repeat_identity_continue_preview",
    url: safeUrl(rawUrl),
    sourceAnalysisSnapshotAt: plan.snapshotAt,
    section: plan.section.text,
    profileRecordCount: educationRows.length,
    result: result && typeof result === "object" ? result : {}
  };
  const file = appendDiagnostic(diagnostic);
  return Object.assign({}, diagnostic, { logFileName: path.basename(file) });
});



ipcMain.handle("lite:continue-education-records", async (_event, guestId) => {
  const wc = getGuest(guestId);
  const rawUrl = wc.getURL();
  if (!/^https?:\/\//i.test(rawUrl)) throw new Error("当前页面不是 http/https 网页");
  await injectAutofillCore(wc);
  const plan = loadLatestAnalyzedSectionProbePlan(rawUrl, "教育背景");
  const resumeData = loadProfile(PROFILE_FILE);
  const educationRows = Array.isArray(resumeData && resumeData.education) ? resumeData.education : [];
  if (!educationRows.length) throw new Error("资料库没有高等教育记录");
  const payload = JSON.stringify({
    section: plan.section,
    requireSectionActive: true,
    records: educationRows,
    editorOpenTimeoutMs: 4500,
    dynamicOptionTimeoutMs: 2200,
    saveFeedbackTimeoutMs: 5000,
    saveModalCloseTimeoutMs: 1800,
    postSaveVerifyTimeoutMs: 4000
  });
  const result = await runIsolated(wc, `(() => {
    const api = window.AF && AF.SpecialSiteWorkflow && AF.SpecialSiteWorkflow._test;
    if (!api || typeof api.runAnalyzedEducationRepeatSaveTransaction !== "function") {
      throw new Error("EducationRepeatSaveTransaction runtime unavailable");
    }
    return api.runAnalyzedEducationRepeatSaveTransaction(${payload});
  })()`);
  const diagnostic = {
    at: new Date().toISOString(),
    buildId: BUILD_ID,
    kind: "education_repeat_save_transaction",
    url: safeUrl(rawUrl),
    sourceAnalysisSnapshotAt: plan.snapshotAt,
    section: plan.section.text,
    profileRecordCount: educationRows.length,
    result: result && typeof result === "object" ? result : {}
  };
  const file = appendDiagnostic(diagnostic);
  return Object.assign({}, diagnostic, { logFileName: path.basename(file) });
});


ipcMain.handle("lite:survey-resume-section-editors", async (_event, guestId) => {
  const wc = getGuest(guestId);
  const rawUrl = wc.getURL();
  if (!/^https?:\/\//i.test(rawUrl)) throw new Error("当前页面不是 http/https 网页");
  await injectAutofillCore(wc);
  const targets = ["外语水平", "通讯信息", "实习/工作/入伍经历", "获奖信息", "家庭成员", "其他资格"];
  const plan = loadLatestAnalyzedMultiSectionSurveyPlan(rawUrl, targets);
  const payload = JSON.stringify({
    sections: plan.sections,
    navigationTimeoutMs: 3000,
    editorOpenTimeoutMs: 4500,
    editorCloseTimeoutMs: 2500
  });
  const result = await runIsolated(wc, `(() => {
    const api = window.AF && AF.SpecialSiteWorkflow && AF.SpecialSiteWorkflow._test;
    if (!api || typeof api.runAnalyzedResumeSectionEditorSurvey !== "function") {
      throw new Error("ResumeSectionEditorSurvey runtime unavailable");
    }
    return api.runAnalyzedResumeSectionEditorSurvey(${payload});
  })()`);
  const diagnostic = {
    at: new Date().toISOString(),
    buildId: BUILD_ID,
    kind: "resume_section_editor_survey",
    url: safeUrl(rawUrl),
    sourceAnalysisSnapshotAt: plan.snapshotAt,
    targetSections: targets,
    result: result && typeof result === "object" ? result : {}
  };
  const file = appendDiagnostic(diagnostic);
  return Object.assign({}, diagnostic, { logFileName: path.basename(file) });
});

ipcMain.handle("lite:preview-resume-sections", async (_event, guestId) => {
  const wc = getGuest(guestId);
  const rawUrl = wc.getURL();
  if (!/^https?:\/\//i.test(rawUrl)) throw new Error("当前页面不是 http/https 网页");
  await injectAutofillCore(wc);
  const targets = ["外语水平", "通讯信息", "实习/工作/入伍经历", "获奖信息", "家庭成员", "其他资格"];
  const plan = loadLatestAnalyzedMultiSectionSurveyPlan(rawUrl, targets);
  const resumeData = loadProfile(PROFILE_FILE);
  const payload = JSON.stringify({
    sections: plan.sections,
    profile: {
      basicInfo: resumeData.basicInfo || {},
      languageSkills: Array.isArray(resumeData.languageSkills) ? resumeData.languageSkills : [],
      internshipExperience: Array.isArray(resumeData.internshipExperience) ? resumeData.internshipExperience : [],
      awards: Array.isArray(resumeData.awards) ? resumeData.awards : [],
      familyMembers: Array.isArray(resumeData.familyMembers) ? resumeData.familyMembers : []
    },
    navigationTimeoutMs: 3000,
    editorOpenTimeoutMs: 4500,
    editorCloseTimeoutMs: 2500,
    dynamicOptionTimeoutMs: 2200,
    languageRecordSelectionPolicy: "preferred_only",
    preferredLanguageExamAliases: ["IELTS", "雅思"],
    languageRecordLimit: 1
  });
  const result = await runIsolated(wc, `(() => {
    const api = window.AF && AF.SpecialSiteWorkflow && AF.SpecialSiteWorkflow._test;
    if (!api || typeof api.runAnalyzedResumeSectionPreviewBatch !== "function") {
      throw new Error("ResumeSectionPreviewBatch runtime unavailable");
    }
    return api.runAnalyzedResumeSectionPreviewBatch(${payload});
  })()`);
  const diagnostic = {
    at: new Date().toISOString(),
    buildId: BUILD_ID,
    kind: "resume_section_preview_batch",
    url: safeUrl(rawUrl),
    sourceAnalysisSnapshotAt: plan.snapshotAt,
    targetSections: targets,
    result: result && typeof result === "object" ? result : {}
  };
  const file = appendDiagnostic(diagnostic);
  return Object.assign({}, diagnostic, { logFileName: path.basename(file) });
});


ipcMain.handle("lite:save-resume-sections", async (_event, guestId) => {
  const wc = getGuest(guestId);
  const rawUrl = wc.getURL();
  if (!/^https?:\/\//i.test(rawUrl)) throw new Error("当前页面不是 http/https 网页");
  await injectAutofillCore(wc);
  const targets = ["外语水平", "通讯信息", "实习/工作/入伍经历", "获奖信息", "家庭成员", "其他资格"];
  const plan = loadLatestAnalyzedMultiSectionSurveyPlan(rawUrl, targets);
  const resumeData = loadProfile(PROFILE_FILE);
  const payload = JSON.stringify({
    sections: plan.sections,
    profile: {
      basicInfo: resumeData.basicInfo || {},
      languageSkills: Array.isArray(resumeData.languageSkills) ? resumeData.languageSkills : [],
      internshipExperience: Array.isArray(resumeData.internshipExperience) ? resumeData.internshipExperience : [],
      awards: Array.isArray(resumeData.awards) ? resumeData.awards : [],
      familyMembers: Array.isArray(resumeData.familyMembers) ? resumeData.familyMembers : [],
      otherQualifications: Array.isArray(resumeData.otherQualifications) ? resumeData.otherQualifications : []
    },
    navigationTimeoutMs: 3000,
    editorOpenTimeoutMs: 4500,
    dynamicOptionTimeoutMs: 2200,
    languageRecordSelectionPolicy: "preferred_only",
    preferredLanguageExamAliases: ["IELTS", "雅思"],
    languageRecordLimit: 1,
    saveFeedbackTimeoutMs: 5000,
    saveModalCloseTimeoutMs: 2200,
    postSaveVerifyTimeoutMs: 4000
  });
  const result = await runIsolated(wc, `(() => {
    const api = window.AF && AF.SpecialSiteWorkflow && AF.SpecialSiteWorkflow._test;
    if (!api || typeof api.runAnalyzedResumeSectionSaveBatch !== "function") {
      throw new Error("ResumeSectionSaveBatch runtime unavailable");
    }
    return api.runAnalyzedResumeSectionSaveBatch(${payload});
  })()`);
  const diagnostic = {
    at: new Date().toISOString(),
    buildId: BUILD_ID,
    kind: "resume_section_save_batch",
    url: safeUrl(rawUrl),
    sourceAnalysisSnapshotAt: plan.snapshotAt,
    targetSections: targets,
    result: result && typeof result === "object" ? result : {}
  };
  const file = appendDiagnostic(diagnostic);
  return Object.assign({}, diagnostic, { logFileName: path.basename(file) });
});

function cleanWorkflowFailureLabel(value) {
  return String(value || "")
    .replace(/^\[特殊工作流\]\s*/, "")
    .replace(/^\[.*?\]\s*/, "")
    .trim();
}

function resolveAutofillCompletionState(input) {
  const x = input || {};
  const unhandled = Array.isArray(x.unhandledFields) ? x.unhandledFields : [];
  const reconciliationOnly = unhandled.length > 0 && unhandled.every((item) =>
    String(item && item.reason || "") === "core_count_reconciliation"
  );
  const resumedRecoveryComplete = x.resumedFromRecoveryCheckpoint === true && x.recoveryCheckpointResolved === true;
  const noFailureContext = !x.failureContext;
  const failedCount = Number(x.failedCount || 0);
  const manualActionRequired = x.manualActionRequired === true;
  const stopped = x.stopped === true;

  if (
    resumedRecoveryComplete && noFailureContext && !manualActionRequired && !stopped &&
    failedCount === 0 && reconciliationOnly
  ) {
    return { status: "complete", resolved: true, reason: "resolved_recovery_reconciliation_only" };
  }

  return { status: String(x.status || "unknown"), resolved: false, reason: "unchanged" };
}

function buildAutofillUserFacingSummary(options) {
  const x = options || {};
  const failureContext = x.failureContext && typeof x.failureContext === "object" ? x.failureContext : null;
  if (failureContext) {
    const where = String(failureContext.stepName || failureContext.fieldLabel || "当前步骤");
    const summary = String(failureContext.humanSummary || "当前步骤没有成功完成");
    const action = String(failureContext.suggestedAction || "请检查当前打开的表单，处理后再次点击“一键填写”。");
    const checkpointText = x.recoveryCheckpointCreated
      ? "已记录恢复检查点；再次点击“一键填写”将视为你已手动处理完成，并从后续内容继续，不会重做此前已完成步骤。"
      : (String(failureContext.recoverability || "") === "UNSAFE_STOP"
        ? "为避免覆盖已有内容，本次没有建立自动恢复检查点。"
        : "");
    return {
      state: String(failureContext.recoverability || "") === "UNSAFE_STOP" ? "unsafe_stop" : "paused",
      title: `一键填写停在：${where}`,
      reason: summary,
      action,
      checkpoint: checkpointText
    };
  }
  if (x.manualActionRequired) {
    const where = String(x.manualActionStep || "当前步骤");
    return {
      state: "paused",
      title: `一键填写停在：${where}`,
      reason: String(x.manualActionReason || x.message || "当前步骤需要人工处理"),
      action: "请在网页中完成当前步骤并保存，然后再次点击“一键填写”。",
      checkpoint: "当前人工检查点已保留，完成后可从这里继续。"
    };
  }
  const failures = Array.isArray(x.failedFields) ? x.failedFields : [];
  if (Number(x.failedCount || 0) > 0 || failures.length) {
    const first = failures[0] || {};
    const where = cleanWorkflowFailureLabel(first.label || first.fieldKey || "当前步骤");
    const rawReason = String(first.reason || "");
    let reason = "当前步骤没有成功完成自动填写。";
    if (/日期.*失败/.test(rawReason)) reason = "日期字段没有成功填写。";
    else if (/未找到字段标签|候选未展开|下拉.*失败/.test(rawReason)) reason = "页面字段或下拉选项没有被安全识别。";
    else if (/依赖字段填写未完成|必填字段/.test(rawReason)) reason = "当前区域仍有必填项未完成。";
    else if (/上传|附件/.test(rawReason)) reason = "当前区域需要人工上传或确认文件。";
    else if (/字数|长度|格式|校验/.test(rawReason)) reason = "填写内容不符合网站当前的格式或长度要求。";
    return {
      state: "partial",
      title: "一键填写已结束，但有内容需要检查",
      reason: `${where}：${reason}`,
      action: "当前没有建立恢复检查点；请人工核对这些失败项。再次运行会按普通填写流程重新扫描页面。",
      checkpoint: ""
    };
  }
  if (String(x.completionStatus || "") === "complete") {
    return {
      state: "complete",
      title: "一键填写已完成",
      reason: "没有检测到自动填写失败。",
      action: "请在最终保存或投递前快速核对关键信息。",
      checkpoint: ""
    };
  }
  if (String(x.completionStatus || "") === "failed" || x.success === false || String(x.success || "") === "failed") {
    return {
      state: "failed",
      title: "一键填写没有开始成功",
      reason: String(x.message || "当前页面没有进入可执行的自动填写流程。"),
      action: "一键填写会自动进行结构分析和 AI 候选兜底；如果本次仍未填写，请查看技术详情中的自动恢复结果。",
      checkpoint: ""
    };
  }
  if (Number(x.unhandledCount || 0) > 0) {
    return {
      state: "partial",
      title: "一键填写基本完成",
      reason: `还有 ${Number(x.unhandledCount || 0)} 个字段未能自动确认。`,
      action: "建议人工快速核对页面剩余必填项后再保存或提交。",
      checkpoint: ""
    };
  }
  return {
    state: "complete",
    title: "一键填写已完成",
    reason: "没有检测到自动填写失败。",
    action: "请在最终保存或投递前快速核对关键信息。",
    checkpoint: ""
  };
}


function shouldAttemptSameClickAiRecovery(result, siteSupportProbe, context) {
  if (!result || result.manualActionRequired || result.pausedForManualAction || result.stopped) return false;
  const ctx = context && typeof context === "object" ? context : {};
  // Mature local owners remain authoritative. Same-click AI recovery is only for a
  // genuinely generic/new site where the Core has no verified owner yet.
  if (String(ctx.matchedWorkflowId || "") || ctx.localConfigFound || ctx.builtInConfigFound || ctx.domPlatformDetected) return false;
  const filled = Math.max(0, Number(result.filledCount || 0));
  const failed = Math.max(0, Number(Array.isArray(result.failedFields) ? result.failedFields.length : result.failedCount || 0));
  const controls = Math.max(0, Number(siteSupportProbe && siteSupportProbe.visibleEditableControlCount || 0));
  const labels = Math.max(0, Number(siteSupportProbe && siteSupportProbe.visibleLabelLikeCount || 0));
  if (controls <= 0 || labels <= 0) return false;
  const message = String(result.message || "");
  const entryGap = filled === 0 && /未找到标题元素|未找到表单字段|未找到匹配的字段|交互式表单已识别/.test(message);
  const semanticCoverageGap = filled > 0 && controls >= 3 && controls > filled + failed + 1;
  return entryGap || semanticCoverageGap;
}

async function attemptSameClickAiRecovery(wc, rawUrl, resumePayloadJson, urlJson, context, firstResult, siteSupportProbe) {
  const trace = {
    attempted: false,
    candidateGeneratedOrFound: false,
    candidateInstalled: false,
    retried: false,
    success: false,
    reason: "not_applicable",
    firstMessage: String(firstResult && firstResult.message || ""),
    route: "",
    runtimeMappingsApplied: 0,
    valueCandidatesInstalled: 0,
    siteCandidateInstalled: false,
    retryFilledCount: 0,
    retryMessage: ""
  };
  if (!shouldAttemptSameClickAiRecovery(firstResult, siteSupportProbe, context)) return { result: firstResult, trace, aiAssist: null };

  trace.attempted = true;
  const support = Object.assign({}, siteSupportProbe || {}, classifySiteSupport({
    matchedWorkflowId: String(context && context.matchedWorkflowId || ""),
    localConfigFound: !!(context && context.localConfigFound),
    builtInConfigFound: !!(context && context.builtInConfigFound),
    domPlatformDetected: !!(context && context.domPlatformDetected),
    visibleEditableControlCount: Number(siteSupportProbe && siteSupportProbe.visibleEditableControlCount || 0),
    visibleLabelLikeCount: Number(siteSupportProbe && siteSupportProbe.visibleLabelLikeCount || 0),
    filledCount: 0,
    totalFieldsFound: Number(firstResult && (firstResult.totalFieldsFound || firstResult.totalFields) || 0)
  }));
  const firstFilled = Math.max(0, Number(firstResult && firstResult.filledCount || 0));
  const firstFailed = Math.max(0, Number(firstResult && Array.isArray(firstResult.failedFields) ? firstResult.failedFields.length : 0));
  const inferredUnhandled = Math.max(0, Number(siteSupportProbe && siteSupportProbe.visibleEditableControlCount || 0) - firstFilled - firstFailed);
  const postFillGap = classifyAutofillGap({
    completionStatus: firstFilled > 0 ? "partial" : "failed",
    failedCount: firstFailed,
    unhandledCount: inferredUnhandled,
    failedFields: Array.isArray(firstResult && firstResult.failedFields) ? firstResult.failedFields : [],
    missingProfileFields: [],
    siteSupportCode: String(support.code || "")
  });
  if (!postFillGap.aiSemanticRecommended) {
    trace.reason = "gap_not_ai_eligible";
    return { result: firstResult, trace, aiAssist: null };
  }

  try {
    const foundation = await preparePostFillAiGapCandidate(wc, rawUrl, {
      postFillGap,
      failedFields: Array.isArray(firstResult && firstResult.failedFields) ? firstResult.failedFields : [],
      unhandledFields: [],
      matchedWorkflowId: String(context && context.matchedWorkflowId || ""),
      siteSupportDiagnostic: support
    });
    trace.candidateGeneratedOrFound = !!(foundation && foundation.candidateAvailable);
    if (!trace.candidateGeneratedOrFound) {
      trace.reason = String(foundation && foundation.status || "candidate_unavailable");
      return { result: firstResult, trace, aiAssist: null };
    }

    const retryAssist = await prepareLocalFirstAiAssist(wc, rawUrl, context || {});
    trace.route = String(retryAssist && retryAssist.route || "");
    trace.runtimeMappingsApplied = Number(retryAssist && retryAssist.runtimeMappingsApplied || 0);
    trace.valueCandidatesInstalled = Number(retryAssist && retryAssist.valueCandidatesInstalled || 0);
    trace.siteCandidateInstalled = !!(retryAssist && retryAssist.siteCandidateInstalled);
    trace.candidateInstalled = trace.runtimeMappingsApplied > 0 || trace.valueCandidatesInstalled > 0 || trace.siteCandidateInstalled;
    if (!trace.candidateInstalled) {
      trace.reason = "candidate_not_installable";
      return { result: firstResult, trace, aiAssist: retryAssist };
    }

    // Exactly one bounded retry in the same click. Existing-value preservation in
    // RuntimeSelectorOverlay/VisibleForm means the retry cannot replay or overwrite
    // scalar values already committed by the first pass.
    const retryResult = await runIsolated(wc, `window.OfferAutofill.run(${resumePayloadJson}, { url: ${urlJson} })`);
    trace.retried = true;
    trace.retryFilledCount = Number(retryResult && retryResult.filledCount || 0);
    trace.retryMessage = String(retryResult && retryResult.message || "");
    trace.success = trace.retryFilledCount > 0 || !!(retryResult && retryResult.success === true);
    trace.reason = trace.success ? "same_click_ai_core_retry_succeeded" : "same_click_ai_core_retry_no_commit";
    return { result: trace.success ? retryResult : firstResult, trace, aiAssist: retryAssist };
  } catch (error) {
    trace.reason = "same_click_ai_recovery_error";
    trace.error = String(error && error.message || error).slice(0, 800);
    return { result: firstResult, trace, aiAssist: null };
  }
}

ipcMain.handle("lite:run-autofill", async (_event, guestId) => {
  const wc = getGuest(guestId);
  const rawUrl = wc.getURL();
  if (!/^https?:\/\//i.test(rawUrl)) throw new Error("当前页面不是 http/https 网页");
  await injectAutofillCore(wc);
  const localConfig = await installLocalConfig(wc, rawUrl);
  const resumeData = loadProfile(PROFILE_FILE);
  const payload = JSON.stringify(resumeData);
  const urlJson = JSON.stringify(rawUrl);
  const matchedWorkflowId = await runIsolated(wc, `(() => {
    try {
      const w = window.AF && AF.PrivateSpecialSites && typeof AF.PrivateSpecialSites.getWorkflowForUrl === "function"
        ? AF.PrivateSpecialSites.getWorkflowForUrl(${urlJson})
        : null;
      return w && w.id ? String(w.id) : "";
    } catch (_) { return ""; }
  })()`);
  const siteSupportProbe = await collectSiteSupportProbe(wc, rawUrl);
  let bankcommTrustedBasicPreflight = null;
  let bankcommResumeCheckpoint = null;
  let bankcommRecoveryCheckpoint = null;
  if (String(matchedWorkflowId || "") === "bankcomm-recruitment") {
    try {
      bankcommResumeCheckpoint = await runIsolated(wc, `(async () => {
        try {
          const api = window.AF && AF.SpecialSiteWorkflow && AF.SpecialSiteWorkflow._test;
          return api && typeof api.getManualWorkflowCheckpointForCurrentPage === "function"
            ? await api.getManualWorkflowCheckpointForCurrentPage()
            : null;
        } catch (_) { return null; }
      })()`);
    } catch (_) { bankcommResumeCheckpoint = null; }
    try {
      bankcommRecoveryCheckpoint = await runIsolated(wc, `(async () => {
        try {
          const api = window.AF && AF.SpecialSiteWorkflow && AF.SpecialSiteWorkflow._test;
          return api && typeof api.getRecoveryWorkflowCheckpointForCurrentPage === "function"
            ? await api.getRecoveryWorkflowCheckpointForCurrentPage()
            : null;
        } catch (_) { return null; }
      })()`);
    } catch (_) { bankcommRecoveryCheckpoint = null; }
    const activeBankcommCheckpoint = (bankcommResumeCheckpoint && bankcommResumeCheckpoint.status === "waiting_manual")
      ? bankcommResumeCheckpoint
      : ((bankcommRecoveryCheckpoint && bankcommRecoveryCheckpoint.status === "waiting_recovery") ? bankcommRecoveryCheckpoint : null);
    const resumeStepIndex = Number(activeBankcommCheckpoint && activeBankcommCheckpoint.stepIndex);
    const hasWaitingCheckpoint = !!(
      activeBankcommCheckpoint &&
      Number.isInteger(resumeStepIndex) && resumeStepIndex >= 0
    );
    const resumeStartsAfterBasic = hasWaitingCheckpoint && resumeStepIndex > 0;
    if (resumeStartsAfterBasic) {
      // Checkpoint-first rule: once a Bankcomm workflow paused after Basic, every
      // subsequent one-click run starts from the persisted checkpoint. Site-specific
      // trusted preflights for earlier steps must not run before the workflow state
      // machine, otherwise they can reopen a completed Basic editor and visually
      // roll the page backwards. Step 0 (Basic itself) still gets its preflight when
      // the checkpoint is on Basic.
      bankcommTrustedBasicPreflight = {
        attempted: false,
        success: true,
        skippedForResumeCheckpoint: true,
        checkpointStepIndex: resumeStepIndex,
        checkpointStepName: String(activeBankcommCheckpoint && activeBankcommCheckpoint.stepName || ""),
        reason: "manual_checkpoint_resume_after_basic"
      };
    } else {
      try { bankcommTrustedBasicPreflight = await prepareBankcommBasicForTrustedInput(wc, resumeData); }
      catch (error) { bankcommTrustedBasicPreflight = { attempted: true, success: false, reason: String(error && error.message || error).slice(0, 300) }; }
    }
  }
  const aiAssistContext = {
    matchedWorkflowId: String(matchedWorkflowId || ""),
    localConfigFound: !!(localConfig && localConfig.found && localConfig.ok !== false),
    builtInConfigFound: !!(siteSupportProbe && siteSupportProbe.builtInConfigFound),
    domPlatformDetected: !!(siteSupportProbe && siteSupportProbe.domPlatformDetected)
  };
  let aiAssist = await prepareLocalFirstAiAssist(wc, rawUrl, aiAssistContext);
  const zhiyeEducationBefore = await collectZhiyeEducationDebug(wc, rawUrl, Array.isArray(resumeData.education) ? resumeData.education.length : 0);
  const tencentTextareaDebug = await collectTencentTextareaDebug(wc, rawUrl);
  // Each diagnostic belongs to exactly one autofill attempt; stale writer
  // traces from a previous click would otherwise be misleading.
  await runIsolated(wc, `document.documentElement.removeAttribute("data-af-longtext-debug")`);
  await runIsolated(wc, `document.documentElement.removeAttribute("data-af-repeat-record-trace")`);
  await runIsolated(wc, `document.documentElement.removeAttribute("data-af-execution-route-trace")`);
  await runIsolated(wc, `document.documentElement.removeAttribute("data-af-zhaopin-higher-education-trace")`);
  await runIsolated(wc, `document.documentElement.removeAttribute("data-af-zhaopin-repeat-section-trace")`);
  await runIsolated(wc, `document.documentElement.removeAttribute("data-af-zhaopin-repeat-save-trace")`);
  await runIsolated(wc, `document.documentElement.removeAttribute("data-af-bankcomm-education-checkpoint-probe")`);
  await runIsolated(wc, `document.documentElement.removeAttribute("data-af-phoenix-select-trace")`);
  let result = await runIsolated(wc, `window.OfferAutofill.run(${payload}, { url: ${urlJson} })`);
  let sameClickAiRecovery = { attempted: false, reason: "not_applicable" };
  if (shouldAttemptSameClickAiRecovery(result, siteSupportProbe, aiAssistContext)) {
    const recovered = await attemptSameClickAiRecovery(wc, rawUrl, payload, urlJson, aiAssistContext, result, siteSupportProbe);
    result = recovered && recovered.result || result;
    sameClickAiRecovery = recovered && recovered.trace || sameClickAiRecovery;
    if (recovered && recovered.aiAssist) aiAssist = recovered.aiAssist;
  }
  const zhiyeEducationAfter = await collectZhiyeEducationDebug(wc, rawUrl, Array.isArray(resumeData.education) ? resumeData.education.length : 0);
  const dateDebug = await runIsolated(wc, `(() => {
    try {
      const read = (name) => {
        try {
          const parsed = JSON.parse(document.documentElement.getAttribute(name) || "{}");
          return parsed && typeof parsed === "object" ? parsed : {};
        } catch (_) { return {}; }
      };
      return Object.assign({}, read("data-af-element-month-debug"), read("data-af-date-debug"));
    } catch (_) { return {}; }
  })()`);
  const longTextDiagnostics = await runIsolated(wc, `(() => {
    try {
      const parsed = JSON.parse(document.documentElement.getAttribute("data-af-longtext-debug") || "{}");
      return parsed && typeof parsed === "object" ? parsed : {};
    } catch (_) { return {}; }
  })()`);
  const repeatRecordTrace = await runIsolated(wc, `(() => { try { return JSON.parse(document.documentElement.getAttribute("data-af-repeat-record-trace") || "{}"); } catch (_) { return {}; } })()`);
  const zhaopinRepeatSectionTrace = await runIsolated(wc, `(() => { try { return JSON.parse(document.documentElement.getAttribute("data-af-zhaopin-repeat-section-trace") || "{}"); } catch (_) { return {}; } })()`);
  const zhaopinRepeatSaveTrace = await runIsolated(wc, `(() => { try { return JSON.parse(document.documentElement.getAttribute("data-af-zhaopin-repeat-save-trace") || "{}"); } catch (_) { return {}; } })()`);
  const executionRouteTrace = await runIsolated(wc, `(() => { try { return JSON.parse(document.documentElement.getAttribute("data-af-execution-route-trace") || "{}"); } catch (_) { return {}; } })()`);
  const bankcommEducationCheckpointProbe = await runIsolated(wc, `(() => { try { return JSON.parse(document.documentElement.getAttribute("data-af-bankcomm-education-checkpoint-probe") || "{}"); } catch (_) { return {}; } })()`);
  const phoenixSelectTrace = await runIsolated(wc, `(() => { try { const x = JSON.parse(document.documentElement.getAttribute("data-af-phoenix-select-trace") || "[]"); return Array.isArray(x) ? x : []; } catch (_) { return []; } })()`);
  const rawProfile = readRawProfile();
  const knownQuestions = profileKnownQuestionSet(rawProfile);
  const remainingRequiredFieldsRaw = await scanVisibleRequiredFields(wc);
  const routeInfo = routeInfoForUrl(rawUrl);
  const zhaopinPageDebug = matchedWorkflowId === "zhaopin-campus-enterprise-resume-v1"
    ? await collectZhaopinPageDebug(wc) : null;
  const zhaopinHigherEducationDebug = await collectZhaopinHigherEducationDebug(wc, matchedWorkflowId === "zhaopin-campus-enterprise-resume-v1");
  const higherTraceRecords = Array.isArray(zhaopinHigherEducationDebug.trace && zhaopinHigherEducationDebug.trace.records) ? zhaopinHigherEducationDebug.trace.records : [];
  const higherFillCoverage = {
    attempted: higherTraceRecords.length,
    committed: higherTraceRecords.filter((item) => item && item.committed === true).length,
    failed: higherTraceRecords.filter((item) => item && item.committed !== true).length
  };
  const explicitMissing = Array.isArray(result && result.failedFields) ? result.failedFields
    .filter((f) => /简历(?:中)?缺少(?:此字段资料|必填字段值)/.test(String(f && f.reason || "")))
    .map((f) => ({ fieldKey: String(f && f.fieldKey || ""), label: String(f && f.label || "") })) : [];
  const missingSeen = new Set();
  const missingProfileFields = explicitMissing.filter((x) => {
    const k = normalizeQuestionText(x.label);
    if (!k || missingSeen.has(k)) return false;
    missingSeen.add(k);
    return true;
  }).slice(0, 40);
  const remainingRequiredFields = (remainingRequiredFieldsRaw || []).map((x) => ({
    label: String(x && x.label || ""),
    knownInProfile: knownQuestions.has(normalizeQuestionText(x && x.label || ""))
  })).slice(0, 60);

  const filledCount = Number(result && result.filledCount || 0);
  const totalFieldsFound = Number(result && result.totalFieldsFound || result && result.totalFields || 0);
  const coverageFailures = Array.isArray(zhaopinHigherEducationDebug.coverage && zhaopinHigherEducationDebug.coverage.unmappedRequiredLabels)
    ? zhaopinHigherEducationDebug.coverage.unmappedRequiredLabels : [];
  const failedCount = Number(result && result.failedCount || (result && Array.isArray(result.failedFields) ? result.failedFields.length : 0) || 0) + coverageFailures.length;
  const unhandledCount = Math.max(0, totalFieldsFound - filledCount - failedCount);
  const unhandledFields = Array.isArray(result && result.unhandledFields) ? result.unhandledFields.slice(0, 100) : (unhandledCount ? [{ fieldKey: "", label: "未命名字段", reason: "core_count_reconciliation" }] : []);
  const resultMessage = String(result && result.message || "");
  const explicitRunFailure = !!(result && result.success === false && filledCount === 0);
  const zeroFillFailure = filledCount === 0 && (
    explicitRunFailure ||
    totalFieldsFound > 0 ||
    /未找到标题元素|未找到表单字段|未找到匹配的字段|交互式表单已识别/.test(resultMessage)
  );
  const manualActionRequired = !!(result && result.manualActionRequired);
  let completionStatus = manualActionRequired
    ? "partial"
    : (result && result.stopped ? "failed" : (zeroFillFailure ? "failed" : (failedCount || unhandledCount ? "partial" : "complete")));
  const completionResolution = resolveAutofillCompletionState({
    unhandledFields,
    failedCount,
    failureContext: result && result.failureContext,
    manualActionRequired,
    stopped: !!(result && result.stopped),
    resumedFromRecoveryCheckpoint: !!(result && result.resumedFromRecoveryCheckpoint),
    recoveryCheckpointResolved: !!(result && result.recoveryCheckpointResolved),
    status: completionStatus
  });
  if (completionResolution && completionResolution.status === "complete") {
    completionStatus = "complete";
  }
  const failureContext = result && result.failureContext && typeof result.failureContext === "object" ? result.failureContext : null;
  const recoveryCheckpoint = result && result.recoveryCheckpoint && typeof result.recoveryCheckpoint === "object" ? result.recoveryCheckpoint : null;
  const recoveryCheckpointCreated = !!(result && result.recoveryCheckpointCreated);
  const userFacingSummary = buildAutofillUserFacingSummary({
    failureContext,
    recoveryCheckpointCreated,
    manualActionRequired,
    manualActionStep: result && result.manualActionStep,
    manualActionReason: result && result.manualActionReason,
    failedCount,
    failedFields: result && result.failedFields,
    unhandledCount,
    completionStatus,
    success: completionStatus,
    message: resultMessage
  });

  const siteSupportDiagnostic = Object.assign({}, siteSupportProbe || {}, classifySiteSupport({
    matchedWorkflowId,
    localConfigFound: !!(localConfig && localConfig.found && localConfig.ok !== false),
    builtInConfigFound: !!(siteSupportProbe && siteSupportProbe.builtInConfigFound),
    domPlatformDetected: !!(siteSupportProbe && siteSupportProbe.domPlatformDetected),
    visibleEditableControlCount: Number(siteSupportProbe && siteSupportProbe.visibleEditableControlCount || 0),
    visibleLabelLikeCount: Number(siteSupportProbe && siteSupportProbe.visibleLabelLikeCount || 0),
    filledCount,
    totalFieldsFound
  }));
  const sanitized = {
    at: new Date().toISOString(),
    buildId: BUILD_ID,
    url: safeUrl(rawUrl),
    filledCount,
    totalFieldsFound,
    failedCount,
    unhandledCount,
    unhandledFields,
    stopped: !!(result && result.stopped),
    completionStatus,
    success: completionStatus,
    completionResolver: completionResolution && typeof completionResolution === "object" ? completionResolution : null,
    message: resultMessage,
    manualActionRequired,
    pausedForManualAction: !!(result && result.pausedForManualAction),
    manualActionStep: String(result && result.manualActionStep || ""),
    manualActionReason: String(result && result.manualActionReason || ""),
    manualActionFields: Array.isArray(result && result.manualActionFields) ? result.manualActionFields.slice(0, 20) : [],
    workflowNotices: Array.isArray(result && result.notices) ? result.notices.slice(0, 30).map((x) => String(x || "")) : [],
    failureContext,
    recoveryCheckpoint,
    recoveryCheckpointCreated,
    resumedFromRecoveryCheckpoint: !!(result && result.resumedFromRecoveryCheckpoint),
    recoveryCheckpointResolved: !!(result && result.recoveryCheckpointResolved),
    executionLedger: result && result.executionLedger && typeof result.executionLedger === "object" ? result.executionLedger : null,
    formFieldCheckpoint: result && result.formFieldCheckpoint && typeof result.formFieldCheckpoint === "object" ? result.formFieldCheckpoint : null,
    formRecordCheckpoint: result && result.formRecordCheckpoint && typeof result.formRecordCheckpoint === "object" ? result.formRecordCheckpoint : null,
    formRecordExecutionLedger: result && result.formRecordExecutionLedger && typeof result.formRecordExecutionLedger === "object" ? result.formRecordExecutionLedger : null,
    formSectionCheckpoint: result && result.formSectionCheckpoint && typeof result.formSectionCheckpoint === "object" ? result.formSectionCheckpoint : null,
    formWorkflowCheckpoint: result && result.formWorkflowCheckpoint && typeof result.formWorkflowCheckpoint === "object" ? result.formWorkflowCheckpoint : null,
    checkpointRuntime: result && result.checkpointRuntime && typeof result.checkpointRuntime === "object" ? result.checkpointRuntime : null,
    runtimeSelectorOverlay: result && result.runtimeSelectorOverlay && typeof result.runtimeSelectorOverlay === "object" ? result.runtimeSelectorOverlay : null,
    repeatRecordExecution: result && result.repeatRecordExecution && typeof result.repeatRecordExecution === "object" ? result.repeatRecordExecution : null,
    userFacingSummary,
    matchedWorkflowId: String(matchedWorkflowId || ""),
    bankcommTrustedBasicPreflight: bankcommTrustedBasicPreflight && typeof bankcommTrustedBasicPreflight === "object" ? bankcommTrustedBasicPreflight : null,
    bankcommResumeCheckpoint: bankcommResumeCheckpoint && typeof bankcommResumeCheckpoint === "object" ? bankcommResumeCheckpoint : null,
    bankcommRecoveryCheckpoint: bankcommRecoveryCheckpoint && typeof bankcommRecoveryCheckpoint === "object" ? bankcommRecoveryCheckpoint : null,
    bankcommEducationCheckpointProbe: bankcommEducationCheckpointProbe && typeof bankcommEducationCheckpointProbe === "object" ? bankcommEducationCheckpointProbe : {},
    bankcommExecutionAudit: result && result.bankcommExecutionAudit && typeof result.bankcommExecutionAudit === "object" ? result.bankcommExecutionAudit : null,
    phoenixSelectTrace: Array.isArray(phoenixSelectTrace) ? phoenixSelectTrace.slice(0, 30) : [],
    aiAssist: aiAssist && typeof aiAssist === "object" ? aiAssist : {},
    sameClickAiRecovery: sameClickAiRecovery && typeof sameClickAiRecovery === "object" ? sameClickAiRecovery : {},
    siteSupportDiagnostic,
    routeInfo,
    zhaopinPageDebug,
    zhaopinHigherEducationTrace: zhaopinHigherEducationDebug.trace || {},
    higherEducationCoverage: zhaopinHigherEducationDebug.coverage || {},
    mappingCoverageComplete: !!(zhaopinHigherEducationDebug.coverage && zhaopinHigherEducationDebug.coverage.complete),
    fillCoverage: higherFillCoverage,
    educationFieldOwnership: zhaopinHigherEducationDebug.ownership || {},
    currentVisibleEditorMode: !!zhaopinHigherEducationDebug.currentVisibleEditorMode,
    educationRepeatNavigationTrace: zhaopinHigherEducationDebug.trace && zhaopinHigherEducationDebug.trace.educationRepeatNavigationTrace || {},
    resumeSectionNavigationTrace: zhaopinHigherEducationDebug.trace && zhaopinHigherEducationDebug.trace.resumeSectionNavigationTrace || {},
    moduleTransactionTrace: zhaopinHigherEducationDebug.trace && zhaopinHigherEducationDebug.trace.moduleTransactionTrace || {},
    labelControlTrace: higherTraceRecords.map((item) => item && item.labelControlTrace).filter(Boolean),
    higherEducationRecordTrace: zhaopinHigherEducationDebug.trace && zhaopinHigherEducationDebug.trace.higherEducationRecordTrace || {},
    currentVisibleEditorExecutionTrace: zhaopinHigherEducationDebug.trace && zhaopinHigherEducationDebug.trace.currentVisibleEditorExecutionTrace || { enabled: false, selectedProfileRecordIndex: null, indexBase: 0, attemptedRecordCount: 0 },
    zhaopinChoiceTrace: Array.isArray(zhaopinHigherEducationDebug.trace && zhaopinHigherEducationDebug.trace.zhaopinChoiceTrace) ? zhaopinHigherEducationDebug.trace.zhaopinChoiceTrace : [],
    higherEducationEditorStateTrace: zhaopinHigherEducationDebug.trace && zhaopinHigherEducationDebug.trace.higherEducationEditorStateTrace || { initialState: "unknown", sectionScopeResolved: false, editableControlCount: 0, editButtonFound: false, editButtonClicked: false, stateAfterClick: "unknown", editorReady: false, reason: "trace_not_available" },
    sectionStateTrace: zhaopinHigherEducationDebug.trace && zhaopinHigherEducationDebug.trace.sectionStateTrace || { activeNavText: "", detectedSection: "", detectionStrategy: "none", currentVisibleSectionTitle: "" },
    scopeSanityTrace: zhaopinHigherEducationDebug.trace && zhaopinHigherEducationDebug.trace.scopeSanityTrace || { configuredScopeLabelCount: 0, configuredScopeEditableControlCount: 0, likelyTooBroad: false, candidateEditorCount: 0, selectedEditorStrategy: "" },
    labelCandidateTrace: Array.isArray(zhaopinHigherEducationDebug.trace && zhaopinHigherEducationDebug.trace.labelCandidateTrace) ? zhaopinHigherEducationDebug.trace.labelCandidateTrace : [],
    fieldStructureTrace: Array.isArray(zhaopinHigherEducationDebug.trace && zhaopinHigherEducationDebug.trace.fieldStructureTrace) ? zhaopinHigherEducationDebug.trace.fieldStructureTrace : [],
    activeEditorControlTrace: Array.isArray(zhaopinHigherEducationDebug.trace && zhaopinHigherEducationDebug.trace.activeEditorControlTrace) ? zhaopinHigherEducationDebug.trace.activeEditorControlTrace : [],
    higherEducationBindingResolverTrace: Array.isArray(zhaopinHigherEducationDebug.trace && zhaopinHigherEducationDebug.trace.higherEducationBindingResolverTrace) ? zhaopinHigherEducationDebug.trace.higherEducationBindingResolverTrace : [],
    zhiyeEducationDebug: Object.keys(zhiyeEducationBefore || {}).length ? Object.assign({}, zhiyeEducationBefore, { pageCardCountAfter: Number(zhiyeEducationAfter && zhiyeEducationAfter.candidateCardCount || 0), cardsAfter: Array.isArray(zhiyeEducationAfter && zhiyeEducationAfter.cards) ? zhiyeEducationAfter.cards : [] }) : {},
    repeatRecordTrace: repeatRecordTrace && typeof repeatRecordTrace === "object" ? repeatRecordTrace : {},
    zhaopinRepeatSectionTrace: zhaopinRepeatSectionTrace && typeof zhaopinRepeatSectionTrace === "object" ? zhaopinRepeatSectionTrace : {},
    zhaopinRepeatSaveTrace: zhaopinRepeatSaveTrace && typeof zhaopinRepeatSaveTrace === "object" ? zhaopinRepeatSaveTrace : {},
    executionRouteTrace: executionRouteTrace && typeof executionRouteTrace === "object" ? executionRouteTrace : {},
    tencentTextareaDebug,
    recordScopeDebug: Array.isArray(longTextDiagnostics && longTextDiagnostics.recordScopeDebug) ? longTextDiagnostics.recordScopeDebug : [],
    structuredPlanDebug: Array.isArray(longTextDiagnostics && longTextDiagnostics.structuredPlanDebug) ? longTextDiagnostics.structuredPlanDebug : [],
    longTextTrace: longTextDiagnostics && longTextDiagnostics.longTextTrace && typeof longTextDiagnostics.longTextTrace === "object" ? longTextDiagnostics.longTextTrace : {},
    dateDebug: dateDebug && typeof dateDebug === "object" ? dateDebug : {},
    missingProfileFields,
    remainingRequiredFields,
    failedFields: (Array.isArray(result && result.failedFields) ? result.failedFields.slice(0, 100).map((f) => ({
      fieldKey: String(f && f.fieldKey || ""),
      label: String(f && f.label || ""),
      reason: String(f && f.reason || "")
    })) : []).concat(coverageFailures.map((label) => ({ fieldKey: "higherEducationCoverage", label, reason: "页面必填字段尚未纳入高等教育字段序列" }))),
    localConfig: localConfig && localConfig.found ? path.basename(localConfig.file || "") : null
  };
  sanitized.postFillGap = classifyAutofillGap({
    completionStatus: sanitized.completionStatus,
    failedCount: sanitized.failedCount,
    unhandledCount: sanitized.unhandledCount,
    failedFields: sanitized.failedFields,
    missingProfileFields: sanitized.missingProfileFields,
    siteSupportCode: sanitized.siteSupportDiagnostic && sanitized.siteSupportDiagnostic.code
  });
  sanitized.aiGapFoundation = await preparePostFillAiGapCandidate(wc, rawUrl, sanitized);
  const logFile = appendDiagnostic(sanitized);
  return Object.assign({}, sanitized, { logFile });
});

async function analyzeSiteInternal(wc, rawUrl) {
  if (!/^https?:\/\//i.test(rawUrl || "")) throw new Error("请先打开招聘网页再分析");
  await injectAutofillCore(wc);
  const probe = await collectSiteSupportProbe(wc, rawUrl);
  const localConfig = readLocalConfig(rawUrl);
  const analysis = await runIsolated(wc, `(async () => {
    if (!window.AF || !AF.SiteAnalysisCollector || typeof AF.SiteAnalysisCollector.analyze !== "function") {
      throw new Error("SITE_ANALYSIS_COLLECTOR_NOT_READY");
    }
    return AF.SiteAnalysisCollector.analyze({ maxModules: 18, maxControlsPerSurface: 260 });
  })()`);
  const staticScan = analysis && analysis.staticScan || {};
  const formGraph = analysis && analysis.formGraph || {};
  const recordGraph = analysis && analysis.recordGraph || {};
  const graphCoverage = analysis && analysis.graphCoverage || {};
  const interactive = analysis && analysis.interactive || {};
  const result = {
    at: new Date().toISOString(),
    buildId: BUILD_ID,
    url: safeUrl(rawUrl),
    hostname: (() => { try { return new URL(rawUrl).hostname; } catch (_) { return ""; } })(),
    localConfig: localConfig && localConfig.file ? path.basename(localConfig.file) : null,
    siteSupportProbe: probe || {},
    analysis: analysis && typeof analysis === "object" ? analysis : {},
    summary: {
      staticControlCount: Number(staticScan.controlCount || 0),
      staticLabeledControlCount: Number(staticScan.labeledControlCount || 0),
      staticSectionCount: Array.isArray(staticScan.sections) ? staticScan.sections.length : 0,
      formGraphSectionCount: Number(formGraph.totals && formGraph.totals.sections || 0),
      formGraphRowCount: Number(formGraph.totals && formGraph.totals.rows || 0),
      formGraphControlCount: Number(formGraph.totals && formGraph.totals.controls || 0),
      formGraphLinkedFieldCount: Number(graphCoverage.linkedStaticFieldCount || 0),
      formGraphLinkedRatio: Number(graphCoverage.linkedRatio || 0),
      recordGraphGroupCount: Number(recordGraph.totals && recordGraph.totals.groups || 0),
      recordGraphRecordCount: Number(recordGraph.totals && recordGraph.totals.records || 0),
      recordGraphSavedRecordCount: Number(recordGraph.totals && recordGraph.totals.savedRecords || 0),
      recordGraphEditorRecordCount: Number(recordGraph.totals && recordGraph.totals.editorRecords || 0),
      recordGraphAddActionCount: Number(recordGraph.totals && recordGraph.totals.addActions || 0),
      interactiveModuleCount: Array.isArray(interactive.modules) ? interactive.modules.length : 0,
      interactiveSkippedCount: Array.isArray(interactive.skipped) ? interactive.skipped.length : 0,
      interactiveFailedCount: Array.isArray(interactive.failed) ? interactive.failed.length : 0,
      interactiveLeftOpenCount: Array.isArray(interactive.leftOpen) ? interactive.leftOpen.length : 0
    },
    safety: {
      autofillExecuted: false,
      finalSubmitExecuted: false,
      saveExecuted: false,
      addProbeAllowed: false,
      fieldValuesStored: false,
      fullUrlQueryStored: false
    }
  };
  const file = appendSiteAnalysis(result, rawUrl);
  const bundle = updateSiteAnalysisBundle(result, rawUrl, file);
  const aiInput = buildAiSiteInput(bundle.file, rawUrl);
  return Object.assign({}, result, {
    analysisFile: file,
    analysisFileName: path.basename(file),
    analysisBundleFile: bundle.file,
    analysisBundleFileName: path.basename(bundle.file),
    analysisBundleSnapshotCount: Number(bundle.snapshotCount || 0),
    analysisFingerprint: bundle.fingerprint,
    aiInputFile: aiInput && aiInput.file || "",
    aiInputFileName: aiInput && aiInput.file ? path.basename(aiInput.file) : "",
    aiInputSnapshotCount: Number(aiInput && aiInput.snapshotCount || 0),
    aiInputTotalFieldCount: Number(aiInput && aiInput.totalFieldCount || 0),
    aiInputMappedFieldCount: Number(aiInput && aiInput.mappedFieldCount || 0),
    aiInputTentativeMappedFieldCount: Number(aiInput && aiInput.tentativeMappedFieldCount || 0),
    aiInputUnmappedFieldCount: Number(aiInput && aiInput.unmappedFieldCount || 0),
    aiInputMappingNeededFieldCount: Number(aiInput && aiInput.aiMappingNeededFieldCount || 0),
    aiReviewFile: aiInput && aiInput.reviewFile || "",
    aiReviewFileName: aiInput && aiInput.reviewFile ? path.basename(aiInput.reviewFile) : "",
    aiInputLegacySnapshotCountExcluded: Number(aiInput && aiInput.legacySnapshotCountExcluded || 0),
    aiInputEmptySnapshotCountExcluded: Number(aiInput && aiInput.emptySnapshotCountExcluded || 0)
  });
}

ipcMain.handle("lite:analyze-site", async (_event, guestId) => {
  const wc = getGuest(guestId);
  return analyzeSiteInternal(wc, wc.getURL());
});


ipcMain.handle("lite:get-ai-settings", async () => {
  return aiSettingsStore.getPublicSettings();
});

ipcMain.handle("lite:save-ai-settings", async (_event, payload) => {
  return aiSettingsStore.save(payload || {});
});

function writeAiCandidateOverlay(rawUrl, review, patch) {
  const overlay = compileRuntimeSemanticOverlay(review, patch, { minConfidence: 0.5 });
  const file = aiCandidateFileForUrl(rawUrl);
  const payload = Object.assign({}, overlay, {
    generatedAt: new Date().toISOString(),
    sourceReviewFile: path.basename(aiReviewFileForUrl(rawUrl)),
    sourcePatchFile: path.basename(aiPatchFileForUrl(rawUrl))
  });
  fs.writeFileSync(file, JSON.stringify(payload, null, 2), "utf8");

  let siteCandidate = compileSemanticSiteCandidate(review, patch, { minConfidence: 0.5 });
  let graphStructure = null;
  try {
    const bundleFile = siteAnalysisBundleFileForUrl(rawUrl);
    if (fs.existsSync(bundleFile)) {
      graphStructure = compileGraphStructureFromBundle(readJsonFile(bundleFile), rawUrl);
      if (graphStructure) siteCandidate = attachGraphStructureToSiteCandidate(siteCandidate, graphStructure);
    }
  } catch (error) {
    graphStructure = null;
  }
  const siteCandidateFile = aiSiteCandidateFileForUrl(rawUrl);
  const sitePayload = Object.assign({}, siteCandidate, {
    generatedAt: new Date().toISOString(),
    sourceReviewFile: path.basename(aiReviewFileForUrl(rawUrl)),
    sourcePatchFile: path.basename(aiPatchFileForUrl(rawUrl)),
    graphStructureSummary: graphStructure && graphStructure.summary || null
  });
  fs.writeFileSync(siteCandidateFile, JSON.stringify(sitePayload, null, 2), "utf8");
  return { file, overlay: payload, siteCandidateFile, siteCandidate: sitePayload, graphStructure };
}

function writeValueCandidateArtifact(rawUrl, valueReview, valuePatch, valueGate, meta) {
  const profileHash = readCurrentProfileFingerprint();
  const file = aiValueCandidateFileForUrl(rawUrl);
  const payload = {
    schemaType: "autofill-lite-ai-value-candidate-artifact",
    schemaVersion: 1,
    generatedAt: new Date().toISOString(),
    profileFingerprint: profileHash,
    sourcePatchFile: path.basename(aiPatchFileForUrl(rawUrl)),
    provider: String(meta && meta.provider || "local-fallback"),
    model: String(meta && meta.model || "none"),
    tokenBudget: Number(meta && meta.tokenBudget || 0),
    usage: meta && meta.usage || { inputTokens: 0, outputTokens: 0, totalTokens: 0 },
    apiAttempted: !!(meta && meta.apiAttempted),
    apiError: String(meta && meta.apiError || "").slice(0, 800),
    review: valueReview || { schemaType: "autofill-lite-ai-value-review", schemaVersion: 1, targets: [] },
    patch: valuePatch || { schemaType: "autofill-lite-ai-value-candidate-patch", schemaVersion: 1, decisions: [] },
    gate: valueGate || { executableCandidates: [], reviewOnlyCandidates: [], rejectedCandidates: [], summary: { total: 0, eligibleForCore: 0, reviewOnly: 0, rejected: 0 } },
    safety: {
      fullResumeIncluded: false,
      sensitiveProfileFieldsIncluded: false,
      synthesizedTextAutoFillAllowed: false,
      repeatRecordOwnerByAi: false
    }
  };
  fs.writeFileSync(file, JSON.stringify(payload, null, 2), "utf8");
  return { file, payload };
}

function loadValueCandidateArtifact(rawUrl) {
  const file = aiValueCandidateFileForUrl(rawUrl);
  if (!fs.existsSync(file)) return null;
  try {
    const artifact = readJsonFile(file);
    if (!artifact || artifact.schemaType !== "autofill-lite-ai-value-candidate-artifact") return null;
    const current = readCurrentProfileFingerprint();
    if (!current || String(artifact.profileFingerprint || "") !== current) return null;
    return { file, artifact };
  } catch (_) {
    return null;
  }
}

function loadValidatedAiCandidate(rawUrl) {
  const reviewFile = aiReviewFileForUrl(rawUrl);
  const patchFile = aiPatchFileForUrl(rawUrl);
  if (!fs.existsSync(reviewFile) || !fs.existsSync(patchFile)) return null;
  const review = validateReview(readJsonFile(reviewFile));
  const patch = validateSemanticPatch(review, readJsonFile(patchFile));
  const route = (() => { try { const u = new URL(rawUrl); return { hostname: u.hostname.toLowerCase(), pathname: u.pathname || "/" }; } catch (_) { return null; } })();
  if (!route) return null;
  if (String(review.page && review.page.hostname || "").toLowerCase() !== route.hostname) return null;
  if (String(review.page && review.page.pathname || "/") !== route.pathname) return null;
  const compiled = writeAiCandidateOverlay(rawUrl, review, patch);
  const valueArtifact = loadValueCandidateArtifact(rawUrl);
  if (valueArtifact && valueArtifact.artifact && valueArtifact.artifact.gate) {
    compiled.overlay.valueCandidates = Array.isArray(valueArtifact.artifact.gate.executableCandidates)
      ? valueArtifact.artifact.gate.executableCandidates.map((item) => ({
          fieldId: String(item.fieldId || ""),
          category: String(item.category || ""),
          fieldKey: String(item.fieldKey || ""),
          value: String(item.value || ""),
          mode: String(item.mode || ""),
          confidence: Number(item.confidence || 0),
          source: String(item.source || "ai_value_candidate")
        }))
      : [];
  }
  return {
    review,
    patch,
    file: compiled.file,
    overlay: compiled.overlay,
    siteCandidateFile: compiled.siteCandidateFile,
    siteCandidate: compiled.siteCandidate,
    valueCandidateFile: valueArtifact && valueArtifact.file || "",
    valueCandidateArtifact: valueArtifact && valueArtifact.artifact || null
  };
}


function loadVerifiedSemanticSiteCandidate(rawUrl) {
  const file = aiVerifiedSiteCandidateFileForUrl(rawUrl);
  if (!fs.existsSync(file)) return null;
  const verified = readJsonFile(file);
  if (!candidateMatchesUrl(verified, rawUrl)) return null;
  if (!verified.configTemplate || verified.configTemplate._serverStatus !== "verified") return null;
  return { file, siteCandidate: verified };
}

function latestInstalledCandidateDiagnostic(rawUrl) {
  const targetUrl = safeUrl(rawUrl);
  let files = [];
  try {
    files = fs.readdirSync(LOG_DIR)
      .filter((name) => /\.json$/i.test(name))
      .map((name) => path.join(LOG_DIR, name))
      .sort((a, b) => {
        try { return fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs; } catch (_) { return 0; }
      });
  } catch (_) { return null; }
  for (const file of files.slice(0, 300)) {
    try {
      const row = JSON.parse(fs.readFileSync(file, "utf8"));
      if (String(row && row.url || "") !== targetUrl) continue;
      if (!(row.aiAssist && row.aiAssist.siteCandidateInstalled)) continue;
      if (Number(row.filledCount || 0) <= 0) continue;
      return row;
    } catch (_) {}
  }
  return null;
}

function verifySemanticSiteCandidate(rawUrl) {
  const candidateFile = aiSiteCandidateFileForUrl(rawUrl);
  if (!fs.existsSync(candidateFile)) throw new Error("当前页面没有 SiteConfig candidate，请先生成 AI候选");
  const candidate = readJsonFile(candidateFile);
  if (!candidateMatchesUrl(candidate, rawUrl)) throw new Error("候选配置与当前页面路径不一致，请重新分析本站");
  const diagnostic = latestInstalledCandidateDiagnostic(rawUrl);
  if (!diagnostic) throw new Error("当前版本的新 AI candidate 已进入 Safety Gate 分类，但尚未进入受控执行，因此暂不能标记 verified；请保留候选，待后续受控执行阶段验证");
  const verified = buildVerifiedSiteCandidate(candidate, diagnostic, { verifiedAt: new Date().toISOString() });
  const file = aiVerifiedSiteCandidateFileForUrl(rawUrl);
  fs.writeFileSync(file, JSON.stringify(verified, null, 2), "utf8");
  appendDiagnostic({
    at: new Date().toISOString(),
    type: "semantic-site-candidate-verified",
    buildId: BUILD_ID,
    url: safeUrl(rawUrl),
    verifiedFile: path.basename(file),
    sourceCandidateFile: path.basename(candidateFile),
    verification: verified.verification || {},
    safety: {
      profileValuesIncluded: false,
      selectorsAuthoredByAi: false,
      pageActionsExecuted: false
    }
  });
  return {
    success: true,
    file,
    fileName: path.basename(file),
    verification: verified.verification || {},
    summary: verified.summary || {},
    semanticFieldCount: Number(verified.summary && verified.summary.acceptedFieldMappings || (verified.configTemplate._aiSemanticPatch && verified.configTemplate._aiSemanticPatch.fieldMappings || []).length || 0),
    sectionCount: Number(verified.summary && verified.summary.acceptedSectionMappings || (verified.configTemplate._aiSemanticPatch && verified.configTemplate._aiSemanticPatch.sectionMappings || []).length || 0)
  };
}

async function installPrefetchedSemanticCandidate(wc, rawUrl, siteCandidate) {
  if (!siteCandidate || !siteCandidate.configTemplate) return { installed: false, reason: "candidate_missing" };
  const payload = JSON.stringify(siteCandidate.configTemplate);
  const urlJson = JSON.stringify(String(rawUrl || ""));
  return runIsolated(wc, `(async () => {
    try {
      if (!window.AF || !AF.SiteLoader || typeof AF.SiteLoader.setPrefetchedConfig !== "function") {
        return { installed: false, reason: "site_loader_unavailable" };
      }
      const url = ${urlJson};
      const semanticCandidate = ${payload};
      const graphBacked = !!(semanticCandidate && semanticCandidate._graphStructure && Array.isArray(semanticCandidate._graphStructure.sections) && semanticCandidate._graphStructure.sections.length);
      const exact = typeof AF.SiteLoader._getConfigForUrl === "function" ? AF.SiteLoader._getConfigForUrl(url) : null;
      if (exact && exact.preferAiStructure !== true) {
        return { installed: false, reason: "exact_mature_config_priority", baseSource: "exact" };
      }
      const detected = typeof AF.SiteLoader._detectSiteType === "function" ? AF.SiteLoader._detectSiteType() : null;
      const base = exact || detected || null;
      if (!base && !graphBacked) return { installed: false, reason: "no_mature_base_config" };

      let config = null;
      let baseSource = "graph_structure";
      if (base) {
        let cloned = null;
        try { cloned = JSON.parse(JSON.stringify(base)); } catch (_) { cloned = Object.assign({}, base); }
        config = Object.assign({}, cloned || {}, semanticCandidate || {});
        config.selectors = Object.assign({}, cloned && cloned.selectors || {}, semanticCandidate && semanticCandidate.selectors || {});
        config._aiSemanticPatch = Object.assign({}, cloned && cloned._aiSemanticPatch || {}, semanticCandidate && semanticCandidate._aiSemanticPatch || {});
        baseSource = exact ? "exact" : "dom_platform";
      } else {
        try { config = JSON.parse(JSON.stringify(semanticCandidate)); }
        catch (_) { config = Object.assign({}, semanticCandidate); }
        config.selectors = Object.assign({}, semanticCandidate && semanticCandidate.selectors || {});
      }

      const verifiedSemantic = String(semanticCandidate && semanticCandidate._serverStatus || "") === "verified";
      config._source = "ai_generated";
      config._serverStatus = verifiedSemantic ? "verified" : "candidate";
      config._manualCandidate = !verifiedSemantic;
      config._autoConfigStrategy = Object.assign({}, semanticCandidate && semanticCandidate._autoConfigStrategy || {}, {
        mode: graphBacked ? "graph_backed_structure_candidate_v1" : (verifiedSemantic ? "local_verified_semantic_candidate_v1" : "local_first_semantic_candidate_v2"),
        matureBaseSource: baseSource,
        matureBaseName: String(base && base.name || ""),
        graphBacked: graphBacked,
        requiresMatureBaseConfig: graphBacked ? false : true,
        aiAuthoredSelectors: false
      });

      if (graphBacked && typeof AF.SiteLoader.evaluateConfigCompatibility === "function") {
        const compatibility = AF.SiteLoader.evaluateConfigCompatibility(config);
        if (!compatibility || compatibility.compatible !== true) {
          return { installed: false, reason: "graph_structure_incompatible", compatibility: compatibility || null, baseSource };
        }
        config._compatibility = compatibility;
      }

      const host = String(location.hostname || "").toLowerCase();
      const installed = AF.SiteLoader.setPrefetchedConfig(host, config, url) === true;
      return {
        installed,
        reason: installed ? "installed" : "set_prefetched_rejected",
        baseSource,
        baseName: String(base && base.name || ""),
        graphBacked,
        graphSectionCount: Number(config._graphStructure && config._graphStructure.sections && config._graphStructure.sections.length || 0),
        fieldMappingCount: Number(config._aiSemanticPatch && config._aiSemanticPatch.fieldMappings && config._aiSemanticPatch.fieldMappings.length || 0),
        sectionMappingCount: Number(config._aiSemanticPatch && config._aiSemanticPatch.sectionMappings && config._aiSemanticPatch.sectionMappings.length || 0),
        serverStatus: config._serverStatus || "candidate"
      };
    } catch (e) {
      return { installed: false, reason: "candidate_install_error", error: String(e && e.message || e) };
    }
  })()`);
}

async function clearRuntimeSemanticOverlay(wc) {
  try {
    return await runIsolated(wc, `(() => { try { if (window.AF) delete window.AF.RuntimeSemanticPatch; return true; } catch (_) { return false; } })()`);
  } catch (_) { return false; }
}

async function installRuntimeSemanticOverlay(wc, rawUrl, overlay) {
  const fieldMappings = overlay && Array.isArray(overlay.fieldMappings) ? overlay.fieldMappings : [];
  const selectorMappings = overlay && Array.isArray(overlay.selectorMappings) ? overlay.selectorMappings : [];
  const recordSelectorMappings = overlay && Array.isArray(overlay.recordSelectorMappings) ? overlay.recordSelectorMappings : [];
  const valueCandidates = overlay && Array.isArray(overlay.valueCandidates) ? overlay.valueCandidates : [];
  if (!fieldMappings.length && !selectorMappings.length && !recordSelectorMappings.length && !valueCandidates.length) {
    await clearRuntimeSemanticOverlay(wc);
    return { installed: false, mappingCount: 0, labelMappingCount: 0, selectorMappingCount: 0, recordSelectorMappingCount: 0, valueCandidateCount: 0 };
  }
  const route = new URL(rawUrl);
  const payload = JSON.stringify({
    hostname: route.hostname.toLowerCase(),
    pathname: route.pathname || "/",
    observedFieldCount: Number(overlay && overlay.observedFieldCount || 0),
    fieldMappings: fieldMappings.map((item) => ({
      category: item.category,
      fieldKey: item.fieldKey,
      label: item.label,
      confidence: item.confidence,
      fieldId: item.fieldId
    })),
    selectorMappings: selectorMappings.map((item) => ({
      category: item.category,
      fieldKey: item.fieldKey,
      selector: item.selector,
      selectorMode: item.selectorMode || "unique",
      controlType: item.controlType || "text",
      confidence: item.confidence,
      fieldId: item.fieldId
    })),
    recordSelectorMappings: recordSelectorMappings.map((item) => ({
      category: item.category,
      fieldKey: item.fieldKey,
      selector: item.selector,
      selectorMode: item.selectorMode || "unique",
      controlType: item.controlType || "text",
      confidence: item.confidence,
      fieldId: item.fieldId,
      source: item.source || "local_structure_repeat_semantic"
    })),
    valueCandidates: valueCandidates.map((item) => ({
      category: item.category,
      fieldKey: item.fieldKey,
      value: item.value,
      mode: item.mode || "extract",
      confidence: item.confidence,
      fieldId: item.fieldId || "",
      source: item.source || "ai_value_candidate"
    }))
  });
  const result = await runIsolated(wc, `(() => {
    try {
      window.AF = window.AF || {};
      window.AF.RuntimeSemanticPatch = ${payload};
      const labelMappingCount = Array.isArray(window.AF.RuntimeSemanticPatch.fieldMappings) ? window.AF.RuntimeSemanticPatch.fieldMappings.length : 0;
      const selectorMappingCount = Array.isArray(window.AF.RuntimeSemanticPatch.selectorMappings) ? window.AF.RuntimeSemanticPatch.selectorMappings.length : 0;
      const recordSelectorMappingCount = Array.isArray(window.AF.RuntimeSemanticPatch.recordSelectorMappings) ? window.AF.RuntimeSemanticPatch.recordSelectorMappings.length : 0;
      const valueCandidateCount = Array.isArray(window.AF.RuntimeSemanticPatch.valueCandidates) ? window.AF.RuntimeSemanticPatch.valueCandidates.length : 0;
      return { installed: true, mappingCount: labelMappingCount + selectorMappingCount + recordSelectorMappingCount, labelMappingCount, selectorMappingCount, recordSelectorMappingCount, valueCandidateCount };
    } catch (e) { return { installed: false, mappingCount: 0, labelMappingCount: 0, selectorMappingCount: 0, recordSelectorMappingCount: 0, valueCandidateCount: 0, error: String(e && e.message || e) }; }
  })()`);
  return result && typeof result === "object" ? result : { installed: false, mappingCount: 0, labelMappingCount: 0, selectorMappingCount: 0 };
}


function mergeValueCandidatePatches(localPatch, apiPatch) {
  const rows = [];
  const seen = new Set();
  for (const patch of [localPatch, apiPatch]) {
    for (const row of Array.isArray(patch && patch.decisions) ? patch.decisions : []) {
      const id = String(row && row.candidateId || "");
      if (!id || seen.has(id)) continue;
      seen.add(id);
      rows.push(row);
    }
  }
  return { schemaType: "autofill-lite-ai-value-candidate-patch", schemaVersion: 1, decisions: rows };
}

async function buildValueCandidatesForSemanticPatch(rawUrl, settings, apiKey, review, semanticPatch, semanticGate) {
  let profile = null;
  try { profile = loadProfile(PROFILE_FILE); } catch (_) { profile = null; }
  if (!profile) return { available: false, reason: "profile_unavailable" };
  const valueReview = buildValueReview(review, semanticPatch, profile, { maxTargets: 24, maxRepeatRecordsPerField: 4 });
  const localPatch = buildLocalValueCandidatePatch(valueReview);
  const locallyResolved = new Set((localPatch.decisions || []).map((x) => String(x.candidateId || "")));
  const unresolvedTargets = (valueReview.targets || []).filter((x) => !locallyResolved.has(String(x.candidateId || "")));
  let apiPatch = { schemaType: "autofill-lite-ai-value-candidate-patch", schemaVersion: 1, decisions: [] };
  let apiAttempted = false;
  let apiError = "";
  let usage = { inputTokens: 0, outputTokens: 0, totalTokens: 0 };
  let tokenBudget = 0;
  let retryAttempted = false;

  if (apiKey && unresolvedTargets.length) {
    const apiTargets = unresolvedTargets.filter((target) => !target.repeatRecord && !HIGH_RISK_VALUE_KEYS.has(String(target.fieldKey || "")));
    const apiReview = Object.assign({}, valueReview, { targets: apiTargets });
    if (apiTargets.length) {
      tokenBudget = valueTokenBudget(apiReview, settings);
      apiAttempted = true;
    try {
      let response = await requestJsonViaElectron(settings.endpoint, apiKey, buildValueCandidateRequest(settings, apiReview, "schema", { maxOutputTokens: tokenBudget }), 90000);
      let parsed = null;
      try {
        parsed = validateValueCandidatePatch(apiReview, parseProviderResponse(settings.provider, response.body));
      } catch (firstError) {
        retryAttempted = true;
        response = await requestJsonViaElectron(settings.endpoint, apiKey, buildValueCandidateRequest(settings, apiReview, "json_object", { maxOutputTokens: tokenBudget }), 90000);
        parsed = validateValueCandidatePatch(apiReview, parseProviderResponse(settings.provider, response.body));
      }
      apiPatch = parsed;
      usage = usageFromResponse(settings.provider, response.body);
      } catch (error) {
        apiError = String(error && error.message || error).slice(0, 800);
      }
    }
  }

  const combinedPatch = mergeValueCandidatePatches(localPatch, apiPatch);
  const gate = classifyValueCandidates(valueReview, combinedPatch, semanticGate);
  const artifact = writeValueCandidateArtifact(rawUrl, valueReview, combinedPatch, gate, {
    provider: apiAttempted ? settings.provider : "local-fallback",
    model: apiAttempted ? settings.model : "none",
    tokenBudget,
    usage,
    apiAttempted,
    apiError
  });
  return {
    available: true,
    file: artifact.file,
    fileName: path.basename(artifact.file),
    reviewTargetCount: Number((valueReview.targets || []).length),
    localCandidateCount: Number((localPatch.decisions || []).length),
    apiCandidateCount: Number((apiPatch.decisions || []).filter((x) => x && x.decision === "candidate").length),
    unresolvedTargetCount: unresolvedTargets.length,
    gate,
    usage,
    tokenBudget,
    apiAttempted,
    apiError,
    retryAttempted
  };
}

async function runAiMappingInternal(wc, rawUrl) {
  if (!/^https?:\/\//i.test(rawUrl || "")) throw new Error("请先打开招聘网页");
  const reviewFile = aiReviewFileForUrl(rawUrl);
  if (!fs.existsSync(reviewFile)) throw new Error("当前页面还没有 AI review，请先点击“分析本站”");
  const review = validateReview(readJsonFile(reviewFile));
  const aiNeeded = Number(review && review.mappingSummary && review.mappingSummary.aiMappingNeededFieldCount || review.reviewFields.length || 0);
  const settings = aiSettingsStore.getPublicSettings();
  const apiKey = aiSettingsStore.getApiKey();
  const startedAt = Date.now();
  const errorFile = aiErrorFileForUrl(rawUrl);
  const endpointHost = (() => { try { return new URL(settings.endpoint).host; } catch (_) { return ""; } })();
  const semanticBudget = aiNeeded > 0 ? semanticTokenBudget(review, settings) : 0;

  let provider = "local-core";
  let model = "none";
  let response = null;
  let retryResponse = null;
  let retryAttempted = false;
  let apiAttempted = false;
  let apiFallbackReason = "";
  let usage = { inputTokens: 0, outputTokens: 0, totalTokens: 0 };
  let validated = null;

  if (aiNeeded <= 0) {
    validated = { schemaType: "autofill-lite-ai-semantic-patch", schemaVersion: 1, decisions: [] };
  } else if (!apiKey) {
    provider = "local-fallback";
    validated = validateSemanticPatch(review, buildLocalSemanticFallbackPatch(review, { minCandidateConfidence: 0.50 }));
    apiFallbackReason = "no_api_key";
  } else {
    provider = settings.provider;
    model = settings.model;
    apiAttempted = true;
    let stage = "request";
    try {
      const payload = buildProviderRequest(settings, review, { maxOutputTokens: semanticBudget });
      response = await requestJsonViaElectron(settings.endpoint, apiKey, payload, 90000);
      stage = "parse";
      try {
        validated = validateSemanticPatch(review, parseProviderResponse(settings.provider, response.body));
      } catch (firstError) {
        retryAttempted = true;
        stage = "retry_request";
        const retryPayload = buildProviderRetryRequest(settings, review, { maxOutputTokens: semanticBudget });
        retryResponse = await requestJsonViaElectron(settings.endpoint, apiKey, retryPayload, 90000);
        stage = "retry_parse";
        validated = validateSemanticPatch(review, parseProviderResponse(settings.provider, retryResponse.body));
      }
      usage = usageFromResponse(settings.provider, retryResponse ? retryResponse.body : response.body);
      try { if (fs.existsSync(errorFile)) fs.unlinkSync(errorFile); } catch (_) {}
    } catch (error) {
      // Build159: an expired quota, unavailable model, network outage, or malformed
      // model output must not disable the assistant. Fall back to deterministic local
      // semantic hints and keep Autofill Core usable without spending more tokens.
      apiFallbackReason = String(error && error.message || error).slice(0, 800);
      provider = "local-fallback";
      model = "none";
      validated = validateSemanticPatch(review, buildLocalSemanticFallbackPatch(review, { minCandidateConfidence: 0.50 }));
      const failure = {
        schemaType: "autofill-lite-ai-mapping-error",
        schemaVersion: 1,
        at: new Date().toISOString(),
        buildId: BUILD_ID,
        page: { hostname: safeAnalysisHost(rawUrl), pathname: (() => { try { return new URL(rawUrl).pathname || "/"; } catch (_) { return "/"; } })() },
        provider: settings.provider,
        model: settings.model,
        endpointHost,
        reviewFile: path.basename(reviewFile),
        stage,
        retryAttempted,
        fallbackApplied: true,
        error: apiFallbackReason,
        firstResponse: response ? { statusCode: response.statusCode, debug: responseDebugSummary(settings.provider, response.body) } : null,
        retryResponse: retryResponse ? { statusCode: retryResponse.statusCode, debug: responseDebugSummary(settings.provider, retryResponse.body) } : null
      };
      try { fs.writeFileSync(errorFile, JSON.stringify(failure, null, 2), "utf8"); } catch (_) {}
    }
  }

  const summary = summarizePatch(validated);
  const finalPatch = Object.assign({}, validated, {
    generatedAt: new Date().toISOString(),
    page: review.page || {},
    sourceReviewFile: path.basename(reviewFile),
    provider,
    model,
    endpointHost: provider === "local-fallback" || provider === "local-core" ? "" : endpointHost,
    apiAttempted,
    apiFallbackReason,
    retryAttempted,
    semanticTokenBudget: semanticBudget,
    usage,
    summary,
    durationMs: Date.now() - startedAt,
    safety: {
      resumeValuesIncludedInSemanticPhase: false,
      selectorsModified: false,
      javascriptGenerated: false,
      pageActionsExecuted: false,
      semanticPatchAppliedToAutofill: false,
      localFallbackAvailableWithoutApi: true
    }
  });
  const patchFile = aiPatchFileForUrl(rawUrl);
  fs.writeFileSync(patchFile, JSON.stringify(finalPatch, null, 2), "utf8");
  const candidate = writeAiCandidateOverlay(rawUrl, review, finalPatch);
  const matchedWorkflowId = await detectMatchedWorkflowIdForAiGate(wc, rawUrl);
  const safetyGate = compileAiCandidateSafetyGate(review, finalPatch, { matchedWorkflowId, localSupport: !!matchedWorkflowId });

  // AI-2: local deterministic extraction/normalization always runs. The API value
  // phase is optional and only receives selected non-sensitive source facts. If the
  // semantic API fell back because quota/network failed, do not immediately spend a
  // second request; keep the local value resolver path only.
  const valueResult = await buildValueCandidatesForSemanticPatch(
    rawUrl,
    settings,
    provider === settings.provider ? apiKey : "",
    review,
    finalPatch,
    safetyGate
  );

  appendDiagnostic({
    at: new Date().toISOString(),
    type: "ai-semantic-mapping",
    buildId: BUILD_ID,
    url: safeUrl(rawUrl),
    provider,
    model,
    apiAttempted,
    apiFallbackReason,
    endpointHost: provider === settings.provider ? endpointHost : "",
    reviewFile: path.basename(reviewFile),
    patchFile: path.basename(patchFile),
    candidateFile: path.basename(candidate.file),
    retryAttempted,
    semanticTokenBudget: semanticBudget,
    summary,
    candidateSummary: candidate.overlay.summary,
    safetyGateSummary: safetyGate && safetyGate.summary || {},
    valueCandidateSummary: valueResult && valueResult.gate && valueResult.gate.summary || {},
    valueCandidateFile: valueResult && valueResult.fileName || "",
    valueTokenBudget: Number(valueResult && valueResult.tokenBudget || 0),
    valueApiAttempted: !!(valueResult && valueResult.apiAttempted),
    valueApiError: String(valueResult && valueResult.apiError || ""),
    usage,
    valueUsage: valueResult && valueResult.usage || { inputTokens: 0, outputTokens: 0, totalTokens: 0 },
    durationMs: finalPatch.durationMs,
    safety: finalPatch.safety
  });

  return {
    success: true,
    skipped: aiNeeded <= 0,
    reason: aiNeeded <= 0 ? "local_mapping_complete" : (provider === "local-fallback" ? "local_fallback_used" : "ai_candidate_generated"),
    message: aiNeeded <= 0
      ? "本地可信映射已覆盖全部字段，无需调用 AI。"
      : provider === "local-fallback"
        ? "AI API 不可用或未配置，已自动使用本地语义候选与本地值归一化；Autofill Core 仍可继续工作。"
        : "AI 语义候选已生成；安全候选将在后续一键填写中经 Core/Checkpoint 受控使用。",
    patchFile,
    patchFileName: path.basename(patchFile),
    candidateFile: candidate.file,
    candidateFileName: path.basename(candidate.file),
    candidateSummary: candidate.overlay.summary,
    siteCandidateFile: candidate.siteCandidateFile,
    siteCandidateFileName: path.basename(candidate.siteCandidateFile),
    siteCandidateSummary: candidate.siteCandidate && candidate.siteCandidate.summary || {},
    provider,
    model,
    apiAttempted,
    apiFallbackReason,
    retryAttempted,
    semanticTokenBudget: semanticBudget,
    summary,
    usage,
    durationMs: finalPatch.durationMs,
    safetyGate,
    valueCandidates: valueResult,
    semanticPatchAppliedToAutofill: false
  };
}

ipcMain.handle("lite:run-ai-mapping", async (_event, guestId) => {
  const wc = getGuest(guestId);
  return runAiMappingInternal(wc, wc.getURL());
});

ipcMain.handle("lite:verify-site-candidate", async (_event, guestId) => {
  const wc = getGuest(guestId);
  const rawUrl = wc.getURL();
  if (!/^https?:\/\//i.test(rawUrl || "")) throw new Error("请先打开招聘网页");
  return verifySemanticSiteCandidate(rawUrl);
});

ipcMain.handle("lite:stop-autofill", async (_event, guestId) => {
  const wc = getGuest(guestId);
  if (!(await coreReady(wc))) return { success: false, error: "CORE_NOT_READY" };
  return runIsolated(wc, `window.OfferAutofill.stop()`);
});

ipcMain.handle("lite:get-progress", async (_event, guestId) => {
  try {
    const wc = getGuest(guestId);
    if (!(await coreReady(wc))) return null;
    return await runIsolated(wc, `window.__OFFER_AUTOFILL_PROGRESS__ || null`);
  } catch (_) {
    return null;
  }
});


let mainWindow = null;
let bookmarkWindow = null;
let profileQuickWindow = null;
let bookmarkPrefill = { name: "", url: "" };

function bookmarkSnapshot() {
  const library = readBookmarkLibrary();
  return { library, folders: folderOptions(library), file: BOOKMARK_FILE };
}

ipcMain.handle("lite:get-bookmark-library", async () => bookmarkSnapshot());

ipcMain.handle("lite:get-bookmark-prefill", async () => bookmarkPrefill);

ipcMain.handle("lite:add-bookmark-folder", async (_event, payload) => {
  const current = readBookmarkLibrary();
  const result = addFolder(current, payload && payload.parentId || ROOT_ID, payload && payload.name);
  writeBookmarkLibrary(result.library);
  return bookmarkSnapshot();
});

ipcMain.handle("lite:add-bookmark", async (_event, payload) => {
  const current = readBookmarkLibrary();
  const result = addBookmark(current, payload && payload.parentId || ROOT_ID, {
    name: payload && payload.name,
    url: payload && payload.url,
    status: payload && payload.status
  });
  writeBookmarkLibrary(result.library);
  return bookmarkSnapshot();
});

ipcMain.handle("lite:update-bookmark-node", async (_event, payload) => {
  const current = readBookmarkLibrary();
  const result = updateNode(current, payload && payload.id, payload && payload.patch || {});
  writeBookmarkLibrary(result.library);
  return bookmarkSnapshot();
});

ipcMain.handle("lite:move-bookmark-node", async (_event, payload) => {
  const current = readBookmarkLibrary();
  const result = moveNode(current, payload && payload.id, payload && payload.targetFolderId || ROOT_ID);
  writeBookmarkLibrary(result.library);
  return bookmarkSnapshot();
});

ipcMain.handle("lite:delete-bookmark-node", async (_event, payload) => {
  const current = readBookmarkLibrary();
  const result = deleteNode(current, payload && payload.id);
  writeBookmarkLibrary(result.library);
  return bookmarkSnapshot();
});

ipcMain.handle("lite:search-bookmarks", async (_event, query) => {
  return searchBookmarks(readBookmarkLibrary(), query).slice(0, 200);
});

ipcMain.handle("lite:open-bookmark-manager", async (_event, payload) => {
  bookmarkPrefill = sanitizeBookmarkPrefill(payload);
  if (bookmarkWindow && !bookmarkWindow.isDestroyed()) {
    bookmarkWindow.show();
    bookmarkWindow.focus();
    bookmarkWindow.webContents.send("lite:bookmark-prefill", bookmarkPrefill);
    return true;
  }
  bookmarkWindow = new BrowserWindow({
    width: 1080,
    height: 760,
    minWidth: 820,
    minHeight: 560,
    title: "Autofill Lite 岗位库 · " + BUILD_ID,
    icon: path.join(APP_ROOT, "assets", "tuxedo-cat.ico"),
    webPreferences: { preload: path.join(APP_ROOT, "ui-preload.js"), contextIsolation: true, nodeIntegration: false, sandbox: false }
  });
  bookmarkWindow.on("closed", () => { bookmarkWindow = null; });
  await bookmarkWindow.loadFile(path.join(APP_ROOT, "bookmarks.html"));
  return true;
});

const forcedGuestNavigation = new Map();

ipcMain.handle("lite:navigate-guest", async (_event, guestId, rawUrl) => {
  const url = cleanUrl(rawUrl);
  const wc = getGuest(guestId);
  const token = Date.now();
  forcedGuestNavigation.set(wc.id, token);
  try { wc.stop(); } catch (_) {}
  // Do not await loadURL here. Explicit user navigation must not be serialized behind
  // the current site's unload work / autofill observers. The navigation lifecycle will
  // report success/failure through the webview events as before.
  setTimeout(() => {
    try {
      const pending = wc.loadURL(url);
      if (pending && typeof pending.catch === "function") pending.catch(() => {});
    } catch (_) {}
  }, 0);
  setTimeout(() => {
    if (forcedGuestNavigation.get(wc.id) === token) forcedGuestNavigation.delete(wc.id);
  }, 5000);
  return { started: true, url };
});

ipcMain.handle("lite:open-bookmark-url", async (_event, rawUrl) => {
  const url = cleanUrl(rawUrl);
  if (!mainWindow || mainWindow.isDestroyed()) throw new Error("主窗口不可用");
  mainWindow.webContents.send("lite:navigate", url);
  mainWindow.show();
  mainWindow.focus();
  return true;
});

ipcMain.handle("lite:get-profile-summary", async () => {
  const data = loadProfile(PROFILE_FILE);
  return Object.assign({ profileFile: PROFILE_FILE }, summarizeResumeData(data));
});

ipcMain.handle("lite:get-profile-raw", async () => readRawProfile());

ipcMain.handle("lite:save-profile-raw", async (_event, payload) => {
  const result = writeRawProfile(payload);
  const profileUpdatedPayload = { updatedAt: result && result.updatedAt || "", profileHash: result && result.profileHash || "" };
  if (profileQuickWindow && !profileQuickWindow.isDestroyed()) {
    try { profileQuickWindow.webContents.send("lite:profile-updated", profileUpdatedPayload); } catch (_) {}
  }
  if (mainWindow && !mainWindow.isDestroyed()) {
    try { mainWindow.webContents.send("lite:profile-updated", profileUpdatedPayload); } catch (_) {}
  }
  return result;
});

ipcMain.handle("lite:copy-text", async (_event, value) => {
  const text = String(value == null ? "" : value);
  clipboard.writeText(text);
  return { copied: true, length: text.length };
});

function preferredProfileQuickBounds() {
  const width = 430;
  const height = 820;
  if (!mainWindow || mainWindow.isDestroyed()) return { width, height };
  try {
    const mainBounds = mainWindow.getBounds();
    const display = screen.getDisplayMatching(mainBounds);
    const work = display && display.workArea ? display.workArea : null;
    if (!work) return { width, height };
    const gap = 10;
    const h = Math.max(520, Math.min(height, work.height - 20));
    let x;
    const rightX = mainBounds.x + mainBounds.width + gap;
    const leftX = mainBounds.x - width - gap;
    if (rightX + width <= work.x + work.width) x = rightX;
    else if (leftX >= work.x) x = leftX;
    else x = Math.max(work.x, work.x + work.width - width - 8);
    const y = Math.max(work.y, Math.min(mainBounds.y, work.y + work.height - h));
    return { x, y, width, height: h };
  } catch (_) {
    return { width, height };
  }
}

ipcMain.handle("lite:open-profile-quick", async () => {
  if (profileQuickWindow && !profileQuickWindow.isDestroyed()) {
    profileQuickWindow.showInactive();
    try { profileQuickWindow.webContents.send("lite:profile-updated", { reason: "reopen" }); } catch (_) {}
    return true;
  }
  const bounds = preferredProfileQuickBounds();
  profileQuickWindow = new BrowserWindow({
    ...bounds,
    minWidth: 340,
    minHeight: 520,
    maxWidth: 720,
    maximizable: false,
    modal: false,
    alwaysOnTop: false,
    title: "Autofill Lite 简历速查 · " + BUILD_ID,
    icon: path.join(APP_ROOT, "assets", "tuxedo-cat.ico"),
    backgroundColor: "#f5f7fb",
    webPreferences: { preload: path.join(APP_ROOT, "ui-preload.js"), contextIsolation: true, nodeIntegration: false, sandbox: false }
  });
  profileQuickWindow.on("closed", () => { profileQuickWindow = null; });
  await profileQuickWindow.loadFile(path.join(APP_ROOT, "profile-quick.html"));
  profileQuickWindow.showInactive();
  return true;
});

ipcMain.handle("lite:open-profile-editor", async () => {
  const win = new BrowserWindow({
    width: 1180,
    height: 820,
    minWidth: 900,
    minHeight: 620,
    title: "Autofill Lite 资料库 · " + BUILD_ID,
    icon: path.join(APP_ROOT, "assets", "tuxedo-cat.ico"),
    webPreferences: { preload: path.join(APP_ROOT, "ui-preload.js"), contextIsolation: true, nodeIntegration: false, sandbox: false }
  });
  await win.loadFile(path.join(APP_ROOT, "profile-editor.html"));
  return true;
});

ipcMain.handle("lite:get-build-info", async () => ({
  version: "0.1.7",
  buildId: BUILD_ID,
  buildShort: BUILD_SHORT,
}));

ipcMain.handle("lite:open-data-dir", async () => {
  await shell.openPath(DATA_DIR);
  return DATA_DIR;
});

ipcMain.handle("lite:save-diagnostic", async (_event, payload) => {
  return appendDiagnostic({ at: new Date().toISOString(), type: "manual", payload: payload || null });
});

function createWindow() {
  const win = new BrowserWindow({
    width: 1500,
    height: 980,
    minWidth: 1000,
    minHeight: 680,
    title: "Autofill Lite · v0.1.7 · 测试版 · build " + BUILD_SHORT,
    icon: path.join(APP_ROOT, "assets", "tuxedo-cat.ico"),
    webPreferences: {
      preload: path.join(APP_ROOT, "ui-preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      webviewTag: true
    }
  });
  mainWindow = win;
  win.on("closed", () => { if (mainWindow === win) mainWindow = null; });
  win.loadFile(path.join(APP_ROOT, "index.html"));
}

app.on("web-contents-created", (_event, contents) => {
  if (contents.getType && contents.getType() === "webview") {
    contents.setWindowOpenHandler(({ url }) => {
      if (/^https?:\/\//i.test(url)) setTimeout(() => contents.loadURL(url), 0);
      return { action: "deny" };
    });
    contents.on("will-prevent-unload", (event) => {
      // Only bypass a site's beforeunload guard for a navigation explicitly requested
      // from Autofill Lite's address bar / job library. This restores browser-like
      // switching without globally disabling unload protection.
      if (forcedGuestNavigation.has(contents.id)) event.preventDefault();
    });
    contents.on("did-start-navigation", (_event, _url, _isInPlace, isMainFrame) => {
      if (isMainFrame) forcedGuestNavigation.delete(contents.id);
    });
    contents.on("destroyed", () => { injectedDocuments.delete(contents.id); forcedGuestNavigation.delete(contents.id); });
  }
});

app.whenReady().then(() => {
  createWindow();
});

app.on("window-all-closed", () => {
  app.quit();
});
