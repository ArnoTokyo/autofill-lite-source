"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");

// The mature product already carries platform/site knowledge for both real-site
// acceptance pages used in Build96. Keep those assets authoritative.
const templates = fs.readFileSync(path.join(root, "autofill-plugin", "content", "config", "site-templates.js"), "utf8");
const experience = fs.readFileSync(path.join(root, "autofill-plugin", "content", "experience-handler.js"), "utf8");
assert(templates.includes('name: "beisen-phoenix"'), "mature Beisen Phoenix platform config missing");
assert(templates.includes('.form-item__text'), "mature Phoenix label selector missing");
assert(templates.includes('.sc-khQegj, .ux-standard-form'), "mature Phoenix card selectors missing");
assert(templates.includes('"xiaoyuan.zhaopin.com": zhaopinCampusConfig'), "mature Zhaopin campus config missing");
assert(templates.includes('.apply-module'), "mature Zhaopin module selector missing");
assert(templates.includes('.icon-box:not(.icon-box-disabled)'), "mature Zhaopin edit selector missing");
assert(experience.includes('function findPhoenixSectionContainer'), "mature Phoenix section recovery missing");
assert(experience.includes('.form-item__text, .phoenix-select, .phoenix-radio-group, .ux-standard-form'), "mature Phoenix semantic container evidence missing");

// FormGraph must consume SiteLoader's mature assets rather than implementing a
// separate platform detector.
global.location = { href: "https://cmsk1979.zhiye.com/form", hostname: "cmsk1979.zhiye.com", pathname: "/form" };
global.AF = {
  SiteLoader: {
    _getConfigForUrl: () => null,
    _detectSiteType: () => ({
      name: "beisen-phoenix",
      selectors: {
        container: { class: ".sc-iAKWXU, .sc-cTAqQK" },
        title: { class: ".sc-efQSVx, .sc-jObWnj" },
        labels: { class: ".form-item__text" }
      },
      experience: { container: { containerSelector: ".sc-cTAqQK" } }
    })
  }
};
const graphPath = path.join(root, "autofill-plugin", "content", "form-graph.js");
delete require.cache[require.resolve(graphPath)];
const graph = require(graphPath);
const hints = graph.__test.resolveStructureHints();
assert.strictEqual(hints.source, "dom_platform");
assert.strictEqual(hints.configName, "beisen-phoenix");
assert(hints.sectionSelectors.includes(".sc-cTAqQK"));
assert(hints.rowSelectors.includes(".form-item"));
assert(hints.labelSelectors.includes(".form-item__text"));

// Analyzer should translate the mature Zhaopin config into a safe EDIT-only probe.
global.window = { AF: {} };
global.document = { body: null };
global.location = { href: "https://xiaoyuan.zhaopin.com/scrd/resume2", hostname: "xiaoyuan.zhaopin.com", pathname: "/scrd/resume2" };
const collectorPath = path.join(root, "autofill-plugin", "content", "site-analysis-collector.js");
delete require.cache[require.resolve(collectorPath)];
require(collectorPath);
const collector = global.window.AF.SiteAnalysisCollector;
const builtIn = {
  name: "xiaoyuan.zhaopin.com/scrd/resume2",
  selectors: {
    container: { class: ".apply-module" },
    title: { class: ".form-content--title" }
  },
  experience: {
    editor: {
      cardEditButtonSelector: ".icon-box:not(.icon-box-disabled)",
      cardEditButtonText: ["编辑", "修改"]
    }
  }
};
const closed = collector.buildMatureInteractiveProbeOptions(builtIn, null, 0);
assert.strictEqual(closed.source, "built_in_config");
assert.strictEqual(closed.options.moduleSelector, ".apply-module");
assert.strictEqual(closed.options.titleSelector, ".form-content--title");
assert.strictEqual(closed.options.allowSingleModule, true);
assert.strictEqual(closed.options.allowAddProbe, false);
assert(closed.options.openAction.selectors.includes(".icon-box:not(.icon-box-disabled)"));
const open = collector.buildMatureInteractiveProbeOptions(builtIn, null, 5);
assert.strictEqual(open.options.allowSingleModule, false, "visible editable form must remain static-first");

// When the generic mature InteractiveFormRuntime does not discover a closed
// module, Analyzer may still consume the exact mature config directly. This is
// the same second-line philosophy used by mature FillEngine's module-dialog path.
const visibleRect = () => ({ width: 100, height: 30, left: 0, top: 0 });
const edit = {
  isConnected: true,
  textContent: "",
  innerText: "",
  getBoundingClientRect: visibleRect,
  getAttribute: () => "",
  matches: (selector) => selector === ".icon-box:not(.icon-box-disabled)"
};
const title = { textContent: "高等教育经历", isConnected: true, getBoundingClientRect: visibleRect };
const moduleEl = {
  isConnected: true,
  getBoundingClientRect: visibleRect,
  querySelector: (selector) => {
    if (selector === ".form-content--title") return title;
    if (selector.includes(".apply-form .icon-box")) return edit;
    return null;
  },
  querySelectorAll: (selector) => {
    if (selector === ".icon-box:not(.icon-box-disabled)") return [edit];
    return [];
  }
};
global.window.getComputedStyle = () => ({ display: "block", visibility: "visible", opacity: "1" });
global.document.querySelectorAll = (selector) => selector === ".apply-module" ? [moduleEl] : [];
const direct = collector.discoverModulesFromMatureConfig(closed.options);
assert.strictEqual(direct.length, 1, "exact mature config should recover a closed module when generic discovery misses it");
assert.strictEqual(direct[0].action.type, "edit");
assert.strictEqual(direct[0].title, "高等教育经历");

console.log("mature assets first analysis: PASS");
