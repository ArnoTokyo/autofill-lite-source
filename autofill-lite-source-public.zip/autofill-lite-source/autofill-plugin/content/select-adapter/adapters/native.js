// content/select-adapter/adapters/native.js — 原生 <select> 适配器
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   NativeSelectAdapter (混淆名 v, 模块2914):  行 5948-6763
//   triggerNativeSelect (混淆名 d/y, 模块2914): 行 6560-6698
//
// 算法 (逐行对应源码 y() 函数):
//   1. focus + 派发 focus/mousedown 事件
//   2. 遍历 <option>，用 isOptionMatch(text, text, value) 模糊匹配 -> 命中则设值
//   3. 若第2步没命中，退化为大小写不敏感的双向 includes 匹配
//   4. 若还没命中，尝试把 value 当数字下标 (parseInt) 直接设 selectedIndex
//   5. 全部失败则 blur 并返回 false
//   命中后统一派发 input/change/click/blur 事件序列。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};
  var H = SA._helpers;

  function fireOptionChosen(selectEl) {
    selectEl.dispatchEvent(new Event("input", { bubbles: true }));
    selectEl.dispatchEvent(new Event("change", { bubbles: true }));
    selectEl.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    selectEl.blur();
    selectEl.dispatchEvent(new Event("blur", { bubbles: true }));
  }

  async function setNativeSelectValue(selectEl, rawValue) {
    try {
      if (!selectEl || selectEl.tagName !== "SELECT") return false;
      var target = Array.isArray(rawValue) ? rawValue[0] : rawValue;
      if (target === undefined || target === null || target === "") return false;
      var targetStr = String(target);

      var options = Array.prototype.slice.call(selectEl.options);
      var strictLocation = SA._currentCapability &&
        String(SA._currentCapability.matchMode || "") === "exactOrContains";
      selectEl.focus();
      selectEl.dispatchEvent(new Event("focus", { bubbles: true }));
      selectEl.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));

      // 第1轮: isOptionMatch 模糊匹配 (含学历特判)
      for (var i = 0; i < options.length; i++) {
        var text = options[i].text.trim();
        if (
          text === targetStr ||
          (!strictLocation && H.isOptionMatch(text, text, targetStr))
        ) {
          selectEl.value = options[i].value;
          fireOptionChosen(selectEl);
          return true;
        }
      }

      // 第2轮: 双向 includes (大小写不敏感)
      var targetLower = targetStr.toLowerCase();
      for (var j = 0; j < options.length; j++) {
        var optText = options[j].text.toLowerCase();
        if (
          optText === targetLower ||
          (!strictLocation && (optText.includes(targetLower) || targetLower.includes(optText)))
        ) {
          selectEl.value = options[j].value;
          fireOptionChosen(selectEl);
          return true;
        }
      }

      // 严格地址选择没有精确项时直接失败，禁止把数字或相似项当作省份。
      if (strictLocation) {
        selectEl.blur();
        selectEl.dispatchEvent(new Event("blur", { bubbles: true }));
        return false;
      }

      // 学制数字不能解释成 option 下标；例如目标“4”表示四年制，不是第5个选项。
      if (AF.DomUtils.parseStudyYears && AF.DomUtils.parseStudyYears(targetStr) !== null) {
        selectEl.blur();
        selectEl.dispatchEvent(new Event("blur", { bubbles: true }));
        return false;
      }

      // 第3轮: 数字下标兜底
      var idx = parseInt(targetStr, 10);
      if (!isNaN(idx) && idx >= 0 && idx < options.length) {
        selectEl.selectedIndex = idx;
        fireOptionChosen(selectEl);
        return true;
      }

      selectEl.blur();
      selectEl.dispatchEvent(new Event("blur", { bubbles: true }));
      return false;
    } catch (e) {
      try {
        selectEl.blur();
        selectEl.dispatchEvent(new Event("blur", { bubbles: true }));
      } catch (e2) {}
      return false;
    }
  }

  SA._registry["native"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        return await setNativeSelectValue(element, value);
      },
    };
  };

  // 供 index.js 的兜底逻辑复用
  SA._setNativeSelectValue = setNativeSelectValue;
})();
