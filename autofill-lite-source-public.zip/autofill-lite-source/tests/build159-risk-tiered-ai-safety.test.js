"use strict";
const assert = require("assert");
const { compileAiCandidateSafetyGate } = require("../ai-candidate-safety-gate");

const review = {
  trustedMappings: [],
  reviewFields: [
    { fieldId: "low", label: "期望岗位", labelSource: "label", graphLinkConfidence: 0.2, controlType: "text", patchTarget: { kind: "semantic_label", label: "期望岗位" } },
    { fieldId: "evidence", label: "研究方向", labelSource: "label", graphLinkConfidence: 0.95, suggestedCoreFieldKey: "researchDirection", suggestedCoreMappingConfidence: 0.81, controlType: "text", patchTarget: { kind: "semantic_label", label: "研究方向" } },
    { fieldId: "reject", label: "其他信息", labelSource: "nearby_text", controlType: "text", patchTarget: { kind: "semantic_label", label: "其他信息" } },
    { fieldId: "risk", label: "政治面貌", labelSource: "label", graphLinkConfidence: 0.98, controlType: "select", patchTarget: { kind: "semantic_label", label: "政治面貌" } },
    { fieldId: "repeat", label: "毕业院校", labelSource: "label", graphLinkConfidence: 0.98, controlType: "search", patchTarget: { kind: "semantic_label", label: "毕业院校" } }
  ]
};
const patch = { decisions: [
  { fieldId: "low", decision: "map", category: "jobIntention", fieldKey: "expectedPosition", confidence: 0.65 },
  { fieldId: "evidence", decision: "map", category: "basicInfo", fieldKey: "researchDirection", confidence: 0.52 },
  { fieldId: "reject", decision: "map", category: "basicInfo", fieldKey: "otherInfo", confidence: 0.49 },
  { fieldId: "risk", decision: "map", category: "basicInfo", fieldKey: "politicalStatus", confidence: 0.84 },
  { fieldId: "repeat", decision: "map", category: "education", fieldKey: "school", confidence: 0.99 }
] };

const gate = compileAiCandidateSafetyGate(review, patch, {});
assert.strictEqual(gate.thresholds.review, 0.50);
assert.strictEqual(gate.thresholds.autoEligible, 0.65);
assert.strictEqual(gate.thresholds.sensitiveAuto, 0.85);
assert.ok(gate.executableCandidates.some(x => x.fieldId === "low"), "0.65 low-risk scalar should enter Core");
assert.ok(gate.executableCandidates.some(x => x.fieldId === "evidence" && x.reasons.includes("passed_by_strong_local_semantic_evidence")), "0.50+ strong local evidence should be eligible");
assert.ok(gate.rejectedCandidates.some(x => x.fieldId === "reject" && x.reasons.includes("confidence_below_review_threshold")), "below 0.50 must reject");
assert.ok(gate.reviewOnlyCandidates.some(x => x.fieldId === "risk" && x.reasons.includes("confidence_below_sensitive_auto_threshold")), "high-risk scalar under 0.85 must remain review-only");
assert.ok(gate.reviewOnlyCandidates.some(x => x.fieldId === "repeat" && x.reasons.includes("repeat_record_requires_recordgraph_ownership")), "AI must never choose RepeatRecord owner");
assert.strictEqual(gate.policy.directSaveSubmitApplyDeleteUploadAllowed, false);
assert.strictEqual(gate.policy.aiMayChooseRepeatRecordOwner, false);
console.log("build159-risk-tiered-ai-safety.test.js PASS");
