// content/clean-html.js — HTML 清洗，供 AI 站点配置生成 (Phase 8) 使用
// 源码参考: webcrack-output/content/deobfuscated.js 行69391 cleanHtml()
// 直接采用已实测验证过的版本 (来自 /Users/dayu/Desktop/autofill/autofill-test-extension/content/cleanHtml.js，
// 该版本在真实招聘网站上跑通并把 AI 配置生成覆盖率从 43% 调优到 98%，比主 bundle 里的早期版本更可靠)。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});

  var PROTECTED_SELECTORS = [
    "ant-select", "ant-radio-group", "ant-checkbox-group", "ant-calendar-picker",
    "ant-cascader-picker", "ant-upload", "ant-tree-select", "el-select", "el-radio-group",
    "el-checkbox-group", "el-date-editor", "el-cascader", "el-upload", "cascader-plugins-wrap",
    "uploadFileBtn", "signature", "canvas", "input", "select", "textarea", "button",
  ];

  function normalizeSensitiveText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function shouldTreatAsUserValue(text) {
    text = normalizeSensitiveText(text);
    if (!text || text.length < 2 || text.length > 120) return false;
    if (/^(请选择|请输入|请上传|上传|添加|新增|编辑|删除|保存|确定|取消|男|女|是|否|无|有)$/.test(text)) return false;
    return true;
  }

  function collectExistingUserValues(rootElement) {
    var values = [];
    var seen = {};
    function add(text) {
      text = normalizeSensitiveText(text);
      if (!shouldTreatAsUserValue(text) || seen[text]) return;
      seen[text] = true;
      values.push(text);
    }

    try {
      rootElement.querySelectorAll("input, textarea").forEach(function (el) {
        add(el.value || el.getAttribute("value") || el.textContent);
      });
      rootElement.querySelectorAll("select").forEach(function (el) {
        Array.from(el.selectedOptions || []).forEach(function (opt) {
          add(opt.textContent || opt.value);
        });
      });
      rootElement.querySelectorAll('[contenteditable="true"], [contenteditable=""]').forEach(function (el) {
        add(el.textContent);
      });
      rootElement.querySelectorAll(
        [
          ".ant-select-selection-item",
          ".ant-select-selection-overflow-item",
          ".el-select__tags-text",
          ".el-input__inner",
          ".ivu-select-selected-value",
          ".kuma-select2-selection__rendered",
          '[class*="selected" i]',
          '[class*="value" i]',
        ].join(",")
      ).forEach(function (el) {
        add(el.textContent || el.getAttribute("title") || el.getAttribute("value"));
      });
    } catch (e) {}

    return values.sort(function (a, b) { return b.length - a.length; });
  }

  function scrubExistingValues(clone, values) {
    if (!values || !values.length) return;
    try {
      clone.querySelectorAll("[value], [checked], [selected], [aria-checked], [aria-selected]").forEach(function (el) {
        el.removeAttribute("value");
        el.removeAttribute("checked");
        el.removeAttribute("selected");
        el.removeAttribute("aria-checked");
        el.removeAttribute("aria-selected");
      });
      clone.querySelectorAll('[contenteditable="true"], [contenteditable=""]').forEach(function (el) {
        el.textContent = "[contenteditable]";
      });
      var walker = document.createTreeWalker(clone, NodeFilter.SHOW_TEXT, null);
      var textNodes = [];
      var node;
      while ((node = walker.nextNode())) textNodes.push(node);
      textNodes.forEach(function (textNode) {
        var text = textNode.nodeValue || "";
        values.forEach(function (value) {
          if (text.indexOf(value) !== -1) text = text.split(value).join("[已隐藏]");
        });
        textNode.nodeValue = text;
      });
    } catch (e) {}
  }

  function cleanHtml(rootElement) {
    try {
      var existingUserValues = collectExistingUserValues(rootElement);
      var clone = rootElement.cloneNode(true);
      scrubExistingValues(clone, existingUserValues);

      clone.querySelectorAll('[style*="display: none"], [style*="display:none"], [hidden]').forEach(function (el) {
        el.remove();
      });

      clone.querySelectorAll("script, style, noscript, link, meta, iframe, svg, path").forEach(function (el) {
        el.remove();
      });

      clone.querySelectorAll("input").forEach(function (el) {
        var span = document.createElement("span");
        span.setAttribute("data-input", "true");
        var inputType = el.getAttribute("type") || "text";
        var placeholder = el.getAttribute("placeholder") || "";
        span.textContent = "[input:" + inputType + (placeholder ? ":" + placeholder : "") + "]";
        el.parentNode.replaceChild(span, el);
      });

      clone.querySelectorAll("textarea").forEach(function (el) {
        var span = document.createElement("span");
        span.setAttribute("data-textarea", "true");
        var placeholder = el.getAttribute("placeholder") || "";
        span.textContent = "[textarea" + (placeholder ? ":" + placeholder : "") + "]";
        el.parentNode.replaceChild(span, el);
      });

      clone.querySelectorAll("select").forEach(function (el) {
        var span = document.createElement("span");
        span.setAttribute("data-select", "true");
        var options = Array.from(el.querySelectorAll("option"))
          .map(function (opt) { return opt.textContent.trim(); })
          .filter(function (t) { return t; })
          .join("|");
        span.textContent = "[select" + (options ? ":" + options : "") + "]";
        el.parentNode.replaceChild(span, el);
      });

      var html = clone.innerHTML.replace(/\s+/g, " ");

      var protectPattern = PROTECTED_SELECTORS.join("|");
      var protectRegex = new RegExp("<(" + protectPattern + ")[\\s>]", "i");

      for (var i = 0; i < 3; i++) {
        html = html.replace(/<(\w+)([^>]*)>\s*<\/\1>/g, function (match, tag, attrs) {
          if (protectRegex.test(match)) return match;
          if (/data-(input|textarea|select)/.test(attrs)) return match;
          return "";
        });
      }

      var allowedAttrs = ["class", "id", "type", "name", "data-input", "data-textarea", "data-select", "placeholder", "title", "dlcolname", "for"];
      var attrPattern = /(\w+)=["'][^"']*["']/g;

      html = html.replace(/<(\w+)([^>]*)>/g, function (match, tag, attrs) {
        var cleanedAttrs = "";
        attrs.replace(attrPattern, function (attrMatch, attrName) {
          if (allowedAttrs.indexOf(attrName.toLowerCase()) !== -1) {
            cleanedAttrs += " " + attrMatch;
          }
        });
        return "<" + tag + cleanedAttrs + ">";
      });

      html = html.replace(/\s+/g, " ").trim();

      if (html.length > 50000) {
        html = html.substring(0, 50000) + "...[truncated]";
      }

      return html;
    } catch (e) {
      console.error("[AutoFill] cleanHtml error:", e);
      return rootElement.innerHTML.substring(0, 50000);
    }
  }

  // 采集页面信息，供 AI 站点配置生成使用 (源码参考 collectPageInfo，同一来源验证过)
  function collectModuleDialogResumeInfo() {
    if (AF.InteractiveFormRuntime && typeof AF.InteractiveFormRuntime.detectPage === "function") {
      try {
        var detected = AF.InteractiveFormRuntime.detectPage();
        return {
          matched: Boolean(detected && detected.matched),
          moduleCount: Number(detected && detected.moduleCount || 0),
          actionCount: Number(detected && detected.actionCount || 0),
          titles: (detected && detected.modules || []).map(function (module) { return module.title; }).filter(Boolean).slice(0, 20),
          confidence: Number(detected && detected.confidence || 0),
          mode: detected && detected.mode || "",
          runtimeVersion: AF.InteractiveFormRuntime.version || "",
        };
      } catch (e) {}
    }
    var root = document.querySelector(".resume");
    if (!root) return { matched: false, moduleCount: 0, actionCount: 0, titles: [] };
    var modules = Array.from(root.querySelectorAll(".resume-module"));
    var titles = [];
    var actionCount = 0;
    modules.forEach(function (module) {
      var titleEl = module.querySelector(".resume-module-header .title, .module-title, .title");
      var title = titleEl && titleEl.textContent ? titleEl.textContent.replace(/\s+/g, " ").trim() : "";
      if (/我的意向志愿|意向志愿|求职志愿|志愿信息|投递职位|申请职位/.test(title)) return;
      if (title) titles.push(title);
      var buttons = Array.from(module.querySelectorAll(
        ".resume-module-header .right .custom-button, .resume-module-header button, .resume-module-header a, .resume-module-header [role='button'], button, a, [role='button']"
      ));
      buttons.forEach(function (btn) {
        var text = String(btn.innerText || btn.textContent || btn.getAttribute("aria-label") || btn.getAttribute("title") || "")
          .replace(/\s+/g, "")
          .trim();
        if (!text || /立即投递|一键移除并投递|投递|提交|删除|移除|取消|关闭|我知道了/.test(text)) return;
        if (/编辑|添加|新增|修改/.test(text)) actionCount++;
      });
    });
    return {
      matched: modules.length >= 2 && actionCount > 0,
      moduleCount: modules.length,
      actionCount: actionCount,
      titles: Array.from(new Set(titles)).slice(0, 20),
    };
  }

  function collectPageInfo() {
    var labelElements = document.querySelectorAll(
      "label, .el-form-item__label, .ant-form-item-label, " +
        ".kuma-label, .brick-field-label, .form-item__text, " +
        ".subtitle, .field-label, .form-label, " +
        '[class*="label"], [class*="Label"]'
    );

    var labels = [];
    labelElements.forEach(function (el) {
      var text = el.textContent.trim();
      if (text && text.length > 0 && text.length < 50) labels.push(text);
    });
    labels = Array.from(new Set(labels));

    var uiFrame示例资料 = "unknown";
    if (document.querySelector(".ant-btn, .ant-form, .ant-input")) {
      uiFrame示例资料 = "Ant Design";
    } else if (document.querySelector(".el-input, .el-form, .el-button")) {
      uiFrame示例资料 = "Element UI";
    } else if (document.querySelector(".kuma-label, .uxcore-card")) {
      uiFrame示例资料 = "Kuma (uxcore)";
    } else if (document.querySelector('[class*="apply-block-"], [class*="createFormSection"]')) {
      uiFrame示例资料 = "Byte UI (字节自研)";
    } else if (
      /(^|\.)zhiye\.com$/i.test(window.location.hostname || "") &&
      document.querySelector(".dl_示例资料info") &&
      document.querySelector(".form_container[id^='RecruitmentPortal.']")
    ) {
      uiFrame示例资料 = "Legacy Zhiye Portal (北森/智业旧版)";
    } else if (document.querySelector(".brick-field-label")) {
      uiFrame示例资料 = "Brick UI (B站自研)";
    } else if (document.querySelector('.Wdate, [onclick*="WdatePicker"]')) {
      uiFrame示例资料 = "My97 DatePicker";
    }

    var existingUserValues = collectExistingUserValues(document.body);
    var cleanedHtml = cleanHtml(document.body);
    var moduleDialogResume = collectModuleDialogResumeInfo();

    return {
      hostname: window.location.hostname,
      url: window.location.href,
      uiFrame示例资料: uiFrame示例资料,
      labels: labels,
      cleanedHtml: cleanedHtml,
      collectedAt: new Date().toISOString(),
      inputCount: document.querySelectorAll("input, textarea, select").length,
      labelCount: labels.length,
      existingValueCount: existingUserValues.length,
      moduleDialogResumePage: moduleDialogResume.matched,
      moduleDialogResume: moduleDialogResume,
      interactiveFormPage: moduleDialogResume.matched,
      interactiveDetection: moduleDialogResume,
    };
  }

  AF.cleanHtml = cleanHtml;
  AF.collectPageInfo = collectPageInfo;
})();
