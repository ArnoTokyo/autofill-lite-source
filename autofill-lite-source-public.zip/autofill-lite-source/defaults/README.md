# Profile examples

This source archive intentionally does not include any completed candidate profile.

Create local JSON files named `candidate-profile-merged.json` and `candidate-profile-ledger.json` in the application's local data directory. Use the field names required by `profile-adapter.js`; keep all personal values, credentials, browser state and documents outside this repository.

