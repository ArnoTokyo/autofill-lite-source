// content/data-matcher.js — DataMatcher: 页面标题/标签文字 → 简历数据类别/字段名 匹配引擎
//
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   DataMatcher 类 (混淆名 C, 导出为 `r.d(e, { n: () => C })`，与任务书里说的
//   "混淆名 v, 导出 v.n" 是同一种导出写法，只是这份 build 里类被命名成了 C):
//     构造函数 (校验 resumeData + 初始化字段):                行24829-24844
//     _preprocessText (清洗文字, 供相似度比较用):              行24847-24854
//     _levenshteinDistance:                                    行24856-24881
//     _calculateStringSimilarity:                              行24883-24898
//     getCategoryByTitleFuzzy (标题→类别, 模糊匹配):           行24900-24946
//     analyzePageCategories:                                    行24948-24975
//     findFieldByFuzzyMatchInCategory:                          行24977-25026
//     findFieldByFuzzyMatch (跨类别模糊匹配, 本文件未搬运):     行25028-25094
//     getCategoryByTitle:                                       行25096-25212
//     _formatData:                                              行25214-25237
//     findFieldByCategory:                                      行25239-25256
//     findExperienceData / findPersonalInfo / findFieldInfo
//       (本文件未搬运, 不在任务范围内, 依赖 getDataByPath 等
//        更多方法, 详见下方"改造点"说明):                       行25258-25407
//   精确匹配用的预构建索引 g()/w() (categoryIndex/fieldIndex,
//     由字段字典 f 在模块加载时构建成 Map):                     行24428-24458
//   字段字典 f 本体 (混淆名 f, 即本项目的 AF.FieldDictionary):  行24222-24385
//   educationType "是否"型字段 是/否 归一化 (混淆名 D.aZ.normalizeEducationTypeToYesNo,
//     与 DataMatcher 不是同一个类, 但任务书要求把这段转换逻辑放進本文件):  行2586-2604
//   findFieldKeyByMapping (双向 includes 匹配, 已在 utils.js 实现):        行10358-10386
//
// 改造点:
//   - 源码里 categoryIndex/fieldIndex 是模块加载时预先构建好的 Map (对 title/label
//     做"完全相等"精确匹配用，行24428-24458 的 g()/w())。本文件不维护这份额外的索引，
//     而是直接复用已经写好的 AF.Utils.findFieldKeyByMapping (双向 includes 匹配) 来做
//     "精确匹配"这一步 —— 语义上是原索引精确匹配的超集(包含完全相等的情况，外加子串
//     包含)，但保留了源码"先精确、后 Levenshtein 模糊"的两段式结构不变。
//     analyzePageCategories/getCategoryByTitle 里对应 g(title) 的部分则用一个线性扫描
//     的 _findCategoryByExactTitle 代替，效果等价 (源码是 O(1) Map 查找，这里是 O(n)
//     线性扫描，量级很小，不影响正确性)。
//   - fieldMappings 不再由构造函数外部注入，而是直接读全局 AF.FieldDictionary
//     (按 manifest.json 里 content_scripts 的加载顺序，field-dictionary.js 在本文件
//     之前加载，运行时一定已经存在)。
//   - _preprocessText/_levenshteinDistance/_calculateStringSimilarity/
//     getCategoryByTitleFuzzy/findFieldByFuzzyMatchInCategory/getCategoryByTitle/
//     findFieldByCategory/analyzePageCategories/_formatData 全部原样保留算法逻辑，
//     只改了变量名。
//   - findFieldByFuzzyMatch(不带 category 的全局模糊匹配)/findExperienceData/
//     findPersonalInfo/findFieldInfo/getDataByPath 这几个方法不在任务范围
//     (任务书明确列出的只有 analyzePageCategories/getCategoryByTitle/
//     findFieldByCategory/findFieldByFuzzyMatchInCategory 四个 + educationType
//     特殊处理)，本文件未搬运，避免超出既定契约引入未经验证的行为。
//   - getCategoryByTitle 的 options.returnMultiple 分支: 源码里判断"是否要返回多个
//     类别"完全是数据驱动的 (谁的 labels 数组里字面包含这个 title 谁就会被收进候选)，
//     并不会在 DataMatcher 内部硬编码检查 title === "实习/项目经历" —— 那个字符串判断
//     是在调用方 FillEngine 里做的 (决定要不要传 returnMultiple: true)，本文件按源码
//     原样实现成数据驱动版本，不做字符串硬编码。
//   - normalizeEducationTypeToYesNo (是否全日制 → 是/否 归一化) 严格来说属于源码里
//     另一个类 D.aZ，不属于 DataMatcher 本体；但任务书明确要求把这段值转换逻辑放進
//     本文件，故作为 DataMatcher 的实例方法提供 (供未来的 FillEngine/FormHandler
//     在拿到 fieldKey==="educationType" 且 label 命中 /是否/ 时调用，用法见源码
//     行13051-13053/13175-13177)。注: content/form-handler.js 目前已经有一份自己
//     的本地等价实现并接进了实际填写循环，这里提供的是 DataMatcher 侧的等价 API，
//     两边逻辑完全一致，互不冲突。
//   - 未发现会员/登录/配额相关逻辑，无需删除。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});

  // ============================================================
  // DataMatcher 构造函数 (行24829-24844)
  // ============================================================
  function DataMatcher(resumeData, siteConfig) {
    if (!resumeData || typeof resumeData !== "object" || Array.isArray(resumeData)) {
      throw new Error("Invalid resume data: must be a non-null object");
    }
    this.resumeData = resumeData;
    // 字段字典由并行的另一个模块 (content/field-dictionary.js) 提供，
    // 按 manifest.json 里的加载顺序，此时 AF.FieldDictionary 必然已存在。
    this.fieldMappings = AF.FieldDictionary || {};
    this.SIMILARITY_THRESHOLD = 0.55;
    this.CATEGORY_SIMILARITY_THRESHOLD = 0.55;
    this.EXPERIENCE_CATEGORIES = ["education", "workExperience", "internshipExperience", "projectExperience", "campusLeadership", "campusActivities", "trainingExperience", "awards", "certificates", "publications", "patents", "languageSkills", "familyMembers", "combinedExperience"];
    this.siteConfig = siteConfig || null;
  }

  function normalizeAiLabel(text) {
    return String(text || "")
      .replace(/[\s：:*?？（）()【】\[\]「」'"“”‘’.,，。;；、]/g, "")
      .replace(/必填|选填|请输入|请选择/g, "")
      .toLowerCase();
  }

  function labelMatchesAiLabel(labelText, aiLabel) {
    var label = normalizeAiLabel(labelText);
    var target = normalizeAiLabel(aiLabel);
    if (!label || !target) return false;
    return label === target || (label.length >= 2 && target.length >= 2 && (label.indexOf(target) !== -1 || target.indexOf(label) !== -1));
  }

  function isUnsafeFieldMatch(labelText, category, fieldKey) {
    var label = normalizeAiLabel(labelText);
    var key = String(fieldKey || "").toLowerCase();
    if (!label || !key) return false;
    // “QQ邮箱”仍然是邮箱字段，不是 QQ 账号字段。双向 includes 匹配中
    // `QQ` 会先命中该标签，若不拦截就可能把 QQ 号填入邮箱控件，页面再
    // 将其显示成 `数字@qq.com`。只有明确的“QQ/QQ账号”标签才允许映射 qq。
    if (category === "basicInfo" && /邮箱|电子邮件|邮件/.test(label) && key === "qq") {
      return true;
    }
    if (category === "basicInfo" && /^(qq|qq账号)$/.test(label) && key === "email") {
      return true;
    }
    if (/电话|手机|联系方式|联系电话/.test(label) && !/(phone|mobile|tel|contact|telephone)/i.test(fieldKey)) {
      return true;
    }
    // “是否同意提供身份证号码”是授权选择题，不是证件号码输入框。包含匹配
    // 会把真实身份证号当成下拉选项填写，既错误也存在敏感字段串填风险。
    if (/是否.*(?:同意|允许|授权).*身份证号码/.test(label) && key === "idnumber") {
      return true;
    }
    if (/(?:证件照|照片|头像|生活照|简历附件|附件|上传)/.test(label) && key === "idnumber") {
      return true;
    }
    if (/(?:证件号码|身份证号|身份证号码|证件号)/.test(label) && /^(photo|idphoto|lifephoto)$/i.test(fieldKey)) {
      return true;
    }
    if (/亲属/.test(label) && key === "name" && category === "basicInfo") {
      return true;
    }
    if (/直接上司|上司/.test(label) && key === "position") {
      return true;
    }
    // “描述”只有两个字，跨模块误匹配风险极高。自我评价必须出现“自我评价/
    // 自我介绍/个人评价”等明确标签，不能把工作、实习、项目、获奖里的描述兜底填成它。
    if (label === "描述" && category === "selfIntroduction") {
      return true;
    }
    if (/交换生/.test(label) && key === "level" && category === "education") {
      return true;
    }
    if (/^(等级|级别)$/.test(label) && key === "degree" && category === "education") {
      return true;
    }
    // Build153 local-first semantic vetoes: short/fuzzy labels in RepeatRecord
    // must not cross obvious semantic families. These vetoes only reject unsafe
    // candidates; they never invent a replacement field.
    var repeatCategory = /^(education|workExperience|internshipExperience|projectExperience|campusLeadership|campusActivities|trainingExperience|awards|certificates|publications|patents|languageSkills|familyMembers)$/.test(String(category || ""));
    if (repeatCategory && /(时间|日期|年月|年份|年度)$/.test(label) && !/(time|date|year|duration|period)/i.test(key)) {
      return true;
    }
    if (category === "familyMembers" && /姓名$/.test(label) && key !== "name") {
      return true;
    }
    if (category === "awards" && /(?:奖项|获奖|奖励)名称$/.test(label) && key !== "awardname") {
      return true;
    }
    if (category === "projectExperience" && /项目名称$/.test(label) && !/^(projectname|name|title)$/.test(key)) {
      return true;
    }
    if (category === "certificates" && /(?:证书|资格|认证).*(?:编号|号码)$/.test(label) && !/(no|number|code)/i.test(key)) {
      return true;
    }
    return false;
  }


  function isBlockedBySemanticPatch(siteConfig, labelText) {
    try {
      var blocked = siteConfig && siteConfig._aiSemanticPatch && siteConfig._aiSemanticPatch.blockedLabels;
      if (!Array.isArray(blocked) || !blocked.length) return false;
      var wanted = normalizeAiLabel(labelText);
      if (!wanted) return false;
      return blocked.some(function (item) {
        var label = typeof item === "string" ? item : item && item.label;
        return wanted === normalizeAiLabel(label);
      });
    } catch (e) {
      return false;
    }
  }

  DataMatcher.prototype.setSiteConfig = function (siteConfig) {
    this.siteConfig = siteConfig || null;
    return this;
  };

  // 旧版AI提示词曾生成过一批旧字段名。加载旧站点配置时按“分类 + 页面标签”
  // 转成当前简历字段，不改服务器存量配置，也不影响仍然有效的 duration 等字段。
  function normalizeLegacyAiFieldKey(category, labelText, fieldKey) {
    var label = String(labelText || "").replace(/[\s：:*?？（）()【】\[\]「」'"“”‘’.,，。;；、]/g, "");
    if (category === "education" && fieldKey === "duration" && /学制|学习年限|几年制|修业年限/.test(label)) {
      return "studyLength";
    }
    var aliases = {
      awards: { name: "awardName", time: "awardTime", level: "awardLevel", description: "awardDescription" },
      certificates: { name: "certificateName", issueDate: "obtainedTime" },
      languageSkills: { language: "name" },
      familyMembers: { workplace: "company", occupation: "position" },
      campusLeadership: { position: "title", organization: "projectName" },
    };
    return aliases[category] && aliases[category][fieldKey] || fieldKey;
  }

  DataMatcher.prototype.findFieldBySemanticPatch = function (category, labelText) {
    var config = this.siteConfig || {};
    if (!category || !labelText) return null;

    var semanticMappings = [];
    try {
      var runtimePatch = AF.RuntimeSemanticPatch;
      if (
        runtimePatch &&
        (!runtimePatch.hostname || String(runtimePatch.hostname).toLowerCase() === String(location.hostname || "").toLowerCase()) &&
        (!runtimePatch.pathname || String(runtimePatch.pathname) === String(location.pathname || "/")) &&
        Array.isArray(runtimePatch.fieldMappings)
      ) {
        semanticMappings = semanticMappings.concat(runtimePatch.fieldMappings);
      }
    } catch (e) {}
    semanticMappings = semanticMappings.concat(config._aiSemanticPatch && config._aiSemanticPatch.fieldMappings || []);
    var normalizeSemanticLabel = function (value) {
      return String(value || "").replace(/[\s：:*?？（）()【】\[\]「」'"“”‘’.,，。;；、]/g, "").toLowerCase();
    };
    var wanted = normalizeSemanticLabel(labelText);
    var resolvePatchedFieldKey = function (mapping) {
      if (!mapping) return null;
      // 新填写适配器随客户端版本发布，但普通站点补丁会立即下发给旧客户端。
      // adapterFieldKey 只有在当前客户端确实注册了 requiresAdapter 时才启用；
      // 老客户端不认识这两个扩展字段，仍读取安全的 fieldKey（通常是 skip key）。
      if (
        mapping.requiresAdapter &&
        mapping.adapterFieldKey &&
        AF.SelectAdapter &&
        AF.SelectAdapter._registry &&
        AF.SelectAdapter._registry[mapping.requiresAdapter]
      ) {
        return mapping.adapterFieldKey;
      }
      return mapping.fieldKey;
    };

    // 人工补丁先做完全相等匹配。“毕业院校”不能被更靠前的
    // “毕业院校所在国家/地区”抢走，“证件”也不能误中“证件签发国家/地区”。
    for (var exactIndex = 0; exactIndex < semanticMappings.length; exactIndex++) {
      var exactMapping = semanticMappings[exactIndex];
      if (!exactMapping || exactMapping.category !== category || !exactMapping.fieldKey) continue;
      if (wanted && wanted === normalizeSemanticLabel(exactMapping.label)) {
        return normalizeLegacyAiFieldKey(category, labelText, resolvePatchedFieldKey(exactMapping));
      }
    }
    for (var i = 0; i < semanticMappings.length; i++) {
      var mapping = semanticMappings[i];
      if (!mapping || mapping.category !== category || !mapping.fieldKey) continue;
      if (labelMatchesAiLabel(labelText, mapping.label)) {
        return normalizeLegacyAiFieldKey(category, labelText, resolvePatchedFieldKey(mapping));
      }
    }
    return null;
  };

  DataMatcher.prototype.findFieldByAiMapping = function (category, labelText) {
    var config = this.siteConfig;
    if (!config || !category || !labelText) return null;

    var semanticFieldKey = this.findFieldBySemanticPatch(category, labelText);
    if (semanticFieldKey) return semanticFieldKey;

    var aiSection = config._aiSections && config._aiSections[category];
    var fields = aiSection && aiSection.fields;
    if (!fields) return null;
    for (var fieldKey in fields) {
      if (!Object.prototype.hasOwnProperty.call(fields, fieldKey)) continue;
      var labels = fields[fieldKey] && fields[fieldKey].labels || [];
      for (var j = 0; j < labels.length; j++) {
        if (labelMatchesAiLabel(labelText, labels[j])) return normalizeLegacyAiFieldKey(category, labelText, fieldKey);
      }
    }
    return null;
  };

  // ============================================================
  // 私有辅助: 文字预处理 (行24847-24854)
  // 去掉全套中英文标点/空白 + "必填"/"请输入"/"可选" 这几个提示词，转小写，
  // 供 Levenshtein 相似度比较使用。注意这跟 AF.LabelUtils.getLabelText 的清洗
  // 规则不是同一套 (getLabelText 只删 `* : ： 必填 选填 空格`)，两者服务于不同用途，
  // 不能互相替代，源码里也是两套独立的清洗函数。
  // ============================================================
  DataMatcher.prototype._preprocessText = function (text) {
    if (!text) return "";
    return String(text)
      .toLowerCase()
      .replace(/[：:「」【】（）()*\[\]\s,，.。!！"#$%&'*+,;<=>?@^_`{|}~-]/g, "")
      .replace(/必填/g, "")
      .replace(/请输入/g, "")
      .replace(/可选/g, "");
  };

  // ---------- _levenshteinDistance (编辑距离, 行24856-24881) ----------
  DataMatcher.prototype._levenshteinDistance = function (a, b) {
    if (a.length === 0) return b.length;
    if (b.length === 0) return a.length;
    var matrix = [];
    for (var i = 0; i <= b.length; i++) matrix[i] = [i];
    for (var j = 0; j <= a.length; j++) matrix[0][j] = j;
    for (var row = 1; row <= b.length; row++) {
      for (var col = 1; col <= a.length; col++) {
        if (b.charAt(row - 1) === a.charAt(col - 1)) {
          matrix[row][col] = matrix[row - 1][col - 1];
        } else {
          matrix[row][col] = Math.min(matrix[row - 1][col - 1] + 1, Math.min(matrix[row][col - 1] + 1, matrix[row - 1][col] + 1));
        }
      }
    }
    return matrix[b.length][a.length];
  };

  // ---------- _calculateStringSimilarity (行24883-24898) ----------
  // 完全相等→1；一个包含另一个→较短串占较长串的比例 * 0.9；否则用编辑距离算相似度。
  DataMatcher.prototype._calculateStringSimilarity = function (a, b) {
    if (a === b) return 1;
    if (a && b) {
      if (a.includes(b)) return (b.length / a.length) * 0.9;
      if (b.includes(a)) return (a.length / b.length) * 0.9;
      return 1 - this._levenshteinDistance(a, b) / Math.max(a.length, b.length);
    }
    return 0;
  };

  // ============================================================
  // 私有辅助: 标题精确匹配类别 (对应源码预构建索引 g(title), 行24428-24453 的 Map
  // 换成线性扫描的等价实现，见文件头"改造点"说明)
  // ============================================================
  DataMatcher.prototype._findCategoryByExactTitle = function (title) {
    var cleanedTitle = this._preprocessText(title);
    var semanticSection = this.findSectionSemanticMapping(title);
    if (semanticSection) return semanticSection.category;
    for (var key in this.fieldMappings) {
      if (!Object.prototype.hasOwnProperty.call(this.fieldMappings, key)) continue;
      if (key === title) return key;
      var cat = this.fieldMappings[key];
      if (cat && cat.labels && cat.labels.indexOf(title) !== -1) return key;
      if (cat && cat.labels && cleanedTitle) {
        for (var i = 0; i < cat.labels.length; i++) {
          var cleanedLabel = this._preprocessText(cat.labels[i]);
          if (cleanedLabel && cleanedLabel.length >= 2 && cleanedTitle.indexOf(cleanedLabel) !== -1) {
            return key;
          }
        }
      }
    }
    return null;
  };

  DataMatcher.prototype.findSectionSemanticMapping = function (title) {
    var cleanedTitle = this._preprocessText(title);
    var sectionMappings = this.siteConfig && this.siteConfig._aiSemanticPatch && this.siteConfig._aiSemanticPatch.sectionMappings || [];
    for (var mappingIndex = 0; mappingIndex < sectionMappings.length; mappingIndex++) {
      var mapping = sectionMappings[mappingIndex];
      if (!mapping || !mapping.category || !mapping.label) continue;
      var cleanedMappingLabel = this._preprocessText(mapping.label);
      if (
        mapping.label === title ||
        (cleanedTitle && cleanedMappingLabel && (
          cleanedTitle === cleanedMappingLabel ||
          cleanedTitle.indexOf(cleanedMappingLabel) !== -1 ||
          cleanedMappingLabel.indexOf(cleanedTitle) !== -1
        ))
      ) return mapping;
    }
    return null;
  };

  // ---------- getCategoryByTitleFuzzy (标题→类别, 模糊匹配, 行24900-24946) ----------
  DataMatcher.prototype.getCategoryByTitleFuzzy = function (title) {
    var cleanedTitle = this._preprocessText(title);
    if (!cleanedTitle) return null;
    var best = { categoryKey: null, score: 0 };
    for (var key in this.fieldMappings) {
      if (!Object.prototype.hasOwnProperty.call(this.fieldMappings, key)) continue;
      var cat = this.fieldMappings[key];
      if (!cat || !cat.labels) continue;

      var cleanedKey = this._preprocessText(key);
      var keyScore = this._calculateStringSimilarity(cleanedTitle, cleanedKey);
      if (keyScore > best.score) best = { categoryKey: key, score: keyScore };

      for (var i = 0; i < cat.labels.length; i++) {
        var cleanedLabel = this._preprocessText(cat.labels[i]);
        if (!cleanedLabel) continue;
        var labelScore = this._calculateStringSimilarity(cleanedTitle, cleanedLabel);
        if (labelScore > best.score) best = { categoryKey: key, score: labelScore };
      }
    }
    return best.score >= this.CATEGORY_SIMILARITY_THRESHOLD ? best : null;
  };

  // ---------- analyzePageCategories (行24948-24975) ----------
  // 输入一批页面上扫描到的分区标题文字，返回页面上实际存在哪些简历数据类别 (Set)。
  DataMatcher.prototype.analyzePageCategories = function (titles) {
    var result = new Set();
    var list = titles || [];
    for (var i = 0; i < list.length; i++) {
      var title = list[i];
      if (!title) continue;
      var exactKey = this._findCategoryByExactTitle(title);
      if (exactKey) {
        result.add(exactKey);
      } else {
        var fuzzy = this.getCategoryByTitleFuzzy(title);
        if (fuzzy && fuzzy.categoryKey) result.add(fuzzy.categoryKey);
      }
    }
    return result;
  };

  // ---------- findFieldByFuzzyMatchInCategory (行24977-25026) ----------
  DataMatcher.prototype.findFieldByFuzzyMatchInCategory = function (labelText, category) {
    var cleanedLabel = this._preprocessText(labelText);
    if (!cleanedLabel || !category) return null;
    var cat = this.fieldMappings[category];
    if (!cat || !cat.fields) return null;

    var best = { fieldKey: null, score: 0 };
    for (var fieldKey in cat.fields) {
      if (!Object.prototype.hasOwnProperty.call(cat.fields, fieldKey)) continue;

      var cleanedKey = this._preprocessText(fieldKey);
      var keyScore = this._calculateStringSimilarity(cleanedLabel, cleanedKey);
      if (keyScore > best.score) best = { fieldKey: fieldKey, score: keyScore };

      var aliases = cat.fields[fieldKey] || [];
      for (var i = 0; i < aliases.length; i++) {
        var cleanedAlias = this._preprocessText(aliases[i]);
        if (!cleanedAlias) continue;
        var aliasScore = this._calculateStringSimilarity(cleanedLabel, cleanedAlias);
        if (aliasScore > best.score) best = { fieldKey: fieldKey, score: aliasScore };
      }
    }
    return best.score >= this.SIMILARITY_THRESHOLD ? best : null;
  };

  // ---------- findFieldByCategory (精确匹配 + 模糊回退, 行25239-25256) ----------
  DataMatcher.prototype.findFieldByCategory = function (category, labelText) {
    if (!category || !labelText) return null;
    try {
      // Candidate-level negative knowledge must be honored before the generic
      // dictionary/fuzzy matcher. This prevents a reviewed current-role/current-city
      // field from being silently re-mapped to a desired role/city later in Core.
      if (isBlockedBySemanticPatch(this.siteConfig, labelText)) return null;
      // 邮箱语义优先于别名包含匹配，避免“QQ邮箱”等复合标签被 `QQ`
      // 别名抢先解析为 qq。普通“QQ/QQ账号”仍只映射 QQ 字段。
      if (category === "basicInfo") {
        var basicLabel = this._preprocessText(labelText);
        if (/邮箱|电子邮件|邮件/.test(basicLabel)) return "email";
        if (/^(qq|qq账号)$/.test(basicLabel)) return "qq";
      }
      // 北森 Phoenix 等站点会把“院校所在城市”做成单独的城市下拉框。
      // 该标签包含“院校所在地”，通用的双向 includes 规则会误命中
      // schoolLocation；先在教育分类固定其语义，避免省份/城市串填。
      if (category === "education") {
        var educationLabel = this._preprocessText(labelText);
        if (/^(办学属地|院校属性|院校所属地|境内\/境外院校类别|国内\/海外院校类别)$/.test(educationLabel)) return "schoolAffiliation";
        if (/^(就读院校|院校|学校|毕业院校)所在城市$|^院校城市$/.test(educationLabel)) return "city";
        if (/^(院校|学校|毕业院校)所在省份$/.test(educationLabel)) return "schoolProvince";
      }
      // 人工站点修正层必须先于通用字典。否则类似华为“籍贯”的内部字段名
      // nationality、第二意向工作地等站点特有语义仍会被通用别名提前抢走，
      // 补丁即使已下发也无法阻止串填。旧版 AI `_aiSections` 仍保留在模糊
      // 匹配之后，只有人工维护的 `_aiSemanticPatch` 获得最高优先级。
      var semanticFieldKey = this.findFieldBySemanticPatch(category, labelText);
      if (semanticFieldKey && !isUnsafeFieldMatch(labelText, category, semanticFieldKey)) return semanticFieldKey;

      var cat = this.fieldMappings[category];
      if (cat && cat.fields) {
        // 精确匹配一步: 源码用预构建的 Map 索引 w(category, label) 做"完全相等"匹配
        // (行24436-24444)。这里复用已实现的 AF.Utils.findFieldKeyByMapping (双向
        // includes)，效果是原精确匹配的超集，但"先精确后模糊"的两段式结构与源码一致。
        var exactFieldKey = AF.Utils.findFieldKeyByMapping(labelText, cat.fields);
        if (exactFieldKey && !isUnsafeFieldMatch(labelText, category, exactFieldKey)) return exactFieldKey;
      }
      var fuzzy = this.findFieldByFuzzyMatchInCategory(labelText, category);
      if (fuzzy && !isUnsafeFieldMatch(labelText, category, fuzzy.fieldKey)) return fuzzy.fieldKey;

      var aiFieldKey = this.findFieldByAiMapping(category, labelText);
      if (aiFieldKey && !isUnsafeFieldMatch(labelText, category, aiFieldKey)) return aiFieldKey;

      return null;
    } catch (e) {
      return null;
    }
  };

  // ---------- _formatData (行25214-25237) ----------
  // array 类型: 浅拷贝成新数组；object 类型: 浅拷贝成新对象。源码里用的是
  // 数组展开/对象展开语法，效果就是浅拷贝，这里直接用等价的 slice/Object.assign。
  DataMatcher.prototype._formatData = function (data, type) {
    if (type === "array") {
      return Array.isArray(data) ? data.slice() : Array.from(data);
    }
    return Object.assign({}, data);
  };

  // ---------- getCategoryByTitle (标题 → {type, category, data}, 行25096-25212) ----------
  // options: { allowInternToWork, allowWorkToIntern, disableOtherLanguage, returnMultiple }
  DataMatcher.prototype.getCategoryByTitle = function (title, options) {
    options = options || {};
    var allowInternToWork = !!options.allowInternToWork;
    var allowWorkToIntern = !!options.allowWorkToIntern;
    var disableOtherLanguage = !!options.disableOtherLanguage;
    var returnMultiple = !!options.returnMultiple;
    var self = this;
    var semanticSection = this.findSectionSemanticMapping(title);

    var filterSectionRows = function (raw, mapping) {
      if (!Array.isArray(raw) || !mapping || !mapping.recordFilter) return raw;
      var filter = mapping.recordFilter;
      var fields = Array.isArray(filter.fields) ? filter.fields : [];
      var includeAny = Array.isArray(filter.includeAny) ? filter.includeAny : [];
      var excludeAny = Array.isArray(filter.excludeAny) ? filter.excludeAny : [];
      var normalize = function (value) { return String(value == null ? "" : value).replace(/\s+/g, "").toLowerCase(); };
      var includesPattern = function (text, patterns) {
        return patterns.some(function (pattern) {
          var wanted = normalize(pattern);
          return wanted && text.indexOf(wanted) !== -1;
        });
      };
      return raw.filter(function (row) {
        var values = fields.length
          ? fields.map(function (field) { return row && row[field]; })
          : Object.keys(row || {}).map(function (field) { return row[field]; });
        var text = normalize(values.filter(Boolean).join(" "));
        if (includeAny.length && !includesPattern(text, includeAny)) return false;
        if (excludeAny.length && includesPattern(text, excludeAny)) return false;
        return true;
      });
    };

    var hasData = function (key) {
      var raw = self.resumeData[key];
      return Array.isArray(raw) ? raw.length > 0 : !!raw;
    };
    var buildResult = function (key) {
      var raw = self.resumeData[key];
      if (!raw) return null;
      raw = filterSectionRows(raw, semanticSection && semanticSection.category === key ? semanticSection : null);
      if (Array.isArray(raw) && raw.length === 0) return null;
      var type = Array.isArray(raw) ? "array" : "object";
      return { category: key, type: type, data: self._formatData(raw, type) };
    };
    var cloneExperienceRow = function (row, category) {
      var cloned = row && typeof row === "object" ? Object.assign({}, row) : row;
      if (cloned && typeof cloned === "object") cloned.__afCategory = category;
      return cloned;
    };
    var buildMergedExperienceResult = function (primaryKey, secondaryKey) {
      var primary = self.resumeData[primaryKey];
      var secondary = self.resumeData[secondaryKey];
      var merged = [];
      if (Array.isArray(primary)) {
        primary.forEach(function (row) {
          merged.push(cloneExperienceRow(row, primaryKey));
        });
      }
      if (Array.isArray(secondary)) {
        secondary.forEach(function (row) {
          merged.push(cloneExperienceRow(row, secondaryKey));
        });
      }
      if (merged.length === 0) return null;
      return {
        category: primaryKey,
        type: "array",
        data: merged,
        mergedCategories: [primaryKey, secondaryKey],
      };
    };

    // ---- returnMultiple 分支 (行25107-25159): 数据驱动地收集所有"labels 数组里
    // 字面包含这个 title"或者"类别key本身等于title"的类别 (不止一个才走这条路径，
    // 是否要特殊照顾"实习/项目经历"这个具体字符串完全由调用方 FillEngine 决定，
    // DataMatcher 这一层不做字符串硬编码) ----
    if (returnMultiple) {
      var matchedKeys = [];
      for (var key in this.fieldMappings) {
        if (!Object.prototype.hasOwnProperty.call(this.fieldMappings, key)) continue;
        var cat = this.fieldMappings[key];
        if (key === title || (cat && cat.labels && cat.labels.indexOf(title) !== -1)) {
          matchedKeys.push(key);
        }
      }
      if (matchedKeys.length > 1) {
        var multiResults = [];
        for (var i = 0; i < matchedKeys.length; i++) {
          var k = matchedKeys[i];
          var raw = this.resumeData[k];
          if (!raw) continue;
          if (Array.isArray(raw) && raw.length > 0) {
            multiResults.push({ category: k, type: "array", data: this._formatData(raw, "array") });
          } else if (!Array.isArray(raw) && typeof raw === "object") {
            var hasValue = Object.keys(raw).some(function (p) {
              return raw[p] !== null && raw[p] !== undefined && raw[p] !== "";
            });
            if (hasValue) multiResults.push({ category: k, type: "object", data: this._formatData(raw, "object") });
          }
        }
        if (multiResults.length > 0) return multiResults;
      }
      // 没能收集到多个有效结果时，跟源码一样继续往下走单类别匹配逻辑，不提前返回。
    }

    // ---- 单类别匹配: 先精确 (对应源码 g(title)), 再模糊 ----
    var categoryKey = this._findCategoryByExactTitle(title);
    if (!categoryKey) {
      var fuzzy = this.getCategoryByTitleFuzzy(title);
      categoryKey = fuzzy ? fuzzy.categoryKey : null;
    }
    if (!categoryKey) return null;

    // ---- 页面只有一个工作/实习入口时，把两类经历合并给同一个入口。
    // 原版的 allowInternToWork/allowWorkToIntern 只解决"目标类别没数据时互转"；
    // 招聘站常把正式工作和实习合在一个"工作经历"区，这里保留每条记录的
    // __afCategory，让后续字段匹配仍按原类别走。
    if (categoryKey === "workExperience" && allowInternToWork && hasData("internshipExperience")) {
      var mergedWork = buildMergedExperienceResult("workExperience", "internshipExperience");
      if (mergedWork) return mergedWork;
    }
    if (categoryKey === "internshipExperience" && allowWorkToIntern && hasData("workExperience")) {
      var mergedIntern = buildMergedExperienceResult("internshipExperience", "workExperience");
      if (mergedIntern) return mergedIntern;
    }

    // ---- 匹配到类别但简历里这块没数据时的互转逻辑 (行25189-25204) ----
    if (!hasData(categoryKey)) {
      if (categoryKey === "workExperience" && allowInternToWork && hasData("internshipExperience")) {
        var swappedIntern = buildResult("internshipExperience");
        if (swappedIntern) return swappedIntern;
      } else if (categoryKey === "internshipExperience" && allowWorkToIntern && hasData("workExperience")) {
        var swappedWork = buildResult("workExperience");
        if (swappedWork) return swappedWork;
      } else if (disableOtherLanguage && categoryKey === "otherLanguageSkills") {
        // 源码这个分支和下面的兜底 return null 效果完全相同 (行25200-25202)，
        // 保留只是为了跟源码的分支结构保持一致，不代表有额外行为。
        return null;
      }
      return null;
    }

    return buildResult(categoryKey);
  };

  // ============================================================
  // educationType "是否"型字段 是/否 归一化 (源码 D.aZ.normalizeEducationTypeToYesNo,
  // 行2586-2604，逐行照搬)。使用场景 (源码行13051-13053/13175-13177): 当
  // findFieldByCategory 匹配出的 fieldKey === "educationType" 且原始 label 文字
  // 命中 /是否/ 时，把简历里的值 (可能是 "全日制"/"非统招"/true/"有" 等各种写法)
  // 归一化成统一的 "是"/"否" 字符串，再交给 fillFormElement 填入 (通常配合 radio
  // 或下拉的语义值选择)。见文件头"改造点"说明，这个方法严格来说不属于 DataMatcher
  // 本体，是任务书要求并入本文件的。
  // ============================================================
  DataMatcher.prototype.normalizeEducationTypeToYesNo = function (value) {
    var text = String(value === undefined || value === null ? "" : value).trim();
    if (!text) return text;
    if (text === "是" || text === "否") return text;
    if (/^(true|yes|y|1)$/i.test(text)) return "是";
    if (
      /^(false|no|n|0)$/i.test(text) ||
      /非全日制|非统招|不是|没有|无|未|否|自考|成教|函授|网络教育|自学考试|成人|在职|留学生/.test(text)
    ) {
      return "否";
    }
    if (/全日制|统招|有|是/.test(text)) return "是";
    return text;
  };

  AF.DataMatcher = DataMatcher;
})();
