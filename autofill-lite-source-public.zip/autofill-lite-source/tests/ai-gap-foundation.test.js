"use strict";
const assert = require("assert");
const { buildAiGapFoundation, collectSemanticGaps, summarizeCandidateMappings } = require("../ai-gap-foundation");

const semanticRun = {
  postFillGap: { code: "semantic_gap_possible", summary: "存在未处理字段，可能是语义映射缺口", aiSemanticRecommended: true },
  failedFields: [
    { fieldKey: "namePinyin", label: "姓名全拼", reason: "未找到依赖字段标签" },
    { fieldKey: "specialWorkflow", label: "项目经验 第1条", reason: "保存未成功：编辑器仍处于编辑态" }
  ],
  unhandledFields: [
    { fieldKey: "hukouLocation", label: "入学前户口所在地", reason: "未映射字段" },
    { fieldKey: "", label: "未命名字段", reason: "core_count_reconciliation" }
  ]
};
const foundation = buildAiGapFoundation(semanticRun);
assert.strictEqual(foundation.mode, "candidate_only");
assert.strictEqual(foundation.eligible, true);
assert.strictEqual(foundation.policy.autoApply, false);
assert.strictEqual(foundation.policy.autoExecute, false);
assert.strictEqual(foundation.policy.mayClickSaveSubmitApplyDeleteUpload, false);
assert.strictEqual(foundation.policy.mayChooseRepeatRecordOwner, false);
assert.deepStrictEqual(foundation.gaps.map((x) => x.label), ["姓名全拼", "入学前户口所在地"]);

const controlOnly = collectSemanticGaps({
  failedFields: [{ fieldKey: "specialWorkflow", label: "教育第2条", reason: "record ownership 不明确，保存结果未知" }]
});
assert.strictEqual(controlOnly.length, 0, "workflow/ownership failure must never become an AI semantic gap");

const siteCandidate = {
  semanticPatch: {
    fieldMappings: [
      { label: "姓名全拼", category: "basicInfo", fieldKey: "namePinyin", confidence: 0.95, source: "ai_semantic_patch" },
      { label: "入学前户口所在地", category: "basicInfo", fieldKey: "hukouLocation", confidence: 0.97, source: "ai_semantic_patch" },
      { label: "姓名", category: "basicInfo", fieldKey: "name", confidence: 1, source: "local_core_trusted" }
    ]
  }
};
const candidates = summarizeCandidateMappings(siteCandidate, foundation, 20);
assert.strictEqual(candidates.length, 2);
assert.ok(candidates.every((x) => x.label !== "姓名"), "trusted local mapping should not be surfaced as an AI gap candidate");
console.log("ai-gap-foundation.test.js PASS");
