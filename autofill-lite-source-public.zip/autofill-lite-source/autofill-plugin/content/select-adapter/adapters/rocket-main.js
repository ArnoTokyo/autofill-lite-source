// content/select-adapter/adapters/rocket-main.js
// Runs in the page's main world. Content scripts live in an isolated world, and
// React/rc-select-like components can ignore value mutations created there.
(function () {
  "use strict";
  if (window.__AFRocketMainBridge) return;
  window.__AFRocketMainBridge = true;

  function sleep(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, ms);
    });
  }

  function setNativeValue(input, value) {
    var text = String(value == null ? "" : value);
    input.removeAttribute && input.removeAttribute("readonly");
    input.readOnly = false;
    var previous = input.value;
    var descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
    if (descriptor && descriptor.set) descriptor.set.call(input, text);
    else input.value = text;
    if (input._valueTracker && typeof input._valueTracker.setValue === "function") {
      input._valueTracker.setValue(previous);
    }
    input.setAttribute && input.setAttribute("value", text);
  }

  function key(input, type, value, extra) {
    var opts = {
      bubbles: true,
      cancelable: true,
      composed: true,
      key: value || "",
      code: value && value.length === 1 ? "Key" + value.toUpperCase() : value || "",
      keyCode: value && value.length === 1 ? value.charCodeAt(0) : 0,
      which: value && value.length === 1 ? value.charCodeAt(0) : 0,
    };
    if (extra) {
      Object.keys(extra).forEach(function (name) {
        opts[name] = extra[name];
      });
    }
    input.dispatchEvent(new window.KeyboardEvent(type, opts));
  }

  function inputEvent(input, inputType, data) {
    try {
      input.dispatchEvent(new window.InputEvent("beforeinput", {
        bubbles: true,
        cancelable: true,
        composed: true,
        inputType: inputType,
        data: data || null,
      }));
    } catch (e) {}
    input.dispatchEvent(new window.InputEvent("input", {
      bubbles: true,
      cancelable: true,
      composed: true,
      inputType: inputType,
      data: data || null,
    }));
  }

  async function typeSearch(input, value) {
    var text = String(value == null ? "" : value);
    input.removeAttribute && input.removeAttribute("readonly");
    input.readOnly = false;
    input.focus && input.focus();
    input.dispatchEvent(new window.FocusEvent("focus", { bubbles: true, composed: true }));
    input.dispatchEvent(new window.MouseEvent("mousedown", { bubbles: true, cancelable: true, composed: true, view: window }));
    input.dispatchEvent(new window.MouseEvent("mouseup", { bubbles: true, cancelable: true, composed: true, view: window }));
    input.dispatchEvent(new window.MouseEvent("click", { bubbles: true, cancelable: true, composed: true, view: window }));

    setNativeValue(input, "");
    key(input, "keydown", "Backspace", { code: "Backspace", keyCode: 8, which: 8 });
    inputEvent(input, "deleteContentBackward", null);
    key(input, "keyup", "Backspace", { code: "Backspace", keyCode: 8, which: 8 });
    await sleep(80);

    // Chinese school names do not necessarily pass through browser IME in
    // automation, so use both composition and ordinary input signals.
    input.dispatchEvent(new window.CompositionEvent("compositionstart", { bubbles: true, composed: true, data: "" }));
    var composed = "";
    for (var i = 0; i < text.length; i++) {
      var ch = text.charAt(i);
      composed += ch;
      key(input, "keydown", ch);
      key(input, "keypress", ch);
      input.dispatchEvent(new window.CompositionEvent("compositionupdate", { bubbles: true, composed: true, data: composed }));
      setNativeValue(input, composed);
      inputEvent(input, "insertCompositionText", ch);
      inputEvent(input, "insertText", ch);
      key(input, "keyup", ch);
      await sleep(70);
    }
    input.dispatchEvent(new window.CompositionEvent("compositionend", { bubbles: true, composed: true, data: text }));
    setNativeValue(input, text);
    inputEvent(input, "insertText", text);
    input.dispatchEvent(new window.Event("search", { bubbles: true, cancelable: true, composed: true }));
    input.dispatchEvent(new window.Event("change", { bubbles: true, cancelable: true, composed: true }));
    await sleep(120);
    return input.value;
  }

  function textOf(node) {
    return String(
      node && (node.textContent || node.getAttribute && (node.getAttribute("title") || node.getAttribute("aria-label") || node.getAttribute("data-value"))) || ""
    ).replace(/\s+/g, " ").trim();
  }

  function isVisible(node) {
    if (!node || !node.getBoundingClientRect) return false;
    var style = window.getComputedStyle ? window.getComputedStyle(node) : null;
    if (style && (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0)) return false;
    var rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isNearInput(node, input) {
    if (!node || !input || !node.getBoundingClientRect || !input.getBoundingClientRect) return true;
    var nr = node.getBoundingClientRect();
    var ir = input.getBoundingClientRect();
    var horizontalOverlap = Math.min(nr.right, ir.right + 80) - Math.max(nr.left, ir.left - 80);
    var belowOrSamePanel = nr.bottom >= ir.top - 12 && nr.top <= ir.bottom + 420;
    return horizontalOverlap > 0 && belowOrSamePanel;
  }

  function reactPropsOf(node) {
    if (!node) return null;
    var keys = Object.keys(node);
    for (var i = 0; i < keys.length; i++) {
      if (keys[i].indexOf("__reactProps$") === 0 || keys[i].indexOf("__reactEventHandlers$") === 0) {
        return node[keys[i]];
      }
    }
    return null;
  }

  function makeSyntheticLikeEvent(type, target, x, y) {
    return {
      type: type,
      target: target,
      currentTarget: target,
      nativeEvent: {
        type: type,
        target: target,
        currentTarget: target,
        clientX: x,
        clientY: y,
        button: 0,
        buttons: /down|move/.test(type) ? 1 : 0,
      },
      clientX: x,
      clientY: y,
      button: 0,
      buttons: /down|move/.test(type) ? 1 : 0,
      bubbles: true,
      cancelable: true,
      defaultPrevented: false,
      isPropagationStopped: function () { return false; },
      isDefaultPrevented: function () { return false; },
      persist: function () {},
      preventDefault: function () {
        this.defaultPrevented = true;
        if (this.nativeEvent) this.nativeEvent.defaultPrevented = true;
      },
      stopPropagation: function () {},
    };
  }

  function invokeReactOptionHandlers(node, x, y) {
    var option = (node && node.closest && node.closest(".rocket-select-item-option, .rocket-select-item, [role='option'], [data-value], li")) || node;
    var chain = [];
    var cur = node;
    while (cur && chain.length < 5) {
      chain.push(cur);
      if (cur === option) break;
      cur = cur.parentElement;
    }
    if (option && chain.indexOf(option) === -1) chain.push(option);
    var handlerNames = ["onMouseEnter", "onMouseMove", "onPointerDown", "onMouseDown", "onPointerUp", "onMouseUp", "onClick"];
    var called = false;
    chain.forEach(function (el) {
      var props = reactPropsOf(el);
      if (!props) return;
      handlerNames.forEach(function (name) {
        if (typeof props[name] !== "function") return;
        try {
          props[name](makeSyntheticLikeEvent(name.slice(2).toLowerCase(), el, x, y));
          called = true;
        } catch (e) {}
      });
    });
    return called;
  }

  async function clickLikeUser(node) {
    if (!node) return false;
    node = (node.closest && node.closest(".rocket-select-item-option, .rocket-select-item, [role='option'], [data-value], li")) || node;
    try {
      node.scrollIntoView({ block: "nearest", behavior: "auto" });
    } catch (e) {}
    await sleep(60);
    var rect = node.getBoundingClientRect && node.getBoundingClientRect();
    var x = rect ? rect.left + Math.max(2, Math.min(rect.width / 2, rect.width - 2)) : 0;
    var y = rect ? rect.top + Math.max(2, Math.min(rect.height / 2, rect.height - 2)) : 0;
    var target = (x && y && document.elementFromPoint) ? document.elementFromPoint(x, y) : node;
    target = target || node;
    invokeReactOptionHandlers(target, x, y);
    invokeReactOptionHandlers(node, x, y);
    await sleep(60);
    var chain = [target, node];
    var parent = node.parentElement;
    var hops = 0;
    while (parent && hops < 2) {
      chain.push(parent);
      parent = parent.parentElement;
      hops++;
    }
    chain = chain.filter(function (item, index, arr) {
      return item && arr.indexOf(item) === index;
    });
    for (var i = 0; i < chain.length; i++) {
      var el = chain[i];
      ["pointerover", "mouseover", "mousemove", "pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach(function (type) {
        var ev;
        if (type.indexOf("pointer") === 0 && window.PointerEvent) {
          ev = new window.PointerEvent(type, {
            view: window,
            bubbles: true,
            cancelable: true,
            composed: true,
            pointerType: "mouse",
            isPrimary: true,
            clientX: x,
            clientY: y,
            button: 0,
            buttons: /down|move/.test(type) ? 1 : 0,
          });
        } else {
          ev = new window.MouseEvent(type, {
            view: window,
            bubbles: true,
            cancelable: true,
            composed: true,
            clientX: x,
            clientY: y,
            button: 0,
            which: 1,
            buttons: /down|move/.test(type) ? 1 : 0,
          });
        }
        el.dispatchEvent(ev);
      });
      invokeReactOptionHandlers(el, x, y);
      try {
        if (typeof el.click === "function") el.click();
      } catch (e) {}
      await sleep(80);
    }
    return true;
  }

  function findOptionByToken(token) {
    return document.querySelector("[data-af-rocket-option-token='" + String(token).replace(/'/g, "\\'") + "']");
  }

  function findOptionByInputAndValue(inputToken, value) {
    var input = document.querySelector("[data-af-rocket-token='" + String(inputToken).replace(/'/g, "\\'") + "']");
    var target = String(value || "").trim().toLowerCase();
    var listId = input && (input.getAttribute("aria-controls") || input.getAttribute("aria-owns") || "");
    var scopes = [];
    var list = listId ? document.getElementById(listId) : null;
    if (list) scopes.push(list);
    Array.prototype.slice.call(document.querySelectorAll(
      ".rocket-select-dropdown, .rocket-select-dropdown-menu, [id$='_list'], [role='listbox']"
    )).forEach(function (scope) {
      if (scopes.indexOf(scope) === -1) scopes.push(scope);
    });
    var candidates = [];
    scopes.forEach(function (scope) {
      Array.prototype.slice.call(scope.querySelectorAll(
        ".rocket-select-item-option, .rocket-select-dropdown-menu-item, .rocket-select-option, [role='option'], [data-value], li, div, span"
      )).forEach(function (node) {
        var text = textOf(node);
        if (!text || /没有找到学校|添加学校全称|暂无数据|无匹配结果|loading|加载中/i.test(text)) return;
        candidates.push(node);
      });
    });
    Array.prototype.slice.call(document.querySelectorAll("div,span,li,[role='option'],[data-value]")).forEach(function (node) {
      var text = textOf(node);
      if (!text || text.toLowerCase() !== target) return;
      if (!isVisible(node) || !isNearInput(node, input)) return;
      if (node.closest && node.closest(".rocket-select")) return;
      if (candidates.indexOf(node) === -1) candidates.push(node);
    });
    for (var i = 0; i < candidates.length; i++) {
      if (textOf(candidates[i]).toLowerCase() === target) return candidates[i];
    }
    for (var j = 0; j < candidates.length; j++) {
      var text = textOf(candidates[j]).toLowerCase();
      if (text && text.indexOf(target) !== -1 && text.length <= target.length + 2) return candidates[j];
    }
    return null;
  }

  async function clickFirstOptionByPoint(inputToken, value) {
    var input = document.querySelector("[data-af-rocket-token='" + String(inputToken).replace(/'/g, "\\'") + "']");
    if (!input || !input.getBoundingClientRect || !document.elementsFromPoint) throw new Error("input_not_found");
    var targetText = String(value || "").trim().toLowerCase();
    var rect = input.getBoundingClientRect();
    var x = Math.max(2, Math.min(window.innerWidth - 2, rect.left + Math.min(48, Math.max(24, rect.width / 3))));
    var ys = [rect.bottom + 28, rect.bottom + 38, rect.bottom + 50, rect.bottom + 64];
    for (var round = 0; round < 12; round++) {
      for (var i = 0; i < ys.length; i++) {
        var y = Math.max(2, Math.min(window.innerHeight - 2, ys[i]));
        var stack = document.elementsFromPoint(x, y);
        for (var s = 0; s < stack.length; s++) {
          var node = stack[s];
          var text = textOf(node).toLowerCase();
          if (!text || /没有找到学校|添加学校全称|暂无数据|无匹配结果|loading|加载中/i.test(text)) continue;
          if (targetText && text === targetText) {
            await clickLikeUser(node);
            return textOf(node);
          }
        }
      }
      await sleep(120);
    }

    // Last resort: if the option row is visually rendered but text is on a child
    // not exposed in elementsFromPoint, click the usual first-row coordinate.
    var fallbackY = Math.max(2, Math.min(window.innerHeight - 2, rect.bottom + 34));
    var target = document.elementFromPoint(x, fallbackY);
    if (!target) throw new Error("point_target_not_found");
    await clickLikeUser(target);
    return textOf(target);
  }

  async function clickAddSchoolFullName(inputToken, value) {
    var input = document.querySelector("[data-af-rocket-token='" + String(inputToken).replace(/'/g, "\\'") + "']");
    if (!input) throw new Error("input_not_found");
    var targetText = String(value || input.value || "").trim();
    var candidates = Array.prototype.slice.call(document.querySelectorAll("a,button,span,div")).filter(function (node) {
      if (!isVisible(node) || !isNearInput(node, input)) return false;
      var text = textOf(node);
      return /添加学校全称/.test(text);
    });
    candidates.sort(function (a, b) {
      var ar = a.getBoundingClientRect();
      var br = b.getBoundingClientRect();
      return ar.width * ar.height - br.width * br.height;
    });
    var target = candidates[0];
    if (!target) throw new Error("add_school_link_not_found");
    setNativeValue(input, targetText);
    inputEvent(input, "insertText", targetText);
    await clickLikeUser(target);
    return textOf(target);
  }

  window.addEventListener("message", async function (event) {
    if (event.source !== window) return;
    var data = event.data || {};
    if (!data || ["AF_ROCKET_TYPE_REQUEST", "AF_ROCKET_CLICK_REQUEST", "AF_ROCKET_POINT_CLICK_REQUEST", "AF_ROCKET_ADD_SCHOOL_REQUEST"].indexOf(data.type) === -1) return;
    if (data.type === "AF_ROCKET_TYPE_REQUEST" && !data.token) return;
    var ok = false;
    var error = "";
    var value = "";
    try {
      if (data.type === "AF_ROCKET_TYPE_REQUEST") {
        var input = document.querySelector("[data-af-rocket-token='" + String(data.token).replace(/'/g, "\\'") + "']");
        if (!input) throw new Error("input_not_found");
        value = await typeSearch(input, data.value || "");
      } else if (data.type === "AF_ROCKET_CLICK_REQUEST") {
        var option = findOptionByToken(data.token) || findOptionByInputAndValue(data.inputToken, data.value);
        if (!option) throw new Error("option_not_found");
        value = textOf(option);
        await clickLikeUser(option);
      } else if (data.type === "AF_ROCKET_POINT_CLICK_REQUEST") {
        value = await clickFirstOptionByPoint(data.inputToken, data.value);
      } else if (data.type === "AF_ROCKET_ADD_SCHOOL_REQUEST") {
        value = await clickAddSchoolFullName(data.inputToken, data.value);
      }
      ok = true;
    } catch (e) {
      error = e && e.message ? e.message : String(e);
    }
    window.postMessage({
      type: data.type === "AF_ROCKET_ADD_SCHOOL_REQUEST" ? "AF_ROCKET_ADD_SCHOOL_RESULT" : (data.type === "AF_ROCKET_POINT_CLICK_REQUEST" ? "AF_ROCKET_POINT_CLICK_RESULT" : (data.type === "AF_ROCKET_CLICK_REQUEST" ? "AF_ROCKET_CLICK_RESULT" : "AF_ROCKET_TYPE_RESULT")),
      id: data.id,
      ok: ok,
      value: value,
      error: error,
    }, "*");
  });
})();
