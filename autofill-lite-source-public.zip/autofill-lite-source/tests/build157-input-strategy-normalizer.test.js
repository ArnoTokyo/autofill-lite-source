const fs=require('fs');const path=require('path');
const src=fs.readFileSync(path.join(__dirname,'../autofill-plugin/content/form-handler.js'),'utf8');
if(!src.includes('resolveInputStrategy')) throw new Error('missing resolver');
console.log('build157 input strategy ok');
