// content/date-picker/handlers/phoenix.js — Phoenix 日期选择器 (.phoenix-date-picker)
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   工厂分支 Kn.create() case "phoenix": 行46033 -> so
//   so.setValue: 行 47213-47300 (string 走 Gr() 单选; object 走 findSimilarElements+ho() 兄弟填结束,
//     填完开始后 sleep(500)，候选为空时 findSurroundingInputs 兜底)
//   Gr()/Br() (打开面板 + 通用导航器 w()): 行 40943-41005 — 已核实:
//     - 点击目标是 (element.querySelector("input") || element).click()，不是外层容器
//     - 等待 standardSleep() + sleep(200) 后立即取面板，无轮询
//     - 面板 = document.querySelectorAll(".phoenix-date-picker") 里第一个 isElementVisible 的
//       （面板类名与触发器同名，靠可见性区分；不存在 .phoenix-calendar-picker-container/
//        .phoenix-date-picker-dropdown/.phoenix-calendar 这些类名——旧版是凭空猜的，永远匹配不到）
//     - w() 调用参数: 行 41014 (逐参数照搬，见下方 _navigatePanel 调用)
//
// 注: 之前版本面板选择器写错 + 丢弃 endTime，范围日期永远只填开始时间。现按源码修正。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  // 源码 Gr()/Br() (行40943): 打开 phoenix 面板 + 通用导航器选日期
  async function phoenixSingleNavigate(triggerEl, dateStr) {
    var clickTarget = (triggerEl.querySelector && triggerEl.querySelector("input")) || triggerEl;
    clickTarget.click();
    await AF.Utils.sleep(AF.DatePicker._STANDARD_DELAY || 30); // 源码 standardSleep()
    await AF.Utils.sleep(200);
    var panels = document.querySelectorAll(".phoenix-date-picker");
    var panel = Array.from(panels).find(function (p) {
      return AF.DomUtils.isElementVisible(p);
    });
    if (!panel) throw new Error("Phoenix日期选择器未找到或不可见");
    // 源码行41014 w() 参数逐个照搬
    var ok = await AF.DatePicker._navigatePanel({
      container: panel,
      dateString: dateStr,
      headerClickSelector: '[class^="phoenix-calendar-month-panel-year-select"], .phoenix-calendar-year-select',
      yearCellSelector: '[class^="phoenix-calendar-year-panel-year"], .phoenix-calendar-year-panel-year',
      disabledClassList: ["phoenix-calendar-year-panel-last-decade-cell", "phoenix-calendar-year-panel-next-decade-cell"],
      yearBoundarySelector: '[class^="phoenix-calendar-year-panel-decade-select"], .phoenix-calendar-year-panel-decade-select-content',
      nextYearSelector: '[class*="phoenix-calendar-year-panel-next-decade-btn"]',
      prevYearSelector: '[class*="phoenix-calendar-year-panel-prev-decade-btn"]',
      monthPanelSelector: ".phoenix-calendar-month-select",
      monthCellSelector: '[class^="phoenix-calendar-month-panel-month"]',
      dayCellSelector: '[class*="phoenix-calendar-date"]',
      maxRetries: 20,
    });
    if (!ok) throw new Error("Phoenix calendar navigation failed");
    return true;
  }

  AF.DatePicker._registry["phoenix"] = function (element, valueType) {
    return {
      setValue: async function (value) {
        try {
          if (!value) throw new Error("日期为空");
          if (typeof value === "string" || valueType === "string") {
            return await phoenixSingleNavigate(element, value);
          }
          if (typeof value !== "object" || !("startTime" in value) || !("endTime" in value)) {
            throw new Error("当option为对象时，dateValue必须包含startTime和endTime属性");
          }
          // 源码 so.setValue object 分支 (行47240-47280): 先取兄弟候选, 填开始, sleep(500),
          // 再挑"结束"兄弟框填结束; 候选为空时 findSurroundingInputs 兜底
          var candidates = AF.DomUtils.findSimilarElements(element, 4, { sameTag: true, sameClass: true, sameParent: false });
          await phoenixSingleNavigate(element, value.startTime);
          await AF.Utils.sleep(500);
          if (candidates.length > 0) {
            var best = AF.DatePicker._pickEndDateCandidate(element, candidates);
            await phoenixSingleNavigate(best, value.endTime);
          } else {
            var surrounding = AF.DomUtils.findSurroundingInputs(element);
            if (surrounding.length > 0) await phoenixSingleNavigate(surrounding[0], value.endTime);
          }
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
