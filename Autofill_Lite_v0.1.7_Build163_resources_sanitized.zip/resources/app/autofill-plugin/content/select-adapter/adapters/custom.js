// content/select-adapter/adapters/custom.js — 站点配置驱动的自定义适配器 (type: "custom")
// 源码参考: 源码定位手册 第六章表格第18行 "n.n 配置表遍历匹配" —— detectType 在所有框架专属分支
// 都没命中时，会遍历站点/全局配置表 (n.n) 按 container 选择器做兜底匹配 (deobfuscated.js
// 行23559-23568)。原版没有一个独立叫 "CustomSelectAdapter" 的类，这个匹配分支散落在
// detectType/create 里；这里按任务要求把它收敛成一个独立、自包含的适配器文件，
// 专门用来处理"某个具体网站的下拉框跟任何已知 UI 框架都不一样"的情况(例如 51job 的自定义组件)。
// 51job 等站点的绝大部分下拉框已经由 FillEngine/站点配置里的专用逻辑处理，这里只是兜底，
// 所以刻意写得简单：优先用调用方传入的 customSelectors 表 (container/trigger/dropdown/option)，
// 没有的话退化成一套通用启发式扫描 (就近找可点击触发器 -> 找新出现的可见列表 -> 文字匹配点击)。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};
  var H = SA._helpers;

  // 没有配置表时的启发式扫描: 触发器优先用常见 class 关键字，找不到就用 element 本身；
  // 面板用通用下拉面板选择器列表全局搜索。
  var HEURISTIC_TRIGGER_SELECTOR = '[class*="select"], [class*="dropdown"], [class*="picker"], [class*="combo"]';
  var LOCAL_PANEL_SELECTOR = "ul, [class*='select-ul'], [class*='dropdown'], [class*='options'], [role='listbox'], [role='menu']";
  var LOCAL_OPTION_SELECTOR = "li, [role='option'], [class*='select-li'], [class*='option'], [data-value], [value]";
  var SD_CONTAINER_SELECTOR = '[class^="sd-Dropdown-container"], [class*=" sd-Dropdown-container"], [class^="sd-Select-container"], [class*=" sd-Select-container"], [class*="sd-Select"]';
  var SD_TRIGGER_SELECTOR = 'label[class*="sd-Select-container"], [class*="sd-Select-addon"], [role="combobox"], input';
  var SD_PANEL_SELECTOR = [
    ".sugar-portal:not([style*='display: none'])",
    '[class*="sd-Select"][class*="dropdown"]:not([style*="display: none"])',
    '[class*="sd-Dropdown"][class*="dropdown"]:not([style*="display: none"])',
    '[class*="sd-Dropdown-menu"]:not([style*="display: none"])',
    '[class*="sd-Menu-container"]:not([style*="display: none"])',
    '[role="listbox"]:not([aria-hidden="true"])',
  ].join(",");
  var SD_OPTION_SELECTOR = [
    '[class*="sd-Select-common-item"]',
    '[class*="sd-Menu-content-item"]',
    '[class*="sd-Menu-container"]',
    '[class*="sd-Menu-content"]',
    '[class*="sd-Menu-option"]',
    "li",
    '[role="option"]',
    '[data-value]',
    '[class*="option"]',
    '[class*="Option"]',
    '[class*="item"]',
    '[class*="Item"]',
    '[class*="menu"] > div',
    '[class*="list"] > div',
  ].join(",");
  var sdMainBridgePromise = null;

  function pingSdMainBridge(timeoutMs) {
    var id = "af_sd_ping_" + Date.now() + "_" + Math.random().toString(36).slice(2);
    return new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, timeoutMs || 500);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (data.type !== "AF_SD_PING_RESULT" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(true);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({ type: "AF_SD_PING_REQUEST", id: id }, "*");
    });
  }

  function ensureSdMainBridge() {
    if (sdMainBridgePromise) return sdMainBridgePromise;
    sdMainBridgePromise = (async function () {
      if (await pingSdMainBridge(300)) return true;
      return await new Promise(function (resolve) {
        var settled = false;
        function finish(ok) {
          if (settled) return;
          settled = true;
          resolve(!!ok);
        }
        try {
          var script = document.createElement("script");
          script.src = chrome.runtime.getURL("content/select-adapter/adapters/sd-main.js");
          script.async = false;
          script.onload = async function () {
            script.remove && script.remove();
            finish(await pingSdMainBridge(1200));
          };
          script.onerror = function () {
            script.remove && script.remove();
            finish(false);
          };
          (document.documentElement || document.head || document.body).appendChild(script);
          setTimeout(async function () {
            finish(await pingSdMainBridge(500));
          }, 1400);
        } catch (e) {
          finish(false);
        }
      });
    })();
    sdMainBridgePromise.then(function (ok) {
      if (!ok) sdMainBridgePromise = null;
    });
    return sdMainBridgePromise;
  }

  async function typeSdSearchInPage(input, value) {
    if (!input) return false;
    if (!await ensureSdMainBridge()) return false;
    var token = "af_sd_" + Date.now() + "_" + Math.random().toString(36).slice(2);
    var id = token + "_type";
    input.setAttribute("data-af-sd-token", token);
    return await new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, 5500);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (!data || data.type !== "AF_SD_TYPE_RESULT" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: "AF_SD_TYPE_REQUEST",
        id: id,
        token: token,
        value: String(value == null ? "" : value),
      }, "*");
    });
  }

  async function clickSdOptionInPage(option, input, value) {
    if (!await ensureSdMainBridge()) return false;
    var token = "";
    if (option) {
      token = "af_sd_option_" + Date.now() + "_" + Math.random().toString(36).slice(2);
      option.setAttribute("data-af-sd-option-token", token);
    }
    var inputToken = input && input.getAttribute && input.getAttribute("data-af-sd-token") || "";
    var id = (token || inputToken || "af_sd_click") + "_click";
    return await new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMessage);
        resolve(false);
      }, 5500);
      function onMessage(event) {
        if (event.source !== window) return;
        var data = event.data || {};
        if (!data || data.type !== "AF_SD_CLICK_RESULT" || data.id !== id) return;
        if (done) return;
        done = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(!!data.ok);
      }
      window.addEventListener("message", onMessage);
      window.postMessage({
        type: "AF_SD_CLICK_REQUEST",
        id: id,
        token: token,
        inputToken: inputToken,
        value: String(value == null ? "" : value),
      }, "*");
    });
  }

  function resolveConfig(element, customSelectors) {
    if (customSelectors && (customSelectors.container || customSelectors.trigger || customSelectors.dropdown)) {
      return {
        container: customSelectors.container || null,
        trigger: customSelectors.trigger || customSelectors.container || null,
        dropdown: customSelectors.dropdown || null,
        option: customSelectors.option || null,
        searchInput: customSelectors.searchInput || null,
        confirm: customSelectors.confirm || null,
        jbs: customSelectors.jbs === true,
        selectFirstAfterSearch: customSelectors.selectFirstAfterSearch === true,
        waitAfterSearchMs: customSelectors.waitAfterSearchMs,
        maxLevels: customSelectors.maxLevels,
      };
    }
    return null;
  }

  function setSearchValue(input, value) {
    if (!input) return;
    input.focus && input.focus();
    try {
      var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      if (setter) setter.call(input, String(value));
      else input.value = String(value);
    } catch (e) {
      input.value = String(value);
    }
    var lastKey = String(value).slice(-1) || "a";
    input.dispatchEvent(new InputEvent("input", {
      bubbles: true,
      cancelable: true,
      composed: true,
      data: String(value),
      inputType: "insertText",
    }));
    ["keydown", "keypress", "keyup"].forEach(function (eventName) {
      input.dispatchEvent(new KeyboardEvent(eventName, {
        bubbles: true,
        cancelable: true,
        composed: true,
        key: lastKey,
      }));
    });
  }

  async function waitForCcbSearchPanel(container, value, timeoutMs) {
    var startedAt = Date.now();
    while (Date.now() - startedAt < (timeoutMs || 3200)) {
      var panel = container.querySelector(".select_body");
      if (panel && isVisible(panel)) {
        var options = Array.from(panel.querySelectorAll(".select_options_box li")).filter(isVisible);
        if (options.length) return panel;
      }
      await AF.Utils.sleep(100);
    }
    return null;
  }

  function ccbSearchCommitted(container) {
    try {
      var input = container.querySelector(".select_btn_input, .select_search_input");
      var hidden = container.parentElement && container.parentElement.querySelector(".edit_field_value");
      var selectedId = input && input.getAttribute("select_id");
      return !!(selectedId || (hidden && String(hidden.value || "").trim()));
    } catch (e) {
      return false;
    }
  }

  function normalizeCcbOptionText(value) {
    return String(value == null ? "" : value).toLowerCase().replace(/[\s:：()（）\-_/]/g, "");
  }

  function findCcbOption(panel, value) {
    var target = String(value == null ? "" : value).trim();
    var normalizedTarget = normalizeCcbOptionText(target);
    var options = Array.from(panel.querySelectorAll(".select_options_box li")).filter(isVisible);
    return options.find(function (option) {
      return String(option.textContent || "").trim() === target;
    }) || options.find(function (option) {
      var text = String(option.textContent || "").trim();
      var normalizedText = normalizeCcbOptionText(text);
      return normalizedText && normalizedTarget && (
        normalizedText.indexOf(normalizedTarget) !== -1 || normalizedTarget.indexOf(normalizedText) !== -1
      );
    }) || options.find(function (option) {
      try {
        return AF.DomUtils.isOptionMatch(
          String(option.textContent || "").trim(),
          option.getAttribute("value") || "",
          target
        );
      } catch (e) {
        return false;
      }
    }) || null;
  }

  async function clickCcbOption(option) {
    if (!option) return false;
    try { option.scrollIntoView({ block: "nearest", behavior: "auto" }); } catch (e) {}
    try {
      // 建行旧版选择器使用直接绑定在 li 上的 jQuery click 处理器。
      option.click();
      await AF.Utils.sleep(150);
      return true;
    } catch (e2) {
      return AF.DomUtils.safeClickElement(option);
    }
  }

  async function selectCcbSearchValue(container, value) {
    var input = container.querySelector(".select_btn_input, .select_search_input");
    if (!input) return false;
    if (container.classList.contains("search_selector") && !container.classList.contains("multi_search_selector")) {
      var button = container.querySelector(".select_btn");
      if (button) await AF.DomUtils.safeClickElement(button);
    }
    setSearchValue(input, value);
    var panel = await waitForCcbSearchPanel(container, value, 3200);
    if (!panel) return false;
    var selected = await clickCcbOption(findCcbOption(panel, value));
    if (!selected) return false;
    await AF.Utils.sleep(120);
    return ccbSearchCommitted(container);
  }

  async function selectCcbStaticValue(container, value) {
    var button = container.querySelector(".select_btn") || container;
    try { button.click(); } catch (e) { await AF.DomUtils.safeClickElement(button); }
    var panel = await waitForCcbSearchPanel(container, value, 1600);
    if (!panel) return false;
    var selected = await clickCcbOption(findCcbOption(panel, value));
    if (!selected) return false;
    await AF.Utils.sleep(100);
    var display = container.querySelector(".select_btn_text");
    var displayText = String(display && display.textContent || "").trim();
    var wanted = normalizeCcbOptionText(value);
    var actual = normalizeCcbOptionText(displayText);
    return !!(wanted && actual && (actual === wanted || actual.indexOf(wanted) !== -1 || wanted.indexOf(actual) !== -1));
  }

  function visibleJbsDialogs() {
    try {
      return Array.from(document.querySelectorAll(
        ".jbs_cascader_dialog, .functype_cascader_dialog, .jbs_category-dialog, .el-dialog__wrapper"
      )).filter(function (dialog) {
        return isVisible(dialog) && /选择职位|选择行业|选择专业|选择分类|职位|行业|专业/.test(String(dialog.textContent || ""));
      });
    } catch (e) {
      return [];
    }
  }

  async function waitForJbsDialog(timeoutMs) {
    var startedAt = Date.now();
    while (Date.now() - startedAt < (timeoutMs || 2500)) {
      var dialogs = visibleJbsDialogs();
      if (dialogs.length) return dialogs[0];
      await AF.Utils.sleep(100);
    }
    return null;
  }

  function visibleJbsSuggestionPanels() {
    try {
      return Array.from(document.querySelectorAll(
        ".el-autocomplete-suggestion, .el-popper, .jbs_cascader_dialog .el-dialog__body"
      )).filter(isVisible);
    } catch (e) {
      return [];
    }
  }

  function jbsOptionNodes(panel, cfg) {
    var selector = cfg && cfg.option || [
      ".el-autocomplete-suggestion li",
      ".el-autocomplete-suggestion [role='option']",
      ".jbs_cascader_dialog .cascader_panel_item .func-item",
      ".jbs_cascader_dialog .cascader_panel_item",
      ".jbs_cascader_dialog .cascader_item_label"
    ].join(",");
    var roots = [];
    if (panel) roots.push(panel);
    roots = roots.concat(visibleJbsSuggestionPanels());
    var nodes = [];
    roots.forEach(function (root) {
      try {
        Array.from(root.querySelectorAll(selector)).filter(isVisible).forEach(function (node) {
          if (nodes.indexOf(node) === -1) nodes.push(node);
        });
      } catch (e) {}
    });
    return nodes.filter(function (node) {
      var text = String(node.textContent || "").replace(/\s+/g, " ").trim();
      return text && !/选择职位|选择行业|选择专业|取消|确定|确认|自定义/.test(text);
    });
  }

  function jbsSuggestionNodes() {
    var nodes = [];
    visibleJbsSuggestionPanels().forEach(function (root) {
      try {
        Array.from(root.querySelectorAll(".el-autocomplete-suggestion li, .el-autocomplete-suggestion [role='option']"))
          .filter(isVisible).filter(function (node) {
            return !/暂无匹配|无匹配|去选择|请选择分类/.test(String(node.textContent || ""));
          }).forEach(function (node) {
            if (nodes.indexOf(node) === -1) nodes.push(node);
          });
      } catch (e) {}
    });
    return nodes;
  }

  function jbsPrimarySuggestionText(node) {
    if (!node) return "";
    try {
      var primary = node.querySelector(".key-name, .key-name_words");
      if (primary) return String(primary.textContent || "").replace(/\s+/g, " ").trim();
    } catch (e) {}
    return String(node.textContent || "").replace(/\s+/g, " ").trim();
  }

  function jbsSuggestionScore(node, value) {
    var target = normalizeJbsText(value);
    var primary = normalizeJbsText(jbsPrimarySuggestionText(node));
    var full = normalizeJbsText(node && node.textContent);
    if (!target || !primary) return Number.MAX_SAFE_INTEGER;
    if (primary === target) return 0;
    if (primary.indexOf(target) === 0) return 10 + Math.max(0, primary.length - target.length);
    if (primary.indexOf(target) !== -1) return 30 + Math.max(0, primary.length - target.length);
    if (target.indexOf(primary) !== -1) return 50 + Math.max(0, target.length - primary.length);
    if (full.indexOf(target) !== -1) return 80 + Math.max(0, full.length - target.length);
    try {
      if (AF.DomUtils.isOptionMatch(jbsPrimarySuggestionText(node), "", value)) return 120;
    } catch (e) {}
    return 1000 + Math.abs(primary.length - target.length);
  }

  function pickJbsSuggestion(value) {
    var nodes = jbsSuggestionNodes();
    if (!nodes.length) return null;
    return nodes.slice().sort(function (left, right) {
      return jbsSuggestionScore(left, value) - jbsSuggestionScore(right, value);
    })[0] || null;
  }

  function buildJbsSearchQueries(value) {
    var original = String(value == null ? "" : value).replace(/\s+/g, " ").trim();
    var queries = [];
    function add(query) {
      query = String(query || "").replace(/^[\s\-_/]+|[\s\-_/]+$/g, "").trim();
      if (query && queries.indexOf(query) === -1) queries.push(query);
    }
    add(original);
    var simplified = original
      .replace(/[（(][^）)]*[）)]/g, "")
      .replace(/(?:实习生|实习|管培生|储备生|助理)$/g, "")
      .replace(/^(?:B端|C端|G端|To\s*B|To\s*C|to\s*b|to\s*c)[\s\-_/]*/i, "")
      .trim();
    add(simplified);
    // 站内词典往往只有标准职位，简历中的业务端、部门和实习
    // 修饰词并不在词库。提取核心职位作为第三次搜索，仍然优先
    // 使用前两个更精确的词。
    var corePatterns = [
      /产品经理/, /产品运营/, /项目经理/, /数据分析师/, /商业分析师/,
      /软件工程师/, /开发工程师/, /算法工程师/, /测试工程师/, /运维工程师/,
      /设计师/, /运营专员/, /市场专员/, /销售专员/, /财务专员/, /人力资源专员/
    ];
    for (var i = 0; i < corePatterns.length; i++) {
      var matched = simplified.match(corePatterns[i]);
      if (matched) { add(matched[0]); break; }
    }
    return queries;
  }

  function readInputLikeValue(element) {
    try {
      if (!element) return "";
      if (element.tagName === "INPUT" || element.tagName === "TEXTAREA") return String(element.value || "").trim();
      var input = element.querySelector && element.querySelector("input, textarea");
      if (input) return String(input.value || "").trim();
      return String(element.textContent || "").replace(/\s+/g, " ").trim();
    } catch (e) {
      return "";
    }
  }

  function jbsCascaderMenus(panel) {
    try {
      return Array.from((panel || document).querySelectorAll(".jbs_cascader_dialog .cascader_panel_menu, .cascader_panel_menu"))
        .filter(isVisible);
    } catch (e) {
      return [];
    }
  }

  function jbsMenuOptions(menu, cfg) {
    try {
      var selector = cfg && cfg.option || ".cascader_panel_item .func-item, .cascader_panel_item, .cascader_item_label";
      return Array.from(menu.querySelectorAll(selector)).filter(isVisible).filter(function (node) {
        var text = String(node.textContent || "").replace(/\s+/g, " ").trim();
        return text && !/选择职位|选择行业|选择专业|取消|确定|确认|自定义/.test(text);
      });
    } catch (e) {
      return [];
    }
  }

  function pickJbsCascaderOption(panel, value, cfg) {
    var menus = jbsCascaderMenus(panel);
    if (menus.length) {
      var allOptions = menus.reduce(function (nodes, menu) {
        return nodes.concat(jbsMenuOptions(menu, cfg));
      }, []);
      var matched = pickJbsOption(allOptions, value, false);
      if (matched) {
        var matchedText = normalizeJbsText(matched.textContent);
        var targetText = normalizeJbsText(value);
        if (matchedText && targetText && (matchedText.indexOf(targetText) !== -1 || targetText.indexOf(matchedText) !== -1)) {
          return matched;
        }
      }
      for (var i = menus.length - 1; i >= 0; i--) {
        var options = jbsMenuOptions(menus[i], cfg);
        if (options.length) return pickJbsOption(options, value, !!(cfg && cfg.selectFirstAfterSearch));
      }
    }
    return pickJbsOption(jbsOptionNodes(panel, cfg), value, !!(cfg && cfg.selectFirstAfterSearch));
  }

  function normalizeJbsText(text) {
    return String(text == null ? "" : text).toLowerCase().replace(/[\s:：()（）\-_/，,、]/g, "");
  }

  function pickJbsOption(nodes, value, selectFirstAfterSearch) {
    var target = String(value == null ? "" : value).trim();
    var normalizedTarget = normalizeJbsText(target);
    var exact = nodes.find(function (node) {
      return String(node.textContent || "").trim() === target;
    });
    if (exact) return exact;
    var fuzzy = nodes.find(function (node) {
      var text = String(node.textContent || "").trim();
      var normalized = normalizeJbsText(text);
      return normalized && normalizedTarget && (
        normalized.indexOf(normalizedTarget) !== -1 ||
        normalizedTarget.indexOf(normalized) !== -1
      );
    });
    if (fuzzy) return fuzzy;
    if (selectFirstAfterSearch && nodes.length) return nodes[0];
    try {
      return nodes.find(function (node) {
        return AF.DomUtils.isOptionMatch(String(node.textContent || "").trim(), "", target);
      }) || nodes[0] || null;
    } catch (e) {
      return nodes[0] || null;
    }
  }

  async function clickJbsOption(option) {
    if (!option) return false;
    try { option.scrollIntoView({ block: "nearest", behavior: "auto" }); } catch (e) {}
    await AF.Utils.sleep(80);
    var clicked = await AF.DomUtils.safeClickElement(option);
    if (!clicked) {
      try { option.click(); clicked = true; } catch (e) {}
    }
    await AF.Utils.sleep(300);
    return !!clicked;
  }

  async function confirmJbsDialog(panel, cfg) {
    var selector = cfg && cfg.confirm || "button.el-button--primary, .confirm_button, button";
    var dialogs = visibleJbsDialogs();
    var root = panel || dialogs[0] || document;
    var buttons = [];
    try { buttons = Array.from(root.querySelectorAll(selector)).filter(isVisible); } catch (e) {}
    var confirm = buttons.find(function (button) {
      return /确定|确认|完\s*成|保存/.test(String(button.textContent || ""));
    });
    if (confirm) {
      await AF.DomUtils.safeClickElement(confirm);
      await AF.Utils.sleep(250);
    }
    return true;
  }

  async function selectJbsSearchValue(element, value, cfg) {
    var trigger = (cfg && cfg.trigger && element.closest && (element.closest(cfg.container || ".el-form-item") || document).querySelector(cfg.trigger)) || element;
    var beforeValue = readInputLikeValue(trigger);
    await AF.DomUtils.safeClickElement(trigger);
    var panel = await waitForJbsDialog(2800);
    if (!panel) return false;

    var searchInput = null;
    try {
      searchInput = (cfg && cfg.searchInput && panel.querySelector(cfg.searchInput)) ||
        panel.querySelector(".jbs_suggest input, input[placeholder*='搜索'], input[role='textbox']");
    } catch (e) {}
    if (searchInput && value) {
      // 51job 职位/专业搜索会在 Element autocomplete 中返回已经
      // 携带分类路径的最终叶子节点。直接点最相似的搜索结果即会
      // 关闭大弹窗并回填，比重新遍历三层菜单更快也更准。
      var searchQueries = buildJbsSearchQueries(value);
      var searchedOption = null;
      for (var queryIndex = 0; queryIndex < searchQueries.length && !searchedOption; queryIndex++) {
        var query = searchQueries[queryIndex];
        setSearchValue(searchInput, query);
        await AF.Utils.sleep(cfg && cfg.waitAfterSearchMs == null ? 850 : cfg && cfg.waitAfterSearchMs);
        searchedOption = await (async function () {
          var startedAt = Date.now();
          while (Date.now() - startedAt < (cfg && cfg.searchOptionTimeoutMs || 1800)) {
            var candidate = pickJbsSuggestion(query);
            if (candidate) return candidate;
            await AF.Utils.sleep(100);
          }
          return null;
        })();
      }
      if (searchedOption) {
        if (!await clickJbsOption(searchedOption)) return false;
        await AF.Utils.sleep(cfg && cfg.waitAfterSearchSelectMs == null ? 350 : cfg && cfg.waitAfterSearchSelectMs);
        var searchedValue = readInputLikeValue(trigger);
        if ((searchedValue && searchedValue !== beforeValue) || !visibleJbsDialogs().length) return true;
      }
    }

    // 启用搜索的职位/专业控件，若多组搜索词仍无结果，不能
    // 在三层菜单里盲选当前默认的“销售专员”。只有未配置搜索
    // 输入框的纯级联控件，才允许进入下面的菜单路径逻辑。
    if (searchInput && cfg && cfg.disableMenuFallbackAfterSearch !== false) return false;

    var lastClickedKey = "";
    for (var level = 0; level < (cfg && cfg.maxLevels || 5); level++) {
      panel = visibleJbsDialogs()[0] || panel;
      if (!panel || !isVisible(panel)) break;
      var option = null;
      var startedAt = Date.now();
      while (Date.now() - startedAt < 2500) {
        option = pickJbsCascaderOption(panel, value, cfg);
        if (option) break;
        await AF.Utils.sleep(120);
      }
      if (!option) break;
      var optionText = String(option.textContent || "").replace(/\s+/g, " ").trim();
      var key = level + ":" + optionText + ":" + jbsCascaderMenus(panel).length;
      if (key === lastClickedKey) break;
      lastClickedKey = key;
      if (!await clickJbsOption(option)) return false;
      await AF.Utils.sleep(350);
      var afterValue = readInputLikeValue(trigger);
      if (afterValue && afterValue !== beforeValue) return true;
      if (!visibleJbsDialogs().length) return true;
    }
    await confirmJbsDialog(panel, cfg);
    await AF.Utils.sleep(250);
    var finalValue = readInputLikeValue(trigger);
    return !!(finalValue && finalValue !== beforeValue) || !visibleJbsDialogs().length;
  }

  function findPlainPopupWithExactOption(element, value) {
    try {
      var target = String(value == null ? "" : value).replace(/\s+/g, " ").trim().toLowerCase();
      if (!target) return null;
      var selectors = [
        "ul", "ol", "[role='listbox']", "[role='menu']",
        "[class*='dropdown']", "[class*='options']", "[class*='option-list']",
        "[class*='popup']", "[class*='menu']", "[class*='select-list']"
      ].join(",");
      var candidates = Array.from(document.querySelectorAll(selectors)).filter(function (panel) {
        if (!panel || panel === element || !isVisible(panel)) return false;
        var options = H.getOptionNodes(panel, LOCAL_OPTION_SELECTOR);
        return options.some(function (node) {
          return String(node && node.textContent || "").replace(/\s+/g, " ").trim().toLowerCase() === target;
        });
      });
      if (!candidates.length) return null;
      if (candidates.length === 1 || !element.getBoundingClientRect) return candidates[0];
      var ref = element.getBoundingClientRect();
      candidates.sort(function (a, b) {
        var ra = a.getBoundingClientRect();
        var rb = b.getBoundingClientRect();
        var da = Math.abs(ra.left - ref.left) + Math.abs(ra.top - ref.bottom);
        var db = Math.abs(rb.left - ref.left) + Math.abs(rb.top - ref.bottom);
        return da - db;
      });
      return candidates[0];
    } catch (e) {
      return null;
    }
  }

  async function selectOneCustomValue(element, value, cfg) {
    var container = (cfg && cfg.container && element.closest(cfg.container)) ||
      (element.closest && element.closest(".multi_search_selector, .search_selector, .select_box, .multi_select_box")) ||
      element;
    if ((cfg && cfg.jbs) || (element.closest && element.closest(".el-form-item") && /51job\.com/i.test(location.hostname))) {
      if (await selectJbsSearchValue(element, value, cfg || {})) return true;
    }
    if (container.matches && container.matches(".multi_search_selector, .search_selector") && container.querySelector(".select_btn_input, .select_search_input")) {
      return await selectCcbSearchValue(container, value);
    }
    if (container.matches && container.matches(".select_box, .multi_select_box") && container.querySelector(".select_options_box")) {
      return await selectCcbStaticValue(container, value);
    }
    var trigger = (cfg && cfg.trigger && container.querySelector(cfg.trigger)) || container.querySelector(HEURISTIC_TRIGGER_SELECTOR) || container;

    trigger.focus && trigger.focus();
    await AF.DomUtils.safeClickElement(trigger);
    await AF.Utils.sleep(200);

    var panel = null;
    if (cfg && cfg.dropdown) {
      panel = H.findVisibleDropdownNear(element, cfg.dropdown, cfg.container) || (await H.waitForVisibleDropdownNear(element, cfg.dropdown, cfg.container, 1500));
    } else {
      panel = findLocalPanel(container) || H.findDropdown(element) || (await H.waitForVisibleDropdownNear(element, H.GENERIC_DROPDOWN_SELECTOR, null, 1500));
    }
    var selected = false;
    if (panel) selected = await H.selectMatchingOption(panel, value, (cfg && cfg.dropdown) || LOCAL_OPTION_SELECTOR);
    if (selected) return true;
    var exactPlainPanel = findPlainPopupWithExactOption(element, value);
    if (!exactPlainPanel || exactPlainPanel === panel) return false;
    return await H.selectMatchingOption(exactPlainPanel, value, LOCAL_OPTION_SELECTOR);
  }

  function findLocalPanel(container) {
    try {
      var panels = Array.from(container.querySelectorAll(LOCAL_PANEL_SELECTOR)).filter(function (panel) {
        return panel !== container && AF.DomUtils.isElementVisible(panel) && panel.querySelector(LOCAL_OPTION_SELECTOR);
      });
      return panels[0] || (container.querySelector(LOCAL_OPTION_SELECTOR) ? container : null);
    } catch (e) {
      return null;
    }
  }

  async function triggerCustomSelect(element, value, customSelectors) {
    try {
      if (!element || value === undefined || value === null || value === "") return false;
      var cfg = resolveConfig(element, customSelectors);

      var ok;
      if (Array.isArray(value)) {
        ok = false;
        for (var i = 0; i < value.length; i++) {
          var one = await selectOneCustomValue(element, value[i], cfg);
          if (one) ok = true;
          await AF.Utils.sleep(150);
        }
      } else {
        ok = await selectOneCustomValue(element, value, cfg);
      }
      H.dispatchChangeEvents(element);
      return ok;
    } catch (e) {
      return false;
    }
  }

  function normalizeLegacyZhiyeLocation(value) {
    return String(value == null ? "" : value)
      .replace(/市辖区/g, "")
      .replace(/[\s:：,，。._\-\/\\|>＞]/g, "")
      .toLowerCase();
  }

  function visibleLegacyZhiyeAddressPopup() {
    try {
      return Array.from(document.querySelectorAll(".bas_select_wrap")).find(isVisible) || null;
    } catch (e) {
      return null;
    }
  }

  async function waitForLegacyZhiyeAddressPopup(timeoutMs) {
    var startedAt = Date.now();
    while (Date.now() - startedAt < (timeoutMs || 2200)) {
      var popup = visibleLegacyZhiyeAddressPopup();
      if (popup) return popup;
      await AF.Utils.sleep(80);
    }
    return null;
  }

  function legacyZhiyeAddressOptions(popup) {
    if (!popup) return [];
    return Array.from(popup.querySelectorAll(".bas_select_ctt .lst_item")).filter(function (item) {
      return isVisible(item) && item.querySelector("label[title]");
    });
  }

  function legacyZhiyeAddressOptionText(item) {
    var label = item && item.querySelector("label[title]");
    return String(label && (label.getAttribute("title") || label.textContent) || "").trim();
  }

  function chooseLegacyZhiyeAddressOption(popup, target) {
    var normalizedTarget = normalizeLegacyZhiyeLocation(target);
    var candidates = legacyZhiyeAddressOptions(popup).map(function (item) {
      var text = legacyZhiyeAddressOptionText(item);
      var normalized = normalizeLegacyZhiyeLocation(text);
      var included = normalized && normalizedTarget && normalizedTarget.indexOf(normalized) !== -1;
      var reverseIncluded = normalized && normalizedTarget && normalized.indexOf(normalizedTarget) !== -1;
      return {
        item: item,
        text: text,
        normalized: normalized,
        score: included ? 10000 + normalized.length : (reverseIncluded ? 5000 + normalizedTarget.length : 0),
      };
    }).filter(function (candidate) {
      return candidate.score > 0 && !/^(全国|其他)$/.test(candidate.text);
    }).sort(function (a, b) {
      return b.score - a.score;
    });
    return candidates[0] || null;
  }

  function legacyZhiyeAddressSignature(popup) {
    return legacyZhiyeAddressOptions(popup).map(legacyZhiyeAddressOptionText).join("|");
  }

  async function cancelLegacyZhiyeAddress(popup) {
    try {
      var cancel = popup && popup.querySelector(".bas_btn_canc");
      if (cancel) cancel.click();
      await AF.Utils.sleep(100);
    } catch (e) {}
  }

  async function selectLegacyZhiyeAddress(element, value) {
    if (!element || value === undefined || value === null || value === "") return false;
    var target = Array.isArray(value) ? value.filter(Boolean).join("") : String(value);
    var normalizedTarget = normalizeLegacyZhiyeLocation(target);
    if (!normalizedTarget) return false;
    var beforeValue = String(element.value || "").trim();
    var hidden = element.parentElement && element.parentElement.querySelector("input[type='hidden']");
    var beforeHidden = String(hidden && hidden.value || "").trim();

    try {
      element.click();
    } catch (e) {
      await AF.DomUtils.safeClickElement(element);
    }
    var popup = await waitForLegacyZhiyeAddressPopup(2500);
    if (!popup) return false;

    var selected = false;
    var usedOptions = {};
    var remainingTarget = normalizedTarget;
    for (var level = 0; level < 4; level++) {
      var candidate = chooseLegacyZhiyeAddressOption(popup, remainingTarget);
      if (!candidate || usedOptions[candidate.text]) break;
      usedOptions[candidate.text] = true;

      // 老版组件只用 `pr` 标记仍可继续下钻的省/市节点；叶子节点也可能
      // 带空的 iconfont，占位图标不能据此判断还有下一级。
      var hasChildren = candidate.item.classList.contains("pr");
      remainingTarget = remainingTarget.replace(candidate.normalized, "");
      var remaining = remainingTarget;
      var shouldDescend = hasChildren && remaining.length >= 2;
      if (shouldDescend) {
        var beforeSignature = legacyZhiyeAddressSignature(popup);
        var label = candidate.item.querySelector("label[title]") || candidate.item;
        label.click();
        var changed = false;
        var waitStartedAt = Date.now();
        while (Date.now() - waitStartedAt < 1600) {
          await AF.Utils.sleep(80);
          if (legacyZhiyeAddressSignature(popup) !== beforeSignature) {
            changed = true;
            break;
          }
        }
        if (!changed) break;
        continue;
      }

      var radio = candidate.item.querySelector('input[type="radio"], input[type="checkbox"]');
      if (radio) radio.click();
      else candidate.item.click();
      await AF.Utils.sleep(120);
      selected = Boolean(
        candidate.item.querySelector('input[type="radio"]:checked, input[type="checkbox"]:checked') ||
        popup.querySelector(".bas_select_slted li, .items_selected li")
      );
      break;
    }

    if (!selected) {
      await cancelLegacyZhiyeAddress(popup);
      return false;
    }
    var confirm = popup.querySelector(".bas_btn_save");
    if (!confirm) {
      await cancelLegacyZhiyeAddress(popup);
      return false;
    }
    confirm.click();
    await AF.Utils.sleep(250);

    var afterValue = String(element.value || "").trim();
    var afterHidden = String(hidden && hidden.value || "").trim();
    var normalizedAfter = normalizeLegacyZhiyeLocation(afterValue);
    return Boolean(
      (afterValue && afterValue !== beforeValue) ||
      (afterHidden && afterHidden !== beforeHidden) ||
      (normalizedAfter && (normalizedTarget.indexOf(normalizedAfter) !== -1 || normalizedAfter.indexOf(normalizedTarget) !== -1))
    );
  }

  function isVisible(el) {
    return !!(el && AF.DomUtils && AF.DomUtils.isElementVisible(el));
  }

  function sdContainer(element) {
    if (!element || !element.closest) return element;
    return element.closest(SD_CONTAINER_SELECTOR) || element;
  }

  function sdTrigger(container) {
    if (!container || !container.querySelector) return container;
    return (
      container.querySelector('label[class*="sd-Select-container"]') ||
      container.querySelector('[class*="sd-Select-addon"]') ||
      container.querySelector('[role="combobox"]') ||
      container.querySelector("input") ||
      container
    );
  }

  function sdInput(container) {
    if (!container) return null;
    if (container.tagName === "INPUT") return container;
    return container.querySelector && container.querySelector('input[type="text"], input[type="search"], input:not([type])');
  }

  function sdReadValue(container) {
    try {
      var display = container.querySelector && container.querySelector('[class*="sd-Input-display-value"]');
      var displayText = display ? String(display.textContent || "").trim() : "";
      if (displayText) return displayText;
      return "";
    } catch (e) {
      return "";
    }
  }

  function sdReadDisplayValue(container) {
    try {
      var display = container && container.querySelector && container.querySelector('[class*="sd-Input-display-value"]');
      return String(display && display.textContent || "").replace(/\s+/g, " ").trim();
    } catch (e) {
      return "";
    }
  }

  function normalizeSdText(text) {
    return String(text == null ? "" : text)
      .toLowerCase()
      .replace(/\s+/g, "")
      .replace(/[年月日:：,，。.\-_/]/g, "");
  }

  function sdTextMatches(optionText, value) {
    var option = String(optionText || "").trim();
    var target = String(value == null ? "" : value).trim();
    if (!option || !target) return false;
    if (option === target) return true;
    var o = normalizeSdText(option);
    var t = normalizeSdText(target);
    if (!o || !t) return false;
    if (/^\d+$/.test(o) && /^\d+$/.test(t)) return parseInt(o, 10) === parseInt(t, 10);
    if (o === t || o.indexOf(t) !== -1 || t.indexOf(o) !== -1) return true;
    var om = option.match(/(\d{1,2})\s*月/);
    var tm = target.match(/^0?(\d{1,2})$/);
    if (om && tm && parseInt(om[1], 10) === parseInt(tm[1], 10)) return true;
    try {
      return AF.DomUtils.isOptionMatch(option, option, target) || AF.DomUtils.isSimilarText(option, target);
    } catch (e) {
      return false;
    }
  }

  function visibleSdPanels(refEl) {
    try {
      var panels = Array.from(document.querySelectorAll(SD_PANEL_SELECTOR)).filter(isVisible);
      if (panels.length <= 1 || !refEl || !refEl.getBoundingClientRect) return panels;
      var refRect = refEl.getBoundingClientRect();
      panels.sort(function (a, b) {
        function dist(panel) {
          var r = panel.getBoundingClientRect();
          var horizontalGap = 0;
          if (r.right < refRect.left) horizontalGap = refRect.left - r.right;
          else if (r.left > refRect.right) horizontalGap = r.left - refRect.right;
          else horizontalGap = Math.abs(r.left - refRect.left) * 0.25;
          var belowGap = Math.abs(r.top - refRect.bottom);
          var aboveGap = Math.abs(r.bottom - refRect.top);
          var verticalGap = Math.min(belowGap, aboveGap);
          var overlapBonus = r.left <= refRect.right && r.right >= refRect.left ? -80 : 0;
          return horizontalGap + verticalGap + overlapBonus;
        }
        return dist(a) - dist(b);
      });
      return panels;
    } catch (e) {
      return [];
    }
  }

  async function waitForSdPanels(refEl, timeoutMs) {
    var start = Date.now();
    while (Date.now() - start < (timeoutMs || 2500)) {
      var panels = visibleSdPanels(refEl);
      if (panels.length) return panels;
      await AF.Utils.sleep(80);
    }
    return [];
  }

  async function waitForSdPanelsWithOptions(refEl, timeoutMs) {
    var start = Date.now();
    var lastPanels = [];
    while (Date.now() - start < (timeoutMs || 6500)) {
      var panels = visibleSdPanels(refEl);
      if (panels.length) lastPanels = panels;
      var readyPanels = panels.filter(function (panel) {
        return sdOptions(panel).length > 0;
      });
      if (readyPanels.length) return readyPanels;
      await AF.Utils.sleep(120);
    }
    return lastPanels;
  }

  function normalizeSdOptionNode(panel, node) {
    try {
      if (!node || !node.closest) return node;
      var item = node.closest('[class*="sd-Select-common-item"], [class*="sd-Menu-content-item"], [class*="sd-Menu-container"], [role="option"], [data-value]');
      if (item && panel.contains(item) && item !== panel) return item;
    } catch (e) {}
    return node;
  }

  function sdOptionText(node) {
    try {
      var main = node.querySelector && node.querySelector(".sd-Menu-content-item-37fPj");
      var text = String(
        (main && main.textContent) ||
        node.getAttribute("title") ||
        node.getAttribute("data-value") ||
        node.textContent ||
        ""
      ).replace(/\s+/g, " ").trim();
      return text;
    } catch (e) {
      return "";
    }
  }

  function sdOptions(panel) {
    try {
      var seen = new Set();
      var raw = [];
      if (panel.matches && panel.matches(SD_OPTION_SELECTOR)) raw.push(panel);
      raw = raw.concat(Array.from(panel.querySelectorAll(SD_OPTION_SELECTOR)));
      return raw.map(function (node) {
        return normalizeSdOptionNode(panel, node);
      }).filter(function (node) {
        if (!node || seen.has(node)) return false;
        seen.add(node);
        if (!isVisible(node)) return false;
        if (node.getAttribute("aria-disabled") === "true" || node.disabled) return false;
        if (node === panel && !(node.matches && node.matches('[class*="sd-Menu-container"], [class*="sd-Select-common-item"], [role="option"], [data-value]'))) return false;
        if (node.classList && node.classList.contains("sugar-portal")) return false;
        var text = sdOptionText(node);
        if (!text || text.length > 120) return false;
        try {
          var rect = node.getBoundingClientRect();
          if (rect.width <= 0 || rect.height <= 0) return false;
        if (rect.height > 96 && !node.getAttribute("role") && !node.hasAttribute("data-value") && !(node.classList && String(node.className || "").indexOf("sd-Menu") !== -1)) return false;
        } catch (e2) {}
        return true;
      });
    } catch (e) {
      return [];
    }
  }

  function sdOptionScore(node, value) {
    var text = sdOptionText(node);
    var target = String(value == null ? "" : value).trim();
    var score = 0;
    if (text === target) score += 1000;
    if (normalizeSdText(text) === normalizeSdText(target)) score += 500;
    if (node.matches && node.matches('[class*="sd-Select-common-item"]')) score += 120;
    if (node.getAttribute("role") === "option") score += 80;
    if (node.hasAttribute("data-value")) score += 60;
    var cls = String(node.className || "");
    if (/option|item|menu/i.test(cls)) score += 40;
    try {
      var rect = node.getBoundingClientRect();
      if (rect.height > 0 && rect.height <= 64) score += 30;
      score -= Math.max(0, text.length - target.length);
      score -= Math.max(0, rect.height - 64);
    } catch (e) {}
    return score;
  }

  function sdSelectionSettled(container, value) {
    return sdTextMatches(sdReadDisplayValue(container), value);
  }

  function sdDropdownStillOpen(container) {
    try {
      return visibleSdPanels(container).some(function (panel) {
        if (!panel.getBoundingClientRect || !container || !container.getBoundingClientRect) return true;
        var pr = panel.getBoundingClientRect();
        var cr = container.getBoundingClientRect();
        var overlapsX = pr.left <= cr.right + 80 && pr.right >= cr.left - 80;
        var nearY = Math.abs(pr.top - cr.bottom) < 360 || Math.abs(pr.bottom - cr.top) < 360;
        return overlapsX && nearY;
      });
    } catch (e) {
      return false;
    }
  }

  async function realisticClick(el) {
    if (!el) return false;
    try {
      el.scrollIntoView({ block: "nearest", behavior: "auto" });
    } catch (e) {}
    await AF.Utils.sleep(120);
    try {
      var rect = el.getBoundingClientRect();
      var x = Math.max(rect.left + 6, Math.min(rect.left + rect.width / 2, window.innerWidth - 3));
      var y = Math.max(rect.top + 6, Math.min(rect.top + rect.height / 2, window.innerHeight - 3));
      var target = document.elementFromPoint(x, y) || el;
      if (target.closest && !target.closest('[class*="sd-Select-common-item"], [role="option"], [data-value]')) {
        target = el.querySelector && (
          el.querySelector(".sd-Menu-content-item-37fPj") ||
          el.querySelector(".sd-Menu-content-2vKOA") ||
          el.querySelector(".sd-Menu-container-3HY1z")
        ) || el;
      }
      var events = ["pointerover", "mouseover", "mouseenter", "mousemove", "pointerenter", "pointermove", "pointerdown", "mousedown", "pointerup", "mouseup", "click"];
      for (var i = 0; i < events.length; i++) {
        var type = events[i];
        var init = {
          view: window,
          bubbles: true,
          cancelable: true,
          composed: true,
          clientX: x,
          clientY: y,
          screenX: x,
          screenY: y,
          buttons: /down/.test(type) ? 1 : 0,
          button: 0,
          detail: /click|down|up/.test(type) ? 1 : 0,
        };
        if (/^pointer/.test(type) && typeof PointerEvent !== "undefined") {
          init.pointerId = 1;
          init.pointerType = "mouse";
          init.isPrimary = true;
        }
        var event = /^pointer/.test(type) && typeof PointerEvent !== "undefined"
          ? new PointerEvent(type, init)
          : new MouseEvent(type, init);
        target.dispatchEvent(event);
        if (/down$/.test(type)) await AF.Utils.sleep(80);
        else if (/up$|click$/.test(type)) await AF.Utils.sleep(60);
        else await AF.Utils.sleep(20);
      }
      await AF.Utils.sleep(320);
      return true;
    } catch (e2) {
      return await H.clickOption(el);
    }
  }

  async function waitForSdSelectionSettled(container, value, timeoutMs) {
    var start = Date.now();
    while (Date.now() - start < (timeoutMs || 1200)) {
      if (sdSelectionSettled(container, value)) {
        await AF.Utils.sleep(260);
        return true;
      }
      await AF.Utils.sleep(80);
    }
    return sdSelectionSettled(container, value);
  }

  async function waitForSdCommitOrClose(container, value, timeoutMs) {
    var start = Date.now();
    while (Date.now() - start < (timeoutMs || 2500)) {
      if (sdSelectionSettled(container, value)) {
        await AF.Utils.sleep(360);
        return true;
      }
      if (!sdDropdownStillOpen(container) && sdSelectionSettled(container, value)) return true;
      await AF.Utils.sleep(100);
    }
    return sdSelectionSettled(container, value);
  }

  async function typeSdSearch(input, value) {
    if (!input || input.disabled || input.readOnly) return false;
    var text = String(value);
    input.focus && input.focus();
    try {
      var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      if (setter) setter.call(input, "");
      else input.value = "";
    } catch (e) {
      input.value = "";
    }
    input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    await AF.Utils.sleep(50);
    try {
      var setter2 = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      if (setter2) setter2.call(input, text);
      else input.value = text;
    } catch (e2) {
      input.value = text;
    }
    ["compositionstart", "compositionupdate", "input", "keydown", "keyup", "search", "change"].forEach(function (type) {
      try {
        var event = type === "keydown" || type === "keyup"
          ? new KeyboardEvent(type, { bubbles: true, cancelable: true, key: text.slice(-1) || "a" })
          : new Event(type, { bubbles: true, cancelable: true, composed: true });
        input.dispatchEvent(event);
      } catch (e3) {}
    });
    await AF.Utils.sleep(500);
    return true;
  }

  async function dispatchSdKey(input, key, code, keyCode) {
    if (!input) return false;
    try {
      input.focus && input.focus();
      var container = sdContainer(input);
      var label = container && container.querySelector && container.querySelector('label[class*="sd-Select-container"], label[class*="sd-Input-container"]');
      var targets = [input, document.activeElement, label, container, document].filter(Boolean);
      targets = Array.from(new Set(targets));
      ["keydown", "keypress", "keyup"].forEach(function (type) {
        targets.forEach(function (target) {
          try {
            target.dispatchEvent(new KeyboardEvent(type, {
              bubbles: true,
              cancelable: true,
              key: key,
              code: code,
              keyCode: keyCode,
              which: keyCode,
            }));
          } catch (e) {}
        });
      });
      return true;
    } catch (e2) {
      return false;
    }
  }

  async function commitSdKeyboard(input, enterOnly) {
    if (!input) return false;
    try {
      input.focus && input.focus();
      if (enterOnly) {
        await dispatchSdKey(input, "Enter", "Enter", 13);
        input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
        await AF.Utils.sleep(300);
        return true;
      }
      var keys = [
        { type: "keydown", key: "ArrowDown", code: "ArrowDown", keyCode: 40 },
        { type: "keyup", key: "ArrowDown", code: "ArrowDown", keyCode: 40 },
        { type: "keydown", key: "Enter", code: "Enter", keyCode: 13 },
        { type: "keyup", key: "Enter", code: "Enter", keyCode: 13 },
      ];
      for (var i = 0; i < keys.length; i++) {
        var k = keys[i];
        input.dispatchEvent(new KeyboardEvent(k.type, {
          bubbles: true,
          cancelable: true,
          key: k.key,
          code: k.code,
          keyCode: k.keyCode,
          which: k.keyCode,
        }));
        await AF.Utils.sleep(80);
      }
      input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      await AF.Utils.sleep(300);
      return true;
    } catch (e) {
      return false;
    }
  }

  function findSdBestOption(panels, value, refEl) {
    var options = [];
    panels.forEach(function (panel, panelIndex) {
      options = options.concat(sdOptions(panel).map(function (node) {
        return { node: node, panelIndex: panelIndex };
      }));
    });
    var seen = new Set();
    var unique = options.filter(function (entry) {
      if (seen.has(entry.node)) return false;
      seen.add(entry.node);
      return true;
    });
    var matches = unique.filter(function (entry) {
      var node = entry.node;
      var text = sdOptionText(node);
      return sdTextMatches(text, value);
    });
    matches.sort(function (a, b) {
      function score(entry) {
        var optionScore = sdOptionScore(entry.node, value) - entry.panelIndex * 120;
        if (refEl && refEl.getBoundingClientRect && entry.node.getBoundingClientRect) {
          try {
            var refRect = refEl.getBoundingClientRect();
            var rect = entry.node.getBoundingClientRect();
            var dy = Math.min(Math.abs(rect.top - refRect.bottom), Math.abs(rect.bottom - refRect.top));
            optionScore -= Math.min(200, dy * 0.2);
          } catch (e) {}
        }
        return optionScore;
      }
      return score(b) - score(a);
    });
    if (matches[0]) return matches[0].node;
    return null;
  }

  function findSdFirstUsableOption(panels, refEl) {
    var options = [];
    panels.forEach(function (panel, panelIndex) {
      options = options.concat(sdOptions(panel).map(function (node) {
        return { node: node, panelIndex: panelIndex };
      }));
    });
    var seen = new Set();
    options = options.filter(function (entry) {
      if (!entry.node || seen.has(entry.node)) return false;
      seen.add(entry.node);
      return true;
    });
    options.sort(function (a, b) {
      function score(entry) {
        var cls = String(entry.node.className || "");
        var s = -entry.panelIndex * 120;
        if (/pointer|active|selected|hover|highlight|focus/i.test(cls)) s += 800;
        if (entry.node.matches && entry.node.matches('[class*="sd-Select-common-item"], [class*="sd-Menu-content-item"], [class*="sd-Menu-container"], [role="option"]')) s += 160;
        try {
          var rect = entry.node.getBoundingClientRect();
          s -= Math.max(0, rect.top);
          if (refEl && refEl.getBoundingClientRect) {
            var refRect = refEl.getBoundingClientRect();
            s -= Math.min(300, Math.abs(rect.top - refRect.bottom) * 0.25);
          }
        } catch (e) {}
        return s;
      }
      return score(b) - score(a);
    });
    return options[0] && options[0].node || null;
  }

  function isSdAutocompleteInput(input) {
    if (!input) return false;
    var placeholder = String(input.getAttribute("placeholder") || "").trim();
    // Moka distinguishes searchable dictionaries (school/major) from normal
    // selects through an "请输入..." placeholder. Normal selects use "请选择".
    return /^请输入/.test(placeholder);
  }

  function normalizeSdRegionPart(value) {
    return String(value == null ? "" : value).replace(/\s+/g, "").trim();
  }

  function parseSdRegionPath(value) {
    if (Array.isArray(value)) return value.map(normalizeSdRegionPart).filter(Boolean).slice(0, 3);
    var text = normalizeSdRegionPart(value);
    if (!text) return [];
    var separated = text.split(/(?:\/|>|＞|,|，|\|)+/).map(normalizeSdRegionPart).filter(Boolean);
    if (separated.length > 1) return separated.slice(0, 3);

    var municipalities = ["北京市", "上海市", "天津市", "重庆市"];
    for (var i = 0; i < municipalities.length; i++) {
      var municipality = municipalities[i];
      var shortName = municipality.slice(0, -1);
      if (text.indexOf(municipality) === 0 || text.indexOf(shortName) === 0) {
        var municipalRest = text.slice(text.indexOf(municipality) === 0 ? municipality.length : shortName.length);
        var municipalPath = [municipality, municipality];
        if (municipalRest) municipalPath.push(municipalRest);
        return municipalPath.slice(0, 3);
      }
    }

    var provinceMatch = text.match(/^(.+?(?:省|自治区|特别行政区))/);
    if (!provinceMatch) return [text];
    var province = provinceMatch[1];
    var rest = text.slice(province.length);
    var cityMatch = rest.match(/^(.+?(?:市|自治州|地区|盟))/);
    var city = cityMatch ? cityMatch[1] : rest;
    var district = cityMatch ? rest.slice(city.length) : "";
    return [province, city, district].filter(Boolean).slice(0, 3);
  }

  function sdRegionVariants(value) {
    var text = normalizeSdRegionPart(value);
    var variants = [text];
    var stripped = text
      .replace(/壮族自治区$/g, "")
      .replace(/回族自治区$/g, "")
      .replace(/维吾尔自治区$/g, "")
      .replace(/自治区$/g, "")
      .replace(/特别行政区$/g, "")
      .replace(/省$/g, "")
      .replace(/市$/g, "");
    if (stripped && variants.indexOf(stripped) === -1) variants.push(stripped);
    return variants;
  }

  function visibleSdRegionMenu(container) {
    var menus = [];
    try {
      menus = Array.from((container || document).querySelectorAll('[class*="menu-wrapper"]'));
    } catch (e) {}
    return menus.find(function (menu) {
      if (!isVisible(menu)) return false;
      var text = normalizeSdRegionPart(menu.textContent);
      return text.indexOf("省份") !== -1 && text.indexOf("城市") !== -1 && text.indexOf("县区") !== -1;
    }) || null;
  }

  function findSdRegionOption(menu, value) {
    if (!menu) return null;
    var variants = sdRegionVariants(value);
    var leaves = [];
    try {
      leaves = Array.from(menu.querySelectorAll('[class*="sd-Tag-text"], [class*="sd-Menu-content-item"], [role="option"]'));
    } catch (e) {}
    return leaves.find(function (node) {
      if (!isVisible(node)) return false;
      var text = normalizeSdRegionPart(node.textContent);
      return variants.indexOf(text) !== -1;
    }) || null;
  }

  function sdRegionCommittedText(container) {
    try {
      return Array.from(container.querySelectorAll('[class*="sd-Tag-text"]')).filter(isVisible).map(function (node) {
        return normalizeSdRegionPart(node.textContent);
      }).filter(Boolean).join("");
    } catch (e) {
      return "";
    }
  }

  async function fillSdRegionPicker(element, value) {
    var path = parseSdRegionPath(value);
    if (path.length < 2) return false;
    var container = sdContainer(element);
    var trigger = sdTrigger(container);
    var committedBefore = sdRegionCommittedText(container);
    if (path.slice(0, 2).every(function (part) {
      return sdRegionVariants(part).some(function (variant) { return committedBefore.indexOf(variant) !== -1; });
    })) return true;

    await AF.DomUtils.safeClickElement(trigger || container);
    var menu = null;
    for (var waitIndex = 0; waitIndex < 20 && !menu; waitIndex++) {
      await AF.Utils.sleep(100);
      menu = visibleSdRegionMenu(container);
    }
    if (!menu) return false;

    for (var level = 0; level < path.length; level++) {
      var option = null;
      for (var optionWait = 0; optionWait < 20 && !option; optionWait++) {
        option = findSdRegionOption(menu, path[level]);
        if (!option) await AF.Utils.sleep(100);
      }
      if (!option) {
        if (level >= 2) break;
        return false;
      }
      await AF.DomUtils.safeClickElement(option);
      await AF.Utils.sleep(220);
      menu = visibleSdRegionMenu(container) || menu;
    }

    var confirmButton = Array.from(menu.querySelectorAll('button, [role="button"]')).find(function (node) {
      return isVisible(node) && normalizeSdRegionPart(node.textContent) === "确认";
    });
    if (!confirmButton) return false;
    await AF.DomUtils.safeClickElement(confirmButton);
    await AF.Utils.sleep(350);

    var committed = sdRegionCommittedText(container);
    return path.slice(0, 2).every(function (part) {
      return sdRegionVariants(part).some(function (variant) { return committed.indexOf(variant) !== -1; });
    });
  }

  function findSdAutocompleteOption(container, value) {
    var target = String(value == null ? "" : value).trim();
    if (!target) return null;
    var scope = container || document;
    var nodes = [];
    try {
      nodes = Array.from(scope.querySelectorAll('[class*="sd-Select-common-item"]'));
    } catch (e) {}
    if (!nodes.length) {
      try {
        nodes = Array.from(document.querySelectorAll('[class*="sd-Select-common-item"]'));
      } catch (e2) {}
    }
    nodes = nodes.filter(function (node) {
      return isVisible(node) && !node.querySelector("input");
    });

    var exact = nodes.filter(function (node) {
      return sdOptionText(node) === target;
    });
    if (exact.length) return exact[0];

    var scored = nodes.map(function (node) {
      return { node: node, score: sdOptionScore(node, target), text: sdOptionText(node) };
    }).filter(function (entry) {
      return sdTextMatches(entry.text, target);
    }).sort(function (a, b) {
      // For universities, prefer the main school over subordinate schools
      // such as "浙江大学医学院" when the target is "浙江大学".
      var aSub = entryIsSubordinateSchool(a.text, target);
      var bSub = entryIsSubordinateSchool(b.text, target);
      if (aSub !== bSub) return aSub ? 1 : -1;
      return b.score - a.score;
    });
    return scored[0] && scored[0].node || null;
  }

  function entryIsSubordinateSchool(optionText, target) {
    var option = String(optionText || "").trim();
    var wanted = String(target || "").trim();
    if (!option || !wanted || option === wanted || option.indexOf(wanted) === -1) return false;
    return /学院|分校|分院|校区/.test(option.slice(wanted.length));
  }

  function waitForSdAutocompleteOption(container, value, timeoutMs) {
    return new Promise(function (resolve) {
      var done = false;
      var observer = null;
      var timer = null;
      var poller = null;
      function finish(node) {
        if (done) return;
        done = true;
        if (observer) observer.disconnect();
        if (timer) clearTimeout(timer);
        if (poller) clearInterval(poller);
        resolve(node || null);
      }
      function scan() {
        var option = findSdAutocompleteOption(container, value);
        if (option) finish(option);
      }
      try {
        observer = new MutationObserver(scan);
        observer.observe(document.body, { childList: true, subtree: true, attributes: true });
      } catch (e) {}
      poller = setInterval(scan, 20);
      timer = setTimeout(function () { finish(null); }, timeoutMs || 1000);
      scan();
    });
  }

  async function fillSdAutocompleteLikeOriginal(container, input, value) {
    if (!input || input.disabled || input.readOnly) return false;
    var text = String(value == null ? "" : value).trim();
    if (!text) return false;
    try {
      // Align with the reference SearchInputHandler.inputData(value, blur=false).
      input.dispatchEvent(new Event("focus"));
      await AF.Utils.sleep(10);
      input.value = text;
      input.setAttribute("value", text);
      input.dispatchEvent(new Event("input", { bubbles: true, cancelable: false }));

      var option = await waitForSdAutocompleteOption(container, text, 1000);
      if (!option) {
        input.value = "";
        input.dispatchEvent(new Event("input", { bubbles: true }));
        return false;
      }
      return await clickSdSearchOptionLeaf(option);
    } catch (e) {
      return false;
    }
  }

  async function clickSdSearchOptionLeaf(node) {
    if (!node) return false;
    try {
      node.scrollIntoView({ block: "nearest", behavior: "auto" });
    } catch (e) {}
    try {
      if (await ensureSdMainBridge()) {
        var token = "af_sd_leaf_" + Date.now() + "_" + Math.random().toString(36).slice(2);
        var id = token + "_click";
        node.setAttribute("data-af-sd-leaf-token", token);
        var mainWorldClicked = await new Promise(function (resolve) {
          var done = false;
          var timer = setTimeout(function () {
            if (done) return;
            done = true;
            window.removeEventListener("message", onMessage);
            resolve(false);
          }, 2500);
          function onMessage(event) {
            if (event.source !== window) return;
            var data = event.data || {};
            if (data.type !== "AF_SD_LEAF_CLICK_RESULT" || data.id !== id) return;
            if (done) return;
            done = true;
            clearTimeout(timer);
            window.removeEventListener("message", onMessage);
            resolve(!!data.ok);
          }
          window.addEventListener("message", onMessage);
          window.postMessage({ type: "AF_SD_LEAF_CLICK_REQUEST", id: id, token: token }, "*");
        });
        try { node.removeAttribute("data-af-sd-leaf-token"); } catch (e2) {}
        if (mainWorldClicked) return true;
      }

      // The reference searchable-input path does not click the option wrapper.
      // It finds the first non-empty leaf inside the matched option and calls
      // leaf.click(). Moka binds the effective selection through the bubbling
      // click from this text node (for example: <div>浙江大学</div>).
      var leaves = [];
      try {
        leaves = Array.from(node.querySelectorAll("*:not(:has(*))"));
      } catch (e3) {
        leaves = Array.from(node.querySelectorAll("div, span"));
      }
      var leaf = leaves.find(function (item) {
        return String(item && item.textContent || "").trim().length > 0;
      });
      (leaf || node).click();
      // The original handler closes the suggestion layer after committing.
      // This also forces the controlled input to leave its search state.
      try { document.body.click(); } catch (e4) {}
      await AF.Utils.sleep(100);
      return true;
    } catch (e5) {
      return false;
    }
  }

  async function clickSdBestOption(panels, value, refEl, input) {
    var node = findSdBestOption(panels, value, refEl) || findSdFirstUsableOption(panels, refEl);
    // Searchable Moka fields (school/major) commit from the deepest text leaf,
    // not from the sd option wrapper it示例资料.
    if (node) return await clickSdSearchOptionLeaf(node);
    return await H.clickBestMatch(panels.reduce(function (nodes, panel) {
      return nodes.concat(sdOptions(panel));
    }, []), value);
  }

  async function selectSdOneValue(element, value) {
    var container = sdContainer(element);
    var input = sdInput(container);
    var trigger = sdTrigger(container);
    if (sdTextMatches(sdReadValue(container), value)) return true;

    // Faithful SearchInputHandler path for Moka dictionary fields such as
    // school and major: type -> observe suggestions -> click text leaf.
    if (input && isSdAutocompleteInput(input)) {
      var autocompleteOk = await fillSdAutocompleteLikeOriginal(container, input, value);
      if (autocompleteOk) return true;
    }

    if (trigger && trigger.focus) {
      try { trigger.focus(); } catch (e) {}
    }
    await AF.DomUtils.safeClickElement(trigger || container);
    await AF.Utils.sleep(180);

    if (input && typeof value === "string") {
      if (!await typeSdSearchInPage(input, value)) {
        await typeSdSearch(input, value);
      }
    }

    var panels = await waitForSdPanelsWithOptions(container, 8000);
    var clicked = false;
    if (!sdSelectionSettled(container, value) && panels.length) {
      clicked = await clickSdBestOption(panels, value, container, input);
    }
    // The original implementation treats the single matched click as the
    // commit. Let the outer fill verifier read the resulting value; clicking
    // the same controlled option again can undo or disturb the first commit.
    if (clicked) {
      await AF.Utils.sleep(350);
      H.dispatchChangeEvents(input || container);
      return true;
    }
    await waitForSdCommitOrClose(container, value, 3200);
    if (!sdSelectionSettled(container, value)) {
      var retryPanels = visibleSdPanels(container);
      if (retryPanels.length) {
        await clickSdBestOption(retryPanels, value, container, input);
        await waitForSdCommitOrClose(container, value, 2600);
      }
    }
    if (!sdSelectionSettled(container, value) && input && !sdDropdownStillOpen(container)) {
      await AF.DomUtils.safeClickElement(trigger || container);
      await AF.Utils.sleep(180);
      if (typeof value === "string") {
        if (!await typeSdSearchInPage(input, value)) await typeSdSearch(input, value);
      }
      await waitForSdPanelsWithOptions(container, 5000);
    }
    if (!sdSelectionSettled(container, value) && input) {
      await commitSdKeyboard(input, true);
      await waitForSdCommitOrClose(container, value, 1800);
    }
    if (!sdSelectionSettled(container, value) && input) {
      await commitSdKeyboard(input, false);
      await waitForSdCommitOrClose(container, value, 1800);
    }
    if (sdSelectionSettled(container, value)) {
      H.dispatchChangeEvents(input || container);
      await AF.Utils.sleep(420);
      return true;
    }
    H.dispatchChangeEvents(input || container);
    try {
      (input || container).dispatchEvent(new Event("blur", { bubbles: true, composed: true }));
    } catch (e2) {}
    await AF.Utils.sleep(300);
    var displayValue = sdReadDisplayValue(container);
    if (sdTextMatches(displayValue, value)) return true;
    return false;
  }

  async function triggerSdSelect(element, value) {
    if (!element || value === undefined || value === null || value === "") return false;
    if (Array.isArray(value)) {
      var ok = false;
      for (var i = 0; i < value.length; i++) {
        if (await selectSdOneValue(element, value[i])) ok = true;
        await AF.Utils.sleep(150);
      }
      return ok;
    }
    return await selectSdOneValue(element, value);
  }

  async function triggerSdLegacyPanelSelect(element, value) {
    try {
      if (!element || value === undefined || value === null || value === "") return false;
      var container = sdContainer(element);
      var input = sdInput(container);
      var trigger = sdTrigger(container);

      if (trigger && trigger.focus) {
        try { trigger.focus(); } catch (e0) {}
      }
      await AF.DomUtils.safeClickElement(trigger || container);
      await AF.Utils.sleep(180);

      if (input && typeof value === "string") {
        await typeSdSearch(input, value);
      }

      var panels = await waitForSdPanels(container, 3000);
      panels = panels.filter(function (panel) {
        return sdOptions(panel).length > 0;
      });
      if (!panels.length) return false;

      var ok;
      if (Array.isArray(value)) {
        ok = false;
        for (var i = 0; i < value.length; i++) {
          var one = await H.clickBestMatch(panels.reduce(function (nodes, panel) {
            return nodes.concat(sdOptions(panel));
          }, []), value[i]);
          if (one) ok = true;
          await waitForSdSelectionSettled(container, value[i], 1200);
          await AF.Utils.sleep(150);
        }
      } else {
        ok = await H.clickBestMatch(panels.reduce(function (nodes, panel) {
          return nodes.concat(sdOptions(panel));
        }, []), value);
        await waitForSdSelectionSettled(container, value, 1600);
      }

      H.dispatchChangeEvents(input || container);
      try {
        (input || container).dispatchEvent(new Event("blur", { bubbles: true, composed: true }));
      } catch (e1) {}
      await AF.Utils.sleep(220);
      return ok || sdTextMatches(sdReadDisplayValue(container), value);
    } catch (e2) {
      return false;
    }
  }

  // 注册函数支持第4个参数 customSelectors: { container, trigger, dropdown }，
  // 由调用方 (站点配置/FillEngine) 在 AF.SelectAdapter.create() 时传入。
  SA._registry["custom"] = function (element, valueType, sectionEl, customSelectors) {
    return {
      selectValue: async function (value) {
        return await triggerCustomSelect(element, value, customSelectors);
      },
    };
  };

  SA._registry["legacyZhiye"] = function (element) {
    return {
      selectValue: async function (value) {
        return await selectLegacyZhiyeAddress(element, value);
      },
    };
  };

  SA._registry["sd"] = function (element, valueType, sectionEl, capability) {
    return {
      selectValue: async function (value) {
        if (capability && capability.sdMode === "regionCascader") {
          return await fillSdRegionPicker(element, value);
        }
        return await triggerSdSelect(element, value);
      },
    };
  };
})();
