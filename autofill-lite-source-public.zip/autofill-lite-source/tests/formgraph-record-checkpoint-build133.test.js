"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const coreSource = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-core.js"), "utf8");
const handler = fs.readFileSync(path.join(root, "autofill-plugin/content/form-handler.js"), "utf8");
const engine = fs.readFileSync(path.join(root, "autofill-plugin/content/fill-engine.js"), "utf8");
const experience = fs.readFileSync(path.join(root, "autofill-plugin/content/experience-handler.js"), "utf8");

assert(/const BUILD_ID = \"202609\d{2}-[^\"]+-\d+\";/.test(main), "A: current numeric Build id missing");
assert(main.includes("formRecordCheckpoint:"), "A: record checkpoint diagnostic missing");
assert(main.includes("一键填写已结束，但有内容需要检查"), "A: non-checkpoint partial result must not pretend to be a stop");
assert(coreSource.includes('FORM_RECORD_CHECKPOINT_STORAGE_KEY = "offerAutofillFormRecordCheckpointV1"'), "B: record checkpoint storage missing");
assert(coreSource.includes('FORM_RECORD_LEDGER_STORAGE_KEY = "offerAutofillFormRecordLedgerV1"'), "B: record ledger storage missing");
assert(coreSource.includes('granularity: "record"'), "B: record granularity missing");
assert(coreSource.includes("beginFormRecordRun"), "B: record runtime missing");
assert(handler.includes("configuredCardSelector"), "C: education detector must reuse mature platform card selector");
assert(handler.includes("recordCheckpointRuntime.shouldSkip(recordCheckpointMeta)"), "C: education record resume gate missing");
assert(handler.includes("findPendingManualExperienceSaveButton"), "C: education manual-save ownership probe missing");
assert(experience.includes("record_checkpoint_pause"), "D: generic ExperienceHandler manual-save checkpoint missing");
assert(experience.includes("recordCheckpointRuntime.shouldSkip(recordCheckpointMeta)"), "D: repeat record resume skip missing");
assert(engine.includes("beginFormRecordCheckpointRuntime"), "E: FillEngine record checkpoint initialization missing");
assert(engine.includes("applyFormRecordCheckpointResult"), "E: record checkpoint result bridge missing");

const store = {};
const sandbox = {
  window: { AF: {}, location: { hostname: "app.mokahr.com", pathname: "/campus-recruitment/test/1", hash: "#/candidateHome/resume" } },
  chrome: {
    storage: { local: {
      get(keys, cb) { const out = {}; keys.forEach(k => { if (Object.prototype.hasOwnProperty.call(store, k)) out[k] = store[k]; }); cb(out); },
      set(payload, cb) { Object.assign(store, payload); cb && cb(); },
      remove(keys, cb) { keys.forEach(k => delete store[k]); cb && cb(); }
    } },
    runtime: { lastError: null }
  },
  console, Date, Math, Promise, Set, setTimeout, clearTimeout
};
vm.createContext(sandbox);
vm.runInContext(coreSource, sandbox, { filename: "checkpoint-core.js" });
const core = sandbox.window.AF.CheckpointCore;

(async () => {
  const loc = sandbox.window.location;
  const row1 = { school: "A大学", degree: "本科", startTime: "2021-09", endTime: "2025-06" };
  const row2 = { school: "A大学", degree: "硕士", startTime: "2025-09", endTime: "2027-06" };
  const meta1 = { category: "education", sectionTitle: "教育背景", repeatIndex: 0, repeatTotal: 2, row: row1, recordFingerprint: core.recordFingerprint(row1) };
  const meta2 = { category: "education", sectionTitle: "教育背景", repeatIndex: 1, repeatTotal: 2, row: row2, recordFingerprint: core.recordFingerprint(row2) };

  // Cross-granularity safety: a RECORD checkpoint must preserve FIELD ledger
  // so a rerun never rewrites scalar fields that were completed before the record.
  const scalarMeta = { category: "basicInfo", fieldKey: "name", label: "姓名", occurrence: 0, controlType: "text" };
  const scalarRun = await core.beginFormFieldRun(loc);
  await scalarRun.markCompleted(scalarMeta);

  const fresh = await core.beginFormRecordRun(loc, { preserveExistingLedger: true });
  assert.strictEqual(fresh.resumed, false, "F: fresh record run must not resume");
  await fresh.markCompleted(meta1);
  const cp = await fresh.pause(meta2, "当前教育记录已填写，仍需手动保存");
  assert(cp && cp.granularity === "record", "F: record checkpoint not persisted");
  assert.strictEqual(cp.acknowledgeOnRerun, true, "F: record checkpoint must use user acknowledgement");
  assert(cp.completedRecordTokens.includes(core.formRecordToken(meta1)), "F: completed record token missing");

  const scalarResume = await core.beginFormFieldRun(loc, { preserveExistingLedger: true });
  assert.strictEqual(scalarResume.shouldSkip(scalarMeta), true, "G: RECORD checkpoint must preserve pre-checkpoint scalar FIELD ledger");

  const resumed = await core.beginFormRecordRun(loc, { preserveExistingLedger: true });
  assert.strictEqual(resumed.resumed, true, "G: rerun must acknowledge prior record checkpoint");
  assert.strictEqual(resumed.shouldSkip(meta1), true, "G: completed earlier record must skip");
  assert.strictEqual(resumed.shouldSkip(meta2), true, "G: manually saved failed record must skip");
  assert.strictEqual(resumed.resumeRecordSeen, true, "G: resume record token should be observed");
  assert.strictEqual(await core.loadFormRecordCheckpoint(loc), null, "G: acknowledged record checkpoint must be cleared");

  const snap = core.snapshotFormRecordRuntime(resumed);
  assert.strictEqual(snap.granularity, "record", "H: record runtime snapshot granularity incorrect");
  assert.strictEqual(snap.ledger.completedRecordCount, 2, "H: ledger should retain pre-checkpoint record and user-acknowledged resume record");
  console.log("formgraph-record-checkpoint-build133.test.js passed (A-H)");
})().catch(err => { console.error(err); process.exit(1); });
