"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const 示例资料flow = fs.readFileSync(path.join(root, "autofill-plugin", "content", "special-site-示例资料flow.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const renderer = fs.readFileSync(path.join(root, "renderer.js"), "utf8");
const index = fs.readFileSync(path.join(root, "index.html"), "utf8");

assert(示例资料flow.includes("function analyzedBatchSaveIdentityReadableText"), "read-only identity text extractor missing");
assert(示例资料flow.includes("select, option, datalist, input, textarea, button"), "identity extractor must exclude editor controls/options");
assert(示例资料flow.includes("function analyzedBatchSaveManualInputRequirement"), "generic manual input checkpoint missing");
assert(示例资料flow.includes("function analyzedBatchSaveParsedMinLength"), "minimum-length requirement parser missing");
assert(示例资料flow.includes('reason: "min_length"'), "min-length manual requirement trace missing");
assert(示例资料flow.includes('reason: "required_empty"'), "required-empty manual requirement trace missing");
assert(示例资料flow.includes("manualActionFields"), "manual checkpoint must expose safe field diagnostics");
assert(示例资料flow.includes("manualRequirementKinds"), "manual checkpoint kind trace missing");
assert(示例资料flow.includes("function analyzedBatchSaveMeaningfulExistingSpec"), "resume-aware existing editor preservation missing");
assert(示例资料flow.includes('reason = "existing_manual_value_preserved"'), "manual non-empty overrides must be preserved on resume");
assert(示例资料flow.includes('trace.result = "manual_action_required"'), "batch must pause on generic manual requirements");
assert(renderer.includes("需要补充/修正"), "renderer must surface manual input requirements");
assert(renderer.includes("人工补完后可直接重新运行"), "renderer must explain resumable checkpoint behavior");
assert(!index.includes('id="multiSectionSave"'), "Build160 removes the legacy experiment tooltip; checkpoint behavior remains covered by runtime assertions");
console.log("resumable manual checkpoint test: PASS");
