// content/date-picker/handlers/aui.js — Huawei AUI / we-datepicker 日期输入兜底
//
// AUI 日期控件外层常见 data-tag="we-datepicker"，内部仍有 input。
// 如果控件可编辑，先直接写入 input 并派发事件；复杂面板后续再根据实际弹层补强。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  function normalizeDateValue(value) {
    if (value && typeof value === "object") {
      return value.startTime || value.endTime || "";
    }
    return value || "";
  }

  function setNativeInputValue(input, value) {
    var text = String(value || "");
    var descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    if (descriptor && descriptor.set) descriptor.set.call(input, text);
    else input.value = text;
    input.setAttribute && input.setAttribute("value", text);
    input.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: text, inputType: "insertText" }));
    input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true, composed: true }));
    input.dispatchEvent(new Event("blur", { bubbles: true, cancelable: true, composed: true }));
  }

  AF.DatePicker._registry.aui = function (element, valueType) {
    return {
      setValue: async function (value) {
        try {
          var target = normalizeDateValue(value);
          if (!target) return false;
          var root = (element.closest && element.closest('[data-tag="we-datepicker"], .picker[data-tag="we-datepicker"], .aui-date-picker, .aui-picker')) || element;
          var input = (root.querySelector && root.querySelector("input")) || (element.tagName === "INPUT" ? element : null);
          if (!input || input.disabled || input.readOnly) return false;
          input.focus && input.focus();
          setNativeInputValue(input, target);
          await AF.Utils.sleep(80);
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
