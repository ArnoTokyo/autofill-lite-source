// content/date-picker/handlers/wdate.js — My97 DatePicker (.Wdate / onclick~="WdatePicker")
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   工厂分支 Kn.create() case "wdate": 行 46034 -> mo
//   mo.setValue: 行 47608-47706 — 先尝试一个通用 Ne.Jc().handleDatePicker() 兜底路径，失败/不适用
//     再走 dn()。Ne.Jc() 是跟 getDatePickerType 共用的一个内部单例辅助类，其 handleDatePicker
//     具体实现未在日期模块附近定位到，属于其他框架检测逻辑的复用兜底，这里不再重建，直接使用
//     已完整核实的 dn() 路径（即 My97 的标准点击弹出 iframe 面板方式）。
//   dn()/yn() (点击弹出 iframe 里的 .WdateDiv 面板): 行 43672-43760
//   vn()/mn() (在 body 下找 position:absolute+z-index 的浮层, 从其 iframe 里找 .WdateDiv): 行 43761-43893
//   bn()/gn() (设置年份 input.yminput[1]): 行 43894-43937
//   wn()/xn() (设置月份 input.yminput[0]): 行 43938-43981
//   kn()/En() (在 .WdayTable 的 td 里按文本精确匹配日期并点击): 行 43982-44048
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  function findWdateDiv() {
    var overlays = document.querySelectorAll('body > div[style*="position: absolute"][style*="z-index"]');
    for (var i = 0; i < overlays.length; i++) {
      var style = overlays[i].getAttribute("style") || "";
      if (style.includes("display: none") || style.includes("display:none")) continue;
      var iframe = overlays[i].querySelector("iframe");
      if (!iframe) continue;
      try {
        var doc = iframe.contentDocument || iframe.contentWindow.document;
        var wdateDiv = doc.querySelector(".WdateDiv");
        if (wdateDiv) return wdateDiv;
      } catch (e) {}
    }
    return null;
  }

  async function waitForWdateDiv() {
    var found = findWdateDiv();
    if (found) return found;
    await AF.Utils.sleep(200);
    return findWdateDiv();
  }

  function setYearInput(wdateDiv, year) {
    var inputs = wdateDiv.querySelectorAll("input.yminput");
    var el = inputs[1];
    if (!el) throw new Error("未找到年份输入框");
    el.value = year.toString();
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.blur();
  }

  function setMonthInput(wdateDiv, month) {
    var inputs = wdateDiv.querySelectorAll("input.yminput");
    var el = inputs[0];
    if (!el) throw new Error("未找到月份输入框");
    el.value = month.toString();
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.blur();
  }

  function clickDayCell(wdateDiv, day) {
    var dayTable = wdateDiv.querySelector(".WdayTable");
    if (!dayTable) throw new Error("未找到WdayTable容器");
    var cells = dayTable.querySelectorAll("td");
    var target = day.toString();
    for (var i = 0; i < cells.length; i++) {
      if (cells[i].textContent.trim() === target) {
        cells[i].click();
        return;
      }
    }
    throw new Error("未找到日期" + day + "的td元素");
  }

  async function wdateSingleNavigate(triggerEl, dateStr) {
    if (!triggerEl || !dateStr) throw new Error("元素或日期值为空");
    var parsed = AF.DatePicker._parseDateValue(dateStr);
    var d = parsed ? new Date(parsed.year, parsed.month - 1, parsed.day || 1) : new Date(dateStr);
    var year = parsed ? parsed.year : d.getFullYear();
    var month = parsed ? parsed.month : d.getMonth() + 1;
    var day = parsed && parsed.day ? parsed.day : d.getDate();

    triggerEl.click();
    await AF.Utils.sleep(100);
    var wdateDiv = await waitForWdateDiv();
    if (!wdateDiv) throw new Error("未找到WdateDiv容器");
    setYearInput(wdateDiv, year);
    await AF.Utils.sleep(20);
    setMonthInput(wdateDiv, month);
    await AF.Utils.sleep(20);
    clickDayCell(wdateDiv, day);
    await AF.Utils.sleep(20);
    return true;
  }

  AF.DatePicker._registry["wdate"] = function (element, valueType) {
    return {
      setValue: async function (value) {
        try {
          if (!value) throw new Error("日期为空");
          if (typeof value === "string" || valueType === "string") {
            return await wdateSingleNavigate(element, value);
          }
          if (typeof value !== "object" || !("startTime" in value) || !("endTime" in value)) {
            throw new Error("dateValue必须包含startTime和endTime属性");
          }
          await wdateSingleNavigate(element, value.startTime);
          await AF.Utils.sleep(500);
          var candidates = AF.DomUtils.findSimilarElements(element, 4, { sameTag: true, sameClass: true, sameParent: false });
          if (candidates.length > 0) {
            var best = AF.DatePicker._pickEndDateCandidate(element, candidates);
            await wdateSingleNavigate(best, value.endTime);
          } else {
            var surrounding = AF.DomUtils.findSurroundingInputs(element);
            if (surrounding.length > 0) await wdateSingleNavigate(surrounding[0], value.endTime);
          }
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
