// content/select-adapter/adapters/vuetify.js — Vuetify (.v-select/.v-menu) 适配器
// 源码参考 (webcrack-output/content/deobfuscated.js, 模块3620):
//   VuetifySelectAdapter (混淆名 j, 行14768-14775) 直接继承 GenericSelectAdapter (混淆名 E)，
//   没有覆盖 setValue —— 走 triggerGenericSelect 通用流程 (点击 element 本身 ->
//   全局找可见下拉面板 -> 通用文字匹配点击)，没有 Vuetify 专属定位逻辑。
// 选择器配置 SA._config.vuetify 仅供 detectType 分类使用。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};

  SA._registry["vuetify"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        return await SA._helpers.triggerGenericSelect(element, value);
      },
    };
  };
})();
