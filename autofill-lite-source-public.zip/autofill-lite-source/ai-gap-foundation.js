"use strict";

function cleanText(value) {
  return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
}

function norm(value) {
  return cleanText(value).replace(/[：:，,。；;（）()\[\]【】\s]/g, "").toLowerCase();
}

const CONTROL_OR_WORKFLOW_RE = /保存|save|repeat|editor|scope|ownership|record|日期|date|控件|候选|面板|弹层|popup|timeout|retained|selection|新增|删除|关闭|归属|事务|编辑器|验证码|上传/i;
const SEMANTIC_RE = /未找到依赖字段标签|label[_\s-]?not[_\s-]?found|未映射|unmapped|semantic|语义|字段标签|匹配字段|字段别名|mapping/i;

function pushUnique(out, seen, item) {
  const label = cleanText(item && item.label);
  const fieldKey = cleanText(item && item.fieldKey);
  if (!label || label === "未命名字段") return;
  const key = `${norm(label)}::${norm(fieldKey)}`;
  if (!key || seen.has(key)) return;
  seen.add(key);
  out.push({
    label,
    fieldKey,
    source: cleanText(item && item.source),
    reason: cleanText(item && item.reason)
  });
}

function collectSemanticGaps(input) {
  const x = input && typeof input === "object" ? input : {};
  const out = [];
  const seen = new Set();
  const failed = Array.isArray(x.failedFields) ? x.failedFields : [];
  const unhandled = Array.isArray(x.unhandledFields) ? x.unhandledFields : [];

  failed.forEach((row) => {
    const reason = cleanText(row && row.reason);
    if (!reason) return;
    if (CONTROL_OR_WORKFLOW_RE.test(reason) && !SEMANTIC_RE.test(reason)) return;
    if (!SEMANTIC_RE.test(reason)) return;
    pushUnique(out, seen, {
      label: row && (row.label || row.fieldKey),
      fieldKey: row && row.fieldKey,
      source: "failed_field",
      reason
    });
  });

  unhandled.forEach((row) => {
    const label = cleanText(row && (row.label || row.fieldKey));
    if (!label || label === "未命名字段") return;
    const reason = cleanText(row && row.reason);
    if (CONTROL_OR_WORKFLOW_RE.test(reason)) return;
    pushUnique(out, seen, {
      label,
      fieldKey: row && row.fieldKey,
      source: "unhandled_field",
      reason: reason || "未处理字段"
    });
  });

  return out.slice(0, 40);
}

function buildAiGapFoundation(input) {
  const x = input && typeof input === "object" ? input : {};
  const postFillGap = x.postFillGap && typeof x.postFillGap === "object" ? x.postFillGap : {};
  const gaps = collectSemanticGaps(x);
  const eligible = postFillGap.aiSemanticRecommended === true;
  return {
    schemaType: "autofill-lite-ai-gap-foundation",
    schemaVersion: 1,
    mode: "candidate_only",
    eligible,
    gapCode: cleanText(postFillGap.code),
    gapSummary: cleanText(postFillGap.summary),
    gapCount: gaps.length,
    gaps,
    needsFreshAnalysis: eligible && gaps.length === 0,
    aiInvoked: false,
    candidateAvailable: false,
    candidateGenerated: false,
    candidateFileName: "",
    candidateSummary: {},
    candidates: [],
    safetyGate: null,
    status: eligible ? "candidate_pending" : "not_applicable",
    policy: {
      autoApply: false,
      autoExecute: false,
      mayWriteJavascript: false,
      mayChangeSelectors: false,
      mayClickSaveSubmitApplyDeleteUpload: false,
      mayChooseRepeatRecordOwner: false,
      trustedLocalMappingsWin: true
    }
  };
}

function summarizeCandidateMappings(siteCandidate, gapFoundation, limit) {
  const semantic = siteCandidate && siteCandidate.semanticPatch || siteCandidate && siteCandidate.configTemplate && siteCandidate.configTemplate._aiSemanticPatch || {};
  const mappings = Array.isArray(semantic.fieldMappings) ? semantic.fieldMappings : [];
  const gapLabels = new Set((gapFoundation && Array.isArray(gapFoundation.gaps) ? gapFoundation.gaps : [])
    .map((item) => norm(item && item.label)).filter(Boolean));
  const aiMappings = mappings.filter((item) => String(item && item.source || "") === "ai_semantic_patch");
  const selected = gapLabels.size
    ? aiMappings.filter((item) => gapLabels.has(norm(item && item.label)))
    : aiMappings;
  return selected.slice(0, Math.max(1, Number(limit || 20))).map((item) => ({
    label: cleanText(item && item.label),
    category: cleanText(item && item.category),
    fieldKey: cleanText(item && item.fieldKey),
    confidence: Number(item && item.confidence || 0)
  }));
}

module.exports = {
  buildAiGapFoundation,
  collectSemanticGaps,
  summarizeCandidateMappings,
  CONTROL_OR_WORKFLOW_RE,
  SEMANTIC_RE
};
