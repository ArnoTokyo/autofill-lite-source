"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

class FakeElement {
  constructor(tag, text = "", className = "") {
    this.tagName = String(tag || "div").toUpperCase();
    this.textContent = text;
    this.className = className;
    this.parentElement = null;
    this.children = [];
    this.attrs = {};
    this.id = "";
    this.type = "";
    this.value = "";
    this.disabled = false;
    this.readOnly = false;
    this.required = false;
    this.isConnected = true;
    this.rect = { left: 20, top: 20, right: 180, bottom: 50, width: 160, height: 30 };
  }
  append(child) { child.parentElement = this; this.children.push(child); return child; }
  contains(node) { return node === this || this.children.some((child) => child.contains(node)); }
  getBoundingClientRect() { return this.rect; }
  getClientRects() { return this.isConnected ? [this.rect] : []; }
  getAttribute(name) {
    if (name === "id") return this.id || null;
    if (name === "type") return this.type || null;
    return Object.prototype.hasOwnProperty.call(this.attrs, name) ? this.attrs[name] : null;
  }
  setAttribute(name, value) { this.attrs[name] = String(value); if (name === "id") this.id = String(value); }
  hasAttribute(name) { return this.getAttribute(name) != null; }
  scrollIntoView() {}
  dispatchEvent() { return true; }
  click() {}
  matches(selector) {
    if (selector.includes("input") && this.tagName === "INPUT") return true;
    if (selector.includes("select") && this.tagName === "SELECT") return true;
    if (selector.includes("button") && this.tagName === "BUTTON") return true;
    return false;
  }
  closest(selector) {
    for (let node = this; node; node = node.parentElement) {
      if (selector.includes("form") && node.tagName === "FORM") return node;
      if (selector.includes("li") && node.tagName === "LI") return node;
    }
    return null;
  }
  querySelectorAll(selector) {
    const all = [];
    const walk = (node) => { for (const child of node.children) { all.push(child); walk(child); } };
    walk(this);
    if (selector.includes("button") || selector.includes("[role='button']") || selector.includes("input[type='button']") || selector.includes("input[type='submit']")) {
      return all.filter((node) => node.tagName === "BUTTON" || node.tagName === "A");
    }
    if (selector === "*") return all;
    return [];
  }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
}

const root = new FakeElement("html");
const body = root.append(new FakeElement("body"));
const navLi = body.append(new FakeElement("li", "", "on"));
const nav = navLi.append(new FakeElement("a", "教育背景"));
const add = body.append(new FakeElement("div", "+添加教育背景", "add-btn"));
const form = body.append(new FakeElement("form", "", "education-editor"));
const school = form.append(new FakeElement("input"));
school.id = "schoolName";
school.attrs.name = "schoolName";
school.attrs.placeholder = "请输入学校名称";
school.required = true;
const degree = form.append(new FakeElement("select"));
degree.id = "educationLevel";
degree.attrs.name = "educationLevel";
degree.options = [{ textContent: "请选择" }, { textContent: "本科" }, { textContent: "硕士" }];
const start = form.append(new FakeElement("input"));
start.id = "startTime";
start.attrs.placeholder = "开始时间";
const save = form.append(new FakeElement("button", "保存"));
const cancel = form.append(new FakeElement("button", "取消"));

let editorOpen = false;
for (const node of [form, school, degree, start, save, cancel]) node.isConnected = false;
add.click = () => {
  editorOpen = true;
  for (const node of [form, school, degree, start, save, cancel]) node.isConnected = true;
};
cancel.click = () => {
  editorOpen = false;
  for (const node of [form, school, degree, start, save, cancel]) node.isConnected = false;
};

const interactiveSelectorFragment = "input, textarea, select";
const documentStub = {
  nodeType: 9,
  documentElement: root,
  body,
  querySelectorAll(selector) {
    if (selector === "#eduNav") return [nav];
    if (selector.includes("button, a, [role='button'], [onclick], div, span, li")) return editorOpen ? [navLi, nav, add, save, cancel] : [navLi, nav, add];
    if (selector.includes(interactiveSelectorFragment)) return editorOpen ? [school, degree, start] : [];
    if (selector === "*") return editorOpen ? [navLi, nav, add, form, school, degree, start, save, cancel] : [navLi, nav, add];
    if (selector === "label") return [];
    if (selector === '[id="schoolName"]') return editorOpen ? [school] : [];
    if (selector === '[id="educationLevel"]') return editorOpen ? [degree] : [];
    if (selector === '[id="startTime"]') return editorOpen ? [start] : [];
    if (selector.includes('[name="schoolName"]')) return editorOpen ? [school] : [];
    if (selector.includes('[name="educationLevel"]')) return editorOpen ? [degree] : [];
    if (selector.includes('[placeholder="请输入学校名称"]')) return editorOpen ? [school] : [];
    if (selector.includes('[placeholder="开始时间"]')) return editorOpen ? [start] : [];
    return [];
  },
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; },
  createEvent() { return { initMouseEvent() {} }; }
};

global.HTMLElement = FakeElement;
global.Element = FakeElement;
global.document = documentStub;
global.MouseEvent = function () {};
global.window = {
  AF: { Utils: { sleep: async () => {} } },
  top: null,
  location: { hostname: "zhaopin.cnpc.com.cn", pathname: "/web/createResume.html", href: "https://zhaopin.cnpc.com.cn/web/createResume.html" },
  innerWidth: 1400,
  innerHeight: 900,
  getComputedStyle: () => ({ display: "block", visibility: "visible", cursor: "default", zIndex: "0" }),
  sessionStorage: { getItem() { return null; }, removeItem() {} },
  postMessage() {}
};
window.top = window;

const realSetTimeout = global.setTimeout;
global.setTimeout = () => 0;
const source = fs.readFileSync(path.join(__dirname, "..", "autofill-plugin", "content", "special-site-workflow.js"), "utf8");
new Function(source)();
global.setTimeout = realSetTimeout;

(async () => {
  const api = window.AF.SpecialSiteWorkflow._test;
  assert.strictEqual(typeof api.runAnalyzedEducationAddEditorProbe, "function");
  const result = await api.runAnalyzedEducationAddEditorProbe({
    section: { text: "教育背景", selectorHint: "#eduNav" },
    requireSectionActive: true,
    editorOpenTimeoutMs: 50,
    editorCloseTimeoutMs: 50
  });
  assert.strictEqual(result.sectionActiveBefore, true);
  assert.strictEqual(result.addButtonFound, true);
  assert.strictEqual(result.addClickDispatched, true);
  assert.strictEqual(result.editorOpened, true);
  assert(result.newVisibleControlCount >= 3, "probe should observe newly visible education controls");
  assert(result.fields.some((field) => field.id === "schoolName"), "sanitized probe should include school field structure");
  assert(result.fields.some((field) => field.id === "educationLevel"), "sanitized probe should include education level structure");
  assert.strictEqual(result.safeCloseFound, true);
  assert.strictEqual(result.safeCloseText, "取消");
  assert.strictEqual(result.safeCloseClickDispatched, true);
  assert.strictEqual(result.editorClosed, true);
  assert.strictEqual(result.leftOpen, false);
  assert.strictEqual(result.result, "probe_complete_closed");
  assert.strictEqual(result.safety.valuesCaptured, false);
  assert.strictEqual(result.safety.fieldsWritten, false);
  assert.strictEqual(result.safety.saveExecuted, false);

  const main = fs.readFileSync(path.join(__dirname, "..", "main.js"), "utf8");
  const preload = fs.readFileSync(path.join(__dirname, "..", "ui-preload.js"), "utf8");
  const renderer = fs.readFileSync(path.join(__dirname, "..", "renderer.js"), "utf8");
  const index = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
  assert(main.includes('kind: "education_add_editor_probe"'));
  assert(main.includes('loadLatestAnalyzedSectionProbePlan(rawUrl, "教育背景")'));
  assert(preload.includes('probeEducationEditor'));
  assert(renderer.includes('probeEducationEditor'));
  assert(!index.includes('id="educationProbe"'), "Build160 removes the manual education probe toolbar entry");
  assert(!/save\.click|保存教育背景/.test(source.slice(source.indexOf("async function runAnalyzedEducationAddEditorProbe"), source.indexOf("function analyzedEducationPreviewNormalizeProvince"))), "education probe must not invoke save behavior");
  console.log("education add editor probe fixture: PASS");
})().catch((error) => { console.error(error); process.exitCode = 1; });
