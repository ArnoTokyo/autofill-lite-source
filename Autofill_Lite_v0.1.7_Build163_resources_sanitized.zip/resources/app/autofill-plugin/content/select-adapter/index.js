// content/select-adapter/index.js — 下拉选择器适配器工厂 (最后加载)
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   SelectAdapter.detectType (混淆名 f.detectType, 模块7830): 行 23488-23579
//   SelectAdapter.create     (混淆名 f.create, 模块7830):     行 23400-23486
//
// detectType 级联顺序完全照抄源码 (顺序很重要，例如一个元素同时嵌套了 ant-select 和
// el-select 时，谁先判定谁生效):
//   1. tagName === "SELECT" -> native
//   2. class 以 "brick" 开头 / closest|querySelector "[class^='brick']" -> brick
//   3. class 包含 "kuma" / closest|querySelector kuma 相关 -> kuma
//   4. class 包含 "rocket-select" -> rocket
//   5. data-chakra 属性 / class 包含 "chakra" -> chakra
//   6. class 包含 "ant-" -> ant
//   6. class 包含 "ud__select" / closest ".ud__select__selector" -> ud
//   7. bitable 相关 class/matches -> bitable
//   8. class 以 "layui-" 开头 -> layui
//   9. class 以 "el-" 开头 -> element
//   10. class 包含 "phoenix-select"(__input) -> phoenix
//   11. 遍历全局框架选择器配置表 SA._config 的 container 选择器 (对应源码遍历 n.n) ->
//       命中的 key (iview/layui/bootstrap/material/chakra/vuetify/semantic/jquery/phoenix 等)
//   12. 以上都没命中，递归查 parentElement (最多往上 2 层，对应源码 r>1 截断)
//   13. 全部失败 -> null
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};

  // 源码用 Array.from(e.classList).some(...) (行23496等)，这里保持一致而不是用
  // Array.prototype.some.call，因为后者依赖 classList 严格数组式的 length/索引语义，
  // Array.from 对任何可迭代对象都更稳妥。
  function classListSome(el, predicate) {
    try {
      return !!el.classList && Array.from(el.classList).some(predicate);
    } catch (e) {
      return false;
    }
  }

  function safeClosest(el, selector) {
    try {
      return el.closest && el.closest(selector);
    } catch (e) {
      return null;
    }
  }

  function safeQuery(el, selector) {
    try {
      return el.querySelector && el.querySelector(selector);
    } catch (e) {
      return null;
    }
  }

  function safeMatches(el, selector) {
    try {
      return el.matches && el.matches(selector);
    } catch (e) {
      return false;
    }
  }

  function detectType(element, depth) {
    depth = depth || 0;
    if (!element) return null;

    if (element.tagName === "SELECT") return "native";

    if (
      classListSome(element, function (c) { return c.indexOf("brick") === 0; }) ||
      safeClosest(element, '[class^="brick"]') ||
      safeQuery(element, '[class^="brick"]')
    ) {
      return "brick";
    }

    try {
      if (
        classListSome(element, function (c) { return c.includes("rocket-select"); }) ||
        safeClosest(element, ".rocket-select") ||
        safeQuery(element, ".rocket-select")
      ) {
        return "rocket";
      }
    } catch (e) {}

    try {
      if (
        classListSome(element, function (c) { return c.includes("kuma"); }) ||
        safeClosest(element, '[class*="kuma"], .kuma-select, .kuma-select2') ||
        safeQuery(element, '[class*="kuma"], .kuma-select, .kuma-select2')
      ) {
        return "kuma";
      }
    } catch (e) {}

    try {
      if (
        element.getAttribute && element.getAttribute("data-chakra") ||
        classListSome(element, function (c) { return c.includes("chakra"); }) ||
        safeClosest(element, '[data-chakra], [class*="chakra"]') ||
        safeQuery(element, '[data-chakra], [class*="chakra"]')
      ) {
        return "chakra";
      }
    } catch (e) {}

    try {
      if (
        classListSome(element, function (c) { return c.indexOf("aui-") === 0 || c.includes("aui-select"); }) ||
        safeClosest(element, ".aui-select") ||
        safeQuery(element, ".aui-select")
      ) {
        return "aui";
      }
    } catch (e) {}

    try {
      if (
        safeMatches(element, ".ant-cascader-picker, .ant-select.ant-cascader, .ant-cascader") ||
        safeClosest(element, ".ant-cascader-picker, .ant-select.ant-cascader, .ant-cascader") ||
        safeQuery(element, ".ant-cascader-picker, .ant-select.ant-cascader, .ant-cascader")
      ) {
        return "ant-cascader";
      }
    } catch (e) {}

    try {
      if (
        classListSome(element, function (c) { return c.includes("ant-"); }) ||
        safeClosest(element, '[class*="ant-"]') ||
        safeQuery(element, '[class*="ant-"]')
      ) {
        return "ant";
      }
    } catch (e) {}

    try {
      if (
        classListSome(element, function (c) { return c === "next-select" || c.includes("next-select"); }) ||
        safeClosest(element, ".next-select") ||
        safeQuery(element, ".next-select")
      ) {
        return "next";
      }
    } catch (e) {}

    try {
      if (
        classListSome(element, function (c) { return c.indexOf("sd-Select") === 0 || c.includes("sd-Select"); }) ||
        safeClosest(element, '[class^="sd-Select"], [class*=" sd-Select"], [class*="sd-Select"]') ||
        safeQuery(element, '[class^="sd-Select"], [class*=" sd-Select"], [class*="sd-Select"]')
      ) {
        return "sd";
      }
    } catch (e) {}

    try {
      if (
        classListSome(element, function (c) { return c.includes("ud__select"); }) ||
        safeClosest(element, ".ud__select, .ud__select__selector") ||
        safeQuery(element, ".ud__select, .ud__select__selector")
      ) {
        return "ud";
      }
    } catch (e) {}

    try {
      var bitableSelector = ".bitable-single-selector-editor, .bitable-multi-selector-editor, .bitable-3356de__select, .b-select-dropdown-menu";
      if (
        safeClosest(element, ".bitable-single-selector-editor, .bitable-multi-selector-editor") ||
        safeMatches(element, bitableSelector) ||
        safeQuery(element, ".bitable-single-selector-editor, .bitable-multi-selector-editor, .b-select-dropdown-menu")
      ) {
        return "bitable";
      }
    } catch (e) {}

    try {
      if (
        classListSome(element, function (c) { return c.indexOf("layui-") === 0; }) ||
        safeClosest(element, '[class*="layui-"], .layui-form, .layui-form-select, .layui-select') ||
        safeQuery(element, '[class*="layui-"], .layui-form-select, .layui-select')
      ) {
        return "layui";
      }
    } catch (e) {}

    try {
      if (
        safeMatches(element, ".el-cascader") ||
        safeClosest(element, ".el-cascader") ||
        safeQuery(element, ".el-cascader")
      ) {
        return "element-cascader";
      }
    } catch (e) {}

    try {
      if (
        classListSome(element, function (c) { return c.indexOf("el-") === 0; }) ||
        safeClosest(element, '[class^="el-"], [class*=" el-"]') ||
        safeQuery(element, '[class^="el-"], [class*=" el-"]')
      ) {
        return "element";
      }
    } catch (e) {}

    try {
      if (
        classListSome(element, function (c) { return c.includes("phoenix-select") || c.includes("phoenix-select__input"); }) ||
        safeClosest(element, '[class*="phoenix-select"], .phoenix-select__input') ||
        safeQuery(element, '[class*="phoenix-select"], .phoenix-select__input')
      ) {
        return "phoenix";
      }
    } catch (e) {}

    try {
      if (
        safeMatches(element, "input.ConstDictSingleSelect") ||
        safeClosest(element, "input.ConstDictSingleSelect") ||
        safeQuery(element, "input.ConstDictSingleSelect")
      ) {
        return "legacyZhiye";
      }
    } catch (e) {}

    try {
      if (
        safeMatches(element, ".select-wrapper") ||
        safeClosest(element, ".select-wrapper") ||
        safeQuery(element, ".select-wrapper") ||
        safeMatches(element, ".select_box, .multi_select_box, .multi_search_selector, .search_selector") ||
        safeClosest(element, ".select_box, .multi_select_box, .multi_search_selector, .search_selector") ||
        safeQuery(element, ".select_box, .multi_select_box, .multi_search_selector, .search_selector") ||
        safeMatches(element, ".示例资料-select, .country-select, .province-select, .city-select, .area-select, .region-select, .custom-select, [class*='select-box']") ||
        safeClosest(element, ".示例资料-select, .country-select, .province-select, .city-select, .area-select, .region-select, .custom-select, [class*='select-box']") ||
        safeQuery(element, ".示例资料-select, .country-select, .province-select, .city-select, .area-select, .region-select, .custom-select, [class*='select-box']")
      ) {
        return "custom";
      }
    } catch (e) {}

    try {
      var config = SA._config || {};
      for (var key in config) {
        if (!Object.prototype.hasOwnProperty.call(config, key)) continue;
        var containerSelector = config[key].container;
        if (!containerSelector) continue;
        if (safeMatches(element, containerSelector) || safeClosest(element, containerSelector)) {
          return key;
        }
      }
    } catch (e) {}

    if (depth > 1 || element == null || !element.classList) return null;
    if (element.parentElement) {
      var fromParent = detectType(element.parentElement, depth + 1);
      if (fromParent) return fromParent;
    }
    return null;
  }

  // 兜底: 完全无法识别的元素，当作原生 select-like 处理 —— 直接尝试设 .value，
  // 派发 change，看值是否真的生效了。
  async function fallbackSetValue(element, value) {
    try {
      var target = Array.isArray(value) ? value[0] : value;
      if (target === undefined || target === null) return false;
      if (element.tagName === "SELECT" && AF.SelectAdapter._setNativeSelectValue) {
        return await AF.SelectAdapter._setNativeSelectValue(element, value);
      }
      var before = element.value;
      element.value = target;
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
      return element.value !== before || element.value === String(target);
    } catch (e) {
      return false;
    }
  }

  function create(element, valueType, sectionEl, customSelectors, capabilityContext) {
    valueType = valueType === undefined ? "string" : valueType;
    sectionEl = sectionEl === undefined ? null : sectionEl;

    var capability = capabilityContext && capabilityContext.capability
      ? capabilityContext.capability
      : capabilityContext || null;

    if (customSelectors) {
      var customFactory = SA._registry["custom"];
      if (customFactory) return customFactory(element, valueType, sectionEl, customSelectors, capability);
    }

    var type = null;
    try {
      type = detectType(element);
    } catch (e) {
      type = null;
    }

    if (capability && capability.forceAdapter === true && capability.adapter && SA._registry[capability.adapter]) {
      type = String(capability.adapter);
    }
    var factory = type && SA._registry[type];
    if (factory) {
      try {
        if (capability && capability.adapter && String(capability.adapter) !== String(type)) capability = null;
        var adapter = factory(element, valueType, sectionEl, capability);
        if (!capability || !adapter || typeof adapter.selectValue !== "function") return adapter;
        return {
          selectValue: async function (value) {
            var previous = SA._currentCapability;
            SA._currentCapability = capability;
            try {
              return await adapter.selectValue(value);
            } catch (configuredError) {
              // 配置动作出现异常时才回退旧适配器；正常的“没有匹配项”返回 false
              // 必须保留，避免 strict/leaveEmpty 被旧智能相似度反向误选。
              try {
                var legacyAdapter = factory(element, valueType, sectionEl);
                return legacyAdapter && typeof legacyAdapter.selectValue === "function"
                  ? await legacyAdapter.selectValue(value)
                  : false;
              } catch (legacyError) {
                return false;
              }
            } finally {
              SA._currentCapability = previous || null;
            }
          },
        };
      } catch (e) {
        // 掉到下面的兜底
      }
    }

    // 未识别到已知框架，或对应 registry 未注册 -> 走原生 select-like 兜底
    return {
      selectValue: async function (value) {
        return await fallbackSetValue(element, value);
      },
    };
  }

  SA.detectType = detectType;
  SA.create = create;
})();
