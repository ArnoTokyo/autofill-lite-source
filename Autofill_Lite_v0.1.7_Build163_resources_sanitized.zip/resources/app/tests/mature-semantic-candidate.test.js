"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { compileSemanticSiteCandidate } = require("../ai-site-config-candidate");

const review = {
  page: { hostname: "example.zhiye.com", pathname: "/form" },
  reviewFields: [
    {
      fieldId: "f1",
      label: "现从事职业",
      graphSectionId: "s1",
      graphSectionTitle: "示例资料",
      graphRowLabel: "现从事职业",
      graphLinkConfidence: 0.99,
      patchTarget: { kind: "semantic_label", label: "现从事职业" }
    },
    {
      fieldId: "f2",
      label: "期望工作城市",
      graphSectionId: "s1",
      graphSectionTitle: "示例资料",
      graphRowLabel: "期望工作城市",
      graphLinkConfidence: 0.99,
      patchTarget: { kind: "semantic_label", label: "期望工作城市" }
    },
    {
      fieldId: "f3",
      label: "模糊字段",
      graphSectionId: "s2",
      graphSectionTitle: "示例资料",
      graphLinkConfidence: 0.99,
      patchTarget: { kind: "semantic_label", label: "模糊字段" }
    }
  ]
};
const patch = {
  decisions: [
    { fieldId: "f1", decision: "map", category: "jobIntention", fieldKey: "position", confidence: 0.93 },
    { fieldId: "f2", decision: "map", category: "jobIntention", fieldKey: "city", confidence: 0.91 },
    { fieldId: "f3", decision: "map", category: "示例资料", fieldKey: "major", confidence: 0.72 }
  ]
};
const out = compileSemanticSiteCandidate(review, patch, { minConfidence: 0.8 });
assert.strictEqual(out.schemaType, "autofill-lite-site-config-candidate");
assert.strictEqual(out.configTemplate._serverStatus, "candidate");
assert.strictEqual(out.configTemplate._autoConfigStrategy.mode, "local_first_semantic_candidate_v2");
assert.strictEqual(out.summary.aiAuthoredSelectors, false);
assert.strictEqual(out.semanticPatch.fieldMappings.length, 2);
assert.strictEqual(out.semanticPatch.sectionMappings.length, 1);
assert.strictEqual(out.semanticPatch.sectionMappings[0].category, "jobIntention");
assert.strictEqual(out.semanticPatch.sectionMappings[0].label, "示例资料");
assert.ok(out.skipped.some((item) => item.fieldId === "f3" && item.reason === "low_confidence"));
assert.ok(!Object.prototype.hasOwnProperty.call(out.configTemplate, "selectors"), "AI candidate must not invent selectors");

const main = fs.readFileSync(path.join(__dirname, "..", "main.js"), "utf8");
assert.ok(main.includes("installPrefetchedSemanticCandidate"), "main must install mature-base semantic candidate");
assert.ok(main.includes('reason: "exact_mature_config_priority"'), "exact mature config must keep priority");
assert.ok(main.includes('reason: "no_mature_base_config"'), "unknown pages must not receive an invented generic SiteConfig yet");
assert.ok(main.includes("AF.SiteLoader.setPrefetchedConfig"), "mature SiteLoader prefetched lifecycle must be reused");
console.log("mature semantic candidate tests passed");
