// Build157 smoke test placeholder
// Verifies InputAdapter contract is present in runtime bundles.
const fs=require('fs');
const path=require('path');
const file=path.join(__dirname,'..','autofill-plugin','content','input-adapter','index.js');
if(!fs.existsSync(file)) throw new Error('InputAdapter missing');
console.log('Build157 input adapter PASS');
