// content/field-dictionary.js — 字段字典: 中文标签 -> 标准字段名 映射表
// 源码参考: webcrack-output/content/deobfuscated.js 行 24222-24385 (var f = {...})
// 开发任务书.md 任务6.4: "直接复制，一个字符不改"。
//
// 本文件的每个类别别名数组，只要源码 f 对象里有对应类别/字段，就原样照抄该数组
// (未做任何增删改动)。源码里缺失的类别 (patents / awards / languageSkills /
// otherLanguageSkills / campusLeadership / campusActivities / familyMembers) 以及
// mock/resume-data.json 里存在但源码字典未覆盖的字段 key (如 basicInfo.resumeName /
// education.majorCourses 等)，按开发任务书要求、参照
// 反编译分析文档/AI提示词.md 的"标准简历数据字段名"人工补充了合理的别名 —— 这些补充
// 均在下方以行内注释标出 "[补充]"，与源码原文区分开。
//
// 字段 key 命名以 反编译分析文档/mock/resume-data.json (权威运行时简历数据结构样本)
// 为准；别名数组内容以源码字典为准，源码没有的字段才新增合理别名。
//
// 契约形状 (固定，DataMatcher 依赖):
//   objectType 类别 (basicInfo/jobIntention/selfIntroduction): { labels: [...], fields: {...} }
//     —— labels 不可省! 结构化模式靠分区标题(个人信息/求职意向...)匹配到类别, 缺了整块填不上
//   arrayType  类别 (education/workExperience/...):            { labels: [...], fields: {...} }
//   特殊类别 combinedExperience / otherLanguageSkills:          { labels: [...] }  (无 fields)
(function () {
  "use strict";

  var AF = (window.AF = window.AF || {});

  AF.FieldDictionary = {
    // ============ basicInfo (对象型, 源码行24223-24265) ============
    basicInfo: {
      // labels 必须保留: 结构化模式靠分区标题匹配类别, 缺了它"个人信息"区整块被跳过 (源码行24224)
      labels: ["基本信息", "证件信息", "个人资料", "个人信息", "联系信息","基础信息", "1. 个人信息（必填）", "个人信息*", "基本资料"],
      fields: {
        idNumber: ["证件号", "身份证号", "个人证件", "身份证", "证件号码", "证件", "证件信息"],
        highestEducation: ["最高学历", "学历水平", "最高学历水平", "学历"],
        highestDegree: ["最高学位", "学位类型", "最高学位类型", "学位"],
        highestMajor: ["最高学历专业", "专业", "主修专业"],
        name: ["姓名", "名字", "真实姓名", "姓名请确保填写的姓名与证件姓名一致"],
        gender: ["性别"],
        birthDate: ["出生年月", "出生日期", "出生日期(年龄)", "出生日期 (年龄)", "生日"],
        graduationDate: ["毕业时间", "预计毕业时间", "应届毕业时间", "毕业日期"],
        age: ["年龄"],
        height: ["身高", "身高(cm)", "身高（cm）", "身高（厘米）", "身高(厘米)"],
        weight: ["体重", "体重(kg)", "体重（kg）", "体重（公斤）", "体重(公斤)"],
        country: ["国家", "国家/地区", "国籍/地区", "当前所处国家/地区", "国籍", "证件签发国家/地区", "签发国家/地区", "证件签发国家", "国家/地区请选择证件签发国家/地区"],
        nativePlace: ["籍贯", "家乡"],
        ethnicity: ["民族", "名族"],
        formerName: ["曾用名", "曾用姓名"],
        birthOrigin: ["出生地", "出生地(籍贯)", "生源地", "高考生源地", "生源地/高考所在地"],
        currentAddress: ["现居地", "居住地", "现居住地", "现居住城市", "联系地址", "通信地址", "通讯地址", "目前所在地", "当前居住城市", "当前所处地", "所在地", "所在城市"],
        currentResidence: ["现居住地"],
        maritalStatus: ["婚姻状况", "婚否"],
        phone: ["手机号", "联系方式", "电话号码", "手机", "手机号码", "联系电话", "移动电话", "电话"],
        wechat: ["微信", "微信号"],
        qq: ["QQ", "QQ账号", "QQ号"],
        email: ["邮箱", "电子邮箱", "电子邮件", "邮箱地址", "常用邮箱", "电子邮箱建议填写个人邮箱地址，非校园邮箱"],
        homepage: ["个人主页", "GitHub", "博客链接"],
        currentIdentity: ["当前身份", "学生/非学生"],
        jobStatus: ["求职状态", "在职-离职-应届生"],
        graduationSchool: ["毕业院校", "毕业院校名称", "学校名称", "学校全称", "就读学校"],
        position: ["期望职位", "目标岗位", "期望从事职业"],
        industry: ["期望行业", "行业倾向", "期望从事行业"],
        city: ["期望城市", "期望工作城市"],
        salary: ["期望薪资", "薪资", "期望月薪(税前)"],
        availability: ["到岗时间", "入职时间"],
        acceptOvertime: ["是否接受加班", "加班接受度"],
        acceptBusinessTrip: ["是否接受出差", "出差接受度"],
        employmentType: ["工作性质", "全职/兼职"],
        cityFlexible: ["是否城市服从分配", "工作城市是否服从分配", "是否接受调剂"],
        selfIntroduction: ["自我评价", "自我介绍", "个人评价", "自我描述", "其他信息"],
        acceptAdjustment: ["是否接受调剂", "接受调剂", "愿意调剂"],
        // [补充] mock/resume-data.json 里 basicInfo 存在但源码字典缺失的 key
        resumeName: ["简历名称", "简历标题", "简历名"],
        expectedPosition: ["期望岗位", "应聘职位", "求职意向岗位"],
        expectedLocation: ["期望地点", "期望工作地点", "期望工作地", "期望城市", "意向城市", "意向工作地点"],
        expectedSalary: ["期望薪资", "期望薪酬", "期望月薪", "期望年薪", "薪资期望"],
        // [补充] 参照 AI提示词.md 标准字段名清单人工补充的常见字段
        politicalStatus: ["政治面貌"],
        partyJoinDate: ["入党/团时间", "入党时间", "入团时间"],
        overseasMigration: ["移居国外情况", "是否移居国外"],
        currentStatus: ["当前状态", "目前状态"],
        hasMilitaryService: ["是否有服役经历", "服役经历"],
        workYears: ["工作年限", "工龄"],
        bankWorkYears: ["银行工作年限", "金融工作从业年限", "金融工作从业年限（年）"],
        healthStatus: ["健康状况"],
        emergencyContactName: ["紧急联系人", "紧急联系人姓名", "备用联系人"],
        emergencyPhone: ["紧急联系电话", "紧急联系人电话", "紧急联系人手机", "紧急联系人手机号", "备用联系方式"],
        emergencyContactRelation: ["紧急联系人与本人关系", "紧急联系人关系", "与紧急联系人关系"],
        familyCity: ["家庭所在城市", "家庭城市", "家庭所在地城市"],
        familyDistrict: ["家庭所在区县", "家庭区县", "家庭所在区"],
        schoolCity: ["学校所在城市", "学校城市", "院校所在城市"],
        schoolDistrict: ["学校所在区县", "学校区县", "院校所在区县"],
        familyLocation: ["家庭所在地", "家庭所在地（家人常住地）", "家人常住地"],
        // 单独的“院校所在城市”是城市单选字段，不能让“院校所在地”这类
        // 综合地址语义通过包含匹配抢占。
        schoolAffiliation: ["办学属地", "院校属性", "院校所属地", "境内/境外院校类别", "国内/海外院校类别"],
        schoolLocation: ["学校所在地", "学校所在地区", "学校所在城市", "院校所在地", "院校所在城市", "学校城市", "就读城市", "学校地区", "学校所在地城市"],
        studentType: ["生源类型", "考生类型", "学生类型"],
        currentAddressDetail: ["现居住地详细地址", "现居详细地址", "居住详细地址", "详细居住地址"],
        religion: ["宗教信仰", "信仰"],
        isReferral: ["是否内推", "内推", "是否有内推"],
        acceptPositionAdjustment: ["是否接受岗位调剂", "岗位调剂", "接受岗位调剂", "是否服从调剂"],
        writtenExamCity: ["请选择您的笔试意向城市", "请选择参加笔试的城市", "笔试意向城市", "笔试城市", "笔试地点"],
        isPoorStudent: ["是否贫困生", "贫困生"],
        postalCode: ["邮政编码", "邮编"],
        recruitmentChannel: ["了解招聘信息的渠道", "招聘信息渠道", "获知渠道", "招聘渠道", "信息来源"],
        workExperienceYears: ["工作经验", "工作经历年限", "工作年限", "从业年限"],
        hobbies: ["兴趣爱好", "爱好", "个人爱好"],
        isFreshGraduate: ["是否应届毕业生", "应届生"],
        idType: ["证件类型", "证件号码类型"],
        hukouLocation: ["户口所在地", "户籍所在地", "当前户籍所在地"],
        archiveLocation: ["档案所在地"],
        isCurrentAddress: ["是否现居住地", "是否为现居住地"],
        hasNonCompete: ["是否有竞业限制", "竞业限制"],
        hasLaborDispute: ["是否与其他单位存在劳动纠纷", "劳动纠纷"],
        wasDismissed: ["是否曾被其他单位惩处、辞退", "是否曾被辞退", "惩处辞退"],
        hasBadRecord: ["是否存在违法、违纪、违规或其他不良记录", "不良记录", "违法违纪违规记录"],
        hasRelativeInCompany: ["是否有亲属在本单位", "是否有亲属在华夏银行", "是否有亲属在华夏银行，及其子公司、实际控制公司工作", "是否有亲属在荣耀终端有限公司及其关联公司任职", "亲属在本单位工作"],
        custom_relativeName: ["亲属姓名"],
        custom_relationshipWithApplicant: ["与本人关系"],
        custom_relativeCompanyDepartment: ["亲属所在公司或部门名称", "亲属所在公司", "亲属所在部门"],
        familyAddress: ["家庭住址", "家庭地址", "家庭详细地址"],
        hasForeignResidencePermit: ["是否拥有外国国籍、国（境）外永久居留权或长住许可", "是否拥有外国国籍", "境外永久居留权", "国境外永久居留权", "长住许可"],
        hasSeriousDisease: ["是否有精神病、传染病、生理缺陷及其他严重疾病", "是否有严重疾病", "精神病传染病生理缺陷", "重大疾病声明"],
        specificRecruitmentType: ["专项招聘类别", "专项招聘类别!"],
      },
    },

    // ============ jobIntention (对象型, 源码行24266-24279) ============
    jobIntention: {
      labels: ["求职期望", "求职意向", "职业倾向", "意向信息", "求职工作地意向", "工作地意向", "工作地点意向"],
      fields: {
        position: ["期望职位", "目标岗位", "期望从事职业"],
        job51Position: ["标准岗位", "标准职位", "岗位职能"],
        industry: ["期望行业", "行业倾向", "期望从事行业"],
        city: ["期望城市", "工作地点", "期望工作城市", "期望工作地点", "第一意向工作地", "第二意向工作地", "可接受工作地", "意向工作地", "意向工作地点"],
        currentLocation: ["现居地点", "现居地址", "当前居住地", "当前所在地", "现居城市"],
        expectedLocation: ["意向地点", "期望地点", "期望工作地点", "意向工作地点", "意向城市"],
        salary: ["期望薪资", "薪资", "期望月薪(税前)", "期望薪酬", "期望薪酬（万元/年）"],
        availability: ["到岗时间", "入职时间"],
        acceptOvertime: ["是否接受加班", "加班接受度"],
        acceptBusinessTrip: ["是否接受出差", "出差接受度"],
        employmentType: ["工作性质", "全职/兼职"],
        cityFlexible: ["是否城市服从分配", "工作城市是否服从分配", "是否接受调剂", "接受调剂", "是否接受工作地变更", "是否接受工作地点变更", "工作地变更"],
        // [补充] mock 数据里 jobIntention 存在但源码字典缺失的 key
        currentSalary: ["当前薪资", "现薪资", "目前薪资", "现月薪(税前)", "当前月薪(税前)", "目前月薪(税前)"],
        acceptAdjustment: ["是否接受调剂", "接受调剂", "是否服从调剂"],
        obeyAssignment: ["是否服从分配", "服从分配", "岗位服从分配", "是否服从岗位调配", "服从岗位调配"],
      },
    },

    // ============ education (数组型, 源码行24280-24298) ============
    education: {
      labels: [
        "教育经历", "学历背景", "教育情况", "2. 教育背景（必填）",
        "教育经历请完整填写大学及以上的教育经历哦", "教育背景",
        "教育经历*从最高学历开始填写哦，其他学历可新增，填写后请仔细检查学历信息是否正确。",
        "学历",
      ],
      fields: {
        studentId: ["学号", "学生学号", "学籍号"],
        school: ["学校名称", "毕业院校", "学校全称", "学校", "就读学校", "毕业学校"],
        schoolProvince: ["学校所在省份", "院校所在省份", "学校省份"],
        level: ["学历层次", "学历类别", "学历", "教育程度", "取得学历"],
        educationType: ["学历类型", "学习方式", "学习形式", "学习类型", "就读方式", "就读形式", "培养方式", "培养类型", "受教育类型", "教育形式", "教育类型", "学历性质", "学历形式", "是否统招", "是否全日制"],
        isWorkStudy: ["是否在职期间获取", "在职期间获取", "是否在职取得", "是否在职获得", "在职取得学历", "在职期间获得"],
        degree: ["学位", "获得学位", "学位名称", "学位等级", "所获学位", "授予学位", "取得学位", "获得学位名称"],
        degreeType: ["学位类型", "学位性质"],
        department: ["院系", "学院", "学校院系", "学校学院", "所在院系", "所在学院", "就读院系/学院", "就读院系", "就读学院", "学院名称", "所在院系/研究所"],
        major: ["专业", "主修专业", "专业名称", "专业方向", "就读专业", "专业类别/专业", "具体专业"],
        researchDirection: ["研究方向", "专业方向", "研究领域", "主要研究方向", "研究领域/方向", "硕士研究方向", "科研方向", "研究类别"],
        majorCategory: ["专业分类", "专业大类", "专业类别", "学科属性", "学科门类"],
        majorSubcategory: ["二级专业类", "专业所属类别", "专业细分类"],
        schoolAffiliation: ["办学属地", "院校属性", "院校所属地", "境内/境外院校类别", "国内/海外院校类别"],
        schoolLocation: ["学校所在地", "院校所在地", "学校所在地城市", "目前就读地", "当前就读地"],
        schoolDistrict: ["学校所在区县", "学校区县", "院校所在区县"],
        schoolType: ["学校类别", "院校类别", "学校类型", "院校类型", "是否985/211", "是否985或211"],
        czbankMajorCategory: ["专业分类", "专业类别", "浙商银行专业分类"],
        city: ["城市", "学校城市", "就读城市", "就读院校所在城市", "院校所在城市", "学校所在城市", "毕业院校所在城市", "院校城市", "学校所在地", "院校所在地", "毕业院校所在国家/地区", "院校所在国家/地区", "学校所在国家/地区"],
        duration: ["在校时间", "起止年月", "起止时间", "时间","就读时间"],
        studyLength: ["学制", "学习年限", "几年制", "学制类型", "修业年限"],
        gpa: ["GPA", "绩点", "个人绩点", "gpa", "gpa成绩", "成绩平均分", "成绩平均分（百分制）", "GPA-GPA", "GPA（请以四分制计算分数）"],
        gpaScore: ["GPA实际绩点", "GPA（实际绩点）", "实际绩点", "绩点分数"],
        gpaTotal: ["GPA满分", "绩点满分", "满分绩点", "满绩绩点", "院校满绩绩点", "所在院校的满绩绩点", "GPA总分"],
        startTime: ["开始时间", "入学时间"],
        endTime: ["结束时间", "毕业时间", "毕业或预计毕业时间", "预计毕业时间"],
        classRank: ["本人班级排名", "班级排名", "所在班级排名", "班级成绩排名", "班级名次", "年级排名", "成绩排名", "排名", "专业排名"],
        classSize: ["班级总人数", "总人数"],
        isOverseas: ["是否海外教育经历", "是否境外学历", "是否境外", "是否海外", "海外教育经历", "境外学历", "境外"],
        hasOverseasStudy: ["该段教育经历内是否有国外、港澳台地区学习经历", "该段教育经历是否有境外学习经历", "是否有境外学习经历"],
        secondDegreeOrMinor: ["该段学历是否有第二学位或辅修专业", "第二学位或辅修专业", "第二学位或辅修"],
        integratedTraining: ["是否贯通式培养", "贯通式培养"],
        gaokaoAdmissionBatch: ["高考录取批次", "高考批次", "录取批次"],
        ccbSchoolType: ["学校类别"],
        ccbHighestEducation: ["是否最高学历"],
        isHighestEducation: ["是否最高学历"],
        isFirstEducation: ["是否第一学历"],
        ccbHighestDegree: ["是否最高学位"],
        isExchangeStudent: ["是否为交换生", "该学历是否为交换生", "交换生"],
        isDoubleDegree: ["是否双学位", "双学位"],
        languageAbility: ["语言能力"],
        // [补充] mock 数据里 education 存在但源码字典缺失的 key
        majorCourses: ["主修课程", "课程", "专业课程"],
        majorDescription: ["专业描述", "专业介绍", "学习内容"],
      },
    },

    // ============ workExperience (数组型, 源码行24308-24319) ============
    workExperience: {
      labels: ["工作经历", "职业经历", "工作（实习）经历", "工作(实习)经历"],
      fields: {
        company: ["公司名称", "雇主", "公司", "企业名称", "工作单位", "单位名称"],
        companyNature: ["企业性质", "公司性质", "单位性质", "单位类别"],
        department: ["所在部门", "部门", "部门名称"],
        industry: ["行业类别", "所属行业", "公司行业", "企业行业"],
        workLocation: ["工作地点", "工作所在地", "实习地点", "实习所在地", "办公地点", "所在城市", "工作所在城市", "实习所在城市", "工作城市", "实习城市"],
        workMode: ["工作形式", "用工形式", "工作方式", "用工方式", "工作性质"],
        workType: ["工作类型", "人员类型", "任职类型", "实习或正式"],
        position: ["职位名称", "岗位", "工作岗位"],
        job51Position: ["标准岗位", "标准职位", "岗位职能"],
        jobLevel: ["岗位级别", "职位级别", "职级", "职务级别"],
        duration: ["工作时间", "起止年月", "起止时间", "任职时间"],
        responsibilities: ["主要职责", "工作内容"],
        achievements: ["工作成果", "绩效亮点", "工作职责", "工作描述", "实习描述", "描述", "职责与业绩", "主要业绩", "主要实践内容说明："],
        startTime: ["开始时间"],
        endTime: ["结束时间"],
        reasonForLeaving: ["离职原因", "离任原因", "离职理由", "离开原因"],
        custom_companySize: ["企业规模", "公司规模"],
        custom_subordinateCount: ["下属人数"],
        custom_income: ["收入情况", "薪资收入"],
        ccbWorkType: ["工作类型"],
        ccbDepartmentPosition: ["部门及岗位"],
        ccbDescription: ["工作描述"],
        country: ["所在国家", "工作所在国家"],
        custom_directSupervisorName: ["直接上司姓名", "上司姓名"],
        custom_directSupervisorTitle: ["直接上司职务", "上司职务"],
        custom_directSupervisorPhone: ["直接上司电话", "上司电话"],
        custom_referencePerson: ["证明人"],
        custom_referencePersonPhone: ["证明人电话"],
      },
    },

    // ============ projectExperience (数组型, 源码行24320-24333) ============
    projectExperience: {
      labels: ["项目经历", "技术项目", "项目经验", "项目/活动经历", "实践活动经验"],
      fields: {
        name: ["项目名称", "项目名称（含校园实践）", "项目标题", "公司/项目名称", "公司或项目名称", "企业/项目"],
        company: ["企业名称", "公司名称", "项目单位", "所属企业", "所属公司"],
        duration: ["项目时间", "开发周期", "起止年月", "时间", "起止时间"],
        role: ["项目角色", "担任职责", "在项目中担任的角色", "职责", "职务","担任角色","担任职务", "职位/角色", "职位或职责"],
        techStack: ["技术栈", "使用技术"],
        contributions: ["项目中职责", "项目贡献", "个人贡献", "代码开发"],
        result: ["项目业绩", "项目成果", "达成效果"],
        startTime: ["开始时间", "开始日期", "起始日期", "起始时间"],
        endTime: ["结束时间", "结束日期"],
        details: ["详细信息", "项目详情", "项目描述", "描述", "描述内容", "项目职责", "项目内容", "实践内容", "主要实践内容说明：", "工作/项目描述", "职责及成就"],
        // [补充] mock 数据里 projectExperience 存在但源码字典缺失的 key
        link: ["项目链接", "链接", "项目地址"],
      },
    },

    // ============ internshipExperience (数组型, 源码行24334-24348) ============
    internshipExperience: {
      labels: [
        "实习经历", "实习经历据说这部分信息超级重要，是面试官的重要参考信息呢！",
        "3.工作/实习经历", "实习/工作经历", "实习/工作经历请填写可提供实习证明的实习经历",
      ],
      fields: {
        company: ["公司名称", "企业名称", "组织名称", "公司或组织名称", "公司", "组织", "组织名称", "实习单位", "实习单位名称", "实习公司","工作单位", "实践名称", "公司/项目名称", "公司或项目名称", "企业/项目"],
        companyNature: ["企业性质", "公司性质", "单位性质"],
        department: ["所在部门", "部门", "部门名称"],
        industry: ["行业类别", "所属行业", "公司行业", "企业行业"],
        workLocation: ["工作地点", "工作所在地", "实习地点", "实习所在地", "办公地点", "所在城市", "工作所在城市", "实习所在城市", "工作城市", "实习城市"],
        workMode: ["工作形式", "用工形式", "工作方式", "用工方式", "工作性质"],
        workType: ["工作类型", "人员类型", "任职类型", "实习或正式"],
        duration: ["实习时间", "实习周期", "起止年月", "时间", "起止时间", "工作时间"],
        position: ["角色", "岗位", "岗位名称", "职位名称", "担任岗位", "职位","职务", "职位/角色", "职位或职责"],
        job51Position: ["标准岗位", "标准职位", "岗位职能"],
        detailedContent: ["工作职责", "工作内容", "实习内容", "实习/工作内容", "实践内容", "主要工作内容", "工作描述", "实习描述", "描述", "描述内容", "职责与业绩", "主要实践内容说明：", "详细内容", "经历描述", "工作/项目描述", "职责及成就"],
        contribution: ["贡献", "个人贡献", "本人职责"],
        result: ["成果", "结果", "实习成果"],
        techStack: ["技术栈", "使用技术"],
        startTime: ["开始时间", "开始日期", "起始日期", "起始时间"],
        endTime: ["结束时间", "结束日期"],
        reasonForLeaving: ["离职原因", "离任原因", "离职理由", "离开原因"],
        phone: ["联系电话", "电话", "手机号"],
        employmentType: ["工作性质", "实习类型"],
        custom_companySize: ["企业规模", "公司规模"],
        custom_subordinateCount: ["下属人数"],
        custom_income: ["收入情况", "薪资收入"],
        ccbWorkType: ["工作类型"],
        ccbDepartmentPosition: ["部门及岗位"],
        ccbDescription: ["工作描述"],
        country: ["所在国家", "工作所在国家", "实习所在国家"],
        custom_directSupervisorName: ["直接上司姓名", "上司姓名"],
        custom_directSupervisorTitle: ["直接上司职务", "上司职务"],
        custom_directSupervisorPhone: ["直接上司电话", "上司电话"],
        custom_referencePerson: ["证明人"],
        custom_referencePersonPhone: ["证明人电话"],
      },
    },

    // ============ combinedExperience (数组型, 源码行24349-24359) ============
    // 注意: "实习/项目经历" 标题在源码里同时命中 combinedExperience + educationAwards
    // 两个类别，getCategoryByTitle 的 returnMultiple 分支才会拆成两条填。本重建版没有
    // educationAwards 类别，"实习/项目经历" 只会命中 combinedExperience 一个，因此必须
    // 保留源码原有的 fields，否则该分区会因为 findFieldByCategory 找不到字段而整块填不上。
    combinedExperience: {
      labels: ["实习/项目经历", "实习/实践"],
      fields: {
        name: ["公司或组织名称", "企业/项目","企业名称","公司名称","工作单位"],
        startTime: ["开始时间", "起始时间"],
        endTime: ["结束时间", "终止时间"],
        position: ["职位或职责", "担任角色"],
        detailedContent: ["工作描述", "工作内容", "实习内容", "实习/工作内容", "实践内容", "职责及成就","职务"],
        duration: ["持续时间", "时间", "起止时间"],
      },
    },

    // ============ publications (数组型, 源码行24360-24370, 剔除了专利相关别名迁到 patents) ============
    publications: {
      labels: ["论文和著作", "论文著作", "论文专著", "发表文章及出版专著", "发表文章及出版著作", "发表文章", "出版专著", "出版著作", "论文", "专著", "著作", "论文专利", "学术成果"],
      fields: {
        paperTitle: ["论文标题", "论文名称", "论文题目", "文章/专著名称", "文章/著作名称", "专著名称", "著作名称", "文章名称"],
        journal: ["期刊名称", "会议名称", "刊物名称", "发表刊物", "刊物/出版社", "出版社", "期刊/会议"],
        publishYear: ["发表年份", "出版时间", "发表时间"],
        publishTime: ["刊载/出版时间", "刊载时间", "出版日期", "出版时间", "发表日期"],
        publicationLevel: ["刊物级别", "期刊级别", "刊物等级", "期刊等级"],
        contribution: ["文章贡献", "作者顺序", "作者位次", "作者身份", "作者贡献"],
        paperLink: ["论文链接", "著作链接", "DOI链接"],
      },
    },

    // ============ patents (数组型) [补充: 源码字典无此类别，mock数据里为空数组] ============
    // 按开发任务书要求人工补充: 专利, 专利名称, 专利号, 申请日期, 授权日期
    patents: {
      labels: ["专利", "论文专利", "专利成果","附加信息"],
      fields: {
        patentName: ["专利名称", "专利标题", "专利题目"],
        patentNumber: ["专利号", "专利编号", "授权编号"],
        patentType: ["专利类型", "专利类别"],
        applicationDate: ["申请日期", "申请时间"],
        authorizationDate: ["授权日期", "授权时间"],
        grantDate: ["获得授权时间"],
        description: ["专利描述", "专利成果", "专利说明"],
      },
    },

    // ============ awards (数组型) [补充: 源码字典里叫 educationAwards，字段不同] ============
    // 源码行24378-24384 的 educationAwards.fields (competitionExperience/rewardsAndHonors)
    // 原样保留合并进来 (mock 数据 awards 数组里也确实出现过这两个 key 的历史遗留条目)，
    // 其余字段 (awardCategory/awardName/awardTime/awardLevel/awardGrade/awardDescription)
    // 按 mock/resume-data.json 的真实样本 key 人工补充别名。
    awards: {
      labels: ["奖励情况", "获奖情况", "奖励", "荣誉奖励", "奖励荣誉", "奖励信息", "奖励活动", "获奖经历", "获奖", "获奖信息", "荣誉情况", "所获奖励"],
      fields: {
        awardScope: ["获奖范围", "奖项范围", "校内校外", "校内/校外"],
        awardClass: ["获奖大类", "荣誉类别"],
        // 保留原有别名，避免既有站点把“获奖类别”从 awardCategory
        // 错迁到新增字段，改变原自动填写行为。
        awardCategory: ["奖项类别", "获奖类别", "奖项分类","获奖类型"],
        awardName: ["奖项名称", "获奖名称", "奖励名称","获奖项","竞赛奖项名称"],
        awardTime: ["获奖时间", "颁奖时间"],
        awardIssuer: ["授予单位", "颁发单位", "授予机构", "颁发机构", "发放单位", "主办单位", "组织单位", "发证单位"],
        awardLevel: ["奖项级别", "获奖级别", "级别","竞赛奖项级别"],
        awardGrade: ["获奖等级", "奖项等级", "名次"],
        awardDescription: ["获奖描述", "奖项描述", "描述","奖项说明"],
        // 源码原文 (educationAwards.fields, 行24380-24383)
        competitionExperience: ["大赛经历"],
        rewardsAndHonors: ["奖励与荣誉"],
      },
    },

    // ============ languageSkills (数组型) [补充: 源码字典无此类别] ============
    languageSkills: {
      labels: ["语言能力", "外语水平", "语言技能", "外语能力", "英语能力", "英语水平", "英语等级"],
      fields: {
        name: ["语言名称", "语言种类", "语言", "外语种类", "外语语种", "外语类别", "语言类型", "语种"],
        level: ["语言等级", "外语等级", "外语水平", "大学英语等级", "熟练程度", "掌握程度", "精通程度"],
        proficiency: ["掌握程度", "熟练程度", "精通程度"],
        certificate: ["英语等级", "英语证书", "四六级", "英语四六级", "外语证书"],
        speakingListening: ["听说能力", "听力口语", "听说", "英语口语水平"],
        readingWriting: ["读写能力", "阅读写作", "读写"],
        score: ["考试分数", "具体成绩", "成绩", "分数"],
        certificate: ["英语等级", "英语证书", "四六级", "英语四六级", "外语证书", "语言证书", "证书类型"],
        certificateName: ["证书名称", "考试名称", "英语证书名称", "外语证书名称", "语言证书名称"],
        obtainedTime: ["获得时间", "取得时间", "考试时间", "获证日期", "证书获得时间", "证书取得时间"],
        description: ["其他说明", "外语说明", "备注", "说明"],
        ccbEnglishLevel: ["英语水平"],
        cet4Score: ["大学英语四级考试成绩", "大学英语四级成绩", "CET4成绩", "CET-4成绩"],
        cet6Score: ["大学英语六级考试成绩", "大学英语六级成绩", "CET6成绩", "CET-6成绩"],
        otherEnglishExam: ["其他英语等级考试", "其他英语考试", "其他英语考试名称"],
        otherEnglishScore: ["其他英语等级考试成绩", "其他英语考试成绩"],
      },
    },

    // ============ otherLanguageSkills (特殊: 仅标题, 无own fields, FillEngine disableOtherLanguage逻辑用) ============
    otherLanguageSkills: {
      labels: ["其他语言能力"],
    },

    // ============ certificates (数组型) [补充: 源码字典里的 certificates 是另一套语义(证书类别开关)，
    // 与 mock/resume-data.json 的证书列表结构不兼容，这里按 mock 真实样本重新定义] ============
    certificates: {
      labels: ["技能证书", "资质证明", "证书","技能信息"],
      fields: {
        certificateType: ["证书类型", "证书类别", "资格类型", "认证类型", "资质类型"],
        certificateName: ["证书名称", "认证名称", "资格证书", "技能证书名称", "技能及证书"],
        obtainedTime: ["获得时间", "颁发时间", "取证时间"],
        description: ["证书描述", "备注", "说明"],
      },
    },

    // ============ campusLeadership (数组型) [补充: 源码字典无此类别] ============
    campusLeadership: {
      labels: ["学生工作", "学生工作经历", "学生干部经历", "校园经历", "在校经历", "校内经历", "校园活动经历", "校内活动", "学生组织经历", "校内任职", "在校职务", "社团职务"],
      fields: {
        projectName: ["组织名称", "社团名称", "部门名称", "职务所在组织"],
        title: ["职务", "担任职务", "职位", "职务名称"],
        leadershipLevel: ["学生干部级别", "干部级别", "职务级别"],
        duration: ["起止时间", "起止年月", "任职时间", "在校任职时间", "社团时间"],
        startTime: ["开始时间", "开始日期", "任职开始时间"],
        endTime: ["结束时间", "结束日期", "任职结束时间"],
        description: ["职责描述", "职务描述", "工作描述", "描述", "社团经历", "具体职责"],
      },
    },

    // ============ campusActivities (数组型) [补充: 源码字典无此类别, mock数据里为空数组] ============
    campusActivities: {
      labels: ["校园活动", "社团活动", "社会及校园活动经历"],
      fields: {
        name: ["活动名称", "社团名称"],
        activityName: ["活动名称", "校园活动名称", "社团活动名称", "活动/社团名称", "实践名称"],
        role: ["担任角色", "角色", "职责", "担任职务", "职位", "本人职责"],
        practiceMode: ["实践方式", "活动方式", "实践形式"],
        duration: ["起止时间", "起止年月", "活动时间", "社团时间"],
        startTime: ["开始时间"],
        endTime: ["结束时间"],
        description: ["活动描述", "活动内容", "社会及校园活动经历", "经历描述", "描述"],
      },
    },

    // ============ familyMembers (数组型) [补充: 源码字典无此类别] ============
    familyMembers: {
      labels: ["家庭成员", "家庭关系", "紧急联系人","家庭情况"],
      fields: {
        name: ["姓名", "家庭成员姓名", "父亲姓名", "母亲姓名"],
        age: ["年龄", "家庭成员年龄", "父亲年龄", "母亲年龄"],
        birthDate: ["出生日期", "出生年月", "生日"],
        politicalStatus: ["政治面貌"],
        relationshipCategory: ["关系类别", "亲属关系类别"],
        relationship: ["关系", "与本人关系", "称谓"],
        workStatus: ["工作状态", "人员状态", "是否有工作", "就业状态"],
        isBankEmployee: ["是否为本行员工", "是否为农行员工", "是否是农行员工", "是否在银行集团工作", "是否在建行集团工作"],
        idNumber: ["身份证号", "证件号码", "证件号"],
        company: ["工作单位", "单位", "公司"],
        position: ["职位", "职务", "担任职务"],
        czbankCompanyPosition: ["工作单位及职务"],
        country: ["目前居住国家", "居住国家"],
        familyLocation: ["家庭所在地", "家庭住址", "家庭所在地城市", "目前居住城市", "居住城市", "所在城市"],
        phone: ["联系电话", "电话", "手机号"],
      },
    },

    // ============ trainingExperience（培训经历） ============
    trainingExperience: {
      labels: ["培训经历", "培训信息"],
      fields: {
        name: ["培训名称", "课程名称"],
        organization: ["培训机构", "主办单位"],
        startTime: ["开始时间", "培训开始时间"],
        endTime: ["结束时间", "培训结束时间"],
        description: ["培训内容", "培训内容及证书", "培训说明"],
      },
    },

    // ============ otherInfo (对象型，农行“其他”合规声明) ============
    otherInfo: {
      labels: ["其他", "其他信息", "其他情况", "合规声明"],
      fields: {
        professionalCertificates: ["所获专业技术资格证书"],
        projectExperienceSummary: ["项目经验"],
        researchResults: ["研究成果"],
        awardsSummary: ["奖惩情况"],
        hasOtherEmploymentAgreement: [
          "是否已与其它单位签有劳动合同或工作协议、或在其它单位工作且尚未办清离职手续",
          "是否与其他单位签有劳动合同或工作协议",
        ],
        hasDisciplinaryRecord: [
          "是否曾被其它单位惩戒、开除、辞退",
          "是否曾被其他单位惩戒、开除、辞退",
        ],
        hasMisconduct: [
          "是否有违法、违规、违纪、涉黑、涉恶或者其它不良行为",
          "是否有违法违规违纪或其他不良行为",
        ],
        hasNonCompete: [
          "是否与其它单位签订带有“同业回避”、条款或其他可能限制其为建行工作的劳动合同",
          "是否存在同业回避或竞业限制",
        ],
        hasSeriousDisease: [
          "是否有精神病、传染病、生理缺陷及其他严重疾病",
          "是否患有精神病、传染病及其他严重疾病",
          "是否有严重疾病",
          "重大疾病声明",
        ],
        hasOtherJobIntention: [
          "是否还有其他应聘意向",
          "除了当前应聘志愿，当前发布职位中是否还有其他意向",
          "是否有其他应聘意向",
        ],
        hasBusinessOrPartTime: [
          "是否经商办企业或在其他单位兼职",
          "是否有经商办企业或在其他单位兼职",
          "经商办企业或兼职",
        ],
        hasRelativeInCompany: [
          "是否有亲属在本单位",
          "是否有亲属在本行",
          "是否与本单位在职员工有近亲属关系",
          "是否与浙商银行在职员工有近亲属关系",
        ],
      },
    },

    // ============ selfIntroduction (对象型, 源码行24371-24377 精简为固定契约形状) ============
    selfIntroduction: {
      labels: ["自我介绍", "个人介绍", "自我陈述", "自我评价", "自我描述", "其他","补充信息","附加信息"],
      fields: {
        selfIntroduction: ["自我评价", "自我介绍", "个人评价", "自我描述", "其他信息", "评价内容"],
        adjustable: ["是否接受调剂", "接受调剂", "愿意调剂"],
      },
    },
  };
})();
