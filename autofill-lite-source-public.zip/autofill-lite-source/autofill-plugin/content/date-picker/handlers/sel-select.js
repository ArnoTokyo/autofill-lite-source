// content/date-picker/handlers/sel-select.js — 年/月 select 组合（起止范围控件）
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   工厂分支 Kn.create() case "selSelect": 行 46067 检测 (.sel_date_year/.sel_date_month 或最近 <li> 内含之)
//   vo.setValue: 行 47558-47601 — 只接受 {startTime, endTime} 对象，缺一即抛错(catch后返回false)，
//     不存在"单值"用法：这是一个"起止年月"范围控件，不是单值控件。
//   an()/cn() (实际填写逻辑): 行 42895-42990 — 已逐行核实:
//     - 容器严格是 element.closest("li")，找不到直接抛错，不做任何宽泛回退
//     - 日期串用 split("-").map(Number) 切出 [年, 月]（option 的 value 就是纯数字年/月）
//     - 在该 <li> 内 querySelectorAll(".sel_date_year") / (".sel_date_month") 取数组:
//       index 0 = 开始年/月, index 1 = 结束年/月（一个 li 里共 4 个 select）
//     - 每个 select: 直接 .value = 数字.toString()，依次派发 change → input (bubbles)，
//       然后 sleep(200)；某个 select 不存在时静默跳过该项
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.DatePicker = AF.DatePicker || {};
  AF.DatePicker._registry = AF.DatePicker._registry || {};

  // 对应源码 an() 里对单个 select 的赋值动作 (行 42950-42960 等四段重复结构)
  async function setSelectValue(select, num) {
    if (!select) return;
    select.value = num.toString();
    select.dispatchEvent(new Event("change", { bubbles: true }));
    select.dispatchEvent(new Event("input", { bubbles: true }));
    await AF.Utils.sleep(200);
  }

  // 对应源码 an()/cn() 行 42895-42990
  async function fillSelSelectRange(element, startTime, endTime) {
    if (!element || !startTime || !endTime) {
      throw new Error("触发元素或日期参数为空");
    }
    var li = element.closest("li");
    if (!li) {
      throw new Error("未找到父级li容器");
    }

    var startParts = String(startTime).split("-").map(Number);
    var startYear = startParts[0];
    var startMonth = startParts[1];
    var endParts = String(endTime).split("-").map(Number);
    var endYear = endParts[0];
    var endMonth = endParts[1];

    var years = li.querySelectorAll(".sel_date_year");
    var months = li.querySelectorAll(".sel_date_month");

    await setSelectValue(years[0], startYear);
    await setSelectValue(months[0], startMonth);
    await setSelectValue(years[1], endYear);
    await setSelectValue(months[1], endMonth);
    return true;
  }

  AF.DatePicker._registry["selSelect"] = function (element) {
    return {
      // vo.setValue (行 47558-47601): 非 {startTime, endTime} 对象一律视为错误，返回 false
      setValue: async function (value) {
        try {
          if (!value) throw new Error("日期为空");
          if (
            typeof value !== "object" ||
            !Object.prototype.hasOwnProperty.call(value, "startTime") ||
            !Object.prototype.hasOwnProperty.call(value, "endTime")
          ) {
            throw new Error("dateValue必须包含startTime和endTime属性");
          }
          await fillSelSelectRange(element, value.startTime, value.endTime);
          return true;
        } catch (e) {
          return false;
        }
      },
    };
  };
})();
