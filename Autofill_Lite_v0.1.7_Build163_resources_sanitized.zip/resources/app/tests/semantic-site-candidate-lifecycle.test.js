"use strict";
const assert = require("assert");
const { candidateMatchesUrl, buildVerifiedSiteCandidate } = require("../semantic-site-candidate-lifecycle");

const candidate = {
  schemaType: "autofill-lite-site-config-candidate",
  schemaVersion: 1,
  page: { hostname: "cmsk1979.zhiye.com", pathname: "/form" },
  configTemplate: {
    name: "cmsk1979.zhiye.com",
    _serverStatus: "candidate",
    _manualCandidate: true,
    _autoConfigStrategy: { mode: "local_first_semantic_candidate_v2" },
    _aiSemanticPatch: {
      fieldMappings: [{ category: "jobIntention", fieldKey: "position", label: "期望从事职业", confidence: 1 }],
      sectionMappings: [{ category: "jobIntention", label: "示例资料", confidence: 1 }]
    }
  },
  summary: { acceptedFieldMappings: 1, acceptedSectionMappings: 1 }
};
const diagnostic = {
  at: "2026-09-17T00:00:00.000Z",
  buildId: "build-test",
  url: "https://cmsk1979.zhiye.com/form",
  filledCount: 39,
  failedCount: 2,
  unhandledCount: 0,
  completionStatus: "partial",
  manualActionRequired: false,
  aiAssist: { siteCandidateInstalled: true },
  failedFields: [
    { label: "期望从事职业", reason: "fill failed" },
    { label: "期望月薪(税前)", reason: "fill failed" }
  ]
};
assert.strictEqual(candidateMatchesUrl(candidate, "https://cmsk1979.zhiye.com/form?x=1"), true);
assert.strictEqual(candidateMatchesUrl(candidate, "https://cmsk1979.zhiye.com/示例资料"), false);
const verified = buildVerifiedSiteCandidate(candidate, diagnostic, { verifiedAt: "2026-09-17T01:00:00.000Z" });
assert.strictEqual(verified.schemaType, "autofill-lite-site-config-verified");
assert.strictEqual(verified.configTemplate._serverStatus, "verified");
assert.strictEqual(verified.configTemplate._manualCandidate, false);
assert.strictEqual(verified.configTemplate._autoConfigStrategy.mode, "local_verified_semantic_candidate_v1");
assert.deepStrictEqual(verified.verification.knownExecutionGapLabels, ["期望从事职业", "期望月薪(税前)"]);
assert.strictEqual(verified.verification.profileValuesIncluded, false);
assert.strictEqual(verified.verification.selectorsAuthoredByAi, false);
console.log("semantic site candidate lifecycle test: PASS");
