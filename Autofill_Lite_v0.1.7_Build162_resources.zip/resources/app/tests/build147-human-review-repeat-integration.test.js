"use strict";

const assert = require("assert");
const path = require("path");
const root = path.join(__dirname, "..");

global.location = { href: "https://example.test/resume", hostname: "example.test", pathname: "/resume" };
global.document = { body: { click() {} } };
global.getComputedStyle = () => ({ display: "block", visibility: "visible", opacity: "1" });

global.window = {
  location: global.location,
  AF: {
    CheckpointCore: {
      recordFingerprint(row) { return [row && row.school, row && row.level, row && row.startTime].join("|"); }
    },
    DomUtils: {
      isElementVisible(node) { return !!node && node.isConnected !== false && node.visible !== false; },
      isDateValue() { return false; },
      isDatePicker() { return false; },
      isSearchSelect() { return false; },
      isNormalSelect() { return false; }
    },
    Utils: { async sleep() {} },
    FillTrace: {
      setFieldContext() {}, event() {},
      readElementValue(element) { return String(element && element.value || ""); }
    },
    SelectAdapter: { _registry: { custom: true }, detectType() { return null; } }
  }
};

require(path.join(root, "autofill-plugin/content/form-handler.js"));
const AF = window.AF;

function input(value) {
  return {
    tagName: "INPUT", value: value || "", isConnected: true, visible: true,
    matches() { return false; }, querySelector() { return null; },
    getBoundingClientRect() { return { width: 160, height: 28, left: 0, top: 0, bottom: 28 }; }
  };
}

(async () => {
  const row = {
    school: "中国人民大学", level: "硕士", degree: "硕士",
    degreeDetailed: "经济学硕士", degreeSimple: "硕士", startTime: "2025-09-01"
  };
  const school = input("北方工业大学");
  const degree = input("哲学硕士");
  const startTime = input("");
  const mappings = [
    { fieldId: "school-id", category: "education", fieldKey: "school", selector: "#school", controlType: "text" },
    { fieldId: "degree-id", category: "education", fieldKey: "degree", selector: "#degree", controlType: "text" },
    { fieldId: "start-id", category: "education", fieldKey: "startTime", selector: "#start", controlType: "text" }
  ];
  const selectorMap = { "#school": [school], "#degree": [degree], "#start": [startTime] };
  const doc = { querySelectorAll(sel) { return selectorMap[sel] || []; } };
  const editor = {
    ownerDocument: doc, isConnected: true, visible: true,
    contains(node) { return node === school || node === degree || node === startTime; },
    querySelectorAll() { return []; }
  };
  school.ownerDocument = doc; degree.ownerDocument = doc; startTime.ownerDocument = doc;

  AF.RuntimeSemanticPatch = { hostname: location.hostname, pathname: location.pathname, recordSelectorMappings: mappings };
  AF.RecordGraph = {
    resolveRuntimeEditorOwnership() {
      return {
        status: "owned", confidence: 1, editorScope: editor, recordIndex: 0,
        mappings, ownershipMode: "identity_match",
        identityFieldKeys: { primary: "school", secondary: "level", requireSecondary: false }
      };
    }
  };

  const config = { _aiSemanticPatch: { fieldMappings: [
    { fieldId: "school-id", label: "毕业院校" },
    { fieldId: "degree-id", label: "学位" },
    { fieldId: "start-id", label: "入学时间" }
  ] } };
  const dataMatcher = {
    resumeData: { education: [row] },
    getCategoryByTitle() { return { category: "education", type: "array", data: [row] }; }
  };
  const matcher = { config, findContainerByTitle() { return editor; } };

  // Build150 semantics: stop at the first recoverable field action instead of
  // finishing the whole record and then protecting a field list.
  let firstPause = null;
  const handler1 = new AF.FormHandler(matcher, dataMatcher);
  handler1.recordCheckpointRuntime = {
    resumed: false, previousCheckpoint: null,
    shouldSkip() { return false; },
    async pause(meta, reason, opts) {
      firstPause = Object.assign({
        category: meta.category, repeatIndex: meta.repeatIndex,
        repeatTotal: meta.repeatTotal, recordFingerprint: meta.recordFingerprint
      }, opts.failureContext || {}, {
        acknowledgeMode: opts.acknowledgeMode, nextAction: opts.nextAction,
        manualFields: opts.manualFields, committedFields: opts.committedFields,
        completedActions: opts.completedActions,
        actionCursor: { nextAction: opts.nextAction, completedActions: opts.completedActions || [] }
      });
      return firstPause;
    }
  };
  handler1.fieldCheckpointRuntime = { async pause() { throw new Error("unexpected field pause"); } };
  AF.FormHandler.fillFormElement = async function () { return true; }; // visual school choice readback remains wrong
  const first = await handler1.fillGraphBackedRepeatRecord({}, "教育背景", { specificCategory: "education" });
  assert.strictEqual(first.success, false);
  assert.strictEqual(handler1.lastExperienceResult.manualReviewPending, true);
  assert.strictEqual(firstPause.reasonCode, "manual_record_action_required");
  assert.deepStrictEqual(firstPause.manualFields, ["school"]);
  assert.strictEqual(firstPause.nextAction, "FIELD:degree:degree-id");

  // User fixes school. Rerun must start at degree, never replay school.
  school.value = "中国人民大学";
  let secondPause = null;
  const handler2 = new AF.FormHandler(matcher, dataMatcher);
  handler2.recordCheckpointRuntime = {
    resumed: true, previousCheckpoint: firstPause,
    shouldSkip() { return false; },
    async pause(meta, reason, opts) {
      secondPause = Object.assign({
        category: meta.category, repeatIndex: meta.repeatIndex,
        repeatTotal: meta.repeatTotal, recordFingerprint: meta.recordFingerprint
      }, opts.failureContext || {}, {
        acknowledgeMode: opts.acknowledgeMode, nextAction: opts.nextAction,
        manualFields: opts.manualFields, committedFields: opts.committedFields,
        completedActions: opts.completedActions,
        actionCursor: { nextAction: opts.nextAction, completedActions: opts.completedActions || [] }
      });
      return secondPause;
    }
  };
  handler2.fieldCheckpointRuntime = { async pause() { throw new Error("unexpected field pause"); } };
  let fieldCalls = [];
  AF.FormHandler.fillFormElement = async function (element) { fieldCalls.push(element); return true; };
  const second = await handler2.fillGraphBackedRepeatRecord({}, "教育背景", { specificCategory: "education" });
  assert.strictEqual(second.success, false);
  assert.strictEqual(school.value, "中国人民大学", "school must not replay before cursor");
  assert.strictEqual(secondPause.reasonCode, "manual_record_action_required");
  assert.deepStrictEqual(secondPause.manualFields, ["degree"]);
  assert.strictEqual(secondPause.nextAction, "FIELD:startTime:start-id");
  assert.strictEqual(fieldCalls.includes(school), false, "school action must stay frozen");

  // User fixes degree. Rerun continues with startTime, then pauses at manual SAVE.
  degree.value = "经济学硕士";
  let savePause = null;
  const handler3 = new AF.FormHandler(matcher, dataMatcher);
  handler3.recordCheckpointRuntime = {
    resumed: true, previousCheckpoint: secondPause,
    shouldSkip() { return false; },
    async pause(meta, reason, opts) {
      savePause = Object.assign({
        category: meta.category, repeatIndex: meta.repeatIndex, repeatTotal: meta.repeatTotal,
        recordFingerprint: meta.recordFingerprint
      }, opts.failureContext || {}, {
        acknowledgeMode: opts.acknowledgeMode, nextAction: opts.nextAction,
        freezeBeforeCursor: opts.freezeBeforeCursor, committedFields: opts.committedFields,
        completedActions: opts.completedActions
      });
      return savePause;
    }
  };
  handler3.fieldCheckpointRuntime = { async pause() { throw new Error("single-record cursor should use record checkpoint"); } };
  fieldCalls = [];
  AF.FormHandler.fillFormElement = async function (element, value) { fieldCalls.push(element); element.value = String(value); return true; };
  const third = await handler3.fillGraphBackedRepeatRecord({}, "教育背景", { specificCategory: "education" });
  assert.strictEqual(third.success, false);
  assert.strictEqual(fieldCalls.length, 1, "only the remaining startTime action should execute");
  assert.strictEqual(fieldCalls[0], startTime);
  assert.strictEqual(savePause.reasonCode, "manual_record_save_required");
  assert.strictEqual(savePause.acknowledgeMode, "complete_on_rerun");
  assert.strictEqual(savePause.nextAction, "NEXT_RECORD");
  assert.strictEqual(handler3.lastExperienceResult.actionCursor, "SAVE");
  assert.strictEqual(school.value, "中国人民大学");
  assert.strictEqual(degree.value, "经济学硕士");

  console.log("build147-human-review-repeat-integration.test.js PASS (Build150 cursor semantics)");
})().catch(err => { console.error(err); process.exit(1); });
