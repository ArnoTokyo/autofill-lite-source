"use strict";
const fs = require("fs");
const path = require("path");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const 示例资料flow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-示例资料flow.js"), "utf8");
const core = fs.readFileSync(path.join(root, "autofill-plugin/content/checkpoint-core.js"), "utf8");
const sites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
const renderer = fs.readFileSync(path.join(root, "renderer.js"), "utf8");

assert(/const BUILD_ID = "\d{8}-[^"]+-\d+";/.test(main), "A: numeric Build id missing");
assert(core.includes('RECOVERY_CHECKPOINT_STORAGE_KEY = "offerAutofillRecoveryCheckpointV2"'), "B: V2 recovery checkpoint key missing");
assert(core.includes('acknowledgeOnRerun: true'), "B: rerun acknowledgement marker missing");
assert(示例资料flow.includes('entry.originalIndex > recoveryResumeRepeatIndex'), "C: 示例资料 recovery must continue after manually handled record");
assert(示例资料flow.includes('Number(recoveryPlanPosition.planIndex) +'), "C: non-示例资料 recovery must advance past manually handled step using resolved plan position");
assert(示例资料flow.includes('manualResumeResolvedStepIndex = storedStepIndex'), "D: manual gate must treat rerun as user acknowledgement");
assert(!示例资料flow.includes('checkpointResolved = storedStep.manualCheckpointResolvedWhen'), "D: runtime must not second-guess manual checkpoint completion");
assert(sites.includes('result.bankcommBocmCommitment = true'), "E: Bankcomm commitment value missing");
assert(sites.includes('type: "bankcommCommitmentCheckboxes"'), "E: Bankcomm commitment fieldSequence missing");
assert(sites.includes('requiredCount: 2'), "E: both Bankcomm commitment boxes must be required");
assert(示例资料flow.includes('function fillBankcommCommitmentCheckboxes'), "F: Bankcomm commitment executor missing");
assert(示例资料flow.includes('text.indexOf("本人承诺")'), "F: commitment executor must bind by local commitment text");
assert(示例资料flow.includes('checkedCount >= requiredCount'), "F: commitment executor must verify both checkboxes");
assert(renderer.includes('手动处理后再次运行会从后续内容继续'), "G: renderer recovery wording not updated");
console.log("checkpoint-user-ack-bankcomm-commitment.test.js passed (A-G)");
