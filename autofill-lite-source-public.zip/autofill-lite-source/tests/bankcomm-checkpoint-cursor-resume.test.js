"use strict";
const fs = require("fs");
const path = require("path");
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const workflow = fs.readFileSync(path.join(root, "autofill-plugin/content/special-site-workflow.js"), "utf8");
const sites = fs.readFileSync(path.join(root, "autofill-plugin/private/private-special-sites.js"), "utf8");
assert(workflow.includes('skipManualCheckpoint: manualResumeResolvedStepIndex === stepIndex'), "execution planning must bypass the resolved manual gate");
assert(workflow.includes('options.skipManualCheckpoint && rowsValidationMode === "manual_checkpoint"'), "resolved checkpoint must also bypass its matching manual row validator");
console.log("bankcomm-checkpoint-cursor-resume.test.js passed");
