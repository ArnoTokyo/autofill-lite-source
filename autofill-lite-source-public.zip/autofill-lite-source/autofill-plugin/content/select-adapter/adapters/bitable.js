// content/select-adapter/adapters/bitable.js — 飞书多维表格 "ud" + "bitable" 适配器
// 源码参考 (webcrack-output/content/deobfuscated.js):
//   UdSelectAdapter (模块2044):        行 5227-5948，triggerUdSelect (混淆名 v/y): 行 5843-5882
//   BitableSelectAdapter (模块5730):   行 18834-19956
//     单选 triggerBitableSingleSelect (混淆名 O/_): 行 19683-19760
//     多选 triggerBitableMultiSelect  (混淆名 j/T): 行 19761-19882
//     openBitableEditor (混淆名 k/E):  行 19611-19648
//     closeBitableEditor (混淆名 S/L): 行 19649-19682
//     isDropdownOpen (混淆名 m):       行 19536-19547 (全局搜 .b-select-dropdown-content 可见元素)
//     getOptionNodes (混淆名 b):       行 19548-19552 (.b-select-option 且可见)
//     matchOption (混淆名 g):          行 19553-19567 (精确 -> includes -> 反向includes)
//     typeIntoSearch (混淆名 w/x):     行 19568-19610 (input.b-select-search)
//
// 这两个原本是独立的两个适配器 (ud 是老版本简单下拉，bitable 是新版飞书多维表格单/多选编辑器)，
// 按任务要求合并到同一个文件，用 detectType 返回的 "ud" / "bitable" 两个 key 分别注册。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};
  var H = SA._helpers;

  // ============ ud (旧版飞书 .ud__select__selector) ============
  // 源码 triggerUdSelect: 点箭头 -> 等 .ud__select__list 出现 -> 通用匹配点击
  function setUdSearchValue(input, value) {
    var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    if (setter && setter.set) setter.set.call(input, String(value));
    else input.value = String(value);
    input.dispatchEvent(new InputEvent("input", {
      bubbles: true,
      cancelable: true,
      composed: true,
      data: String(value),
      inputType: "insertText",
    }));
    input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: String(value).slice(-1) || "" }));
  }

  async function triggerUdSelect(element, value) {
    try {
      var container = element.closest(".ud__select__selector, .ud__select") ||
        element.querySelector && element.querySelector(".ud__select__selector, .ud__select") ||
        element;
      var arrow = container.querySelector(
        ".ud__select__selector__arrow, .ud__select__selector, [role='combobox']"
      ) || container;
      var panelSelector = [
        ".ud__select__list",
        ".ud__select-dropdown",
        ".ud__select__dropdown",
        "[class*='ud__select'][class*='list']",
        "[class*='ud__select'][class*='dropdown']",
        "[role='listbox']",
      ].join(",");
      var optionSelector = [
        ".ud__select__list__item",
        ".ud__select-option",
        "[class*='ud__select'][class*='item']",
        "[class*='ud__select'][class*='option']",
        "[role='option']",
        "[data-option-index]",
        "[data-value]",
      ].join(",");

      async function selectOne(val) {
        // 飞书招聘的学校选择器也是 `.ud__select`，但没有 selector/箭头，内部是
        // 可编辑 input。它必须先输入关键词等待异步候选，再点击候选完成对象选择。
        var editableInput = container.querySelector && container.querySelector(
          "input:not([readonly]):not([disabled])"
        );
        var isAsyncSearch = Boolean(editableInput && !container.querySelector(".ud__select__selector"));
        if (isAsyncSearch) {
          editableInput.focus();
          await AF.DomUtils.safeClickElement(editableInput);
          setUdSearchValue(editableInput, val);
          // 学校候选依赖远程搜索：下拉外壳常常先出现，选项稍后才到。旧逻辑
          // 看到空外壳便立即返回失败，只留下看似正确但未提交的输入文字。
          var deadline = Date.now() + 4000;
          var selected = false;
          while (Date.now() < deadline && !selected) {
            var searchPanel = await H.waitForVisibleDropdownNear(
              editableInput,
              panelSelector,
              ".ud__select",
              500
            );
            if (searchPanel) selected = await H.selectMatchingOption(searchPanel, val, optionSelector);
            if (!selected) {
              // 部分 UD 版本把候选 portal 到 body，面板类名也会变化；仅从可见的
              // option 语义节点中匹配，仍然要求文字匹配后才点击。
              selected = await H.selectMatchingOption(document, val, optionSelector);
            }
            if (!selected) await AF.Utils.sleep(150);
          }
          if (!selected) return false;
          await AF.Utils.sleep(200);
          editableInput.dispatchEvent(new Event("blur", { bubbles: true, composed: true }));
          return true;
        }

        await AF.DomUtils.safeClickElement(arrow);
        await AF.Utils.sleep(200);
        var panel = await H.waitForVisibleDropdownNear(element, panelSelector, ".ud__select__selector, .ud__select", 1800);
        if (!panel) panel = H.findDropdown(element, "ud");
        if (!panel) return false;
        return await H.selectMatchingOption(panel, val, optionSelector);
      }

      var ok;
      if (Array.isArray(value)) {
        ok = false;
        for (var i = 0; i < value.length; i++) {
          var one = await selectOne(value[i]);
          if (one) ok = true;
          await AF.Utils.sleep(150);
        }
      } else {
        ok = await selectOne(value);
      }
      H.dispatchChangeEvents(element);
      return ok;
    } catch (e) {
      return false;
    }
  }

  SA._registry["ud"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        return await triggerUdSelect(element, value);
      },
    };
  };

  // ============ bitable (新版飞书多维表格 单选/多选编辑器) ============
  var EDITOR_SELECTOR = ".bitable-single-selector-editor, .bitable-multi-selector-editor";

  // 源码 m(t): 判断下拉面板是否已展开 —— 面板是被 portal 到 document 顶层的 .b-select-dropdown-content，
  // 优先在传入的 editor 范围内找，找不到再全局搜整个 document (行19536-19547)
  function findOpenBitableDropdown(editorEl) {
    var scopes = editorEl ? [editorEl, document] : [document];
    for (var i = 0; i < scopes.length; i++) {
      var candidates = Array.prototype.slice.call(scopes[i].querySelectorAll(".b-select-dropdown-content"));
      for (var j = 0; j < candidates.length; j++) {
        if (AF.DomUtils.isElementVisible(candidates[j])) return candidates[j];
      }
    }
    return null;
  }

  // 源码 b(t): 取面板内可见的 .b-select-option (行19548-19552)
  function getBitableOptionNodes(dropdown) {
    return Array.prototype.slice.call(dropdown.querySelectorAll(".b-select-option")).filter(function (el) {
      return AF.DomUtils.isElementVisible(el);
    });
  }

  function bitableOptionText(el) {
    return (el.querySelector(".ud__tag__content") || el).textContent.trim();
  }

  // 源码 g(t,e): 精确匹配 -> includes -> 反向includes (行19553-19567)
  function matchBitableOption(nodes, value) {
    var target = String(value).trim().toLowerCase();
    if (!target) return null;
    var exact = nodes.find(function (el) {
      return bitableOptionText(el).toLowerCase() === target;
    });
    if (exact) return exact;
    var partial = nodes.find(function (el) {
      return bitableOptionText(el).toLowerCase().includes(target);
    });
    if (partial) return partial;
    return (
      nodes.find(function (el) {
        var text = bitableOptionText(el).toLowerCase();
        return text && target.includes(text);
      }) || null
    );
  }

  // 源码 w(t,e): 往 input.b-select-search 输入文字触发框架过滤 (行19568-19610)
  async function typeIntoBitableSearch(dropdown, text) {
    var input = dropdown.querySelector("input.b-select-search");
    if (!input) return;
    try {
      var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value") && Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      if (setter) {
        setter.call(input, String(text));
      } else {
        input.value = String(text);
      }
      input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
      await AF.Utils.sleep(300);
    } catch (e) {}
  }

  // 源码 k(t): 打开编辑器面板，若未展开则点击面板触发器 (行19611-19648)
  async function openBitableEditor(element) {
    var editor = element.closest(EDITOR_SELECTOR) || element;
    var trigger = editor.querySelector(".b-select-dropdown-menu") || editor;
    var dropdown = findOpenBitableDropdown(editor);
    if (!dropdown) {
      await AF.DomUtils.safeClickElement(trigger);
      await AF.Utils.sleep(300);
      dropdown = findOpenBitableDropdown(editor);
    }
    return { editor: editor, dropdown: dropdown };
  }

  // 源码 S(t): 关闭面板 —— 先按 Escape，若仍然展开再点 body (行19649-19682)
  async function closeBitableEditor(editor) {
    var input = editor.querySelector("input.b-select-search");
    (input || editor).dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
    await AF.Utils.sleep(150);
    if (findOpenBitableDropdown(editor)) {
      document.body.click();
      await AF.Utils.sleep(150);
    }
  }

  // 源码 O(e,r): 单选流程 (行19683-19760)
  async function triggerBitableSingleSelect(element, value) {
    try {
      if (!element || value === undefined || value === null || value === "") return false;
      var opened = await openBitableEditor(element);
      var editor = opened.editor;
      var dropdown = opened.dropdown;
      if (!dropdown) return false;

      var nodes = getBitableOptionNodes(dropdown);
      var match = matchBitableOption(nodes, value);
      if (!match && nodes.length) {
        await typeIntoBitableSearch(dropdown, value);
        nodes = getBitableOptionNodes(dropdown);
        match = matchBitableOption(nodes, value);
      }
      if (!match) {
        await closeBitableEditor(editor);
        return false;
      }

      await AF.DomUtils.safeClickElement(match);
      await AF.Utils.sleep(150);
      if (findOpenBitableDropdown(editor)) {
        await closeBitableEditor(editor);
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  // 源码 j(e,r): 多选流程 (行19761-19882)
  async function triggerBitableMultiSelect(element, value) {
    try {
      if (!element || value === undefined || value === null) return false;
      var values = Array.isArray(value)
        ? value.map(function (v) { return String(v).trim(); }).filter(Boolean)
        : String(value).split(/[,，、;；/|]/).map(function (v) { return v.trim(); }).filter(Boolean);
      if (!values.length) return false;

      var opened = await openBitableEditor(element);
      var editor = opened.editor;
      var dropdown = opened.dropdown;
      if (!dropdown) return false;

      var hasSearch = !!dropdown.querySelector("input.b-select-search");
      var successCount = 0;
      for (var i = 0; i < values.length; i++) {
        var nodes = getBitableOptionNodes(dropdown);
        var match = matchBitableOption(nodes, values[i]);
        if (!match && hasSearch) {
          await typeIntoBitableSearch(dropdown, values[i]);
          nodes = getBitableOptionNodes(dropdown);
          match = matchBitableOption(nodes, values[i]);
        }
        if (match) {
          await AF.DomUtils.safeClickElement(match);
          successCount++;
          await AF.Utils.sleep(150);
        }
        if (hasSearch) {
          await typeIntoBitableSearch(dropdown, "");
        }
      }
      await closeBitableEditor(editor);
      return successCount > 0;
    } catch (e) {
      return false;
    }
  }

  SA._registry["bitable"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        var isMulti = !!(element.closest && element.closest(".bitable-multi-selector-editor"));
        var result = isMulti ? await triggerBitableMultiSelect(element, value) : await triggerBitableSingleSelect(element, value);
        H.dispatchChangeEvents(element);
        return result;
      },
    };
  };
})();
