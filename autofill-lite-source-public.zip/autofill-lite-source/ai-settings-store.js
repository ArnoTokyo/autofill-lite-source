"use strict";

const fs = require("fs");
const path = require("path");

const PROVIDERS = new Set(["openai-responses", "openai-compatible-chat"]);
const REASONING = new Set(["none", "low", "medium", "high"]);

function clampInt(value, min, max, fallback) {
  const num = Number(value);
  if (!Number.isFinite(num)) return fallback;
  return Math.max(min, Math.min(max, Math.round(num)));
}

function sanitizeEndpoint(raw, provider) {
  const fallback = provider === "openai-compatible-chat"
    ? "https://api.openai.com/v1/chat/completions"
    : "https://api.openai.com/v1/responses";
  const text = String(raw || fallback).trim();
  let url;
  try { url = new URL(text); } catch (_) { throw new Error("API 地址不是有效 URL"); }
  const localHttp = url.protocol === "http:" && ["127.0.0.1", "localhost", "::1"].includes(url.hostname);
  if (url.protocol !== "https:" && !localHttp) throw new Error("API 地址必须使用 HTTPS；仅本机 localhost/127.0.0.1 可使用 HTTP");
  if (url.username || url.password) throw new Error("API 地址中不能包含用户名或密码");
  url.hash = "";
  return url.toString().replace(/\/$/, "");
}

function sanitizeSettings(input) {
  const raw = input && typeof input === "object" ? input : {};
  const provider = PROVIDERS.has(String(raw.provider || "")) ? String(raw.provider) : "openai-responses";
  return {
    provider,
    endpoint: sanitizeEndpoint(raw.endpoint, provider),
    model: String(raw.model || "gpt-5.6-luna").trim().slice(0, 120) || "gpt-5.6-luna",
    reasoningEffort: REASONING.has(String(raw.reasoningEffort || "")) ? String(raw.reasoningEffort) : "low",
    maxOutputTokens: clampInt(raw.maxOutputTokens, 4000, 64000, 24000)
  };
}

class AiSettingsStore {
  constructor(filePath, cryptoAdapter) {
    this.filePath = filePath;
    this.crypto = cryptoAdapter || {};
    this.sessionApiKey = "";
  }

  _readFile() {
    if (!fs.existsSync(this.filePath)) return {};
    try {
      const parsed = JSON.parse(fs.readFileSync(this.filePath, "utf8"));
      return parsed && typeof parsed === "object" ? parsed : {};
    } catch (_) {
      return {};
    }
  }

  _writeFile(data) {
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    fs.writeFileSync(this.filePath, JSON.stringify(data, null, 2), "utf8");
  }

  encryptionAvailable() {
    try { return !!(this.crypto && typeof this.crypto.isAvailable === "function" && this.crypto.isAvailable()); }
    catch (_) { return false; }
  }

  getPublicSettings() {
    const raw = this._readFile();
    const settings = sanitizeSettings(raw);
    const encryptedStored = !!raw.apiKeyEncrypted;
    return Object.assign({}, settings, {
      hasApiKey: !!(encryptedStored || this.sessionApiKey),
      apiKeyStorage: encryptedStored ? "encrypted" : (this.sessionApiKey ? "memory" : "none"),
      encryptionAvailable: this.encryptionAvailable()
    });
  }

  getApiKey() {
    if (this.sessionApiKey) return this.sessionApiKey;
    const raw = this._readFile();
    if (!raw.apiKeyEncrypted) return "";
    if (!this.encryptionAvailable()) return "";
    try {
      const buf = Buffer.from(String(raw.apiKeyEncrypted), "base64");
      return String(this.crypto.decrypt(buf) || "");
    } catch (_) {
      return "";
    }
  }

  save(input) {
    const rawExisting = this._readFile();
    const settings = sanitizeSettings(input);
    const output = Object.assign({}, rawExisting, settings, {
      schemaType: "autofill-lite-ai-settings",
      schemaVersion: 1,
      updatedAt: new Date().toISOString()
    });

    if (input && input.clearApiKey) {
      delete output.apiKeyEncrypted;
      this.sessionApiKey = "";
    } else if (input && Object.prototype.hasOwnProperty.call(input, "apiKey")) {
      const key = String(input.apiKey || "").trim();
      if (key) {
        if (this.encryptionAvailable()) {
          const encrypted = this.crypto.encrypt(key);
          output.apiKeyEncrypted = Buffer.from(encrypted).toString("base64");
          this.sessionApiKey = "";
        } else {
          delete output.apiKeyEncrypted;
          this.sessionApiKey = key;
        }
      }
    }

    this._writeFile(output);
    return this.getPublicSettings();
  }
}

module.exports = {
  AiSettingsStore,
  sanitizeSettings,
  sanitizeEndpoint,
  PROVIDERS,
  REASONING
};
