"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const preload = fs.readFileSync(path.join(root, "ui-preload.js"), "utf8");
const renderer = fs.readFileSync(path.join(root, "renderer.js"), "utf8");
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
const quickHtml = fs.readFileSync(path.join(root, "profile-quick.html"), "utf8");
const quickJs = fs.readFileSync(path.join(root, "profile-quick.js"), "utf8");

assert(html.includes('id="profileQuick"'), "quick-reference toolbar entry must remain available");
assert(preload.includes('copyText: (value) => ipcRenderer.invoke("lite:copy-text", value)'), "clipboard IPC bridge missing");
assert(main.includes('ipcMain.handle("lite:copy-text"'), "reliable main-process clipboard handler missing");
assert(renderer.includes('window.lite.getProfileRaw()'), "current quick reference must read runtime profile data");
assert(renderer.includes('复制分区') && renderer.includes('复制记录'), "docked quick reference must preserve section/record copy actions");
assert(renderer.includes('window.lite.openProfileEditor()'), "quick edit action must reuse existing profile editor");
assert(renderer.includes('window.lite.onProfileUpdated'), "quick reference must refresh after profile saves");
// Keep the old standalone implementation as a non-product fallback/reference, but the toolbar no longer invokes it.
assert(quickHtml.includes('id="search"') && quickJs.includes('window.lite.getProfileRaw()'), "legacy standalone quick view assets should remain intact");
assert(!renderer.includes('$("profileQuick").addEventListener("click", () => window.lite.openProfileQuick())'), "toolbar must no longer open the standalone quick window");
console.log("build163-profile-quick-reference.test.js PASS");
