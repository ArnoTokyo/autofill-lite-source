// content/config/site-templates.js — AF.SITE_TEMPLATES: 内置站点配置
// 源码参考:
//   /Users/dayu/Desktop/网页端/原始代码和索引/content.readable.js
//   /Users/dayu/Desktop/网页端/原始代码和索引/autofill-original-code-index.md
// 说明:
//   这里保存原版内置站点配置表。原版本身带有的 experience / domStrategy 会保留；
//   rebuild 自己推断出来的新站点增强配置不能写进这一层。
//
// 开发任务书.md 任务6.2: 配置结构 = selectors.{container,title,labels,...} +
// 可选 experience / domStrategy / urlPattern / type / name。这里的 27 个域名实际只对应
// 21 套*独立*配置对象 —— 多个域名共用同一个配置对象引用 (阿里4个老域名共用1套、
// 字节系3个域名共用1套、腾讯2个域名共用1套)，与源码 Qe 表的写法保持一致。
(function () {
  "use strict";

  var AF = (window.AF = window.AF || {});

  // ============================================================
  // 配置1: 腾讯 (Be) — Element UI
  // 适用域名: join.qq.com, careers.tencent.com
  // 源码: deobfuscated.js 行 71744-71777
  // ============================================================
  var tencentConfig = {
    urlPattern: /^https?:\/\/(join|careers)\.qq\.com/,
    selectors: {
      container: { class: ".send_box" },
      title: { class: ".send_title" },
      labels: { class: ".subtitle", mergeFallback: true },
      radio: { class: ".el-radio, [role='radio'], .el-radio__input" },
      select: { class: ".el-select" },
      // 腾讯模板历史上使用 Element UI；运行时仍由 DatePicker.detectType
      // 确认实际 adapter，不能只凭这条 selector 强制假定 DOM 结构。
      datePicker: { class: ".el-date-editor, .el-range-editor" },
      buttons: {
        save: { class: ".el-button el-button--primary" },
        edit: { class: ".el-button el-button--text" },
        upload: { class: ".el-button el-button--default is-round" },
      },
      i: { class: ".el-select__caret el-input__icon el-icon-arrow-up" },
    },
    _capabilityPatch: {
      fields: [
        { category: "internshipExperience", fieldKey: "duration", labels: ["起止时间"], fillType: "date", datePrecision: "day", dateFormat: "YYYY-MM-DD", preferAdapter: true },
        { category: "projectExperience", fieldKey: "duration", labels: ["起止时间"], fillType: "date", datePrecision: "day", dateFormat: "YYYY-MM-DD", preferAdapter: true }
      ]
    },
  };

  // ============================================================
  // 配置2: 阿里 (Re.L, 来自 9514.js) — Kuma UI
  // 适用域名: talent.alibaba.com, campushr.alibaba.com,
  //          aidc-jobs.alibaba.com, careers.aliyun.com
  // ============================================================
  var alibabaKumaConfig = {
    selectors: {
      container: { class: ".uxcore-card" },
      title: { class: ".uxcore-card-title-text" },
      labels: { class: ".kuma-label.vertical-align" },
      buttons: {
        save: { class: ".kuma-button.kuma-button-primary" },
        edit: { class: ".edit-operation" },
        preview: { class: ".preview-btn" },
        next: { class: ".next-btn" },
        add: { class: ".add-more-btn-link" },
        class: undefined,
      },
    },
  };

  // ============================================================
  // 配置3: 阿里校招新站 (campus-talent.alibaba.com) — Next/Fusion UI
  // ============================================================
  var alibabaNextConfig = {
    name: "campus-talent.alibaba.com",
    type: "structured",
    preferBuiltIn: true,
    blockManualCandidates: true,
    urlPattern: /^https?:\/\/campus-talent\.alibaba\.com\/personal\/resume/,
    selectors: {
      container: { class: ".FormCard--formCard--XecYBPz" },
      title: { class: ".FormCard--formCardTitle--ntWmoSw" },
      labels: { class: ".next-form-item-label label" },
      radio: { class: ".next-radio-group, .next-checkbox-group, .next-checkbox-wrapper, input[type='checkbox'], input[type='radio']" },
      checkbox: { class: ".next-checkbox-group, .next-checkbox-wrapper, input[type='checkbox']" },
      select: { class: ".next-select, .next-select-trigger" },
      datePicker: { class: ".next-range-picker, .next-date-picker, .next-month-picker" },
      address: { class: ".next-select, .next-select-trigger" },
      upload: { class: ".next-upload input[type='file'], .next-upload" },
      buttons: {
        add: { class: ".table-field-buttons button" },
        save: { class: ".PCButton--primary--_w5k0vo" },
        edit: {},
      },
      section: ".FormCard--formCard--XecYBPz",
      content: ".FormCard--formCardContent--Va5DNrX",
      row: ".next-form-item, .deep-table-field-item, .table-field-tiled-item",
    },
    experience: {
      container: { containerSelector: "#educationInfo, #experienceInfo" },
      card: { cardSelector: ".table-field-tiled-item" },
      add: {
        addButtonSelector: ".table-field-buttons button",
        addButtonText: ["添加教育情况", "添加更多项目经历", "添加更多实习经历", "添加更多工作经历"],
        addTimeoutMs: 500,
      },
      save: {
        requiresSaveBeforeNext: true,
        allowAutoSave: true,
        saveButtonSelector: ".PCButton--primary--_w5k0vo",
        saveButtonText: ["保存"],
        saveTimeoutMs: 500,
      },
      editor: {
        cardEditButtonSelector: "",
        cardEditButtonText: ["编辑", "修改"],
        editModeGuardSelector: "",
        editTimeoutMs: 500,
      },
    },
  };

  // ============================================================
  // 配置4: 字节/小米/米哈游(纸鸢) (qe.c, 来自 8311.js) — Byte UI
  // 适用域名: jobs.bytedance.com, xiaomi.jobs.f.mioffice.cn, career.papegames.com
  // ============================================================
  var byteUiConfig = {
    urlPattern: /^https?:\/\/jobs\.bytedance\.com/,
    selectors: {
      container: {
        class:
          ".createFormSection__3y6MP,.createFormSection-container," +
          ".applyFormModuleWrapper-windows,.applyFormModuleWrapper__2JZaE",
      },
      title: {
        class: ".applyFormModuleWrapper-title,.createFormSection-title,.applyFormModuleWrapper-title",
      },
      labels: { class: ".ud-formily-item-label,.atsx-form-item-label" },
      radio: {
        class: ".radio-input",
        ids: ["gender-male", "gender-female", "degree-bachelor", "degree-master"],
      },
      checkbox: {
        class: ".checkbox-input",
        ids: ["skill-java", "skill-python", "skill-cpp"],
      },
      datePicker: {
        class: ".byte-date-picker",
        ids: ["birthday", "graduateDate", "startDate", "endDate"],
      },
      address: {
        class: ".byte-cascader",
        ids: ["province", "city", "district"],
      },
      select: {
        class: ".byte-select",
        ids: ["education", "school-type", "major-type"],
      },
      upload: {
        class: "byte-upload",
        ids: ["resume-upload", "photo-upload", "transcript-upload"],
      },
      buttons: {
        save: { class: "primary-button", ids: ["saveBtn", "submitBtn", "saveAndNext"] },
        edit: { class: "edit-button", ids: ["editBtn", "modifyBtn", "updateBtn"] },
        preview: { class: "preview-button", ids: ["previewBtn", "viewBtn"] },
        next: { class: "next-button", ids: ["nextBtn", "continueBtn"] },
        add: { class: ".addMore-add", ids: ["addBtn", "addMoreBtn"] },
      },
    },
  };

  // ============================================================
  // 配置4: 京东 (Ve) — Ant Design (CSS Modules 自定义 class)
  // 适用域名: campus.jd.com
  // 源码: deobfuscated.js 行 71781-71805
  // ============================================================
  var jdConfig = {
    selectors: {
      container: { class: ".gridContainer___1K4Rp" },
      title: { class: ".titleContainer___2E0OM" },
      labels: { class: ".filedName___2rXII" },
      radio: { class: ".ant-radio-wrapper" },
      buttons: {
        upload: { class: ".ant-btn" },
        add: { class: ".am-button.addBtn___3r3aQ" },
        class: undefined,
      },
    },
  };

  // ============================================================
  // 配置5: 网易 (inline) — Ant Design
  // 适用域名: campus.163.com
  // 源码: deobfuscated.js 行 72166-72201
  // ============================================================
  var neteaseConfig = {
    selectors: {
      container: { class: ".ant-card" },
      title: { class: ".ant-card-head-title" },
      inputs: { class: ".ant-input" },
      labels: { class: ".ant-form-item-label" },
      radio: { class: ".ant-radio" },
      datePicker: { class: ".ant-calendar-picker-input.ant-input" },
      address: { class: ".ant-input.ant-cascader-input" },
      select: { class: ".ant-select-selection__rendered" },
      upload: { class: ".file-upload" },
      buttons: {
        add: { class: "i.anticon-plus-circle" },
      },
    },
  };

  // ============================================================
  // 配置6: 美团 (inline) — MTD UI
  // 适用域名: zhaopin.meituan.com
  // 源码: deobfuscated.js 行 72202-72234
  // ============================================================
  var meituanConfig = {
    selectors: {
      container: { class: ".base_info_edit, .model_edit" },
      title: { class: ".model_title" },
      labels: { class: ".label" },
      datePicker: { class: ".mtd-input-affix-wrapper" },
      address: { class: ".mtd-select-filter" },
      select: { class: ".mtd-select-filter" },
      buttons: {
        save: { class: ".list_add" },
        edit: { class: ".delete-list" },
        add: { class: ".add_icon" },
      },
    },
  };

  // ============================================================
  // 配置7: 滴滴 (De.v, 来自 3860.js) — SD UI
  // 适用域名: campus.didiglobal.com
  // ============================================================
  var didiSdConfig = {
    selectors: {
      container: { class: '[class^="apply-block-"]' },
      title: { class: '[class^="text-"].theme-border-color' },
      labels: { class: '[class^="title-"]' },
      datePicker: { class: ".sd-Input-common-input-2VyCG" },
      address: { class: ".sd-Input-input-1WaF0 sd-Inpu" },
      select: { class: ".kuma-select2-selection__rendered" },
      upload: { class: ".file-upload" },
      buttons: {
        save: {
          class: "sd-Button-content-1nfPb.sd-Icon-container-1njYU sd-Icon-iconadd-1M_Oo sd-Button-left-icon-B2RzM",
        },
        edit: { class: ".sd-Button-lg-2C1Ss.portrait-upload-btn" },
        add: { class: ".sd-Button-content-1nfPb" },
      },
    },
  };

  // ============================================================
  // 配置8: B站 (inline) — Ant Design
  // 适用域名: jobs.bilibili.com
  // 源码: deobfuscated.js 行 72236-72265
  // ============================================================
  var bilibiliConfig = {
    selectors: {
      container: { class: ".bili-resume-card" },
      title: { class: ".bili-form-card-header" },
      labels: { class: ".ant-form-item-no-colon, span[data-v-259be428]" },
      datePicker: { class: ".input.ant-calendar-picker-input" },
      select: { class: ".ant-select-selection__rendered" },
      upload: { class: ".file-upload" },
      buttons: {
        add: { class: ".bili-form-add" },
        delete: { class: ".bili-form-delete" },
      },
    },
  };

  // ============================================================
  // 配置9: 快手 (Ye) — Ant Design 4.x
  // 适用域名: campus.kuaishou.cn
  // 源码: deobfuscated.js 行 71806-71842
  // ============================================================
  var kuaishouConfig = {
    selectors: {
      container: { class: ".edit-resume-form-item " },
      title: { class: ".section-gorgeously-title" },
      inputs: { class: ".ant-input" },
      radio: { class: ".ant-radio-inner" },
      textareas: { class: ".ant-input" },
      labels: { class: ".ant-form-item-label" },
      select: { class: ".ant-select-selection-search-input" },
      datePicker: { class: ".ant-picker-input" },
      buttons: {
        upload: { class: ".ant-btn" },
        add: { class: ".ant-btn.ant-btn-link" },
        class: undefined,
      },
    },
  };

  // ============================================================
  // 配置10: 百度 (ze) — Brick UI
  // 适用域名: talent.baidu.com
  // 源码: deobfuscated.js 行 71843-71864
  // ============================================================
  var baiduConfig = {
    selectors: {
      container: { class: ".resume-item__d8ts2" },
      title: { class: ".common-title__CPGfm" },
      labels: { class: ".brick-field-label" },
      buttons: {
        upload: { class: ".ant-btn" },
        add: { class: ".add-one__afqKP" },
        class: undefined,
      },
    },
  };

  // ============================================================
  // 配置11: 小红书 (He) — Ant Design + Tailwind
  // 适用域名: job.xiaohongshu.com
  // 源码: deobfuscated.js 行 71865-71886
  // ============================================================
  var xiaohongshuConfig = {
    selectors: {
      container: { class: "div:has(.mb-4)" },
      title: { class: ".flex.items-center.text-h6.font-medium" },
      labels: { class: ".ant-form-item-label" },
      input: { class: ".ant-input" },
      buttons: {
        add: { class: ".ant-btn-stroke" },
        class: undefined,
      },
    },
  };

  // ============================================================
  // 配置12: 米哈游 (Ue) — Ant Design (rfe-resume-form)
  // 适用域名: jobs.mihoyo.com
  // 源码: deobfuscated.js 行 71887-71911
  // ============================================================
  var mihoyoConfig = {
    selectors: {
      container: { class: ".ant-card" },
      title: { class: ".ant-card-head-title" },
      labels: { class: ".ant-form-item-label" },
      input: { class: ".ant-input" },
      radio: { class: ".ant-radio-wrapper" },
      buttons: {
        add: {
          class: ".ant-btn.css-96wdb2.ant-btn-dashed.rfe-resume-form-pc-form-list-renderer-add-btn",
        },
        class: undefined,
      },
    },
  };

  // ============================================================
  // 配置13: 思爱普 (We) — Element UI ✅ 原版有 experience
  // 适用域名: career.sicarrier.com
  // 源码: deobfuscated.js 行 71913-71957
  // ============================================================
  var sicarrierConfig = {
    urlPattern: /^https?:\/\/career\.sicarrier\.com/,
    selectors: {
      container: {
        class:
          ".projectExperience, .educationExperience, .workExperience, " +
          ".baseInfo, .competitionInfo, .scholarshipInfo",
      },
      title: { class: ".form-title" },
      labels: { class: ".el-form-item__label" },
      radio: { class: ".radio-class" },
    },
    experience: {
      container: {
        containerSelector:
          ".projectExperience, .educationExperience, .workExperience, " +
          ".baseInfo, .competitionInfo, .scholarshipInfo",
      },
      card: { cardSelector: ".el-form" },
      editor: {
        containerEditButtonSelector: undefined,
        containerEditButtonText: ["编辑", "Edit", "修改"],
        cardEditButtonSelector: ".el-button.el-button--primary",
        cardEditButtonText: ["编辑", "Edit", "修改"],
        editModeGuardSelector: ".el-input__inner",
        editTimeoutMs: 200,
      },
      add: {
        addButtonSelector: ".el-button.el-button--success",
        addButtonText: ["添加", "Add", "新增", "增加"],
        addTimeoutMs: 200,
      },
      save: {
        requiresSaveBeforeNext: false,
        saveButtonSelector: ".el-button.el-button--primary",
        saveButtonText: ["保存", "Save", "提交", "Submit"],
        saveWaitForSelector: ".save-success-message",
        saveTimeoutMs: 200,
      },
    },
  };

  // ============================================================
  // 配置14: 人保财险 ($e) — Phoenix UI ✅ 原版有 experience
  // 适用域名: picc.zhiye.com
  // 源码: deobfuscated.js 行 71958-72007
  // ============================================================
  var piccConfig = {
    urlPattern: /^https?:\/\/picc\.zhiye\.com/,
    selectors: {
      container: { class: ".sc-iAKWXU.bDEPcy" },
      title: { class: ".sc-efQSVx.eAPYIl" },
      labels: { class: ".form-item__text" },
      radio: {
        class: ".phoenix-radio-group__radioItem > .phoenix-radio.phoenix-radio--withLabel",
      },
      buttons: {
        add: { class: ".sc-iNGGcK.oeWnn" },
      },
    },
    experience: {
      container: { containerSelector: ".sc-iAKWXU.bDEPcy" },
      card: { cardSelector: ".sc-khQegj.iYTdn" },
      editor: {
        containerEditButtonSelector: undefined,
        containerEditButtonText: [],
        cardEditButtonSelector: undefined,
        cardEditButtonText: [],
        editModeGuardSelector: ".form-item__text",
        editTimeoutMs: 100,
      },
      add: {
        addButtonSelector: ".sc-iNGGcK.oeWnn",
        addButtonText: ["添加", "Add", "新增", "增加", "+"],
        addTimeoutMs: 300,
      },
      save: {
        requiresSaveBeforeNext: false,
        saveButtonSelector: undefined,
        saveButtonText: [],
        saveWaitForSelector: undefined,
        saveTimeoutMs: 100,
      },
    },
  };

  // 北森 Phoenix 平台级 DOM 配置。保留 piccConfig 供人保旧页面精确命中；
  // 其他复用 zhiye.com / Phoenix 组件的企业页面通过 DOM 指纹使用本配置。
  var phoenixDomConfig = {
    name: "beisen-phoenix",
    type: "structured",
    // Phoenix 是控件平台而不是企业表单结构；新企业页应先由 AI 识别真实
    // 模块和字段。本模板仅在 AI 不可用时兜底，或为 AI 配置补齐控件能力。
    preferAiStructure: true,
    selectors: {
      container: { class: ".sc-iAKWXU, .sc-cTAqQK" },
      title: { class: ".sc-efQSVx, .sc-jObWnj" },
      labels: { class: ".form-item__text" },
      radio: { class: ".phoenix-radio-group__radioItem > .phoenix-radio" },
      checkbox: { class: ".phoenix-checkbox, .phoenix-checkbox__realInput" },
      select: { class: ".phoenix-select, .phoenix-select__input" },
      datePicker: { class: ".phoenix-date-picker" },
      upload: { class: "input[type='file'], .phoenix-upload" },
      buttons: {
        add: { class: "[id$='_addButton'], .sc-lbhJGD, .sc-iNGGcK, .sc-jeraig, .sc-eJwWfJ" },
        class: undefined,
      },
    },
    // Mature-site capability knowledge that is safe to lift to the Phoenix
    // platform level. These rules do not invent semantics; they only force known
    // Phoenix choice widgets through the mature Phoenix adapter after a field has
    // already been semantically resolved by Core/SiteConfig.
    _capabilityPatch: {
      fields: [
        { category: "jobIntention", fieldKey: "position", labels: ["期望从事职业", "期望职位", "目标岗位"], fillType: "select", adapter: "phoenix", forceAdapter: true, genericPortalFallback: true, searchWhenEmpty: true, dialogChoiceFallback: true, forceDialogProbe: true },
        { category: "jobIntention", fieldKey: "city", labels: ["期望工作城市", "期望城市", "期望工作地点"], fillType: "select", adapter: "phoenix", forceAdapter: true, matchMode: "exactOrContains", fallback: "firstFilteredOption", locationMode: "firstPreferredChinaPath" },
        { category: "jobIntention", fieldKey: "salary", labels: ["期望月薪(税前)", "期望薪资", "期望薪酬"], fillType: "select", adapter: "phoenix", forceAdapter: true, preserveSlashValue: true, genericPortalFallback: true, salaryMode: "monthlyRange" },
        { category: "jobIntention", fieldKey: "currentSalary", labels: ["现月薪(税前)", "当前薪资", "目前薪资"], fillType: "select", adapter: "phoenix", forceAdapter: true, matchMode: "exactOrContains", preserveSlashValue: true },
        { category: "jobIntention", fieldKey: "availability", labels: ["到岗时间", "入职时间"], fillType: "select", adapter: "phoenix", forceAdapter: true, matchMode: "exactOrContains", availabilityMode: "relativeChoice", preserveDateLikeSelect: true },
        { category: "languageSkills", fieldKey: "level", labels: ["掌握程度", "熟练程度"], fillType: "select", adapter: "phoenix", forceAdapter: true, matchMode: "exactOrContains" }
      ]
    },
    // 平台级经历能力：适用于所有 Phoenix 租户。企业 AI 配置仍负责真实
    // 模块标题和字段，ExperienceHandler 负责逐卡新增及“是”门控展开。
    experience: {
      platformConditionalGates: true,
      container: { containerSelector: ".sc-cTAqQK" },
      card: { cardSelector: ".sc-khQegj, .ux-standard-form" },
      add: {
        addButtonSelector: "[id$='_addButton'], .sc-lbhJGD, .sc-iNGGcK, .sc-jeraig, .sc-eJwWfJ",
        addTimeoutMs: 700,
      },
      editor: {
        cardEditButtonSelector: "",
        cardEditButtonText: [],
        editModeGuardSelector: ".form-item__text",
        editTimeoutMs: 100,
      },
      save: {
        requiresSaveBeforeNext: false,
        allowAutoSave: false,
        saveButtonSelector: "",
        saveButtonText: [],
        saveTimeoutMs: 100,
      },
    },
  };

  // 北森/智业旧版 Portal 平台级配置。该版本早于 Phoenix，使用传统
  // RecruitmentPortal.* 表单、直属 form 经历卡片及 sel_date_year/month。
  // 只允许 site-loader 通过严格组合 DOM 指纹启用，不能仅按 zhiye.com 域名套用。
  var legacyZhiyePortalConfig = {
    name: "beisen-legacy-zhiye-portal",
    type: "structured",
    interaction: { enabled: false },
    selectors: {
      container: { class: ".dl_basicinfo, .dl_educationwrap.mainContainer" },
      section: ".dl_basicinfo, .dl_educationwrap.mainContainer",
      content: ".form_container",
      row: ".form_container li",
      title: {
        class: ".dl_basicinfo > .dl_greyline_bg .dl_menutit, .dl_educationwrap.mainContainer > .dl_greyline_bg .dl_menutit",
      },
      labels: { class: ".form_container li > label" },
      select: { class: "select" },
      address: { class: ".ConstDictSingleSelect" },
      datePicker: { class: ".sel_date_year, .sel_date_month, .Wdate" },
      buttons: {
        add: { class: "a.dl_add_ico" },
        edit: { class: "" },
        save: { class: "" },
      },
    },
    allowAutoSaveExperienceCards: false,
    experience: {
      container: { containerSelector: ".dl_educationwrap.mainContainer" },
      card: { cardSelector: ":scope > form:not([id^='emptyFrom_'])" },
      add: {
        addButtonSelector: ":scope > .dl_mgtop10 a.dl_add_ico",
        addButtonText: ["继续添加"],
        addTimeoutMs: 300,
      },
      editor: {
        containerEditButtonSelector: "",
        containerEditButtonText: [],
        cardEditButtonSelector: "",
        cardEditButtonText: [],
        editModeGuardSelector: ".form_container li > label",
        editTimeoutMs: 100,
      },
      save: {
        requiresSaveBeforeNext: false,
        allowAutoSave: false,
        saveButtonSelector: "",
        saveButtonText: [],
        saveTimeoutMs: 100,
      },
    },
  };

  // 飞书招聘 SaaS 平台级配置。平台外壳是 saas-career / atsx，简历表单本身
  // 使用 UD Formily + Bitable/Throne 控件。选择器只依赖稳定语义前缀，不能绑定
  // `__1d6856` 这类每次构建都可能变化的 CSS 哈希。
  var feishuFormilyConfig = {
    name: "feishu-formily",
    type: "structured",
    selectors: {
      container: {
        class: "[class^='applyFormModuleWrapper__'], [class*=' applyFormModuleWrapper__']",
      },
      title: { class: ".applyFormModuleWrapper-title" },
      labels: { class: ".ud-formily-item-label" },
      radio: { class: ".ud__radio, [role='radio'], input[type='radio']" },
      checkbox: { class: ".ud__checkbox, [role='checkbox'], input[type='checkbox']" },
      select: { class: ".ud__select, .ud__select__selector" },
      datePicker: {
        class: ".ud__picker, .ud-datepicker, .throne-biz-date-range-picker-wrapper",
      },
      upload: { class: "input[type='file'], .ud__upload" },
      buttons: {
        add: {
          class: "[class^='apply-form-array-card-add-float-right'], [class*=' apply-form-array-card-add-float-right']",
        },
      },
    },
    experience: {
      container: {
        containerSelector: "[class^='applyFormModuleWrapper__'], [class*=' applyFormModuleWrapper__']",
      },
      card: {
        cardSelector: "[class^='apply-form-array-card__'], [class*=' apply-form-array-card__']",
      },
      add: {
        addButtonSelector: "[class^='apply-form-array-card-add-float-right'], [class*=' apply-form-array-card-add-float-right']",
        addButtonText: ["添加", "新增", "增加", "Add", "+"],
        addTimeoutMs: 3000,
      },
      save: {
        requiresSaveBeforeNext: false,
        allowAutoSave: false,
      },
      editor: {
        containerEditButtonSelector: undefined,
        containerEditButtonText: [],
        cardEditButtonSelector: undefined,
        cardEditButtonText: [],
        editModeGuardSelector: ".ud-formily-item-label",
        editTimeoutMs: 300,
      },
    },
  };

  // ============================================================
  // 配置15: 拼多多 (Ke) — Ant Design + Rocket UI ✅ 原版有 experience
  // 适用域名: careers.pddglobalhr.com
  // 源码: deobfuscated.js 行 72008-72057
  // ============================================================
  var pddConfig = {
    urlPattern: /^https?:\/\/careers\.pddglobalhr\.com/,
    selectors: {
      container: {
        class:
          '#basic, #education, #language, #selfAssessment, #account, #resume, #workFile, ' +
          '[class^="wrapper-base-info_wrapper"], [class^="wrapper-education-experience_wrapper"]',
      },
      title: {
        class:
          '.divider-title_divider__8bzpH > .divider-title_title__fXWvL, [class^="divider-title_title"]',
      },
      labels: {
        class: ".ant-form-item-label > label, .rocket-form-field-item-label > label",
      },
      radio: { class: ".ant-radio-wrapper, .rocket-radio-wrapper" },
      buttons: {
        add: { class: '[class^="wrapper-education-experience_addBtn"]' },
      },
    },
    experience: {
      container: {
        containerSelector:
          '#basic, #education, #language, #selfAssessment, #account, #resume, #workFile, ' +
          '[class^="wrapper-education-experience_wrapper"]',
      },
      card: { cardSelector: "form > div" },
      editor: {
        containerEditButtonSelector: undefined,
        containerEditButtonText: [],
        cardEditButtonSelector:
          'span[class*="wrapper-education-experience_innerBtn"][class*="wrapper-education-experience_save"]',
        cardEditButtonText: ["编辑", "Edit", "修改"],
        editModeGuardSelector: ".ant-input, .ant-select, input, select, textarea",
        editTimeoutMs: 500,
      },
      add: {
        addButtonSelector: '[class^="wrapper-education-experience_addBtn"]',
        addButtonText: ["添加教育经历", "添加工作经历", "添加经历", "添加", "Add", "新增", "+"],
        addTimeoutMs: 500,
      },
      save: {
        requiresSaveBeforeNext: true,
        allowAutoSave: true,
        saveButtonSelector: 'span[class*="wrapper-education-experience_save"], .ant-btn-primary',
        saveButtonText: ["保存", "Save", "确定", "确认"],
        saveWaitForSelector: undefined,
        saveTimeoutMs: 500,
      },
      special: {
        nonBlockingCategories: ["languageSkills"],
      },
    },
  };

  // ============================================================
  // 配置16: 美的 (Ze) — Ant Design ✅ 原版有 experience
  // 适用域名: careers.midea.com
  // 源码: deobfuscated.js 行 72058-72107
  // ============================================================
  var mideaConfig = {
    urlPattern: /^https?:\/\/careers\.midea\.com/,
    selectors: {
      container: {
        class:
          ".basicResumeForm, .eduResumeForm, .internshipWorkResumeForm, " +
          ".projectResumeForm, .awardsResumeForm, .patentResumeForm, " +
          ".paperResumeForm, .languageResumeForm, .specialtyResumeForm, " +
          ".remarkResumeForm, .attachment-form",
      },
      title: { class: ".css-ielwhl" },
      labels: { class: ".ant-form-item-label > label > .form-label > .label-content" },
      radio: { class: ".ant-radio-button-wrapper" },
      buttons: {
        add: { class: ".add-title-btn" },
      },
    },
    experience: {
      container: {
        containerSelector:
          ".basicResumeForm, .eduResumeForm, .internshipWorkResumeForm, " +
          ".projectResumeForm, .awardsResumeForm, .patentResumeForm, " +
          ".paperResumeForm, .languageResumeForm, .specialtyResumeForm, .remarkResumeForm",
      },
      card: { cardSelector: ".multiple-block" },
      editor: {
        containerEditButtonSelector: undefined,
        containerEditButtonText: [],
        cardEditButtonSelector: undefined,
        cardEditButtonText: [],
        editModeGuardSelector: ".ant-form-item-label > label > .form-label > .label-content",
        editTimeoutMs: 100,
      },
      add: {
        addButtonSelector: ".add-title-btn,.css-1dxxn90",
        addButtonText: ["添加", "Add", "新增", "增加", "+"],
        addTimeoutMs: 300,
      },
      save: {
        requiresSaveBeforeNext: false,
        saveButtonSelector: undefined,
        saveButtonText: [],
        saveWaitForSelector: undefined,
        saveTimeoutMs: 100,
      },
    },
  };

  // ============================================================
  // 配置17: 智联校园 (Je) — Element UI ✅ 原版有 experience
  // 适用域名: xiaoyuan.zhaopin.com
  // 源码: deobfuscated.js 行 72108-72155
  // ============================================================
  var zhaopinCampusConfig = {
    selectors: {
      container: { class: ".apply-module" },
      title: { class: ".form-content--title" },
      labels: { class: ".el-form-item__label" },
      radio: { class: ".radio-class" },
    },
    experience: {
      container: { containerSelector: ".apply-module" },
      card: { cardSelector: ".apply-form" },
      editor: {
        containerEditButtonSelector: undefined,
        containerEditButtonText: ["编辑", "Edit", "修改"],
        cardEditButtonSelector: ".icon-box:not(.icon-box-disabled)",
        cardEditButtonText: ["编辑", "Edit", "修改"],
        editModeGuardSelector: "input",
        editTimeoutMs: 200,
      },
      add: {
        addButtonSelector: ".icon-box",
        addButtonText: ["添加", "Add", "新增", "增加"],
        addTimeoutMs: 200,
      },
      save: {
        requiresSaveBeforeNext: true,
        saveButtonSelector: ".el-button",
        saveButtonText: ["保存", "Save", "提交", "Submit"],
        saveWaitForSelector: ".save-success-message",
        saveTimeoutMs: 200,
      },
      special: {
        singleCardMode: true,
        dataIndexByCardCount: true,
      },
    },
  };

  // ============================================================
  // 配置18: 泛微 (inline) — iView UI ✅ 原版有 domStrategy
  // 适用域名: job.fandow.com
  // 源码: deobfuscated.js 行 72277-72295
  // ============================================================
  var fandowConfig = {
    selectors: {
      container: { class: ".ivu-row" },
      title: { class: ".form-part > .title" },
      labels: { class: ".ivu-form-item-label" },
    },
    domStrategy: {
      containerSearch: {
        useSiblingContainer: true,
        parentLevels: 1,
      },
    },
  };

  // ============================================================
  // 配置19: Moka / Mokahr — SD UI structured 类型
  // 适用域名: app.mokahr.com，以及使用相同 Moka DOM 的企业定制域名
  // ============================================================
  var mokaSdConfig = {
    name: "moka",
    type: "structured",
    // Moka 是控件平台而不是企业表单结构；新企业页先由 AI 识别真实模块，
    // 本模板只在 AI 不可用时兜底，并提供 SD 控件和条件式经历能力。
    preferAiStructure: true,
    urlPattern: /^https?:\/\/(?:[^/]+\.)?mokahr\.com/i,
    selectors: {
      section: '[class^="apply-block-"], [class*=" apply-block-"], [class^="basic-block-"], [class*=" basic-block-"]',
      container: {
        class: '[class^="apply-block-"], [class*=" apply-block-"], [class^="basic-block-"], [class*=" basic-block-"]',
      },
      title: {
        class: '[class^="blockTitle-"] [class^="text-"], [class*=" blockTitle-"] [class*=" text-"]',
      },
      labels: {
        class: '[class^="title-"], [class*=" title-"], [class^="filed-title-"], [class*=" filed-title-"]',
      },
      content: '[class^="apply-fields-"], [class*=" apply-fields-"]',
      row: '[class^="apply-field-"], [class*=" apply-field-"], [class^="field-"], [class*=" field-"]',
      select: {
        class: '[class^="sd-Dropdown-container-"], [class*=" sd-Dropdown-container-"], [class^="sd-Select-container-"], [class*=" sd-Select-container-"]',
      },
      datePicker: {
        class: '[class*="sd-picker-input-"], [class*="month-range-select"], [class*="date_info"]',
      },
      radio: {
        class: '[class^="sd-RadioGroup-container"], [class*=" sd-RadioGroup-container"], [class^="sd-Checkbox-container-"], [class*=" sd-Checkbox-container-"]',
      },
      upload: {
        class: 'input[type="file"], [class*="file-upload"], [class*="upload"]',
      },
      buttons: {
        add: {
          class: '[class^="blockTitle-"] a, [class*=" blockTitle-"] a, [class^="blockTitle-"] button, [class*=" blockTitle-"] button',
        },
        edit: { class: 'button[class*="sd-Button-container-"]' },
        save: { class: 'button[class*="sd-Button-container-"]' },
      },
    },
    experience: {
      container: {
        // 空经历区块还没有 multi-* 卡片，也必须定位到自己的区块。
        containerSelector: '[class^="apply-block-"], [class*=" apply-block-"]',
      },
      card: {
        cardSelector: '[class^="apply-fields-"][class*="multi-"], [class*=" apply-fields-"][class*=" multi-"]',
      },
      add: {
        addButtonSelector: '[class^="blockTitle-"] a, [class*=" blockTitle-"] a, [class^="blockTitle-"] button, [class*=" blockTitle-"] button',
        addButtonText: ["添加", "新增", "增加", "Add"],
      },
      editor: {
        cardEditButtonSelector: 'button[class*="sd-Button-container-"]',
        cardEditButtonText: ["编辑", "修改", "Edit"],
      },
      save: {
        // Moka经历卡为行内持久化：添加下一条不会依赖逐卡“保存”事务。
        // 明确声明后，Checkpoint 不再把“删除本条/添加”等普通 SD 按钮误判成保存按钮。
        inlinePersistence: true,
        requiresSaveBeforeNext: false,
        saveButtonSelector: 'button[class*="sd-Button-container-"]',
        saveButtonText: ["保存", "确定", "Save"],
      },
    },
  };

  // ============================================================
  // 域名 -> 配置映射表
  // ============================================================
  AF.SITE_TEMPLATES = {
    "join.qq.com": tencentConfig,
    "careers.tencent.com": tencentConfig,

    "talent.alibaba.com": alibabaKumaConfig,
    "campushr.alibaba.com": alibabaKumaConfig,
    "aidc-jobs.alibaba.com": alibabaKumaConfig,
    "careers.aliyun.com": alibabaKumaConfig,
    "campus-talent.alibaba.com": alibabaNextConfig,

    "jobs.bytedance.com": byteUiConfig,
    "xiaomi.jobs.f.mioffice.cn": byteUiConfig,
    "career.papegames.com": byteUiConfig,

    "campus.jd.com": jdConfig,
    "campus.163.com": neteaseConfig,
    "zhaopin.meituan.com": meituanConfig,
    "campus.didiglobal.com": didiSdConfig,
    "jobs.bilibili.com": bilibiliConfig,
    "campus.kuaishou.cn": kuaishouConfig,
    "talent.baidu.com": baiduConfig,
    "job.xiaohongshu.com": xiaohongshuConfig,
    "jobs.mihoyo.com": mihoyoConfig,

    "career.sicarrier.com": sicarrierConfig,
    "picc.zhiye.com": piccConfig,
    "careers.pddglobalhr.com": pddConfig,
    "careers.midea.com": mideaConfig,
    "xiaoyuan.zhaopin.com": zhaopinCampusConfig,
    "job.fandow.com": fandowConfig,
    "app.mokahr.com": mokaSdConfig,
  };

  // 导出各配置对象引用，供 site-loader.js 的 detectSiteType() 7种DOM特征检测
  // 直接复用同一个配置对象 (与源码 detectSiteType 返回同一个 webpack 模块引用一致)。
  AF.SITE_TEMPLATE_REFS = {
    tencent: tencentConfig,
    alibabaKuma: alibabaKumaConfig,
    alibabaNext: alibabaNextConfig,
    byteUi: byteUiConfig,
    mokaSd: mokaSdConfig,
    didiSd: didiSdConfig,
    picc: phoenixDomConfig,
    beisenPhoenix: phoenixDomConfig,
    legacyZhiyePortal: legacyZhiyePortalConfig,
    feishuFormily: feishuFormilyConfig,
  };

  // ============================================================
  // AF.SiteConfig — processConfig() + convertAiResult()
  // ============================================================

  var AF_NS = (AF.SiteConfig = AF.SiteConfig || {});

  function mergeSelectorText(existing, extras) {
    var parts = String(existing || "")
      .split(",")
      .map(function (s) { return s.trim(); })
      .filter(Boolean);
    (extras || []).forEach(function (selector) {
      if (parts.indexOf(selector) === -1) parts.push(selector);
    });
    return parts.join(", ");
  }

  // processConfig(): 给配置注入公共属性 common (源码行72949-72962)
  // 无论配置来自硬编码/DOM检测/本地缓存/AI生成，返回前都会经过这一步。
  AF_NS.processConfig = function (config) {
    if (!config || !config.selectors) {
      return null;
    }
    var processed = {};
    for (var k in config) {
      if (Object.prototype.hasOwnProperty.call(config, k)) {
        processed[k] = config[k];
      }
    }
    processed.selectors = Object.assign({}, config.selectors || {});
    processed.selectors.labels = Object.assign({}, processed.selectors.labels || {});
    processed.selectors.labels.class = mergeSelectorText(processed.selectors.labels.class, [
      ".work-describe .text",
      ".study-time-wrapper .text",
      ".field-label",
      ".form-label",
      ".form-item-label",
      ".resume-module-label",
    ]);
    // 框架级选择器作为所有来源配置的安全兜底。这样旧的 AI candidate 缓存即使没有
    // select/datePicker/upload 槽位，也能在重新生成配置前识别飞书招聘 UD 控件。
    processed.selectors.select = Object.assign({}, processed.selectors.select || {});
    processed.selectors.select.class = mergeSelectorText(processed.selectors.select.class, [
      ".ud__select",
      ".ud__select__selector",
      ".next-select",
      ".next-select-trigger",
    ]);
    processed.selectors.datePicker = Object.assign({}, processed.selectors.datePicker || {});
    processed.selectors.datePicker.class = mergeSelectorText(processed.selectors.datePicker.class, [
      ".ud__picker",
      ".ud__picker-input",
      ".ud__picker-range",
      ".ud-datepicker",
      ".throne-biz-date-range-picker-wrapper",
      ".throne-biz-date-range-picker-input",
      ".next-range-picker",
      ".next-date-picker",
      ".next-month-picker",
    ]);
    processed.selectors.address = Object.assign({}, processed.selectors.address || {});
    processed.selectors.address.class = mergeSelectorText(processed.selectors.address.class, [
      ".ud__cascader",
      "[class*='ud__cascader']",
      ".cascader-plugins-wrap",
      ".next-select",
      ".next-select-trigger",
    ]);
    processed.selectors.upload = Object.assign({}, processed.selectors.upload || {});
    processed.selectors.upload.class = mergeSelectorText(processed.selectors.upload.class, [
      "input[type='file']",
      ".ud__upload",
      "[class*='ud__upload']",
      ".next-upload",
    ]);
    processed.common = {
      requiredMark: ["*", "必填", "必须"],
      errorClass: ["error", "invalid", "has-error"],
      successClass: ["success", "valid", "has-success"],
      disabledClass: ["disabled", "readonly", "inactive"],
    };
    return processed;
  };

  // convertAiResult(): an() 格式转换函数 (源码行76224-76280, 逐行照搬)
  // 把 AI/后端返回的 { type, labels, radioButtons, containers, titles, addButtons,
  // editButtons } 简化格式转换成内部标准配置格式 (selectors.*)。
  AF_NS.convertAiResult = function (aiResult) {
    var hostname = window.location.hostname;
    var result;

    if (aiResult.type === "simple") {
      result = {
        type: "simple",
        selectors: {
          labels: { class: aiResult.labels || undefined },
          radio: {
            class:
              aiResult.radioButtons && aiResult.radioButtons.length === 0
                ? null
                : aiResult.radioButtons,
          },
          select: { class: aiResult.selects || undefined },
          datePicker: { class: aiResult.datePickers || undefined },
          address: { class: aiResult.addresses || undefined },
          upload: { class: aiResult.uploads || undefined },
        },
      };
    } else {
      result = {
        type: "structured",
        selectors: {
          container: { class: aiResult.containers || undefined },
          title: { class: aiResult.titles || undefined },
          labels: { class: aiResult.labels || undefined },
          buttons: {
            add: { class: aiResult.addButtons || undefined },
            edit: { class: aiResult.editButtons || undefined },
            class: undefined,
          },
          radio: {
            class:
              aiResult.radioButtons && aiResult.radioButtons.length === 0
                ? null
                : aiResult.radioButtons,
          },
          select: { class: aiResult.selects || undefined },
          datePicker: { class: aiResult.datePickers || undefined },
          address: { class: aiResult.addresses || undefined },
          upload: { class: aiResult.uploads || undefined },
        },
      };
    }

    if (hostname) {
      var escaped = hostname.replace(/\./g, "\\.");
      result.urlPattern = new RegExp("^https?://(.*\\.)?" + escaped);
    }

    return result;
  };
})();
