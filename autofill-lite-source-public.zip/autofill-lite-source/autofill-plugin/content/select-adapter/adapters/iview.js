// content/select-adapter/adapters/iview.js — iView (.ivu-select) 适配器
// 源码参考 (webcrack-output/content/deobfuscated.js, 模块3620):
//   IViewSelectAdapter (混淆名 L, 行14744-14751) 直接继承 GenericSelectAdapter (混淆名 E)，
//   自身没有覆盖 setValue，也就是说 iView 走的就是 triggerGenericSelect 通用流程
//   (点击 element 本身 -> 全局找可见下拉面板 -> 通用文字匹配点击)，没有任何 iView 专属定位逻辑。
// 选择器配置 SA._config.iview (container/.ivu-select, trigger/.ivu-select-selection,
// dropdown/.ivu-select-item) 仅供 detectType 分类使用，setValue 本身不用它。
(function () {
  "use strict";
  var AF = (window.AF = window.AF || {});
  AF.SelectAdapter = AF.SelectAdapter || {};
  var SA = AF.SelectAdapter;
  SA._registry = SA._registry || {};

  SA._registry["iview"] = function (element, valueType, sectionEl) {
    return {
      selectValue: async function (value) {
        return await SA._helpers.triggerGenericSelect(element, value);
      },
    };
  };
})();
